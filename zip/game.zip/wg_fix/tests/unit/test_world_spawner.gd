# res://tests/unit/test_world_spawner.gd
extends GutTest

## Unit-Tests für WorldSpawner.
##
## Strategie: WorldSpawner extends RefCounted — direkt instanziierbar.
## EntityOrchestrator und WorldData als einfache Doubles/Stubs.
## Kein SceneTree-Overhead.
##
## Abgedeckt:
##   P1 — Typisiertes Spawning: willow_tree / maple_tree / copper_ore werden gespawnt
##   P1 — Harvest-Filter: geerntete typed Positions werden nicht gespawnt
##   P1 — Seed-Konsistenz: _generate_positions() nutzt world_seed aus WorldData
##   P0 — Legacy-Pfad: leere typed_*_positions → oak_tree/iron_ore Fallback

# ─────────────────────────────────────────────
# Stubs
# ─────────────────────────────────────────────

## Minimaler EntityOrchestrator-Stub: zeichnet alle spawn_entity()-Aufrufe auf.
class StubOrchestrator:
	var spawned: Array = []  ## Array von { type_id, position }

	func spawn_entity(type_id: String, pos: Vector3, _cfg: Dictionary = {}, _pid: int = 1) -> Node3D:
		spawned.append({"type_id": type_id, "position": pos})
		return Node3D.new()

	func get_entity_count() -> int:
		return spawned.size()

## Minimal-Stub für TerrainGenerator — get_height_at() gibt 0 zurück.
class StubTerrain:
	func get_height_at(_x: float, _z: float) -> float:
		return 0.0

# ─────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────

var _orchestrator: StubOrchestrator
var _data:         WorldData
var _terrain:      StubTerrain

func before_each() -> void:
	_orchestrator = StubOrchestrator.new()
	_data         = WorldData.new()
	_terrain      = StubTerrain.new()

# ─────────────────────────────────────────────
# Typisiertes Spawning (P1)
# ─────────────────────────────────────────────

func test_typed_trees_all_spawned() -> void:
	## Wenn typed_tree_positions befüllt ist, müssen alle Typen spawnen.
	_data.add_typed_tree("willow_tree", Vector3(1, 0, 1))
	_data.add_typed_tree("maple_tree",  Vector3(2, 0, 2))
	_data.add_typed_tree("oak_tree",    Vector3(3, 0, 3))

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var type_ids := _orchestrator.spawned.map(func(e): return e["type_id"])
	assert_true("willow_tree" in type_ids, "willow_tree muss gespawnt werden")
	assert_true("maple_tree"  in type_ids, "maple_tree muss gespawnt werden")
	assert_true("oak_tree"    in type_ids, "oak_tree muss gespawnt werden")

func test_typed_ores_all_spawned() -> void:
	_data.add_typed_ore("iron_ore",   Vector3(-4, 0, 6))
	_data.add_typed_ore("copper_ore", Vector3(6,  0, -8))

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var type_ids := _orchestrator.spawned.map(func(e): return e["type_id"])
	assert_true("iron_ore"   in type_ids, "iron_ore muss gespawnt werden")
	assert_true("copper_ore" in type_ids, "copper_ore muss gespawnt werden")

# ─────────────────────────────────────────────
# Harvest-Filter (P0/P1)
# ─────────────────────────────────────────────

func test_harvested_typed_tree_not_spawned() -> void:
	## Geerntete Position (via make_key) darf nicht respawnt werden.
	var pos := Vector3(5, 0, 5)
	_data.add_typed_tree("oak_tree", pos)
	_data.mark_harvested(WorldData.make_key("oak_tree", pos))

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var tree_spawns := _orchestrator.spawned.filter(
		func(e): return e["type_id"] == "oak_tree" and e["position"].is_equal_approx(pos)
	)
	assert_eq(tree_spawns.size(), 0,
		"Geerntete oak_tree-Position darf nicht gespawnt werden")

func test_harvested_typed_ore_not_spawned() -> void:
	var pos := Vector3(-4, 0, 6)
	_data.add_typed_ore("copper_ore", pos)
	_data.mark_harvested(WorldData.make_key("copper_ore", pos))

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var ore_spawns := _orchestrator.spawned.filter(
		func(e): return e["type_id"] == "copper_ore" and e["position"].is_equal_approx(pos)
	)
	assert_eq(ore_spawns.size(), 0,
		"Geerntete copper_ore-Position darf nicht gespawnt werden")

func test_unharvested_type_at_same_position_still_spawns() -> void:
	## Nur der geerntete Typ wird gefiltert — andere Typen an selber Position spawnen.
	var pos := Vector3(5, 0, 5)
	_data.add_typed_tree("oak_tree",    pos)
	_data.add_typed_tree("willow_tree", pos)
	_data.mark_harvested(WorldData.make_key("oak_tree", pos))

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var willow_spawns := _orchestrator.spawned.filter(
		func(e): return e["type_id"] == "willow_tree" and e["position"].is_equal_approx(pos)
	)
	assert_eq(willow_spawns.size(), 1,
		"Willow an selber Position wie geerntete Eiche muss trotzdem spawnen")

# ─────────────────────────────────────────────
# Seed-Konsistenz (P1)
# ─────────────────────────────────────────────

func test_generate_positions_uses_world_seed() -> void:
	## _generate_positions() ohne WorldGenerationService → Hardcode-Defaults.
	## world_seed muss in _data gesetzt werden wenn er 0 war.
	_data.world_seed = 42
	var spawner := _make_spawner_no_worldgen()
	spawner._generate_positions()
	## Nach _generate_positions(): typed_tree_positions muss befüllt sein.
	assert_false(_data.typed_tree_positions.is_empty(),
		"_generate_positions() muss typed_tree_positions befüllen")
	## Seed-Konsistenz: world_seed darf nicht von 42 abweichen
	assert_eq(_data.world_seed, 42,
		"world_seed darf durch _generate_positions() nicht überschrieben werden wenn bereits gesetzt")

func test_generate_positions_sets_seed_if_zero() -> void:
	_data.world_seed = 0
	var spawner := _make_spawner_no_worldgen()
	spawner._generate_positions()
	assert_ne(_data.world_seed, 0,
		"world_seed muss gesetzt werden wenn er 0 war")

# ─────────────────────────────────────────────
# Legacy-Pfad (P0 Abwärtskompatibilität)
# ─────────────────────────────────────────────

func test_legacy_path_uses_oak_tree_when_no_typed_data() -> void:
	## Wenn typed_tree_positions leer ist (alter Save), Fallback auf oak_tree.
	_data.tree_positions.append(Vector3(5, 0, 5))
	# typed_tree_positions bleibt leer

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var oak_spawns := _orchestrator.spawned.filter(func(e): return e["type_id"] == "oak_tree")
	assert_eq(oak_spawns.size(), 1,
		"Legacy-Save ohne typed_tree_positions muss als oak_tree gespawnt werden")

func test_legacy_path_uses_iron_ore_when_no_typed_data() -> void:
	_data.ore_positions.append(Vector3(-4, 0, 6))

	var spawner := _make_spawner()
	spawner.spawn_all(Node3D.new())

	var iron_spawns := _orchestrator.spawned.filter(func(e): return e["type_id"] == "iron_ore")
	assert_eq(iron_spawns.size(), 1,
		"Legacy-Save ohne typed_ore_positions muss als iron_ore gespawnt werden")

# ─────────────────────────────────────────────
# Hilfsfunktionen
# ─────────────────────────────────────────────

## WorldSpawner ohne WorldGenerationService (für Fallback-Tests).
func _make_spawner_no_worldgen() -> WorldSpawner:
	return WorldSpawner.new(_orchestrator as EntityOrchestrator, _terrain as TerrainGenerator, null, _data)

## WorldSpawner mit Stub-Terrain aber ohne WorldGenerationService.
func _make_spawner() -> WorldSpawner:
	return _make_spawner_no_worldgen()
