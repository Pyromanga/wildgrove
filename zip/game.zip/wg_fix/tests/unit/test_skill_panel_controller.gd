# res://tests/unit/test_skill_panel_controller.gd
extends GutTest

## Tests für SkillPanelController — I-02 (AUDIT-03).
##
## SkillPanelController nahm schon vor diesem Fix einen IUIContext entgegen (für
## get_skill_system()), verband aber XP-/Level-Up-Signale weiterhin direkt am
## EventBus-AutoLoad. Dieser Test deckt den "Quelle umgehängt"-Fall ab: ctx war
## bereits da, nur EventBus.player.* → _ctx.bus().player() musste noch passieren.

## Kleines, zustandsbehaftetes Test-Double, analog zum MockSkillSystem-Muster in
## test_entity_context.gd — der Level-Wert ist im Test veränderbar, damit sich ein
## erneutes Auslesen nach einem Signal von der Initial-Anzeige unterscheiden lässt.
class StubSkillSystem extends SkillSystem:
	var level: int = 3
	func get_skill_ids(_player_id: int = 1) -> Array[String]:
		var ids: Array[String] = ["mining"]
		return ids
	func get_level(_skill_name: String, _player_id: int = 1) -> int:
		return level
	func get_xp(_skill_name: String, _player_id: int = 1) -> int:
		return 42
	func get_xp_to_next_level(_skill_name: String, _player_id: int = 1) -> int:
		return 100

var _ctrl: SkillPanelController
var _ctx: UIContext
var _bus: MockEventBus
var _canvas: CanvasLayer
var _visuals: SkillPanelVisuals
var _skill_system: StubSkillSystem

func before_each() -> void:
	_canvas = autofree(CanvasLayer.new())
	_visuals = SkillPanelVisuals.new(_canvas)

	_bus = MockEventBus.new()
	_skill_system = StubSkillSystem.new()

	_ctx = UIContext.for_test()
	_ctx._bus = _bus
	_ctx._skill_system = _skill_system

	_ctrl = add_child_autofree(SkillPanelController.new())
	_ctrl.setup(_visuals, _ctx)  # setup() ruft bereits einmal _refresh_all() auf (Level 3)

func _label_text() -> String:
	return (_visuals._skill_labels["mining"]["label"] as Label).text

func test_setup_connects_to_injected_mock_bus() -> void:
	assert_true(
		_bus.player().xp_gained.is_connected(_ctrl._on_xp_gained),
		"setup() muss xp_gained auf dem injizierten Bus verbinden"
	)
	assert_true(
		_bus.player().level_up.is_connected(_ctrl._on_level_up),
		"setup() muss level_up auf dem injizierten Bus verbinden"
	)

func test_mock_bus_xp_gained_refreshes_visuals_with_new_value() -> void:
	assert_eq(_label_text(), "Mining  Lv.3", "Initialer Stand aus setup()'s _refresh_all()")

	_skill_system.level = 7
	_bus.player().emit_xp("mining", 5)

	assert_eq(
		_label_text(), "Mining  Lv.7",
		"_on_xp_gained() muss über den injizierten Mock-Bus erneut von get_skill_system() lesen"
	)

func test_real_autoload_event_bus_does_not_reach_controller() -> void:
	# Der entscheidende Beweis für I-02: der reale EventBus-AutoLoad darf den
	# Controller nicht mehr erreichen — nur der injizierte Mock.
	_skill_system.level = 99
	EventBus.player.emit_xp("mining", 5)

	assert_eq(
		_label_text(), "Mining  Lv.3",
		"Der echte AutoLoad-EventBus darf SkillPanelController nicht mehr erreichen"
	)
