# res://tests/unit/test_main_menu_controller.gd
extends GutTest

## Regression BUG-21: inject_save_system() existierte als DI-Punkt, hatte aber
## nie einen Aufrufer — _save_system blieb dauerhaft null, die Charakterliste
## im Hauptmenü war deshalb immer leer (_refresh_character_list() loggte
## "SaveSystem nicht injiziert." und brach ab).
##
## Testet die Controller-Seite der DI direkt (kein Disk-I/O — Double überschreibt
## list_local_saves() statt der echten Datei-Implementierung in SaveSystem).

class SaveSystemDouble extends SaveSystem:
	var _fake_saves: Array[String] = []
	func list_local_saves() -> Array[String]:
		return _fake_saves

var _menu: MainMenuController
var _save_double: SaveSystemDouble

func before_each() -> void:
	_menu = MainMenuController.new()

	var center := VBoxContainer.new()
	center.name = "CenterContainer"
	_menu.add_child(center)

	var char_list := VBoxContainer.new()
	char_list.name = "CharacterList"
	center.add_child(char_list)

	var new_btn := Button.new()
	new_btn.name = "NewGameButton"
	center.add_child(new_btn)

	_save_double = SaveSystemDouble.new()

	add_child_autofree(_menu)

func test_inject_save_system_sets_field_and_enables_character_list() -> void:
	_save_double._fake_saves = ["charakter_1", "charakter_2"]
	_menu.inject_save_system(_save_double)

	_menu.call("_refresh_character_list")

	var char_list := _menu.get_node("CenterContainer/CharacterList")
	assert_eq(char_list.get_child_count(), 2, "Beide gespeicherten Charaktere müssen als Buttons erscheinen")

func test_refresh_character_list_without_injection_logs_error_and_stays_empty() -> void:
	# Kein inject_save_system() Aufruf — reproduziert exakt den Log-Befund.
	_menu.call("_refresh_character_list")

	var char_list := _menu.get_node("CenterContainer/CharacterList")
	assert_eq(char_list.get_child_count(), 0, "Ohne SaveSystem darf keine Charakterliste aufgebaut werden")

func test_menu_scope_initializer_emits_parent_as_menu_root() -> void:
	var root := Control.new()
	add_child_autofree(root)
	var initializer := MenuScopeInitializer.new()

	var received: Array = []
	initializer.menu_ready.connect(func(r: Control) -> void: received.append(r))
	root.add_child(initializer)
	await get_tree().process_frame

	assert_eq(received.size(), 1, "menu_ready muss genau einmal feuern")
	assert_eq(received[0], root, "menu_ready muss den Parent (MainMenu-Root) übergeben")
