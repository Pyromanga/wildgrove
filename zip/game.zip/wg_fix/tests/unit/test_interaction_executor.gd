# res://tests/unit/test_interaction_executor.gd
extends GutTest

## Unit-Tests für InteractionExecutor.
##
## Vorher ungetestet (Coverage-Lücke aus Architect-Review). Mit der Runde-4
## EventBus-Migration (deps.require(EVENT_BUS) statt AutoLoad) jetzt vollständig
## über MockEventBus isolierbar.
##
## Abgedeckt:
##   - configure(): _bus und _player_states korrekt gesetzt
##   - on_ready(): Signal-Connects auf injizierten Bus, nicht AutoLoad
##   - execute_action(): startet nur wenn Spieler frei ist
##   - execute_action(): blockiert wenn bereits eine Aktion läuft
##   - execute_action(): emittiert interaction_started
##   - execute_action(): setzt PlayerState auf BUSY
##   - cancel_interaction(): emittiert interaction_cancelled, setzt FREE
##   - cancel_interaction(): no-op wenn keine aktive Aktion
##   - _on_tween_finished(): emittiert interaction_finished, loot, xp, reward_text
##   - is_busy(): korrekt für aktive/inaktive Aktion
##   - on_cleanup(): disconnected beide Signale

class MockPlayerStateService extends PlayerStateService:
	var _is_free: bool = true
	var last_state_set: int = -1
	func is_free(_pid: int = 1) -> bool: return _is_free
	func set_state(new_state: int, _pid: int = 1) -> void: last_state_set = new_state

var _executor: InteractionExecutor
var _bus:      MockEventBus
var _states:   MockPlayerStateService

func before_each() -> void:
	_executor = InteractionExecutor.new()
	_bus      = MockEventBus.new()
	_states   = MockPlayerStateService.new()
	_executor.configure(ServiceDeps.from_dict({
		ServiceKeys.PLAYER_STATES: _states,
		ServiceKeys.EVENT_BUS:     _bus,
	}))
	_executor.on_ready()

func _make_action(id: String = "chop", duration: float = 0.0) -> InteractableAction:
	var a := InteractableAction.new(id, "Test-Aktion")
	a.duration = duration
	return a

# ─────────────────────────────────────────────────────────────────────────────
# configure()
# ─────────────────────────────────────────────────────────────────────────────

func test_configure_sets_bus() -> void:
	assert_eq(_executor._bus, _bus, "_bus muss via deps.require(EVENT_BUS) gesetzt sein")

func test_configure_sets_player_states() -> void:
	assert_eq(_executor._player_states, _states, "_player_states muss gesetzt sein")

# ─────────────────────────────────────────────────────────────────────────────
# on_ready() — Signal-Connects auf injizierten Bus
# ─────────────────────────────────────────────────────────────────────────────

func test_on_ready_connects_movement_interrupted() -> void:
	assert_true(
		_bus.player().movement_interrupted.is_connected(_executor.cancel_interaction),
		"on_ready() muss movement_interrupted auf injiziertem Bus connecten"
	)

func test_on_ready_connects_interaction_execute_requested() -> void:
	assert_true(
		_bus.ui().interaction_execute_requested.is_connected(_executor.execute_action),
		"on_ready() muss interaction_execute_requested auf injiziertem Bus connecten"
	)

# ─────────────────────────────────────────────────────────────────────────────
# execute_action() — Guard-Verhalten
# ─────────────────────────────────────────────────────────────────────────────

func test_execute_action_starts_when_player_free() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action())
	assert_true(_executor.is_busy(), "execute_action() muss starten wenn Spieler frei ist")

func test_execute_action_blocked_when_player_busy() -> void:
	_states._is_free = false
	_executor.execute_action(_make_action())
	assert_false(_executor.is_busy(), "execute_action() darf nicht starten wenn Spieler beschäftigt ist")

func test_execute_action_blocked_when_already_active() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("first"))
	_executor.execute_action(_make_action("second"))
	# Zweite Aktion darf die erste nicht überschreiben
	assert_true(_executor.is_busy(), "Erste Aktion muss aktiv bleiben")

func test_execute_action_sets_player_state_busy() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action())
	assert_eq(_states.last_state_set, PlayerStateService.State.BUSY,
		"execute_action() muss PlayerState auf BUSY setzen")

func test_execute_action_emits_interaction_started() -> void:
	_states._is_free = true
	watch_signals(_bus.world())
	_executor.execute_action(_make_action("chop", 2.0))
	assert_signal_emitted(_bus.world(), "interaction_started",
		"execute_action() muss interaction_started über injizierten Bus emittieren")

func test_execute_action_emits_correct_action_id() -> void:
	_states._is_free = true
	watch_signals(_bus.world())
	_executor.execute_action(_make_action("mine", 1.5))
	assert_signal_emitted_with_parameters(
		_bus.world(), "interaction_started", ["mine", "Test-Aktion", 1.5]
	)

# ─────────────────────────────────────────────────────────────────────────────
# cancel_interaction()
# ─────────────────────────────────────────────────────────────────────────────

func test_cancel_interaction_noop_when_nothing_active() -> void:
	watch_signals(_bus.world())
	_executor.cancel_interaction()
	assert_signal_not_emitted(_bus.world(), "interaction_cancelled",
		"cancel_interaction() ohne aktive Aktion darf nichts emittieren")

func test_cancel_interaction_emits_interaction_cancelled() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("chop"))
	watch_signals(_bus.world())
	_executor.cancel_interaction()
	assert_signal_emitted(_bus.world(), "interaction_cancelled",
		"cancel_interaction() muss interaction_cancelled über injizierten Bus emittieren")

func test_cancel_interaction_sets_player_state_free() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("chop"))
	_executor.cancel_interaction()
	assert_eq(_states.last_state_set, PlayerStateService.State.FREE,
		"cancel_interaction() muss PlayerState zurück auf FREE setzen")

func test_cancel_interaction_clears_active_action() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("chop"))
	_executor.cancel_interaction()
	assert_false(_executor.is_busy(), "Nach cancel_interaction() darf is_busy() nicht mehr true sein")

# ─────────────────────────────────────────────────────────────────────────────
# is_busy()
# ─────────────────────────────────────────────────────────────────────────────

func test_is_busy_false_initially() -> void:
	assert_false(_executor.is_busy(), "is_busy() muss initial false sein")

func test_is_busy_true_after_execute() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action())
	assert_true(_executor.is_busy(), "is_busy() muss true sein während Aktion läuft")

# ─────────────────────────────────────────────────────────────────────────────
# _on_tween_finished() — Completion-Pfad
# ─────────────────────────────────────────────────────────────────────────────

func test_completion_emits_interaction_finished() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("chop", 0.0))
	watch_signals(_bus.world())
	_executor._on_tween_finished()
	assert_signal_emitted(_bus.world(), "interaction_finished",
		"_on_tween_finished() muss interaction_finished über injizierten Bus emittieren")

func test_completion_with_drops_emits_loot_collected() -> void:
	_states._is_free = true
	var action := _make_action("mine", 0.0)
	action.drops = {"iron_ore": 2}
	_executor.execute_action(action)
	watch_signals(_bus.world())
	_executor._on_tween_finished()
	assert_signal_emitted_with_parameters(_bus.world(), "loot_collected", ["iron_ore", 2])

func test_completion_with_xp_emits_xp_via_player_bus() -> void:
	_states._is_free = true
	var action := _make_action("chop", 0.0)
	action.xp_type   = "woodcutting"
	action.xp_amount = 5
	_executor.execute_action(action)
	watch_signals(_bus.player())
	_executor._on_tween_finished()
	assert_signal_emitted_with_parameters(_bus.player(), "xp_gained", ["woodcutting", 5])

func test_completion_without_xp_type_none_no_xp_emitted() -> void:
	_states._is_free = true
	var action := _make_action("inspect", 0.0)
	action.xp_type = "none"
	_executor.execute_action(action)
	watch_signals(_bus.player())
	_executor._on_tween_finished()
	assert_signal_not_emitted(_bus.player(), "xp_gained",
		"xp_type='none' darf kein xp_gained Signal emittieren")

func test_completion_with_inspect_text_emits_reward_text() -> void:
	_states._is_free = true
	var action := _make_action("inspect", 0.0)
	action.inspect_text = "Ein gewöhnlicher Stein."
	_executor.execute_action(action)
	watch_signals(_bus.world())
	_executor._on_tween_finished()
	assert_signal_emitted_with_parameters(
		_bus.world(), "interaction_reward_text", ["Ein gewöhnlicher Stein."]
	)

func test_completion_calls_on_complete_callback() -> void:
	_states._is_free = true
	var action  := _make_action("chop", 0.0)
	var called  := [false]
	action.on_complete = func(): called[0] = true
	_executor.execute_action(action)
	_executor._on_tween_finished()
	assert_true(called[0], "_on_tween_finished() muss on_complete-Callback aufrufen")

func test_completion_sets_player_state_free() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("chop", 0.0))
	_executor._on_tween_finished()
	assert_eq(_states.last_state_set, PlayerStateService.State.FREE,
		"_on_tween_finished() muss PlayerState zurück auf FREE setzen")

func test_completion_clears_active_action() -> void:
	_states._is_free = true
	_executor.execute_action(_make_action("chop", 0.0))
	_executor._on_tween_finished()
	assert_false(_executor.is_busy(), "Nach Completion darf is_busy() nicht mehr true sein")

func test_tween_finished_noop_when_nothing_active() -> void:
	watch_signals(_bus.world())
	_executor._on_tween_finished()
	assert_signal_not_emitted(_bus.world(), "interaction_finished",
		"_on_tween_finished() ohne aktive Aktion darf nichts emittieren")

# ─────────────────────────────────────────────────────────────────────────────
# on_cleanup()
# ─────────────────────────────────────────────────────────────────────────────

func test_on_cleanup_disconnects_movement_interrupted() -> void:
	_executor.on_cleanup()
	assert_false(
		_bus.player().movement_interrupted.is_connected(_executor.cancel_interaction),
		"on_cleanup() muss movement_interrupted disconnecten"
	)

func test_on_cleanup_disconnects_interaction_execute_requested() -> void:
	_executor.on_cleanup()
	assert_false(
		_bus.ui().interaction_execute_requested.is_connected(_executor.execute_action),
		"on_cleanup() muss interaction_execute_requested disconnecten"
	)

func test_on_cleanup_twice_no_crash() -> void:
	_executor.on_cleanup()
	_executor.on_cleanup()
	assert_true(true, "Zweites on_cleanup() darf nicht crashen (is_connected-Guard)")
