## tests/unit/test_equipment_service.gd
## Unit-Tests für EquipmentService.
##
## Abdeckung:
##   - equip() / unequip() / get_equipped() / is_equipped()
##   - StatModifier-Anbindung: damage_bonus via StatModifierService
##   - PARALLELE BUFFS: zwei Slots → zwei unabhängige Modifier
##   - Slot-Exklusivität: erneutes equip() auf denselben Slot ersetzt nur diesen Modifier
##   - unequip() entfernt Modifier + Visual symmetrisch
##   - on_cleanup() räumt alle "equipment_"-Modifier in einem Rutsch ab
##   - get_equipped_weapon() liefert null für Nicht-Waffen-Items
##   - Multi-Tenancy: player_id-Isolation, clear_player()
##   - ISaveProvider: get_save_key() / get_save_data() / load_data() + round-trip

extends GutTest

var _equipment: EquipmentService
var _stat_mods: StatModifierService
## Minimal SaveSystem stand-in: records registered providers and returns preset state.
class MockSaveSystem:
	var providers: Array = []
	var _preset_state: Dictionary = {}

	func register_save_provider(p: Object) -> void:
		providers.append(p)

	func get_state_for(key: String) -> Dictionary:
		return _preset_state.get(key, {})

	func set_preset(key: String, value: Dictionary) -> void:
		_preset_state[key] = value

var _save_sys: MockSaveSystem

func before_each() -> void:
	_stat_mods = StatModifierService.new()
	_save_sys = MockSaveSystem.new()
	_equipment = EquipmentService.new()
	_equipment.configure(ServiceDeps.from_dict({
		"stat_modifiers": _stat_mods,
		"savesystem": _save_sys,
	}))

func after_each() -> void:
	_equipment.on_cleanup()
	_stat_mods.on_cleanup()
	_equipment = null
	_stat_mods = null
	_save_sys = null

func _make_weapon(id: String, dmg_bonus: float) -> WeaponDefinition:
	var w := WeaponDefinition.new()
	w.id = id
	w.display_name = id
	w.damage_bonus = dmg_bonus
	return w

# ─────────────────────────────────────────────
# equip / unequip / Accessors
# ─────────────────────────────────────────────

func test_equip_stores_item_in_slot() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	assert_true(_equipment.equip("weapon", sword))
	assert_eq(_equipment.get_equipped("weapon"), sword)
	assert_true(_equipment.is_equipped("weapon"))

func test_equip_rejects_empty_slot() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	assert_false(_equipment.equip("", sword))

func test_equip_rejects_invalid_item() -> void:
	assert_false(_equipment.equip("weapon", null))

func test_unequip_clears_slot() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	assert_true(_equipment.unequip("weapon"))
	assert_false(_equipment.is_equipped("weapon"))
	assert_null(_equipment.get_equipped("weapon"))

func test_unequip_empty_slot_returns_false() -> void:
	assert_false(_equipment.unequip("weapon"))

func test_get_equipped_weapon_returns_null_for_non_weapon_item() -> void:
	var generic_item := ItemDefinition.new()
	generic_item.id = "raw_log"
	_equipment.equip("offhand", generic_item)
	assert_null(_equipment.get_equipped_weapon("offhand"))

# ─────────────────────────────────────────────
# StatModifier-Anbindung
# ─────────────────────────────────────────────

func test_equip_applies_damage_bonus_as_stat_modifier() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	assert_true(_stat_mods.has_modifier("equipment_weapon"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 15.0)

func test_unequip_removes_stat_modifier() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	_equipment.unequip("weapon")
	assert_false(_stat_mods.has_modifier("equipment_weapon"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 10.0)

func test_equip_zero_damage_bonus_adds_no_modifier() -> void:
	var dagger := _make_weapon("starter_dagger", 0.0)
	_equipment.equip("weapon", dagger)
	assert_false(_stat_mods.has_modifier("equipment_weapon"))

# ─────────────────────────────────────────────
# Parallele Buffs (Kernanforderung)
# ─────────────────────────────────────────────

func test_two_slots_apply_independent_parallel_modifiers() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	var ring  := _make_weapon("power_ring", 3.0)

	_equipment.equip("weapon", sword)
	_equipment.equip("offhand", ring)

	assert_true(_stat_mods.has_modifier("equipment_weapon"))
	assert_true(_stat_mods.has_modifier("equipment_offhand"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 18.0)

func test_unequipping_one_slot_leaves_other_slot_active() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	var ring  := _make_weapon("power_ring", 3.0)
	_equipment.equip("weapon", sword)
	_equipment.equip("offhand", ring)

	_equipment.unequip("weapon")

	assert_false(_stat_mods.has_modifier("equipment_weapon"))
	assert_true(_stat_mods.has_modifier("equipment_offhand"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 13.0)

func test_reequipping_same_slot_replaces_only_that_modifier() -> void:
	var sword        := _make_weapon("iron_sword", 5.0)
	var better_sword := _make_weapon("steel_sword", 8.0)
	var ring         := _make_weapon("power_ring", 3.0)

	_equipment.equip("weapon", sword)
	_equipment.equip("offhand", ring)
	_equipment.equip("weapon", better_sword)

	assert_eq(_equipment.get_equipped("weapon"), better_sword)
	assert_true(_stat_mods.has_modifier("equipment_offhand"), "offhand-Slot darf vom weapon-Re-Equip nicht betroffen sein.")
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 21.0)  # 10 + 8 + 3

# ─────────────────────────────────────────────
# Cleanup
# ─────────────────────────────────────────────

func test_on_cleanup_removes_all_equipment_modifiers() -> void:
	_equipment.equip("weapon", _make_weapon("iron_sword", 5.0))
	_equipment.equip("offhand", _make_weapon("power_ring", 3.0))

	_equipment.on_cleanup()

	assert_false(_stat_mods.has_modifier("equipment_weapon"))
	assert_false(_stat_mods.has_modifier("equipment_offhand"))
	assert_false(_equipment.is_equipped("weapon"))
	assert_false(_equipment.is_equipped("offhand"))

# ─────────────────────────────────────────────
# Signal
# ─────────────────────────────────────────────

func test_equip_emits_equipment_changed_signal() -> void:
	watch_signals(_equipment)
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	assert_signal_emitted_with_parameters(_equipment, "equipment_changed", ["weapon", sword])

func test_unequip_emits_equipment_changed_with_null() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	watch_signals(_equipment)
	_equipment.unequip("weapon")
	assert_signal_emitted_with_parameters(_equipment, "equipment_changed", ["weapon", null])

# ─────────────────────────────────────────────
# Multi-Tenancy (Prio 3)
# ─────────────────────────────────────────────

func test_different_player_ids_have_isolated_slots() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	var axe   := _make_weapon("iron_axe", 8.0)

	_equipment.equip("weapon", sword, null, 1)
	_equipment.equip("weapon", axe, null, 2)

	assert_eq(_equipment.get_equipped("weapon", 1), sword, "Player 1 muss sein eigenes Item haben.")
	assert_eq(_equipment.get_equipped("weapon", 2), axe, "Player 2 muss sein eigenes Item haben.")

func test_stat_modifiers_are_isolated_per_player() -> void:
	_equipment.equip("weapon", _make_weapon("sword_p1", 5.0), null, 1)
	_equipment.equip("weapon", _make_weapon("sword_p2", 20.0), null, 2)

	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0, 1), 15.0, "Player 1: 10 + 5")
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0, 2), 30.0, "Player 2: 10 + 20")

func test_unequip_only_affects_target_player() -> void:
	_equipment.equip("weapon", _make_weapon("sword", 5.0), null, 1)
	_equipment.equip("weapon", _make_weapon("sword", 5.0), null, 2)

	_equipment.unequip("weapon", 1)

	assert_false(_equipment.is_equipped("weapon", 1))
	assert_true(_equipment.is_equipped("weapon", 2), "Player 2 muss unberührt bleiben.")

func test_clear_player_removes_all_slots_and_modifiers() -> void:
	_equipment.equip("weapon", _make_weapon("sword", 5.0), null, 10)
	_equipment.equip("offhand", _make_weapon("ring", 2.0), null, 10)
	_equipment.equip("weapon", _make_weapon("sword", 5.0), null, 11)

	_equipment.clear_player(10)

	assert_false(_equipment.is_equipped("weapon", 10))
	assert_false(_equipment.is_equipped("offhand", 10))
	assert_false(_stat_mods.has_modifier("equipment_weapon", 10))
	assert_true(_equipment.is_equipped("weapon", 11), "Player 11 muss unberührt bleiben.")

func test_default_player_id_is_one() -> void:
	_equipment.equip("weapon", _make_weapon("sword", 3.0))
	assert_true(_equipment.is_equipped("weapon", 1))
	assert_false(_equipment.is_equipped("weapon", 2), "Player 2 darf nichts sehen.")

# ─────────────────────────────────────────────
# ISaveProvider (Prio 3)
# ─────────────────────────────────────────────

func test_save_data_includes_equipped_item_id() -> void:
	_equipment.equip("weapon", _make_weapon("iron_sword", 5.0), null, 1)

	var data := _equipment.get_save_data()

	assert_true(data.has("1"), "Player 1 muss im Save-Blob sein.")
	assert_eq(data["1"]["weapon"], "iron_sword")

func test_save_data_is_empty_when_nothing_equipped() -> void:
	var data := _equipment.get_save_data()
	assert_eq(data, {})

func test_save_key_returns_equipment() -> void:
	assert_eq(_equipment.get_save_key(), "equipment")

func test_save_data_null_slot_when_unequipped_after_equip() -> void:
	## Unequip löscht den Slot aus dem Dict — kein null-Eintrag im Save.
	_equipment.equip("weapon", _make_weapon("iron_sword", 5.0))
	_equipment.unequip("weapon")
	var data := _equipment.get_save_data()
	# Player 1 wird angelegt aber hat leeren Slot-Dict → "1" hat kein "weapon"
	if data.has("1"):
		assert_false(data["1"].has("weapon"), "Entfernte Slots dürfen nicht im Save sein.")

# ─────────────────────────────────────────────
# Save/Load Round-Trip (Prio 3 — war fehlend)
# ─────────────────────────────────────────────

func test_register_save_provider_called_on_configure() -> void:
	assert_eq(_save_sys.providers.size(), 1, "EquipmentService muss sich beim SaveSystem registrieren.")
	assert_eq(_save_sys.providers[0], _equipment)

func test_get_save_key_matches_load_key() -> void:
	## SaveSystem nutzt get_save_key() als Lookup-Key für get_state_for() — beide müssen übereinstimmen.
	assert_eq(_equipment.get_save_key(), "equipment")

func test_round_trip_equip_save_reload_restores_item() -> void:
	## Equip → serialize → new service with preset state → verify loaded.
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword, null, 1)

	var saved := _equipment.get_save_data()

	# Simulate a new session: new service, SaveSystem returns saved state.
	var save_sys2 := MockSaveSystem.new()
	save_sys2.set_preset("equipment", saved)
	var stat_mods2 := StatModifierService.new()
	var equipment2 := EquipmentService.new()
	equipment2.configure(ServiceDeps.from_dict({
		"stat_modifiers": stat_mods2,
		"savesystem": save_sys2,
	}))

	assert_true(equipment2.is_equipped("weapon", 1), "Nach Reload muss Slot 'weapon' belegt sein.")
	var loaded_item := equipment2.get_equipped("weapon", 1)
	assert_not_null(loaded_item, "Geladenes Item darf nicht null sein.")
	assert_eq(loaded_item.id, "iron_sword", "Item-ID muss nach Reload übereinstimmen.")

	equipment2.on_cleanup()
	stat_mods2.on_cleanup()

func test_round_trip_empty_save_produces_empty_equipment() -> void:
	## A fresh save (no equipment key) must load as empty, not error.
	var save_sys2 := MockSaveSystem.new()
	var stat_mods2 := StatModifierService.new()
	var equipment2 := EquipmentService.new()
	equipment2.configure(ServiceDeps.from_dict({
		"stat_modifiers": stat_mods2,
		"savesystem": save_sys2,
	}))

	assert_false(equipment2.is_equipped("weapon", 1), "Leerer Save → kein Equipment.")
	equipment2.on_cleanup()
	stat_mods2.on_cleanup()
