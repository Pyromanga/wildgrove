# res://tests/unit/test_quest_service.gd
extends GutTest

## Unit-Tests für QuestService (E-02).
##
## Strategie: QuestService ohne SceneTree instanziieren.
## configure() erhält minimale Mock-Services.
## on_ready() wird NICHT aufgerufen (EventBus-Connects überspringen).
## Direkter Aufruf von request_start_quest / request_complete_quest /
## update_objective für Tier-1-Pfade.
##
## Abgedeckt:
##   - request_start_quest(): start, already_active, already_completed, prereq_missing
##   - request_complete_quest(): normal, not_active
##   - fail_quest(): normal, not_active
##   - unlock_quest(): unlock, duplicate-ignore, already-active-ignore
##   - update_objective(): progress, auto-complete bei Ziel erfüllt
##   - is_quest_active() / is_quest_completed()
##   - Multi-Tenanz: zwei player_ids unabhängig
##   - get_save_key() / get_save_data()
##   - Save-Round-Trip

# ─────────────────────────────────────────────────────────────────────────────
# Minimal-Mocks
# ─────────────────────────────────────────────────────────────────────────────

class MockObjectiveDef:
	var id:       String
	var required: int
	var type:     String
	func _init(p_id: String, p_req: int = 1, p_type: String = "COLLECT") -> void:
		id       = p_id
		required = p_req
		type     = p_type

class MockQuestDef:
	var quest_id:      String
	var objectives:    Array = []
	var prerequisites: Array = []
	var auto_start:    bool  = false
	var reward              = null  # null → kein Reward

	func _init(p_id: String) -> void:
		quest_id = p_id

class MockDataService:
	var _quests: Dictionary = {}
	func get_all_quests() -> Dictionary:  return _quests
	func get_auto_start_quests() -> Array: return []
	func has_method(m: String) -> bool:    return true

# ─────────────────────────────────────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────────────────────────────────────

var _svc: QuestService
var _ds:  MockDataService
var _bus: MockEventBus

const Q_SIMPLE  := "quest_simple"
const Q_PREREQ  := "quest_prereq"
const Q_OBJ     := "quest_objective"

func before_each() -> void:
	_ds  = MockDataService.new()
	_bus = MockEventBus.new()

	# Einfache Quest ohne Voraussetzungen
	var q_simple := MockQuestDef.new(Q_SIMPLE)
	_ds._quests[Q_SIMPLE] = q_simple

	# Quest mit Voraussetzung
	var q_prereq := MockQuestDef.new(Q_PREREQ)
	q_prereq.prerequisites = [Q_SIMPLE]
	_ds._quests[Q_PREREQ] = q_prereq

	# Quest mit einem Objective (COLLECT 5x)
	var q_obj := MockQuestDef.new(Q_OBJ)
	q_obj.objectives = [MockObjectiveDef.new("obj_collect", 5, "COLLECT")]
	_ds._quests[Q_OBJ] = q_obj

	_svc = QuestService.new()
	_svc.configure(ServiceDeps.from_dict({
		ServiceKeys.DATA:       _ds,
		ServiceKeys.SAVE_SYSTEM: MockSaveSystemNoop.new(),
		ServiceKeys.EVENT_BUS:  _bus,
	}))
	# on_ready() bewusst NICHT aufrufen — kein SceneTree-Signal-Connect nötig

class MockSaveSystemNoop extends SaveSystem:
	func register_save_provider(_p) -> void: pass
	func get_state_for(_key: String) -> Dictionary: return {}

func after_each() -> void:
	_svc.on_cleanup()
	_svc = null

# ─────────────────────────────────────────────────────────────────────────────
# request_start_quest
# ─────────────────────────────────────────────────────────────────────────────

func test_start_quest_sets_active() -> void:
	var ok := _svc.request_start_quest(Q_SIMPLE)
	assert_true(ok, "request_start_quest() muss true zurückgeben")
	assert_true(_svc.is_quest_active(Q_SIMPLE), "Quest muss aktiv sein nach Start")

func test_start_empty_id_returns_false() -> void:
	var ok := _svc.request_start_quest("")
	assert_false(ok, "Leere ID → false")

func test_start_already_active_returns_false() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	var ok := _svc.request_start_quest(Q_SIMPLE)
	assert_false(ok, "Bereits aktive Quest → false")

func test_start_already_completed_returns_false() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.request_complete_quest(Q_SIMPLE)
	var ok := _svc.request_start_quest(Q_SIMPLE)
	assert_false(ok, "Abgeschlossene Quest → false")

func test_start_with_unmet_prereq_returns_false() -> void:
	var ok := _svc.request_start_quest(Q_PREREQ)
	assert_false(ok, "Fehlende Voraussetzung → false")
	assert_false(_svc.is_quest_active(Q_PREREQ), "Quest darf nicht aktiv sein")

func test_start_with_met_prereq_succeeds() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.request_complete_quest(Q_SIMPLE)
	var ok := _svc.request_start_quest(Q_PREREQ)
	assert_true(ok, "Erfüllte Voraussetzung → Quest kann starten")

# ─────────────────────────────────────────────────────────────────────────────
# request_complete_quest
# ─────────────────────────────────────────────────────────────────────────────

func test_complete_quest_moves_to_completed() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.request_complete_quest(Q_SIMPLE)
	assert_false(_svc.is_quest_active(Q_SIMPLE),    "Nicht mehr aktiv nach Abschluss")
	assert_true( _svc.is_quest_completed(Q_SIMPLE), "Muss als abgeschlossen markiert sein")

func test_complete_inactive_quest_is_noop() -> void:
	_svc.request_complete_quest(Q_SIMPLE)  # nie gestartet
	assert_false(_svc.is_quest_completed(Q_SIMPLE), "Nie gestartete Quest kann nicht abgeschlossen werden")

# ─────────────────────────────────────────────────────────────────────────────
# fail_quest
# ─────────────────────────────────────────────────────────────────────────────

func test_fail_quest_removes_from_active() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.fail_quest(Q_SIMPLE)
	assert_false(_svc.is_quest_active(Q_SIMPLE), "Fehlgeschlagene Quest darf nicht aktiv sein")

func test_fail_inactive_quest_is_noop() -> void:
	_svc.fail_quest(Q_SIMPLE)  # kein Crash erwartet
	assert_false(_svc.is_quest_active(Q_SIMPLE), "Nicht-aktive Quest bleibt inaktiv")

# ─────────────────────────────────────────────────────────────────────────────
# unlock_quest
# ─────────────────────────────────────────────────────────────────────────────

func test_unlock_adds_to_available() -> void:
	_svc.unlock_quest(Q_PREREQ)
	assert_true(_svc.available_quests.has(Q_PREREQ), "Quest muss in available_quests erscheinen")

func test_unlock_duplicate_is_ignored() -> void:
	_svc.unlock_quest(Q_PREREQ)
	_svc.unlock_quest(Q_PREREQ)
	var count := _svc.available_quests.count(Q_PREREQ)
	assert_eq(count, 1, "Doppeltes Unlock darf keinen Duplicate-Eintrag erzeugen")

func test_unlock_already_active_is_ignored() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.unlock_quest(Q_SIMPLE)
	assert_false(_svc.available_quests.has(Q_SIMPLE), "Aktive Quest darf nicht in available erscheinen")

func test_unlock_already_completed_is_ignored() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.request_complete_quest(Q_SIMPLE)
	_svc.unlock_quest(Q_SIMPLE)
	assert_false(_svc.available_quests.has(Q_SIMPLE), "Abgeschlossene Quest darf nicht in available erscheinen")

# ─────────────────────────────────────────────────────────────────────────────
# update_objective / Auto-Complete
# ─────────────────────────────────────────────────────────────────────────────

func test_update_objective_tracks_progress() -> void:
	_svc.request_start_quest(Q_OBJ)
	_svc.update_objective(Q_OBJ, "obj_collect", 3)
	var progress := _svc.get_objective_progress(Q_OBJ, "obj_collect")
	assert_eq(progress, 3, "Fortschritt muss 3 sein nach +3")

func test_update_objective_accumulates() -> void:
	_svc.request_start_quest(Q_OBJ)
	_svc.update_objective(Q_OBJ, "obj_collect", 2)
	_svc.update_objective(Q_OBJ, "obj_collect", 2)
	var progress := _svc.get_objective_progress(Q_OBJ, "obj_collect")
	assert_eq(progress, 4, "Fortschritt muss 4 sein nach 2×2")

func test_objective_auto_completes_quest() -> void:
	_svc.request_start_quest(Q_OBJ)
	_svc.update_objective(Q_OBJ, "obj_collect", 5)  # required = 5 → Auto-Complete
	assert_false(_svc.is_quest_active(Q_OBJ),    "Quest darf nach Auto-Complete nicht aktiv sein")
	assert_true( _svc.is_quest_completed(Q_OBJ), "Quest muss nach Auto-Complete abgeschlossen sein")

func test_update_objective_inactive_quest_is_noop() -> void:
	_svc.update_objective(Q_OBJ, "obj_collect", 5)  # Q_OBJ nie gestartet
	assert_false(_svc.is_quest_active(Q_OBJ),    "Nicht-gestartete Quest bleibt inaktiv")
	assert_false(_svc.is_quest_completed(Q_OBJ), "Nicht-gestartete Quest nicht abgeschlossen")

# ─────────────────────────────────────────────────────────────────────────────
# Multi-Tenanz
# ─────────────────────────────────────────────────────────────────────────────

func test_two_players_independent_quest_state() -> void:
	_svc.request_start_quest(Q_SIMPLE, 1)
	assert_true( _svc.is_quest_active(Q_SIMPLE, 1), "Spieler 1: Quest aktiv")
	assert_false(_svc.is_quest_active(Q_SIMPLE, 2), "Spieler 2: Quest nicht aktiv")

func test_complete_for_player1_does_not_affect_player2() -> void:
	_svc.request_start_quest(Q_SIMPLE, 1)
	_svc.request_start_quest(Q_SIMPLE, 2)
	_svc.request_complete_quest(Q_SIMPLE, 1)
	assert_true( _svc.is_quest_completed(Q_SIMPLE, 1), "Spieler 1: abgeschlossen")
	assert_false(_svc.is_quest_completed(Q_SIMPLE, 2), "Spieler 2: noch aktiv")

# ─────────────────────────────────────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────────────────────────────────────

func test_save_key_is_quest_progress() -> void:
	assert_eq(_svc.get_save_key(), "quest_progress", "SAVE_KEY muss 'quest_progress' sein")

func test_save_data_contains_player_bucket() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	var sd := _svc.get_save_data()
	assert_true(sd.has("1"), "Save-Daten müssen Player-1-Bucket enthalten")

func test_save_data_reflects_completed() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.request_complete_quest(Q_SIMPLE)
	var sd := _svc.get_save_data()
	var bucket := sd["1"] as Dictionary
	var completed := bucket["completed"] as Array
	assert_true(completed.has(Q_SIMPLE), "Abgeschlossene Quest muss im Snapshot sein")

# ─────────────────────────────────────────────────────────────────────────────
# Save-Round-Trip (A-04)
# ─────────────────────────────────────────────────────────────────────────────

func test_round_trip_restores_active_quest() -> void:
	_svc.request_start_quest(Q_OBJ)
	_svc.update_objective(Q_OBJ, "obj_collect", 3)
	var snapshot := _svc.get_save_data()

	var svc2 := QuestService.new()
	svc2.configure(ServiceDeps.from_dict({
		ServiceKeys.DATA: _ds,
		ServiceKeys.SAVE_SYSTEM: MockSaveSystemNoop.new(),
		ServiceKeys.EVENT_BUS: MockEventBus.new(),
	}))
	svc2._restore_from_save(snapshot)

	assert_true(svc2.is_quest_active(Q_OBJ), "Round-Trip: Quest muss aktiv sein")
	assert_eq(svc2.get_objective_progress(Q_OBJ, "obj_collect"), 3,
		"Round-Trip: Fortschritt muss 3 sein")
	svc2.on_cleanup()

func test_round_trip_restores_completed_quest() -> void:
	_svc.request_start_quest(Q_SIMPLE)
	_svc.request_complete_quest(Q_SIMPLE)
	var snapshot := _svc.get_save_data()

	var svc2 := QuestService.new()
	svc2.configure(ServiceDeps.from_dict({
		ServiceKeys.DATA: _ds,
		ServiceKeys.SAVE_SYSTEM: MockSaveSystemNoop.new(),
		ServiceKeys.EVENT_BUS: MockEventBus.new(),
	}))
	svc2._restore_from_save(snapshot)

	assert_true(svc2.is_quest_completed(Q_SIMPLE), "Round-Trip: Quest muss abgeschlossen sein")
	svc2.on_cleanup()

func test_round_trip_empty_save_produces_empty_state() -> void:
	var svc2 := QuestService.new()
	svc2.configure(ServiceDeps.from_dict({
		ServiceKeys.DATA: _ds,
		ServiceKeys.SAVE_SYSTEM: MockSaveSystemNoop.new(),
		ServiceKeys.EVENT_BUS: MockEventBus.new(),
	}))
	svc2._restore_from_save({})

	assert_false(svc2.is_quest_active(Q_SIMPLE),    "Kein aktiver Quest nach leerem Restore")
	assert_false(svc2.is_quest_completed(Q_SIMPLE), "Kein abgeschlossener Quest nach leerem Restore")
	svc2.on_cleanup()

# ─────────────────────────────────────────────────────────────────────────────
# TALK / CUSTOM Objectives (Runde 6 — vorher Enum-Einträge ohne Handler)
# ─────────────────────────────────────────────────────────────────────────────

func test_on_npc_talked_to_updates_talk_objective() -> void:
	var q := MockQuestDef.new("quest_talk")
	q.objectives = [MockObjectiveDef.new("obj_talk", 1, "TALK")]
	_ds._quests["quest_talk"] = q
	_svc._definitions = _ds._quests
	_svc.request_start_quest("quest_talk")

	# _on_npc_talked_to() prüft via QuestObjectiveHandler.resolve_talk() gegen
	# obj.target_id — MockObjectiveDef hat aber kein target_id-Feld, daher
	# rufen wir update_objective() direkt analog zum bestehenden Testmuster.
	_svc.update_objective("quest_talk", "obj_talk", 1)
	assert_eq(_svc.get_objective_progress("quest_talk", "obj_talk"), 1,
		"TALK-Objective muss via update_objective() Fortschritt verzeichnen")

func test_on_custom_objective_triggered_updates_custom_objective() -> void:
	var q := MockQuestDef.new("quest_custom")
	q.objectives = [MockObjectiveDef.new("obj_custom", 1, "CUSTOM")]
	_ds._quests["quest_custom"] = q
	_svc._definitions = _ds._quests
	_svc.request_start_quest("quest_custom")

	_svc.update_objective("quest_custom", "obj_custom", 1)
	assert_eq(_svc.get_objective_progress("quest_custom", "obj_custom"), 1,
		"CUSTOM-Objective muss via update_objective() Fortschritt verzeichnen")

func test_npc_talked_to_signal_triggers_handler_when_connected() -> void:
	## Voller on_ready()-Pfad: npc_talked_to Signal muss _on_npc_talked_to()
	## auslösen, das wiederum QuestObjectiveHandler.resolve_talk() aufruft.
	var def := QuestDefinition.new()
	def.id = "quest_real_talk"
	var obj := QuestObjective.new()
	obj.id        = "obj_talk_erik"
	obj.type      = QuestObjective.Type.TALK
	obj.target_id = "erik_woodcutter"
	obj.required  = 1
	def.objectives = [obj]
	_ds._quests["quest_real_talk"] = def
	_svc._definitions = _ds._quests
	_svc.on_ready()
	_svc.request_start_quest("quest_real_talk")

	_bus.quest().emit_npc_talked_to("erik_woodcutter")

	assert_eq(_svc.get_objective_progress("quest_real_talk", "obj_talk_erik"), 1,
		"npc_talked_to Signal muss TALK-Objective über vollen Signal-Pfad aktualisieren")

func test_npc_talked_to_wrong_npc_id_does_not_update() -> void:
	var def := QuestDefinition.new()
	def.id = "quest_real_talk2"
	var obj := QuestObjective.new()
	obj.id        = "obj_talk_erik"
	obj.type      = QuestObjective.Type.TALK
	obj.target_id = "erik_woodcutter"
	obj.required  = 1
	def.objectives = [obj]
	_ds._quests["quest_real_talk2"] = def
	_svc._definitions = _ds._quests
	_svc.on_ready()
	_svc.request_start_quest("quest_real_talk2")

	_bus.quest().emit_npc_talked_to("some_other_npc")

	assert_eq(_svc.get_objective_progress("quest_real_talk2", "obj_talk_erik"), 0,
		"npc_talked_to mit falscher npc_id darf Objective nicht aktualisieren")

func test_custom_objective_triggered_signal_triggers_handler_when_connected() -> void:
	var def := QuestDefinition.new()
	def.id = "quest_real_custom"
	var obj := QuestObjective.new()
	obj.id        = "obj_explore"
	obj.type      = QuestObjective.Type.CUSTOM
	obj.target_id = "erik_camp_explored"
	obj.required  = 1
	def.objectives = [obj]
	_ds._quests["quest_real_custom"] = def
	_svc._definitions = _ds._quests
	_svc.on_ready()
	_svc.request_start_quest("quest_real_custom")

	_bus.quest().emit_custom_objective_triggered("erik_camp_explored")

	assert_eq(_svc.get_objective_progress("quest_real_custom", "obj_explore"), 1,
		"custom_objective_triggered Signal muss CUSTOM-Objective über vollen Signal-Pfad aktualisieren")

func test_custom_objective_triggered_wrong_key_does_not_update() -> void:
	var def := QuestDefinition.new()
	def.id = "quest_real_custom2"
	var obj := QuestObjective.new()
	obj.id        = "obj_explore"
	obj.type      = QuestObjective.Type.CUSTOM
	obj.target_id = "erik_camp_explored"
	obj.required  = 1
	def.objectives = [obj]
	_ds._quests["quest_real_custom2"] = def
	_svc._definitions = _ds._quests
	_svc.on_ready()
	_svc.request_start_quest("quest_real_custom2")

	_bus.quest().emit_custom_objective_triggered("wrong_key")

	assert_eq(_svc.get_objective_progress("quest_real_custom2", "obj_explore"), 0,
		"custom_objective_triggered mit falschem Key darf Objective nicht aktualisieren")

func test_on_cleanup_disconnects_npc_talked_to() -> void:
	_svc.on_ready()
	_svc.on_cleanup()
	assert_false(
		_bus.quest().npc_talked_to.is_connected(_svc._on_npc_talked_to),
		"on_cleanup() muss npc_talked_to disconnecten"
	)

func test_on_cleanup_disconnects_custom_objective_triggered() -> void:
	_svc.on_ready()
	_svc.on_cleanup()
	assert_false(
		_bus.quest().custom_objective_triggered.is_connected(_svc._on_custom_objective_triggered),
		"on_cleanup() muss custom_objective_triggered disconnecten"
	)
