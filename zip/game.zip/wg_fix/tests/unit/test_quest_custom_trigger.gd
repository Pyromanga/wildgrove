# res://tests/unit/test_quest_custom_trigger.gd
extends GutTest

## Unit-Tests für QuestCustomTrigger.
##
## Abgedeckt:
##   - inject_bus(): setzt _bus
##   - _on_body_entered(): emittiert custom_objective_triggered für Spieler
##   - _on_body_entered(): ignoriert Nicht-Spieler-Bodies
##   - _on_body_entered(): ohne Bus kein Crash
##   - trigger_once: feuert nur einmal, monitoring wird deaktiviert
##   - trigger_once=false: feuert mehrfach
##   - leerer signal_key: kein Emit, Warnung

var _bus: MockEventBus

func before_each() -> void:
	_bus = MockEventBus.new()

func _make_trigger(key: String = "test_key", once: bool = true) -> QuestCustomTrigger:
	var t := QuestCustomTrigger.new()
	t.signal_key    = key
	t.trigger_once  = once
	add_child_autofree(t)
	return t

func _make_player_body() -> Node3D:
	var p := Node3D.new()
	p.add_to_group("player")
	add_child_autofree(p)
	return p

func _make_non_player_body() -> Node3D:
	var p := Node3D.new()
	add_child_autofree(p)
	return p

# ─────────────────────────────────────────────────────────────────────────────
# inject_bus()
# ─────────────────────────────────────────────────────────────────────────────

func test_inject_bus_sets_field() -> void:
	var t := _make_trigger()
	t.inject_bus(_bus)
	assert_eq(t._bus, _bus, "inject_bus() muss _bus setzen")

# ─────────────────────────────────────────────────────────────────────────────
# _on_body_entered() — Kern-Funktionalität
# ─────────────────────────────────────────────────────────────────────────────

func test_player_entering_emits_custom_objective_triggered() -> void:
	var t := _make_trigger("erik_camp_explored")
	t.inject_bus(_bus)
	watch_signals(_bus.quest())
	t._on_body_entered(_make_player_body())
	assert_signal_emitted_with_parameters(
		_bus.quest(), "custom_objective_triggered", ["erik_camp_explored"]
	)

func test_non_player_entering_does_not_emit() -> void:
	var t := _make_trigger("erik_camp_explored")
	t.inject_bus(_bus)
	watch_signals(_bus.quest())
	t._on_body_entered(_make_non_player_body())
	assert_signal_not_emitted(_bus.quest(), "custom_objective_triggered",
		"Nicht-Spieler-Body darf kein CUSTOM-Objective triggern")

func test_entering_without_bus_no_crash() -> void:
	var t := _make_trigger("erik_camp_explored")
	# kein inject_bus() aufgerufen
	t._on_body_entered(_make_player_body())
	assert_true(true, "_on_body_entered() ohne injizierten Bus darf nicht crashen")

func test_entering_with_empty_signal_key_does_not_emit() -> void:
	var t := _make_trigger("")
	t.inject_bus(_bus)
	watch_signals(_bus.quest())
	t._on_body_entered(_make_player_body())
	assert_signal_not_emitted(_bus.quest(), "custom_objective_triggered",
		"Leerer signal_key darf kein Signal emittieren")

# ─────────────────────────────────────────────────────────────────────────────
# trigger_once
# ─────────────────────────────────────────────────────────────────────────────

func test_trigger_once_fires_only_once() -> void:
	var t := _make_trigger("key", true)
	t.inject_bus(_bus)
	var emit_count := 0
	_bus.quest().custom_objective_triggered.connect(func(_k): emit_count += 1)
	var player := _make_player_body()
	t._on_body_entered(player)
	t._on_body_entered(player)  # zweiter Eintritt
	assert_eq(emit_count, 1, "trigger_once=true darf nur einmal emittieren")

func test_trigger_once_disables_monitoring_after_fire() -> void:
	var t := _make_trigger("key", true)
	t.inject_bus(_bus)
	t._on_body_entered(_make_player_body())
	assert_false(t.monitoring, "Nach Trigger muss monitoring deaktiviert werden (trigger_once)")

func test_trigger_repeatable_fires_multiple_times() -> void:
	var t := _make_trigger("key", false)
	t.inject_bus(_bus)
	var emit_count := 0
	_bus.quest().custom_objective_triggered.connect(func(_k): emit_count += 1)
	var player := _make_player_body()
	t._on_body_entered(player)
	t._on_body_entered(player)
	assert_eq(emit_count, 2, "trigger_once=false muss bei jedem Eintritt emittieren")

func test_trigger_repeatable_keeps_monitoring_enabled() -> void:
	var t := _make_trigger("key", false)
	t.inject_bus(_bus)
	t._on_body_entered(_make_player_body())
	assert_true(t.monitoring, "Bei trigger_once=false darf monitoring nicht deaktiviert werden")

# ─────────────────────────────────────────────────────────────────────────────
# Integration mit QuestService (End-to-End über echten Bus)
# ─────────────────────────────────────────────────────────────────────────────

func test_trigger_feeds_into_quest_service_via_real_bus() -> void:
	## Voller Pfad: QuestCustomTrigger → IEventBus → QuestService.
	var obj := QuestObjective.new()
	obj.id        = "obj_explore"
	obj.type      = QuestObjective.Type.CUSTOM
	obj.target_id = "erik_camp_explored"
	obj.required  = 1
	var def := QuestDefinition.new()
	def.id = "quest_x"
	def.objectives = [obj]

	var ds := QuestServiceTestHelper.new()
	ds._quests["quest_x"] = def

	var svc := QuestService.new()
	svc.configure(ServiceDeps.from_dict({
		ServiceKeys.DATA:        ds,
		ServiceKeys.SAVE_SYSTEM: QuestServiceTestHelper.NoopSaveSystem.new(),
		ServiceKeys.EVENT_BUS:   _bus,
	}))
	svc.on_ready()
	svc.request_start_quest("quest_x")

	var trigger := _make_trigger("erik_camp_explored")
	trigger.inject_bus(_bus)
	trigger._on_body_entered(_make_player_body())

	assert_eq(svc.get_objective_progress("quest_x", "obj_explore"), 1,
		"QuestCustomTrigger muss End-to-End über den realen Bus QuestService erreichen")
	svc.on_cleanup()

class QuestServiceTestHelper extends RefCounted:
	var _quests: Dictionary = {}
	func get_all_quests() -> Dictionary:  return _quests
	func get_auto_start_quests() -> Array: return []

	class NoopSaveSystem extends SaveSystem:
		func register_save_provider(_p) -> void: pass
		func get_state_for(_key: String) -> Dictionary: return {}
