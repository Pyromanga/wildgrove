extends GutTest

var _validator: ServiceValidator
var _resolver: ServiceDependencyResolver

func before_each() -> void:
	_validator = ServiceValidator.new()
	_resolver = ServiceDependencyResolver.new()

func test_app_services_resolve_without_missing_dependency() -> void:
	var defs := _validator.validate()
	assert_gt(defs.size(), 0, "global_services muss ladbar sein")

	var cfg := _validator.get_loaded_config()
	var resource_names: Array[String] = []
	for r in cfg.global_resources:
		resource_names.append(r.registry_key.to_lower())

	var external_names := resource_names.duplicate()
	external_names.append(ServiceKeys.EVENT_BUS)
	var ordered := _resolver.resolve(defs, external_names)

	assert_eq(ordered.size(), defs.size(), "alle App-Services müssen auflösbar sein")

func test_app_resolution_fails_loudly_if_event_bus_dep_not_declared_external() -> void:
	var defs := _validator.validate()
	var cfg := _validator.get_loaded_config()
	var resource_names: Array[String] = []
	for r in cfg.global_resources:
		resource_names.append(r.registry_key.to_lower())

	var has_event_bus_dep := false
	for d in defs:
		if ServiceKeys.EVENT_BUS in d.deps:
			has_event_bus_dep = true
			break
	assert_true(has_event_bus_dep, "mindestens ein Service muss event_bus als Dep deklarieren")

	var ordered := _resolver.resolve(defs, resource_names)
	assert_eq(ordered.size(), 0, "ohne event_bus in external_names muss die Auflösung scheitern")

func test_session_services_resolve_without_missing_dependency() -> void:
	var app_defs := _validator.validate()
	var app_names: Array[String] = []
	for d in app_defs:
		app_names.append(d.service_name.to_lower())

	var session_defs := _validator.validate_session(app_names)
	assert_gt(session_defs.size(), 0, "session_services muss ladbar sein")

	var external_names := app_names.duplicate()
	external_names.append(ServiceKeys.EVENT_BUS)
	var ordered := _resolver.resolve(session_defs, external_names)

	assert_eq(ordered.size(), session_defs.size(), "alle Session-Services müssen auflösbar sein")

func test_full_dependency_graph_has_no_unresolvable_service() -> void:
	var app_defs := _validator.validate()
	var cfg := _validator.get_loaded_config()
	var resource_names: Array[String] = []
	for r in cfg.global_resources:
		resource_names.append(r.registry_key.to_lower())

	var app_external := resource_names.duplicate()
	app_external.append(ServiceKeys.EVENT_BUS)
	var app_ordered := _resolver.resolve(app_defs, app_external)
	assert_eq(app_ordered.size(), app_defs.size(), "App-Graph muss vollständig auflösbar sein")

	var app_names: Array[String] = []
	for d in app_defs:
		app_names.append(d.service_name.to_lower())

	var session_defs := _validator.validate_session(app_names)
	var session_external := app_names.duplicate()
	session_external.append(ServiceKeys.EVENT_BUS)
	var session_ordered := _resolver.resolve(session_defs, session_external)

	assert_eq(session_ordered.size(), session_defs.size(), "Session-Graph muss vollständig auflösbar sein")
