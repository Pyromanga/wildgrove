# res://tests/unit/test_bootstrap_config_integration.gd
extends GutTest

## Integrationstest: reale BootstrapConfig.tres + realer ServiceDependencyResolver.
##
## HINTERGRUND (Bug, Session vom 2026-07-01):
## test_boot_pipeline.gd testet nur die Orchestrierung von BootPipeline mit
## MockValidator + MockResolver — die echte BootstrapConfig.tres und der
## echte ServiceDependencyResolver kommen dort nie zusammen zum Einsatz.
## Dadurch blieb unbemerkt, dass scenemanager/session_manager/interaction_executor
## eine Dependency auf "event_bus" deklarieren, obwohl EventBusAdapter erst NACH
## der Dependency-Auflösung (Phase 3.5 / C4.5) registriert wird. Phase 2/C3 hielt
## "event_bus" für unbekannt und brach den kompletten Boot ab — Ergebnis:
## Spiel startete weder Solo noch Multiplayer, trotz "All tests passed!".
##
## Dieser Test bildet GENAU die Reihenfolge nach, die BootPipeline.boot_app()
## und boot_character() tatsächlich verwenden (inkl. der external_names, die
## an resolver.resolve() übergeben werden). Er lädt dabei die ECHTE
## res://config/BootstrapConfig.tres von Disk — kein Mock, kein Fake-Config.
##
## Läuft headless, keine Scene/Node-Instanziierung nötig (Validator und
## Resolver sind beide RefCounted, kein SceneTree-Zugriff).

const LOG_CAT := "Test"

var _validator: ServiceValidator
var _resolver:  ServiceDependencyResolver

func before_each() -> void:
	_validator = ServiceValidator.new()   # config = null → lädt echte .tres von Disk
	_resolver  = ServiceDependencyResolver.new()

# ─────────────────────────────────────────────────────────────────────────────
# App-Phase (Phase 1/1.5/2 in BootPipeline.boot_app)
# ─────────────────────────────────────────────────────────────────────────────

func test_app_services_resolve_without_missing_dependency() -> void:
	var defs := _validator.validate()
	assert_gt(defs.size(), 0, "Vorbedingung: global_services muss geladen werden können")

	var cfg := _validator.get_loaded_config()
	var resource_names: Array[String] = []
	for r in cfg.global_resources:
		resource_names.append(r.registry_key.to_lower())

	# Exakt wie BootPipeline.boot_app() Zeile ~82: resource_names + event_bus,
	# weil EventBusAdapter erst in Phase 3.5 registriert wird.
	var ordered := _resolver.resolve(defs, resource_names + [ServiceKeys.EVENT_BUS])

	assert_eq(
		ordered.size(), defs.size(),
		"Alle App-Services müssen auflösbar sein — leeres Ergebnis bedeutet " +
		"unbekannte Dependency ODER echten Zyklus in BootstrapConfig.tres"
	)

func test_app_resolution_fails_loudly_if_event_bus_dep_not_declared_external() -> void:
	## Gegenprobe: OHNE event_bus in external_names muss die Auflösung
	## exakt an der Stelle scheitern, die den ursprünglichen Bug verursacht hat.
	## Dieser Test dokumentiert das Bugverhalten und schützt davor, dass
	## jemand den Fix in BootPipeline.gd wieder entfernt, ohne es hier zu merken.
	var defs := _validator.validate()
	var cfg := _validator.get_loaded_config()
	var resource_names: Array[String] = []
	for r in cfg.global_resources:
		resource_names.append(r.registry_key.to_lower())

	var has_event_bus_dep := false
	for d in defs:
		if ServiceKeys.EVENT_BUS in d.deps:
			has_event_bus_dep = true
			break
	assert_true(
		has_event_bus_dep,
		"Vorbedingung: mindestens ein Service muss 'event_bus' als Dep deklarieren " +
		"(sonst testet dieser Fall nichts)"
	)

	var ordered := _resolver.resolve(defs, resource_names)  # ohne event_bus!
	assert_eq(
		ordered.size(), 0,
		"Ohne event_bus in external_names MUSS die Auflösung scheitern — " +
		"wenn das hier plötzlich klappt, hat sich die Config geändert und " +
		"test_app_services_resolve_without_missing_dependency muss geprüft werden"
	)

# ─────────────────────────────────────────────────────────────────────────────
# Character-Phase (Phase C2/C3 in BootPipeline.boot_character)
# ─────────────────────────────────────────────────────────────────────────────

func test_session_services_resolve_without_missing_dependency() -> void:
	var app_defs := _validator.validate()
	var app_names: Array[String] = []
	for d in app_defs:
		app_names.append(d.service_name.to_lower())

	var session_defs := _validator.validate_session(app_names)
	assert_gt(session_defs.size(), 0, "Vorbedingung: session_services muss geladen werden können")

	# Exakt wie BootPipeline.boot_character() Zeile ~161: app_names + event_bus,
	# weil EventBusAdapter erst in Phase C4.5 registriert wird.
	var ordered := _resolver.resolve(session_defs, app_names + [ServiceKeys.EVENT_BUS])

	assert_eq(
		ordered.size(), session_defs.size(),
		"Alle Session-Services müssen auflösbar sein — leeres Ergebnis bedeutet " +
		"unbekannte Dependency ODER echten Zyklus in BootstrapConfig.tres"
	)

# ─────────────────────────────────────────────────────────────────────────────
# Vollständiger End-to-End-Sanity-Check über beide Phasen hinweg
# ─────────────────────────────────────────────────────────────────────────────

func test_full_dependency_graph_has_no_unresolvable_service() -> void:
	## Fängt jede zukünftige "Service X hängt von Y ab, aber Y wird nie
	## registriert"-Regression ab — unabhängig davon ob Y ein normaler
	## Service, eine Resource oder ein spät registrierter Adapter wie
	## EventBusAdapter ist. Deckt beide Boot-Phasen in der echten Reihenfolge ab.
	var app_defs := _validator.validate()
	var cfg := _validator.get_loaded_config()
	var resource_names: Array[String] = []
	for r in cfg.global_resources:
		resource_names.append(r.registry_key.to_lower())

	var app_ordered := _resolver.resolve(app_defs, resource_names + [ServiceKeys.EVENT_BUS])
	assert_eq(app_ordered.size(), app_defs.size(), "App-Graph muss vollständig auflösbar sein")

	var app_names: Array[String] = []
	for d in app_defs:
		app_names.append(d.service_name.to_lower())

	var session_defs := _validator.validate_session(app_names)
	var session_ordered := _resolver.resolve(
		session_defs, app_names + [ServiceKeys.EVENT_BUS]
	)
	assert_eq(
		session_ordered.size(), session_defs.size(),
		"Session-Graph muss vollständig auflösbar sein"
	)
