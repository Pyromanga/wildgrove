# res://tests/unit/test_quest_panel_controller.gd
extends GutTest

## Tests für QuestPanelController — IV-03 (AUDIT-03).
##
## QuestPanelController extends Node — setup() verbindet 3 quest-Signale
## auf _ctx.bus().quest().
## Positiv-Test: quest_started via Mock → panel wird sichtbar.
## Isolation: AutoLoad-EventBus erreicht den Controller nicht.

var _ctrl: QuestPanelController
var _ctx: UIContext
var _bus: MockEventBus
var _canvas: CanvasLayer
var _visuals: QuestPanelVisuals

func before_each() -> void:
	_canvas = add_child_autofree(CanvasLayer.new())
	_visuals = QuestPanelVisuals.new(_canvas)

	_bus = MockEventBus.new()
	_ctx = UIContext.for_test()
	_ctx._bus = _bus

	_ctrl = QuestPanelController.new()
	_ctrl.setup(_visuals, _ctx)
	add_child_autofree(_ctrl)

func test_setup_connects_quest_started_on_injected_bus() -> void:
	assert_true(
		_bus.quest().quest_started.is_connected(_ctrl._on_quest_started),
		"setup() muss quest_started auf dem injizierten Bus verbinden"
	)

func test_quest_started_makes_panel_visible() -> void:
	# _on_quest_started() setzt panel.visible = true
	# QuestService ist null (for_test) → _show_quest bricht früh ab, aber visible wird gesetzt
	_visuals.panel.visible = false
	_bus.quest().emit_quest_started("quest_intro")
	assert_true(_visuals.panel.visible,
		"quest_started über Mock-Bus muss das Quest-Panel sichtbar machen")

func test_real_autoload_does_not_reach_controller() -> void:
	_visuals.panel.visible = false
	EventBus.quest.emit_quest_started("should_be_ignored")
	assert_false(
		_visuals.panel.visible,
		"Der echte AutoLoad-EventBus darf QuestPanelController nicht mehr erreichen"
	)
