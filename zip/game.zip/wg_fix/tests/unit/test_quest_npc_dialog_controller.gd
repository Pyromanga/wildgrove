# res://tests/unit/test_quest_npc_dialog_controller.gd
extends GutTest

## Unit-Tests für QuestNPCDialogController.
##
## Vorher ungetestet. Mit Runde-4-Migration nutzt der Controller Konstruktor-
## Injection (_init(quest_id, dialog_label, scene_tree, bus: IEventBus)) statt
## direktem EventBus-AutoLoad — vollständig isoliert über MockEventBus testbar.
##
## Abgedeckt:
##   - on_interact(): State-Übergänge HAS_QUEST → QUEST_ACTIVE → QUEST_DONE
##   - _offer_quest(): emittiert quest_start_requested über injizierten Bus
##   - on_quest_completed(): setzt State nur bei passender quest_id
##   - on_objective_updated(): cached Fortschritt
##   - on_quest_start_failed(): zeigt passende Dialog-Texte je nach reason
##   - _show_dialog(): emittiert interaction_reward_text über injizierten Bus

var _bus:   MockEventBus
var _label: Label3D
var _tree:  SceneTree

func before_each() -> void:
	_bus   = MockEventBus.new()
	_label = add_child_autofree(Label3D.new())
	_tree  = Engine.get_main_loop() as SceneTree

func _make_controller(quest_id: String = "quest_woodcutter_intro") -> QuestNPCDialogController:
	return QuestNPCDialogController.new(quest_id, _label, _tree, _bus)

# ─────────────────────────────────────────────────────────────────────────────
# Konstruktor
# ─────────────────────────────────────────────────────────────────────────────

func test_init_starts_in_has_quest_state() -> void:
	var c := _make_controller()
	assert_eq(c.state, QuestNPCDialogController.NPCState.HAS_QUEST,
		"Frischer Controller muss im HAS_QUEST State starten")

func test_init_obj_progress_zero() -> void:
	var c := _make_controller()
	assert_eq(c.obj_progress, 0, "obj_progress muss initial 0 sein")

# ─────────────────────────────────────────────────────────────────────────────
# on_interact() — State-Übergänge
# ─────────────────────────────────────────────────────────────────────────────

func test_on_interact_has_quest_emits_quest_start_requested() -> void:
	var c := _make_controller("quest_woodcutter_intro")
	watch_signals(_bus.quest())
	c.on_interact()
	assert_signal_emitted_with_parameters(
		_bus.quest(), "quest_start_requested", ["quest_woodcutter_intro"]
	)

func test_on_interact_has_quest_transitions_to_active() -> void:
	var c := _make_controller()
	c.on_interact()
	assert_eq(c.state, QuestNPCDialogController.NPCState.QUEST_ACTIVE,
		"Nach on_interact() im HAS_QUEST State muss State auf QUEST_ACTIVE wechseln")

func test_on_interact_has_quest_shows_dialog() -> void:
	var c := _make_controller()
	c.on_interact()
	assert_true(_label.visible, "Dialog-Label muss nach _offer_quest() sichtbar sein")
	assert_true(_label.text.length() > 0, "Dialog-Text darf nicht leer sein")

func test_on_interact_active_stays_active() -> void:
	var c := _make_controller()
	c.state = QuestNPCDialogController.NPCState.QUEST_ACTIVE
	c.on_interact()
	assert_eq(c.state, QuestNPCDialogController.NPCState.QUEST_ACTIVE,
		"_encourage() darf den State nicht ändern")

func test_on_interact_active_does_not_reoffer_quest() -> void:
	var c := _make_controller()
	c.state = QuestNPCDialogController.NPCState.QUEST_ACTIVE
	watch_signals(_bus.quest())
	c.on_interact()
	assert_signal_not_emitted(_bus.quest(), "quest_start_requested",
		"Im QUEST_ACTIVE State darf quest_start_requested nicht erneut emittiert werden")

func test_on_interact_done_stays_done() -> void:
	var c := _make_controller()
	c.state = QuestNPCDialogController.NPCState.QUEST_DONE
	c.on_interact()
	assert_eq(c.state, QuestNPCDialogController.NPCState.QUEST_DONE)

# ─────────────────────────────────────────────────────────────────────────────
# on_quest_completed()
# ─────────────────────────────────────────────────────────────────────────────

func test_on_quest_completed_matching_id_sets_done() -> void:
	var c := _make_controller("quest_woodcutter_intro")
	c.on_quest_completed("quest_woodcutter_intro")
	assert_eq(c.state, QuestNPCDialogController.NPCState.QUEST_DONE)

func test_on_quest_completed_different_id_no_change() -> void:
	var c := _make_controller("quest_woodcutter_intro")
	c.state = QuestNPCDialogController.NPCState.QUEST_ACTIVE
	c.on_quest_completed("some_other_quest")
	assert_eq(c.state, QuestNPCDialogController.NPCState.QUEST_ACTIVE,
		"Quest-Completion eines anderen Quests darf den State nicht ändern")

# ─────────────────────────────────────────────────────────────────────────────
# on_objective_updated()
# ─────────────────────────────────────────────────────────────────────────────

func test_on_objective_updated_caches_progress() -> void:
	var c := _make_controller()
	c.on_objective_updated("quest_woodcutter_intro", 2)
	assert_eq(c.obj_progress, 2, "on_objective_updated() muss current cachen")

func test_on_objective_updated_reflected_in_encourage_dialog() -> void:
	var c := _make_controller()
	c.state = QuestNPCDialogController.NPCState.QUEST_ACTIVE
	c.on_objective_updated("quest_woodcutter_intro", 2)
	c.on_interact()
	assert_true("2" in _label.text, "Encourage-Dialog muss aktuellen Fortschritt zeigen")

# ─────────────────────────────────────────────────────────────────────────────
# on_quest_start_failed() — Dialog-Texte je nach reason
# ─────────────────────────────────────────────────────────────────────────────

func test_quest_start_failed_already_completed_shows_correct_text() -> void:
	var c := _make_controller()
	c.on_quest_start_failed("already_completed")
	assert_true("bereits erledigt" in _label.text)

func test_quest_start_failed_already_active_shows_correct_text() -> void:
	var c := _make_controller()
	c.on_quest_start_failed("already_active")
	assert_true("bereits" in _label.text)

func test_quest_start_failed_prereq_missing_shows_correct_text() -> void:
	var c := _make_controller()
	c.on_quest_start_failed("prereq_missing_level")
	assert_true("noch nicht bereit" in _label.text)

func test_quest_start_failed_unknown_reason_shows_default_text() -> void:
	var c := _make_controller()
	c.on_quest_start_failed("some_unknown_reason")
	assert_true("nicht gestartet werden" in _label.text)

func test_quest_start_failed_emits_reward_text_via_bus() -> void:
	var c := _make_controller()
	watch_signals(_bus.world())
	c.on_quest_start_failed("already_completed")
	assert_signal_emitted(_bus.world(), "interaction_reward_text",
		"_show_dialog() muss interaction_reward_text über injizierten Bus emittieren")

# ─────────────────────────────────────────────────────────────────────────────
# _show_dialog() — Bus-Integration
# ─────────────────────────────────────────────────────────────────────────────

func test_show_dialog_sets_label_text() -> void:
	var c := _make_controller()
	c.on_interact()  # ruft intern _offer_quest() → _show_dialog()
	assert_true(_label.text.length() > 0)

func test_show_dialog_strips_newlines_for_reward_text() -> void:
	var c := _make_controller()
	watch_signals(_bus.world())
	c.on_quest_start_failed("already_completed")
	# "Diese Aufgabe hast du\nbereits erledigt." → Zeilenumbruch durch Leerzeichen ersetzt
	var params = get_signal_parameters(_bus.world(), "interaction_reward_text")
	if params != null:
		assert_false("\n" in params[0], "interaction_reward_text darf keine Zeilenumbrüche enthalten")
