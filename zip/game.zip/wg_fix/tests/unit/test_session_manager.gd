## tests/unit/test_session_manager.gd
## Unit-Tests für SessionManager — Sprint B.
##
## Abdeckung:
##   SM-01  has_active_peer() = false ohne gesetzten Peer
##   SM-02  is_server() = true ohne Peer (Tier-1-Trivialfall)
##   SM-03  get_local_peer_id() = 1 ohne Peer
##   SM-04  create_server() gibt false zurück in headless (kein ENet-Stack)
##   SM-05  join_server() gibt false zurück in headless
##   SM-06  close() ist idempotent ohne Peer
##   SM-07  register_player_slot() speichert und get_player_id_for_peer() gibt zurück
##   SM-08  get_player_id_for_peer() für unbekannte peer_id = ""
##   SM-09  get_all_slots() gibt Kopie zurück (keine Referenz-Lecks)
##   SM-10  _on_peer_disconnected() entfernt Slot und emittiert peer_left
##   SM-11  configure() setzt kein Dep (no-op, nur Logging)
##   SM-12  on_cleanup() ruft close() und disconnected EventBus-Signale

extends GutTest

var _sm: SessionManager = null

func before_each() -> void:
	_sm = SessionManager.new()
	_sm.configure(ServiceDeps.from_dict({}))
	# on_ready() verbindet multiplayer.*-Signale — braucht SceneTree
	add_child_autofree(_sm)

func after_each() -> void:
	_sm.on_cleanup()
	_sm = null

# ─────────────────────────────────────────────
# SM-01…SM-03: Tier-1-Grundzustand (kein Peer)
# ─────────────────────────────────────────────

func test_has_active_peer_false_without_peer() -> void:
	assert_false(_sm.has_active_peer(), "Ohne Peer: has_active_peer() muss false sein.")

func test_is_server_true_without_peer() -> void:
	assert_true(_sm.is_server(), "Ohne Peer ist dieser Prozess immer die Autorität (Tier 1).")

func test_get_local_peer_id_is_1_without_peer() -> void:
	assert_eq(_sm.get_local_peer_id(), 1, "Ohne Peer ist die lokale peer_id immer 1.")

# ─────────────────────────────────────────────
# SM-04…SM-05: Host/Join in headless-Umgebung
# ─────────────────────────────────────────────

func test_create_server_returns_false_without_enet() -> void:
	# In der headless GUT-Umgebung ist kein ENet-Netzwerk-Stack verfügbar.
	# create_server() muss false zurückgeben statt zu crashen.
	var result := _sm.create_server(7777)
	assert_false(result, "create_server() muss false zurückgeben wenn kein ENet-Stack.")

func test_join_server_returns_false_without_enet() -> void:
	## HINWEIS: ENetMultiplayerPeer.create_client() prüft bei gültigen Adressen
	## (z.B. "127.0.0.1") nur lokale Voraussetzungen und schlägt selbst ohne
	## echten Server NICHT synchron fehl — die Verbindung wird nur "eingeleitet"
	## (siehe join_server()-Doku). Ein deterministischer Fehlerfall ohne echten
	## Netzwerk-Stack ist eine strukturell ungültige Adresse, die ENet schon bei
	## der Host-Auflösung zurückweist.
	var result := _sm.join_server("", 7777)
	assert_false(result, "join_server() muss bei ungültiger Adresse false zurückgeben.")

# ─────────────────────────────────────────────
# SM-06: close() idempotent
# ─────────────────────────────────────────────

func test_close_without_peer_does_not_crash() -> void:
	_sm.close()
	_sm.close()  # Zweiter Aufruf darf nicht crashen
	assert_true(true, "close() ohne Peer muss idempotent sein.")

# ─────────────────────────────────────────────
# SM-07…SM-09: Player-Slot-Registry
# ─────────────────────────────────────────────

func test_register_player_slot_and_get_back() -> void:
	_sm.register_player_slot(1, "charakter_1234")
	assert_eq(
		_sm.get_player_id_for_peer(1), "charakter_1234",
		"register_player_slot() muss player_id speichern und get_player_id_for_peer() zurückgeben."
	)

func test_get_player_id_for_unknown_peer_returns_empty() -> void:
	assert_eq(
		_sm.get_player_id_for_peer(99), "",
		"get_player_id_for_peer() für unbekannte peer_id muss leeren String zurückgeben."
	)

func test_get_all_slots_returns_copy() -> void:
	_sm.register_player_slot(1, "host")
	_sm.register_player_slot(2, "peer_2")
	var slots := _sm.get_all_slots()
	slots[99] = "manipuliert"  # Außenmodifikation darf Registry nicht ändern
	assert_eq(
		_sm.get_player_id_for_peer(99), "",
		"get_all_slots() muss eine echte Kopie zurückgeben — kein Referenz-Leak."
	)
	assert_eq(slots.size(), 3, "Kopie enthält 3 Einträge (inkl. manipuliertem).")
	assert_eq(_sm.get_all_slots().size(), 2, "Original-Registry bleibt bei 2 Einträgen.")

# ─────────────────────────────────────────────
# SM-10: Slot-Cleanup bei Disconnect
# ─────────────────────────────────────────────

func test_peer_disconnected_removes_slot_and_emits_signal() -> void:
	_sm.register_player_slot(2, "peer_2")
	var signal_received := [false]
	var received_peer   := [-1]
	_sm.peer_left.connect(func(p: int) -> void:
		signal_received[0] = true
		received_peer[0] = p
	)
	# Simuliere Disconnect direkt (kein echter Peer nötig)
	_sm._on_peer_disconnected(2)
	assert_true(signal_received[0], "peer_left muss emittiert werden.")
	assert_eq(received_peer[0], 2, "peer_left muss korrekte peer_id übergeben.")
	assert_eq(
		_sm.get_player_id_for_peer(2), "",
		"Slot muss nach Disconnect aus der Registry entfernt sein."
	)

# ─────────────────────────────────────────────
# SM-11: configure() ist no-op (kein Dep erforderlich)
# ─────────────────────────────────────────────

func test_configure_with_empty_deps_does_not_crash() -> void:
	var sm2 := SessionManager.new()
	sm2.configure(ServiceDeps.from_dict({}))
	# Kein Crash = Test bestanden
	assert_true(true, "configure() mit leeren deps darf nicht crashen.")

# ─────────────────────────────────────────────
# SM-12: on_cleanup() ist idempotent
# ─────────────────────────────────────────────

func test_on_cleanup_is_idempotent() -> void:
	_sm.register_player_slot(1, "host")
	_sm.on_cleanup()
	_sm.on_cleanup()  # Zweiter Aufruf darf nicht crashen
	assert_true(true, "on_cleanup() muss idempotent sein.")

# ─────────────────────────────────────────────
# SM-G03: Reconnect / Timeout / Peer-Cleanup
# ─────────────────────────────────────────────

func test_peer_disconnected_emits_peer_cleanup_requested() -> void:
	## G-03: peer_cleanup_requested muss VOR peer_left emittiert werden
	## damit Services Daten sichern können bevor der Slot entfernt wird.
	_sm.register_player_slot(3, "peer_3")
	var cleanup_fired := [false]
	var left_fired    := [false]
	var cleanup_order := [-1]
	var left_order    := [-1]
	var call_counter  := [0]

	_sm.peer_cleanup_requested.connect(func(p: int) -> void:
		if p == 3:
			call_counter[0] += 1
			cleanup_order[0] = call_counter[0]
			cleanup_fired[0] = true
	)
	_sm.peer_left.connect(func(p: int) -> void:
		if p == 3:
			call_counter[0] += 1
			left_order[0] = call_counter[0]
			left_fired[0] = true
	)

	_sm._on_peer_disconnected(3)

	assert_true(cleanup_fired[0], "peer_cleanup_requested muss bei Disconnect emittiert werden.")
	assert_true(left_fired[0],    "peer_left muss bei Disconnect emittiert werden.")
	assert_lt(cleanup_order[0], left_order[0],
		"peer_cleanup_requested muss VOR peer_left emittiert werden.")

func test_close_resets_retry_count() -> void:
	## G-03: close() setzt _retry_count zurück — nach close() keine Retries mehr.
	_sm._retry_count = 2
	_sm.close()
	assert_eq(_sm._retry_count, 0, "close() muss _retry_count auf 0 zurücksetzen.")

func test_join_timeout_constants_are_sane() -> void:
	## G-03: Timeout und Retry-Werte prüfen — keine absurden Defaults.
	assert_gt(SessionManager.JOIN_TIMEOUT_SEC, 0.0,
		"JOIN_TIMEOUT_SEC muss positiv sein.")
	assert_gte(SessionManager.MAX_RETRIES, 0,
		"MAX_RETRIES muss >= 0 sein.")
	assert_gt(SessionManager.RETRY_BASE_DELAY_SEC, 0.0,
		"RETRY_BASE_DELAY_SEC muss positiv sein.")
