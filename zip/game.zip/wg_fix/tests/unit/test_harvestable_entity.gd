# res://tests/unit/test_harvestable_entity.gd
extends GutTest

## Unit-Tests für HarvestableEntity + Subklassen.
##
## Abgedeckt:
##   P0 — Key-Round-Trip: mark_harvested via WorldService.mark_harvested()
##        dann is_harvested_by_type() → muss denselben Key finden
##   P0 — Key-Konsistenz: mark / unmark / is_harvested_by_type nutzen make_key()
##   P1 — Pool-Reuse: on_spawn() zweimal aufrufen → kein Visual-Kind akkumuliert
##   P1 — _clear_visuals(): InteractableComponent bleibt erhalten, MeshChildren weg
##   P2 — _add_placeholder_cylinder(): korrekte Kinder-Anzahl
##   P2 — _add_placeholder_box(): korrekte Kinder-Anzahl
##   Abstract-Guard: _get_entity_type_id() push_error (per direktem Aufruf prüfbar)

# ─────────────────────────────────────────────
# Hilfklassen — minimale Subklassen ohne SceneTree-Abhängigkeit
# ─────────────────────────────────────────────

## Minimale konkrete Subklasse für Tests die keine Factory3D brauchen.
class TestOre extends HarvestableEntity:
	func _get_entity_type_id() -> String:
		return "iron_ore"

	func _build_interactable_data() -> InteractableData:
		var d := InteractableData.new()
		d.id = "mine"; d.label = "Test"; d.xp_type = "mining"; d.xp_amount = 1
		return d

	func _build_visuals() -> void:
		_add_placeholder_box(Vector3(0.5, 0.5, 0.5), Color.GRAY)

class TestTree extends HarvestableEntity:
	func _get_entity_type_id() -> String:
		return "oak_tree"

	func _build_interactable_data() -> InteractableData:
		var d := InteractableData.new()
		d.id = "chop"; d.label = "Chop"; d.xp_type = "woodcutting"; d.xp_amount = 1
		return d

	func _build_visuals() -> void:
		_add_placeholder_cylinder(0.1, 1.0, Color.BROWN)

# ─────────────────────────────────────────────
# P0 — Harvest-Key-Round-Trip
# ─────────────────────────────────────────────

func test_p0_mark_key_matches_is_harvested_by_type() -> void:
	## Schreibt mit make_key() (wie WorldService.mark_harvested tut),
	## liest mit is_harvested_by_type() — beide müssen denselben Key erzeugen.
	var data := WorldData.new()
	var pos  := Vector3(5, 0, 5)
	# Schreiben — der Pfad den HarvestableEntity.on_despawn() geht:
	data.mark_harvested(WorldData.make_key("iron_ore", pos))
	# Lesen — der Pfad den WorldSpawner / RespawnService geht:
	assert_true(
		data.is_harvested_by_type("iron_ore", pos),
		"P0: mark via make_key() → is_harvested_by_type() muss denselben Key finden"
	)

func test_p0_unmark_key_matches_mark_key() -> void:
	## unmark_harvested() muss denselben Key löschen den mark_harvested() gesetzt hat.
	var data := WorldData.new()
	var pos  := Vector3(-3, 0, 2)
	data.mark_harvested(WorldData.make_key("oak_tree", pos))
	data.unmark_harvested("oak_tree", pos)
	assert_false(
		data.is_harvested_by_type("oak_tree", pos),
		"P0: unmark muss den von mark gesetzten Key entfernen"
	)

func test_p0_different_types_different_keys() -> void:
	## oak_tree_5_0_5 und iron_ore_5_0_5 dürfen sich nicht gegenseitig beeinflussen.
	var data := WorldData.new()
	var pos  := Vector3(5, 0, 5)
	data.mark_harvested(WorldData.make_key("oak_tree", pos))
	assert_false(
		data.is_harvested_by_type("iron_ore", pos),
		"P0: Typ-spezifische Keys dürfen sich nicht überschneiden"
	)

func test_p0_legacy_is_tree_harvested_uses_oak_tree_key() -> void:
	## is_tree_harvested() muss mit mark_harvested("oak_tree", pos) kompatibel sein.
	var data := WorldData.new()
	var pos  := Vector3(10, 0, 20)
	data.mark_harvested(WorldData.make_key("oak_tree", pos))
	assert_true(
		data.is_tree_harvested(pos),
		"P0: is_tree_harvested() muss oak_tree-Key aus mark_harvested finden"
	)

func test_p0_legacy_is_ore_harvested_uses_iron_ore_key() -> void:
	var data := WorldData.new()
	var pos  := Vector3(-5, 0, 15)
	data.mark_harvested(WorldData.make_key("iron_ore", pos))
	assert_true(
		data.is_ore_harvested(pos),
		"P0: is_ore_harvested() muss iron_ore-Key aus mark_harvested finden"
	)

# ─────────────────────────────────────────────
# P0 — make_key() Format
# ─────────────────────────────────────────────

func test_p0_make_key_format() -> void:
	var key := WorldData.make_key("oak_tree", Vector3(5, 0, 5))
	assert_eq(key, "oak_tree_5_0_5", "make_key() Format muss type_id_x_y_z sein")

func test_p0_make_key_negative_coords() -> void:
	var key := WorldData.make_key("iron_ore", Vector3(-3, 0, 2))
	assert_eq(key, "iron_ore_-3_0_2", "make_key() muss negative Koordinaten korrekt formatieren")

# ─────────────────────────────────────────────
# P1 — Pool-Reuse: Visual-Akkumulation
# ─────────────────────────────────────────────

func test_p1_pool_reuse_no_visual_accumulation() -> void:
	## Simuliert zwei Spawn-Zyklen ohne vollständigen despawn/free-Zyklus.
	## Nach dem zweiten on_spawn() darf es nicht doppelt so viele Kinder geben.
	var entity: TestOre = add_child_autofree(TestOre.new())
	# Erster Spawn
	entity.on_spawn({}, null)
	var children_after_first := entity.get_child_count()

	# Zweiter Spawn (Pool-Reuse) — ohne on_despawn() dazwischen
	entity.on_spawn({}, null)
	var children_after_second := entity.get_child_count()

	assert_eq(
		children_after_second,
		children_after_first,
		"P1: Pool-Reuse darf keine Kinder akkumulieren — Anzahl muss nach zweitem Spawn gleich sein"
	)

func test_p1_clear_visuals_removes_mesh_children() -> void:
	## _clear_visuals() soll MeshInstance3D entfernen.
	var entity: TestOre = add_child_autofree(TestOre.new())
	entity.on_spawn({}, null)
	# Manuelle Prüfung: nach _clear_visuals() keine MeshInstance3D mehr
	entity._clear_visuals()
	# get_children() gibt noch queue_free-markierte zurück bis nächster Frame —
	# wir prüfen stattdessen ob bei erneutem Spawn die Anzahl nicht wächst.
	entity._build_visuals()
	var count_a := entity.get_child_count()
	entity._clear_visuals()
	entity._build_visuals()
	var count_b := entity.get_child_count()
	assert_eq(count_a, count_b, "P1: _clear_visuals() + _build_visuals() muss idempotent sein")

func test_p1_clear_visuals_keeps_interactable_component() -> void:
	## _clear_visuals() darf den InteractableComponent NICHT entfernen.
	var entity: TestOre = add_child_autofree(TestOre.new())
	entity.on_spawn({}, null)
	entity._clear_visuals()
	# InteractableComponent bleibt als Kind (auch wenn queue_free-markiert werden
	# — TestOre hat keinen IC ohne _ready()-Aufruf). Wir prüfen dass _interactable_comp
	# noch valid ist wenn er existiert.
	if is_instance_valid(entity._interactable_comp):
		assert_true(
			is_instance_valid(entity._interactable_comp),
			"P1: InteractableComponent muss nach _clear_visuals() noch valid sein"
		)

# ─────────────────────────────────────────────
# P2 — _add_placeholder_cylinder / _add_placeholder_box
# ─────────────────────────────────────────────

func test_p2_placeholder_cylinder_adds_one_child() -> void:
	var entity: TestTree = add_child_autofree(TestTree.new())
	var before := entity.get_child_count()
	entity._add_placeholder_cylinder(0.1, 1.0, Color.BROWN)
	# +1 MeshInstance3D erwartet
	assert_eq(entity.get_child_count(), before + 1, "P2: _add_placeholder_cylinder() muss genau ein Kind hinzufügen")

func test_p2_placeholder_box_adds_one_child() -> void:
	var entity: TestOre = add_child_autofree(TestOre.new())
	var before := entity.get_child_count()
	entity._add_placeholder_box(Vector3(0.5, 0.5, 0.5), Color.GRAY)
	assert_eq(entity.get_child_count(), before + 1, "P2: _add_placeholder_box() muss genau ein Kind hinzufügen")

func test_p2_placeholder_cylinder_position_y() -> void:
	## Stamm-Mitte soll bei height * 0.5 liegen.
	var entity: TestTree = add_child_autofree(TestTree.new())
	entity._add_placeholder_cylinder(0.1, 2.0, Color.BROWN)
	var mesh := entity.get_children().back() as MeshInstance3D
	assert_almost_eq(mesh.position.y, 1.0, 0.001,
		"P2: Zylinder-Mitte muss bei height/2 = 1.0 liegen")

# ─────────────────────────────────────────────
# P0 — WorldData.typed_tree/ore_positions
# ─────────────────────────────────────────────

func test_p0_add_typed_tree_populates_both_arrays() -> void:
	var data := WorldData.new()
	var pos  := Vector3(3, 0, 7)
	data.add_typed_tree("willow_tree", pos)
	assert_true(pos in data.tree_positions,
		"add_typed_tree() muss Position in tree_positions eintragen (Abwärtskompatibilität)")
	assert_true(data.typed_tree_positions.has("willow_tree"),
		"add_typed_tree() muss typed_tree_positions[willow_tree] anlegen")
	assert_true(pos in data.typed_tree_positions["willow_tree"],
		"add_typed_tree() muss Position in typed_tree_positions[willow_tree] eintragen")

func test_p0_add_typed_ore_populates_both_arrays() -> void:
	var data := WorldData.new()
	var pos  := Vector3(-2, 0, 8)
	data.add_typed_ore("copper_ore", pos)
	assert_true(pos in data.ore_positions,
		"add_typed_ore() muss Position in ore_positions eintragen")
	assert_true(data.typed_ore_positions.has("copper_ore"),
		"add_typed_ore() muss typed_ore_positions[copper_ore] anlegen")

# ─────────────────────────────────────────────────────────────────────────────
# _on_interacted() — Despawn via IEventBus (Runde 4 EventBus-Migration)
# ─────────────────────────────────────────────────────────────────────────────
##
## _on_interacted() nutzt jetzt _ctx.get_event_bus() statt direktem AutoLoad-Zugriff.
## Diese Tests verifizieren den neuen Pfad: mit Bus, ohne Bus, ohne UUID.

func test_on_interacted_emits_despawn_via_injected_bus() -> void:
	var entity: TestTree = add_child_autofree(TestTree.new())
	var bus    := MockEventBus.new()
	var ctx    := EntityContext.for_test()
	ctx._bus   = bus
	entity.on_spawn({}, ctx)
	entity.set_meta("entity_uuid", "uuid-123")

	watch_signals(bus.world())
	entity._on_interacted("chop")

	assert_signal_emitted(bus.world(), "entity_despawn_requested",
		"_on_interacted() muss entity_despawn_requested über den injizierten Bus emittieren")

func test_on_interacted_emits_correct_uuid() -> void:
	var entity: TestTree = add_child_autofree(TestTree.new())
	var bus    := MockEventBus.new()
	var ctx    := EntityContext.for_test()
	ctx._bus   = bus
	entity.on_spawn({}, ctx)
	entity.set_meta("entity_uuid", "uuid-xyz")

	watch_signals(bus.world())
	entity._on_interacted("chop")

	assert_signal_emitted_with_parameters(bus.world(), "entity_despawn_requested", ["uuid-xyz"],
		"entity_despawn_requested muss mit der korrekten UUID emittiert werden")

func test_on_interacted_without_bus_falls_back_to_direct_despawn() -> void:
	## Kein _ctx gesetzt (Entity ohne EntityOrchestrator gespawnt) → direkter
	## on_despawn() + queue_free() Pfad, kein Crash.
	var entity: TestTree = add_child_autofree(TestTree.new())
	entity.set_meta("entity_uuid", "uuid-456")
	# Kein on_spawn() aufgerufen — _ctx bleibt null.
	entity._on_interacted("chop")
	assert_true(true, "_on_interacted() ohne _ctx darf nicht crashen (Fallback auf queue_free)")

func test_on_interacted_without_uuid_falls_back_to_direct_despawn() -> void:
	var entity: TestTree = add_child_autofree(TestTree.new())
	var bus    := MockEventBus.new()
	var ctx    := EntityContext.for_test()
	ctx._bus   = bus
	entity.on_spawn({}, ctx)
	# Keine UUID gesetzt.
	watch_signals(bus.world())
	entity._on_interacted("chop")
	assert_signal_not_emitted(bus.world(), "entity_despawn_requested",
		"Ohne UUID darf kein Despawn-Request emittiert werden — direkter Pfad stattdessen")

func test_on_interacted_with_ctx_but_no_bus_logs_warning_no_crash() -> void:
	## EntityContext.for_test() ohne _bus gesetzt — get_event_bus() liefert null.
	var entity: TestTree = add_child_autofree(TestTree.new())
	var ctx    := EntityContext.for_test()
	entity.on_spawn({}, ctx)
	entity.set_meta("entity_uuid", "uuid-789")
	entity._on_interacted("chop")
	assert_true(true, "_on_interacted() mit ctx aber ohne bus darf nicht crashen")
