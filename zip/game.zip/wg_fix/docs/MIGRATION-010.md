# MIGRATION-010 — Multiplayer Authority Tiers

**Referenz:** [ADR-010](adr/010-multiplayer-authority-tiers.md)  
**Ziel:** Session-Services von Single-Tenant auf Multi-Tenant umstellen;
`INetworkAdapter`/`LocalNetworkAdapter` (ADR-007) entfernen;
`request_*()`-Implementierungen direkt auf Godot-RPC verdrahten.

---

## Gesamtstatus

| Phase | Beschreibung | Status |
|-------|-------------|--------|
| 1 | Multi-Tenant State in Session-Services | ✅ Abgeschlossen |
| 2 | `INetworkAdapter` entfernen | ✅ Abgeschlossen |
| 3 | Authority Guards hardenen | ✅ Abgeschlossen |
| 4 | RPC-Verdrahtung (`request_*` → Godot-RPC) | 🔲 Ausstehend |
| 5 | Equipment-Sync im NetworkBridge | 🔲 Ausstehend |

---

## Phase 1 — Multi-Tenant State ✅

**Ziel:** Alle Session-Services trennen internen State per `player_id`/`peer_id`.

| Service | Vorher | Nachher | Status |
|---------|--------|---------|--------|
| `InventorySystem` | `_items: Dictionary` (flat) | `_players: { peer_id: {...} }` | ✅ |
| `PlayerStateService` | `_current: State` (single) | `_current: { peer_id: State }` | ✅ |
| `EquipmentService` | `_slots: Dictionary` (flat) | `_players: { player_id: slots }` | ✅ |
| `QuestService` | `_quests` per player_id | bereits multi-tenant | ✅ |
| `SkillSystem` | `_skills` per player_id | bereits multi-tenant | ✅ |
| `CombatSystem` | `_active_effects` per source_id | bereits per source_id gekeyt | ✅ |

---

## Phase 2 — INetworkAdapter entfernen ✅

`INetworkAdapter.gd` und `LocalNetworkAdapter.gd` wurden entfernt.
`NetworkContract.gd` und `CONTRIBUTING.md` (Abschnitt 2.3) wurden aktualisiert.
`request_*()` / `on_*_confirmed()` als Naming-Konvention bleibt (ADR-004).

---

## Phase 3 — Authority Guards hardenen ✅

| Ort | Vorher | Nachher | Status |
|-----|--------|---------|--------|
| `CombatSystem.roll_critical()` | `assert(multiplayer.is_server())` — No-Op in Release | `if not is_server(): return false` | ✅ |
| `CombatSystem.roll_critical()` | `chance` ignorierte StatModifier | `chance += get_effective_stat("crit_chance", ...)` | ✅ |

---

## Phase 4 — RPC-Verdrahtung 🔲

**Ziel:** `request_*()` direkt gegen Godot `MultiplayerAPI` bauen statt gegen entfernten Adapter.

Betroffen (geschätzt, nicht vollständig geprüft):

- `InventorySystem.request_add_item()` / `on_item_add_confirmed()`
- `QuestService.request_start_quest()` / `on_quest_start_confirmed()`
- `SkillSystem.request_skill_use()` / `on_skill_use_confirmed()`
- `NetworkBridge.gd` — zentrale RPC-Dispatch-Schicht

Muster (ADR-010, Option C):

```gdscript
# Client → Authority
func request_add_item(item_id: String, player_id: int) -> void:
    rpc_id(get_multiplayer_authority(), "_rpc_add_item", item_id, player_id)

# Authority → lokal ausführen
@rpc("authority", "call_local")
func _rpc_add_item(item_id: String, player_id: int) -> void:
    on_item_add_confirmed(item_id, player_id)
```

Tier-1-Fallback (kein Peer): `get_multiplayer_authority()` = 1 = lokaler Peer → `rpc_id` ruft
Methode lokal auf, kein Netzwerkverkehr. Kein separater Code-Pfad nötig.

**Vorbedingung:** Tier-2/3-Testumgebung (zwei Peers) vorhanden, bevor Phase 4 beginnt.

---

## Phase 5 — Equipment-Sync im NetworkBridge 🔲

`NetworkBridge` hat keine `send_equip_item()` / `_rpc_equip_item()`.
In Tier 1 ist Equipment lokal — kein Problem.
Ab Tier 2 (Hosted Coop) sehen andere Spieler keine Equipment-Änderungen.

Scope: `NetworkBridge.gd` erweitern um Equip/Unequip RPC analog zu Phase 4.

---

## Offene Schulden nach Phase 3

- Authority Guards in Services selbst fehlen noch (nicht nur in NetworkBridge):
  `InventorySystem.on_item_add_confirmed()` hat keinen `is_server()`-Check.
  Solange NetworkBridge der einzige Aufrufer ist, kein akutes Problem —
  bei direktem Aufruf (Tests, Debug-Konsole) bypassbar.

- UUID-Vergabe in `EntityOrchestrator` noch nicht authority-gebunden (ADR-010, Punkt 2).
