# Architecture Decision Records — WildGrove

ADRs dokumentieren **warum** Entscheidungen getroffen wurden, nicht nur was entschieden wurde.  
Sie sind unveränderliche Geschichte: ein ADR wird nie gelöscht, nur durch einen neuen ADR abgelöst.  
Ausnahme: ADRs die vollständig durch ihren Nachfolger absorbiert wurden und keinen eigenständigen historischen Wert mehr haben, können entfernt werden (wie ADR-007).

---

## Index

| Nr. | Titel | Status | Datum |
|-----|-------|--------|-------|
| [001](001-service-locator-pattern.md) | Service Locator statt vollständigem DI-Container | Akzeptiert | 2026-06 |
| [002](002-eventbus-namespacing.md) | EventBus mit typisierten Namespaces | Akzeptiert | 2026-06 |
| [003](003-servicenode-vs-service.md) | ServiceNode (Node) vs Service (RefCounted) als Basisklassen | Akzeptiert | 2026-06 |
| [004](004-request-confirmed-pattern.md) | request_/on_*_confirmed als Networking-Kontrakt | Akzeptiert — Tech Debt offen (AUDIT-03 I-01) | 2026-06 |
| [005-006](005-006-save-provider-entity-context.md) | ISaveProvider-Interface + EntityContext-Injection | Akzeptiert | 2026-06 |
| [007] | INetworkAdapter-Interface | **Gelöscht** — vollständig in ADR-010 absorbiert | 2026-06 |
| [008](008-combat-system.md) | CombatSystem mit DamageRecord + DamageType | Akzeptiert | 2026-06 |
| [009](009-global-vs-session-services.md) | Global-Services vs. Session-Services — Charakter-Wechsel ohne App-Neustart | Akzeptiert | 2026-06 |
| [010](010-multiplayer-authority-tiers.md) | Multiplayer-Authority — Listen-Server/Dedicated-Server-Dualität auf Godots MultiplayerAPI | Akzeptiert | 2026-06 |
| [011](011-typed-di-resource-injection.md) | Typisiertes DI-Interface: ServiceDeps + Injectable Resources | Akzeptiert | 2026-06 |
| [012](012-ui-eventbus-injection.md) | UI-Layer EventBus-Injektion: IUIContext.bus() (schließt H-07 ab) | Akzeptiert | 2026-06 |
| [013](013-harvestable-entity-base-class.md) | HarvestableEntity als Basisklasse für abbaubare Welt-Objekte | Akzeptiert | 2026-06 |
| 014 | AutoLoad-Ausnahmen für Pre-Boot-Nodes | Obsolet (gelöscht — Ausnahme entfiel nach Three-Scope-Refactor) | 2026-06 |

---

## ADR-Template

Neue ADRs mit dieser Vorlage anlegen: `docs/adr/NNN-kurztitel.md`

```markdown
# ADR-NNN: Titel

**Status:** Vorgeschlagen | Akzeptiert | Abgelehnt | Abgelöst von ADR-XXX  
**Datum:** YYYY-MM  
**Kontext:** [Wer ist betroffen?] [Welche Systeme?]

## Problem

[Welches Problem löst diese Entscheidung? Was war der Auslöser?]

## Optionen

### Option A: [Name]
[Beschreibung]
- ✅ Vorteile
- ❌ Nachteile

### Option B: [Name]
[Beschreibung]
- ✅ Vorteile
- ❌ Nachteile

## Entscheidung

[Welche Option wurde gewählt und warum?]

## Konsequenzen

### Positiv
- [Was wird besser?]

### Negativ / Risiken
- [Was wird schlechter oder welche neuen Probleme entstehen?]

### Mitigationen
- [Wie werden die Risiken abgefedert?]

## Ablösung

[Leer lassen bis dieser ADR durch einen neuen abgelöst wird]
```
