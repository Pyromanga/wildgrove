# ADR-009: Global-Services vs. Session-Services — Charakter-Wechsel ohne App-Neustart

**Status:** Akzeptiert  
**Datum:** 2026-06  
**Kontext:** ServiceOrchestrator, BootstrapConfig, SaveSystem, MainMenu

---

## Problem

Der `ServiceOrchestrator` bootet beim App-Start alle Services ein einziges Mal und reißt sie erst beim App-Exit wieder ab. Das ist für `SceneManager`, `DataService` oder `GameManager` korrekt — diese Services halten keinen Charakter-spezifischen State. Aber `InventorySystem`, `SkillSystem`, `QuestService`, `PlayerStateService`, `WorldService` u.a. laden ihre Daten aus dem Save-Slot des aktiven Charakters. Wenn man den Charakter wechseln möchte (über das Hauptmenü), müsste man derzeit die App neu starten — `SaveSystem.set_active_player_id()` war zwar im A-10-Design vorgesehen, aber es gab keinen Mechanismus, um die betreffenden Services danach neu zu initialisieren.

**Symptom:** `list_local_saves()` existiert (A-10), `set_active_player_id()` existiert (A-10), aber ein Character-Select-Screen hätte keine Möglichkeit, die geladenen Services auf den neuen Charakter umzuschalten — das A-10-Fundament blieb ohne den „letzten Meter" nutzbar.

---

## Optionen

### Option A: App-Neustart bei Charakter-Wechsel
Charakter-Wechsel bedeutet vollständiger Neustart. Session-Daten per URL-Parameter oder Datei übergeben.
- ✅ Kein Infrastruktur-Overhead
- ❌ Inakzeptable UX für jedes Spiel mit Character-Select
- ❌ Godot Mobile unterstützt keinen App-Neustart als Game-Flow

### Option B: Alle Services in configure() säubern und neu initialisieren
Kein zweites Registry. `ServiceOrchestrator.reload_session()` ruft `on_cleanup()` dann `configure()` erneut auf einem Subset auf.
- ✅ Kein neues Abstraktionskonzept
- ❌ Services sind nach `configure()` mit Live-State in `on_ready()` — ein partielles Re-Init ist fehleranfällig
- ❌ Kein klares Konzept: welche Services werden neu-initialisiert? Ad-hoc-Liste im Orchestrator.
- ❌ EventBus-Connections werden in `on_ready()` registered und in `on_cleanup()` removed — ein erneutes `configure()` ohne `on_cleanup()` → Connection-Leak

### Option C: Zwei Registries — Global-Services und Session-Services (gewählt)
`BootstrapConfig.tres` deklariert `global_services` und `session_services` als getrennte Arrays. `ServiceOrchestrator` hält `_global_registry` (bootet in `_ready()`, läuft für die gesamte App-Lifetime) und `_session_registry` (bootet in `boot_session(player_id)`, wird in `teardown_session()` vollständig abgerissen und bei Charakter-Wechsel neu gebootet).

- ✅ Explizite, dokumentierte Trennung: welcher Service ist global, welcher ist session-scoped
- ✅ `teardown_session()` nutzt den bestehenden `ServiceTeardownManager` → `on_cleanup()` läuft korrekt, Connection-Leaks unmöglich
- ✅ Session-Services können in `configure(deps)` auf Global-Services zeigen (SaveSystem, DataService) — korrekte DI via fallback-Registry
- ✅ `SaveSystem` bleibt global → `list_local_saves()` im Hauptmenü ohne aktive Session nutzbar
- ⚠️ `ServiceValidator`, `ServiceDependencyResolver`, `ServiceInitializer` brauchen kleine Erweiterungen für Cross-Registry-Dependencies

---

## Entscheidung

**Option C.** Zwei Registries als explizite Architektur-Entscheidung.

**Global-Services** (app-lifetime, `global_services` in BootstrapConfig):
- `ticker` — Tick-Infrastruktur
- `scenemanager` — Szenen-Übergänge
- `data` — Statische Spieldaten (ItemDefinition, SkillDefinition), kein Charakter-State
- `gamemanager` — State-Machine, kein Charakter-State
- `savesystem` — Slot-Management (`list_local_saves()`, `has_save_for()`), kein geladener Save-State

**Session-Services** (charakter-lifetime, `session_services` in BootstrapConfig):
- `gamesave`, `playerstates`, `inventory`, `skill_system`, `interaction_executor`
- `world_gen`, `world`, `respawn`, `quest`, `reward_dispatcher`
- `stat_modifiers`, `combat`

**Boot-Flow:**
1. App-Start → `ServiceOrchestrator._ready()` → `boot_global()` → `GameManager.start_game()` → State: MAIN_MENU
2. Spieler wählt Charakter → `EventBus.system.emit_session_requested(player_id)`
3. `ServiceOrchestrator._on_session_requested()` → `boot_session(player_id)`:
   - `SaveSystem.begin_session(player_id)` → lädt Save vom Disk
   - Session-Services booten (können auf Global-Services als Deps zugreifen)
   - `Services.populate_session()` → `EventBus.system.session_ready.emit()`
4. `GameManager._on_session_ready()` → `change_state(PLAYING)` → Szenenwechsel zu World.tscn

**Teardown-Flow:**
- `GameManager.change_state(MAIN_MENU)` → emittiert `state_changed(MAIN_MENU)`
- `ServiceOrchestrator._on_state_changed(MAIN_MENU)` → wenn Session aktiv: `teardown_session()`
- `teardown_session()`: `Services.clear_session()` → `ServiceTeardownManager.execute(_session_registry)` → `SaveSystem.end_session()` → `session_unloaded.emit()`
- Szenenwechsel zu MainMenu.tscn (deferred, passiert nach Teardown)
- `MainMenuController._ready()` → `Services.save_system.list_local_saves()` → works ✓

---

## Konsequenzen

### Positiv
- Charakter-Wechsel ist ein vollständig unterstützter Game-Flow, keine App-Restart-Anforderung
- Das A-10-Fundament (Save-Slots, `list_local_saves()`, `set_active_player_id()`) bekommt seinen fehlenden „letzten Meter"
- Session-Services sind nach `teardown_session()` vollständig bereinigt — keine stale References
- `SaveSystem` als Global-Service: `list_local_saves()` und `has_save_for()` sind immer nutzbar, unabhängig von einer aktiven Session

### Negativ / Risiken
- `ServiceValidator`, `ServiceDependencyResolver`, `ServiceInitializer` brauchen minimale Erweiterungen
- Contributor-Entscheidung bei neuen Services: global oder session? → CONTRIBUTING.md dokumentiert den Entscheidungsbaum
- Session-Services die irrtümlich als Global definiert werden: kein Charakter-Wechsel mehr ohne Workaround → Code-Review muss diesen Aspekt prüfen

### Mitigationen
- `BootstrapConfig.tres` ist die Single Source of Truth: global vs. session ist explizit in einer Datei sichtbar
- Kommentar-Block über beiden Arrays in BootstrapConfig.gd erklärt die Unterscheidung
- CONTRIBUTING.md: Entscheidungsbaum — „Hält dieser Service Charakter-spezifischen State oder lädt er Daten aus dem Save?" → ja = session, nein = global

---

## Ablösung

Dieser ADR wird durch einen Account-ADR abgelöst wenn ein Server-seitiges Account-System implementiert wird. Zu diesem Zeitpunkt:
- `begin_session(player_id)` bekommt einen Token-Parameter vom Server statt einer lokalen Player-ID
- `end_session()` informiert ggf. den Server
- Der Zwei-Registry-Split bleibt bestehen; nur der Auth-Flow ändert sich
