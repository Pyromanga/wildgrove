extends RefCounted
class_name TerminalController

## TerminalController — Verbindet SimpleTerminalUI mit SimpleTerminal-Logik.
##
## Verwaltet Drag-Logik des Toggle-Buttons und leitet Eingaben weiter.
## Extends RefCounted (nicht Node) damit _init() Argumente annehmen kann.

var _logic: Node       # SimpleTerminal (AutoLoad)
var _ui: CanvasLayer   # SimpleTerminalUI

var _is_dragging     := false
var _drag_offset     := Vector2.ZERO
var _drag_start_pos  := Vector2.ZERO
const DRAG_THRESHOLD := 15.0

func _init(logic_node: Node, ui_node: CanvasLayer) -> void:
	_logic = logic_node
	_ui    = ui_node

## InputEventScreenTouch/-Drag haben nur 'position' (Viewport-lokal), kein
## 'global_position' — das existiert ausschließlich auf Maus-Events. Einheitlicher
## Zugriff über diesen Helper statt direktem .global_position auf beiden Event-Familien.
func _event_position(event: InputEvent) -> Vector2:
	if event is InputEventMouseButton or event is InputEventMouseMotion:
		return event.global_position
	return event.position

func handle_button_input(event: InputEvent, button: Button) -> void:
	if event is InputEventMouseButton or event is InputEventScreenTouch:
		var pos := _event_position(event)
		if event.pressed:
			_is_dragging    = true
			_drag_start_pos = pos
			_drag_offset    = button.global_position - pos
		else:
			_is_dragging = false
			# Nur togglen wenn kaum bewegt (kein Drag)
			if pos.distance_to(_drag_start_pos) < DRAG_THRESHOLD:
				_logic.toggle()

	if (event is InputEventMouseMotion or event is InputEventScreenDrag) and _is_dragging:
		button.global_position = _event_position(event) + _drag_offset

func submit_command(text: String) -> void:
	_logic.execute(text)
