# res://scripts/core/ServiceKeys.gd
class_name ServiceKeys

## ServiceKeys — Typsichere Konstanten für alle Service-Registry-Keys.
##
## Ersetzt alle magic strings wie deps.get("savesystem") oder
## registry.get_service("inventory") durch ServiceKeys.SAVE_SYSTEM etc.
##
## Tippfehler crashen zur Laufzeit → durch Konstanten werden sie zu
## Compile-Time-Fehlern (GDScript: Parser-Fehler bei undefined const).
##
## Konvention: Konstanten spiegeln den tatsächlichen Registry-Key 1:1.
## Wenn ein Key umbenannt wird, hier ändern — alle Aufrufer folgen automatisch.

# ─────────────────────────────────────────────
# Global Services (app-lifetime)
# ─────────────────────────────────────────────

const TICKER        := "ticker"
const SCENE         := "scenemanager"
const SAVE_SYSTEM   := "savesystem"
const DATA          := "data"
const GAME_MANAGER  := "gamemanager"
const SESSION_MANAGER := "session_manager"

# ─────────────────────────────────────────────
# Session Services (character-lifetime)
# ─────────────────────────────────────────────

const GAME_SAVE         := "gamesave"
const NETWORK_BRIDGE    := "network_bridge"
const INVENTORY         := "inventory"
const SKILL_SYSTEM      := "skill_system"
const QUEST             := "quest"
const PLAYER_STATES     := "playerstates"
const REWARD_DISPATCHER := "reward_dispatcher"
const STAT_MODIFIERS    := "stat_modifiers"
const COMBAT            := "combat"
const EQUIPMENT         := "equipment"
const WORLD             := "world"
const INTERACTION       := "interaction_executor"
const WORLD_GEN         := "world_gen"
const RESPAWN           := "respawn"

# ─────────────────────────────────────────────
# Injectable Resources (ADR-011)
# ─────────────────────────────────────────────

const GAME_CONFIG := "gameconfig"

# ─────────────────────────────────────────────
# Infrastructure (injectable — kein AutoLoad-Zugriff in Services)
# ─────────────────────────────────────────────

## IEventBus — injizierter Event-Bus für Services.
## In Produktion: EventBusAdapter (delegiert an EventBus-AutoLoad).
## In Tests:      MockEventBus (lokale Instanz, kein globales Bleeding).
const EVENT_BUS := "event_bus"
