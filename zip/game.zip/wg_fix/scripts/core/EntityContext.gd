# res://scripts/core/EntityContext.gd
class_name EntityContext extends IEntityContext

## EntityContext — Produktions-Implementierung von IEntityContext.
##
## Wird von EntityOrchestrator erstellt und in on_spawn() injiziert.
## Hält keine Services selbst — delegiert an die übergebenen Instanzen.
##
## Entities reichen diesen Wert an Service-Aufrufe durch statt player_id selbst
## herzuleiten — Abschirmung gemäß ADR-006 (kein Autoload-Zugriff in Entities).

var _skill_system:    Object = null
var _inventory:       Object = null
var _factory:         Object = null
var _respawn:         Object = null
var _data:            Object = null
var _stat_modifiers:  Object = null
var _combat_system:   Object = null
var _equipment:       Object = null
var _world:           Object = null
var _interaction_executor: Object = null
var _bus: IEventBus = null

## peer_id des Spielers, dem diese Entity gehört.
## Default 1 = lokaler Spieler (Tier 1 / Solo-Modus, kein MultiplayerPeer gesetzt).
## In Tier 2/3 wird dieser Wert von EntityOrchestrator.spawn_entity() gesetzt.
var owner_peer_id: int = 1

## Erstellt einen EntityContext aus injizierten Service-Instanzen.
## Canonical-Pfad: EntityOrchestrator.spawn_entity() nutzt diesen Constructor
## nach EntityOrchestrator.set_entity_services() — kein Services-Locator-Zugriff.
static func from_deps(
	skill_system: SkillSystem,
	inventory: InventorySystem,
	factory: Factory3D,
	respawn: RespawnService,
	data: DataService,
	stat_modifiers: StatModifierService,
	combat_system: CombatSystem,
	equipment: EquipmentService,
	world: WorldService,
	interaction_executor: InteractionExecutor,
	peer_id: int = 1,
	bus: IEventBus = null
) -> EntityContext:
	var ctx := EntityContext.new()
	ctx._skill_system         = skill_system
	ctx._inventory            = inventory
	ctx._factory              = factory
	ctx._respawn              = respawn
	ctx._data                 = data
	ctx._stat_modifiers       = stat_modifiers
	ctx._combat_system        = combat_system
	ctx._equipment            = equipment
	ctx._world                = world
	ctx._interaction_executor = interaction_executor
	ctx.owner_peer_id         = peer_id
	ctx._bus                  = bus
	return ctx

## Erstellt einen minimalen Kontext für Unit-Tests.
## Felder können danach direkt gesetzt werden:
##   var ctx = EntityContext.for_test()
##   ctx._skill_system = MockSkillSystem.new()
##   ctx.owner_peer_id = 42
static func for_test(peer_id: int = 1) -> EntityContext:
	var ctx := EntityContext.new()
	ctx.owner_peer_id = peer_id
	return ctx

# ─────────────────────────────────────────────
# IEntityContext Overrides
# ─────────────────────────────────────────────

func get_skill_system() -> SkillSystem:
	return _skill_system as SkillSystem

func get_inventory() -> InventorySystem:
	return _inventory as InventorySystem

func get_factory() -> Factory3D:
	return _factory as Factory3D

func get_respawn() -> RespawnService:
	return _respawn as RespawnService

func get_data() -> DataService:
	return _data as DataService

func get_stat_modifiers() -> StatModifierService:
	return _stat_modifiers as StatModifierService

func get_combat_system() -> CombatSystem:
	return _combat_system as CombatSystem

func get_equipment() -> EquipmentService:
	return _equipment as EquipmentService

func get_world() -> WorldService:
	return _world as WorldService

func get_interaction_executor() -> InteractionExecutor:
	return _interaction_executor as InteractionExecutor

func get_factory3d() -> Factory3D:
	return _factory as Factory3D

func get_event_bus() -> IEventBus:
	return _bus
