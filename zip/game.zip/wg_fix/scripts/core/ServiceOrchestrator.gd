extends Node

## ServiceOrchestrator — Dünne Lifecycle-Shell. Nichts mehr.
##
## Verwaltet nur noch:
##   - App-Boot in _ready()
##   - Character-Boot/Teardown auf Session-Request
##   - World-Boot wenn WorldScopeInitializer signalisiert
##   - Shutdown-Handling
##
## Alle Boot-Logik lebt in BootPipeline.
## Alle Scope-Daten leben in AppScope / CharacterScope / WorldScope.
## Keine _inject_*-Methoden. Keine Cross-Registry-Handshakes. Kein God Object.

const LOG_CAT := "Orchestrator"

var _pipeline: BootPipeline = BootPipeline.new()
var _app_scope: AppScope    = null

func _ready() -> void:
	_app_scope = AppScope.new(ServiceRegistry.new())
	var result := _pipeline.boot_app(_app_scope, self)
	if not result.ok:
		EventBus.system.boot_failed.emit(result.failed_phase, result.reason)
		return
	EventBus.system.session_requested.connect(_on_session_requested)
	EventBus.system.state_changed.connect(_on_state_changed)
	_connect_session_manager()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_CRASH:
		_pipeline.teardown_all(_app_scope)

# ─────────────────────────────────────────────
# Character-Scope
# ─────────────────────────────────────────────

func _on_session_requested(player_id: String) -> void:
	var char_scope := _app_scope.create_character_scope(player_id, self)
	var result     := _pipeline.boot_character(char_scope, self)
	if not result.ok:
		EventBus.system.boot_failed.emit(result.failed_phase, result.reason)
		return
	# WorldScope wird getriggert sobald WorldScopeInitializer in World.tscn bereit ist.
	# CharacterScope.world_scope_ready → _on_world_scope_ready
	char_scope.world_scope_ready.connect(_on_world_scope_ready)
	_watch_for_world_initializer()
	_wire_hud(char_scope)
	EventBus.system.emit_session_ready()

func _on_state_changed(new_state: int) -> void:
	if new_state == GameEnums.State.MAIN_MENU and _app_scope.has_character_scope():
		_app_scope.destroy_character_scope()
		EventBus.system.emit_session_unloaded()

# ─────────────────────────────────────────────
# World-Scope — getriggert durch WorldScopeInitializer (Push, kein Pull)
# ─────────────────────────────────────────────

func _on_world_initializer_ready(world_root: Node3D) -> void:
	var char_scope := _app_scope.get_character_scope()
	if char_scope == null:
		Logger.log_warn("WorldScopeInitializer signalisierte aber kein CharacterScope aktiv.", LOG_CAT)
		return
	var world_scope := char_scope.create_world_scope(world_root, self)
	var result      := _pipeline.boot_world(world_scope, self)
	if not result.ok:
		EventBus.system.boot_failed.emit(result.failed_phase, result.reason)

func _on_world_scope_ready(_world_scope: WorldScope) -> void:
	pass  # Erweiterungspunkt für post-world-boot Wiring

# ─────────────────────────────────────────────
# HUD-Wiring (war: _inject_save_system_into_main_menu + HUDManager.boot)
# MenuScopeInitializer und HUDScopeInitializer übernehmen das in Sprint I.
# Für jetzt: bleibt hier als expliziter Aufruf bis die Initializer-Nodes gebaut sind.
# ─────────────────────────────────────────────

func _wire_hud(char_scope: CharacterScope) -> void:
	var reg     := char_scope.registry
	var factory := func() -> IUIContext: return UIContext.from_registry(reg)
	if get_tree():
		HUDManager.boot(get_tree(), factory)

# ─────────────────────────────────────────────
# SessionManager — Client-Auto-Join
# ─────────────────────────────────────────────

func _connect_session_manager() -> void:
	var sm := _app_scope.get_service(ServiceKeys.SESSION_MANAGER) as SessionManager
	if is_instance_valid(sm):
		sm.client_connected_to_server.connect(_on_client_connected)

func _on_client_connected() -> void:
	var sm         := _app_scope.get_service(ServiceKeys.SESSION_MANAGER) as SessionManager
	var local_peer := sm.get_local_peer_id() if is_instance_valid(sm) else 1
	_on_session_requested("client_%d" % local_peer)

# ─────────────────────────────────────────────
# Debug API
# ─────────────────────────────────────────────

func get_service(service_name: String) -> Object:
	var svc := _app_scope.get_service(service_name)
	if svc == null and _app_scope.has_character_scope():
		svc = _app_scope.get_character_scope().get_service(service_name)
	return svc

func is_session_active() -> bool:
	return _app_scope.has_character_scope()

## Lauscht einmalig auf WorldScopeInitializer im SceneTree.
## Wird direkt nach boot_character() aufgerufen — bevor World.tscn geladen ist.
## Sobald WorldScopeInitializer bereit ist, wird world_ready connected und
## node_added sofort disconnected. Kein dauerhaftes Polling.
func _watch_for_world_initializer() -> void:
	get_tree().node_added.connect(_on_node_added_check_world, CONNECT_ONE_SHOT)

func _on_node_added_check_world(node: Node) -> void:
	if node is WorldScopeInitializer:
		node.world_ready.connect(_on_world_initializer_ready, CONNECT_ONE_SHOT)
	else:
		# Noch nicht der richtige Node — weiterwarten
		get_tree().node_added.connect(_on_node_added_check_world, CONNECT_ONE_SHOT)
