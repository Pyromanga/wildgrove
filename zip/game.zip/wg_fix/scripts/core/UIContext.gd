# res://scripts/core/UIContext.gd
class_name UIContext extends IUIContext

## UIContext — Produktions-Implementierung von IUIContext.
##
## Wird von HUDBuilder.build_all() erstellt und an alle Controller injiziert.

var _quest:        QuestService    = null
var _skill_system: SkillSystem     = null
var _inventory:    InventorySystem = null
var _equipment:    EquipmentService = null
var _data:         DataService      = null
var _bus:          IEventBus        = null

## Canonical DI-Pfad — nutzt ServiceRegistry statt AutoLoad.
## HUDManager.set_ui_context_factory() setzt eine Callable die diese Methode aufruft.
## I-02: löst IEventBus aus demselben Registry-Key wie Services (ServiceKeys.EVENT_BUS) —
## identischer EventBusAdapter, keine zweite Produktions-Implementierung.
static func from_registry(registry: ServiceRegistry) -> UIContext:
	var ctx        := UIContext.new()
	ctx._quest        = registry.get_service(ServiceKeys.QUEST)        as QuestService
	ctx._skill_system = registry.get_service(ServiceKeys.SKILL_SYSTEM) as SkillSystem
	ctx._inventory    = registry.get_service(ServiceKeys.INVENTORY)    as InventorySystem
	ctx._equipment    = registry.get_service(ServiceKeys.EQUIPMENT)    as EquipmentService
	ctx._data         = registry.get_service(ServiceKeys.DATA)         as DataService
	ctx._bus          = registry.get_service(ServiceKeys.EVENT_BUS)    as IEventBus
	return ctx

static func for_test() -> UIContext:
	return UIContext.new()

func get_quest()        -> QuestService:    return _quest
func get_skill_system() -> SkillSystem:     return _skill_system
func get_inventory()    -> InventorySystem: return _inventory
func get_equipment()    -> EquipmentService: return _equipment
func get_data()         -> DataService:      return _data
func bus()              -> IEventBus:        return _bus
