extends ServiceNode
# justified: on_ready() verbindet EventBus-Signals; change_state() braucht Lifecycle-Kontext.
class_name GameManager

const LOG_CAT := "GameManager"

var _current_state: GameEnums.State = GameEnums.State.BOOT
var _scene_manager: SceneManager
var _config:        GameConfig
var _bus:           IEventBus

func configure(deps: ServiceDeps) -> void:
	_scene_manager = deps.get_optional(ServiceKeys.SCENE) as SceneManager
	_config = deps.require(ServiceKeys.GAME_CONFIG) as GameConfig
	_bus    = deps.require(ServiceKeys.EVENT_BUS)    as IEventBus
	if not _config:
		AppLogger.log_warn("GameConfig nicht in deps — Übergänge unkontrolliert.", LOG_CAT)

func on_ready() -> void:
	# Session-Ready-Signal: wenn Session-Services gebootet sind → PLAYING
	_bus.system().session_ready.connect(_on_session_ready)
	_bus.ui().main_menu_requested.connect(
		func() -> void: change_state(GameEnums.State.MAIN_MENU)
	)
	AppLogger.log_debug("GameManager lauscht auf session_ready.", LOG_CAT)

## start_game() setzt den initialen State ohne einen Szenenwechsel auszulösen.
## MainMenu.tscn ist bereits die laufende Startszene (project.godot: run/main_scene).
## Keine Session wird hier gestartet — der Spieler wählt im Hauptmenü einen Charakter.
func start_game() -> void:
	_current_state = GameEnums.State.MAIN_MENU
	AppLogger.log_info("State initialisiert: MAIN_MENU (warte auf Charakter-Auswahl).", LOG_CAT)
	_bus.system().emit_state_changed(_current_state)

func _on_session_ready() -> void:
	AppLogger.log_info("Session bereit — wechsle zu PLAYING.", LOG_CAT)
	change_state(GameEnums.State.PLAYING)

func change_state(new_state: GameEnums.State) -> void:
	if new_state == _current_state:
		AppLogger.log_debug(
			"change_state ignoriert — bereits in State %s." % GameEnums.State.keys()[new_state],
			LOG_CAT
		)
		return

	if not is_instance_valid(_config):
		AppLogger.log_warn("GameConfig nicht geladen — StateValidator uebersprungen, Uebergang erlaubt.", LOG_CAT)
	elif not StateValidator.is_transition_allowed(_current_state, new_state, _config):
		AppLogger.log_error(
			"Uebergang BLOCKIERT: %s -> %s (nicht in valid_transitions)." % [
				GameEnums.State.keys()[_current_state], GameEnums.State.keys()[new_state]
			],
			LOG_CAT
		)
		return

	AppLogger.log_info(
		(
			"State: %s → %s"
			% [GameEnums.State.keys()[_current_state], GameEnums.State.keys()[new_state]]
		),
		LOG_CAT
	)
	_current_state = new_state

	if _scene_manager:
		_scene_manager.transition_to_state(_current_state)

	_bus.system().emit_state_changed(_current_state)

func get_state() -> GameEnums.State:
	return _current_state

func is_playing() -> bool:
	return _current_state == GameEnums.State.PLAYING
