# res://scripts/events/EventBusAdapter.gd
class_name EventBusAdapter extends IEventBus

## EventBusAdapter — Produktions-Implementierung von IEventBus.
##
## Delegiert 1:1 an den globalen EventBus-AutoLoad.
## Kein eigener State, kein overhead — reine Indirektionsschicht.
##
## Wird von ServiceInstaller als "event_bus"-Dep in die Registry eingetragen
## bevor Services configure() aufgerufen werden. Dadurch bekommen alle Services
## eine IEventBus-Instanz injiziert statt EventBus direkt zu referenzieren.
##
## Die echte EventBus-Instanz (AutoLoad) bleibt unverändert.
## Alle bestehenden UI-Nodes, Scene-Nodes und AutoLoads die EventBus direkt
## nutzen brauchen NICHT angepasst werden — die Adapter-Schicht ist
## ausschließlich für Services (configure/on_ready-Lifecycle).

func player() -> PlayerEvents:
	return EventBus.player

func world() -> WorldEvents:
	return EventBus.world

func system() -> SystemEvents:
	return EventBus.system

func ui() -> UIEvents:
	return EventBus.ui

func quest() -> QuestEvents:
	return EventBus.quest
