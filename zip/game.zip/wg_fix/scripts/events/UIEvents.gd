class_name UIEvents extends BaseEvents

## UIEvents.gd
## UI-spezifische Signale.
##
## request_context_menu — neu; wird von ContextButtonController gefeuert und
## von ContextMenuController empfangen. Vorher fehlte die Deklaration hier,
## was zur Laufzeit zu einem "Signal not found"-Fehler geführt hätte.

signal layout_requested(state: String)
signal menu_toggled(menu_name: String, is_visible: bool)
signal overlay_changed(overlay_type: String, active: bool)

signal joystick_moved(origin: Vector2, offset: Vector2)
signal joystick_toggled(is_active: bool, origin: Vector2)

## Wird von ContextButtonController gesendet, wenn der Spieler den Kontext-Button drückt.
## ContextMenuController empfängt es und öffnet das Menü mit den verfügbaren Aktionen.
signal request_context_menu

## Wird von beliebigen UI-Layern gesendet um eine Kurznotiz anzuzeigen.
## NotificationController lauscht hierauf.
signal notification_requested(text: String)

## Wird gesendet wenn ein Item gedroppt/aufgesammelt wird.
## FloatingTextController zeigt den Text kurz im HUD an.
## world_pos ist die 3D-Position des Drops (optional, wird ggf. ignoriert wenn kein Camera3D).
signal floating_loot_text_requested(text: String, world_pos: Vector3)

## Wird von UI-Controllern gesendet wenn eine Interaktion ausgeführt werden soll.
## InteractionExecutor lauscht hierauf.
signal interaction_execute_requested(action: InteractableAction)

## Szenen-Wechsel vom UI angefordert (z.B. Neu laden im Pause-Menü).
signal scene_reload_requested

## Hauptmenü vom UI angefordert (z.B. "Hauptmenü"-Button im Pause-Menü).
signal main_menu_requested

func _init() -> void:
	super._init("Events/UI")

# --- Logik-Emitter ---

func emit_layout_requested(state: String) -> void:
	_log("Layout Änderung angefordert: %s" % state)
	layout_requested.emit(state)

func emit_menu_toggled(menu_name: String, is_visible: bool) -> void:
	_log("Menü '%s' sichtbar: %s" % [menu_name, is_visible])
	menu_toggled.emit(menu_name, is_visible)

func emit_overlay_changed(overlay_type: String, active: bool) -> void:
	_log("Overlay '%s' Status: %s" % [overlay_type, active])
	overlay_changed.emit(overlay_type, active)

func emit_joystick_toggled(is_active: bool, origin: Vector2 = Vector2.ZERO) -> void:
	_log("Joystick aktiv: %s" % is_active)
	joystick_toggled.emit(is_active, origin)

func emit_joystick_moved(origin: Vector2, offset: Vector2) -> void:
	joystick_moved.emit(origin, offset)

func emit_request_context_menu() -> void:
	_log("Kontext-Menü angefordert.")
	request_context_menu.emit()

func emit_notification(text: String) -> void:
	_log("Notification: %s" % text)
	notification_requested.emit(text)

func emit_floating_text(text: String, world_pos: Vector3 = Vector3.ZERO) -> void:
	floating_loot_text_requested.emit(text, world_pos)

func emit_interaction_execute_requested(action: InteractableAction) -> void:
	_log("Interaktion ausführen: '%s'" % action.label)
	interaction_execute_requested.emit(action)

func emit_scene_reload_requested() -> void:
	_log("Szenen-Reload angefordert.")
	scene_reload_requested.emit()

func emit_main_menu_requested() -> void:
	_log("Hauptmenü angefordert.")
	main_menu_requested.emit()
