extends Node
class_name TouchInput

## TouchInput — Input-Adapter für Mobile + Desktop.
## Kein Service — direktes Child des Player-Nodes.
## Gibt js_vec, cam_delta und zoom_delta als Output-State heraus.
## Player liest diese Werte in _physics_process.
##
## IEventBus wird via inject_bus() von Player.on_spawn() injiziert — kein AutoLoad
## mehr (vgl. ADR-014, mittlerweile obsolet). JoystickController lauscht auf
## _bus.ui() für joystick_toggled/moved — die Bridge-Calls in _handle_touch()/
## _handle_drag() laufen über den injizierten Bus, nicht über AutoLoad.

# ─────────────────────────────────────────────
# Output-State (vom Player gelesen)
# ─────────────────────────────────────────────
var js_vec: Vector2 = Vector2.ZERO
var cam_delta: Vector2 = Vector2.ZERO
var zoom_delta: float = 0.0

# ─────────────────────────────────────────────
# Interner State
# ─────────────────────────────────────────────
const JS_RADIUS: float = 90.0

var _js_finger: int = -1
var _js_origin: Vector2 = Vector2.ZERO
var _right_fingers: Dictionary = {}
var _pinch_last_dist: float = 0.0
var _cam_finger: int = -1
var _cam_last: Vector2 = Vector2.ZERO

# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────

func _ready() -> void:
	pass  # Bus-Connect erfolgt in inject_bus(), aufgerufen von Player.on_spawn().

## Injiziert von Player.inject_player_states() → von EntityOrchestrator nach on_spawn().
## Kein Services-Locator, kein EventBus-Polling.
var _player_states: PlayerStateService = null
var _bus: IEventBus = null

## Wird von Player.inject_player_states() aufgerufen — einziger Injection-Punkt.
func inject_player_states(svc: PlayerStateService) -> void:
	_player_states = svc

## Wird von Player.on_spawn() unmittelbar nach add_child(input) aufgerufen.
## Ersetzt das frühere connect_to_event_bus() — kein AutoLoad mehr, Pflicht-Dep.
func inject_bus(bus: IEventBus) -> void:
	_bus = bus
	reset_input()  # Push initial joystick-off state to EventBus.ui listeners.
	_bus.player().input_reset_requested.connect(reset_input)

# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Zurücksetzen — aufgerufen von PlayerStateService wenn State wechselt.
func reset_input() -> void:
	js_vec = Vector2.ZERO
	cam_delta = Vector2.ZERO
	zoom_delta = 0.0
	_js_finger = -1
	_cam_finger = -1
	_pinch_last_dist = 0.0
	_right_fingers.clear()
	# Joystick-Visuals ausblenden wenn Input resettet wird
	_bus.ui().emit_joystick_toggled(false, Vector2.ZERO)

# ─────────────────────────────────────────────
# Input
# ─────────────────────────────────────────────

func _unhandled_input(event: InputEvent) -> void:
	if _bus == null:
		return  # inject_bus() noch nicht aufgerufen — Player baut Subsysteme noch auf
	if is_instance_valid(_player_states) and _player_states.is_in_menu():
		js_vec = Vector2.ZERO
		cam_delta = Vector2.ZERO
		return

	var sw := get_viewport().get_visible_rect().size.x

	if event is InputEventScreenTouch:
		_handle_touch(event as InputEventScreenTouch, sw)
	elif event is InputEventScreenDrag:
		_handle_drag(event as InputEventScreenDrag)
	elif event is InputEventMouseMotion:
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
			cam_delta += (event as InputEventMouseMotion).relative
	elif event is InputEventMouseButton and event.pressed:
		match (event as InputEventMouseButton).button_index:
			MOUSE_BUTTON_WHEEL_UP:
				zoom_delta -= 1.0
			MOUSE_BUTTON_WHEEL_DOWN:
				zoom_delta += 1.0

# ─────────────────────────────────────────────
# Touch-Handler
# ─────────────────────────────────────────────

func _handle_touch(event: InputEventScreenTouch, sw: float) -> void:
	if event.pressed:
		if event.position.x < sw * 0.5:
			# Linke Seite → Joystick
			if _js_finger < 0:
				_js_finger = event.index
				_js_origin = event.position
				# FIX: Bridge zu EventBus.ui damit JoystickController reagiert
				_bus.ui().emit_joystick_toggled(true, _js_origin)
				_bus.ui().emit_joystick_moved(_js_origin, Vector2.ZERO)
		else:
			# Rechte Seite → Kamera / Pinch
			_right_fingers[event.index] = event.position
			if _right_fingers.size() == 1:
				_cam_finger = event.index
				_cam_last = event.position
			elif _right_fingers.size() == 2:
				_cam_finger = -1
				var keys := _right_fingers.keys()
				_pinch_last_dist = (_right_fingers[keys[0]] as Vector2).distance_to(
					_right_fingers[keys[1]]
				)
	else:
		if event.index == _js_finger:
			_js_finger = -1
			js_vec = Vector2.ZERO
			# FIX: Bridge zu EventBus.ui
			_bus.ui().emit_joystick_toggled(false, Vector2.ZERO)
		if _right_fingers.erase(event.index):
			if _right_fingers.size() == 1:
				_cam_finger = _right_fingers.keys()[0]
				_cam_last = _right_fingers[_cam_finger]
			else:
				_cam_finger = -1

func _handle_drag(event: InputEventScreenDrag) -> void:
	if event.index == _js_finger:
		var delta_pos := event.position - _js_origin
		var clamped := delta_pos.limit_length(JS_RADIUS)
		js_vec = clamped / JS_RADIUS
		# FIX: Bridge zu EventBus.ui damit JoystickVisuals den Knob bewegen
		_bus.ui().emit_joystick_moved(_js_origin, clamped)

	elif _right_fingers.has(event.index):
		_right_fingers[event.index] = event.position

		if _right_fingers.size() == 2:
			var keys := _right_fingers.keys()
			var new_dist: float = (_right_fingers[keys[0]] as Vector2).distance_to(
				_right_fingers[keys[1]]
			)
			if _pinch_last_dist > 0.0:
				zoom_delta += (_pinch_last_dist - new_dist) * 0.05
			_pinch_last_dist = new_dist

		elif event.index == _cam_finger:
			cam_delta += event.position - _cam_last
			_cam_last = event.position
