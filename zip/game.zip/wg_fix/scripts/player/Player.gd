extends CharacterBody3D
class_name Player

## Player.gd — Gameplay-Loop, State-Machine, Death/Respawn.
## Setup-Logik (Subsystem-Bau) → PlayerSetup.gd
##
## Player wird via EntityOrchestrator.spawn_entity("player", pos) gespawnt.
## on_spawn(config, ctx) übernimmt Initialisierung — identisch zu allen anderen Entities.
## Initialer State kommt via EventBus.player.player_state_changed (PlayerStateService
## emittiert beim ersten set_state()). Kein einmaliges Polling mehr nötig.

const LOG_CAT       := "Player"
const JUMP_VELOCITY := 6.0

var _mover:  PlayerMover
var visuals: PlayerVisuals
var camera:  PlayerCamera
var input:   TouchInput
var sensor:  InteractionSensor
var health:  HealthComponent

var _jump_requested: bool    = false
var _spawn_position: Vector3 = Vector3.ZERO
var _is_dead:        bool    = false
var _respawn_timer:  SceneTreeTimer = null  ## Referenz zum Canceln bei Session-Ende

## Lokaler State-Cache — wird via EventBus aktualisiert, nie per Polling.
var _player_state: PlayerStateService.State = PlayerStateService.State.FREE
var _bus: IEventBus = null

func _ready() -> void:
	add_to_group("player")
	set_physics_process(false)
	# Signal-Connects laufen in on_spawn() — _bus ist erst dort garantiert gesetzt
	# (Pflicht-Dep via EntityContext, kein AutoLoad-Fallback, vgl. ADR-014).
	AppLogger.log_debug("Player _ready(). Warte auf on_spawn().", LOG_CAT)

## on_spawn() — Einstiegspunkt via EntityOrchestrator.
## ctx liefert alle benötigten Services. config kann spawn_position enthalten.
func on_spawn(config: Dictionary, ctx: IEntityContext) -> void:
	AppLogger.log_info("Player on_spawn() — initialisiere Subsysteme.", LOG_CAT)

	_bus = ctx.get_event_bus() if is_instance_valid(ctx) else null
	if _bus == null:
		AppLogger.log_error(
			"Player.on_spawn(): kein IEventBus im EntityContext — Spawn ohne DI nicht unterstützt.",
			LOG_CAT
		)
		return
	_bus.player().movement_interrupted.connect(_on_action_interrupted)
	_bus.player().player_state_changed.connect(_on_player_state_changed)

	var subs := PlayerSetup.build(self)
	_mover  = subs["mover"]
	visuals = subs["visuals"]
	camera  = subs["camera"]
	input   = subs["input"]
	sensor  = subs["sensor"]
	health  = subs["health"]
	health.died.connect(_on_player_died)
	health.health_changed.connect(
		func(cur: int, mx: int) -> void: _bus.player().emit_player_health_changed(cur, mx)
	)
	_bus.player().emit_player_health_changed(health.current_health, health.max_health)

	if is_instance_valid(sensor):
		sensor.inject_bus(_bus)
	if is_instance_valid(input):
		input.inject_bus(_bus)

	PlayerSetup.apply_stats(_mover, ctx)

	# StatModifierService in PlayerMover injizieren (Ablösung des internen Modifier-Dicts).
	# P1-Fix: ctx.get_service() existiert nicht in IEntityContext — korrekter Aufruf ist get_stat_modifiers().
	var stat_svc := ctx.get_stat_modifiers()
	if is_instance_valid(stat_svc):
		_mover.inject_stat_modifiers(stat_svc)

	# Spawn-Position aus config falls vorhanden, sonst aktuelle Position.
	if config.has("spawn_position"):
		global_position = config["spawn_position"]
	_spawn_position = global_position

	set_physics_process(true)
	_setup_multiplayer_sync()

	# G-04: Für Remote-Spieler (nicht der lokale Peer) Snapshot-Interpolation aktivieren.
	# Ohne Interpolation springen Remote-Spieler alle 50ms (20 Hz Sync-Rate).
	# Der lokale Spieler braucht keine Interpolation — er steuert sich selbst.
	if multiplayer.has_multiplayer_peer() \
			and get_multiplayer_authority() != multiplayer.get_unique_id():
		var interpolator := RemotePlayerInterpolator.new()
		interpolator.name = "RemoteInterpolator"
		add_child(interpolator)
		AppLogger.log_debug("Remote-Spieler: Snapshot-Interpolation aktiviert.", LOG_CAT)

	AppLogger.log_info("Player online. Position: %s." % str(global_position), LOG_CAT)

func on_despawn() -> void:
	set_physics_process(false)
	if is_instance_valid(_respawn_timer):
		if _respawn_timer.timeout.is_connected(_respawn):
			_respawn_timer.timeout.disconnect(_respawn)
		_respawn_timer = null
	_is_dead = false
	AppLogger.log_info("Player despawned.", LOG_CAT)

## Empfängt PlayerStateService von EntityOrchestrator nach on_spawn() — kein Services-Locator.
## EntityOrchestrator.spawn_entity() ruft dies auf wenn _entity_player_states gesetzt ist.
func inject_player_states(svc: PlayerStateService) -> void:
	if is_instance_valid(input):
		input.inject_player_states(svc)

# ─────────────────────────────────────────────
# Physics-Loop
# ─────────────────────────────────────────────

func _physics_process(delta: float) -> void:
	match _player_state:
		PlayerStateService.State.FREE:
			_loop_free(delta)
		PlayerStateService.State.BUSY:
			_loop_busy(delta)
		_:
			velocity = Vector3.ZERO
			move_and_slide()

func _loop_free(delta: float) -> void:
	var move_dir := MathHelper.calculate_move_direction(camera, input.js_vec)
	velocity = _mover.calculate_velocity(velocity, move_dir, delta, is_on_floor())
	if _jump_requested:
		_jump_requested = false
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
	move_and_slide()
	visuals.handle_rotation(move_dir, delta)
	camera.handle_input(input, delta)

func _loop_busy(delta: float) -> void:
	if input.js_vec.length() > 0.5:
		_bus.player().emit_movement_interrupted()
	velocity = velocity.move_toward(Vector3.ZERO, 15.0 * delta)
	move_and_slide()
	camera.handle_input(input, delta)

# ─────────────────────────────────────────────
# Jump / Death / Respawn
# ─────────────────────────────────────────────

func request_jump() -> void:
	_jump_requested = true

func _on_player_died() -> void:
	if _is_dead:
		return
	_is_dead = true
	AppLogger.log_info("Spieler gestorben — Respawn in 2s.", LOG_CAT)
	_bus.player().emit_player_died()
	_respawn_timer = get_tree().create_timer(2.0)
	_respawn_timer.timeout.connect(_respawn)

func _respawn() -> void:
	global_position = _spawn_position
	if is_instance_valid(health):
		health.reset()
	velocity        = Vector3.ZERO
	_is_dead        = false
	_jump_requested = false
	_bus.player().emit_player_respawned()
	AppLogger.log_info("Spieler respawnt.", LOG_CAT)

func _on_action_interrupted() -> void:
	visuals.play_effect("interrupted")

## Event-Handler für State-Updates vom PlayerStateService via EventBus.
func _on_player_state_changed(new_state: int) -> void:
	_player_state = new_state as PlayerStateService.State

# ─────────────────────────────────────────────
# Öffentliche API — Interaktion
# ─────────────────────────────────────────────

func get_closest_interactable() -> Node3D:
	return sensor.get_closest() if is_instance_valid(sensor) else null

# ─────────────────────────────────────────────
# Multiplayer-Sync (Sprint E / F-3)
# ─────────────────────────────────────────────

## Erstellt einen MultiplayerSynchronizer für Position, Rotation und Velocity.
##
## Autorität und Richtung:
##   Ein einzelner MultiplayerSynchronizer auf einem Node sendet immer
##   vom Autoritäts-Peer zu allen anderen Peers.
##   - Server-Entities (EnemyNPC, Bäume, …): Authority = 1 (Server) → Server→Clients
##   - Player des lokalen Clients: Authority = peer_id (Client) → Client→Server→andere Clients
##   set_multiplayer_authority() wurde in EntityOrchestrator.spawn_entity() bereits gesetzt
##   bevor on_spawn() (und damit diese Methode) aufgerufen wird.
##
## Interval:
##   replication_interval = 0.05s → 20 Hz. Ausreichend für flüssige Bewegung,
##   deutlich weniger Bandbreite als per-frame (60+ Hz).
func _setup_multiplayer_sync() -> void:
	var sync := MultiplayerSynchronizer.new()
	sync.name = "MultiplayerSync"
	sync.replication_interval = 0.05   # 20 Hz — Bandbreite/Flüssigkeit-Kompromiss
	add_child(sync)
	var config := SceneReplicationConfig.new()
	config.add_property(NodePath(".:position"))
	config.add_property(NodePath(".:rotation"))
	config.add_property(NodePath(".:velocity"))
	sync.replication_config = config
	AppLogger.log_debug("MultiplayerSynchronizer erstellt (position, rotation, velocity, 20Hz).", LOG_CAT)

func get_context_actions() -> Array[InteractableAction]:
	var target := get_closest_interactable()
	if not is_instance_valid(target):
		return []

	AppLogger.log_debug("Kontext für '%s'." % target.name, LOG_CAT)

	if target.has_meta("interactable_component"):
		var comp: InteractableComponent = target.get_meta("interactable_component")
		if is_instance_valid(comp):
			var actions := comp.get_actions()
			AppLogger.log_info("%d Aktion(en) für '%s'." % [actions.size(), target.name], LOG_CAT)
			return actions

	# Fallback: Child-Traversal
	for child in target.get_children():
		if child is InteractableComponent:
			return (child as InteractableComponent).get_actions()

	if target.has_method("start_default_interaction"):
		var fallback := InteractableAction.new("interact", "Interagieren")
		fallback.duration   = 1.5
		fallback.on_complete = func(): target.start_default_interaction()
		return [fallback]

	return []
