# InteractableData.gd
extends Resource
class_name InteractableData

## id: Eindeutiger Bezeichner der Aktion (z.B. "chop", "mine_iron", "attack_enemy").
## Wird von InteractableComponent für Signale und Bar-Zuordnung genutzt.
## Konvention: "<verb>_<objekttyp>", alles lowercase, kein Leerzeichen.
@export var id: String = "interact"
@export var label: String = "Interagieren"
@export var duration: float = 1.5
@export var xp_type: String = "none"
@export var xp_amount: int = 10
## loot_table: Neue datengetriebene Drop-Tabelle (LootTable.tres).
## Wenn gesetzt, wird diese für Drops verwendet statt dem alten drops-Dictionary.
@export var loot_table: LootTable
## drops: Legacy-Feld { "item_id": quantity } — wird ersetzt durch loot_table.
## Bleibt für Rückwärtskompatibilität bis alle Objekte migriert sind.
@export var drops: Dictionary = {}
@export var inspect_text: String = ""
