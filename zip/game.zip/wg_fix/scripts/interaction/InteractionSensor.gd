class_name InteractionSensor extends Area3D

## InteractionSensor — findet das nächste interagierbare Objekt in Reichweite.
##
## Verantwortung: Synchronen Lookup via get_closest() liefern UND
## proximity_changed emittieren wenn sich das nächste Ziel ändert.
##
## WICHTIG: Der Sensor ist die einzige Autorität für proximity_changed.
##   InteractableComponent emittiert proximity_changed nur noch für Logging-Zwecke.
##   Der Sensor aggregiert alle Area3D-Überlappungen und gibt nur das nächste Ziel aus.
##   Das verhindert Flickering wenn der Spieler zwischen zwei Entities läuft.
##
## CollisionShape wird von Player._build_sensor() gesetzt (Radius: 2.5m).

const LOG_CAT := "Sensor"

var _last_closest: Node3D = null
var _bus: IEventBus = null

## Wird von Player._build_sensor() unmittelbar nach add_child() aufgerufen —
## kein AutoLoad-Zugriff, Konstruktor-Injection-Äquivalent für SceneTree-Nodes.
func inject_bus(bus: IEventBus) -> void:
	_bus = bus

func _ready() -> void:
	add_to_group("interaction_sensor")
	AppLogger.log_debug(
		"InteractionSensor bereit. Monitoring: %s, Monitorable: %s."
		% [str(monitoring), str(monitorable)],
		LOG_CAT
	)

	if not monitoring:
		monitoring = true
		AppLogger.log_warn("monitoring war false — automatisch aktiviert.", LOG_CAT)

## Gibt das aktuell nächste Ziel zurück (oder null).
## Wird von InteractableComponent genutzt um zu prüfen ob SIE das Ziel ist.
func get_current_target() -> Node3D:
	return _last_closest

func _physics_process(_delta: float) -> void:
	if _bus == null:
		return  # inject_bus() noch nicht aufgerufen — Player baut Sensor noch auf

	var current := get_closest()

	if current == _last_closest:
		return  # Kein Wechsel — nichts zu tun

	# Ziel hat sich geändert — proximity_changed für altes und neues Ziel emittieren
	if is_instance_valid(_last_closest):
		AppLogger.log_debug("Ziel verloren: '%s'." % _last_closest.name, LOG_CAT)
		_bus.world().emit_proximity_changed(_last_closest, false)

	if is_instance_valid(current):
		var dist := global_position.distance_to(current.global_position)
		AppLogger.log_info(
			"Nächstes Ziel: '%s' (Dist: %.2fm)." % [current.name, dist],
			LOG_CAT
		)
		_bus.world().emit_proximity_changed(current, true)
	else:
		AppLogger.log_info("Kein Ziel mehr in Reichweite.", LOG_CAT)

	_last_closest = current

## Gibt das nächste Objekt in der "interactable"-Gruppe zurück, oder null.
## Nutzt get_overlapping_bodies() für Physics-Bodies und get_overlapping_areas() für Area3D-Entities.
func get_closest() -> Node3D:
	var closest: Node3D = null
	var min_dist := 999.0

	# Overlapping Bodies (für CharacterBody3D, StaticBody3D Entities)
	for body in get_overlapping_bodies():
		if body is Node3D and body.is_in_group("interactable"):
			var dist := global_position.distance_to((body as Node3D).global_position)
			if dist < min_dist:
				min_dist = dist
				closest = body

	# Overlapping Areas (für Area3D-basierte Entities — deckt InteractableComponent ab)
	#
	# Node-Hierarchie bei OakTree/IronOre (extends Node3D):
	#   OakTree  ← Entity-Root, in Gruppe "interactable"
	#     └─ InteractableComponent (Node3D)
	#          └─ ProximityDetector (Node3D)
	#               └─ DetectionArea (Area3D)  ← get_overlapping_areas() liefert diesen
	#
	# Daher: Vorfahren-Kette bis 4 Ebenen hoch durchsuchen.
	for area in get_overlapping_areas():
		var node: Node = area.get_parent()
		var depth := 0
		while is_instance_valid(node) and depth < 4:
			if node is Node3D and node.is_in_group("interactable"):
				var dist := global_position.distance_to((node as Node3D).global_position)
				if dist < min_dist:
					min_dist = dist
					closest = node as Node3D
				break
			node = node.get_parent()
			depth += 1

	return closest

## Gibt true zurück wenn gerade ein Ziel in Reichweite ist.
func has_target() -> bool:
	return is_instance_valid(get_closest())
