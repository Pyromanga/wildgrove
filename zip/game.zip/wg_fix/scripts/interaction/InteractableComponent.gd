extends Node3D
class_name InteractableComponent

## InteractableComponent — Koppelt ein World-Objekt an das Interaktions-System.
##
## Verantwortung:
##   - Gruppe "interactable" + Meta "interactable_component" auf Parent setzen
##   - Label3D + 3D-Fortschrittsbar verwalten
##   - Interaktion via InteractionExecutor ausführen
##   - Completion-Ergebnisse nur via EventBus weitergeben
##
## Delegiert Nähe-Erkennung → ProximityDetector (eigenes Signal-basiertes Node)
##
##   inject_context() empfängt IEntityContext von der Parent-Entity.
##   Falls inject_context() nie aufgerufen wird (Legacy/Tests ohne ctx),
##   greift start_default_interaction() als Fallback auf Services zurück
##   und loggt eine Warnung (Abwärtskompatibilitätspfad, kein harter Fehler).
##
##   Emittiert NUR via EventBus — keine direkten Service-Calls.
##
## G-02: ProximityDetector übergibt jetzt den Player-Node in player_entered/exited.
##   _is_player_target() nutzt den nächsten Spieler relativ zu dieser Interactable
##   statt get_first_node_in_group("player") — korrekt bei zwei Spielern.

@export var data: InteractableData
@export var detection_radius: float = 3.0

## Emitted when an interaction completes. The parent entity connects to this
## in _ready() — the component never calls get_parent() directly.
signal interacted(action_id: String)

const LOG_CAT := "Interactable"

var _bar_3d:  Factory3D.Bar3D = null
var _label:   Label3D         = null
var _ctx:     IEntityContext   = null   ## injiziert von Parent via inject_context()
var _world_events_connected: bool = false

# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────

func _ready() -> void:
	assert(data != null, "InteractableComponent braucht InteractableData! (data == null)")

	get_parent().add_to_group("interactable")
	get_parent().set_meta("interactable_component", self)

	_setup_label()
	# Bar-Setup + World-Events erfolgen in inject_context() sobald _ctx verfügbar ist;
	# hier nur wenn _ctx bereits gesetzt (Szenen-Init-Reihenfolge-Workaround).
	if is_instance_valid(_ctx):
		_setup_bar()
		_connect_world_events()
	_setup_proximity()
	# _connect_world_events() läuft in inject_context() — _ctx (und damit der
	# injizierte IEventBus) ist erst dort garantiert gesetzt.

	AppLogger.log_info(
		"Bereit: '%s' | Parent: '%s' | Radius: %.1fm"
		% [data.label, get_parent().name, detection_radius],
		LOG_CAT
	)

## Wird von der Parent-Entity in on_spawn() aufgerufen sobald der IEntityContext vorliegt.
## Ermöglicht Factory3D-Zugriff ohne Services-Locator.
func inject_context(ctx: IEntityContext) -> void:
	_ctx = ctx
	# Bar jetzt erst erstellen — Factory3D ist über ctx verfügbar.
	if not is_instance_valid(_bar_3d):
		_setup_bar()
	if not _world_events_connected:
		_connect_world_events()

# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Gibt alle verfügbaren Aktionen zurück. Aufgerufen von Player.get_context_actions().
func get_actions() -> Array[InteractableAction]:
	var actions: Array[InteractableAction] = []

	var action := InteractableAction.new(data.id, data.label)
	action.duration     = data.duration
	action.xp_type      = data.xp_type
	action.xp_amount    = data.xp_amount
	action.drops        = data.drops
	action.loot_table   = data.loot_table
	action.inspect_text = data.inspect_text
	action.on_complete  = _handle_completion
	actions.append(action)

	var inspect_text := data.inspect_text if not data.inspect_text.is_empty() \
		else "%s — nichts Besonderes fällt auf." % data.label
	var inspect := InteractableAction.new(data.id + "_inspect", "Untersuchen")
	inspect.duration    = 0.0
	inspect.xp_type     = "none"
	inspect.xp_amount   = 0
	inspect.inspect_text = inspect_text
	inspect.on_complete  = func():
		if is_instance_valid(_ctx) and _ctx.get_event_bus() != null:
			_ctx.get_event_bus().world().emit_interaction_reward_text(inspect_text)
		else:
			AppLogger.log_warn("get_actions(): kein IEventBus — inspect_text nicht emittiert.", LOG_CAT)
	actions.append(inspect)

	AppLogger.log_debug(
		"get_actions(): '%s' — %d Aktionen." % [data.label, actions.size()], LOG_CAT
	)
	return actions

## Startet die erste verfügbare Aktion via InteractionExecutor.
## Nutzt ctx.get_interaction_executor() — setzt inject_context() voraus.
## In Produktion immer erfüllt (EntityOrchestrator ruft inject_context() immer auf).
## Ohne ctx wird ein klarer Fehler geloggt statt auf Services-Locator zurückzufallen.
func start_default_interaction() -> void:
	if not is_instance_valid(_ctx):
		AppLogger.log_error(
			"start_default_interaction: inject_context() wurde nie aufgerufen — "
			+ "Entity ohne Orchestrator gespawnt? Interaktion abgebrochen.",
			LOG_CAT
		)
		return

	var executor := _ctx.get_interaction_executor()

	if not is_instance_valid(executor):
		AppLogger.log_error("InteractionExecutor-Service fehlt!", LOG_CAT)
		return

	var actions := get_actions()
	if actions.is_empty():
		return
	executor.execute_action(actions[0])

# ─────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────

func _setup_label() -> void:
	_label           = Label3D.new()
	_label.text      = data.label
	_label.position  = Vector3(0.0, 2.5, 0.0)
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.visible   = false
	add_child(_label)

func _setup_bar() -> void:
	# Factory3D über IEntityContext.
	var factory: Factory3D = _ctx.get_factory3d() if is_instance_valid(_ctx) else null
	if is_instance_valid(factory):
		_bar_3d = factory.create_3d_bar(self)
	else:
		AppLogger.log_warn("Factory3D nicht verfügbar — 3D-Fortschrittsbar fehlt.", LOG_CAT)

func _setup_proximity() -> void:
	var detector := ProximityDetector.new(detection_radius)
	add_child(detector)
	detector.player_entered.connect(_on_player_entered)
	detector.player_exited.connect(_on_player_exited)
	AppLogger.log_debug("ProximityDetector erstellt (Radius: %.1fm)." % detection_radius, LOG_CAT)

func _connect_world_events() -> void:
	if not is_instance_valid(_ctx):
		AppLogger.log_error(
			"_connect_world_events: kein _ctx — inject_context() wurde nicht aufgerufen.",
			LOG_CAT
		)
		return
	var bus: IEventBus = _ctx.get_event_bus()
	if bus == null:
		AppLogger.log_error("_connect_world_events: kein IEventBus im Context.", LOG_CAT)
		return
	bus.world().interaction_started.connect(_on_interaction_started)
	bus.world().interaction_finished.connect(_on_interaction_ended)
	bus.world().interaction_cancelled.connect(_on_interaction_ended)
	_world_events_connected = true

# ─────────────────────────────────────────────
# Proximity
# ─────────────────────────────────────────────

## G-02: player-Parameter von ProximityDetector — welcher Spieler nah ist.
func _on_player_entered(_player: Node3D) -> void:
	if is_instance_valid(_label):
		_label.visible = true
	AppLogger.log_info(
		"Spieler in Reichweite: '%s' (%.1fm)." % [data.label, detection_radius], LOG_CAT
	)

## G-02: player-Parameter von ProximityDetector.
func _on_player_exited(_player: Node3D) -> void:
	if is_instance_valid(_label):
		_label.visible = false
	AppLogger.log_info("Spieler außer Reichweite: '%s'." % data.label, LOG_CAT)

# ─────────────────────────────────────────────
# Completion
# ─────────────────────────────────────────────

func _handle_completion() -> void:
	AppLogger.log_info("Interaktion abgeschlossen: '%s'. Entity-Hook aufgerufen." % data.label, LOG_CAT)
	if get_parent().has_method("_on_interacted"):
		interacted.emit(data.id)  # Parent connects to this signal in _ready() — no direct call

# ─────────────────────────────────────────────
# 3D-Bar (World-Events)
# ─────────────────────────────────────────────

func _on_interaction_started(action_id: String, _label: String, duration: float) -> void:
	if action_id != data.id or not is_instance_valid(_bar_3d):
		return
	if not _is_player_target():
		return
	_bar_3d.visible = true
	var t := create_tween()
	t.tween_method(func(v: float): _bar_3d.update(v), 0.0, 1.0, duration)

func _on_interaction_ended(action_id: String, _label: String) -> void:
	if action_id == data.id and is_instance_valid(_bar_3d):
		_bar_3d.visible = false

func _is_player_target() -> bool:
	# G-02: Alle Spieler prüfen — true wenn IRGENDEINER dieser Interactable als Ziel hat.
	# Verhindert dass Spieler 2 das Fortschrittsbalken-Feedback von Spieler 1 sieht
	# (und umgekehrt), wenn beide in Reichweite derselben Interactable sind.
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return true  # Kein Spieler vorhanden — sicherer Default
	var parent: Node = get_parent()
	for player_node in players:
		if not is_instance_valid(player_node):
			continue
		if not player_node.has_method("get_closest_interactable"):
			continue
		var target: Node3D = player_node.get_closest_interactable()
		if not is_instance_valid(target):
			continue
		if parent == target or target.is_ancestor_of(self):
			return true
	return false
