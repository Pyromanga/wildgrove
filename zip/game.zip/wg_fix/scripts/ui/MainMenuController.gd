extends Node
class_name MainMenuController

## MainMenuController — Haupt-/Character-Select- und Netzwerk-Setup-Screen.
##
## Zustände (enum _View):
##   CHARACTERS  — Standard: Character-Liste + [Neues Spiel] + [Multiplayer]-Button.
##   NET_SETUP   — Netzwerk-Panel: [Host starten] / [Beitreten] Optionen.
##   HOST_ACTIVE — Host läuft; Character-Liste wird gezeigt mit "Host aktiv auf Port X"-Hinweis.
##   CONNECTING  — Verbindungsversuch als Client; zeigt Fortschritts-Label.
##
## Flow Solo:
##   Charakter klicken → emit_session_requested(player_id) → GameManager → PLAYING.
##
## Flow Host:
##   [Multiplayer] → NET_SETUP → [Host starten] + Port →
##   emit_host_game_requested(port) → SessionManager.create_server() →
##   EventBus.system.hosting_started → HOST_ACTIVE →
##   Charakter klicken → emit_session_requested(player_id) → PLAYING.
##
## Flow Join (Client):
##   [Multiplayer] → NET_SETUP → [Beitreten] + IP:Port →
##   emit_join_game_requested(ip, port) → SessionManager.join_server() →
##   EventBus.system.joined_as_client → ServiceOrchestrator auto-bootet Session →
##   PLAYING.

const LOG_CAT      := "MainMenuController"
const NEW_CHAR_PREFIX := "charakter"

enum _View { CHARACTERS, NET_SETUP, HOST_ACTIVE, CONNECTING }

var _save_system: SaveSystem = null
var _current_view: _View    = _View.CHARACTERS
var _host_port: int         = 7777

# ─────────────────────────────────────────────
# DI
# ─────────────────────────────────────────────

func inject_save_system(svc: SaveSystem) -> void:
	_save_system = svc

# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────

func _ready() -> void:
	EventBus.system.session_unloaded.connect(_on_session_unloaded)
	EventBus.system.save_slot_deleted.connect(_on_save_deleted)
	EventBus.system.hosting_started.connect(_on_hosting_started)
	EventBus.system.connection_to_server_failed.connect(_on_connection_failed)
	EventBus.system.network_peer_disconnected.connect(_on_network_peer_disconnected)
	_build_static_ui()
	_show_view(_View.CHARACTERS)
	AppLogger.log_info("MainMenuController bereit.", LOG_CAT)

# ─────────────────────────────────────────────
# UI aufbauen (statische Buttons werden einmalig verdrahtet)
# ─────────────────────────────────────────────

func _build_static_ui() -> void:
	# Solo-Bereich
	var new_btn := _get_new_game_button()
	if new_btn:
		new_btn.pressed.connect(_on_new_game_pressed, CONNECT_ONE_SHOT)

	# Multiplayer-Button
	var mp_btn := _get_multiplayer_button()
	if mp_btn:
		mp_btn.pressed.connect(_show_net_setup)

	# Net-Setup-Panel
	var host_btn := _get_start_host_button()
	if host_btn:
		host_btn.pressed.connect(_on_start_host_pressed)

	var join_btn := _get_start_join_button()
	if join_btn:
		join_btn.pressed.connect(_on_start_join_pressed)

	var back_btn := _get_back_button()
	if back_btn:
		back_btn.pressed.connect(_on_back_pressed)

# ─────────────────────────────────────────────
# View-Switching
# ─────────────────────────────────────────────

func _show_view(view: _View) -> void:
	_current_view = view

	var center    := _get_center_container()
	var net_panel := _get_net_panel()

	match view:
		_View.CHARACTERS:
			if center:    center.visible    = true
			if net_panel: net_panel.visible = false
			_refresh_character_list()
			_update_new_game_button()
			_set_status("")

		_View.NET_SETUP:
			if center:    center.visible    = false
			if net_panel: net_panel.visible = true
			_set_status("")

		_View.HOST_ACTIVE:
			if center:    center.visible    = true
			if net_panel: net_panel.visible = false
			_refresh_character_list()
			_update_new_game_button()
			_set_status("Server läuft auf Port %d — wähle einen Charakter." % _host_port)

		_View.CONNECTING:
			if center:    center.visible    = true
			if net_panel: net_panel.visible = false
			_set_status("Verbinde mit Server…")
			_clear_character_list()

func _set_status(text: String) -> void:
	var lbl := _get_status_label()
	if lbl:
		lbl.text   = text
		lbl.visible = not text.is_empty()

# ─────────────────────────────────────────────
# Charakter-Liste
# ─────────────────────────────────────────────

func _refresh_character_list() -> void:
	_clear_character_list()
	if not is_instance_valid(_save_system):
		AppLogger.log_error("SaveSystem nicht injiziert.", LOG_CAT)
		return
	for player_id in _save_system.list_local_saves():
		_add_character_button(player_id)

func _clear_character_list() -> void:
	var list := _get_character_list()
	if list:
		for child in list.get_children():
			child.queue_free()

func _add_character_button(player_id: String) -> void:
	var list := _get_character_list()
	if not list:
		return
	var btn := Button.new()
	btn.text = _format_character_name(player_id)
	btn.pressed.connect(func() -> void: _on_character_selected(player_id))
	list.add_child(btn)

func _update_new_game_button() -> void:
	var btn := _get_new_game_button()
	if not btn:
		return
	if not is_instance_valid(_save_system):
		return
	var saves := _save_system.list_local_saves()
	btn.text = "Neues Spiel" if saves.is_empty() else "Neuer Charakter"
	# Neu verbinden (nach queue_free beim View-Wechsel kann der Button neu sein)
	if not btn.pressed.is_connected(_on_new_game_pressed):
		btn.pressed.connect(_on_new_game_pressed, CONNECT_ONE_SHOT)

func _format_character_name(player_id: String) -> String:
	return player_id.replace("_", " ").capitalize()

# ─────────────────────────────────────────────
# Event-Handler
# ─────────────────────────────────────────────

func _on_character_selected(player_id: String) -> void:
	AppLogger.log_info("Charakter ausgewählt: '%s'." % player_id, LOG_CAT)
	EventBus.system.emit_session_requested(player_id)

func _on_new_game_pressed() -> void:
	var new_id := "%s_%d" % [NEW_CHAR_PREFIX, Time.get_unix_time_from_system()]
	AppLogger.log_info("Neuer Charakter: '%s'." % new_id, LOG_CAT)
	EventBus.system.emit_session_requested(new_id)

func _on_session_unloaded() -> void:
	_show_view(_View.CHARACTERS)

func _on_save_deleted(_player_id: String) -> void:
	if _current_view == _View.CHARACTERS or _current_view == _View.HOST_ACTIVE:
		_refresh_character_list()

# ── Netzwerk-Events ───────────────────────────────────────────────────────────

func _show_net_setup() -> void:
	_show_view(_View.NET_SETUP)

func _on_back_pressed() -> void:
	_show_view(_View.CHARACTERS)

func _on_start_host_pressed() -> void:
	var port_edit := _get_host_port_edit()
	if is_instance_valid(port_edit) and port_edit.text.is_valid_int():
		_host_port = int(port_edit.text)
	AppLogger.log_info("Host angefordert auf Port %d." % _host_port, LOG_CAT)
	EventBus.system.emit_host_game_requested(_host_port)
	# Weiter nach _on_hosting_started via EventBus

func _on_start_join_pressed() -> void:
	var addr_edit := _get_join_address_edit()
	var port_edit := _get_join_port_edit()
	var address   := "127.0.0.1"
	var port      := 7777
	if is_instance_valid(addr_edit) and not addr_edit.text.is_empty():
		address = addr_edit.text
	if is_instance_valid(port_edit) and port_edit.text.is_valid_int():
		port = int(port_edit.text)
	AppLogger.log_info("Join angefordert: %s:%d." % [address, port], LOG_CAT)
	_show_view(_View.CONNECTING)
	EventBus.system.emit_join_game_requested(address, port)
	# Weiter via SessionManager → EventBus.system.joined_as_client → ServiceOrchestrator

func _on_hosting_started(port: int) -> void:
	_host_port = port
	_show_view(_View.HOST_ACTIVE)

func _on_connection_failed() -> void:
	_set_status("Verbindung fehlgeschlagen. Bitte erneut versuchen.")
	_show_view(_View.NET_SETUP)

func _on_network_peer_disconnected() -> void:
	_set_status("Verbindung zum Server verloren.")
	_show_view(_View.CHARACTERS)

# ─────────────────────────────────────────────
# Node-Referenzen
# ─────────────────────────────────────────────

func _get_center_container() -> Node:
	return get_node_or_null("CenterContainer")

func _get_character_list() -> Node:
	return get_node_or_null("CenterContainer/CharacterList")

func _get_new_game_button() -> Button:
	return get_node_or_null("CenterContainer/NewGameButton") as Button

func _get_multiplayer_button() -> Button:
	return get_node_or_null("CenterContainer/MultiplayerButton") as Button

func _get_status_label() -> Label:
	return get_node_or_null("CenterContainer/StatusLabel") as Label

func _get_net_panel() -> Node:
	return get_node_or_null("NetPanel")

func _get_host_port_edit() -> LineEdit:
	return get_node_or_null("NetPanel/HostSection/HostPortEdit") as LineEdit

func _get_start_host_button() -> Button:
	return get_node_or_null("NetPanel/HostSection/StartHostButton") as Button

func _get_join_address_edit() -> LineEdit:
	return get_node_or_null("NetPanel/JoinSection/JoinAddressEdit") as LineEdit

func _get_join_port_edit() -> LineEdit:
	return get_node_or_null("NetPanel/JoinSection/JoinPortEdit") as LineEdit

func _get_start_join_button() -> Button:
	return get_node_or_null("NetPanel/JoinSection/StartJoinButton") as Button

func _get_back_button() -> Button:
	return get_node_or_null("NetPanel/BackButton") as Button
