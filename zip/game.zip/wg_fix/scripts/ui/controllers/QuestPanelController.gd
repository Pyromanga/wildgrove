class_name QuestPanelController
extends Node

var _visuals: QuestPanelVisuals
var _ctx: IUIContext

func setup(visuals: QuestPanelVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx     = ctx
	_ctx.bus().quest().quest_started.connect(_on_quest_started)
	_ctx.bus().quest().quest_completed.connect(_on_quest_completed)
	_ctx.bus().quest().quest_objective_updated.connect(_on_objective_updated)
	_refresh_active_quests()

func _refresh_active_quests() -> void:
	var qs := _ctx.get_quest()
	if not is_instance_valid(qs):
		return
	for quest_id in qs.active_quests:
		_show_quest(quest_id)

func _show_quest(quest_id: String) -> void:
	var qs := _ctx.get_quest()
	if not is_instance_valid(qs):
		return
	if not qs.active_quests.has(quest_id):
		return
	var def: QuestDefinition = qs.get_quest_definition(quest_id)
	_visuals.show_quest(quest_id, def.title if def else quest_id, _build_obj_data(quest_id, def))

func _build_obj_data(quest_id: String, def: QuestDefinition) -> Array[Dictionary]:
	if not def:
		return []
	var qs := _ctx.get_quest()
	var result := []
	for obj in def.objectives:
		result.append({
			"label":    obj.label,
			"current":  qs.get_objective_progress(quest_id, obj.id) if is_instance_valid(qs) else 0,
			"required": obj.required,
		})
	return result

func _on_quest_started(quest_id: String) -> void:
	_show_quest(quest_id)
	# Quest-Panel automatisch einblenden wenn eine neue Quest startet,
	# damit der Spieler das Quest-Log nicht manuell öffnen muss.
	_visuals.panel.visible = true

func _on_quest_completed(quest_id: String, _reward: QuestReward) -> void:
	var qs  := _ctx.get_quest()
	var def := qs.get_quest_definition(quest_id) if is_instance_valid(qs) else null
	_visuals.remove_quest(quest_id)
	_visuals.add_completed(quest_id, def.title if def else quest_id)

func _on_objective_updated(quest_id: String, _obj_id: String, _cur: int, _req: int) -> void:
	_show_quest(quest_id)
