# scripts/ui/controllers/joystick_controller.gd
class_name JoystickController

var _visuals: JoystickVisuals

# Injection: Wir übergeben den Event-Bus explizit
func setup(visuals: JoystickVisuals, event_bus: Object) -> void:
	_visuals = visuals
	event_bus.joystick_toggled.connect(_on_toggled)
	event_bus.joystick_moved.connect(_on_moved)

func _on_toggled(active: bool, origin: Vector2) -> void:
	_visuals.set_visible(active)
	if active:
		# origin ist in Viewport-Koordinaten — in CanvasLayer ist position == Viewport-Position
		_visuals.base.position = origin - (_visuals.base.size / 2)
		# Knob startet in der Mitte der Base
		_visuals.knob.position = origin - (_visuals.knob.size / 2)

func _on_moved(origin: Vector2, offset: Vector2) -> void:
	# Knob-Position: Mitte der Base + Offset, geclampt auf Base-Radius
	var base_center := _visuals.base.position + (_visuals.base.size / 2)
	var max_radius := (_visuals.base.size.x / 2) - (_visuals.knob.size.x / 2)
	var clamped_offset := offset.limit_length(max_radius)
	_visuals.knob.position = base_center + clamped_offset - (_visuals.knob.size / 2)
