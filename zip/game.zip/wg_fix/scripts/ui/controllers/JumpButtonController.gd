class_name JumpButtonController
extends Node

const JUMP_VELOCITY: float = 6.0
const LOG_CAT := "JumpBtn"

var _visuals: JumpButtonVisuals

func setup(visuals: JumpButtonVisuals) -> void:
	_visuals = visuals
	_visuals.connect_pressed(_on_jump_pressed)

func _on_jump_pressed() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: Node = players[0]
	if not is_instance_valid(player):
		return
	# request_jump() setzt nur ein Flag — das wird im nächsten _loop_free()
	# NACH calculate_velocity() angewendet, damit der Impuls nicht sofort durch
	# vel.y=0 (wenn on_floor) überschrieben wird.
	if player.has_method("request_jump"):
		player.request_jump()
	AppLogger.log_debug("Sprung angefordert.", LOG_CAT)
