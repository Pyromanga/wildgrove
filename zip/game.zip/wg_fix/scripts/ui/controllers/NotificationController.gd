# scripts/ui/controllers/notification_controller.gd
class_name NotificationController

var _visuals: NotificationVisuals
var _ctx: IUIContext

func setup(visuals: NotificationVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx = ctx
	_ctx.bus().ui().notification_requested.connect(show)

func show(text: String) -> void:
	_visuals.show_popup(text)
	AppLogger.log_debug("Popup angezeigt: " + text, "UI/Notification")
