class_name SkillPanelController
extends Node

var _visuals: SkillPanelVisuals
var _ctx: IUIContext

func setup(visuals: SkillPanelVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx     = ctx
	_ctx.bus().player().xp_gained.connect(_on_xp_gained)
	_ctx.bus().player().level_up.connect(_on_level_up)
	_refresh_all()

func _refresh_all() -> void:
	var ss := _ctx.get_skill_system()
	if not is_instance_valid(ss):
		return
	for skill_id in ss.get_skill_ids():
		_refresh_skill(skill_id)

func _refresh_skill(skill_id: String) -> void:
	var ss := _ctx.get_skill_system()
	if not is_instance_valid(ss):
		return
	_visuals.update_skill(
		skill_id,
		ss.get_level(skill_id),
		ss.get_xp(skill_id),
		ss.get_xp_to_next_level(skill_id)
	)

func _on_xp_gained(skill_id: String, _amount: int) -> void:
	_refresh_skill(skill_id)

func _on_level_up(skill_id: String, _new_level: int) -> void:
	_refresh_skill(skill_id)
