class_name HUDBuilder

static func build_all(hud: HUD, ctx: IUIContext) -> Dictionary:
	var registry: Dictionary = {}

	registry["interaction"] = InteractionComponent.new().build(hud, ctx.bus().world())
	registry["interaction_button"] = InteractionButtonComponent.new().build(hud, ctx)
	var inv_ctrl := InventoryComponent.new().build(hud, ctx)
	registry["inventory"] = inv_ctrl
	if inv_ctrl is InventoryUIController:
		inv_ctrl.refresh()
	registry["equipment"] = EquipmentComponent.new().build(hud, ctx)
	registry["floating_text"] = FloatingTextComponent.new().build(hud, ctx)
	registry["notification"] = NotificationComponent.new().build(hud, ctx)
	registry["joystick"] = JoystickComponent.new().build(hud, ctx)
	registry["context_button"] = ContextButtonComponent.new().build(hud, ctx)
	registry["context_menu"] = ContextMenuComponent.new().build(hud, ctx)
	registry["pause_menu"] = PauseMenuComponent.new().build(hud, ctx)
	registry["skill_panel"] = SkillPanelComponent.new().build(hud, ctx)
	registry["quest_panel"] = QuestPanelComponent.new().build(hud, ctx)
	registry["player_hp"] = PlayerHPComponent.new().build(hud, ctx)
	registry["jump_button"] = JumpButtonComponent.new().build(hud)

	return registry
