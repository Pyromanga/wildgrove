extends Node
class_name HUDManager

const LOG_CAT := "HUD"

var hud: HUD = null
var controllers: Dictionary = {}

var _ui_context_factory: Callable = func() -> IUIContext:
	push_error("HUDManager: set_ui_context_factory() vor build_all() aufrufen.")
	return null

var _bus: IEventBus = null

func initialize() -> void:
	hud = HUD.new()
	hud.name = "GameHUD"
	hud.visible = false
	hud.add_to_group("hud_canvas")

func set_ui_context_factory(factory: Callable) -> void:
	_ui_context_factory = factory

static func boot(tree: SceneTree, ui_context_factory: Callable = Callable()) -> HUDManager:
	var mgr := HUDManager.new()
	mgr.name = "HUDManager"
	mgr.initialize()
	if ui_context_factory.is_valid():
		mgr.set_ui_context_factory(ui_context_factory)
	tree.root.call_deferred("add_child", mgr)
	return mgr

func _ready() -> void:
	Logger.log_debug("HUDManager._ready() — hänge HUD unter /root ein.", LOG_CAT)
	get_tree().root.call_deferred("add_child", hud)
	var ctx := _ui_context_factory.call()
	if ctx != null:
		_bus = ctx.bus()
	if _bus != null:
		_bus.world().world_scene_ready.connect(_on_world_scene_ready)
		_bus.system().state_changed.connect(_on_state_changed)
	Logger.log_info("HUDManager bereit. HUD wird unter /root eingehängt.", LOG_CAT)

static func register_session_listener(tree: SceneTree) -> void:
	EventBus.system.session_ready.connect(func(): HUDManager.boot(tree), CONNECT_ONE_SHOT)

func _exit_tree() -> void:
	if _bus != null:
		if _bus.world().world_scene_ready.is_connected(_on_world_scene_ready):
			_bus.world().world_scene_ready.disconnect(_on_world_scene_ready)
		if _bus.system().state_changed.is_connected(_on_state_changed):
			_bus.system().state_changed.disconnect(_on_state_changed)
	if is_instance_valid(hud):
		hud.queue_free()
	hud = null
	controllers.clear()

func get_controller(key: String) -> Object:
	return controllers.get(key)

func _on_world_scene_ready(_scene_root: Node) -> void:
	Logger.log_debug("world_scene_ready Signal empfangen — baue HUD-Controller.", LOG_CAT)
	if not is_instance_valid(hud):
		Logger.log_error("_on_world_scene_ready: HUD ist null!", LOG_CAT)
		return

	for child in hud.get_children():
		hud.remove_child(child)
		child.free()
	controllers.clear()

	var notif_old := controllers.get("notification") as NotificationController
	if notif_old and _bus != null and _bus.world().interaction_reward_text.is_connected(notif_old.show):
		_bus.world().interaction_reward_text.disconnect(notif_old.show)

	controllers = HUDBuilder.build_all(hud, _ui_context_factory.call())

	var notif := controllers.get("notification") as NotificationController
	if notif and _bus != null:
		_bus.world().interaction_reward_text.connect(notif.show)

	hud.visible = true
	Logger.log_info("HUD aktiv. %d Controller." % controllers.size(), LOG_CAT)

func _on_state_changed(new_state: int) -> void:
	if not is_instance_valid(hud):
		return
	hud.visible = (new_state == GameEnums.State.PLAYING)
