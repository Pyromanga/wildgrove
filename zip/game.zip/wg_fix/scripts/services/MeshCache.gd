# res://scripts/services/MeshCache.gd
class_name MeshCache extends RefCounted

## MeshCache — Baut alle prozeduralen Meshes einmalig beim Session-Boot.
##
## Kein Service im Container — lebt als Feld in Factory3D.
## Factory3D.build_cache() muss VOR dem ersten Spawn aufgerufen werden.
## ServiceOrchestrator ruft dies in Phase S8.8 auf (nach populate_session,
## vor world_gen und Entity-Spawning).
##
## Caching-Strategie:
##   ArrayMesh-Objekte: direkt geteilt (GPU-Ressource ist immutable nach build())
##   Multi-Node-Objekte (Baum, Kaktus): PackedScene built from code, geklont via instantiate()
##
## Performance-Ziel: 0 CylinderMesh.new() / SphereMesh.new() zur Laufzeit.
## Alle GPU-Uploads passieren einmalig in build().

const LOG_CAT := "MeshCache"

## Einfache Meshes — direkt als ArrayMesh geteilt
var meshes: Dictionary = {}     # { "key": ArrayMesh }

## Komplexe Multi-Node-Objekte — als PackedScene geklont
var scenes: Dictionary = {}     # { "key": PackedScene }

## Material-Cache — StandardMaterial3D ist teuer zu erstellen
var materials: Dictionary = {}  # { color_key: StandardMaterial3D }

var _built: bool = false

func build() -> void:
	if _built:
		return
	var t := Time.get_ticks_msec()

	_build_materials()
	_build_simple_meshes()
	_build_tree_scenes()
	_build_animal_meshes()
	_build_bar_mesh()

	_built = true
	AppLogger.log_info(
		"MeshCache: %d meshes, %d scenes, %d materials in %d ms" % [
			meshes.size(), scenes.size(), materials.size(),
			Time.get_ticks_msec() - t
		],
		LOG_CAT
	)

func is_built() -> bool:
	return _built

## Gibt ein gecachtes oder neu erstelltes Material zurück.
## resource_local_to_scene = false → GPU-seitig geteilt, kein erneutes Upload.
func get_material(color: Color, unshaded: bool = false) -> StandardMaterial3D:
	var key := "%s_%s" % [color.to_html(), str(unshaded)]
	if not materials.has(key):
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		if unshaded:
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.resource_local_to_scene = false  # GPU-seitig teilen
		materials[key] = mat
	return materials[key]

func get_mesh(key: String) -> ArrayMesh:
	return meshes.get(key)

## Instanziiert eine komplexe Szene (Baum, Kaktus, Farn etc.).
## Gibt Node3D.new() zurück wenn der Key nicht existiert — nie null.
func instantiate_scene(key: String) -> Node3D:
	var scene: PackedScene = scenes.get(key)
	if scene == null:
		AppLogger.log_error("MeshCache: Szene '%s' nicht gefunden." % key, LOG_CAT)
		return Node3D.new()
	return scene.instantiate() as Node3D

# ─────────────────────────────────────────────────────────────────────────────
# Build-Methoden (einmalig beim Session-Boot)
# ─────────────────────────────────────────────────────────────────────────────

func _build_materials() -> void:
	# Alle Biom-/Objekt-Farben vorab bauen
	var presets := {
		"trunk_oak":      Color(0.4,  0.25, 0.10),
		"trunk_pine":     Color(0.35, 0.20, 0.08),
		"leaves_oak":     Color(0.15, 0.50, 0.10),
		"leaves_pine":    Color(0.10, 0.40, 0.08),
		"leaves_snow":    Color(0.95, 0.97, 1.00),
		"rock_forest":    Color(0.45, 0.40, 0.35),
		"rock_desert":    Color(0.75, 0.60, 0.35),
		"cactus":         Color(0.20, 0.55, 0.15),
		"fern":           Color(0.20, 0.60, 0.15),
		"mushroom_red":   Color(0.85, 0.10, 0.10),
		"mushroom_brown": Color(0.50, 0.30, 0.10),
		"bar_hp":         Color(0.10, 0.85, 0.10),
		"bar_bg":         Color(0.15, 0.15, 0.15, 0.80),
		"fallen_log":     Color(0.35, 0.22, 0.09),
		"animal_body":    Color(0.60, 0.50, 0.35),
		"animal_head":    Color(0.55, 0.45, 0.30),
	}
	for key in presets:
		get_material(presets[key])

func _build_simple_meshes() -> void:
	# Zylinder-Varianten für Baumstämme
	for r_pair in [["trunk_sm", 0.12, 0.18], ["trunk_md", 0.15, 0.22], ["trunk_lg", 0.18, 0.28]]:
		var m := CylinderMesh.new()
		m.top_radius    = r_pair[1]
		m.bottom_radius = r_pair[2]
		m.height        = 2.0
		meshes[r_pair[0]] = _to_array_mesh(m)

	# Kugeln für Baumkronen
	for s_pair in [["crown_sm", 0.8], ["crown_md", 1.1], ["crown_lg", 1.4]]:
		var m := SphereMesh.new()
		m.radius = s_pair[1]
		m.height = s_pair[1] * 2.0
		meshes[s_pair[0]] = _to_array_mesh(m)

	# Kegel für Tanne (CylinderMesh mit top_radius = 0)
	for c_pair in [["pine_cone_0", 1.2, 0.8], ["pine_cone_1", 1.0, 0.65], ["pine_cone_2", 0.75, 0.5]]:
		var m := CylinderMesh.new()
		m.top_radius    = 0.0
		m.bottom_radius = c_pair[1]
		m.height        = c_pair[2]
		meshes[c_pair[0]] = _to_array_mesh(m)

	# Kaktus-Stamm und -Arme
	var kaktus_stamm := CylinderMesh.new()
	kaktus_stamm.top_radius    = 0.18
	kaktus_stamm.bottom_radius = 0.20
	kaktus_stamm.height        = 1.6
	meshes["cactus_trunk"] = _to_array_mesh(kaktus_stamm)

	var kaktus_arm := CylinderMesh.new()
	kaktus_arm.top_radius    = 0.10
	kaktus_arm.bottom_radius = 0.12
	kaktus_arm.height        = 0.6
	meshes["cactus_arm"] = _to_array_mesh(kaktus_arm)

	# Farn-Blatt (abgeflachte Kugel)
	var fern_leaf := SphereMesh.new()
	fern_leaf.radius = 0.4
	fern_leaf.height = 0.15
	meshes["fern_leaf"] = _to_array_mesh(fern_leaf)

	# Gefällter Baumstamm (liegender Zylinder — Rotation beim Instanziieren)
	var log := CylinderMesh.new()
	log.top_radius    = 0.22
	log.bottom_radius = 0.25
	log.height        = 2.4
	meshes["fallen_log"] = _to_array_mesh(log)

func _build_tree_scenes() -> void:
	scenes["tree_oak"]          = _build_scene_oak()
	scenes["tree_pine"]         = _build_scene_pine(false)
	scenes["tree_pine_snow"]    = _build_scene_pine(true)
	scenes["tree_fallen_forest"] = _build_scene_fallen("forest")
	scenes["tree_fallen_desert"] = _build_scene_fallen("desert")
	scenes["cactus"]            = _build_scene_cactus()
	scenes["fern"]              = _build_scene_fern()

func _build_animal_meshes() -> void:
	for a in [["animal_body_sm", Vector3(0.3, 0.5, 0.3)],
			  ["animal_body_md", Vector3(0.5, 0.7, 0.5)],
			  ["animal_body_lg", Vector3(0.6, 0.8, 0.6)]]:
		var m := BoxMesh.new()
		m.size = a[1]
		meshes[a[0]] = _to_array_mesh(m)

	# Tier-Kopf (kleinere Box)
	var head := BoxMesh.new()
	head.size = Vector3(0.28, 0.28, 0.28)
	meshes["animal_head"] = _to_array_mesh(head)

func _build_bar_mesh() -> void:
	# HP-Bar Hintergrund + Füllung (zwei schmale Quads)
	var bg := QuadMesh.new()
	bg.size = Vector2(1.2, 0.20)
	meshes["bar_bg"] = _to_array_mesh(bg)
	var fg := QuadMesh.new()
	fg.size = Vector2(1.1, 0.15)
	meshes["bar_fg"] = _to_array_mesh(fg)

# ─────────────────────────────────────────────────────────────────────────────
# Szenen-Builder (erstellen Node-Hierarchie, verpacken als PackedScene)
# ─────────────────────────────────────────────────────────────────────────────

func _build_scene_oak() -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Oak"

	# Stamm
	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_md"]
	trunk.set_surface_override_material(0, get_material(Color(0.4, 0.25, 0.10)))
	trunk.position = Vector3(0.0, 1.0, 0.0)
	root.add_child(trunk)

	# Krone (Hauptkugel)
	var crown := MeshInstance3D.new()
	crown.mesh = meshes["crown_md"]
	crown.set_surface_override_material(0, get_material(Color(0.15, 0.50, 0.10)))
	crown.position = Vector3(0.0, 2.4, 0.0)
	root.add_child(crown)

	# Zweite, kleinere Krone versetzt
	var crown2 := MeshInstance3D.new()
	crown2.mesh = meshes["crown_sm"]
	crown2.set_surface_override_material(0, get_material(Color(0.12, 0.45, 0.08)))
	crown2.position = Vector3(0.3, 2.8, 0.2)
	root.add_child(crown2)

	return _pack_scene(root)

func _build_scene_pine(snow: bool) -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Pine" + ("_Snow" if snow else "")

	# Stamm
	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_sm"]
	trunk.set_surface_override_material(0, get_material(Color(0.35, 0.20, 0.08)))
	trunk.position = Vector3(0.0, 1.0, 0.0)
	root.add_child(trunk)

	# Drei Kegel-Ebenen von unten nach oben
	var cone_offsets: Array = [[0, 0.6], [1, 1.1], [2, 1.55]]
	var leaf_color := get_material(Color(0.10, 0.40, 0.08) if not snow else Color(0.95, 0.97, 1.0))

	for pair in cone_offsets:
		var cone := MeshInstance3D.new()
		cone.mesh = meshes["pine_cone_%d" % pair[0]]
		cone.set_surface_override_material(0, leaf_color)
		cone.position = Vector3(0.0, pair[1], 0.0)
		root.add_child(cone)

	return _pack_scene(root)

func _build_scene_fallen(biome: String) -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Fallen_%s" % biome.capitalize()

	var log := MeshInstance3D.new()
	log.mesh = meshes["fallen_log"]
	log.set_surface_override_material(0, get_material(Color(0.35, 0.22, 0.09)))
	# Liegend: 90° um Z-Achse kippen
	log.rotation_degrees = Vector3(0.0, 0.0, 90.0)
	root.add_child(log)

	return _pack_scene(root)

func _build_scene_cactus() -> PackedScene:
	var root := Node3D.new()
	root.name = "Cactus"

	var mat := get_material(Color(0.20, 0.55, 0.15))

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["cactus_trunk"]
	trunk.set_surface_override_material(0, mat)
	trunk.position = Vector3(0.0, 0.8, 0.0)
	root.add_child(trunk)

	# Linker Arm
	var arm_l := MeshInstance3D.new()
	arm_l.mesh = meshes["cactus_arm"]
	arm_l.set_surface_override_material(0, mat)
	arm_l.rotation_degrees = Vector3(0.0, 0.0, 90.0)
	arm_l.position = Vector3(-0.38, 1.0, 0.0)
	root.add_child(arm_l)

	# Rechter Arm
	var arm_r := MeshInstance3D.new()
	arm_r.mesh = meshes["cactus_arm"]
	arm_r.set_surface_override_material(0, mat)
	arm_r.rotation_degrees = Vector3(0.0, 0.0, -90.0)
	arm_r.position = Vector3(0.38, 0.85, 0.0)
	root.add_child(arm_r)

	return _pack_scene(root)

func _build_scene_fern() -> PackedScene:
	var root := Node3D.new()
	root.name = "Fern"

	var mat := get_material(Color(0.20, 0.60, 0.15))

	# 4 Blätter radial angeordnet
	var leaf_positions: Array = [
		[Vector3( 0.3, 0.1,  0.0), Vector3(-30.0, 0.0, 0.0)],
		[Vector3(-0.3, 0.1,  0.0), Vector3(-30.0, 180.0, 0.0)],
		[Vector3( 0.0, 0.1,  0.3), Vector3(-30.0, 90.0, 0.0)],
		[Vector3( 0.0, 0.1, -0.3), Vector3(-30.0, -90.0, 0.0)],
	]
	for lp in leaf_positions:
		var leaf := MeshInstance3D.new()
		leaf.mesh = meshes["fern_leaf"]
		leaf.set_surface_override_material(0, mat)
		leaf.position = lp[0]
		leaf.rotation_degrees = lp[1]
		root.add_child(leaf)

	return _pack_scene(root)

# ─────────────────────────────────────────────────────────────────────────────
# Hilfsmethoden
# ─────────────────────────────────────────────────────────────────────────────

## Konvertiert PrimitiveMesh → ArrayMesh (unveränderlich, GPU-seitig cachbar).
static func _to_array_mesh(primitive: PrimitiveMesh) -> ArrayMesh:
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, primitive.get_mesh_arrays())
	return am

## Verpackt eine Node-Hierarchie als PackedScene.
## Die root-Node muss bereits alle Kinder haben.
static func _pack_scene(root: Node) -> PackedScene:
	var scene := PackedScene.new()
	scene.pack(root)
	root.free()  # Temp-Node freigeben — PackedScene hat den State geklont
	return scene
