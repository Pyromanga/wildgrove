extends ServiceNode
# justified: on_ready() verbindet multiplayer.*-Signale (Node-Lifecycle erforderlich); hostet
# ENetMultiplayerPeer für die gesamte App-Laufzeit (überdauert Session-Wechsel — ADR-010).
class_name SessionManager

## SessionManager — Globaler Service für den Multiplayer-Peer-Lifecycle und Player-Slot-Registry.
##
## Verantwortlichkeiten:
##   - ENetMultiplayerPeer aufbauen (Host) oder verbinden (Client) vor dem Session-Boot.
##   - Player-Slot-Registry: peer_id (int) → player_id (String).
##   - Signale emittieren wenn Peers joinen / verlassen.
##   - NetworkBridge und die Session-Services sehen denselben multiplayer.multiplayer_peer —
##     kein separater Peer-State nötig.
##
## Drei-Tier-Modell (ADR-010):
##   Tier 1 — Solo:         Kein Peer gesetzt. has_active_peer() = false.
##   Tier 2 — Hosted Coop:  create_server() → Host ist Spieler und Autorität.
##   Tier 3 — Ded. Server:  create_server() auf Headless-Instanz; Host spielt nicht.
##
## Für Join-Flow: ServiceOrchestrator verbindet sich in _ready() auf client_connected_to_server
## und bootet automatisch eine Session für den Client.
##
## SessionManager nutzt IEventBus via DI (deps.require()) — kein AutoLoad mehr.
## Der frühere Dep-Loop ("event_bus kommt erst in Phase 3.5") existierte nur unter
## der alten Zwei-Registry-Architektur. Nach dem Three-Scope-Refactor läuft
## SessionManager als regulärer App-Service durch boot_app() — EVENT_BUS ist als
## Resource bereits in Phase 3.5 registriert, bevor configure() (Phase 4) läuft.
##
## G-03 Reconnect/Timeout:
##   join_server() startet einen JOIN_TIMEOUT_SEC-Sekunden-Timer. Läuft er ab ohne Verbindung,
##   wird client_connection_failed emittiert und der Peer bereinigt. Das verhindert hängende
##   Verbindungsversuche ohne UI-Feedback.
##   join_server() unterstützt konfigurierbares Retry-Budget: max. MAX_RETRIES Versuche mit
##   exponentiell wachsender Wartezeit (RETRY_BASE_DELAY_SEC * 2^n).
##   _on_peer_disconnected() emittiert peer_cleanup_requested(peer_id) damit Services
##   Spieler-Buckets sichern und Chunk-Tracking bereinigen können.

const LOG_CAT       := "SessionManager"
const DEFAULT_PORT  := 7777
const MAX_CLIENTS   := 8

## G-03: Verbindungs-Timeout in Sekunden. ENet läuft ohne Obergrenze — dieser Timer
## beendet einen hängenden Verbindungsversuch sauber.
const JOIN_TIMEOUT_SEC   := 10.0
## G-03: Maximale Anzahl automatischer Retry-Versuche nach Connection-Failure.
## 0 = kein Auto-Retry (der Spieler muss manuell erneut versuchen).
const MAX_RETRIES        := 3
## G-03: Basis-Wartezeit zwischen Retries in Sekunden. Wird exponentiell verdoppelt.
const RETRY_BASE_DELAY_SEC := 1.0

## Emittiert wenn ein Client-Peer verbunden und im Slot-Register eingetragen wurde (nur auf Server).
signal peer_joined(peer_id: int, player_id: String)
## Emittiert wenn ein Peer getrennt und aus dem Slot-Register entfernt wurde.
signal peer_left(peer_id: int)
## G-03: Emittiert wenn Services Ressourcen für peer_id bereinigen sollen (Buckets sichern etc.).
signal peer_cleanup_requested(peer_id: int)
## Emittiert wenn der lokale Server erfolgreich gestartet wurde.
signal server_started(port: int)
## Emittiert wenn dieser Client erfolgreich mit dem Server verbunden wurde.
signal client_connected_to_server()
## Emittiert wenn der Verbindungsversuch als Client gescheitert ist.
signal client_connection_failed()
## Emittiert wenn die Verbindung zum Server verloren gegangen ist.
signal server_connection_lost()
## G-03: Emittiert wenn ein Retry-Versuch gestartet wird. UI kann Fortschritt anzeigen.
signal retry_attempt(attempt: int, max_attempts: int)

## peer_id (int) → player_id (String). Wird vom Server befüllt.
var _peer_slots: Dictionary = {}

## G-03: Retry-State
var _join_address:    String = ""
var _join_port:       int    = DEFAULT_PORT
var _retry_count:     int    = 0
var _join_timer:      SceneTreeTimer = null  # Timeout-Timer für laufenden Join-Versuch
var _bus: IEventBus = null

# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	_bus = deps.require(ServiceKeys.EVENT_BUS) as IEventBus
	Logger.log_info("SessionManager konfiguriert mit IEventBus.", LOG_CAT)

func on_ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	_bus.system().host_game_requested.connect(_on_host_game_requested)
	_bus.system().join_game_requested.connect(_on_join_game_requested)
	Logger.log_info("SessionManager bereit. Tier: %s" % _tier_name(), LOG_CAT)

func on_cleanup() -> void:
	_cancel_join_timer()
	_disconnect_multiplayer_signals()
	_disconnect_bus_signals()
	close()
	Logger.log_info("SessionManager cleanup.", LOG_CAT)

# ─────────────────────────────────────────────
# Host / Join API
# ─────────────────────────────────────────────

## Startet einen ENet-Host auf dem angegebenen Port.
## Tier 2 (Hosted Coop) oder Tier 3 (Dedicated Server).
## Gibt true zurück wenn erfolgreich.
func create_server(port: int = DEFAULT_PORT, max_clients: int = MAX_CLIENTS) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, max_clients)
	if err != OK:
		Logger.log_error(
			"create_server(%d) fehlgeschlagen: %s" % [port, error_string(err)], LOG_CAT
		)
		return false
	multiplayer.multiplayer_peer = peer
	Logger.log_info(
		"Server gestartet auf Port %d (max. %d Clients)." % [port, max_clients], LOG_CAT
	)
	_bus.system().emit_hosting_started(port)
	server_started.emit(port)
	return true

## Verbindet als Client mit einem Host.
## Gibt true zurück wenn die Verbindung EINGELEITET wurde (noch nicht hergestellt).
## G-03: Startet einen JOIN_TIMEOUT_SEC-Sekunden-Timer. Läuft er ab, wird die Verbindung
## abgebrochen und client_connection_failed emittiert.
## Auf Erfolg: client_connected_to_server Signal + _bus.system().emit_joined_as_client().
func join_server(address: String, port: int = DEFAULT_PORT) -> bool:
	if address.is_empty():
		Logger.log_error("join_server(): leere Adresse — Verbindung abgelehnt.", LOG_CAT)
		return false

	_join_address = address
	_join_port    = port

	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(address, port)
	if err != OK:
		Logger.log_error(
			"join_server(%s:%d) fehlgeschlagen: %s" % [address, port, error_string(err)], LOG_CAT
		)
		return false
	multiplayer.multiplayer_peer = peer

	# G-03: Timeout-Timer starten — verhindert hängenden Verbindungsversuch.
	_start_join_timer()

	Logger.log_info("Verbindung zu %s:%d eingeleitet (Timeout: %.0fs)." % [address, port, JOIN_TIMEOUT_SEC], LOG_CAT)
	return true

## Trennt Peer und kehrt zu Tier 1 (Solo) zurück.
func close() -> void:
	_cancel_join_timer()
	if _has_active_peer():
		multiplayer.multiplayer_peer = null
		Logger.log_info("Multiplayer-Peer geschlossen — zurück zu Tier 1 (Solo).", LOG_CAT)
	_peer_slots.clear()
	_retry_count = 0

# ─────────────────────────────────────────────
# Player-Slot-Registry
# ─────────────────────────────────────────────

## Registriert peer_id ↔ player_id. Wird von BootPipeline.boot_session() für den lokalen
## Spieler aufgerufen (Phase S8.7) und von _on_peer_connected() für Remote-Clients.
func register_player_slot(peer_id: int, player_id: String) -> void:
	_peer_slots[peer_id] = player_id
	Logger.log_debug(
		"Slot registriert: peer=%d → player='%s'" % [peer_id, player_id], LOG_CAT
	)

## Gibt die player_id für eine peer_id zurück. Leer wenn kein Slot bekannt.
func get_player_id_for_peer(peer_id: int) -> String:
	return _peer_slots.get(peer_id, "")

## Gibt eine Kopie aller bekannten Slots zurück.
func get_all_slots() -> Dictionary:
	return _peer_slots.duplicate()

# ─────────────────────────────────────────────
# Status-Helfer
# ─────────────────────────────────────────────

## true wenn ein echter ENet-Peer gesetzt ist (Tier 2 oder 3).
func has_active_peer() -> bool:
	return _has_active_peer()

## true wenn dieser Prozess Autorität ist (Solo oder Host).
func is_server() -> bool:
	return not _has_active_peer() or multiplayer.is_server()

## Lokale peer_id. Ohne Peer immer 1.
func get_local_peer_id() -> int:
	return multiplayer.get_unique_id() if _has_active_peer() else 1

# ─────────────────────────────────────────────
# Multiplayer-Signal-Handler
# ─────────────────────────────────────────────

func _on_peer_connected(peer_id: int) -> void:
	if not multiplayer.is_server():
		# Clients bekommen peer_connected wenn der Server ihnen andere Clients bekannt gibt.
		# Wir führen hier keine eigene Slot-Registry auf Client-Seite.
		Logger.log_debug("Client: peer %d bekannt gegeben." % peer_id, LOG_CAT)
		return
	var player_id := "peer_%d" % peer_id
	register_player_slot(peer_id, player_id)
	Logger.log_info("Peer %d verbunden → '%s'." % [peer_id, player_id], LOG_CAT)
	peer_joined.emit(peer_id, player_id)

func _on_peer_disconnected(peer_id: int) -> void:
	_peer_slots.erase(peer_id)
	Logger.log_info("Peer %d getrennt." % peer_id, LOG_CAT)
	# G-03: Services informieren dass Ressourcen für diesen Peer bereinigt werden sollen.
	# InventorySystem/QuestService/SkillSystem können Spieler-Buckets sichern;
	# WorldService/ChunkManager entfernen den Spieler aus dem Tracking.
	peer_cleanup_requested.emit(peer_id)
	peer_left.emit(peer_id)

func _on_connected_to_server() -> void:
	# G-03: Verbindung hergestellt — Timer und Retry-Zähler zurücksetzen.
	_cancel_join_timer()
	_retry_count = 0
	var local_id := multiplayer.get_unique_id()
	Logger.log_info("Mit Server verbunden. Lokale peer_id: %d" % local_id, LOG_CAT)
	_bus.system().emit_joined_as_client()
	client_connected_to_server.emit()

func _on_connection_failed() -> void:
	_cancel_join_timer()
	Logger.log_error("Verbindung zum Server fehlgeschlagen (Versuch %d/%d)." % [_retry_count + 1, MAX_RETRIES + 1], LOG_CAT)
	# Fehlgeschlagenen Peer bereinigen.
	if _has_active_peer():
		multiplayer.multiplayer_peer = null

	if _retry_count < MAX_RETRIES and not _join_address.is_empty():
		_retry_count += 1
		var delay := RETRY_BASE_DELAY_SEC * pow(2.0, _retry_count - 1)
		Logger.log_info(
			"Retry %d/%d in %.1f Sekunden..." % [_retry_count, MAX_RETRIES, delay], LOG_CAT
		)
		retry_attempt.emit(_retry_count, MAX_RETRIES)
		get_tree().create_timer(delay).timeout.connect(
			func() -> void: join_server(_join_address, _join_port),
			CONNECT_ONE_SHOT
		)
	else:
		_retry_count = 0
		_bus.system().emit_connection_to_server_failed()
		client_connection_failed.emit()

func _on_server_disconnected() -> void:
	Logger.log_warn("Server-Verbindung verloren.", LOG_CAT)
	close()
	_bus.system().emit_network_peer_disconnected()
	server_connection_lost.emit()

# ─────────────────────────────────────────────
# G-03: Join-Timeout-Helpers
# ─────────────────────────────────────────────

func _start_join_timer() -> void:
	_cancel_join_timer()
	_join_timer = get_tree().create_timer(JOIN_TIMEOUT_SEC)
	_join_timer.timeout.connect(_on_join_timeout, CONNECT_ONE_SHOT)

func _cancel_join_timer() -> void:
	if is_instance_valid(_join_timer):
		if _join_timer.timeout.is_connected(_on_join_timeout):
			_join_timer.timeout.disconnect(_on_join_timeout)
	_join_timer = null

func _on_join_timeout() -> void:
	_join_timer = null
	if not _has_active_peer():
		return  # Verbindung wurde inzwischen hergestellt oder bereits abgebrochen.
	Logger.log_warn(
		"Verbindungs-Timeout nach %.0f Sekunden — Peer wird bereinigt." % JOIN_TIMEOUT_SEC,
		LOG_CAT
	)
	multiplayer.multiplayer_peer = null
	_bus.system().emit_connection_to_server_failed()
	client_connection_failed.emit()

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _has_active_peer() -> bool:
	if not is_instance_valid(multiplayer):
		return false
	if not multiplayer.has_multiplayer_peer():
		return false
	var peer := multiplayer.multiplayer_peer
	return is_instance_valid(peer) and peer.get_class() != "OfflineMultiplayerPeer"

func _tier_name() -> String:
	if not _has_active_peer():
		return "Tier 1 (Solo)"
	if multiplayer.is_server():
		return "Tier 2/3 (Host/Server)"
	return "Tier 2/3 (Client)"

func _disconnect_multiplayer_signals() -> void:
	if multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.disconnect(_on_peer_connected)
	if multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.disconnect(_on_peer_disconnected)
	if multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.disconnect(_on_connected_to_server)
	if multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.disconnect(_on_connection_failed)
	if multiplayer.server_disconnected.is_connected(_on_server_disconnected):
		multiplayer.server_disconnected.disconnect(_on_server_disconnected)

func _disconnect_bus_signals() -> void:
	if _bus.system().host_game_requested.is_connected(_on_host_game_requested):
		_bus.system().host_game_requested.disconnect(_on_host_game_requested)
	if _bus.system().join_game_requested.is_connected(_on_join_game_requested):
		_bus.system().join_game_requested.disconnect(_on_join_game_requested)

func _on_host_game_requested(port: int) -> void:
	create_server(port)

func _on_join_game_requested(address: String, port: int) -> void:
	join_server(address, port)
