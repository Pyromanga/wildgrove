extends Service
class_name InventorySystem
## implements ISaveProvider

## InventorySystem — Verwaltet das Spieler-Inventar.
## Abhängigkeiten (deps): ["data", "savesystem", "network_bridge"]
##
## sind jetzt per peer_id verschachtelt. Öffentliche Methoden bekommen player_id: int = 1
## als Default-Parameter — bestehende Aufrufer ohne player_id verhalten sich identisch.
##

signal inventory_changed(player_id: int, items: Array[Dictionary])

const LOG_CAT := "Inventory"
const SAVE_KEY := "inventory"

## Multi-Tenant State: { peer_id: { "items": {item_id: qty}, "weight": float,
##                                   "max_slots": int, "max_weight": float } }
var _players: Dictionary = {}

var _item_registry: Dictionary = {}   # { "item_id": ItemDefinition } — von DataService

var _save_system: SaveSystem
var _network:     NetworkBridge = null
var _bus:         IEventBus     = null

# ─────────────────────────────────────────────
# Interner Helpers: Player-Bucket erstellen / abrufen
# ─────────────────────────────────────────────

func _ensure_player(player_id: int) -> Dictionary:
	if not _players.has(player_id):
		_players[player_id] = {
			"items":      {},
			"weight":     0.0,
			"max_slots":  28,
			"max_weight": 50.0,
		}
	return _players[player_id]

# ─────────────────────────────────────────────
# Phase 4: Configure (DI)
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	var t := Logger.log_begin("InventorySystem.configure()", LOG_CAT)

	var data_service := deps.get_optional(ServiceKeys.DATA) as DataService
	if is_instance_valid(data_service):
		_item_registry = data_service.get_all_items()
		Logger.log_debug("Item-Registry von DataService: %d Items." % _item_registry.size(), LOG_CAT)
	else:
		Logger.log_error("DataService fehlt — Item-Registry leer!" , LOG_CAT)

	_save_system = deps.get_optional(ServiceKeys.SAVE_SYSTEM) as SaveSystem
	_network     = deps.get_optional(ServiceKeys.NETWORK_BRIDGE) as NetworkBridge
	_bus          = deps.require(ServiceKeys.EVENT_BUS)            as IEventBus
	if _save_system:
		_save_system.register_save_provider(self)
		var saved: Variant = _save_system.get_state_for(SAVE_KEY)
		if saved is Dictionary and not (saved as Dictionary).is_empty():
			_restore_from_save(saved)
	else:
		Logger.log_error("Abhängigkeit 'savesystem' fehlt!", LOG_CAT)

	# Slots/Gewicht aus PlayerData für den lokalen Spieler (peer_id=1) laden
	var player_data: PlayerData = data_service.get_player_data() if is_instance_valid(data_service) and data_service.has_method("get_player_data") else null
	if is_instance_valid(player_data):
		var bucket := _ensure_player(1)
		if player_data.get("max_inventory_slots") != null:
			bucket["max_slots"] = player_data.max_inventory_slots
		if player_data.get("max_carry_weight") != null:
			bucket["max_weight"] = player_data.max_carry_weight
		Logger.log_debug("Spieler 1 — Slots: %d, Max-Gewicht: %.1f kg." % [bucket["max_slots"], bucket["max_weight"]], LOG_CAT)

	Logger.log_end("InventorySystem.configure()", t, LOG_CAT)
	Logger.log_info(
		"Initialisiert. %d Items in DB." % _item_registry.size(),
		LOG_CAT
	)

# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────

## Phase S8.6 Late-Inject — NetworkBridge wird nach vollem Session-Boot injiziert
## um den zirkulären Dep (NetworkBridge ↔ Services) aufzulösen.
func inject_network_bridge(network: NetworkBridge) -> void:
	_network = network

func on_ready() -> void:
	inventory_changed.emit(1, get_all_items(1))
	# Benannte Methode statt Lambda — symmetrisches disconnect() in on_cleanup().
	_bus.world().loot_collected.connect(_on_loot_collected)

func on_cleanup() -> void:
	if _bus.world().loot_collected.is_connected(_on_loot_collected):
		_bus.world().loot_collected.disconnect(_on_loot_collected)
	Logger.log_info("InventorySystem cleanup.", LOG_CAT)

func _on_loot_collected(item_id: String, qty: int) -> void:
	request_add_item(item_id, qty)

# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func get_save_key() -> String:
	return SAVE_KEY

func get_save_data() -> Dictionary:
	# Serialisiere alle Player-Buckets kompakt: { peer_id: {item_id: qty} }
	var out: Dictionary = {}
	for pid in _players:
		out[str(pid)] = (_players[pid] as Dictionary)["items"].duplicate()
	return out

# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Fügt ein Item für player_id hinzu. Default player_id=1 → Tier 1 (Solo) unverändert.
## Tier 2/3: NetworkBridge ruft on_item_add_confirmed() direkt auf — request_add_item()
## schickt dann ein RPC (Phase 4). Für Tier 1 bleibt der direkte Aufruf schnellster Pfad.
func request_add_item(item_id: String, quantity: int = 1, player_id: int = 1) -> bool:
	var def := get_item_info(item_id)
	if not def:
		Logger.log_error("Item-ID '%s' unbekannt." % item_id, LOG_CAT)
		return false

	var bucket := _ensure_player(player_id)
	var items: Dictionary = bucket["items"]
	var max_slots: int    = bucket["max_slots"]
	var max_weight: float = bucket["max_weight"]
	var cur_weight: float = bucket["weight"]

	if not items.has(item_id) and items.size() >= max_slots:
		Logger.log_warn(
			"Inventar voll (%d/%d Slots, Spieler %d) — '%s' abgelehnt." % [items.size(), max_slots, player_id, item_id],
			LOG_CAT
		)
		return false

	if max_weight > 0.0:
		var item_weight: float = def.get("weight") if def.get("weight") != null else 0.0
		if cur_weight + item_weight * quantity > max_weight:
			Logger.log_warn(
				"Gewichtslimit (%.1f/%.1f kg, Spieler %d) — '%s' abgelehnt." % [cur_weight, max_weight, player_id, item_id],
				LOG_CAT
			)
			return false

	# Tier 1: direkter Aufruf. Tier 2/3: via NetworkBridge an die Autorität senden.
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		_network.rpc_id(1, "_rpc_add_item", item_id, quantity)
	else:
		on_item_add_confirmed(item_id, quantity, player_id)
	return true

## Authority-Mutation: schreibt State für player_id. Wird von request_add_item() (Tier 1)
## und NetworkBridge._rpc_add_item() (Tier 2/3) aufgerufen.
## C-02: Guard stellt sicher dass nur die Autorität State mutiert — auch bei Direktaufruf
## ohne NetworkBridge (z.B. serverseitiger Code, Cheats, Admin-Tools).
func on_item_add_confirmed(item_id: String, quantity: int, player_id: int = 1) -> void:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		Logger.log_error(
			"on_item_add_confirmed: Aufruf auf Nicht-Autorität (peer %d) — verweigert." % _network.get_local_peer_id(),
			LOG_CAT
		)
		return
	var def := get_item_info(item_id)
	if not def:
		return

	var bucket := _ensure_player(player_id)
	var items: Dictionary = bucket["items"]

	var current: int = items.get(item_id, 0)
	var new_qty: int = min(current + quantity, def.max_stack)
	var actual_added: int = new_qty - current

	items[item_id] = new_qty

	var item_weight: float = def.get("weight") if def.get("weight") != null else 0.0
	bucket["weight"] = (bucket["weight"] as float) + item_weight * actual_added

	inventory_changed.emit(player_id, get_all_items(player_id))
	Logger.log_debug(
		"Item hinzugefügt: '%s' x%d für Spieler %d. Gewicht: %.1f/%.1f kg, Slots: %d/%d."
		% [item_id, actual_added, player_id,
		   bucket["weight"], bucket["max_weight"],
		   items.size(),     bucket["max_slots"]],
		LOG_CAT
	)

func remove_item(item_id: String, quantity: int = 1, player_id: int = 1) -> bool:
	var bucket := _ensure_player(player_id)
	var items: Dictionary = bucket["items"]
	var current: int = items.get(item_id, 0)
	if current < quantity:
		Logger.log_warn("Zu wenig '%s' (Spieler %d, Besitz: %d)." % [item_id, player_id, current], LOG_CAT)
		return false

	items[item_id] = current - quantity
	if items[item_id] <= 0:
		items.erase(item_id)

	var def: ItemDefinition = _item_registry.get(item_id)
	var item_weight: float = def.get("weight") if def and def.get("weight") != null else 0.0
	bucket["weight"] = max(0.0, (bucket["weight"] as float) - item_weight * quantity)

	inventory_changed.emit(player_id, get_all_items(player_id))
	return true

func has_item(item_id: String, quantity: int = 1, player_id: int = 1) -> bool:
	return (_players.get(player_id, {}) as Dictionary).get("items", {}).get(item_id, 0) >= quantity

func get_all_items(player_id: int = 1) -> Array:
	var bucket: Dictionary = _players.get(player_id, {})
	var items: Dictionary  = (bucket.get("items", {}) as Dictionary)
	var result: Array[Dictionary] = []
	for item_id in items:
		var def: ItemDefinition = _item_registry.get(item_id)
		result.append(
			{
				"id":       item_id,
				"name":     def.display_name if def else item_id,
				"quantity": items[item_id],
				"icon":     def.icon if def else null,
				"weight":   def.get("weight") if def and def.get("weight") != null else 0.0,
			}
		)
	return result

func get_weight_status(player_id: int = 1) -> Dictionary:
	var bucket: Dictionary = _players.get(player_id, {"weight": 0.0, "max_weight": 50.0})
	return {"current": bucket.get("weight", 0.0), "max": bucket.get("max_weight", 50.0)}

func get_free_slots(player_id: int = 1) -> int:
	var bucket: Dictionary = _players.get(player_id, {"items": {}, "max_slots": 28})
	var items: Dictionary  = bucket.get("items", {})
	return max(0, (bucket.get("max_slots", 28) as int) - items.size())

func get_item_info(item_id: String) -> ItemDefinition:
	return _item_registry.get(item_id)

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _restore_from_save(saved: Dictionary) -> void:
	# Format: { "1": {item_id: qty}, "2": {item_id: qty}, ... }
	for pid_str in saved:
		var pid: int = int(pid_str)
		var raw: Dictionary = saved[pid_str] as Dictionary if saved[pid_str] is Dictionary else {}
		var bucket := _ensure_player(pid)
		for item_id in raw:
			if _item_registry.has(item_id):
				bucket["items"][item_id] = int(raw[item_id])
