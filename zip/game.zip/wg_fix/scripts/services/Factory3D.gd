class_name Factory3D
extends RefCounted

## Factory3D — Programmatische Erzeugung von 3D-Hilfsobjekten.
##
##   VORHER: extends ServiceNode — lief durch die komplette 8-phasige Boot-Pipeline,
##           hatte eine ghost "data"-Dependency, belegte einen Registrierungsslot.
##   NACHHER: Normale RefCounted-Klasse. Wird einmal in WorldService instantiiert
##            und als öffentliche Variable `factory3d` exponiert.
##
## Zugriff für Entities/Components: IEntityContext.get_factory3d()
##   (WorldService ist sowieso die Voraussetzung für 3D-Entities)
##
## Bar3D extends Node3D (muss im Tree leben für Tweens) — deshalb kein pure static.
##
## MeshCache (Schicht 2): Wenn `cache` gesetzt und gebaut, nutzen alle Create-Methoden
## gecachte GPU-Ressourcen statt neue PrimitiveMesh-Objekte zu erstellen.
## BootPipeline ruft warmup_mesh_cache() in Phase S8.8 auf.

const LOG_CAT := "Factory3D"

## MeshCache — gesetzt von WorldService nach Session-Boot.
## Wenn null oder nicht gebaut: fallback auf legacy inline-Erstellung.
var cache: MeshCache = null

const COLOR_TRUNK: Color  = Color(0.40, 0.25, 0.10)
const COLOR_LEAVES: Color = Color(0.10, 0.50, 0.10)
const COLOR_BAR_BG: Color = Color(0.00, 0.00, 0.00, 0.70)
const COLOR_BAR_HP: Color = Color(0.20, 0.80, 0.30)

func create_simple_tree(parent: Node3D) -> Node3D:
	# MeshCache-Pfad: GPU-Ressourcen werden nur einmal erzeugt
	if _cache_ready():
		var node := cache.instantiate_scene("tree_oak")
		if parent:
			parent.add_child(node)
		return node

	# Legacy-Pfad (kein Cache verfügbar)
	var root := Node3D.new()
	root.name = "Tree_Root"

	var trunk := _create_3d_shape(CylinderMesh.new(), COLOR_TRUNK, false)
	trunk.scale    = Vector3(0.3, 1.5, 0.3)
	trunk.position = Vector3(0.0, 0.75, 0.0)
	root.add_child(trunk)

	var leaves := _create_3d_shape(SphereMesh.new(), COLOR_LEAVES, false)
	leaves.scale    = Vector3(1.2, 1.2, 1.2)
	leaves.position = Vector3(0.0, 1.8, 0.0)
	root.add_child(leaves)

	if parent:
		parent.add_child(root)
	return root

func create_3d_bar(parent: Node3D) -> Bar3D:
	var bar_node := Bar3D.new()
	bar_node.name      = "UI_ProgressBar3D"
	bar_node.position  = Vector3(0.0, 2.5, 0.0)
	bar_node.visible   = false

	if _cache_ready():
		# Cache-Pfad: gecachte ArrayMesh + Material
		var bg := MeshInstance3D.new()
		bg.mesh = cache.get_mesh("bar_bg")
		bg.set_surface_override_material(0, cache.get_material(Color(0.15, 0.15, 0.15, 0.8), true))
		bar_node.add_child(bg)

		var fill := MeshInstance3D.new()
		fill.name = "Fill"
		fill.mesh = cache.get_mesh("bar_fg")
		fill.set_surface_override_material(0, cache.get_material(Color(0.10, 0.85, 0.10), true))
		fill.position.z = 0.01
		bar_node.add_child(fill)
		bar_node.setup(fill)
	else:
		# Legacy-Pfad
		var bg_mesh      := QuadMesh.new()
		bg_mesh.size      = Vector2(1.2, 0.2)
		var bg            := _create_3d_shape(bg_mesh, COLOR_BAR_BG, true)
		bar_node.add_child(bg)

		var fill_mesh    := QuadMesh.new()
		fill_mesh.size    = Vector2(1.1, 0.15)
		var fill          := _create_3d_shape(fill_mesh, COLOR_BAR_HP, true)
		fill.name         = "Fill"
		fill.position.z   = 0.01
		bar_node.add_child(fill)
		bar_node.setup(fill)

	if parent:
		parent.add_child(bar_node)
	return bar_node

## Gibt true zurück wenn der MeshCache verfügbar und gebaut ist.
func _cache_ready() -> bool:
	return cache != null and cache.is_built()

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _create_3d_shape(mesh: Mesh, color: Color, is_ui_element: bool) -> MeshInstance3D:
	var mi  := MeshInstance3D.new()
	mi.mesh  = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color  = color
	mat.transparency  = StandardMaterial3D.TRANSPARENCY_ALPHA

	if is_ui_element:
		mat.billboard_mode = StandardMaterial3D.BILLBOARD_ENABLED
		mat.shading_mode   = StandardMaterial3D.SHADING_MODE_UNSHADED
	else:
		mat.billboard_mode = StandardMaterial3D.BILLBOARD_DISABLED
		mat.shading_mode   = StandardMaterial3D.SHADING_MODE_PER_PIXEL

	mi.material_override = mat
	return mi

# ─────────────────────────────────────────────
# Hilfsklassen
# ─────────────────────────────────────────────

class Bar3D extends Node3D:
	var _fill: MeshInstance3D
	var _max_width: float = 1.1

	func setup(fill_node: MeshInstance3D) -> void:
		_fill = fill_node
		var q_mesh := _fill.mesh as QuadMesh
		if q_mesh:
			_max_width = q_mesh.size.x

	func update(percent: float) -> void:
		if not is_instance_valid(_fill):
			return
		var p: float = clamp(percent, 0.0, 1.0)
		_fill.scale.x    = p
		_fill.position.x = (p - 1.0) * (_max_width / 2.0)

# ─────────────────────────────────────────────
# Welt-Authentizität: Natur-Objekte
# ─────────────────────────────────────────────

## Liegender Baumstamm — prozedural aus Zylinder + optionalen Pilzen.
func create_fallen_tree(parent: Node3D, biome_id: String = "forest") -> Node3D:
	var root := Node3D.new()
	root.name = "FallenTree"

	var length := randf_range(3.0, 7.0)
	var radius := randf_range(0.22, 0.45)

	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius    = radius * 0.8
	trunk_mesh.bottom_radius = radius
	trunk_mesh.height        = length
	var trunk := _create_3d_shape(trunk_mesh, COLOR_TRUNK, false)
	trunk.rotation_degrees.z = 90.0
	trunk.position = Vector3(0.0, radius, 0.0)
	root.add_child(trunk)

	# Zufällige Pilze auf dem Stamm
	if randf() < 0.5:
		var shroom_count := randi_range(1, 3)
		for i in range(shroom_count):
			var shroom := _build_mushroom_single("brown")
			shroom.scale = Vector3(0.4, 0.4, 0.4)
			shroom.position = Vector3(
				randf_range(-length * 0.3, length * 0.3),
				radius * 1.5,
				randf_range(-0.1, 0.1)
			)
			root.add_child(shroom)

	if parent:
		parent.add_child(root)
	return root

## Pilz-Cluster: 1–4 Pilze in Gruppe, Typ bestimmt Farbe.
func create_mushroom_cluster(parent: Node3D, mushroom_type: String = "brown") -> Node3D:
	var root := Node3D.new()
	root.name = "MushroomCluster"

	var count := randi_range(1, 4)
	for i in range(count):
		var shroom := _build_mushroom_single(mushroom_type)
		shroom.position = Vector3(
			randf_range(-0.4, 0.4),
			0.0,
			randf_range(-0.4, 0.4)
		)
		shroom.scale = Vector3.ONE * randf_range(0.7, 1.3)
		root.add_child(shroom)

	if parent:
		parent.add_child(root)
	return root

func _build_mushroom_single(mushroom_type: String) -> Node3D:
	var root := Node3D.new()
	root.name = "Mushroom"

	# Stiel
	var stem_mesh := CylinderMesh.new()
	stem_mesh.top_radius    = 0.04
	stem_mesh.bottom_radius = 0.06
	stem_mesh.height        = 0.18
	var stem := _create_3d_shape(stem_mesh, Color(0.85, 0.80, 0.72), false)
	stem.position.y = 0.09
	root.add_child(stem)

	# Kappe — Farbe je nach Typ
	var cap_color: Color
	match mushroom_type:
		"red":    cap_color = Color(0.85, 0.15, 0.10)   # Fliegenpilz
		"orange": cap_color = Color(0.90, 0.55, 0.10)   # Pfifferling
		_:        cap_color = Color(0.55, 0.35, 0.18)   # Steinpilz (default)

	var cap_mesh := SphereMesh.new()
	cap_mesh.radius = 0.14
	cap_mesh.height = 0.14
	var cap := _create_3d_shape(cap_mesh, cap_color, false)
	cap.scale.y = 0.55   # abgeflacht
	cap.position.y = 0.22
	root.add_child(cap)

	# Weiße Punkte bei Fliegenpilz
	if mushroom_type == "red":
		for i in range(3):
			var dot_mesh := SphereMesh.new()
			dot_mesh.radius = 0.025
			var dot := _create_3d_shape(dot_mesh, Color(1.0, 1.0, 1.0), false)
			var angle := (TAU / 3.0) * i
			dot.position = Vector3(cos(angle) * 0.07, 0.24, sin(angle) * 0.07)
			root.add_child(dot)

	return root

## Farn — kreuzförmige Planes (Billboard-ähnlich, dekorativ).
func create_fern(parent: Node3D) -> Node3D:
	var root := Node3D.new()
	root.name = "Fern"

	var fern_color := Color(0.12, 0.55, 0.12)
	var plane_count := randi_range(3, 5)
	for i in range(plane_count):
		var plane_mesh := PlaneMesh.new()
		plane_mesh.size = Vector2(randf_range(0.4, 0.7), randf_range(0.3, 0.5))
		var plane := _create_3d_shape(plane_mesh, fern_color, false)
		plane.rotation_degrees.y = (180.0 / plane_count) * i
		plane.rotation_degrees.x = randf_range(-20.0, -40.0)
		plane.position.y = 0.15
		var mat := plane.material_override as StandardMaterial3D
		if mat:
			mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		root.add_child(plane)

	if parent:
		parent.add_child(root)
	return root

## Felsblock — deformierte Kugel je nach Biom eingefärbt.
func create_rock_boulder(parent: Node3D, biome_id: String = "forest") -> Node3D:
	var root := Node3D.new()
	root.name = "RockBoulder"

	var rock_color: Color
	match biome_id:
		"desert": rock_color = Color(0.65, 0.50, 0.30)
		"winter": rock_color = Color(0.70, 0.75, 0.82)
		_:        rock_color = Color(0.42, 0.42, 0.40)

	var sphere_mesh := SphereMesh.new()
	sphere_mesh.radius = randf_range(0.4, 0.9)
	sphere_mesh.height = sphere_mesh.radius * 2.0 * randf_range(0.5, 0.8)
	var rock := _create_3d_shape(sphere_mesh, rock_color, false)
	rock.rotation_degrees.y = randf_range(0, 360)
	rock.scale = Vector3(
		randf_range(0.8, 1.2),
		randf_range(0.6, 1.0),
		randf_range(0.8, 1.2)
	)
	root.add_child(rock)

	if parent:
		parent.add_child(root)
	return root

## Tanne (Winter-Biom) — mehrere Kegel übereinander, optional Schnee-Overlay.
func create_pine_tree(parent: Node3D, snow: bool = false) -> Node3D:
	if _cache_ready():
		var key := "tree_pine_snow" if snow else "tree_pine"
		var node := cache.instantiate_scene(key)
		if parent:
			parent.add_child(node)
		return node

	var root := Node3D.new()
	root.name = "PineTree"

	# Stamm
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius    = 0.12
	trunk_mesh.bottom_radius = 0.18
	trunk_mesh.height        = 1.2
	var trunk := _create_3d_shape(trunk_mesh, Color(0.30, 0.18, 0.08), false)
	trunk.position.y = 0.6
	root.add_child(trunk)

	# Kegel-Ebenen (unten groß → oben klein)
	var layers := [
		{"y": 0.8, "r": 1.1, "h": 0.7},
		{"y": 1.4, "r": 0.85, "h": 0.65},
		{"y": 1.9, "r": 0.60, "h": 0.60},
		{"y": 2.3, "r": 0.35, "h": 0.55},
	]
	var leaf_color := Color(0.08, 0.38, 0.12)

	for layer in layers:
		var cone_mesh := CylinderMesh.new()
		cone_mesh.top_radius    = 0.0
		cone_mesh.bottom_radius = layer["r"]
		cone_mesh.height        = layer["h"]
		var cone := _create_3d_shape(cone_mesh, leaf_color, false)
		cone.position.y = layer["y"]
		root.add_child(cone)

		if snow:
			var snow_mesh := CylinderMesh.new()
			snow_mesh.top_radius    = 0.0
			snow_mesh.bottom_radius = layer["r"] * 0.75
			snow_mesh.height        = layer["h"] * 0.35
			var snow_cone := _create_3d_shape(snow_mesh, Color(0.90, 0.93, 0.97), false)
			snow_cone.position.y = layer["y"] + layer["h"] * 0.25
			root.add_child(snow_cone)

	if parent:
		parent.add_child(root)
	return root

## Kaktus (Wüste) — Zylinder + 2 Arme.
func create_cactus(parent: Node3D) -> Node3D:
	if _cache_ready():
		var node := cache.instantiate_scene("cactus")
		if parent:
			parent.add_child(node)
		return node

	var root := Node3D.new()
	root.name = "Cactus"
	var cactus_color := Color(0.18, 0.48, 0.18)

	# Hauptstamm
	var body_mesh := CylinderMesh.new()
	body_mesh.top_radius    = 0.14
	body_mesh.bottom_radius = 0.16
	body_mesh.height        = 1.8
	var body := _create_3d_shape(body_mesh, cactus_color, false)
	body.position.y = 0.9
	root.add_child(body)

	# Linker Arm
	var arm_l := _build_cactus_arm(cactus_color, -1.0)
	root.add_child(arm_l)

	# Rechter Arm
	var arm_r := _build_cactus_arm(cactus_color, 1.0)
	root.add_child(arm_r)

	if parent:
		parent.add_child(root)
	return root

func _build_cactus_arm(color: Color, side: float) -> Node3D:
	var arm_root := Node3D.new()

	# Horizontaler Teil
	var h_mesh := CylinderMesh.new()
	h_mesh.top_radius = 0.09
	h_mesh.bottom_radius = 0.09
	h_mesh.height = 0.45
	var h_part := _create_3d_shape(h_mesh, color, false)
	h_part.rotation_degrees.z = 90.0
	h_part.position = Vector3(side * 0.32, 0.95, 0.0)
	arm_root.add_child(h_part)

	# Vertikaler Teil
	var v_mesh := CylinderMesh.new()
	v_mesh.top_radius = 0.09
	v_mesh.bottom_radius = 0.09
	v_mesh.height = 0.5
	var v_part := _create_3d_shape(v_mesh, color, false)
	v_part.position = Vector3(side * 0.55, 1.20, 0.0)
	arm_root.add_child(v_part)

	return arm_root
