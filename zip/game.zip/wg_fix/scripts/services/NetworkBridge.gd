extends ServiceNode
# justified: enthaelt @rpc-Methoden (Godot 4 RPC nur auf Node); hostet alle Netzwerk-RPCs (ADR-010).
class_name NetworkBridge

## NetworkBridge — RPC-Empfangsstelle + Host/Join-API für alle RefCounted-Services.
##
## TIER 1 (Solo): Kein MultiplayerPeer → kein RPC nötig.
##   request_*()-Methoden in den Services rufen on_*_confirmed() direkt auf.
##
## TIER 2 (Hosted Coop): Host ruft host_game(port), Clients rufen join_game(ip, port).
##   request_*() rufen rpc_id(1, "_rpc_*", ...) auf.
##   NetworkBridge empfängt auf der Autorität (peer_id=1) und delegiert an die zuständigen Services.
##
## TIER 3 (Dedicated Server): Identisch zu Tier 2, Server ist kein spielender Client.

const LOG_CAT := "NetworkBridge"

## G-03: Snapshot-Retry-Konfiguration.
## Das RPC ist "reliable" — ENet garantiert Delivery auf Protokollebene.
## Retry schützt gegen Boot-Race-Conditions: Server antwortet lautlos wenn
## SaveSystem zur Zeit des Requests noch nicht bereit war.
const SNAPSHOT_TIMEOUT_SEC := 3.0   ## Wartezeit auf _rpc_receive_initial_state
const SNAPSHOT_MAX_RETRIES := 3     ## Max. Retry-Versuche bevor aufgegeben wird

const DEFAULT_PORT    := 7777
const MAX_CLIENTS     := 8

var _inventory:     InventorySystem    = null
var _quest:         QuestService       = null
var _skill_system:  SkillSystem        = null
var _player_states: PlayerStateService = null
var _equipment:     EquipmentService   = null
var _save_system:   SaveSystem         = null

## G-03: Snapshot-Retry-State (Client-Seite).
var _snapshot_received:  bool           = false
var _snapshot_retries:   int            = 0
var _snapshot_timer:     SceneTreeTimer = null

## Signale für UI/GameManager
signal player_connected(peer_id: int)
signal player_disconnected(peer_id: int)
signal connection_failed()
signal server_disconnected()

# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	_inventory     = deps.get_optional(ServiceKeys.INVENTORY)      as InventorySystem
	_quest         = deps.get_optional(ServiceKeys.QUEST)          as QuestService
	_skill_system  = deps.get_optional(ServiceKeys.SKILL_SYSTEM)   as SkillSystem
	_player_states = deps.get_optional(ServiceKeys.PLAYER_STATES)  as PlayerStateService
	_equipment     = deps.get_optional(ServiceKeys.EQUIPMENT)      as EquipmentService
	_save_system   = deps.get_optional(ServiceKeys.SAVE_SYSTEM)    as SaveSystem
	AppLogger.log_info("NetworkBridge konfiguriert.", LOG_CAT)

func on_ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	var peer_set := _has_peer()
	AppLogger.log_info("NetworkBridge bereit. Peer gesetzt: %s" % str(peer_set), LOG_CAT)

func on_cleanup() -> void:
	if multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.disconnect(_on_peer_connected)
	if multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.disconnect(_on_peer_disconnected)
	if multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.disconnect(_on_connected_to_server)
	if multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.disconnect(_on_connection_failed)
	if multiplayer.server_disconnected.is_connected(_on_server_disconnected):
		multiplayer.server_disconnected.disconnect(_on_server_disconnected)
	close()
	AppLogger.log_info("NetworkBridge cleanup.", LOG_CAT)

# ─────────────────────────────────────────────
# Host / Join API (Phase 4)
# ─────────────────────────────────────────────

## Startet einen ENet-Host auf dem angegebenen Port.
## Gibt true zurück wenn erfolgreich.
func host_game(port: int = DEFAULT_PORT, max_clients: int = MAX_CLIENTS) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, max_clients)
	if err != OK:
		AppLogger.log_error("host_game(): create_server(%d) fehlgeschlagen: %s" % [port, error_string(err)], LOG_CAT)
		return false
	multiplayer.multiplayer_peer = peer
	AppLogger.log_info("Host gestartet auf Port %d (max. %d Clients)." % [port, max_clients], LOG_CAT)
	return true

## Verbindet als Client mit einem Host.
## Gibt true zurück wenn die Verbindung eingeleitet wurde (nicht: wenn sie fertig ist).
func join_game(address: String, port: int = DEFAULT_PORT) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(address, port)
	if err != OK:
		AppLogger.log_error("join_game(): create_client(%s:%d) fehlgeschlagen: %s" % [address, port, error_string(err)], LOG_CAT)
		return false
	multiplayer.multiplayer_peer = peer
	AppLogger.log_info("Verbindung zu %s:%d eingeleitet." % [address, port], LOG_CAT)
	return true

## Trennt den Peer und setzt ihn zurück auf Tier 1 (Solo).
func close() -> void:
	if _has_peer():
		multiplayer.multiplayer_peer = null
		AppLogger.log_info("Multiplayer-Peer geschlossen — zurück zu Tier 1.", LOG_CAT)

func is_server() -> bool:
	return not _has_peer() or multiplayer.is_server()

func get_local_peer_id() -> int:
	return multiplayer.get_unique_id() if _has_peer() else 1

# ─────────────────────────────────────────────
# RPC-Routing-Helfer (genutzt von Services)
# ─────────────────────────────────────────────

## Gibt true zurück wenn ein Peer gesetzt ist (Tier 2/3).
## Services rufen das ab um zu entscheiden ob sie rpc_id() oder direkt aufrufen.
func has_peer() -> bool:
	return _has_peer()

## Sendet einen PlayerState-Wechsel an die Autorität.
func send_set_state(state: int) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_set_state", state)
	else:
		if is_instance_valid(_player_states):
			_player_states.set_state(state as PlayerStateService.State, get_local_peer_id())

## Sendet einen XP-Gain an die Autorität (oder ruft lokal auf in Tier 1).
func send_add_xp(skill_name: String, amount: int) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_add_xp", skill_name, amount)
	else:
		if is_instance_valid(_skill_system):
			_skill_system.on_xp_add_confirmed(skill_name, amount, 1)

## Sendet eine Item-Anfrage an die Autorität.
func send_add_item(item_id: String, qty: int) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_add_item", item_id, qty)
	else:
		if is_instance_valid(_inventory):
			_inventory.on_item_add_confirmed(item_id, qty, 1)

## Sendet eine Quest-Start-Anfrage an die Autorität.
func send_start_quest(quest_id: String) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_start_quest", quest_id)
	else:
		if is_instance_valid(_quest):
			_quest.on_quest_start_confirmed(quest_id, 1)

## Sendet eine Quest-Complete-Anfrage an die Autorität.
func send_complete_quest(quest_id: String) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_complete_quest", quest_id)
	else:
		if is_instance_valid(_quest):
			_quest.on_quest_complete_confirmed(quest_id, 1)

## C-03: Sendet eine Equip-Anfrage an die Autorität.
## [param item_id] Item-ID aus DataService — kein ItemDefinition über das Netz.
func send_equip_item(slot: String, item_id: String, player_id: int = 1) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_equip_item", slot, item_id)
	else:
		if is_instance_valid(_equipment):
			_equipment.on_equip_confirmed(slot, item_id, player_id)

## C-03: Sendet eine Unequip-Anfrage an die Autorität.
func send_unequip_item(slot: String, player_id: int = 1) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_unequip_item", slot)
	else:
		if is_instance_valid(_equipment):
			_equipment.on_unequip_confirmed(slot, player_id)

# ─────────────────────────────────────────────
# RPC-Empfangs-Methoden (laufen auf Autorität)
# ─────────────────────────────────────────────

@rpc("any_peer", "call_remote", "reliable")
func _rpc_add_item(item_id: String, qty: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	AppLogger.log_debug("RPC _rpc_add_item von peer %d: %s x%d" % [player_id, item_id, qty], LOG_CAT)
	if is_instance_valid(_inventory):
		_inventory.on_item_add_confirmed(item_id, qty, player_id)
	else:
		AppLogger.log_error("_rpc_add_item: InventorySystem nicht verfügbar!", LOG_CAT)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_start_quest(quest_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	AppLogger.log_debug("RPC _rpc_start_quest von peer %d: %s" % [player_id, quest_id], LOG_CAT)
	if is_instance_valid(_quest):
		_quest.on_quest_start_confirmed(quest_id, player_id)
	else:
		AppLogger.log_error("_rpc_start_quest: QuestService nicht verfügbar!", LOG_CAT)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_complete_quest(quest_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	AppLogger.log_debug("RPC _rpc_complete_quest von peer %d: %s" % [player_id, quest_id], LOG_CAT)
	if is_instance_valid(_quest):
		_quest.on_quest_complete_confirmed(quest_id, player_id)
	else:
		AppLogger.log_error("_rpc_complete_quest: QuestService nicht verfügbar!", LOG_CAT)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_add_xp(skill_name: String, amount: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	AppLogger.log_debug("RPC _rpc_add_xp von peer %d: %s +%d" % [player_id, skill_name, amount], LOG_CAT)
	if is_instance_valid(_skill_system):
		_skill_system.on_xp_add_confirmed(skill_name, amount, player_id)
	else:
		AppLogger.log_error("_rpc_add_xp: SkillSystem nicht verfügbar!", LOG_CAT)

@rpc("any_peer", "call_remote", "reliable")
func _rpc_set_state(state: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_player_states):
		_player_states.set_state(state as PlayerStateService.State, player_id)
	else:
		AppLogger.log_error("_rpc_set_state: PlayerStateService nicht verfügbar!", LOG_CAT)

## C-03: RPC-Empfang für equip auf Autorität.
@rpc("any_peer", "call_remote", "reliable")
func _rpc_equip_item(slot: String, item_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	AppLogger.log_debug("RPC _rpc_equip_item von peer %d: slot='%s' item='%s'" % [player_id, slot, item_id], LOG_CAT)
	if is_instance_valid(_equipment):
		_equipment.on_equip_confirmed(slot, item_id, player_id)
	else:
		AppLogger.log_error("_rpc_equip_item: EquipmentService nicht verfügbar!", LOG_CAT)

## C-03: RPC-Empfang für unequip auf Autorität.
@rpc("any_peer", "call_remote", "reliable")
func _rpc_unequip_item(slot: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	AppLogger.log_debug("RPC _rpc_unequip_item von peer %d: slot='%s'" % [player_id, slot], LOG_CAT)
	if is_instance_valid(_equipment):
		_equipment.on_unequip_confirmed(slot, player_id)
	else:
		AppLogger.log_error("_rpc_unequip_item: EquipmentService nicht verfügbar!", LOG_CAT)

## Sprint D/E: Empfängt den initialen State-Snapshot vom Server nach eigenem Request.
## Läuft nur auf Clients — der Server sendet nie an sich selbst.
## G-03: Cancelt den Retry-Timer — Snapshot wurde empfangen.
@rpc("authority", "call_remote", "reliable")
func _rpc_receive_initial_state(state: Dictionary) -> void:
	if multiplayer.is_server():
		return
	# G-03: Snapshot empfangen — Timer und Retry-Zähler stoppen.
	_snapshot_received = true
	_cancel_snapshot_timer()
	AppLogger.log_info("Initial-Snapshot vom Server empfangen (%d Keys)." % state.size(), LOG_CAT)
	if is_instance_valid(_save_system):
		_save_system.apply_remote_state(state)
	else:
		AppLogger.log_error("_rpc_receive_initial_state: SaveSystem nicht verfügbar!", LOG_CAT)

## E-4: Client ruft dies nach seinem Session-Boot auf um den State-Snapshot anzufordern.
## Korrigiertes Timing: Client hat zu diesem Zeitpunkt bereits eine aktive Session
## und apply_remote_state() ist nicht mehr durch den _active_player_id-Guard blockiert.
##
## G-03: Startet einen SNAPSHOT_TIMEOUT_SEC-Timer. Bleibt _rpc_receive_initial_state
## aus (Server noch nicht bereit, Boot-Race-Condition), wird der Request wiederholt.
func send_request_initial_state() -> void:
	if not _has_peer() or multiplayer.is_server():
		return
	_snapshot_received = false
	_snapshot_retries  = 0
	_send_snapshot_request()

## E-4: Server-Seite des Snapshot-Requests — sendet den State nur an den anfragenden Client.
@rpc("any_peer", "call_remote", "reliable")
func _rpc_client_requests_initial_state() -> void:
	if not _is_authority():
		return
	if not is_instance_valid(_save_system):
		AppLogger.log_error("_rpc_client_requests_initial_state: SaveSystem nicht verfügbar!", LOG_CAT)
		return
	var requester := multiplayer.get_remote_sender_id()
	var state := _save_system.get_full_state()
	AppLogger.log_info(
		"Initial-Snapshot angefragt von peer %d — sende %d Keys." % [requester, state.size()],
		LOG_CAT
	)
	rpc_id(requester, "_rpc_receive_initial_state", state)

# ─────────────────────────────────────────────
# Peer-Event-Handler
# ─────────────────────────────────────────────

func _on_peer_connected(peer_id: int) -> void:
	AppLogger.log_info("Peer verbunden: %d" % peer_id, LOG_CAT)
	player_connected.emit(peer_id)
	# Snapshot wird nicht hier gesendet — zu diesem Zeitpunkt hat der Client noch
	# keine Session gebootet und apply_remote_state() würde blockiert.
	# Stattdessen fordert der Client nach seinem Session-Boot den Snapshot an
	# via _rpc_request_initial_state() (E-4).

func _on_peer_disconnected(peer_id: int) -> void:
	AppLogger.log_info("Peer getrennt: %d" % peer_id, LOG_CAT)
	player_disconnected.emit(peer_id)

func _on_connected_to_server() -> void:
	AppLogger.log_info("Mit Server verbunden. Lokale peer_id: %d" % multiplayer.get_unique_id(), LOG_CAT)

func _on_connection_failed() -> void:
	AppLogger.log_error("Verbindung zum Server fehlgeschlagen.", LOG_CAT)
	connection_failed.emit()

func _on_server_disconnected() -> void:
	AppLogger.log_warn("Server-Verbindung verloren.", LOG_CAT)
	server_disconnected.emit()

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _has_peer() -> bool:
	# has_multiplayer_peer() gibt in Godot 4 auch für den Standard-OfflineMultiplayerPeer
	# true zurück. Wir wollen nur echte Netzwerk-Peers (ENet, WebSocket …) als "gesetzt"
	# betrachten — deshalb prüfen wir zusätzlich den Klassen-Namen des Peers.
	if not is_instance_valid(multiplayer):
		return false
	if not multiplayer.has_multiplayer_peer():
		return false
	var peer := multiplayer.multiplayer_peer
	return is_instance_valid(peer) and peer.get_class() != "OfflineMultiplayerPeer"

func _is_authority() -> bool:
	return not _has_peer() or multiplayer.is_server()

func _sender_as_player_id() -> int:
	var sender := multiplayer.get_remote_sender_id()
	return sender if sender != 0 else 1

# ─────────────────────────────────────────────
# G-03: Snapshot-Retry-Helpers
# ─────────────────────────────────────────────

## Sendet den Snapshot-Request und startet den Timeout-Timer.
## Wird von send_request_initial_state() und _on_snapshot_timeout() aufgerufen.
func _send_snapshot_request() -> void:
	rpc_id(1, "_rpc_client_requests_initial_state")
	AppLogger.log_info(
		"Snapshot angefordert (Versuch %d/%d)." % [_snapshot_retries + 1, SNAPSHOT_MAX_RETRIES + 1],
		LOG_CAT
	)
	_start_snapshot_timer()

func _start_snapshot_timer() -> void:
	_cancel_snapshot_timer()
	_snapshot_timer = get_tree().create_timer(SNAPSHOT_TIMEOUT_SEC)
	_snapshot_timer.timeout.connect(_on_snapshot_timeout, CONNECT_ONE_SHOT)

func _cancel_snapshot_timer() -> void:
	if is_instance_valid(_snapshot_timer):
		if _snapshot_timer.timeout.is_connected(_on_snapshot_timeout):
			_snapshot_timer.timeout.disconnect(_on_snapshot_timeout)
	_snapshot_timer = null

func _on_snapshot_timeout() -> void:
	_snapshot_timer = null
	if _snapshot_received:
		return  # Snapshot kam zwischenzeitlich an — kein Retry nötig.
	if _snapshot_retries >= SNAPSHOT_MAX_RETRIES:
		AppLogger.log_error(
			"Snapshot-Request nach %d Versuchen ohne Antwort aufgegeben." % (SNAPSHOT_MAX_RETRIES + 1),
			LOG_CAT
		)
		return
	_snapshot_retries += 1
	AppLogger.log_warn(
		"Snapshot-Timeout — Retry %d/%d..." % [_snapshot_retries, SNAPSHOT_MAX_RETRIES],
		LOG_CAT
	)
	_send_snapshot_request()
