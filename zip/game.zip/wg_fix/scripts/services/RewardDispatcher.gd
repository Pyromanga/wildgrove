extends Service
class_name RewardDispatcher

## RewardDispatcher — Übersetzt QuestReward in konkrete Service-Aufrufe.
##
## ARCHITEKTUR:
##   QuestService kennt KEINE anderen Gameplay-Services (inventory, skill_system).
##   RewardDispatcher ist das einzige System das QuestReward in Service-Calls übersetzt.
##   Das hält QuestService testbar und entkoppelt.
##
## Abhängigkeiten (deps): ["inventory", "skill_system"]
## QuestService deklariert reward_dispatcher als deps und bekommt ihn injiziert (configure()).

const LOG_CAT := "RewardDispatcher"

var _inventory:    InventorySystem
var _skill_system: SkillSystem
var _bus:          IEventBus

func configure(deps: ServiceDeps) -> void:
	_inventory    = deps.require(ServiceKeys.INVENTORY)    as InventorySystem
	_skill_system = deps.require(ServiceKeys.SKILL_SYSTEM) as SkillSystem
	_bus          = deps.require(ServiceKeys.EVENT_BUS)     as IEventBus

	if not is_instance_valid(_inventory):
		Logger.log_warn("InventorySystem fehlt — Item-Rewards nicht verfügbar.", LOG_CAT)
	if not is_instance_valid(_skill_system):
		Logger.log_warn("SkillSystem fehlt — XP-Rewards nicht verfügbar.", LOG_CAT)

func on_ready() -> void:
	Logger.log_info("RewardDispatcher bereit.", LOG_CAT)

## Zahlt eine QuestReward aus. Gibt true zurück wenn alle Teile erfolgreich waren.
func dispatch(reward: QuestReward) -> bool:
	if not reward:
		Logger.log_warn("dispatch() mit null-Reward aufgerufen.", LOG_CAT)
		return false

	var all_ok := true
	var t := Logger.log_begin("RewardDispatcher.dispatch()", LOG_CAT)

	# XP-Rewards
	for skill_name in reward.xp_rewards:
		var amount: int = reward.xp_rewards[skill_name]
		if is_instance_valid(_skill_system):
			_skill_system.request_add_xp(skill_name, amount)
			Logger.log_debug("+%d XP in '%s'." % [amount, skill_name], LOG_CAT)
		else:
			Logger.log_warn("SkillSystem fehlt — XP-Reward '%s' x%d nicht ausgezahlt!" % [skill_name, amount], LOG_CAT)
			all_ok = false

	# Item-Rewards
	for item_id in reward.item_rewards:
		var quantity: int = reward.item_rewards[item_id]
		if is_instance_valid(_inventory):
			_inventory.request_add_item(item_id, quantity)
			Logger.log_debug("+%dx '%s' ins Inventar." % [quantity, item_id], LOG_CAT)
		else:
			Logger.log_warn("InventorySystem fehlt — Item-Reward '%s' x%d nicht ausgezahlt!" % [item_id, quantity], LOG_CAT)
			all_ok = false

	# Quest-Unlocks — via EventBus.
	# QuestService lauscht auf EventBus.quest.quest_unlock_requested und ruft unlock_quest() selbst auf.
	for quest_id in reward.unlock_quests:
		_bus.quest().emit_quest_unlock_requested(quest_id)
		Logger.log_debug("Quest-Unlock angefordert: '%s'." % quest_id, LOG_CAT)

	# Custom-Signals
	for signal_key in reward.custom_signals:
		Logger.log_debug("Custom-Signal emittiert: '%s'." % signal_key, LOG_CAT)
		_bus.quest().emit_reward_signal(signal_key)

	Logger.log_end("RewardDispatcher.dispatch()", t, LOG_CAT)
	return all_ok
