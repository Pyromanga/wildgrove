extends ServiceNode
# justified: get_tree().call_deferred('change_scene_to_file') -- direkter SceneTree-Zugriff noetig.
class_name SceneManager

const LOG_CAT := "SceneManager"

var _bus: IEventBus

func configure(deps: ServiceDeps) -> void:
	_bus = deps.require(ServiceKeys.EVENT_BUS) as IEventBus
	Logger.log_info("SceneManager konfiguriert.", LOG_CAT)

func on_ready() -> void:
	_bus.ui().scene_reload_requested.connect(
		func() -> void: change_scene("res://scenes/World.tscn")
	)
	Logger.log_info("SceneManager bereit.", LOG_CAT)

func on_cleanup() -> void:
	if _bus and _bus.ui().scene_reload_requested.is_connected(change_scene.bind("res://scenes/World.tscn")):
		pass  # Lambda-Disconnect nicht möglich — Signal wird mit SceneManager freigegeben
	Logger.log_info("SceneManager cleanup.", LOG_CAT)

const STATE_SCENE_MAP := {
	GameEnums.State.MAIN_MENU: "res://scenes/MainMenu.tscn",
	GameEnums.State.PLAYING: "res://scenes/World.tscn",
	GameEnums.State.GAME_OVER: "res://scenes/GameOver.tscn"
}

func transition_to_state(state: GameEnums.State) -> void:
	var path = STATE_SCENE_MAP.get(state)
	if path:
		Logger.log_info(
			"Wechsle Szene für State %s -> %s" % [GameEnums.State.keys()[state], path], LOG_CAT
		)
		if not get_tree():
			Logger.log_error("SceneManager hat keinen SceneTree — Szenenwechsel abgebrochen!", LOG_CAT)
			return
		get_tree().call_deferred("change_scene_to_file", path)
		Logger.log_debug("call_deferred(change_scene_to_file) abgesetzt.", LOG_CAT)
	else:
		Logger.log_debug(
			"Kein Szenenwechsel für State: %s" % GameEnums.State.keys()[state], LOG_CAT
		)

func change_scene(path: String) -> void:
	Logger.log_info("Wechsle Szene zu: %s" % path, LOG_CAT)
	get_tree().call_deferred("change_scene_to_file", path)
