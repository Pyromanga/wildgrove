class_name QuestCustomTrigger extends Area3D

## QuestCustomTrigger — generischer, wiederverwendbarer Trigger für CUSTOM-
## Quest-Objectives (QuestObjective.Type.CUSTOM).
##
## Platzierbar überall in der Welt (Lore-Punkte, geheime Bereiche, Events).
## Beim Betreten durch einen Spieler emittiert dieser Node genau einmal
## (pro Spawn-Zyklus) custom_objective_triggered(signal_key) über den
## injizierten IEventBus — signal_key muss exakt obj.target_id in der
## passenden QuestObjective entsprechen.
##
## Beispiel: Lager-Erkundung als CUSTOM-Objective.
##   signal_key = "erik_camp_explored"
##   → QuestObjective.target_id = "erik_camp_explored", type = CUSTOM (5)
##
## IEventBus wird via inject_bus() injiziert — kein AutoLoad-Zugriff
## (analog zu InteractionSensor.inject_bus(), vgl. Runde 4 EventBus-Migration).
## CollisionShape3D muss vom Aufrufer (Szene/Subklasse) gesetzt werden.

const LOG_CAT := "QuestCustomTrigger"

## Der Key der via custom_objective_triggered emittiert wird.
## Muss exakt einer QuestObjective.target_id (type=CUSTOM) entsprechen.
@export var signal_key: String = ""

## Ob der Trigger nach erstmaligem Auslösen deaktiviert wird (Default: ja —
## verhindert wiederholtes Triggern bei jedem erneuten Betreten der Zone).
@export var trigger_once: bool = true

var _bus: IEventBus = null
var _has_triggered: bool = false

## Wird vom Aufrufer (EntityOrchestrator/World-Setup) nach add_child() aufgerufen.
func inject_bus(bus: IEventBus) -> void:
	_bus = bus

func _ready() -> void:
	monitoring   = true
	monitorable  = false
	body_entered.connect(_on_body_entered)
	if signal_key.is_empty():
		AppLogger.log_warn(
			"QuestCustomTrigger ohne signal_key platziert — wird nie etwas auslösen.", LOG_CAT
		)

func _on_body_entered(body: Node3D) -> void:
	if trigger_once and _has_triggered:
		return
	if not body.is_in_group("player"):
		return
	if _bus == null:
		AppLogger.log_error(
			"QuestCustomTrigger '%s': kein IEventBus injiziert — Trigger ignoriert." % signal_key,
			LOG_CAT
		)
		return
	if signal_key.is_empty():
		return

	_has_triggered = true
	_bus.quest().emit_custom_objective_triggered(signal_key)
	AppLogger.log_info("CUSTOM-Objective getriggert: '%s'." % signal_key, LOG_CAT)

	if trigger_once:
		monitoring = false  # Keine weiteren body_entered-Events nötig
