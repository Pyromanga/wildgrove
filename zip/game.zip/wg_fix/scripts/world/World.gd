extends Node3D
## World.gd — Einstiegspunkt der Spielwelt. Leerer Szenen-Container.
##
## Emittiert keine Events mehr. ServiceOrchestrator erkennt via SceneTree.node_added
## wenn diese Szene geladen ist und ruft WorldService.on_world_scene_ready(self) direkt auf.
## Kein AutoLoad-Zugriff, kein EventBus, keine Logik.
