class_name TerrainColorizer
extends RefCounted

## TerrainColorizer — Höhe + Biome → Vertex-Farbe.
##
## Kapselt die gesamte Farbgebungs-Logik aus TerrainGenerator.
## Stateless: jede Methode braucht nur die übergebenen Werte.

const COL_DEEP_WATER := Color(0.08, 0.25, 0.55)
const COL_SHALLOW    := Color(0.18, 0.48, 0.70)
const COL_SAND       := Color(0.76, 0.71, 0.50)
const COL_GRASS      := Color(0.24, 0.54, 0.20)
const COL_GRASS_DRY  := Color(0.55, 0.58, 0.22)
const COL_HILL       := Color(0.36, 0.30, 0.20)
const COL_ROCK       := Color(0.50, 0.46, 0.42)
const COL_SNOW       := Color(0.93, 0.94, 0.96)

## h in [-2, max_height], biome 0..1, sea_level in Welteinheiten.
func height_to_color(h: float, biome: float, max_height: float, sea_level: float) -> Color:
	var min_h: float    = -2.0
	var ratio: float    = clampf((h - min_h) / (max_height - min_h), 0.0, 1.0)
	var sl_ratio: float = (sea_level - min_h) / (max_height - min_h)

	if ratio < sl_ratio * 0.5:
		return COL_DEEP_WATER
	elif ratio < sl_ratio:
		return COL_SHALLOW.lerp(COL_SAND, (ratio - sl_ratio * 0.5) / (sl_ratio * 0.5))
	elif ratio < sl_ratio + 0.04:
		var grass: Color = COL_GRASS_DRY.lerp(COL_GRASS, biome)
		return COL_SAND.lerp(grass, (ratio - sl_ratio) / 0.04)
	elif ratio < 0.55:
		return COL_GRASS_DRY.lerp(COL_GRASS, biome)
	elif ratio < 0.72:
		return COL_GRASS.lerp(COL_HILL, (ratio - 0.55) / 0.17)
	elif ratio < 0.88:
		return COL_HILL.lerp(COL_ROCK, (ratio - 0.72) / 0.16)
	else:
		return COL_ROCK.lerp(COL_SNOW, (ratio - 0.88) / 0.12)
