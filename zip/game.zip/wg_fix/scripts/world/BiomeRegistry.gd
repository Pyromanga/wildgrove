# res://scripts/world/BiomeRegistry.gd
class_name BiomeRegistry

## BiomeRegistry — Statische Sammlung aller Biom-Definitionen.
##
## Kein externes .tres nötig: Biome werden hier code-seitig definiert.
## Vorteil: kein DirAccess/DataManifest-Overhead, sofort refaktorierbar.
##
## Noise-Zuweisung via get_biome_for(temp, humid):
##   temp  –1..1  (kalt → warm)
##   humid –1..1  (trocken → feucht)

const LOG_CAT := "BiomeRegistry"

## Alle registrierten Biome, keyed by biome_id.
static var _biomes: Dictionary = {}
static var _initialized: bool = false

static func get_biome(biome_id: String) -> BiomeDefinition:
	_ensure_init()
	return _biomes.get(biome_id)

## Hauptfunktion: wählt Biom anhand Temperatur + Feuchtigkeit.
static func get_biome_for(temp: float, humid: float) -> BiomeDefinition:
	_ensure_init()
	var id := _resolve_id(temp, humid)
	return _biomes.get(id, _biomes.get("meadow"))

static func get_biome_id_for(temp: float, humid: float) -> String:
	return _resolve_id(temp, humid)

static func _resolve_id(temp: float, humid: float) -> String:
	if temp > 0.6:                        return "desert"
	if temp < -0.5:                       return "winter"
	if humid > 0.5 and temp > 0.0:       return "swamp"
	if humid > 0.3:                       return "dense_forest"
	if humid > 0.0:                       return "forest"
	return "meadow"

static func _ensure_init() -> void:
	if _initialized:
		return
	_initialized = true
	_register_all()

static func _register_all() -> void:
	_register(_make_forest())
	_register(_make_dense_forest())
	_register(_make_meadow())
	_register(_make_desert())
	_register(_make_winter())
	_register(_make_swamp())

static func _register(b: BiomeDefinition) -> void:
	_biomes[b.biome_id] = b

# ─────────────────────────────────────────────
# Biom-Definitionen
# ─────────────────────────────────────────────

static func _make_forest() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "forest"
	b.display_name = "Wald"
	b.terrain_color_grass = Color(0.13, 0.42, 0.12)
	b.terrain_color_dirt  = Color(0.35, 0.22, 0.10)
	b.terrain_color_rock  = Color(0.40, 0.40, 0.38)
	b.prop_chances = {
		"oak_tree":        0.15,
		"fallen_tree":     0.04,
		"mushroom_cluster":0.08,
		"fern":            0.20,
		"rock_boulder":    0.03,
	}
	b.structure_types = ["ruin", "cottage"]
	return b

static func _make_dense_forest() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "dense_forest"
	b.display_name = "Dichter Wald"
	b.terrain_color_grass = Color(0.08, 0.30, 0.08)
	b.terrain_color_dirt  = Color(0.28, 0.18, 0.08)
	b.terrain_color_rock  = Color(0.35, 0.35, 0.33)
	b.fog_density = 0.3
	b.prop_chances = {
		"oak_tree":        0.25,
		"fallen_tree":     0.07,
		"mushroom_cluster":0.12,
		"fern":            0.30,
	}
	return b

static func _make_meadow() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "meadow"
	b.display_name = "Wiese"
	b.terrain_color_grass = Color(0.38, 0.68, 0.20)
	b.terrain_color_dirt  = Color(0.55, 0.42, 0.20)
	b.terrain_color_rock  = Color(0.50, 0.48, 0.45)
	b.prop_chances = {
		"oak_tree":    0.05,
		"rock_boulder":0.02,
	}
	b.structure_types = ["well", "cottage", "barn"]
	return b

static func _make_desert() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "desert"
	b.display_name = "Wüste"
	b.terrain_color_grass = Color(0.78, 0.65, 0.30)
	b.terrain_color_dirt  = Color(0.70, 0.55, 0.25)
	b.terrain_color_rock  = Color(0.65, 0.50, 0.30)
	b.prop_chances = {
		"cactus":      0.10,
		"rock_boulder":0.08,
	}
	return b

static func _make_winter() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "winter"
	b.display_name = "Schnee"
	b.terrain_color_grass = Color(0.85, 0.90, 0.95)
	b.terrain_color_dirt  = Color(0.70, 0.75, 0.80)
	b.terrain_color_rock  = Color(0.60, 0.65, 0.70)
	b.snow_coverage = 1.0
	b.prop_chances = {
		"pine_tree":   0.18,
		"rock_boulder":0.06,
		"fallen_tree": 0.03,
	}
	return b

static func _make_swamp() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "swamp"
	b.display_name = "Sumpf"
	b.terrain_color_grass = Color(0.28, 0.38, 0.12)
	b.terrain_color_dirt  = Color(0.22, 0.28, 0.10)
	b.terrain_color_rock  = Color(0.30, 0.32, 0.22)
	b.fog_density = 0.5
	b.prop_chances = {
		"fallen_tree":      0.10,
		"mushroom_cluster": 0.15,
		"fern":             0.08,
	}
	return b
