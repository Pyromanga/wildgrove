class_name WorldScopeInitializer extends Node

## WorldScopeInitializer — Sitzt in World.tscn als Child-Node.
##
## Einzige Verantwortung: signalisiert wenn der World-Root bereit ist.
## Kein AutoLoad-Zugriff. Kein EventBus. Kein Pull.
##
## CharacterScope connectet sich auf world_ready bevor World.tscn geladen wird.
## Wenn _ready() feuert ist der SceneTree bereit — world_ready.emit() pushed
## den Root nach oben. CharacterScope ruft daraufhin create_world_scope() auf.
##
## Push-Pattern: dieser Node pushed Existenz nach oben, niemand pollt ihn.

## Emittiert einmalig wenn dieser Node im SceneTree bereit ist.
## get_parent() ist zu diesem Zeitpunkt der World-Root (Node3D).
signal world_ready(world_root: Node3D)

func _ready() -> void:
	var root := get_parent()
	if not root is Node3D:
		push_error(
			"WorldScopeInitializer: Parent ist kein Node3D — in World.tscn direkt unter Root einsetzen."
		)
		return
	world_ready.emit(root as Node3D)
	## Nach emit ist dieser Node fertig. Er bleibt im SceneTree für Teardown-Signale
	## aber hat keine weitere aktive Rolle.
