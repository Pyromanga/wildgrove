extends StaticBody3D
class_name QuestNPC

## QuestNPC — Stationärer Quest-Geber. Koordinator-Klasse.
##
## Delegiert an:
##   NPCVisualBuilder          → 3D-Visuals aufbauen
##   QuestNPCDialogController  → Dialog-State-Machine
##
## EventBus-Zugriff: via _bus (IEventBus), Pflicht-Dep injiziert durch on_spawn(ctx).

const LOG_CAT := "QuestNPC"

@export var quest_id:         String = "quest_woodcutter_intro"
@export var quest_obj_id:     String = "obj_chop_trees"
@export var npc_display_name: String = "Waldläufer Erik"
## Stabile ID für TALK-Quest-Objectives (QuestObjective.target_id) — unabhängig
## von npc_display_name, damit Lokalisierung/Umbenennung Quest-Daten nicht bricht.
@export var npc_id:           String = "erik_woodcutter"

var _dialog: QuestNPCDialogController
var _dialog_label: Label3D
var _bus: IEventBus = null  ## Pflicht-Dep, injiziert via on_spawn(ctx). Für Tests: MockEventBus.

func _ready() -> void:
	name = "QuestNPC_" + npc_display_name.replace(" ", "_")
	add_to_group("npcs")

	_dialog_label = NPCVisualBuilder.build(self, npc_display_name)
	# QuestNPCDialogController braucht IEventBus — wird in on_spawn() erzeugt,
	# da _bus erst dort garantiert gesetzt ist (Pflicht-Dep via EntityContext).

	_build_collision()
	_setup_interactable()
	AppLogger.log_info("QuestNPC '%s' bereit." % npc_display_name, LOG_CAT)

func _connect_bus() -> void:
	var q := _bus.quest()
	q.quest_completed.connect(_on_quest_completed)
	q.quest_objective_updated.connect(_on_objective_updated)
	q.quest_start_failed.connect(_on_quest_start_failed)

func _disconnect_bus() -> void:
	if _bus == null:
		return
	var q := _bus.quest()
	if q.quest_completed.is_connected(_on_quest_completed):
		q.quest_completed.disconnect(_on_quest_completed)
	if q.quest_objective_updated.is_connected(_on_objective_updated):
		q.quest_objective_updated.disconnect(_on_objective_updated)
	if q.quest_start_failed.is_connected(_on_quest_start_failed):
		q.quest_start_failed.disconnect(_on_quest_start_failed)

# ─────────────────────────────────────────────
# EventBus-Handler
# ─────────────────────────────────────────────

func _on_objective_updated(q_id: String, obj_id: String, current: int, _required: int) -> void:
	if q_id == quest_id and obj_id == quest_obj_id:
		_dialog.on_objective_updated(q_id, current)

func _on_quest_start_failed(q_id: String, reason: String) -> void:
	if q_id == quest_id:
		_dialog.on_quest_start_failed(reason)
		AppLogger.log_warn("Quest-Start fehlgeschlagen '%s': %s" % [q_id, reason], LOG_CAT)

func _on_quest_completed(q_id: String, _reward: QuestReward) -> void:
	_dialog.on_quest_completed(q_id)
	if q_id == quest_id:
		AppLogger.log_info("Quest '%s' abgeschlossen — NPC-Status aktualisiert." % q_id, LOG_CAT)

# ─────────────────────────────────────────────
# Interaktion
# ─────────────────────────────────────────────

func _setup_interactable() -> void:
	var d := InteractableData.new()
	d.id          = "talk_quest_npc"
	d.label       = "Mit %s sprechen" % npc_display_name
	d.duration    = 0.3
	d.xp_type     = "none"
	d.xp_amount   = 0
	d.drops       = {}
	d.inspect_text = "%s. Er sieht aus als hätte er eine Aufgabe für dich." % npc_display_name
	var comp := InteractableComponent.new()
	comp.data = d
	add_child(comp)

## Aufgerufen von InteractableComponent nach Abschluss der Rede-Interaktion.
func _on_interacted(action_id: String) -> void:
	if action_id != "talk_quest_npc":
		return
	if not is_instance_valid(_dialog):
		AppLogger.log_warn("_on_interacted vor on_spawn() — _dialog nicht initialisiert.", LOG_CAT)
		return
	_dialog.on_interact()
	if _bus != null:
		_bus.quest().emit_npc_talked_to(npc_id)
	AppLogger.log_info("NPC interagiert, State: %s" % _dialog.state, LOG_CAT)

# ─────────────────────────────────────────────
# Collision
# ─────────────────────────────────────────────

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.35
	sh.height = 1.5
	col.shape = sh
	col.position.y = 0.75
	add_child(col)

# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────

func on_spawn(_cfg: Dictionary, ctx: IEntityContext = null) -> void:
	if is_instance_valid(ctx) and ctx.has_method("get_event_bus"):
		_bus = ctx.get_event_bus() as IEventBus
	if _bus == null:
		AppLogger.log_error(
			"QuestNPC.on_spawn(): kein IEventBus im EntityContext — Spawn ohne DI nicht unterstützt.",
			LOG_CAT
		)
		return
	_dialog = QuestNPCDialogController.new(quest_id, _dialog_label, get_tree(), _bus)
	_connect_bus()

func on_despawn() -> void:
	_disconnect_bus()
