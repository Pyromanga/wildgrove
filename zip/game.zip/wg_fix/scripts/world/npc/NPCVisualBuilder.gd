class_name NPCVisualBuilder
extends RefCounted

## NPCVisualBuilder — Erstellt die 3D-Visuals für einen Quest-NPC.
##
## Ausgelagert aus QuestNPC._build_visuals() (v28).
## Analog zu AnimalVisualBuilder — statisch, kein State.
##
## Erzeugt: Körper-Kapsel, Kopf-Kugel, Hut-Zylinder, Name-Label3D,
##           Dialog-Label3D (returned als Referenz).

static func build(parent: Node3D, display_name: String) -> Label3D:
	# Körper
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.25, 0.40, 0.65)
	var body_mesh := CapsuleMesh.new()
	body_mesh.radius = 0.28
	body_mesh.height = 1.1
	var body_mi := MeshInstance3D.new()
	body_mi.mesh = body_mesh
	body_mi.material_override = body_mat
	body_mi.position.y = 0.95
	parent.add_child(body_mi)

	# Kopf
	var head_mat := StandardMaterial3D.new()
	head_mat.albedo_color = Color(0.88, 0.72, 0.58)
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.22
	head_mesh.height = 0.44
	var head_mi := MeshInstance3D.new()
	head_mi.mesh = head_mesh
	head_mi.material_override = head_mat
	head_mi.position.y = 1.72
	parent.add_child(head_mi)

	# Hut
	var hat_mat := StandardMaterial3D.new()
	hat_mat.albedo_color = Color(0.25, 0.18, 0.08)
	var hat_mesh := CylinderMesh.new()
	hat_mesh.top_radius    = 0.20
	hat_mesh.bottom_radius = 0.28
	hat_mesh.height        = 0.25
	var hat_mi := MeshInstance3D.new()
	hat_mi.mesh = hat_mesh
	hat_mi.material_override = hat_mat
	hat_mi.position.y = 1.98
	parent.add_child(hat_mi)

	# Name-Label
	var name_lbl := Label3D.new()
	name_lbl.text      = display_name
	name_lbl.font_size = 48
	name_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_lbl.modulate  = Color(1.0, 0.9, 0.3)
	name_lbl.position.y = 2.4
	parent.add_child(name_lbl)

	# Dialog-Label (Referenz zurückgeben, da QuestNPC damit arbeitet)
	var dialog_lbl := Label3D.new()
	dialog_lbl.text      = ""
	dialog_lbl.font_size = 36
	dialog_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	dialog_lbl.modulate  = Color(1.0, 1.0, 1.0, 0.9)
	dialog_lbl.position.y = 2.9
	dialog_lbl.visible    = false
	parent.add_child(dialog_lbl)

	return dialog_lbl
