class_name AnimalCatcher
extends RefCounted

## AnimalCatcher — Utility zum Umwandeln eines gefangenen Tieres in ein Pet.
## Wird von der Fangen-Aktion in AnimalBase aufgerufen.

const LOG_CAT := "AnimalCatcher"

static func catch_animal(animal: AnimalBase) -> PetComponent:
	if not is_instance_valid(animal):
		return null

	var pet := PetComponent.new()
	pet._color     = animal._color
	pet._body_size = animal._body_size
	pet._name      = "Zahmes " + animal.name
	pet._speed     = animal._speed * 0.85
	pet.global_position = animal.global_position

	# Tier entfernen
	var world := animal.get_parent()
	if is_instance_valid(world):
		world.add_child(pet)
	animal.queue_free()

	Logger.log_info("Tier gefangen → Pet '%s' erstellt." % pet._name, LOG_CAT)
	EventBus.world.emit_interaction_reward_text("Du hast ein %s gefangen!" % pet._name)
	return pet
