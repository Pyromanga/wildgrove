class_name PetRestorer
extends RefCounted

## PetRestorer — Stellt gespeicherte Pets beim Laden der Welt wieder her.
##
## Ausgelagert aus WorldSpawner._restore_pets() (v28).
## Liest Pet-Daten aus WorldData.get_meta("saved_pets") und
## instanziiert PetComponent-Nodes im world_root.

const LOG_CAT := "PetRestorer"

var _data: WorldData

func _init(data: WorldData) -> void:
	_data = data

func restore(world_root: Node3D) -> void:
	if not is_instance_valid(_data) or not _data.has_meta("saved_pets"):
		return
	var pet_data: Variant = _data.get_meta("saved_pets")
	if not pet_data is Array:
		return
	for entry in pet_data:
		if not entry is Dictionary:
			continue
		var pos: Variant = str_to_var(entry.get("pos", "Vector3(0,1,0)"))
		if not pos is Vector3:
			continue
		var pet := PetComponent.new()
		pet._name = entry.get("name", "Pet")
		var col: Variant = str_to_var(entry.get("color", "Color(0.7,0.5,0.3,1)"))
		if col is Color:
			pet._color = col
		pet.position = pos
		world_root.add_child(pet)
	AppLogger.log_info("Pets wiederhergestellt: %d." % (pet_data as Array).size(), LOG_CAT)
