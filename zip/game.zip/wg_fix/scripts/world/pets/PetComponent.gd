class_name PetComponent
extends CharacterBody3D

## PetComponent — Ein Pet das dem Spieler folgt.
## Wird instanziiert wenn ein Tier gefangen wird.

const LOG_CAT := "Pet"
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)

var _color:     Color   = Color(0.7, 0.5, 0.3)
var _body_size: Vector3 = Vector3(0.3, 0.4, 0.3)
var _name:      String  = "Pet"

var _follow_distance: float = 2.5
var _speed:           float = 4.0
var _idle_radius:     float = 1.5

## AnimalBase hat dieses Muster bereits korrekt; PetComponent zog nicht nach.
## Bei 10 Pets = 10 get_nodes_in_group()-Aufrufe pro Physik-Frame ohne Cache.
var _player_ref: Node3D = null

func _ready() -> void:
	add_to_group("pets")
	set_multiplayer_authority(1)
	_build_visuals()
	_build_collision()
	# Cache einmalig befüllen — Player ist beim Pet-Spawn bereits in der Szene.
	_player_ref = get_tree().get_first_node_in_group("player") as Node3D
	AppLogger.log_debug("Pet '%s' bereit." % _name, LOG_CAT)

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0

	var player := _player_ref
	if not is_instance_valid(player):
		# Fallback: erneut suchen falls Player respawned ist (z.B. nach Tod)
		_player_ref = get_tree().get_first_node_in_group("player") as Node3D
		player = _player_ref
	if is_instance_valid(player):
		var dist := global_position.distance_to(player.global_position)
		if dist > _follow_distance:
			var dir: Vector3 = player.global_position - global_position
			dir.y = 0.0
			if dir.length_squared() > 0.01:
				dir = dir.normalized()
				var t: float = min(1.0, (dist - _follow_distance) / 3.0)
				var spd: float = _speed * t
				velocity.x = move_toward(velocity.x, dir.x * spd, 12.0 * delta)
				velocity.z = move_toward(velocity.z, dir.z * spd, 12.0 * delta)
				look_at(global_position + dir, Vector3.UP)
		else:
			velocity.x = move_toward(velocity.x, 0.0, 6.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 6.0 * delta)

	move_and_slide()

func get_save_state() -> Dictionary:
	return {
		"pos":   var_to_str(global_position),
		"color": var_to_str(_color),
		"name":  _name,
	}

func _build_visuals() -> void:
	var bm := CapsuleMesh.new()
	bm.radius = _body_size.x * 0.5
	bm.height = _body_size.y
	var mat := StandardMaterial3D.new()
	mat.albedo_color = _color
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position.y = _body_size.y * 0.5
	add_child(mi)

	var lbl := Label3D.new()
	lbl.text = _name
	lbl.font_size = 36
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(0.6, 1.0, 0.6)
	lbl.position.y = _body_size.y * 1.3
	add_child(lbl)

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh := CapsuleShape3D.new()
	sh.radius = _body_size.x * 0.4
	sh.height = _body_size.y
	col.shape = sh
	col.position.y = _body_size.y * 0.5
	add_child(col)
