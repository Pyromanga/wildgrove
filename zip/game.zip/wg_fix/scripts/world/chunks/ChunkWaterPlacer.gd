class_name ChunkWaterPlacer
extends RefCounted

## ChunkWaterPlacer — Platziert WaterBodies in Terrain-Senken eines Chunks.
##
## Extrahiert aus ChunkManager._place_chunk_water().
## Analog zu WorldSpawner._place_water_bodies(), aber für dynamisch geladene Chunks.
##
## Strategie: Tiefpunkte (h < -0.5) samplen → zu einem Becken zusammenfassen
## → WaterBody.place() wenn Becken breit genug (≥ 4m in X und Z).

const LOG_CAT := "ChunkWaterPlacer"

## Platziert WaterBodies für chunk_node.
## center: Chunk-Zentrum (Vector2), gen: TerrainGenerator des Chunks.
func place_water(chunk_node: Node3D, center: Vector2, gen: TerrainGenerator) -> void:
	if not is_instance_valid(gen):
		return

	var sample_step: float   = gen.size / 6.0
	var low_points: Array[Vector3] = _sample_low_points(gen, sample_step)

	if low_points.is_empty():
		return

	var basin := _compute_basin(low_points)
	var w: float = max(basin["max_x"] - basin["min_x"] + sample_step, sample_step)
	var l: float = max(basin["max_z"] - basin["min_z"] + sample_step, sample_step)
	if w < 4.0 or l < 4.0:
		return

	var wx: float = center.x + (basin["min_x"] + basin["max_x"]) * 0.5
	var wz: float = center.y + (basin["min_z"] + basin["max_z"]) * 0.5
	# y-Position: Terrain-Höhe der Senke + kleiner Offset
	var basin_h: float = gen.get_height_at((basin["min_x"] + basin["max_x"]) * 0.5,
		(basin["min_z"] + basin["max_z"]) * 0.5) + 0.1
	WaterBody.place(chunk_node, Vector3(wx, basin_h, wz), Vector3(w, 4.0, l))

func _sample_low_points(gen: TerrainGenerator, sample_step: float) -> Array[Vector3]:
	var result: Array[Vector3] = []
	for zi in range(-3, 4):
		for xi in range(-3, 4):
			var lx: float = xi * sample_step
			var lz: float = zi * sample_step
			if gen.get_height_at(lx, lz) < -0.5:
				result.append(Vector3(lx, 0.0, lz))
	return result

func _compute_basin(low_points: Array[Vector3]) -> Dictionary:
	var min_x := INF; var max_x := -INF
	var min_z := INF; var max_z := -INF
	for p in low_points:
		min_x = minf(min_x, p.x); max_x = maxf(max_x, p.x)
		min_z = minf(min_z, p.z); max_z = maxf(max_z, p.z)
	return {"min_x": min_x, "max_x": max_x, "min_z": min_z, "max_z": max_z}
