class_name WorldSaveHandler
## implements ISaveProvider
extends RefCounted

## WorldSaveHandler — Save/Restore-Logik für die Spielwelt.
##
## Ausgelagert aus WorldService (v28).
## Verantwortlich für:
##   - get_save_data()  → serialisiert WorldData + WorldTimeService
##   - restore_world()  → deserialisiert gespeicherten Zustand zurück in WorldData
##
## Kein Service, kein Node. Wird von WorldService als Hilfsklasse genutzt.

const LOG_CAT := "WorldSave"

var _data: WorldData
var _time: WorldTimeService

func _init(data: WorldData, time: WorldTimeService) -> void:
	_data = data
	_time = time

# ─────────────────────────────────────────────
# Speichern
# ─────────────────────────────────────────────

func get_save_data() -> Dictionary:
	var tree_strings: Array[String] = []
	for pos in _data.tree_positions:
		tree_strings.append(var_to_str(pos))

	var pets_raw: Variant = _data.get_meta("saved_pets") if _data.has_meta("saved_pets") else []

	var time_data := _time.get_save_data()
	return {
		"day_time":       time_data["day_time"],
		"day_count":      time_data["day_count"],
		"tree_positions": tree_strings,
		"ore_positions":  var_to_str(_data.ore_positions),
		"player_pos":     var_to_str(_data.player_position),
		"harvested":      var_to_str(_data.harvested_objects),
		"saved_pets":     var_to_str(pets_raw),
	}

# ─────────────────────────────────────────────
# Wiederherstellen
# ─────────────────────────────────────────────

func restore_world(state: Dictionary) -> void:
	_time.restore(state)

	var tree_strings: Variant = state.get("tree_positions", [])
	if tree_strings is Array:
		_data.tree_positions = []
		for s in tree_strings:
			var pos: Variant = str_to_var(s)
			if pos is Vector3:
				_data.tree_positions.append(pos)

	var ore_raw: Variant = str_to_var(state.get("ore_positions", "[]"))
	if ore_raw is Array:
		_data.ore_positions = []
		for p in ore_raw:
			if p is Vector3:
				_data.ore_positions.append(p)

	var player_pos_raw: Variant = str_to_var(state.get("player_pos", "Vector3(0,0,0)"))
	_data.player_position = player_pos_raw if player_pos_raw is Vector3 else Vector3.ZERO

	var harvested_raw: Variant = str_to_var(state.get("harvested", "{}"))
	_data.harvested_objects = harvested_raw if harvested_raw is Dictionary else {}

	var pets_raw: Variant = str_to_var(state.get("saved_pets", "[]"))
	if pets_raw is Array:
		_data.set_meta("saved_pets", pets_raw)

	AppLogger.log_info(
		"Welt geladen: Tag %d %s, %d Bäume, %d Erze." % [
			_time.day_count, _time.get_formatted_time(),
			_data.tree_positions.size(), _data.ore_positions.size()
		], LOG_CAT
	)
