extends HarvestableEntity
class_name IronOre

## IronOre — Abbaubarer Erzblock (Mining-Interaktion).
## Lifecycle, Despawn und Harvest-State kommen von HarvestableEntity.
## Hier: nur Typ-ID, InteractableData und Visuals.

func _get_entity_type_id() -> String:
	return "iron_ore"

func _build_interactable_data() -> InteractableData:
	var d := InteractableData.new()
	d.id           = "mine_iron"
	d.label        = "Eisenerz abbauen"
	d.duration     = 4.0
	d.xp_type      = "mining"
	d.xp_amount    = 40
	d.drops        = {"iron_ore": 1}
	d.inspect_text = "Ein Eisenerzblock. Die rötlich-braunen Adern im Stein deuten auf reiche Eisenvorkommen hin."
	return d

func _build_visuals() -> void:
	_add_placeholder_box(Vector3(0.8, 0.8, 0.8), Color(0.6, 0.5, 0.4))
	AppLogger.log_debug("IronOre BoxMesh 0.8m erstellt.", "iron_ore")
