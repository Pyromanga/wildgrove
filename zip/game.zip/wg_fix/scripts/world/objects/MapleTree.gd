extends HarvestableEntity
class_name MapleTree

## MapleTree — Fällbarer Ahorn (höheres Level, mehr XP als Eiche).

func _get_entity_type_id() -> String:
	return "maple_tree"

func _build_interactable_data() -> InteractableData:
	var d := InteractableData.new()
	d.id           = "chop"
	d.label        = "Ahorn fällen"
	d.duration     = 5.0
	d.xp_type      = "woodcutting"
	d.xp_amount    = 60
	d.drops        = {"log_maple": 3}
	d.inspect_text = "Ein alter Ahorn. Sein Stamm ist breit und knorrig — das Holz ist hart und wertvoll."
	return d

func _build_visuals() -> void:
	var factory: Factory3D = _ctx.get_factory3d() if is_instance_valid(_ctx) else null
	if is_instance_valid(factory):
		factory.create_simple_tree(self)
	else:
		Logger.log_warn("Factory3D nicht verfügbar — MapleTree Placeholder.", "maple_tree")
		_add_placeholder_cylinder(0.20, 2.0, Color(0.45, 0.22, 0.08))
