class_name WorldData
extends RefCounted

## WorldData — Reines Daten-Objekt für den Weltzustand.
##
## KEIN Node-Overhead — extends RefCounted (kein SceneTree nötig).
##
## KEY-SCHEMA (einheitlich seit Fix P0):
##   Alle harvest-Keys verwenden das generische Format:
##     "%s_%d_%d_%d" % [type_id, int(x), int(y), int(z)]
##   Beispiele: "oak_tree_5_0_5", "iron_ore_-3_0_2", "copper_ore_8_0_4"
##
##   mark_harvested() schreibt dieses Format (via HarvestableEntity.on_despawn).
##   is_harvested_by_type() und unmark_harvested() lesen dasselbe Format.
##   is_tree_harvested()/is_ore_harvested() delegieren auf make_key() für
##   Abwärtskompatibilität mit WorldSpawner (spawn_all-Filter).
##
## Langfristig: Entity-UUIDs statt positions-derived Keys (ChunkService-Scope).

var tree_positions:    Array[Vector3] = []
## Typisierte Positionen: { type_id: Array[Vector3] }
## Ermöglicht gemischte Baumtypen an unterschiedlichen Positionen.
var typed_tree_positions: Dictionary = {}
var ore_positions:     Array[Vector3] = []
## Typisierte Erzpositionen: { type_id: Array[Vector3] }
var typed_ore_positions: Dictionary = {}
var player_position:   Vector3 = Vector3.ZERO
## Set once at world creation. Passed to ChunkManager so terrain is deterministic
## across sessions, reloads, and between server and client.
var world_seed:        int = 0
## Format: { "oak_tree_5_0_5": true, "iron_ore_-3_0_2": true }
var harvested_objects: Dictionary = {}

func add_tree(pos: Vector3) -> void:
	if not pos in tree_positions:
		tree_positions.append(pos)

## Fügt eine typisierte Baum-Position ein.
## type_id: z.B. "oak_tree", "willow_tree", "maple_tree"
func add_typed_tree(type_id: String, pos: Vector3) -> void:
	add_tree(pos)  # Abwärtskompatibilität: ungefiltert für is_tree_harvested()
	if not typed_tree_positions.has(type_id):
		typed_tree_positions[type_id] = []
	if not pos in typed_tree_positions[type_id]:
		typed_tree_positions[type_id].append(pos)

func add_ore(pos: Vector3) -> void:
	if not pos in ore_positions:
		ore_positions.append(pos)

## Fügt eine typisierte Erz-Position ein.
## type_id: z.B. "iron_ore", "copper_ore"
func add_typed_ore(type_id: String, pos: Vector3) -> void:
	add_ore(pos)  # Abwärtskompatibilität
	if not typed_ore_positions.has(type_id):
		typed_ore_positions[type_id] = []
	if not pos in typed_ore_positions[type_id]:
		typed_ore_positions[type_id].append(pos)

## Einheitlicher Harvest-Marker. Format: "type_id_x_y_z"
## Wird von HarvestableEntity.on_despawn() und WorldService.mark_harvested() aufgerufen.
func mark_harvested(key: String) -> void:
	harvested_objects[key] = true
	AppLogger.log_debug("Als geerntet markiert: '%s'." % key, "WorldData")

## Abwärtskompatibler Wrapper — schreibt ins neue generische Format.
func mark_tree_harvested(pos: Vector3) -> void:
	mark_harvested(make_key("oak_tree", pos))

## Abwärtskompatibler Wrapper — schreibt ins neue generische Format.
func mark_ore_harvested(pos: Vector3) -> void:
	mark_harvested(make_key("iron_ore", pos))

## Prüft ob eine Position für einen bestimmten Typ geerntet wurde.
## Verwendet das einheitliche Schema: "type_id_x_y_z"
func is_harvested_by_type(type_id: String, pos: Vector3) -> bool:
	return harvested_objects.has(make_key(type_id, pos))

## Abwärtskompatibel für WorldSpawner.spawn_all() (oak_tree-Filterung).
## Delegiert auf is_harvested_by_type mit "oak_tree".
func is_tree_harvested(pos: Vector3) -> bool:
	return is_harvested_by_type("oak_tree", pos)

## Abwärtskompatibel für WorldSpawner.spawn_all() (iron_ore-Filterung).
## Delegiert auf is_harvested_by_type mit "iron_ore".
func is_ore_harvested(pos: Vector3) -> bool:
	return is_harvested_by_type("iron_ore", pos)

## Legacy-Kompatibilität: generischer Key-Check per String.
func is_harvested(key: String) -> bool:
	return harvested_objects.has(key)

## Entfernt den Harvested-Marker — aufgerufen durch RespawnService._remove_cb.
## Verwendet einheitlich das generische Schema für alle type_ids.
func unmark_harvested(type_id: String, pos: Vector3) -> void:
	var key := make_key(type_id, pos)
	if harvested_objects.erase(key):
		AppLogger.log_debug("Harvested-Marker '%s' entfernt." % key, "WorldData")
	else:
		AppLogger.log_warn("unmark_harvested: Key '%s' nicht gefunden." % key, "WorldData")

func get_tree_count() -> int:
	return tree_positions.size()

func get_ore_count() -> int:
	return ore_positions.size()

# ─────────────────────────────────────────────
# Intern — deterministische Key-Generierung
# ─────────────────────────────────────────────

## Einheitlicher Key für alle Entity-Typen.
## Format: "type_id_x_y_z" — locale-unabhängig, int-gecasted.
## Beispiel: make_key("oak_tree", Vector3(5,0,5)) → "oak_tree_5_0_5"
static func make_key(type_id: String, pos: Vector3) -> String:
	return "%s_%d_%d_%d" % [type_id, int(pos.x), int(pos.y), int(pos.z)]
