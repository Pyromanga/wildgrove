extends ServiceNode
# justified: Thread-Ergebnisse via call_deferred auf Main-Thread; WorldScene als Child-Node.
class_name WorldGenerationService

## WorldGenerationService — Prozedurale Welt-Generierung.
##
## Verantwortung:
##   - Positionen für Entities (Bäume, Erze) generieren
##   - Seed-basiert und damit reproduzierbar (selber Seed = selbe Welt)
##   - Verhindert Überlappungen durch Mindestabstand-Prüfung
##
## Integration:
##   WorldService ruft generate_world(seed_value, data) in _spawn_world_entities() auf
##   wenn kein Savegame vorhanden ist.
##
## Abhängigkeiten (deps): [] — reine Logik, kein Service nötig

const LOG_CAT := "WorldGen"

var world_half_size: float      = 30.0
var min_tree_distance: float    = 4.0
var min_ore_distance: float     = 5.0
var min_spawn_clearance: float  = 6.0
var tree_count: int             = 12
var ore_count: int              = 5

## Callback für Terrain-Höhe — wird pro Aufruf an generate_world() übergeben.
## Kein persistentes Feld mehr: verhindert das Fenster, in dem der Service
## halbfertig konfiguriert ist (temporale Kopplung, Architekturplan 1.5).
var _active_height_cb: Callable = Callable()  # nur während generate_world()-Aufruf gültig

signal generation_complete(data: WorldData)
signal generation_failed(reason: String)

var _thread:     Thread  = null
var _thread_seed: int    = 0
var _thread_data: WorldData = null

func configure(_deps: ServiceDeps) -> void:
	AppLogger.log_debug("WorldGenerationService konfiguriert.", LOG_CAT)

func on_ready() -> void:
	AppLogger.log_info("WorldGenerationService bereit.", LOG_CAT)

## Generiert eine komplette Welt synchron (Haupt-Thread, Legacy).
## Für MMORPG-Chunk-Größen: generate_world_async() verwenden!
## Wenn data == null wird eine neue WorldData erstellt.
## height_cb: Callable(x: float, z: float) -> float — optional, Fallback y=0.
func generate_world(seed_value: int, data: WorldData = null, height_cb: Callable = Callable()) -> WorldData:
	if data == null:
		data = WorldData.new()
	_active_height_cb = height_cb

	var t := AppLogger.log_begin("WorldGenerationService.generate_world(seed=%d)" % seed_value, LOG_CAT)

	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	# Bäume generieren
	data.tree_positions = _generate_positions(
		rng, tree_count, min_tree_distance, min_spawn_clearance, []
	)
	AppLogger.log_debug(
		"%d Baum-Positionen generiert." % data.tree_positions.size(), LOG_CAT
	)

	# Erze generieren — mit Abstand zu Bäumen
	data.ore_positions = _generate_positions(
		rng, ore_count, min_ore_distance, min_spawn_clearance, data.tree_positions
	)
	AppLogger.log_debug(
		"%d Erz-Positionen generiert." % data.ore_positions.size(), LOG_CAT
	)

	AppLogger.log_end("WorldGenerationService.generate_world()", t, LOG_CAT)
	AppLogger.log_info(
		"Welt generiert (Seed %d): %d Bäume, %d Erze." % [
			seed_value,
			data.tree_positions.size(),
			data.ore_positions.size()
		],
		LOG_CAT
	)
	return data

## Generiert einen deterministischen Seed aus einem String (z.B. Spieler-Name).
static func seed_from_string(s: String) -> int:
	var hash_val := 0
	for i in range(s.length()):
		hash_val = (hash_val * 31 + s.unicode_at(i)) & 0x7FFFFFFF
	return hash_val

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _generate_positions(
	rng:             RandomNumberGenerator,
	count:           int,
	min_dist:        float,
	spawn_clearance: float,
	avoid_positions: Array[Vector3]
) -> Array[Vector3]:
	## Platziert `count` Positionen innerhalb der Weltgrenzen.
	## Garantiert Mindestabstand zueinander und zu avoid_positions.
	## Bricht nach max_attempts ab um Endlosschleifen zu vermeiden.

	var placed: Array[Vector3] = []
	var max_attempts := count * 30  # 30 Versuche pro gewünschter Position
	var attempts     := 0

	while placed.size() < count and attempts < max_attempts:
		attempts += 1

		var x := rng.randf_range(-world_half_size, world_half_size)
		var z := rng.randf_range(-world_half_size, world_half_size)
		var candidate := Vector3(x, 0.0, z)

		# Spawn-Clearance prüfen (Abstand vom Ursprung)
		if candidate.length() < spawn_clearance:
			continue

		# Nicht ins Wasser spawnen — Terrain-Höhe prüfen
		if _active_height_cb.is_valid():
			var h: float = _active_height_cb.call(x, z)
			# water_level ≈ 0.8 — Entities sollen nur auf Land spawnen
			if h < 0.3:
				continue
			candidate.y = h
		
		# Abstand zu bereits platzierten Positionen
		if not _is_far_enough(candidate, placed, min_dist):
			continue

		# Abstand zu avoid_positions (z.B. Bäume wenn Erze platziert werden)
		if not _is_far_enough(candidate, avoid_positions, min_dist):
			continue

		placed.append(candidate)

	if placed.size() < count:
		AppLogger.log_warn(
			"Nur %d/%d Positionen platziert (max_attempts=%d erreicht)." % [
				placed.size(), count, max_attempts
			],
			LOG_CAT
		)

	return placed

static func _is_far_enough(candidate: Vector3, others: Array[Vector3], min_dist: float) -> bool:
	for other in others:
		if candidate.distance_to(other) < min_dist:
			return false
	return true

# ─────────────────────────────────────────────
# ─────────────────────────────────────────────

## Startet die Welt-Generierung im Hintergrund-Thread.
## Emittiert generation_complete(data) wenn fertig.
## Emittiert generation_failed(reason) bei Fehler.
##
## WorldService.on_world_scene_ready() verbindet sich mit generation_complete:
## height_cb: Callable(x: float, z: float) -> float — direkt übergeben,
## kein persistentes Feld mehr (verhindert temporale Kopplung via set_height_callback).
func generate_world_async(seed_value: int, data: WorldData = null, height_cb: Callable = Callable()) -> void:
	if is_instance_valid(_thread) and _thread.is_started():
		AppLogger.log_warn("generate_world_async(): Thread läuft bereits — Aufruf ignoriert.", LOG_CAT)
		return

	_thread_seed = seed_value
	_thread_data = data if data != null else WorldData.new()
	_active_height_cb = height_cb

	_thread = Thread.new()
	_thread.start(_thread_generate.bind(_thread_seed, _thread_data))
	AppLogger.log_info("Welt-Generierung gestartet (Thread, seed=%d)." % seed_value, LOG_CAT)

## Wird aufgerufen wenn der Thread fertig ist (via call_deferred).
## Läuft auf dem Main-Thread — signal emission ist hier sicher.
func _on_thread_done(result: WorldData) -> void:
	# Thread joinen bevor wir den Pointer freigeben
	if is_instance_valid(_thread):
		_thread.wait_to_finish()
		_thread = null

	if is_instance_valid(result):
		AppLogger.log_info("Welt-Generierung abgeschlossen (Thread).", LOG_CAT)
		generation_complete.emit(result)
	else:
		var reason := "WorldData ist null nach Thread-Ausführung."
		AppLogger.log_error(reason, LOG_CAT)
		generation_failed.emit(reason)

## Thread-Arbeiter — läuft NICHT auf dem Main-Thread.
## WICHTIG: Kein AppLogger-Aufruf (nicht thread-safe), kein Node-Zugriff.
## Gibt das fertige WorldData-Objekt zurück — wird via call_deferred weitergegeben.
func _thread_generate(seed_value: int, data: WorldData) -> void:
	var result: WorldData = generate_world(seed_value, data)
	# call_deferred: zurück auf Main-Thread für signal emission
	call_deferred("_on_thread_done", result)

## Phase 7: Cleanup — Thread sauber joinen falls noch aktiv.
func on_cleanup() -> void:
	if is_instance_valid(_thread) and _thread.is_started():
		AppLogger.log_warn("on_cleanup(): Thread noch aktiv — warte auf Finish.", LOG_CAT)
		_thread.wait_to_finish()
	_thread = null
	AppLogger.log_debug("WorldGenerationService bereinigt.", LOG_CAT)
