class_name EnemyAttack
extends RefCounted

## EnemyAttack — Interaktions-Setup für EnemyNPC.
##
## VERANTWORTUNG:
##   setup_interactable() → baut InteractableData + InteractableComponent

const LOG_CAT := "EnemyAttack"

static func setup_interactable(parent: Node3D) -> void:
	var d := InteractableData.new()
	d.id           = "attack_enemy"
	d.label        = "Angreifen"
	d.duration     = 0.7
	d.xp_type      = "combat"
	d.xp_amount    = 5
	d.drops        = {}
	d.inspect_text = "Ein Goblin. Feindselig und gefährlich."
	var comp := InteractableComponent.new()
	comp.name = "AttackInteractable"
	comp.data = d
	parent.add_child(comp)
	# KEIN globales Signal-Connect hier — parent.on_interacted() wird von
	# InteractableComponent via _handle_completion() → get_parent()._on_interacted() aufgerufen.
