class_name EnemyVisuals
extends RefCounted

## EnemyVisuals — Baut das visuelle Erscheinungsbild eines EnemyNPC.
## Extrahiert aus EnemyNPC.gd damit die KI-Logik dort nicht von Mesh-Code überwuchert wird.

var _health_bar: MeshInstance3D

func build(parent: Node3D, color: Color, max_health: int, label_text: String) -> void:
	_build_body(parent, color)
	_build_health_bar(parent)
	_build_label(parent, label_text)

func update_health_bar(current: int, maximum: int) -> void:
	if not is_instance_valid(_health_bar):
		return
	var ratio: float = float(current) / float(maximum)
	_health_bar.scale.x = maxf(0.05, ratio)
	var mat := _health_bar.material_override as StandardMaterial3D
	if mat:
		mat.albedo_color = Color(1.0 - ratio, ratio * 0.8, 0.1)

func _build_body(parent: Node3D, color: Color) -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	var bm := CapsuleMesh.new()
	bm.radius = 0.30
	bm.height = 1.0
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position.y = 0.7
	parent.add_child(mi)

func _build_health_bar(parent: Node3D) -> void:
	var bar_mesh := BoxMesh.new()
	bar_mesh.size = Vector3(0.8, 0.06, 0.04)
	var bar_mat := StandardMaterial3D.new()
	bar_mat.albedo_color   = Color(0.9, 0.1, 0.1)
	bar_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	_health_bar = MeshInstance3D.new()
	_health_bar.mesh = bar_mesh
	_health_bar.material_override = bar_mat
	_health_bar.position.y = 1.6
	parent.add_child(_health_bar)

func _build_label(parent: Node3D, text: String) -> void:
	var lbl := Label3D.new()
	lbl.text       = text
	lbl.font_size  = 40
	lbl.billboard  = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate   = Color(1, 0.4, 0.4)
	lbl.position.y = 1.85
	parent.add_child(lbl)
