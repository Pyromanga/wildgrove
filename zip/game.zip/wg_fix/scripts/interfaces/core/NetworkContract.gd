# res://scripts/interfaces/core/NetworkContract.gd
class_name NetworkContract extends RefCounted

## NetworkContract — Definiert die Authority-Grenze vor dem Network-Layer.
##
## Definiert die Authority-Grenze: welche Systeme server-autoritativ sind,
## welche client-autoritativ, und wie der RPC-Kontrakt aussieht.
##
## VERWENDUNG:
##   Kein Runtime-Code — diese Klasse ist ein lebendiges Architektur-Dokument
##   und Linting-Hilfe (static assertions, Helper-Methoden).
##
## KONVENTION (R11):
##   request_*()                  — Methoden die in Tier 2/3 via RPC an die Autorität gehen.
##                                  In Tier 1 (Solo): synchroner direkter Aufruf.
##   receive_*_from_network()     — ÖFFENTLICHE Einstiegspunkte für NetworkBridge._rpc_*().
##                                  Delegieren intern an _on_*_confirmed().
##                                  NetworkBridge darf NUR diese Methoden aufrufen — keine
##                                  privaten _on_*_confirmed() direkt (ADR-R11).
##   _on_*_confirmed()            — PRIVATE Authority-Mutation.
##                                  Darf nur von request_*() (Tier 1) oder
##                                  receive_*_from_network() (Tier 2/3) aufgerufen werden.
##
## WARUM receive_*_from_network() statt direkter _on_*_confirmed()-Aufrufe:
##   Die privaten Methoden sind Implementierungsdetails. Wenn sich ihre Signatur
##   ändert (z.B. Dictionary → typed params), bricht der Network-Layer stumm.
##   receive_*_from_network() ist der stabile Kontrakt — typisiert, dokumentiert,
##   testbar ohne echten MultiplayerPeer.
##
## IMPLEMENTIERUNG (ab MIGRATION-010 Phase 2, R11):
##   NetworkBridge.gd ist der einzige Node, der @rpc-Methoden hostet und
##   intern an RefCounted-Services delegiert. Siehe docs/adr/010-multiplayer-authority-tiers.md.
##
## ─────────────────────────────────────────────
## SERVER-AUTORITATIV (request_/confirmed_-Pattern PFLICHT):
## Authority-Gating: assert(not multiplayer.has_multiplayer_peer() or multiplayer.is_server())
## ─────────────────────────────────────────────
##   InventorySystem    — add_item, remove_item, trade
##   QuestService       — start_quest, complete_quest, update_objective
##   EntityOrchestrator — spawn_entity, despawn_entity (inkl. UUID-Vergabe)
##   PlayerStateService — state-Wechsel (FREE/BUSY/MENU)
##   SkillSystem        — xp_gain, level_up
##   CombatSystem       — roll_critical(), calculate_damage() (Krit-Würfe server-autoritativ)
##
## ─────────────────────────────────────────────
## CLIENT-AUTORITATIV (darf State direkt mutieren):
## ─────────────────────────────────────────────
##   TouchInput, PlayerCamera — Input, Kamera-Rotation, Look-Smoothing
##   HUDManager, LayoutManager — UI-State, Animation
##   Settings — lokale Display/Audio-Präferenzen
##   AppLogger — Logging ist lokal
##
## ─────────────────────────────────────────────
## SHARED / READ-ONLY REPLICA (Client hat Kopie, Server ist Truth):
## ─────────────────────────────────────────────
##   WorldData — Client hat eine lokale Kopie für Rendering,
##               Server ist die einzige Schreibquelle.
##   DataService — Item/Quest/Skill-Definitionen sind statisch → kein Sync nötig.

## Gibt true zurück wenn der übergebene Methodenname der request_-Konvention folgt.
## Nützlich für Runtime-Checks in Tests.
static func is_valid_request_method(method_name: String) -> bool:
	return method_name.begins_with("request_") or method_name.begins_with("on_") and "_confirmed" in method_name

## Gibt die erwartete confirm-Methode für eine request-Methode zurück.
## Beispiel: "request_add_item" → "on_item_add_confirmed"
## Konvention: request_<noun>_<verb> → on_<noun>_<verb>_confirmed
static func get_confirm_method_for(request_method: String) -> String:
	if not request_method.begins_with("request_"):
		return ""
	var stripped := request_method.substr(8)  # Remove "request_"
	return "on_%s_confirmed" % stripped

## Assertions für Tests — wirft einen Fehler wenn eine server-autoritative
## Klasse direkt State mutiert ohne request_/confirmed_-Pattern.
## Wird in IntegrationTest.gd aufgerufen.
static func assert_server_authoritative_uses_request_pattern(obj: Object, method: String) -> void:
	assert(
		is_valid_request_method(method),
		"[NetworkContract] Server-autoritative Methode '%s' in '%s' verletzt request_-Konvention."
		% [method, obj.get_class()]
	)
