# res://scripts/interfaces/core/IUIContext.gd
class_name IUIContext extends RefCounted

## IUIContext — Schmale Service-Fassade für UI-Controller.
##
## Analogon zu IEntityContext für den UI-Layer.
## Controller bekommen via setup(visuals, ctx) nur die Services die sie
## wirklich brauchen — testbar, ohne AutoLoad-Abhängigkeiten.
##
## VERWENDUNG:
##   HUDBuilder.build_all(hud, context) injiziert den Context via set_ui_context_factory().
##   In Tests: UIContext.for_test() mit Mock-Implementations.
##
## WICHTIG: Controller speichern den Context als _ctx: IUIContext.

## QuestService — für Panels die Quest-State lesen.
func get_quest() -> QuestService:
	return null

## SkillSystem — für Panels die Skill-Level/XP anzeigen.
func get_skill_system() -> SkillSystem:
	return null

## InventorySystem — für das Inventar-Panel.
func get_inventory() -> InventorySystem:
	return null

## EquipmentService — für das Equipment-Panel.
func get_equipment() -> EquipmentService:
	return null

## DataService — für Item-Definitionen in Equipment-Panel.
func get_data() -> DataService:
	return null

## IEventBus — Event-Zugriff für Controller die auf Signale lauschen oder welche emittieren.
## I-02 (AUDIT-03): schließt die UI-Hälfte von H-07/ADR-011 — Services injizieren IEventBus
## bereits korrekt via deps.require(EVENT_BUS); Controller griffen bisher direkt auf den
## EventBus-AutoLoad zu (EventBus.player.*, EventBus.ui.* …) statt über diesen Context.
##
## In Produktion: EventBusAdapter, aus derselben Session-Registry aufgelöst die auch
## Services ihren IEventBus gibt (ServiceKeys.EVENT_BUS) — identischer Adapter, keine
## zweite Implementierung.
## In Tests: MockEventBus (tests/mocks/MockEventBus.gd) — kein AutoLoad, kein SceneTree nötig.
##
## VERWENDUNG in Controllern:
##   var _ctx: IUIContext
##   func setup(visuals: ..., ctx: IUIContext) -> void:
##       _ctx = ctx
##       _ctx.bus().player().xp_gained.connect(_on_xp_gained)
##   Kein EventBus.player.xp_gained.connect(...) mehr in Controller-Code (ADR-012).
func bus() -> IEventBus:
	return null
