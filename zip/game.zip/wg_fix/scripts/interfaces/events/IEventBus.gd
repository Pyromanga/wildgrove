# res://scripts/interfaces/events/IEventBus.gd
class_name IEventBus extends RefCounted

## IEventBus — Schmale Fassade für Event-Infrastruktur.
##
## Services hängen von IEventBus ab, nicht vom globalen EventBus-AutoLoad.
## Das ermöglicht Tests mit MockEventBus ohne laufenden SceneTree.
##
## PRODUKTION: EventBusAdapter implementiert IEventBus und delegiert 1:1
##             an den echten EventBus-AutoLoad. Zero runtime overhead.
##
## TEST:       MockEventBus implementiert IEventBus und zeichnet alle
##             emit_*()-Aufrufe auf. Signal-Connects funktionieren auf
##             lokalen Instanzen — kein globales State-Bleeding zwischen Tests.
##
## VERWENDUNG in Services:
##   var _bus: IEventBus
##   func configure(deps: ServiceDeps) -> void:
##       _bus = deps.require(ServiceKeys.EVENT_BUS) as IEventBus
##
##   func on_ready() -> void:
##       _bus.player().xp_gained.connect(_on_xp_gained)
##       _bus.quest().emit_quest_started("quest_foo")
##
## WARUM Accessor-Methoden statt Properties:
##   GDScript unterstützt keine abstrakten Property-Overrides über Vererbung.
##   Methoden mit virtualem Override-Pattern sind der einzige zuverlässige Weg.

## Gibt den PlayerEvents-Namespace zurück.
## In Produktion: EventBus.player (echtes AutoLoad-Feld)
## In Tests: lokale PlayerEvents-Instanz
func player() -> PlayerEvents:
	return null

## Gibt den WorldEvents-Namespace zurück.
func world() -> WorldEvents:
	return null

## Gibt den SystemEvents-Namespace zurück.
func system() -> SystemEvents:
	return null

## Gibt den UIEvents-Namespace zurück.
func ui() -> UIEvents:
	return null

## Gibt den QuestEvents-Namespace zurück.
func quest() -> QuestEvents:
	return null
