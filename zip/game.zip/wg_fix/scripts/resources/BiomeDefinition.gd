# res://scripts/resources/BiomeDefinition.gd
class_name BiomeDefinition extends Resource

## BiomeDefinition — Daten-Resource für ein Welt-Biom.
##
## Jedes Biom definiert Farben, Vegetation und Strukturen.
## Wird von WorldGenerationService via Noise-Sampling ausgewählt.

@export var biome_id: String = ""
@export var display_name: String = ""

## Terrain-Farben
@export var terrain_color_grass: Color = Color(0.2, 0.55, 0.15)
@export var terrain_color_dirt:  Color = Color(0.45, 0.30, 0.15)
@export var terrain_color_rock:  Color = Color(0.45, 0.45, 0.45)

## Spawn-Wahrscheinlichkeiten: prop_id → chance (0.0–1.0 pro Tile)
@export var prop_chances: Dictionary = {}

## Strukturen die in diesem Biom spawnen können
@export var structure_types: Array[String] = []

## Optionale Atmosphäre
@export var fog_density: float = 0.0
@export var snow_coverage: float = 0.0   # 0.0 = kein Schnee, 1.0 = voll
