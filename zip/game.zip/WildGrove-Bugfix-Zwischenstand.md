# WildGrove — Bugfix-Zwischenstand

Stand: Folgesession 2 (Fortsetzung). Dieses Dokument hält fest, was
bereits gefixt ist, was root-caused aber noch nicht gefixt ist, und was noch
gar nicht untersucht wurde — damit die nächste Session direkt weitermachen kann.

---

## ✅ Bereits gefixt (im Code)

### BUG-1: UI dupliziert sich manchmal
- **Ort:** `scripts/platform/ServiceOrchestrator.gd` (`_wire_hud()`)
- **Ursache (bestätigt):** `_wire_hud(char_scope)` läuft bei JEDEM
  Session-Boot — initial UND beim Reload-Pfad (`_on_scene_reload_requested()`,
  z.B. Charakterwechsel oder "Laden" im Pause-Menü). Jeder Aufruf ruft
  `HUDManager.boot(get_tree(), factory)` — das erzeugt IMMER eine neue
  `HUDManager`-Instanz + einen neuen `HUD`-Node unter `/root`.
  `HUDManager` ist aber kein DI-Service in einer `ServiceRegistry`, sondern
  ein manuell verwalteter Scene-Tree-Node außerhalb des Boot-Systems —
  `BootPipeline.teardown_character()`/`teardown_world()` laufen nur über
  `registry`-Boot-Orders und erfassen ihn nie. Die alte
  HUDManager+HUD-Kombination blieb beim Reload also einfach hängen, während
  `boot()` daneben eine zweite aufbaute: zwei parallele HUD-Bäume mit je
  eigenem Controller-Satz (inkl. Quest-Panel), beide sichtbar, beide an
  Signale gebunden.
- **Fix:** `ServiceOrchestrator` hält jetzt eine Referenz `_hud_manager` auf
  die aktive Instanz. `_wire_hud()` ruft vor jedem `boot()` `queue_free()`
  auf einer evtl. noch vorhandenen alten Instanz auf — das löst
  `HUDManager._exit_tree()` aus, das bereits korrekt aufräumt (Bus-Disconnects,
  `teardown()` auf allen Controllern, HUD-Node freigeben).
- **Status:** Fertig, sollte funktionieren. Nicht getestet (kein Godot-Runtime
  hier verfügbar).

### BUG-2: Text über Spieler überlagert sich
- **Ort:** `scripts/ui/controllers/FloatingTextController.gd`, außerdem
  beim Untersuchen entdeckt und mitgefixt: `scripts/interaction/ui/
  InteractionUIController.gd`, `scripts/economy/equipment/ui/
  EquipmentUIController.gd`, `scripts/ui/controllers/ContextMenuController.gd`
- **Ursache (bestätigt):** dieselbe "Zombie-Controller"-Klasse, die im Code
  bereits für `NotificationController` und `InventoryUIController` gefixt war
  (siehe deren `_is_setup`-Kommentare) — `FloatingTextController` (und die drei
  oben genannten) sind RefCounted statt Node und bieten bislang kein
  `teardown()`. `HUDManager._on_world_scene_ready()` ruft zwar bereits
  generisch `teardown()` auf jedem alten Controller auf, der die Methode
  anbietet — diese vier boten sie schlicht nicht an. Jeder HUD-Rebuild
  (`world_scene_ready`, nicht nur volle Session-Reloads — auch der
  In-Session-Hot-Reload-Fall aus BUG-B) hinterließ also einen weiteren
  dauerhaft lauschenden Zombie. Bei `FloatingTextController` heißt das
  konkret: jedes `xp_gained`/`level_up`/Loot-Event spawnt N überlappende
  Text-Labels an derselben Bildschirmposition, N = Anzahl bisheriger
  HUD-Rebuilds — exakt das gemeldete Symptom "Text über Spieler überlagert
  sich".
- **Fix:** `teardown()` nach demselben Muster wie `NotificationController`
  ergänzt (Signal-Disconnects + `_is_setup`-Flag) für alle vier Controller.
- **Status:** Fertig, sollte funktionieren. Nicht getestet (kein Godot-Runtime
  hier verfügbar). `InteractionUIController`/`EquipmentUIController`/
  `ContextMenuController` waren nicht explizit in der Bug-Liste genannt,
  sondern beim gezielten Audit auf dasselbe Muster gefunden (siehe unten) —
  bitte im Spieltest zusätzlich im Auge behalten, ob sich dort etwas ändert
  (Fortschrittsbalken bei Interaktionen, Ausrüstungs-Panel, Kontextmenü).

### BUG-5: Mining-Quest zeigt 0/3 statt tatsächlichem Fortschritt
- **Ort:** `scripts/progression/quests/QuestObjectiveHandler.gd` (`resolve_xp()`),
  `scripts/progression/quests/QuestService.gd` (`on_quest_start_confirmed()`)
- **Ursache (bestätigt, zwei Teile):**
  1. `resolve_xp()` vergab bei erreichtem Ziel-Level nur ein fixes `delta: 1`
     — `update_objective()`/`QuestProgressRecord.update_progress()` arbeiten
     aber rein additiv (`current + delta`, geclamped). Ein SKILL-Objective
     soll den ABSOLUTEN Skill-Level widerspiegeln (Anzeige `Level/required`,
     z.B. `obj_reach_mining_3`), bekam durch das feste `+1` aber nie den
     tatsächlichen Wert — blieb bei Level 1/2 bei 0, weil der Delta-Zweig
     erst ab `cur_level >= required` überhaupt feuerte.
  2. `on_quest_start_confirmed()` initialisiert neue Records pauschal mit 0
     (`QuestProgressRecord.create_new()`) und synct SKILL-Objectives nicht
     mit dem beim Queststart bereits vorhandenen Skill-Level — die Anzeige
     blieb bis zum nächsten `xp_gained`-Event bei 0, selbst wenn der Spieler
     den Skill schon vorher auf Level 1/2 hatte.
- **Fix:**
  1. `resolve_xp()`: `delta = cur_level - aktueller_objective_progress`
     (nur wenn positiv) statt fixem `+1` — Fortschritt entspricht danach
     nach jedem `xp_gained`-Event exakt dem echten Skill-Level.
  2. `on_quest_start_confirmed()`: SKILL-Objectives werden direkt beim
     Queststart einmalig mit `SkillSystem.get_level()` synchronisiert
     (geclamped auf `required`).
- **Status:** Fertig, sollte funktionieren. Nicht getestet (kein Godot-Runtime
  hier verfügbar).

### BUG-C: Lebenspunkte werden nicht gespeichert
*(unverändert — siehe vorherige Fassung dieses Dokuments für Details)*

### BUG-D: Gegner nach Respawn nicht angreifbar
*(unverändert — siehe vorherige Fassung dieses Dokuments für Details)*

### BUG-B: Pets werden beim Fangen/Neuladen in die Luft geschleudert
*(unverändert — siehe vorherige Fassung dieses Dokuments für Details)*

### BUG-A: Skelette zeigen "Ein Goblin..."-Text
*(unverändert — siehe vorherige Fassung dieses Dokuments für Details)*

---

## 🔍 Root-Cause gefunden, Fix noch NICHT angewendet

(aktuell leer)

---

## ❌ Noch gar nicht untersucht

| # | Bug (aus Original-Liste) | Notiz |
|---|---|---|
| 3 | Quests enden ohne NPC-Gespräch | `scripts/progression/quests/QuestService.gd` + Trigger in `scripts/progression/quests/triggers/`. **Erst nach dem UI-Duplikat-Fix (BUG-1/BUG-2) neu gegentesten** — möglich, dass sich das Symptom durch doppelte/zombie Controller erklärt hat. Falls es weiter auftritt: Verdacht bleibt ein Trigger, der Quest-Completion fälschlich auslöst (z.B. KILL/COLLECT-Objective erreicht komplettiert automatisch ohne Rückgabe-Dialog-Schritt). |
| 4 | Quest-Fortschritt wird gespeichert, UI zeigt ihn nach Save/Reload nicht an | Ebenfalls **erst nach BUG-1/BUG-2-Fix neu gegentesten**. Falls weiter auftritt: fehlender UI-Refresh-Call beim Session-Start prüfen — `QuestPanelController._refresh_active_quests()` existiert bereits und sollte das eigentlich abdecken (siehe Code), also ggf. Timing-Problem statt fehlender Call. |
| 6 | Skill für Kondition fehlt (XP fürs Laufen, Effekt: schneller laufen) | Feature-Wunsch, kein Bug. Noch nicht angefasst. `Player._track_movement_stats()` sammelt bereits `_stat_walked_accum` und emittiert `movement_stats_batch` — natürlicher Hook für ein neues "Ausdauer"-Skill. |
| 7 | UI teils klein / nicht modern | Design-/Polish-Thema, kein klassischer "Bug". Braucht eigene Design-Pass-Session. |
| 8 (neu, geprüft — kein Bug) | Weitere Zombie-Controller? | Beim Audit für BUG-2 wurden `InteractionUIController`/`EquipmentUIController`/`ContextMenuController` gefunden und mitgefixt (siehe BUG-2). Zusätzlich geprüft: `TerminalController.gd`, `QuestNPCDialogController.gd`, `TutorialGuideDialogController.gd` — alle drei haben KEINE eigenen Bus-Signal-Verbindungen (nur direkte Methodenaufrufe bzw. bereits korrektes `on_spawn()`/`on_despawn()`-Paar bei `QuestNPC`/`TutorialGuideNPC`, analog `EnemyNPC`). Kein Zombie-Risiko, keine Änderung nötig. |

---

## Empfehlung für die nächste Session

1. ~~BUG-B (Pets)~~ / ~~BUG-D (Gegner)~~ / ~~BUG-C (HP-Save)~~ — erledigt.
2. ~~BUG-1 (UI-Duplikat)~~ / ~~BUG-2 (Text-Überlagerung + weitere Zombie-Controller)~~ / ~~BUG-5 (Mining-Quest-Progress)~~ — erledigt.
3. **Zuerst im Spiel gegentesten:** Charakterwechsel bzw. "Laden" mehrfach
   hintereinander auslösen und prüfen, ob UI jetzt sauber bleibt, ob XP/Loot-
   Text nicht mehr überlagert UND ob #3/#4 dadurch mit verschwunden sind.
4. Falls #3/#4 weiter auftreten: isoliert wie oben notiert angehen.
5. Feature-Wunsch Kondition-Skill und UI-Modernisierung — separate,
   nicht-Bugfix-Sessions.
