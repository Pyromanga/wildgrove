# Tests — Headless, ohne GUT, ohne Editor

**Neu in Review-Session 4.** Vorher gab es genau eine Datei
(`IntegrationTest.gd`), die ohne installiertes GUT-Addon von NIEMANDEM
aufgerufen wurde — kompiliert fehlerfrei, lief aber nie. Diese Test-Suite
läuft TATSÄCHLICH und braucht weder GUT noch den Godot-Editor.

## Ausführen

```bash
godot --headless --path . res://tests/TestRunner.tscn
echo $?   # 0 = alle Tests bestanden, 1 = mindestens ein Fail
```

`--headless` reicht — keine Display/GPU nötig. `res://tests/TestRunner.tscn`
als Szenen-Argument überschreibt `run/main_scene` NUR für diesen Aufruf;
`project.godot` bleibt unverändert (MainMenu.tscn ist weiter der normale
Start).

Die komplette Ausgabe läuft über `Logger` — landet also auch in
`user://wildgrove.log`, falls ihr das Log lieber aus einer Datei lesen wollt
als aus stdout.

## Struktur

```
tests/
├── TestCase.gd              ← Basisklasse: assert_eq, assert_true, ...
├── TestRunner.gd / .tscn     ← Runner (siehe oben)
├── IntegrationTest.gd        ← alter GUT-Stub, läuft NICHT (siehe Header)
├── unit/                      ← reine Logik, KEIN Boot nötig
│   ├── test_state_validator.gd
│   ├── test_skill_definition.gd
│   ├── test_world_data.gd
│   ├── test_world_save_adapter.gd
│   ├── test_loot_table.gd
│   └── test_service_dependency_resolver.gd
└── integration/               ← braucht erfolgreichen Boot (Services.*)
    └── test_service_integrity.gd
```

## Warum DIESE Architektur (für 20 Jahre)

- **Kein GUT-Risiko mehr.** GUT ist ein externes Addon — installieren,
  Versions-Updates, manchmal API-Brüche zwischen Godot-Versionen. `TestCase.gd`
  ist absichtlich winzig (eine Datei, ~10 Methoden). Falls ihr GUT SPÄTER
  doch installiert: `assert_*`-Namen sind bewusst GUT-ähnlich gewählt,
  mechanisches Umschreiben ist möglich.

- **`tests/unit/` testet das, was am häufigsten kaputt geht, ohne dass man
  es merkt:** reine Daten-/Logik-Klassen (`Resource`/`RefCounted`, kein
  SceneTree). Genau die Art Bug, die im Code "logisch aussieht" aber bei
  echten Werten falsch rechnet — z.B. `test_service_dependency_resolver.gd`
  hätte den `combat.tres`-Schema-Drift NICHT gefangen (das war ein .tres-
  Property-Problem), aber `test_skill_definition.gd` prüft jetzt explizit,
  dass `combat.tres` die richtigen Properties hat.

- **`tests/integration/` ist klein, bewusst.** EIN Test
  (`test_service_integrity.gd`), der den GANZEN Boot validiert
  (`ServiceOrchestrator.boot_ok` + `Services.get_status_report()`). Das ist
  der "ist das Spiel überhaupt noch bootbar"-Smoke-Test — wenn der rot ist,
  ist ALLES andere sekundär.

## Neue Tests hinzufügen

1. `tests/unit/test_<thema>.gd`:
   ```gdscript
   class_name TestThema   # eindeutiger Name, global registriert!
   extends TestCase

   func test_etwas() -> void:
       assert_eq(meine_funktion(), 42, "Beschreibung was schiefging")
   ```
2. In `tests/TestRunner.gd` zu `UNIT_TESTS` (oder `INTEGRATION_TESTS`)
   hinzufügen: `preload("res://tests/unit/test_<thema>.gd"),`
3. `godot --headless --path . res://tests/TestRunner.tscn` ausführen.

**Regel:** `class_name` MUSS projektweit eindeutig sein (globaler Namespace
in GDScript) — `TestXyz`-Namen nach Datei benennen, nicht nach Thema, falls
Kollisionsgefahr.

## Bekannte Grenzen

- Kein Mocking — `test_service_integrity.gd` läuft gegen den ECHTEN Boot
  inkl. allen `.tres`-Dateien. Ein kaputtes `data/*.tres` lässt
  `ServiceValidator` fehlschlagen → `boot_ok=false` → Test schlägt fehl, ABER
  ohne genauen Hinweis WELCHE `.tres`-Datei — dafür ins Log schauen
  (`ServiceValidator`/`ResourceLoader`-Kategorien).
- Tests laufen SEQUENZIELL, ein Prozess, ein Frame Vorlauf. Für Services mit
  mehrstufigem `await`/`call_deferred` in `on_ready()` ggf. mehr
  `await get_tree().process_frame` in `TestRunner.gd` nötig — aktuell reicht
  einer (Stand Session 4, kein Service nutzt mehrstufiges deferred setup).
