# res://tests/unit/test_world_data.gd
class_name TestWorldData
extends TestCase

## Testet WorldData's deterministische Key-Generierung für harvested_objects
## (Session 4 Bugfix: locale-unabhängige int-Keys statt str(Vector3)).
##
## HINWEIS: mark_harvested() loggt log_debug, unmark_harvested() bei
## nicht-gefundenem Key log_warn. Beides ERWARTET in diesem Testlauf.


func test_mark_and_check_tree_harvested() -> void:
	var data := WorldData.new()
	var pos := Vector3(5, 0, 5)

	assert_false(data.is_tree_harvested(pos), "Baum sollte initial NICHT als geerntet markiert sein")
	data.mark_tree_harvested(pos)
	assert_true(data.is_tree_harvested(pos), "Baum sollte nach mark_tree_harvested() als geerntet gelten")


func test_mark_and_check_ore_harvested_with_negative_coords() -> void:
	# Aus dem Doc-Beispiel in WorldData.gd: "ore_-3_0_2"
	var data := WorldData.new()
	var pos := Vector3(-3, 0, 2)

	assert_false(data.is_ore_harvested(pos), "Erz sollte initial NICHT als geerntet markiert sein")
	data.mark_ore_harvested(pos)
	assert_true(data.is_ore_harvested(pos), "Erz sollte nach mark_ore_harvested() als geerntet gelten")
	assert_true(
		data.is_harvested("ore_-3_0_2"),
		"Generierter Key sollte exakt 'ore_-3_0_2' sein (siehe Doc-Beispiel in WorldData.gd)"
	)


func test_unmark_oak_tree_roundtrip() -> void:
	var data := WorldData.new()
	var pos := Vector3(10, 0, -2)

	data.mark_tree_harvested(pos)
	assert_true(data.is_tree_harvested(pos), "Vorbedingung: Baum als geerntet markiert")

	data.unmark_harvested("oak_tree", pos)
	assert_false(data.is_tree_harvested(pos), "Nach unmark_harvested('oak_tree', ...) sollte Baum wieder verfügbar sein")


func test_unmark_iron_ore_roundtrip() -> void:
	var data := WorldData.new()
	var pos := Vector3(1, 0, 1)

	data.mark_ore_harvested(pos)
	data.unmark_harvested("iron_ore", pos)
	assert_false(data.is_ore_harvested(pos), "Nach unmark_harvested('iron_ore', ...) sollte Erz wieder verfügbar sein")


func test_sub_integer_positions_collide_on_truncation() -> void:
	# DOKUMENTIERTES VERHALTEN, nicht unbedingt "gewünscht": _tree_key() nutzt
	# int(pos.x/y/z) — also TRUNCATION, nicht Rundung. Zwei Bäume mit
	# unterschiedlicher Sub-Tile-Position aber gleichen int-Koordinaten
	# landen auf demselben harvested-Key. Für ein Grid-System (TerrainGenerator
	# platziert auf ganzen Koordinaten) ist das unkritisch — aber falls ihr
	# je FREIE Platzierung (Farming-Beete, Deko) einführt, kann das zu
	# "Baum A geerntet → Baum B (auf 5.9, 0, 5.9) zeigt sich als 'schon
	# geerntet' an" führen. Dieser Test macht das Verhalten EXPLIZIT.
	var data := WorldData.new()
	var pos_a := Vector3(5.0, 0.0, 5.0)
	var pos_b := Vector3(5.9, 0.0, 5.9)  # int(5.9) == 5 == int(5.0)

	data.mark_tree_harvested(pos_a)
	assert_true(
		data.is_tree_harvested(pos_b),
		"int(5.9)==int(5.0)==5 → (5.0,0,5.0) und (5.9,0,5.9) teilen sich denselben Key (dokumentiertes Truncation-Verhalten)"
	)


func test_add_tree_deduplicates_positions() -> void:
	var data := WorldData.new()
	var pos := Vector3(2, 0, 2)
	data.add_tree(pos)
	data.add_tree(pos)
	assert_eq(data.get_tree_count(), 1, "add_tree() sollte dieselbe Position nicht doppelt aufnehmen")


func test_unmark_unknown_type_uses_generic_key() -> void:
	# type_id, das weder "oak_tree" noch "iron_ore" ist → generischer Key
	# "%s_%d_%d_%d". Da nie etwas mit diesem Key markiert wurde, erase()
	# liefert false → log_warn (erwartet, kein Testfehler).
	var data := WorldData.new()
	var pos := Vector3(7, 0, 7)
	# Erase auf nicht-existentem generischen Key darf NICHT crashen.
	data.unmark_harvested("future_crop", pos)
	assert_false(
		data.is_harvested("future_crop_7_0_7"),
		"Generischer Key sollte nach erfolglosem unmark weiterhin 'nicht harvested' sein"
	)
