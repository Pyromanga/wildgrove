# res://tests/unit/test_skill_definition.gd
class_name TestSkillDefinition
extends TestCase

## Testet SkillDefinition.get_xp_required() — sowohl die Default-Werte
## (xp_to_level_up Array) als auch die Extrapolation darüber hinaus
## (xp_scaling_factor).
##
## Hintergrund Review-Session 4: data/skills/combat.tres nutzte vorher
## `base_xp_required`/`xp_scaling` — Properties, die SkillDefinition.gd NIE
## hatte. Godot ignoriert unbekannte .tres-Properties stillschweigend, d.h.
## combat.tres lief die ganze Zeit auf den SCRIPT-DEFAULTS (identisch zu
## woodcutting/mining/farming). Dieser Test prüft die SCRIPT-DEFAULTS direkt
## (ohne .tres zu laden) — also genau das, was combat.tres vorher UNGEWOLLT
## tatsächlich genutzt hat, und was es nach dem Fix jetzt EXPLIZIT deklariert.


func test_default_curve_first_entries() -> void:
	var def := SkillDefinition.new()
	# Defaults aus SkillDefinition.gd: xp_to_level_up = [100, 250, 500, 900, 1400, 2000]
	assert_eq(def.get_xp_required(1), 100, "Level 1→2 sollte 100 XP kosten")
	assert_eq(def.get_xp_required(2), 250, "Level 2→3 sollte 250 XP kosten")
	assert_eq(def.get_xp_required(6), 2000, "Level 6→7 sollte 2000 XP kosten (letzter Tabellen-Eintrag)")


func test_extrapolation_beyond_table_uses_scaling_factor() -> void:
	var def := SkillDefinition.new()
	# idx = level-1 = 6 (Level 7), Tabelle hat nur Indizes 0..5 (6 Einträge)
	# → overflow = idx - size + 1 = 6 - 6 + 1 = 1
	# → erwartet: int(2000 * 1.5^1) = 3000
	var xp7 := def.get_xp_required(7)
	assert_eq(xp7, 3000, "Level 7→8 sollte 2000 * 1.5^1 = 3000 XP kosten")

	# Level 8: overflow = 2 → int(2000 * 1.5^2) = int(4500.0) = 4500
	var xp8 := def.get_xp_required(8)
	assert_eq(xp8, 4500, "Level 8→9 sollte 2000 * 1.5^2 = 4500 XP kosten")


func test_xp_curve_is_monotonically_increasing() -> void:
	# Sanity-Check: eine XP-Kurve, die irgendwo SINKT, wäre ein handfester
	# Balance-Bug (höheres Level wird billiger als ein niedrigeres).
	# Prüft 20 Level über die Tabellengröße hinaus (testet die Extrapolation
	# über mehrere Overflow-Stufen).
	var def := SkillDefinition.new()
	var previous := 0
	for level in range(1, 21):
		var required := def.get_xp_required(level)
		assert_true(
			required >= previous,
			"XP-Kurve sollte monoton steigen — Level %d (%d) < vorheriges Level (%d)"
			% [level, required, previous]
		)
		previous = required


func test_combat_skill_now_matches_documented_schema() -> void:
	# Direkter Schema-Check der reparierten combat.tres (Review-Session 4):
	# Vorher: base_xp_required/xp_scaling (unbekannte Properties, ignoriert).
	# Jetzt: xp_to_level_up/xp_scaling_factor wie woodcutting/mining/farming.
	var combat := load("res://data/skills/combat.tres") as SkillDefinition
	assert_not_null(combat, "combat.tres sollte als SkillDefinition ladbar sein")
	if combat == null:
		return

	assert_eq(combat.id, "combat", "combat.tres id-Feld")
	assert_eq(
		combat.xp_to_level_up.size(),
		6,
		"combat.tres sollte (wie die anderen Skills) 6 xp_to_level_up-Einträge haben"
	)
	assert_almost_eq(
		combat.xp_scaling_factor, 1.5, 0.001,
		"combat.tres xp_scaling_factor sollte jetzt 1.5 sein (vorher: stilles 'xp_scaling=1.15' ohne Effekt)"
	)
