# res://tests/unit/test_service_dependency_resolver.gd
class_name TestServiceDependencyResolver
extends TestCase

## Testet ServiceDependencyResolver (Kahn's Algorithmus, Phase 2 der Boot-Pipeline).
##
## Zwei Test-Gruppen:
##   1. Algorithmus-Korrektheit mit handgebauten, kleinen Graphen
##      (Ordering, unbekannte Deps, Zyklen).
##   2. NO-DRIFT-Regressionstest gegen die ECHTE config/BootstrapConfig.tres
##      via ServiceValidator — falls dort je ein Tippfehler in `deps`,
##      ein Zyklus, oder eine unbekannte Abhängigkeit landet, schlägt
##      DIESER Test fehl, BEVOR es ein Boot-Log-Rätsel wird.
##
## HINWEIS: resolve() loggt bei unbekannten Deps / Zyklen log_error — bei den
## entsprechenden Tests unten ERWARTET, kein Testfehler.


## dep_list ist bewusst untypisiertes Array (Variant-Elemente) — d.deps ist
## bereits Array[String] (Default aus ServiceDefinition.gd), .append() prüft
## den Element-Typ zur Laufzeit. So vermeiden wir jede Unsicherheit rund um
## "Array-Literal als Argument für Array[String]-Parameter".
func _make_def(name: String, dep_list: Array) -> ServiceDefinition:
	var d := ServiceDefinition.new()
	d.service_name = name
	for dep in dep_list:
		d.deps.append(dep)
	return d


func test_empty_input_returns_empty() -> void:
	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve([])
	assert_eq(result, [], "Leere Eingabe sollte leeres Ergebnis liefern")


func test_simple_chain_orders_dependencies_first() -> void:
	var defs: Array[ServiceDefinition] = [
		_make_def("c", ["a", "b"]),
		_make_def("b", ["a"]),
		_make_def("a", []),
	]
	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve(defs)

	assert_eq(result.size(), 3, "Alle 3 Services sollten im Ergebnis sein")
	var idx_a := result.find("a")
	var idx_b := result.find("b")
	var idx_c := result.find("c")
	assert_true(idx_a < idx_b, "'a' sollte vor 'b' kommen ('b' braucht 'a')")
	assert_true(idx_a < idx_c, "'a' sollte vor 'c' kommen ('c' braucht 'a')")
	assert_true(idx_b < idx_c, "'b' sollte vor 'c' kommen ('c' braucht 'b')")


func test_unknown_dependency_returns_empty() -> void:
	var defs: Array[ServiceDefinition] = [
		_make_def("a", ["does_not_exist"]),
	]
	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve(defs)
	assert_eq(result, [], "Unbekannte Abhängigkeit sollte zu leerem Ergebnis führen (Fail-Fast)")


func test_cycle_returns_empty() -> void:
	var defs: Array[ServiceDefinition] = [
		_make_def("a", ["b"]),
		_make_def("b", ["a"]),
	]
	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve(defs)
	assert_eq(result, [], "Zirkuläre Abhängigkeit (a→b, b→a) sollte zu leerem Ergebnis führen")


func test_dependency_names_are_case_insensitive() -> void:
	# resolve() normalisiert via to_lower() — "World" als dep sollte "world"
	# als service_name finden.
	var defs: Array[ServiceDefinition] = [
		_make_def("World", []),
		_make_def("Respawn", ["World"]),
	]
	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve(defs)
	assert_eq(result.size(), 2, "Case-insensitive Deps sollten trotzdem aufgelöst werden")
	assert_true(result.find("world") < result.find("respawn"), "'world' vor 'respawn'")


# ─────────────────────────────────────────────
# No-Drift-Regressionstest gegen die echte BootstrapConfig.tres
# ─────────────────────────────────────────────


func test_real_bootstrap_config_resolves_without_cycles() -> void:
	var defs := ServiceValidator.new().validate()
	assert_false(defs.is_empty(), "ServiceValidator.validate() sollte gegen die echte BootstrapConfig.tres nicht leer sein")
	if defs.is_empty():
		return

	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve(defs)

	assert_eq(
		result.size(), defs.size(),
		"resolve() sollte ALLE %d Services aus BootstrapConfig.tres zurückgeben (0 = Zyklus oder unbekannte Dep)"
		% defs.size()
	)


func test_real_bootstrap_config_respects_declared_deps() -> void:
	# Für JEDE in BootstrapConfig.tres deklarierte Abhängigkeit X→Y muss Y
	# vor X im Ergebnis stehen. Das ist die eigentliche Garantie, die
	# configure(deps) braucht (deps.get("y") muss bereits existieren).
	var defs := ServiceValidator.new().validate()
	if defs.is_empty():
		return

	var resolver := ServiceDependencyResolver.new()
	var result := resolver.resolve(defs)
	if result.is_empty():
		return  # bereits oben als Fehler erfasst

	for def in defs:
		var service_key := def.service_name.to_lower()
		var idx_service := result.find(service_key)
		for dep_raw in def.deps:
			var dep_key := (dep_raw as String).to_lower()
			var idx_dep := result.find(dep_key)
			assert_true(
				idx_dep >= 0,
				"'%s' deklariert Abhängigkeit '%s', die nicht im Ergebnis vorkommt" % [service_key, dep_key]
			)
			assert_true(
				idx_dep < idx_service,
				"'%s' (Index %d) sollte VOR '%s' (Index %d) konfiguriert werden — '%s' hängt von '%s' ab"
				% [dep_key, idx_dep, service_key, idx_service, service_key, dep_key]
			)
