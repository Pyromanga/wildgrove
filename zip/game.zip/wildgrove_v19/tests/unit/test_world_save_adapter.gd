# res://tests/unit/test_world_save_adapter.gd
class_name TestWorldSaveAdapter
extends TestCase

## Testet WorldSaveAdapter.to_save_dict() / restore_from_dict() (Session 4,
## extrahiert aus WorldService.gd).
##
## Wichtigster Test hier: das ALTE ore_positions-Format (ein einziger String,
## der das gesamte Array kodiert) muss weiterhin korrekt gelesen werden —
## sonst verlieren Spieler mit einem Save von VOR Session 4 ihre Erz-Positionen.


func test_round_trip_preserves_positions_and_time() -> void:
	var data := WorldData.new()
	data.tree_positions = [Vector3(1, 0, 2), Vector3(3, 0, 4)]
	data.ore_positions = [Vector3(-1, 0, -2)]
	data.player_position = Vector3(10, 1, -5)
	data.harvested_objects = {"oak_tree_1_0_2": true}

	var saved := WorldSaveAdapter.to_save_dict(data, 13.5, 7)

	var restored_data := WorldData.new()
	var restored_time := WorldSaveAdapter.restore_from_dict(restored_data, saved)

	assert_eq(restored_time.get("day_time"), 13.5, "day_time sollte erhalten bleiben")
	assert_eq(restored_time.get("day_count"), 7, "day_count sollte erhalten bleiben")
	assert_eq(restored_data.tree_positions, data.tree_positions, "tree_positions Round-Trip")
	assert_eq(restored_data.ore_positions, data.ore_positions, "ore_positions Round-Trip")
	assert_eq(restored_data.player_position, data.player_position, "player_position Round-Trip")
	assert_eq(restored_data.harvested_objects, data.harvested_objects, "harvested_objects Round-Trip")


func test_new_format_ore_positions_is_array_of_strings() -> void:
	var data := WorldData.new()
	data.ore_positions = [Vector3(7, 0, 8)]
	var saved := WorldSaveAdapter.to_save_dict(data, 6.0, 1)

	assert_true(
		saved["ore_positions"] is Array,
		"FIX (Session 4): ore_positions sollte jetzt ein Array sein (vorher: ein einziger String)"
	)
	assert_eq((saved["ore_positions"] as Array).size(), 1, "ein Eintrag pro Erz-Position")
	assert_true(
		(saved["ore_positions"] as Array)[0] is String,
		"jeder Eintrag ist ein var_to_str(Vector3)-String, wie bei tree_positions"
	)


func test_old_format_ore_positions_is_migrated() -> void:
	# Simuliert einen Save von VOR Session 4: ore_positions als EIN String,
	# der das gesamte Array kodiert (var_to_str(Array[Vector3])).
	var old_positions: Array[Vector3] = [Vector3(1, 0, 1), Vector3(2, 0, 2)]
	var old_save := {
		"day_time": 9.0,
		"day_count": 3,
		"tree_positions": [],
		"ore_positions": var_to_str(old_positions),  # ALT-FORMAT: ein String fürs ganze Array
		"player_pos": var_to_str(Vector3.ZERO),
		"harvested": var_to_str({}),
	}

	var data := WorldData.new()
	var restored_time := WorldSaveAdapter.restore_from_dict(data, old_save)

	assert_eq(restored_time.get("day_count"), 3, "day_count aus Alt-Save sollte gelesen werden")
	assert_eq(
		data.ore_positions, old_positions,
		"Alt-Format ore_positions (ein String fürs ganze Array) sollte korrekt migriert werden"
	)


func test_missing_ore_positions_key_yields_empty_array() -> void:
	# Sehr alter / minimaler Save ohne ore_positions-Key überhaupt.
	var data := WorldData.new()
	data.ore_positions = [Vector3(9, 0, 9)]  # Vorbedingung: nicht leer

	var minimal_save := {"day_time": 6.0, "day_count": 1}
	WorldSaveAdapter.restore_from_dict(data, minimal_save)

	assert_eq(data.ore_positions, [], "Fehlender ore_positions-Key sollte zu [] führen (nicht crashen)")


func test_corrupt_ore_positions_logs_warning_and_yields_empty() -> void:
	# WEDER Array NOCH String — z.B. ein int durch einen kaputten Save.
	# log_warn ist hier ERWARTET (Klassen-Kommentar), kein Testfehler.
	var data := WorldData.new()
	var bad_save := {"ore_positions": 12345}

	WorldSaveAdapter.restore_from_dict(data, bad_save)
	assert_eq(data.ore_positions, [], "Korrupter ore_positions-Typ sollte zu [] führen, nicht crashen")


func test_meta_pets_and_camera_state_round_trip() -> void:
	var data := WorldData.new()
	var pets := [{"name": "Bello", "pos": var_to_str(Vector3(1, 1, 1)), "color": var_to_str(Color.RED)}]
	data.set_meta("saved_pets", pets)
	data.set_meta("camera_state", {"yaw": 1.2, "zoom": 8.0})

	var saved := WorldSaveAdapter.to_save_dict(data, 6.0, 1)
	assert_true(saved.has("saved_pets"), "saved_pets sollte im Save-Dict landen")
	assert_true(saved.has("camera_state"), "camera_state sollte im Save-Dict landen")

	var restored := WorldData.new()
	WorldSaveAdapter.restore_from_dict(restored, saved)

	assert_true(restored.has_meta("saved_pets"), "saved_pets sollte nach restore wieder als Meta vorliegen")
	assert_true(restored.has_meta("camera_state"), "camera_state sollte nach restore wieder als Meta vorliegen")
