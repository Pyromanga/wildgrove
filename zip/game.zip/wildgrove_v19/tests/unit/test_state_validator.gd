# res://tests/unit/test_state_validator.gd
class_name TestStateValidator
extends TestCase

## Testet StateValidator gegen die DEFAULT-Transitions aus GameConfig.gd
## (das @export-Dictionary direkt im Script — config/GameConfig.tres
## überschreibt nichts, siehe Review-Session 4 Notiz dazu).
##
## HINWEIS: is_transition_allowed() loggt bei JEDEM ungültigen Übergang ein
## Logger.log_warn(...). Das ist HIER ERWARTET — die WARN-Logs für die
## "soll false sein"-Fälle unten sind Teil des korrekten Verhaltens, kein
## Testfehler. (Siehe TestRunner-Ausgabe: diese Datei meldet trotzdem "OK".)


func test_boot_to_main_menu_is_allowed() -> void:
	var config := GameConfig.new()
	var ok := StateValidator.is_transition_allowed(
		GameEnums.State.BOOT, GameEnums.State.MAIN_MENU, config
	)
	assert_true(ok, "BOOT → MAIN_MENU sollte erlaubt sein")


func test_boot_to_playing_is_rejected() -> void:
	var config := GameConfig.new()
	var ok := StateValidator.is_transition_allowed(
		GameEnums.State.BOOT, GameEnums.State.PLAYING, config
	)
	assert_false(ok, "BOOT → PLAYING sollte NICHT erlaubt sein (muss über LOADING/MAIN_MENU)")


func test_playing_to_paused_is_allowed() -> void:
	var config := GameConfig.new()
	var ok := StateValidator.is_transition_allowed(
		GameEnums.State.PLAYING, GameEnums.State.PAUSED, config
	)
	assert_true(ok, "PLAYING → PAUSED sollte erlaubt sein")


func test_credits_can_only_return_to_main_menu() -> void:
	var config := GameConfig.new()
	var to_menu := StateValidator.is_transition_allowed(
		GameEnums.State.CREDITS, GameEnums.State.MAIN_MENU, config
	)
	var to_playing := StateValidator.is_transition_allowed(
		GameEnums.State.CREDITS, GameEnums.State.PLAYING, config
	)
	assert_true(to_menu, "CREDITS → MAIN_MENU sollte erlaubt sein")
	assert_false(to_playing, "CREDITS → PLAYING sollte NICHT erlaubt sein")


func test_self_transition_is_rejected() -> void:
	# GameManager.change_state() fängt new_state == _current_state VOR dem
	# Validator ab — aber der Validator selbst kennt keine "A → A"-Regel,
	# also sollte er auch hier false liefern (kein Eintrag enthält den
	# eigenen State-Namen).
	var config := GameConfig.new()
	var ok := StateValidator.is_transition_allowed(
		GameEnums.State.PLAYING, GameEnums.State.PLAYING, config
	)
	assert_false(ok, "PLAYING → PLAYING ist in valid_transitions nicht gelistet")


func test_null_config_allows_everything() -> void:
	# is_transition_allowed(..., null) → "return true # Oder Fallback-Logik"
	# Dokumentiert das aktuelle Verhalten: kein Config = keine Einschränkung.
	var ok := StateValidator.is_transition_allowed(
		GameEnums.State.BOOT, GameEnums.State.GAME_OVER, null
	)
	assert_true(ok, "Ohne GameConfig sollte JEDER Übergang erlaubt sein (Fallback)")


func test_every_state_has_at_least_one_outgoing_transition() -> void:
	# Sanity-Check für die Config selbst: kein State darf eine Sackgasse sein
	# (sonst kann das Spiel theoretisch in diesem State "einfrieren").
	var config := GameConfig.new()
	for state_name in GameEnums.State.keys():
		var allowed: Array = config.valid_transitions.get(state_name, [])
		assert_true(
			not allowed.is_empty(),
			"State '%s' hat keine erlaubten Folge-States (Sackgasse in GameConfig)" % state_name
		)
