# res://tests/unit/test_loot_table.gd
class_name TestLootTable
extends TestCase

## Testet LootTable.roll() / get_guaranteed_drops().
##
## roll() ist ZUFALL — die meisten Tests hier prüfen daher INVARIANTEN, die
## für JEDES Zufallsergebnis gelten müssen (z.B. "result.size() <= max_rolls"),
## statt exakter Werte. Die EINZIGEN deterministischen Fälle sind
## Single-Entry-Tables (siehe Kommentare unten, das ist mathematisch
## garantiert, kein "meistens").
##
## WICHTIGE SEMANTIK, die dieser Test dokumentiert (lest das, bevor ihr
## data/loot/*.tres anlegt — aktuell existiert noch keine):
##   roll() würfelt JEDEN Eintrag UNABHÄNGIG: für jeden Entry gilt
##   P(hit) = entry.weight / total_weight. Das ist NICHT "wähle genau einen
##   Eintrag gewichtet aus" (wie man bei "weight" oft intuitiv erwartet),
##   sondern "jeder Eintrag hat eine unabhängige Chance, zusätzlich zu
##   droppen". Ergebnis: roll() kann 0 bis max_rolls Items zurückgeben,
##   auch bei nicht-leerer entries-Liste.


func _make_entry(item_id: String, weight: float, qty_min: int, qty_max: int) -> LootEntry:
	var e := LootEntry.new()
	e.item_id = item_id
	e.weight = weight
	e.quantity_min = qty_min
	e.quantity_max = qty_max
	return e


func test_empty_table_returns_empty_dict() -> void:
	var table := LootTable.new()
	var result := table.roll()
	assert_eq(result, {}, "Leere LootTable sollte {} zurückgeben")


func test_single_entry_table_always_hits() -> void:
	# Mathematisch garantiert (kein Zufall): bei genau einem Entry ist
	# total_weight == entry.weight, also roll_val = randf()*weight <= weight
	# IMMER wahr (randf() in [0,1)). qty_min==qty_max macht auch die Menge fix.
	var table := LootTable.new()
	table.max_rolls = 3
	table.entries = [_make_entry("log_oak", 100.0, 2, 2)]

	for i in range(10):
		var result := table.roll()
		assert_eq(result, {"log_oak": 2}, "Single-Entry-Table sollte deterministisch {log_oak: 2} liefern")


func test_result_never_exceeds_max_rolls() -> void:
	var table := LootTable.new()
	table.max_rolls = 2
	table.entries = [
		_make_entry("log_oak", 50.0, 1, 1),
		_make_entry("sapling", 30.0, 1, 1),
		_make_entry("rare_gem", 20.0, 1, 1),
	]

	for i in range(200):
		var result := table.roll()
		assert_true(
			result.size() <= table.max_rolls,
			"roll() #%d: result.size()=%d sollte <= max_rolls=%d sein" % [i, result.size(), table.max_rolls]
		)


func test_result_only_contains_known_item_ids_with_valid_quantities() -> void:
	var entries := [
		_make_entry("log_oak", 50.0, 1, 3),
		_make_entry("sapling", 10.0, 1, 1),
	]
	var bounds: Dictionary = {
		"log_oak": Vector2i(1, 3),
		"sapling": Vector2i(1, 1),
	}

	var table := LootTable.new()
	table.max_rolls = 3
	table.entries = entries

	for i in range(200):
		var result: Dictionary = table.roll()
		for item_id in result:
			assert_true(
				bounds.has(item_id),
				"roll() #%d lieferte unbekannte item_id '%s'" % [i, item_id]
			)
			var qty: int = result[item_id]
			var b: Vector2i = bounds[item_id]
			assert_true(
				qty >= b.x and qty <= b.y,
				"roll() #%d: '%s' Menge %d außerhalb [%d, %d]" % [i, item_id, qty, b.x, b.y]
			)


func test_guaranteed_drops_single_entry() -> void:
	# Einziger Eintrag: e.weight >= total_weight ist IMMER wahr (total_weight == e.weight).
	var table := LootTable.new()
	table.entries = [_make_entry("log_oak", 100.0, 1, 1)]
	var guaranteed := table.get_guaranteed_drops()
	assert_eq(guaranteed, ["log_oak"], "Bei genau einem Entry sollte er als 'guaranteed' gelten")


func test_guaranteed_drops_empty_with_multiple_positive_weights() -> void:
	# DOKUMENTIERTES VERHALTEN: Mit ZWEI Einträgen, beide weight > 0, kann
	# KEIN Eintrag e.weight >= total_weight erfüllen (total_weight = Summe
	# > jedes einzelne weight). get_guaranteed_drops() ist also nur für
	# Single-Entry-Tables sinnvoll — bei Mehrfach-Einträgen liefert es []
	# selbst wenn EIN Eintrag z.B. weight=1000 von total=1010 hat
	# (praktisch "fast immer", aber nicht "garantiert" im Sinne dieser Funktion).
	var table := LootTable.new()
	table.entries = [
		_make_entry("log_oak", 1000.0, 1, 1),
		_make_entry("rare_gem", 10.0, 1, 1),
	]
	var guaranteed := table.get_guaranteed_drops()
	assert_eq(
		guaranteed, [],
		"Mit 2 Einträgen (beide weight>0) sollte get_guaranteed_drops() [] liefern — auch wenn ein Eintrag weight=1000 von total=1010 hat"
	)
