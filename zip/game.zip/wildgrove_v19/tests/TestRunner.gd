# res://tests/TestRunner.gd
extends Node

## TestRunner — Headless Test-Runner ohne GUT-Abhängigkeit.
##
## AUSFÜHRUNG (ohne Godot-Editor-UI):
##   godot --headless --path . res://tests/TestRunner.tscn
##
## WARUM EINE SZENE (statt `--script` + `extends SceneTree`):
##   Als normale Szene durchläuft dieser Node den GENAU GLEICHEN Boot-Pfad wie
##   MainMenu.tscn — alle Autoloads (Logger, EventBus, Services,
##   ServiceOrchestrator, ...) sind in _ready() bereits vollständig
##   initialisiert. Kein Rätselraten über `--script`-MainLoop-Timing.
##
## WAS LÄUFT:
##   1. tests/unit/*       — reine Logik, brauchen KEINEN erfolgreichen Boot
##                            (z.B. StateValidator, LootTable, WorldData).
##   2. tests/integration/* — prüfen den ECHTEN Boot (Services.*, boot_ok).
##
## EXIT CODE: 0 = alle Tests bestanden, 1 = mindestens ein Fail.
## Für CI: `godot --headless --path . res://tests/TestRunner.tscn; echo $?`

const LOG_CAT := "TestRunner"

const UNIT_TESTS: Array[Script] = [
	preload("res://tests/unit/test_state_validator.gd"),
	preload("res://tests/unit/test_skill_definition.gd"),
	preload("res://tests/unit/test_world_data.gd"),
	preload("res://tests/unit/test_world_save_adapter.gd"),
	preload("res://tests/unit/test_loot_table.gd"),
	preload("res://tests/unit/test_service_dependency_resolver.gd"),
]

const INTEGRATION_TESTS: Array[Script] = [
	preload("res://tests/integration/test_service_integrity.gd"),
]


func _ready() -> void:
	# Eine Frame Vorlauf: falls irgendein Service in on_ready() call_deferred()
	# nutzt, ist das hier durch. Boot selbst (Autoloads) ist zu diesem
	# Zeitpunkt schon fertig — siehe ServiceOrchestrator-Kommentar zu
	# Autoload-vs-Szenen-Timing.
	await get_tree().process_frame

	Logger.log_info("=========================================", LOG_CAT)
	Logger.log_info("  WildGrove — Test-Runner", LOG_CAT)
	Logger.log_info("=========================================", LOG_CAT)

	var failed_classes: Array[String] = []

	Logger.log_info("--- Unit-Tests (reine Logik, kein Boot nötig) ---", LOG_CAT)
	var r1 := _run_group(UNIT_TESTS, failed_classes)

	Logger.log_info("--- Integrationstests (echter Boot) ---", LOG_CAT)
	var r2 := _run_group(INTEGRATION_TESTS, failed_classes)

	var total_pass: int = int(r1["pass"]) + int(r2["pass"])
	var total_fail: int = int(r1["fail"]) + int(r2["fail"])

	Logger.log_info("=========================================", LOG_CAT)
	Logger.log_info("Ergebnis: %d bestanden, %d fehlgeschlagen" % [total_pass, total_fail], LOG_CAT)

	var exit_code := 0
	if total_fail > 0:
		exit_code = 1
		Logger.log_error("FEHLGESCHLAGEN in: %s" % ", ".join(failed_classes), LOG_CAT)
	else:
		Logger.log_info("Alle Tests bestanden.", LOG_CAT)

	Logger.log_info("=========================================", LOG_CAT)
	get_tree().quit(exit_code)


## Instanziiert jede Test-Klasse, ruft per Reflektion alle test_*-Methoden
## auf. failed_classes wird per Referenz mutiert (Array = Referenztyp in
## GDScript) — vermeidet verschachtelte Array-in-Dictionary-Casts.
## Rückgabe: {"pass": int, "fail": int} für DIESE Gruppe.
func _run_group(test_scripts: Array[Script], failed_classes: Array[String]) -> Dictionary:
	var group_pass := 0
	var group_fail := 0

	for test_script in test_scripts:
		var instance: Object = test_script.new()

		var file_name := "?"
		var script_res: Variant = instance.get_script()
		if script_res is Script:
			file_name = (script_res as Script).resource_path.get_file()

		if instance.has_method("setup"):
			instance.call("setup")

		var ran_any := false
		for m in instance.get_method_list():
			var mname := str(m["name"])
			if mname.begins_with("test_"):
				ran_any = true
				instance.call(mname)

		if instance.has_method("teardown"):
			instance.call("teardown")

		if not ran_any:
			Logger.log_warn("%s hat keine test_*-Methoden — toter Testfile?" % file_name, LOG_CAT)
			continue

		var p: int = instance.get("pass_count")
		var f: int = instance.get("fail_count")
		var fails: Array = instance.get("failures")

		group_pass += p
		group_fail += f

		if f > 0:
			failed_classes.append(file_name)
			for msg in fails:
				Logger.log_error("  FAIL [%s] %s" % [file_name, str(msg)], LOG_CAT)
			Logger.log_info("%s: %d/%d bestanden" % [file_name, p, p + f], LOG_CAT)
		else:
			Logger.log_info("%s: %d/%d bestanden ✓" % [file_name, p, p + f], LOG_CAT)

	return {"pass": group_pass, "fail": group_fail}
