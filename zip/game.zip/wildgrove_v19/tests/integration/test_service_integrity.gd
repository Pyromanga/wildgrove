# res://tests/integration/test_service_integrity.gd
class_name TestServiceIntegrity
extends TestCase

## Integrationstest — prüft den ECHTEN Boot (ServiceOrchestrator-Autoload).
##
## UNTERSCHIED zu tests/unit/*: Diese Tests sind nur sinnvoll, wenn der
## komplette Boot bereits gelaufen ist (Services.populate() in Phase 7).
## TestRunner.tscn garantiert das, weil es als normale Szene NACH allen
## Autoloads geladen wird — exakt der Pfad, den MainMenu.tscn auch nimmt.
##
## Ersetzt inhaltlich tests/IntegrationTest.gd (GUT-Stub, der ohne GUT nie
## ausgeführt wurde) — siehe dessen Header-Kommentar.


func test_boot_succeeded() -> void:
	assert_true(
		ServiceOrchestrator.boot_ok,
		"ServiceOrchestrator.boot_ok sollte true sein (Phase: '%s', Grund: '%s')"
		% [ServiceOrchestrator.boot_failure_phase, ServiceOrchestrator.boot_failure_reason]
	)


func test_all_services_populated() -> void:
	var report: Dictionary = Services.get_status_report()
	assert_false(report.is_empty(), "Services.get_status_report() sollte nicht leer sein")

	for key in report:
		var is_valid: bool = report[key]
		assert_true(is_valid, "Services.%s sollte nach Boot eine gültige Instanz sein" % key)


func test_game_manager_started_in_main_menu_state() -> void:
	if not is_instance_valid(Services.game_manager):
		# Bereits oben als Fehler erfasst — hier nicht doppelt melden.
		return
	assert_eq(
		Services.game_manager.get_state(),
		GameEnums.State.MAIN_MENU,
		"GameManager sollte nach start_game() (Phase 8) im Zustand MAIN_MENU sein"
	)
