# res://tests/TestCase.gd
class_name TestCase
extends RefCounted

## TestCase — Minimale Assertion-Basisklasse für headless Unit-Tests.
##
## KEIN GUT nötig. Subklassen:
##   class_name TestFoo extends TestCase
##
##   func test_etwas() -> void:
##       assert_eq(1 + 1, 2, "Mathe funktioniert noch")
##
## TestRunner.gd instanziiert jede TestXyz-Klasse, ruft per Reflektion
## (get_method_list()) alle Methoden auf, die mit "test_" beginnen, und liest
## danach pass_count / fail_count / failures aus.
##
## WARUM RefCounted statt GUT: GUT-Addon ist nicht installiert (siehe
## tests/IntegrationTest.gd Historie). Diese Klasse ist absichtlich winzig —
## falls GUT später dazukommt, lassen sich `assert_*`-Aufrufe mechanisch auf
## GUTs `assert_*` ummappen (Namen sind bewusst ähnlich gewählt).

var pass_count: int = 0
var fail_count: int = 0
var failures: Array[String] = []


## Optionaler Hook — von TestRunner vor den ersten test_*-Aufrufen gerufen.
func setup() -> void:
	pass


## Optionaler Hook — von TestRunner nach allen test_*-Aufrufen gerufen.
func teardown() -> void:
	pass


func assert_true(condition: bool, message: String) -> void:
	if condition:
		pass_count += 1
	else:
		fail_count += 1
		failures.append(message)


func assert_false(condition: bool, message: String) -> void:
	assert_true(not condition, message)


func assert_eq(actual: Variant, expected: Variant, message: String) -> void:
	if actual == expected:
		pass_count += 1
	else:
		fail_count += 1
		failures.append("%s — erwartet: %s, erhalten: %s" % [message, str(expected), str(actual)])


func assert_not_eq(actual: Variant, not_expected: Variant, message: String) -> void:
	if actual != not_expected:
		pass_count += 1
	else:
		fail_count += 1
		failures.append("%s — sollte NICHT gleich %s sein" % [message, str(not_expected)])


func assert_null(value: Variant, message: String) -> void:
	assert_true(value == null, "%s (erhalten: %s)" % [message, str(value)])


func assert_not_null(value: Variant, message: String) -> void:
	assert_true(value != null, message)


## Für Float-Vergleiche — exakte Gleichheit ist bei Floats meist der falsche Test.
func assert_almost_eq(actual: float, expected: float, tolerance: float, message: String) -> void:
	var diff: float = abs(actual - expected)
	assert_true(
		diff <= tolerance,
		"%s — erwartet: %.4f ±%.4f, erhalten: %.4f (Δ=%.4f)" % [message, expected, tolerance, actual, diff]
	)


## Prüft dass ein Array eine bestimmte Größe hat — eigene Methode für bessere
## Fehlermeldungen als assert_eq(arr.size(), n, ...).
func assert_size(arr: Array, expected_size: int, message: String) -> void:
	assert_eq(arr.size(), expected_size, "%s (Array-Größe)" % message)
