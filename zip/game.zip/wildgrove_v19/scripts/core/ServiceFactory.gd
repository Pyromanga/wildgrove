class_name ServiceFactory extends RefCounted

## ServiceFactory — Phase 3 der Boot-Pipeline.
## Instanziiert Services aus GDScript oder PackedScene und registriert sie.
##
## FIX: script.new() kann null zurückgeben wenn das Script Parse-Fehler hat.
##      Vorher: is-Check auf null crashte ohne Log.
##      Jetzt:  explizite null-Prüfung mit präzisem Fehlertext.

const LOG_CAT := "ServiceFactory"


func instantiate_all(
	defs: Array[ServiceDefinition], registry: ServiceRegistry, parent: Node
) -> bool:
	var failed: Array[String] = []
	for def in defs:
		if _create_service(def, registry, parent) == null:
			failed.append(def.service_name)

	if not failed.is_empty():
		Logger.log_error(
			"Instanziierung fehlgeschlagen für: [%s]" % ", ".join(failed), LOG_CAT
		)
		Logger.log_error(
			"Häufige Ursachen: (1) Pfad falsch in BootstrapConfig.tres  "
			+ "(2) GDScript Parse-Fehler in der .gd-Datei  "
			+ "(3) class_name fehlt oder doppelt vergeben.",
			LOG_CAT
		)
		return false

	Logger.log_info("%d Services erfolgreich instanziiert." % defs.size(), LOG_CAT)
	return true


func _create_service(def: ServiceDefinition, registry: ServiceRegistry, parent: Node) -> Object:
	if not ResourceLoader.exists(def.path):
		Logger.log_error("Pfad existiert nicht: '%s' (Service: '%s')" % [def.path, def.service_name], LOG_CAT)
		return null

	var loaded = load(def.path)
	if loaded == null:
		Logger.log_error("load() fehlgeschlagen: '%s' — Datei korrupt oder Parse-Fehler?" % def.path, LOG_CAT)
		return null

	if loaded is PackedScene:
		return _from_scene(loaded, def, registry, parent)
	elif loaded is GDScript:
		return _from_script(loaded, def, registry, parent)

	Logger.log_error(
		"Unbekannter Ressourcentyp für '%s': %s" % [def.service_name, loaded.get_class()], LOG_CAT
	)
	return null


func _from_scene(
	scene: PackedScene, def: ServiceDefinition, registry: ServiceRegistry, parent: Node
) -> Node:
	var instance: Node = scene.instantiate()
	if instance == null:
		Logger.log_error("PackedScene.instantiate() gab null zurück: '%s'" % def.service_name, LOG_CAT)
		return null
	instance.name = def.service_name
	registry.register(instance, def)
	parent.add_child(instance)
	return instance


func _from_script(
	script: GDScript, def: ServiceDefinition, registry: ServiceRegistry, parent: Node
) -> Object:
	var instance: Object = script.new()

	# KRITISCH: script.new() gibt null zurück wenn das Script Parse-Fehler hat.
	# In Godot 4 gibt es keine Exception — es ist stilles null.
	if instance == null:
		Logger.log_error(
			"script.new() gab null zurück für '%s' ('%s').\n"
			+ "  → Öffne die Datei in Godot um den Parse-Fehler zu sehen." % [def.service_name, def.path],
			LOG_CAT
		)
		return null

	if instance is Node:
		instance.name = def.service_name
		registry.register(instance, def)
		parent.add_child(instance)
	else:
		if "service_name" in instance:
			instance.service_name = def.service_name
		registry.register(instance, def)

	return instance
