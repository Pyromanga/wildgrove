extends Node

## ServiceOrchestrator — Zentrale Boot- und Teardown-Drehscheibe.
##
## AutoLoad #5 (nach Logger, EventBus, SimpleTerminal, Services).
## Lebt für die gesamte Spiellaufzeit und überlebt alle Szenenwechsel.
##
## Boot-Pipeline:
##   Phase 1 — Validate:    ServiceValidator prüft BootstrapConfig.tres
##   Phase 2 — Resolve:     ServiceDependencyResolver (Kahn's Algorithmus)
##   Phase 3 — Instantiate: ServiceFactory erzeugt Instanzen
##   Phase 4 — Configure:   ServiceInitializer ruft configure(deps) auf
##   Phase 5 — Activate:    ServiceInitializer ruft on_ready() auf
##   Phase 6 — Tick Start:  ServiceTicker wird gestartet
##   Phase 7 — Install:     Services-Container wird befüllt
##   Phase 8 — Game Start:  GameManager.start_game() löst Szenenwechsel aus

const LOG_CAT := "Orchestrator"

var registry := ServiceRegistry.new()
var validator := ServiceValidator.new()
var resolver := ServiceDependencyResolver.new()
var factory := ServiceFactory.new()
var initializer := ServiceInitializer.new()
var installer := ServiceInstaller.new()
var teardown := ServiceTeardownManager.new()


func _ready() -> void:
	# Als Autoload lebt dieser Node für die gesamte Laufzeit des Spiels.
	# Services werden einmal gebootet und überleben alle Szenenwechsel.
	boot()


func _notification(what: int) -> void:
	# Nur beim echten App-Exit teardown — NICHT bei Szenenwechseln.
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_CRASH:
		_teardown()


# ─────────────────────────────────────────────
# Boot
# ─────────────────────────────────────────────


func boot() -> void:
	Logger.log_info("╔══ BOOT START ══╗", LOG_CAT)
	var started := Time.get_ticks_msec()

	# --- Phase 1: Validierung ---
	var defs := validator.validate()
	if defs.is_empty():
		Logger.log_error("Phase 1 FAIL — BootstrapConfig leer oder defekt.", LOG_CAT)
		EventBus.system.boot_failed.emit("validate", "BootstrapConfig ungültig")
		return
	Logger.log_info("Phase 1 OK — %d Definitionen geladen." % defs.size(), LOG_CAT)

	# --- Phase 2: Dependency-Auflösung ---
	var ordered := resolver.resolve(defs)
	if ordered.is_empty():
		Logger.log_error("Phase 2 FAIL — Zirkuläre Abhängigkeiten oder unbekannter Service.", LOG_CAT)
		EventBus.system.boot_failed.emit("resolve", "Dependency-Fehler")
		return
	Logger.log_info("Phase 2 OK — Reihenfolge: [%s]" % ", ".join(ordered), LOG_CAT)

	# --- Phase 3: Instanziierung ---
	# Definitionen in aufgelöster Reihenfolge sortieren damit Factory-Fehler
	# in der richtigen Sequenz geloggt werden.
	var ordered_defs: Array[ServiceDefinition] = []
	var def_map: Dictionary = {}
	for d in defs:
		def_map[d.service_name.to_lower()] = d
	for name in ordered:
		if def_map.has(name):
			ordered_defs.append(def_map[name])

	var ok := factory.instantiate_all(ordered_defs, registry, self)
	if not ok:
		Logger.log_error(
			"Phase 3 FAIL — Mindestens ein Service konnte nicht instanziiert werden.\n"
			+ "  → Starte Godot und öffne die betroffene .gd-Datei um den Parse-Fehler zu sehen.",
			LOG_CAT
		)
		EventBus.system.boot_failed.emit("factory", "Instanziierung fehlgeschlagen")
		return
	Logger.log_info("Phase 3 OK — Alle Services instanziiert.", LOG_CAT)

	# --- Phase 4: Init (Konfiguration + Dependency Injection) ---
	initializer.run(ordered, registry)
	Logger.log_info("Phase 4 OK — configure() abgeschlossen.", LOG_CAT)

	# --- Phase 5: Activate (on_ready) ---
	initializer.run_on_ready(ordered, registry)
	Logger.log_info("Phase 5 OK — on_ready() abgeschlossen.", LOG_CAT)

	# --- Phase 6: Service-Ticker Start ---
	var ticker := registry.get_service("ticker") as ServiceTicker
	if ticker:
		ticker.start_ticking()
		Logger.log_info("Phase 6 OK — Ticker gestartet.", LOG_CAT)
	else:
		Logger.log_warn("Phase 6 — Kein Ticker in Registry.", LOG_CAT)

	# --- Phase 7: Installation & Globaler Zugriff ---
	var final_registry := installer.install(registry)
	Services.populate(final_registry)
	Logger.log_info("Phase 7 OK — Services-Container befüllt.", LOG_CAT)

	# --- Phase 8: Gameloop Start ---
	var gm := registry.get_service("gamemanager")
	if gm is GameManager:
		Logger.log_info("Phase 8 — GameManager.start_game().", LOG_CAT)
		gm.start_game()
	else:
		Logger.log_warn("Phase 8 — GameManager nicht in Registry, Spielstart übersprungen.", LOG_CAT)

	EventBus.system.services_initialized.emit()

	var elapsed := Time.get_ticks_msec() - started
	Logger.log_info("╚══ BOOT FERTIG (%d ms) ══╝" % elapsed, LOG_CAT)


# ─────────────────────────────────────────────
# Teardown
# ─────────────────────────────────────────────


func _teardown() -> void:
	Logger.log_info("── Teardown gestartet", LOG_CAT)
	Services.clear()
	teardown.execute(registry)
	Logger.log_info("── Teardown fertig", LOG_CAT)


# ─────────────────────────────────────────────
# Debug API (für SimpleTerminal)
# ─────────────────────────────────────────────


## Gibt alle registrierten Service-Namen zurück. Nützlich für Debug-Commands.
func get_registered_names() -> Array[String]:
	return registry.get_all_names()


## Gibt Laufzeit-Info über einen einzelnen Service zurück.
func get_service_info(service_name: String) -> Dictionary:
	var svc := registry.get_service(service_name)
	var def := registry.get_definition(service_name)
	if svc == null:
		return {"error": "Service '%s' nicht gefunden." % service_name}
	return {
		"name": service_name,
		"class": svc.get_class(),
		"valid": is_instance_valid(svc),
		"deps": def.deps if def else [],
	}
