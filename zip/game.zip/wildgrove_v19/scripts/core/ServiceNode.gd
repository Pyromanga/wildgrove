# res://scripts/core/ServiceNode.gd
class_name ServiceNode extends Node

## ServiceNode — Basisklasse für Node-basierte Services.
##
## Node-Services erben hiervon wenn sie im SceneTree leben müssen
## (z.B. weil sie _process, _physics_process oder Signals auf Node-Ebene brauchen).
##
## Registrierung übernimmt AUSSCHLIESSLICH die ServiceFactory — VOR add_child().
## Dieser Node sucht keinen Orchestrator, hält keine Registry-Referenz,
## und macht in _ready() gar nichts Infrastruktur-bezogenes.
##
## Lifecycle-Methoden (von ServiceInitializer aufgerufen):
##   configure(deps) — Phase 4: Dependency Injection (deps[dep_name] = Service-Instanz)
##   on_ready()       — Phase 5: Cross-Service-Setup, Signals connecten
##   on_cleanup()     — Phase 7: Teardown-Logik
##
## HISTORIE (Review-Session 4): Diese Klasse deklarierte vorher `func init()`
## als "Phase 4"-Hook. ServiceInitializer.run() ruft aber configure(deps) auf —
## init() wurde NIE aufgerufen. Jeder der 15 Services implementierte bereits
## configure(deps), aber die Basisklasse (= der dokumentierte Vertrag) zeigte
## init(). Wer init() implementiert hätte, hätte stillschweigend keine
## Dependencies erhalten (nur eine WARN im Log). Fix: configure(deps) ist jetzt
## der EINZIGE, in der Basisklasse deklarierte Phase-4-Hook.

# ─────────────────────────────────────────────
# Lifecycle-Interface (von Pipeline aufgerufen)
# ─────────────────────────────────────────────


## Phase 4: Dependency Injection. deps enthält die in ServiceDefinition.deps
## gelisteten Service-Instanzen, Key = Service-Name in Kleinbuchstaben.
## NICHT EventBus/Services-Signale connecten — das ist Phase 5 (on_ready).
func configure(_deps: Dictionary) -> void:
	pass


func on_ready() -> void:
	pass


func on_cleanup() -> void:
	pass
