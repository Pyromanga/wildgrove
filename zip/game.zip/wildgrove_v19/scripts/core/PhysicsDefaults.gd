# res://scripts/core/PhysicsDefaults.gd
class_name PhysicsDefaults

## PhysicsDefaults — Geteilte Physik-Konstanten für Nicht-Spieler-Bewegung.
##
## HINTERGRUND (Review-Session 4):
##   `const GRAVITY: float = 9.8` war identisch in DREI Dateien dupliziert:
##     - scripts/world/animals/AnimalBase.gd
##     - scripts/world/combat/EnemyNPC.gd
##     - scripts/world/pets/PetComponent.gd
##   Gleichzeitig nutzt der Spieler PlayerData.gravity = 12.0
##   (res://config/PlayerData.tres, via Services.data.get_player_stat("gravity")).
##
## DAS IST KEIN BUG — unterschiedliche Gravity für Spieler vs. NPCs/Tiere/Pets
## kann ein bewusstes Gameplay-Gefühl sein (Spieler fällt "snappiger"). Aber:
## DREI Kopien derselben Zahl bedeuten DREI Stellen zum Vergessen, wenn ihr
## das jemals tunen wollt. Diese Datei macht es zu EINER Stelle.
##
## project.godot 3d/default_gravity=9.8 betrifft NUR Godots eigene Physik
## (RigidBody3D etc.), NICHT diese CharacterBody3D-basierten Klassen — die
## Werte sind aktuell zufällig identisch, aber konzeptionell getrennt.
##
## NICHT für den Spieler verwenden — der bleibt explizit datengetrieben über
## PlayerData.tres (Inspector-editierbar, Save/Load-fähig als Resource).

## Standard-Fallgeschwindigkeit für NPCs, Tiere und Pets (m/s²).
const GRAVITY_NPC: float = 9.8
