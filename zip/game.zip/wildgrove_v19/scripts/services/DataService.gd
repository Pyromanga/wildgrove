extends ServiceNode
class_name DataService

## DataService — Zentrales Repository für ALLE statischen Spieldaten.
##
## REFACTOR (Session 4):
##   VORHER: Lud nur PlayerData.tres. Item-DB lebte in InventorySystem,
##           Quest-Definitionen in QuestService. Drei Services luden unabhängig
##           Daten — kein zentrales Repository, kein Caching, inkonsistente Pfade.
##   NACHHER: Einziger Ladeort für alle statischen .tres-Ressourcen.
##            InventorySystem und QuestService rufen get_item() / get_quest() auf,
##            statt selbst DirAccess zu öffnen.
##
## Was DataService lädt:
##   - PlayerData.tres       → Spieler-Konfiguration (Speed, Gravity, …)
##   - data/items/*.tres     → ItemDefinition-Ressourcen
##   - data/quests/*.tres    → QuestDefinition-Ressourcen (wenn vorhanden)
##   - data/skills/*.tres    → SkillDefinition-Ressourcen (wenn vorhanden)
##
## Was DataService NICHT tut:
##   - Keinen Laufzeit-State halten (Inventar, Quest-Fortschritt, Skills)
##   - Kein SaveSystem-Provider (statische Daten ändern sich nicht)

const LOG_CAT := "DataService"

const PLAYER_DATA_PATH := "res://config/PlayerData.tres"
# Item/Quest/Skill-Pfade sind jetzt in DataManifest — kein DirAccess mehr nötig.

var player_data: PlayerData

## Repositories — befüllt in configure()
var _items:  Dictionary = {}   # { item_id:  ItemDefinition  }
var _quests: Dictionary = {}   # { quest_id: QuestDefinition }
var _skills: Dictionary = {}   # { skill_id: SkillDefinition } — leer bis SkillDefinition.tres existieren


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────
func configure(_deps: Dictionary) -> void:
	var t := Logger.log_begin("DataService.configure()", LOG_CAT)
	_load_player_data()
	_load_items()
	_load_quests()
	_load_skills()
	Logger.log_end("DataService.configure()", t, LOG_CAT)
	Logger.log_info(
		"Geladen: %d Items, %d Quests, %d Skills."
		% [_items.size(), _quests.size(), _skills.size()],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Öffentliche API — PlayerData
# ─────────────────────────────────────────────


## Liest einen numerischen Spieler-Konfigurationswert.
func get_player_stat(stat_name: String, default_val: float = 0.0) -> float:
	if not player_data:
		Logger.log_error("Abfrage '%s' fehlgeschlagen: player_data ist NULL!" % stat_name, LOG_CAT)
		return default_val

	var value: Variant = player_data.get(stat_name)
	if value != null:
		return float(value)

	Logger.log_warn("Stat '%s' existiert nicht in PlayerData.tres!" % stat_name, LOG_CAT)
	return default_val


## Setzt einen Stat im Speicher (nicht persistiert — nur für Runtime-Tweaks).
func set_player_stat(stat_name: String, value: float) -> void:
	if player_data:
		if stat_name in player_data:
			player_data.set(stat_name, value)
		else:
			Logger.log_warn("Versuch unbekannten Stat zu setzen: %s" % stat_name, LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API — Items
# ─────────────────────────────────────────────


## Gibt die ItemDefinition für eine ID zurück, oder null.
func get_item(item_id: String) -> ItemDefinition:
	return _items.get(item_id)


## Gibt alle geladenen Items zurück (für InventorySystem-Initialisierung).
func get_all_items() -> Dictionary:
	return _items


# ─────────────────────────────────────────────
# Öffentliche API — Quests
# ─────────────────────────────────────────────


## Gibt die QuestDefinition für eine ID zurück, oder null.
func get_quest(quest_id: String) -> QuestDefinition:
	return _quests.get(quest_id)


## Gibt alle geladenen Quest-Definitionen zurück.
func get_all_quests() -> Dictionary:
	return _quests


## Gibt alle Quest-IDs mit auto_start=true zurück (für QuestService-Initialisierung).
func get_auto_start_quests() -> Array[String]:
	var result: Array[String] = []
	for id in _quests:
		var q: QuestDefinition = _quests[id]
		if q.auto_start:
			result.append(id)
	return result


# ─────────────────────────────────────────────
# Öffentliche API — Skills
# ─────────────────────────────────────────────


## Gibt alle geladenen SkillDefinitions zurück.
## Leer bis res://data/skills/*.tres Dateien existieren.
func get_all_skills() -> Dictionary:
	return _skills


# ─────────────────────────────────────────────
# Intern — Lader
# ─────────────────────────────────────────────


func _load_player_data() -> void:
	if not ResourceLoader.exists(PLAYER_DATA_PATH):
		Logger.log_error("KRITISCH: PlayerData fehlt unter '%s'!" % PLAYER_DATA_PATH, LOG_CAT)
		return
	player_data = load(PLAYER_DATA_PATH) as PlayerData
	if player_data:
		Logger.log_debug(
			"PlayerData geladen. Speed=%.1f, Gravity=%.1f." % [player_data.speed, player_data.gravity],
			LOG_CAT
		)
	else:
		Logger.log_error(
			"PlayerData Cast fehlgeschlagen — Script-Pfad in PlayerData.tres prüfen! "
			+ "Erwartet: res://scripts/resources/PlayerData.gd",
			LOG_CAT
		)


func _load_items() -> void:
	_items = {}
	for path: String in DataManifest.ITEMS:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("Item nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		if not res is ItemDefinition:
			Logger.log_warn("'%s' ist kein ItemDefinition." % path, LOG_CAT)
			continue
		var item := res as ItemDefinition
		_items[item.id] = item
	Logger.log_debug("Items geladen: %d" % _items.size(), LOG_CAT)


func _load_quests() -> void:
	_quests = {}
	for path: String in DataManifest.QUESTS:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("Quest nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		if not res is QuestDefinition:
			Logger.log_warn("'%s' ist kein QuestDefinition." % path, LOG_CAT)
			continue
		var quest := res as QuestDefinition
		_quests[quest.id] = quest
	Logger.log_debug("Quests geladen: %d" % _quests.size(), LOG_CAT)


func _load_skills() -> void:
	_skills = {}
	for path: String in DataManifest.SKILLS:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("Skill nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		# SkillDefinition ist optional — kein Fehler wenn Klasse noch nicht existiert
		if res.get("id") == null:
			Logger.log_warn("'%s' hat kein 'id'-Feld." % path, LOG_CAT)
			continue
		_skills[str(res.get("id"))] = res
	Logger.log_debug("Skills geladen: %d" % _skills.size(), LOG_CAT)
