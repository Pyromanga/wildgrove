extends ServiceNode
class_name GameSaveService

## GameSaveService — Koordinator für übergreifende Speicheroperationen.
##
## v19: Kamera-State (yaw/pitch/zoom) wird vor dem Speichern aus dem Player
## abgerufen und in WorldData.meta gesichert, damit er beim Laden wiederhergestellt
## werden kann (WorldService._restore_player_extras).

const LOG_CAT := "GameSave"

var _save_system: SaveSystem
var _is_saving: bool = false


func configure(deps: Dictionary) -> void:
	_save_system = deps.get("savesystem") as SaveSystem
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem-Dependency fehlt!", LOG_CAT)


func on_ready() -> void:
	EventBus.system.save_requested.connect(_on_save_requested)
	Logger.log_info("GameSaveService bereit. Lauscht auf save_requested.", LOG_CAT)


func save_all() -> bool:
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem nicht verfügbar — Speichern abgebrochen!", LOG_CAT)
		return false

	if _is_saving:
		Logger.log_warn("save_all() bereits aktiv — doppelter Aufruf ignoriert.", LOG_CAT)
		return false

	_is_saving = true
	var t := Logger.log_begin("save_all()", LOG_CAT)

	_save_pets()
	_save_camera_state()  # v19: Kamera-Winkel/Zoom sichern

	var success := _save_system.save_game()
	Logger.log_end("save_all()", t, LOG_CAT)
	_is_saving = false

	if success:
		Logger.log_info("Speichervorgang erfolgreich.", LOG_CAT)
	else:
		Logger.log_error("Speichervorgang fehlgeschlagen!", LOG_CAT)

	return success


func _save_pets() -> void:
	if not is_instance_valid(Services.world):
		return
	var pet_data: Array = []
	var pets: Array = get_tree().get_nodes_in_group("pets")
	for pet in pets:
		if pet is PetComponent:
			pet_data.append({
				"pos":   var_to_str(pet.global_position),
				"color": var_to_str(pet._color),
				"name":  pet._name,
			})
	Services.world.data.set_meta("saved_pets", pet_data)
	Logger.log_debug("Pets gespeichert: %d" % pet_data.size(), LOG_CAT)


## v19: Kamera-State (yaw, pitch, zoom) aus dem Player lesen und in WorldData sichern.
## WorldService._restore_player_extras() liest diesen Wert nach dem Laden zurück.
func _save_camera_state() -> void:
	if not is_instance_valid(Services.world):
		return
	var players: Array = get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: Object = players[0]
	if player.has_method("get_camera_state"):
		var cam_state: Dictionary = player.get_camera_state()
		if not cam_state.is_empty():
			Services.world.data.set_meta("camera_state", cam_state)
			Logger.log_debug(
				"Kamera-State gespeichert: yaw=%.2f zoom=%.1f"
				% [cam_state.get("yaw", 0.0), cam_state.get("zoom", 8.0)],
				LOG_CAT
			)


func _on_save_requested() -> void:
	Logger.log_info("save_requested empfangen — starte save_all().", LOG_CAT)
	save_all()
