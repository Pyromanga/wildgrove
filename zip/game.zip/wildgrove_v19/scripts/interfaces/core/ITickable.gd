# res://scripts/interfaces/core/ITickable.gd
class_name ITickable
extends RefCounted

## ITickable — Vertrag für Services, die jeden Frame / Physik-Tick laufen wollen.
##
## GDSCRIPT-LIMITATION (siehe auch IInteractable.gd): Diese Klasse kann NICHT
## als Basisklasse für tick-fähige Services dienen — die erben bereits von
## Service/ServiceNode (und die wiederum von RefCounted/Node). Mehrfachvererbung
## gibt es in GDScript nicht. Diese Datei war vorher genau dieser (toter)
## Vererbungs-Versuch: zwei leere `func on_tick()` / `func on_physics_tick()`
## Stubs, von niemandem implementiert, von niemandem aufgerufen.
##
## TATSÄCHLICHER VERTRAG (so wird er gelebt — siehe ServiceTicker.register_service):
##   ServiceTicker prüft has_method("on_tick") / has_method("on_physics_tick")
##   per Duck-Typing. JEDER Service kann also optional eine oder beide
##   Methoden implementieren — ohne von irgendetwas zu erben:
##
##     func on_tick(delta: float) -> void:
##         ...
##
##     func on_physics_tick(delta: float) -> void:
##         ...
##
## Diese Datei ist reine Dokumentation des Vertrags + ein Helper für Tests
## (tests/unit/), die prüfen wollen "verhält sich X wie ein Tickable?", ohne
## ServiceTicker selbst zu instanziieren.


## true wenn obj mindestens eine der Tick-Methoden implementiert.
## Nutzt exakt die gleichen has_method()-Checks wie ServiceTicker.register_service —
## EIN Ort für "was zählt als tickable", auch für Unit-Tests nutzbar.
static func is_tickable(obj: Object) -> bool:
	if not is_instance_valid(obj):
		return false
	return obj.has_method("on_tick") or obj.has_method("on_physics_tick")
