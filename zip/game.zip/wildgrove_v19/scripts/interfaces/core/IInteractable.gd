# res://scripts/interfaces/core/IInteractable.gd
class_name IInteractable
extends RefCounted

## IInteractable — Vertrag für alles, das Kontext-Aktionen anbietet.
##
## GDSCRIPT-LIMITATION (wichtig, lest das bevor ihr hier "echte" Vererbung
## einbauen wollt): GDScript hat KEINE Interfaces und KEINE Mehrfachvererbung.
## `InteractableComponent` braucht `extends Node3D`, `EnemyNPC` braucht
## `extends CharacterBody3D` — beide können NICHT zusätzlich von einer
## gemeinsamen `IInteractable`-Basisklasse erben, ohne ihre eigentliche
## Node-Basisklasse zu verlieren. Exakt dasselbe Problem, das
## `scripts/ui/components/BaseUIComponent.gd` für `build()` dokumentiert.
##
## DESHALB: Dieses "Interface" ist (a) ein dokumentierter Namens-/Signatur-
## Vertrag und (b) EIN zentraler, typisierter Zugriffspunkt für den
## duck-typed Zugriff. Vorher stand das untypisierte `var comp = ...` direkt
## in `Player.get_context_actions()` mit einem Kommentar, warum die
## "No-Guessing"-Regel (principles.md #1) hier bewusst gebrochen wird. Jetzt
## ist die Ausnahme auf GENAU diese eine Funktion konzentriert, typisiert,
## und unter einem Namen, der die Ausnahme selbst dokumentiert.
##
## VERTRAG — wer hier mitspielen will, MUSS implementieren:
##   func get_actions() -> Array[InteractableAction]
##
## ...UND sich selbst per set_meta("interactable_component", self) auf dem
## Node registrieren, den InteractionSensor als "interactable" findet
## (siehe InteractableComponent._ready() / EnemyNPC._ready()).
##
## Implementierende Klassen (Stand Review-Session 4):
##   - InteractableComponent  (Bäume, Erze, generische Welt-Objekte)
##   - EnemyNPC                (Gegner — Angreifen-Aktion)
##
## Neue interagierbare Entity-Art? → get_actions() -> Array[InteractableAction]
## implementieren + set_meta("interactable_component", self) in _ready().
## Sonst nichts zu tun — get_actions_for() unten findet sie automatisch.


## Sicherer, typisierter Zugriff auf die Kontext-Aktionen eines Ziels.
## Gibt IMMER ein (ggf. leeres) Array[InteractableAction] zurück — nie null.
##
## Zentralisiert den Duck-Type-Check (has_meta + has_method), den vorher
## Player.get_context_actions() inline gemacht hat.
static func get_actions_for(target: Node) -> Array[InteractableAction]:
	var out: Array[InteractableAction] = []

	if not is_instance_valid(target):
		return out
	if not target.has_meta("interactable_component"):
		return out

	var comp: Object = target.get_meta("interactable_component")
	if not is_instance_valid(comp) or not comp.has_method("get_actions"):
		Logger.log_warn(
			"IInteractable.get_actions_for(): Meta auf '%s' ist invalid oder hat kein get_actions()."
			% target.name,
			"IInteractable"
		)
		return out

	# comp.get_actions() liefert je Implementierung Array oder Array[InteractableAction] —
	# hier elementweise in das typisierte Ergebnis übernehmen (keine impliziten
	# Array-Typkonvertierungen, die je nach Godot-Version unterschiedlich strikt sind).
	var raw: Variant = comp.get_actions()
	if raw is Array:
		for item in (raw as Array):
			if item is InteractableAction:
				out.append(item)

	return out


## true wenn target Kontext-Aktionen über das IInteractable-Pattern anbietet
## (also has_meta("interactable_component") + get_actions()).
## Nützlich für Caller, die nur "gibt es überhaupt etwas?" wissen wollen,
## ohne das Array selbst zu bauen (z.B. für einen schnellen UI-Hinweis).
static func is_interactable(target: Node) -> bool:
	if not is_instance_valid(target):
		return false
	if not target.has_meta("interactable_component"):
		return false
	var comp: Object = target.get_meta("interactable_component")
	return is_instance_valid(comp) and comp.has_method("get_actions")
