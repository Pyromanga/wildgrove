extends CharacterBody3D
class_name Player

## Player.gd — Zentraler Spieler-Controller.
##
## v19 Fixes:
##   - Tod: _on_player_died() → physics pause, EventBus.player.emit_player_died()
##   - Respawn: respawn() → HP reset, Position reset, physics resume
##   - Kamera-State: get_camera_state() / apply_camera_state() für Save/Load

const LOG_CAT := "Player"

var _mover: PlayerMover
var visuals: PlayerVisuals
var camera: PlayerCamera
var input: TouchInput
var sensor: InteractionSensor


func _ready() -> void:
	add_to_group("player")
	set_physics_process(false)
	EventBus.player.movement_interrupted.connect(_on_action_interrupted)
	Logger.log_debug("Player _ready(). Warte auf Services...", LOG_CAT)

	if is_instance_valid(Services.game_manager):
		Logger.log_debug("Services bereits bereit — sofort initialisieren.", LOG_CAT)
		_on_core_ready()
	else:
		Logger.log_debug("Warte auf services_initialized Signal.", LOG_CAT)
		EventBus.system.services_initialized.connect(_on_core_ready, CONNECT_ONE_SHOT)


func _on_core_ready() -> void:
	Logger.log_info("Core bereit — Player-System initialisieren.", LOG_CAT)
	_build_system()
	_apply_stats()
	set_physics_process(true)
	Logger.log_info("Player-System online. Physics-Process aktiv.", LOG_CAT)


func _physics_process(delta: float) -> void:
	if not is_instance_valid(Services.player_states):
		return

	match Services.player_states.get_state():
		PlayerStateService.State.FREE:
			_loop_free(delta)
		PlayerStateService.State.BUSY:
			_loop_busy(delta)
		_:
			velocity = Vector3.ZERO
			move_and_slide()


func _loop_free(delta: float) -> void:
	var move_dir := MathHelper.calculate_move_direction(camera, input.js_vec)
	velocity = _mover.calculate_velocity(velocity, move_dir, delta, is_on_floor())
	move_and_slide()
	visuals.handle_rotation(move_dir, delta)
	camera.handle_input(input, delta)


func _loop_busy(delta: float) -> void:
	if input.js_vec.length() > 0.5:
		Logger.log_debug("Bewegung während Interaktion → interrupt.", LOG_CAT)
		EventBus.player.emit_movement_interrupted()
	velocity = velocity.move_toward(Vector3.ZERO, 15.0 * delta)
	move_and_slide()
	camera.handle_input(input, delta)


func _on_action_interrupted() -> void:
	Logger.log_debug("Aktion unterbrochen — Shake-Effekt.", LOG_CAT)
	visuals.play_effect("interrupted")


# ─────────────────────────────────────────────
# Tod & Respawn (v19)
# ─────────────────────────────────────────────


func _on_player_died() -> void:
	Logger.log_warn("Spieler gestorben.", LOG_CAT)
	set_physics_process(false)
	velocity = Vector3.ZERO
	EventBus.player.emit_player_died()


## Respawn: HP zurücksetzen, sicheren Spawn-Punkt anfahren, Physik wieder aktivieren.
## Wird vom Death-Screen (HUDBuilder) aufgerufen wenn der "Respawn"-Button gedrückt wird.
func respawn() -> void:
	Logger.log_info("Respawn ausgeführt.", LOG_CAT)
	# HP zurücksetzen
	var health := find_child("HealthComponent", true, false) as HealthComponent
	if is_instance_valid(health):
		health.reset()

	# Sicherer Spawn: Terrain-Höhe am Ursprung + Offset
	var spawn_y := 5.0
	if is_instance_valid(Services.world) and is_instance_valid(Services.world.factory) \
			and is_instance_valid(Services.world.factory.terrain_generator):
		spawn_y = Services.world.factory.terrain_generator.get_height_at(0.0, 0.0) + 3.0
	position = Vector3(0.0, spawn_y, 0.0)
	velocity = Vector3.ZERO

	set_physics_process(true)
	EventBus.player.emit_player_respawned()
	Logger.log_info("Spieler respawned bei Y=%.1f." % spawn_y, LOG_CAT)


# ─────────────────────────────────────────────
# Kamera-State (v19 — für Save/Load)
# ─────────────────────────────────────────────


## Gibt aktuellen Kamera-Winkel und Zoom zurück.
## Wird von GameSaveService vor dem Speichern aufgerufen.
func get_camera_state() -> Dictionary:
	if not is_instance_valid(camera):
		return {}
	return {
		"yaw":   camera._target_yaw,
		"pitch": camera._target_pitch,
		"zoom":  camera._target_zoom,
	}


## Stellt Kamera-Winkel und Zoom wieder her.
## Wird von WorldService nach dem Laden aufgerufen.
func apply_camera_state(state: Dictionary) -> void:
	if not is_instance_valid(camera):
		return
	camera._target_yaw   = state.get("yaw",   0.0)
	camera._target_pitch = state.get("pitch",  deg_to_rad(-35.0))
	camera._target_zoom  = state.get("zoom",   8.0)
	# Sofort snappen (kein Lerp-Einlauf beim Laden)
	camera.rotation.y    = camera._target_yaw
	camera.rotation.x    = camera._target_pitch
	camera.spring_length = camera._target_zoom
	Logger.log_debug(
		"Kamera-State angewandt: yaw=%.2f pitch=%.2f zoom=%.1f"
		% [camera._target_yaw, rad_to_deg(camera._target_pitch), camera._target_zoom],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


func get_closest_interactable() -> Node3D:
	if not is_instance_valid(sensor):
		Logger.log_warn("get_closest_interactable(): kein Sensor!", LOG_CAT)
		return null
	return sensor.get_closest()


func get_context_actions() -> Array:
	var target := get_closest_interactable()
	if not is_instance_valid(target):
		return []

	Logger.log_debug(
		"get_context_actions(): Ziel '%s'. Suche interactable_component Meta." % target.name,
		LOG_CAT
	)

	if target.has_meta("interactable_component"):
		var comp: Object = target.get_meta("interactable_component")
		if is_instance_valid(comp) and comp.has_method("get_actions"):
			var actions := comp.get_actions()
			Logger.log_info(
				"get_context_actions(): %d Aktion(en) für '%s'." % [actions.size(), target.name],
				LOG_CAT
			)
			return actions

	# Child-Traversal Fallback
	for child in target.get_children():
		if child is InteractableComponent:
			return (child as InteractableComponent).get_actions()

	if target.has_method("start_default_interaction"):
		var fallback := InteractableAction.new("interact", "Interagieren")
		fallback.duration = 1.5
		fallback.on_complete = func(): target.start_default_interaction()
		return [fallback]

	return []


# ─────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────


func _build_system() -> void:
	Logger.log_debug("Baue Player-System (Collision, Mover, Visuals, Camera, Input, Sensor).", LOG_CAT)
	_setup_collision()
	_mover = PlayerMover.new()
	visuals = PlayerVisuals.new()
	camera = PlayerCamera.new()
	input = TouchInput.new()
	sensor = _build_sensor()

	add_child(visuals)
	add_child(camera)
	add_child(input)
	input.add_to_group("touch_input")
	input.connect_to_event_bus()
	add_child(sensor)

	# HealthComponent
	var health := HealthComponent.new()
	health.name = "HealthComponent"
	health.max_health = 100
	add_child(health)
	# v19: _on_player_died() statt direktem emit — erlaubt physics-pause vor Signal
	health.died.connect(_on_player_died)

	Logger.log_debug(
		"Subsysteme bereit: mover=%s visuals=%s camera=%s input=%s sensor=%s"
		% [
			_mover.get_class(),
			visuals.get_class(),
			camera.get_class(),
			input.get_class(),
			sensor.get_class()
		],
		LOG_CAT
	)


func _build_sensor() -> InteractionSensor:
	var s := InteractionSensor.new()
	s.name = "InteractionSensor"
	var col := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 2.5
	col.shape = shape
	s.add_child(col)
	s.monitoring = true
	s.monitorable = false
	return s


func _setup_collision() -> void:
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.45
	cap.height = 1.8
	col.shape = cap
	col.position.y = 0.9
	add_child(col)


func _apply_stats() -> void:
	if not is_instance_valid(Services.data):
		Logger.log_warn("DataService fehlt — Player nutzt Mover-Defaults.", LOG_CAT)
		return
	var s := Services.data.get_player_stat("speed", 6.0)
	var g := Services.data.get_player_stat("gravity", 12.0)
	_mover.speed = s
	_mover.gravity = g
	Logger.log_info("Stats angewandt: Speed=%.2f, Gravity=%.2f." % [s, g], LOG_CAT)
