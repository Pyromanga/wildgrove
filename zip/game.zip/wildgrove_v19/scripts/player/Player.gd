extends CharacterBody3D
class_name Player

## Player.gd — Zentraler Spieler-Controller.
##
## Boot-Timing:
##   Nach dem Boot ist services_initialized bereits emittiert wenn der Player
##   (via WorldFactory) in die Szene kommt. Das Signal ist history → kommt nicht nochmal.
##   Lösung: Direkt prüfen ob Services.game_manager bereits valid ist → sofort starten.
##
## v19:
##   - Tod: _on_player_died() pausiert physics, emittiert player_died
##   - Respawn: respawn() setzt HP zurück, positioniert Spieler sicher, reaktiviert physics
##   - Kamera-State: get_camera_state() / apply_camera_state() für Save/Load
##   - Combat: get_context_actions() liefert Array[InteractableAction] via
##     IInteractable.get_actions_for() (siehe scripts/interfaces/core/IInteractable.gd)

const LOG_CAT := "Player"

var _mover: PlayerMover
var visuals: PlayerVisuals
var camera: PlayerCamera
var input: TouchInput
var sensor: InteractionSensor


func _ready() -> void:
	add_to_group("player")
	set_physics_process(false)
	EventBus.player.movement_interrupted.connect(_on_action_interrupted)
	Logger.log_debug("Player _ready(). Warte auf Services...", LOG_CAT)

	if is_instance_valid(Services.game_manager):
		Logger.log_debug("Services bereits bereit — sofort initialisieren.", LOG_CAT)
		_on_core_ready()
	else:
		Logger.log_debug("Warte auf services_initialized Signal.", LOG_CAT)
		EventBus.system.services_initialized.connect(_on_core_ready, CONNECT_ONE_SHOT)


func _on_core_ready() -> void:
	Logger.log_info("Core bereit — Player-System initialisieren.", LOG_CAT)
	_build_system()
	_apply_stats()
	set_physics_process(true)
	Logger.log_info("Player-System online. Physics-Process aktiv.", LOG_CAT)


func _physics_process(delta: float) -> void:
	if not is_instance_valid(Services.player_states):
		return

	match Services.player_states.get_state():
		PlayerStateService.State.FREE:
			_loop_free(delta)
		PlayerStateService.State.BUSY:
			_loop_busy(delta)
		_:
			velocity = Vector3.ZERO
			move_and_slide()


func _loop_free(delta: float) -> void:
	var move_dir := MathHelper.calculate_move_direction(camera, input.js_vec)
	velocity = _mover.calculate_velocity(velocity, move_dir, delta, is_on_floor())
	move_and_slide()
	visuals.handle_rotation(move_dir, delta)
	camera.handle_input(input, delta)


func _loop_busy(delta: float) -> void:
	if input.js_vec.length() > 0.5:
		Logger.log_debug("Bewegung während Interaktion → interrupt.", LOG_CAT)
		EventBus.player.emit_movement_interrupted()
	velocity = velocity.move_toward(Vector3.ZERO, 15.0 * delta)
	move_and_slide()
	camera.handle_input(input, delta)


func _on_action_interrupted() -> void:
	Logger.log_debug("Aktion unterbrochen — Shake-Effekt.", LOG_CAT)
	visuals.play_effect("interrupted")


# ─────────────────────────────────────────────
# Tod & Respawn (v19)
# ─────────────────────────────────────────────


## Wird von HealthComponent.died aufgerufen.
## Pausiert Physics damit der Spieler nicht weiterfällt/interagiert, dann Signal.
func _on_player_died() -> void:
	Logger.log_warn("Spieler gestorben.", LOG_CAT)
	set_physics_process(false)
	velocity = Vector3.ZERO
	EventBus.player.emit_player_died()


## Respawn: HP zurücksetzen, sichere Y-Position, Physics reaktivieren.
## Wird vom Tod-Overlay (HUDBuilder._build_death_screen) aufgerufen.
func respawn() -> void:
	Logger.log_info("Respawn ausgeführt.", LOG_CAT)
	var health := find_child("HealthComponent", true, false) as HealthComponent
	if is_instance_valid(health):
		health.reset()
	# Hoch genug spawnen damit der Spieler sicher auf dem Terrain landet
	position = Vector3(0.0, 12.0, 0.0)
	velocity = Vector3.ZERO
	set_physics_process(true)
	EventBus.player.emit_player_respawned()


# ─────────────────────────────────────────────
# Kamera-State (v19 — für Save/Load)
# ─────────────────────────────────────────────


## Gibt aktuellen Kamera-Winkel und Zoom zurück (für GameSaveService).
func get_camera_state() -> Dictionary:
	if not is_instance_valid(camera):
		return {}
	return {
		"yaw":   camera._target_yaw,
		"pitch": camera._target_pitch,
		"zoom":  camera._target_zoom,
	}


## Stellt Kamera-Winkel und Zoom sofort wieder her (nach dem Laden).
func apply_camera_state(state: Dictionary) -> void:
	if not is_instance_valid(camera):
		return
	camera._target_yaw   = state.get("yaw",   0.0)
	camera._target_pitch = state.get("pitch",  deg_to_rad(-35.0))
	camera._target_zoom  = state.get("zoom",   8.0)
	# Sofort snappen ohne Lerp damit es beim Laden nicht einschwingt
	camera.rotation.y    = camera._target_yaw
	camera.rotation.x    = camera._target_pitch
	camera.spring_length = camera._target_zoom


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


func get_closest_interactable() -> Node3D:
	if not is_instance_valid(sensor):
		Logger.log_warn("get_closest_interactable(): kein Sensor!", LOG_CAT)
		return null
	return sensor.get_closest()


## Gibt alle verfügbaren Aktionen des nächsten Interagierbaren zurück.
## Wird von ContextMenuController aufgerufen wenn der Spieler den Kontext-Button drückt.
##
## FIX (Review-Session 4): Das untypisierte `var comp = ...get_meta(...)` lebt
## jetzt zentral in IInteractable.get_actions_for() (scripts/interfaces/core/),
## inkl. Begründung warum GDScript hier kein echtes Interface erlaubt. Diese
## Funktion bleibt vollständig typisiert.
func get_context_actions() -> Array[InteractableAction]:
	var target := get_closest_interactable()
	if not is_instance_valid(target):
		Logger.log_debug("get_context_actions(): kein Ziel in Reichweite.", LOG_CAT)
		return []

	Logger.log_debug("get_context_actions(): Ziel '%s'." % target.name, LOG_CAT)

	var actions := IInteractable.get_actions_for(target)
	if not actions.is_empty():
		Logger.log_info(
			"get_context_actions(): %d Aktion(en) für '%s'." % [actions.size(), target.name],
			LOG_CAT
		)
		return actions

	# Fallback: Child-Traversal (langsamer, aber robust) — für Objekte ohne Meta
	Logger.log_warn(
		"Kein interactable_component-Meta auf '%s' — nutze Child-Traversal als Fallback." % target.name, LOG_CAT
	)
	for child in target.get_children():
		if child is InteractableComponent:
			return (child as InteractableComponent).get_actions()

	# Letzter Fallback: generische Interagieren-Aktion
	if target.has_method("start_default_interaction"):
		Logger.log_warn("Letzter Fallback: generische Interagieren-Aktion.", LOG_CAT)
		var fallback := InteractableAction.new("interact", "Interagieren")
		fallback.duration = 1.5
		fallback.on_complete = func(): target.start_default_interaction()
		return [fallback]

	Logger.log_warn(
		"Kein interactable Interface auf '%s' gefunden." % target.name, LOG_CAT
	)
	return []


# ─────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────


func _build_system() -> void:
	Logger.log_debug("Baue Player-System (Collision, Mover, Visuals, Camera, Input, Sensor).", LOG_CAT)
	_setup_collision()
	_mover = PlayerMover.new()
	visuals = PlayerVisuals.new()
	camera = PlayerCamera.new()
	input = TouchInput.new()
	sensor = _build_sensor()

	add_child(visuals)
	add_child(camera)
	add_child(input)
	input.add_to_group("touch_input")
	input.connect_to_event_bus()
	add_child(sensor)

	# HealthComponent — v19: _on_player_died() statt Lambda damit physics pausiert werden kann
	var health := HealthComponent.new()
	health.name = "HealthComponent"
	health.max_health = 100
	add_child(health)
	health.died.connect(_on_player_died)

	Logger.log_debug(
		"Subsysteme bereit: mover=%s visuals=%s camera=%s input=%s sensor=%s"
		% [
			_mover.get_class(),
			visuals.get_class(),
			camera.get_class(),
			input.get_class(),
			sensor.get_class()
		],
		LOG_CAT
	)


func _build_sensor() -> InteractionSensor:
	var s := InteractionSensor.new()
	s.name = "InteractionSensor"
	var col := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 2.5
	col.shape = shape
	s.add_child(col)
	s.monitoring = true
	s.monitorable = false
	Logger.log_debug("InteractionSensor erstellt (Radius: 2.5m).", LOG_CAT)
	return s


func _setup_collision() -> void:
	var col := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.45
	cap.height = 1.8
	col.shape = cap
	col.position.y = 0.9
	add_child(col)
	Logger.log_debug("Collision Capsule erstellt (r=0.45, h=1.8, y=0.9).", LOG_CAT)


func _apply_stats() -> void:
	if not is_instance_valid(Services.data):
		Logger.log_warn("DataService fehlt — Player nutzt Mover-Defaults.", LOG_CAT)
		return

	var s := Services.data.get_player_stat("speed", 6.0)
	var g := Services.data.get_player_stat("gravity", 12.0)
	_mover.speed = s
	_mover.gravity = g

	Logger.log_info("Stats angewandt: Speed=%.2f, Gravity=%.2f." % [s, g], LOG_CAT)

	if s <= 0.0:
		Logger.log_warn("Speed ist ≤ 0 — Spieler kann sich nicht bewegen!", LOG_CAT)
	if g <= 0.0:
		Logger.log_warn("Gravity ist ≤ 0 — Spieler fällt nicht! Physik prüfen.", LOG_CAT)
