# res://scripts/player/PlayerMover.gd
class_name PlayerMover
extends RefCounted

const LOG_CAT := "PlayerMover"

var speed: float = 6.0
var gravity: float = 12.0

var _modifiers: Dictionary = {}
var _last_speed_log: float = 0.0


func _init() -> void:
	EventBus.player.speed_modifier_changed.connect(_on_mod_changed)
	EventBus.player.speed_modifier_removed.connect(_on_mod_removed)


func _on_mod_changed(id: String, multiplier: float) -> void:
	_modifiers[id] = multiplier

func _on_mod_removed(id: String) -> void:
	_modifiers.erase(id)


func get_current_speed() -> float:
	var final_multiplier: float = 1.0
	for m in _modifiers.values():
		final_multiplier *= m
	var current_speed: float = speed * final_multiplier
	if not is_equal_approx(current_speed, _last_speed_log):
		Logger.log_info(
			"Speed Update: %.2f (Base: %.2f, Mult: %.2f)" % [current_speed, speed, final_multiplier],
			LOG_CAT
		)
		_last_speed_log = current_speed
	return current_speed


const MAX_FALL_SPEED: float = 50.0
var _last_gravity_log: float = 0.0


func calculate_velocity(
	current_vel: Vector3, direction: Vector3, delta: float, on_floor: bool
) -> Vector3:
	var effective_speed: float = get_current_speed()
	var target_vel: Vector3 = direction * effective_speed
	var vel: Vector3 = current_vel

	const ACCEL: float = 10.0
	vel.x = lerp(vel.x, target_vel.x, ACCEL * delta)
	vel.z = lerp(vel.z, target_vel.z, ACCEL * delta)

	if on_floor:
		# FIX: Sprung-Velocity NICHT nullen! Nur wenn der Spieler auf dem Boden steht
		# und sich NICHT nach oben bewegt (also kein aktiver Sprung läuft).
		# Vorher: vel.y = 0.0 → kill-te sofort jede Sprung-Velocity die gerade gesetzt wurde.
		if vel.y <= 0.0:
			vel.y = 0.0
	else:
		vel.y -= gravity * delta
		vel.y = maxf(vel.y, -MAX_FALL_SPEED)
		if abs(vel.y - _last_gravity_log) > 5.0:
			Logger.log_trace(
				"Gravity: vel.y=%.1f (gravity=%.1f)" % [vel.y, gravity], {}, LOG_CAT
			)
			_last_gravity_log = vel.y

	return vel
