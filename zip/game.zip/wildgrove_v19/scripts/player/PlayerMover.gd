# res://scripts/player/PlayerMover.gd
class_name PlayerMover
extends RefCounted

const LOG_CAT := "PlayerMover"

## Direkt gesetzte Stats (von Player._apply_stats() via Services.data).
## _stats (PlayerData-Resource) wird nicht mehr benötigt — DataService ist
## die Single Source of Truth, Player injiziert die Werte als floats.
var speed: float = 6.0
var gravity: float = 12.0

var _modifiers: Dictionary = {}
var _last_speed_log: float = 0.0


func _init() -> void:
	EventBus.player.speed_modifier_changed.connect(_on_mod_changed)
	EventBus.player.speed_modifier_removed.connect(_on_mod_removed)


func _on_mod_changed(id: String, multiplier: float) -> void:
	_modifiers[id] = multiplier
	Logger.log_trace("Modifikator aktiv: %s" % id, _modifiers, LOG_CAT)


func _on_mod_removed(id: String) -> void:
	_modifiers.erase(id)
	Logger.log_trace("Modifikator entfernt: %s" % id, _modifiers, LOG_CAT)


func get_current_speed() -> float:
	var final_multiplier: float = 1.0
	for m in _modifiers.values():
		final_multiplier *= m

	var current_speed: float = speed * final_multiplier

	if not is_equal_approx(current_speed, _last_speed_log):
		Logger.log_info(
			(
				"Speed Update: %.2f (Base: %.2f, Mult: %.2f)"
				% [current_speed, speed, final_multiplier]
			),
			LOG_CAT
		)
		_last_speed_log = current_speed

	return current_speed


const MAX_FALL_SPEED: float = 50.0  # Terminal velocity — verhindert unbegrenzten Fall-Log-Spam

var _last_gravity_log: float = 0.0   # Letzte geloggte vel.y für Throttling


func calculate_velocity(
	current_vel: Vector3, direction: Vector3, delta: float, on_floor: bool
) -> Vector3:
	var effective_speed: float = get_current_speed()
	var target_vel: Vector3 = direction * effective_speed
	var vel: Vector3 = current_vel

	const ACCEL: float = 10.0

	vel.x = lerp(vel.x, target_vel.x, ACCEL * delta)
	vel.z = lerp(vel.z, target_vel.z, ACCEL * delta)

	if on_floor:
		vel.y = 0.0
	else:
		vel.y -= gravity * delta
		# Terminal velocity — ohne Deckel fällt der Spieler durch Kollisionen bei hoher Geschwindigkeit
		vel.y = maxf(vel.y, -MAX_FALL_SPEED)
		# Log-Throttling: nur loggen wenn vel.y sich um mehr als 5 geändert hat
		# Verhindert hunderte identische Log-Zeilen pro Sekunde
		if abs(vel.y - _last_gravity_log) > 5.0:
			Logger.log_trace(
				"Gravity: vel.y=%.1f (gravity=%.1f)" % [vel.y, gravity], {}, LOG_CAT
			)
			_last_gravity_log = vel.y

	return vel
