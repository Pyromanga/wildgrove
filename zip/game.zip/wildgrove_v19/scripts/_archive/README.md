# `_archive/` — bewusst aufbewahrter, toter Code

**Regel für dieses Verzeichnis:** Jede Datei hier ist mit `grep -r "<Dateiname ohne .gd>"`
gegen `scripts/`, `scenes/`, `config/`, `data/` geprüft worden — **null Treffer**
außerhalb dieser Datei selbst. Nichts hier wird von Godot beim Boot geladen
(keine `class_name`-Kollisionen, keine `.tscn`/`.tres`-Referenzen).

Warum nicht einfach löschen? Für ein 20-Jahres-Projekt ist "warum gibt es das
hier, und warum NICHT mehr?" oft genauso wichtig wie der Code selbst — siehe
`scripts/debug/principles.md` zu Doku/Code-Drift. Lieber EINMAL hier
dokumentieren, als dass jemand in 3 Jahren denselben Ansatz "neu erfindet"
und erst beim Debuggen merkt, warum er verworfen wurde.

**Wenn eine Datei hier wirklich gebraucht wird:** zurück in `scripts/<bereich>/`
verschieben, Doc-Header aktualisieren (Status ändern von "archiviert" auf
"aktiv"), in `BootstrapConfig.tres` / der relevanten `.tscn` registrieren.

---

## `MainSimple.gd`

**War:** `scripts/core/MainSimple.gd`
**Zweck laut eigenem Header:** "Minimaler Einstiegspunkt ohne ServiceOrchestrator.
Nützlich für schnelle Tests einzelner Systeme."
**Warum archiviert:** Keine `.tscn` instanziiert dieses Script — es war nie an
eine Szene gebunden, lief also nie. Falls ihr einen echten "Minimal-Boot ohne
DI-Pipeline"-Modus für isolierte System-Tests wollt: das gehört eher in die
neue Test-Infrastruktur (`tests/run_tests.gd`, Session 4) als in eine
Szenen-Variante — Letztere zwei verschiedene Boot-Pfade zu pflegen ist über
20 Jahre ein Wartungsrisiko (zwei Stellen, an denen Autoload-Reihenfolge
"stimmen" muss).

## `PlayerBackup.gd`

**War:** `scripts/player/PlayerBackup.gd`
**Zweck:** Frühere, monolithische Player-Implementierung (SpringArm3D,
Kamera, Bewegung, Stats — alles in einer Datei, 183 Zeilen). Wurde durch die
aktuelle Aufteilung in `Player.gd` + `PlayerMover.gd` + `PlayerCamera.gd` +
`PlayerVisuals.gd` + `PlayerStateService.gd` + `TouchInput.gd` ersetzt
(genau die "kleine, testbare Dateien"-Aufteilung, die für den Rest des
Projekts angestrebt wird).
**Warum archiviert statt gelöscht:** Referenz für "wie war das VOR der
Aufteilung" — falls beim Debuggen der aufgeteilten Version mal der Verdacht
aufkommt, dass beim Splitten Verhalten verloren ging, ist hier die
Vergleichsbasis. Hat (bewusst) KEIN `class_name` — kann nicht versehentlich
mit `Player` kollidieren.

## `Main.tscn` / `Main.gd` — NICHT archiviert, aber Status dokumentiert

Diese beiden bleiben an Ort und Stelle (`scenes/Main.tscn`,
`scripts/core/Main.gd`), sind aber ebenfalls aktuell ungenutzt
(`run/main_scene` = `MainMenu.tscn`). Unterschied zu den Dateien oben:

- **Vorher** enthielt `Main.tscn` ein zweites Kind-Node mit
  `ServiceOrchestrator.gd` — bei Reaktivierung hätte das zu einem
  **doppelten Boot** geführt (zweite Registry, doppelte EventBus-Subscriptions
  in jedem Service). Dieses Kind-Node wurde in Session 4 entfernt.
- `Main.tscn` ist dadurch jetzt eine **harmlose**, optionale
  Lade-/Splash-Szene (nur `Main.gd`, hört auf Boot-Signale). Sicher
  reaktivierbar, z.B. als echter Splash-Screen vor `MainMenu.tscn`.
- Die sichtbare Boot-Fehler-Anzeige (vorher: nur `Logger.log_error` in
  `Main.gd._on_boot_failed`, das wegen toter Szene nie feuerte) lebt jetzt in
  `MainMenuController._check_boot_status()` — die läuft garantiert, weil
  `MainMenu.tscn` die echte `run/main_scene` ist.

Details: `scripts/core/Main.gd` Header-Kommentar, `scripts/ui/MainMenuController.gd`.
