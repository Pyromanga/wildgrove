extends Node

## SimpleTerminal — Debug-Konsole für WildGrove.
##
## AutoLoad #3 (nach Logger, EventBus).
## Im Release-Build (OS.is_debug_build() == false): UI + Commands deaktiviert.
##
## Befehle: help, clear, mute, unmute, muted, services, service,
##           state, stats, errors, save, time, status, loglevel, respawns

signal entry_added(entry: LogEntry)
signal toggled(is_visible: bool)

const MAX_ENTRIES := 500

class LogEntry:
	var formatted: String
	func _init(s: String) -> void:
		formatted = s

var entries: Array[LogEntry] = []
var is_visible: bool = false
var _commands: Dictionary = {}


func _init() -> void:
	pass


func _ready() -> void:
	if not OS.is_debug_build():
		return
	Logger.on_log.connect(_on_log_entry)
	_register_default_commands()
	# SimpleTerminalUI direkt instanziieren — class_name ist global verfügbar.
	# load() + .new() war fragil wenn der Pfad zur Laufzeit nicht auflösbar war.
	var ui := SimpleTerminalUI.new()
	add_child(ui)
	Logger.log_debug("SimpleTerminal bereit. Befehle: %d" % _commands.size(), "Terminal")


func toggle() -> void:
	is_visible = !is_visible
	toggled.emit(is_visible)


func get_all_text() -> String:
	var lines := PackedStringArray()
	for e in entries:
		lines.append(e.formatted)
	return "\n".join(lines)


func execute(raw_input: String) -> void:
	var trimmed := raw_input.strip_edges()
	if trimmed.is_empty():
		return
	var parts := trimmed.split(" ", false)
	var cmd   := parts[0].to_lower()
	var args  := parts.slice(1)
	if _commands.has(cmd):
		_commands[cmd]["fn"].call(args)
	else:
		Logger.log_warn("Unbekannter Befehl: '%s'. Tippe 'help'." % cmd, "Terminal")


func register_command(name: String, description: String, fn: Callable) -> void:
	_commands[name.to_lower()] = {"fn": fn, "desc": description}
	Logger.log_debug("Befehl registriert: '%s'" % name, "Terminal")


func _on_log_entry(formatted: String, _cat: String, _level: int) -> void:
	var entry := LogEntry.new(formatted)
	entries.append(entry)
	if entries.size() > MAX_ENTRIES:
		entries.pop_front()
	entry_added.emit(entry)


func _register_default_commands() -> void:

	_commands["help"] = {
		"desc": "Alle verfügbaren Befehle anzeigen",
		"fn": func(_args: Array) -> void:
			var keys := _commands.keys()
			keys.sort()
			var lines: PackedStringArray = []
			for k in keys:
				lines.append("  %-16s %s" % [k, _commands[k].get("desc", "")])
			Logger.log_info("Befehle:\n" + "\n".join(lines), "Terminal")
	}

	_commands["clear"] = {
		"desc": "Terminal-Ausgabe leeren",
		"fn": func(_args: Array) -> void:
			entries.clear()
			entry_added.emit(null)
			Logger.log_debug("Terminal geleert.", "Terminal")
	}

	_commands["mute"] = {
		"desc": "mute <kategorie> — Kategorie stummschalten",
		"fn": func(args: Array) -> void:
			if args.is_empty():
				Logger.log_warn("Verwendung: mute <kategorie>", "Terminal")
				return
			Logger.mute_category(args[0])
			Logger.log_info("Stummgeschaltet: '%s'" % args[0], "Terminal")
	}

	_commands["unmute"] = {
		"desc": "unmute <kategorie> — Stummschaltung aufheben",
		"fn": func(args: Array) -> void:
			if args.is_empty():
				Logger.log_warn("Verwendung: unmute <kategorie>", "Terminal")
				return
			Logger.unmute_category(args[0])
			Logger.log_info("Reaktiviert: '%s'" % args[0], "Terminal")
	}

	_commands["muted"] = {
		"desc": "Alle stummgeschalteten Kategorien anzeigen",
		"fn": func(_args: Array) -> void:
			var muted := Logger.get_muted_categories()
			var msg := "Keine Kategorien stummgeschaltet."
			if not muted.is_empty():
				msg = "Stummgeschaltet: %s" % str(muted)
			Logger.log_info(msg, "Terminal")
	}

	_commands["services"] = {
		"desc": "Alle registrierten Services anzeigen",
		"fn": func(_args: Array) -> void:
			var orch := get_node_or_null("/root/ServiceOrchestrator")
			if orch == null:
				Logger.log_warn("ServiceOrchestrator nicht verfügbar.", "Terminal")
				return
			var names: Array[String] = orch.get_registered_names()
			names.sort()
			Logger.log_info("Services (%d): %s" % [names.size(), str(names)], "Terminal")
	}

	_commands["service"] = {
		"desc": "service <name> — Details zu einem Service",
		"fn": func(args: Array) -> void:
			if args.is_empty():
				Logger.log_warn("Verwendung: service <name>", "Terminal")
				return
			var orch := get_node_or_null("/root/ServiceOrchestrator")
			if orch == null:
				Logger.log_warn("ServiceOrchestrator nicht verfügbar.", "Terminal")
				return
			var info: Dictionary = orch.get_service_info(args[0])
			Logger.log_info("'%s': %s" % [args[0], JSON.stringify(info)], "Terminal")
	}

	_commands["state"] = {
		"desc": "Aktuellen GameState anzeigen",
		"fn": func(_args: Array) -> void:
			if not is_instance_valid(Services.game_manager):
				Logger.log_warn("GameManager nicht verfügbar.", "Terminal")
				return
			var s := Services.game_manager.get_state()
			Logger.log_info("GameState: %s (%d)" % [GameEnums.State.keys()[s], s], "Terminal")
	}

	_commands["stats"] = {
		"desc": "Logger-Statistiken anzeigen",
		"fn": func(_args: Array) -> void:
			Logger.log_info(Logger.log_summary(), "Terminal")
	}

	_commands["errors"] = {
		"desc": "Alle ERROR-Logs aus dem Puffer anzeigen",
		"fn": func(_args: Array) -> void:
			var errs := Logger.get_errors()
			if errs.is_empty():
				Logger.log_info("Keine Fehler im Puffer.", "Terminal")
				return
			Logger.log_warn("=== %d Fehler ===" % errs.size(), "Terminal")
			for e in errs:
				Logger.log_warn(e.get("formatted", "?"), "Terminal")
	}

	_commands["save"] = {
		"desc": "Spielstand speichern",
		"fn": func(_args: Array) -> void:
			if not is_instance_valid(Services.game_save):
				Logger.log_warn("GameSaveService nicht verfügbar.", "Terminal")
				return
			var ok := Services.game_save.save_all()
			Logger.log_info("Gespeichert." if ok else "Speichern fehlgeschlagen!", "Terminal")
	}

	_commands["time"] = {
		"desc": "Weltzeit anzeigen",
		"fn": func(_args: Array) -> void:
			if not is_instance_valid(Services.world):
				Logger.log_warn("WorldService nicht verfügbar.", "Terminal")
				return
			Logger.log_info(
				"Tag %d — %s" % [Services.world.day_count, Services.world.get_formatted_time()],
				"Terminal")
	}

	_commands["status"] = {
		"desc": "Alle Services auf null prüfen",
		"fn": func(_args: Array) -> void:
			var report := Services.get_status_report()
			var ok: Array = []
			var missing: Array = []
			for key in report:
				(ok if report[key] else missing).append(key)
			Logger.log_info("OK (%d): %s" % [ok.size(), str(ok)], "Terminal")
			if not missing.is_empty():
				Logger.log_warn("FEHLT (%d): %s" % [missing.size(), str(missing)], "Terminal")
	}

	_commands["loglevel"] = {
		"desc": "loglevel <debug|info|warn|error> — minimalen Level setzen",
		"fn": func(args: Array) -> void:
			if args.is_empty():
				Logger.log_warn("Verwendung: loglevel <debug|info|warn|error>", "Terminal")
				return
			match args[0].to_lower():
				"debug": Logger.set_min_level(Logger.LogLevel.DEBUG)
				"info":  Logger.set_min_level(Logger.LogLevel.INFO)
				"warn":  Logger.set_min_level(Logger.LogLevel.WARN)
				"error": Logger.set_min_level(Logger.LogLevel.ERROR)
				_: Logger.log_warn("Unbekannter Level: '%s'" % args[0], "Terminal")
	}

	_commands["respawns"] = {
		"desc": "Ausstehende Respawn-Queue anzeigen",
		"fn": func(_args: Array) -> void:
			if not is_instance_valid(Services.respawn):
				Logger.log_warn("RespawnService nicht verfügbar.", "Terminal")
				return
			var queue := Services.respawn.get_queue_debug()
			if queue.is_empty():
				Logger.log_info("Keine ausstehenden Respawns.", "Terminal")
				return
			Logger.log_info("Respawn-Queue (%d):" % queue.size(), "Terminal")
			for e in queue:
				Logger.log_info(
					"  %s @ %s — in %.0fs" % [e["type"], str(e["pos"]), e["secs"]],
					"Terminal")
	}
