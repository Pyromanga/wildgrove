# 🛠️ WildGrove — Service Registry & Responsibilities
*Stand: 2026-06 — Immer synchron halten mit BootstrapConfig.tres und Services.gd*

---

## Service-Übersicht

| Service | Key | Typ | Zuständigkeit | Abhängigkeiten |
|---------|-----|-----|--------------|----------------|
| **ServiceTicker** | `ticker` | `ServiceNode` | Zentraler Update-Loop für `on_tick()`/`on_physics_tick()` | keine |
| **SceneManager** | `scenemanager` | `ServiceNode` | Szenenwechsel via `transition_to_state()` | keine |
| **SaveSystem** | `savesystem` | `ServiceNode` | JSON-Serialisierung, Provider-Pattern, Disk-IO | keine |
| **DataService** | `data` | `ServiceNode` | Statische Ressourcen (PlayerData, Item-DB) | keine |
| **PlayerStateService** | `playerstates` | `ServiceNode` | Mikro-State des Spielers (FREE/BUSY/MENU) | `savesystem` |
| **SkillSystem** | `skill_system` | `ServiceNode` | XP-Kurven, Level-Ups, Skill-Tracking | `data`, `savesystem` |
| **Factory3D** | `factory3d` | `ServiceNode` | Programmatische 3D-Objekte (Bäume, Bars) | `data` |
| **InteractionExecutor** | `interaction_executor` | `ServiceNode` | Timed-Interaction-Ablauf, Tween-Management | `playerstates` |
| **GameSaveService** | `gamesave` | `ServiceNode` | Koordinator für vollständige Speichervorgänge | `savesystem` |
| **GameManager** | `gamemanager` | `ServiceNode` | State Machine (BOOT→MENU→PLAYING…) | `savesystem`, `playerstates`, `scenemanager` |
| **WorldService** | `world` | `ServiceNode` | Welt-Daten, Zeit-Zyklus, prozeduale Generierung | `savesystem`, `data` |
| **InventorySystem** | `inventory` | `ServiceNode` | Item-Add/Remove, Item-DB, Save-Provider | `data`, `savesystem` |
| **UICanvasService** | `ui_canvas` | `ServiceNode` | Root-CanvasLayer bereitstellen | keine |
| **HUDManager** | `hud` | `ServiceNode` | HUD-Controller-Setup, attach_to_scene | `inventory`, `playerstates` |
| **QuestService** | `quest` | `ServiceNode` | Quest-Tracking, Objectives, Rewards | `data`, `savesystem` |

---

## Entity-System (nicht über BootstrapConfig registriert)

| Klasse | Ort | Zuständigkeit |
|--------|-----|--------------| 
| **EntityOrchestrator** | `scripts/core/EntityOrchestrator.gd` | Spawn/Despawn/Pool von World-Entities |
| **OakTree** | `scripts/world/objects/OakTree.gd` | Fällbarer Baum (InteractableComponent) |
| **IronOre** | `scripts/world/objects/IronOre.gd` | Abbaubares Erz (InteractableComponent) |
| **InteractionSensor** | `scripts/interaction/InteractionSensor.gd` | Area3D-Child des Players; erkennt Interagierbare |
| **InteractableComponent** | `scripts/interaction/InteractableComponent.gd` | Node3D-Child von Entities; koppelt an Interaktions-System |

---

## Save-Provider

| Service | Save-Key | Gespeicherte Daten |
|---------|----------|-------------------|
| SaveSystem | — | Koordinator — keine eigenen Daten |
| InventorySystem | `inventory` | `{ "item_id": quantity }` |
| SkillSystem | `skills` | `{ "skill_name": { xp, level } }` |
| QuestService | `quest_progress` | `{ active: {}, completed: [] }` |
| WorldService | `world_state` | `{ day_time, day_count, tree_positions, player_pos }` |

---

## EventBus-Namespaces

### `EventBus.system`
| Signal | Parameter | Wer feuert |
|--------|-----------|-----------|
| `state_changed` | `state: int` | GameManager |
| `services_initialized` | — | ServiceOrchestrator (Phase 8) |
| `boot_failed` | `phase, reason` | ServiceOrchestrator |
| `save_requested` | — | UI (z.B. PauseMenuController) |
| `save_started` | — | SaveSystem |
| `save_completed` | `success: bool` | SaveSystem |

> **`save_requested` vs. `save_started`** (zwei ähnliche Namen, bewusst getrennt):
> `save_requested` ist der EXTERNE Auslöser ("UI will speichern") — GENAU EIN
> Listener: `GameSaveService._on_save_requested()` → `save_all()`.
> `save_started` ist das INTERNE "es läuft jetzt" von `SaveSystem.save_game()` —
> nur für UI-Feedback/Logging (z.B. Spinner), NICHT erneut `save_all()` triggern.
> Beide Comments stehen direkt in `SystemEvents.gd` — falls ihr hier jemals
> einen dritten "save_*"-Namen braucht: erst diese beiden Kommentare lesen,
> sonst entsteht leicht eine Save→Save-Schleife.

### `EventBus.player`
| Signal | Parameter | Wer feuert |
|--------|-----------|-----------|
| `xp_gained` | `skill, amount` | InteractableComponent |
| `level_up` | `skill, new_level` | SkillSystem |
| `movement_interrupted` | — | Player |
| `speed_modifier_changed` | `id, multiplier` | extern (geplant) |
| `speed_modifier_removed` | `id` | extern (geplant) |

> **Inventar-Änderungen sind KEIN EventBus-Signal.** `Services.inventory.inventory_changed`
> (eigenes Signal auf `InventorySystem`, scripts/services/InventorySystem.gd)
> — direkt connecten, z.B. `InventoryUIController`. Bis Session 4 gab es hier
> zusätzlich ein gleichnamiges, nie gefeuertes `EventBus.player.inventory_changed`
> — entfernt, siehe `scripts/events/PlayerEvents.gd` Header-Kommentar.

### `EventBus.world`
| Signal | Parameter | Wer feuert |
|--------|-----------|-----------|
| `interaction_started` | `label, duration` | InteractionExecutor |
| `interaction_finished` | `label` | InteractionExecutor |
| `interaction_cancelled` | `label` | InteractionExecutor |
| `world_scene_ready` | `world_root: Node` | WorldService |
| `loot_collected` | `item_id, quantity` | InteractableComponent |
| `interaction_reward_text` | `text` | InteractableComponent |
| `proximity_changed` | `target: Node3D, in_range: bool` | InteractionSensor |
| `time_of_day_changed` | `hour` | WorldService |
| `chunk_loaded` / `chunk_unloaded` | `chunk_id: Vector2i` | WorldService (future) |

### `EventBus.ui`
| Signal | Parameter | Wer feuert |
|--------|-----------|-----------|
| `joystick_toggled` | `is_active: bool, origin: Vector2` | TouchInput (bridged) |
| `joystick_moved` | `origin: Vector2, offset: Vector2` | TouchInput (bridged) |
| `request_context_menu` | — | ContextButtonController |
| `layout_requested` | `state: String` | extern |
| `menu_toggled` | `menu_name, is_visible` | extern |
| `overlay_changed` | `overlay_type, active` | extern |

### `EventBus.quest`
| Signal | Parameter | Wer feuert |
|--------|-----------|-----------|
| `quest_started` | `quest_id` | QuestService |
| `quest_completed` | `quest_id, reward` | QuestService |
| `quest_objective_updated` | `quest_id, obj_id, current, required` | QuestService |

---

## Boot-Reihenfolge (nach Dependency-Auflösung)

> **Update (Review-Session 4):** Die vorherige Liste hier nannte `factory3d`
> und `ui_canvas` — beide sind KEINE registrierten Services in
> `BootstrapConfig.tres` (Factory3D ist ein `RefCounted`-Helper, kein Service;
> `ui_canvas` existiert nicht). Gleichzeitig fehlten `world_gen`, `respawn`,
> `reward_dispatcher`. Die Liste war vermutlich ein älterer Planungsstand.
>
> Statt eine exakte lineare Reihenfolge zu raten (die hängt von Kahn's
> Algorithmus' Tie-Breaking ab, das ich ohne Godot nicht nachstellen kann —
> "No-Guessing"!), hier der verifizierte ABHÄNGIGKEITSGRAPH aus
> `BootstrapConfig.tres`. Die exakte lineare Reihenfolge bekommt ihr aus dem
> Boot-Log (`Logger`-Kategorie `Resolver`/`Initializer`) ODER aus
> `tests/unit/test_service_dependency_resolver.gd` (Session 4) — der testet
> `ServiceDependencyResolver` gegen genau diesen Graphen und loggt das Ergebnis.

```
ticker            (keine Deps)
scenemanager      (keine Deps)
savesystem        (keine Deps)
data              (keine Deps)
playerstates      (keine Deps)
world_gen         (keine Deps)
skill_system      → data, savesystem
inventory         → data, savesystem
quest             → data, savesystem
gamesave          → savesystem
gamemanager       → scenemanager
interaction_executor → playerstates
world             → savesystem, data, world_gen
hud               → inventory, playerstates
reward_dispatcher → inventory, skill_system
respawn           → world
```

Jede Zeile = "braucht (transitiv) alles rechts vom Pfeil zuerst". Die 6
abhängigkeitslosen Services oben können in JEDER Reihenfolge zueinander
laufen — Kahn's Algorithmus entscheidet das deterministisch nach
Eingabe-Reihenfolge in `BootstrapConfig.tres`, ist aber für die KORREKTHEIT
der DI irrelevant, weil sie nichts voneinander brauchen.

---

## UI-Komponenten Architektur

HUD-Komponenten folgen dem **Component/Controller/Visuals**-Muster:

```
HUDBuilder.build_all()
  └── XyzComponent.build(hud, deps)
        ├── XyzVisuals.new(hud)      ← Erstellt Godot-Nodes, hängt sie in HUD ein
        ├── XyzController.new()      ← Enthält Logik, lauscht auf Events
        └── ctrl.setup(visuals, ...) ← Koppelt Logik an Visuals

Regel: Controller die _ready()/_process() brauchen → extends Node → hud.add_child(ctrl)
Derzeit betrifft das: InteractionButtonController, ContextButtonController
```

---

## Multiplayer-Readiness (Planung)

| Datenkategorie | Besitzer | Validierung |
|---------------|----------|-------------|
| Item-Pickup | Server | `InventorySystem.request_pickup()` → Server-Check → Client-Sync |
| Quest-Fortschritt | Server | QuestService prüft Voraussetzungen serverseitig |
| Welt-Zustand | Server | WorldService ist Authority für Ressourcen-State |
| UI-Einstellungen | Client | Lokal, keine Sync nötig |
