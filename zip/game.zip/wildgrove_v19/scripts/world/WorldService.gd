extends ServiceNode
class_name WorldService

## WorldService — Zentrale Anlaufstelle für Welt-Daten, Zeit und Entity-Verwaltung.
##
## Abhängigkeiten (deps): ["savesystem", "data"]
##
## WICHTIG: Nutzt on_tick() statt _process() — konform mit dem ServiceTicker-Vertrag.
##
## World-Initialisierung (garantierte Reihenfolge):
##   1. World.gd._ready() ruft Services.world.on_world_scene_ready(self)
##   2. WorldService erstellt statische Geometrie via WorldFactory
##   3. WorldService initialisiert EntityOrchestrator mit dem world_root
##   4. WorldEntitySpawner spawnt Entities über EntityOrchestrator
##   5. WorldService feuert EventBus.world.world_scene_ready für HUDManager
##
## AUFTEILUNG (Review-Session 4 — diese Datei war mit 546 Zeilen die größte
## im Projekt):
##   - WorldEntitySpawner: "WorldData → Nodes in der Szene" (Bäume, Erze,
##     Tiere, Gegner, ChunkManager). register_entity_definitions() lebt jetzt
##     dort statt hier.
##   - WorldSaveAdapter: "WorldData <-> Save-Dictionary", komplett statisch.
##   WorldService bleibt der dünne Koordinator + hält den SceneTree-Zustand
##   (EntityOrchestrator als Child-Node, day_time/day_count, _restore_pets /
##   _restore_camera_state — beide brauchen get_tree()/call_deferred auf self).

const LOG_CAT := "World"
const SAVE_KEY := "world_state"

var _save_system: SaveSystem

var data: WorldData
var factory: WorldFactory

## Factory3D lebt als Instanz in WorldService — kein Service-Overhead mehr.
## Entities (OakTree, IronOre) und InteractableComponent greifen via
## Services.world.factory3d darauf zu.
var factory3d: Factory3D

## EntityOrchestrator lebt als Child-Node dieses Services.
## Wird in configure() erstellt, in on_world_scene_ready() initialisiert.
var _entity_orchestrator: EntityOrchestrator

## WorldGenerationService — generiert Positionen wenn kein Savegame vorhanden.
var _world_gen: WorldGenerationService

## Platziert Entities in die Szene (siehe scripts/world/WorldEntitySpawner.gd).
var _entity_spawner: WorldEntitySpawner

var day_time: float = 6.0
var day_count: int = 1
@export var time_speed: float = 0.05


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────
func configure(deps: Dictionary) -> void:
	var t := Logger.log_begin("WorldService.configure()", LOG_CAT)

	# FIX (Review-Session 4): data MUSS existieren BEVOR _restore_world()
	# läuft. Vorher stand dieser Block NACH dem SaveSystem-Block unten —
	# _restore_world(saved) griff dann auf `data` zu, während `data` noch
	# null war (Default eines `var data: WorldData` ohne Initializer).
	# Auf einem FRISCHEN Projekt (kein Save) fällt das nie auf, weil
	# `saved.is_empty()` true ist und _restore_world() gar nicht aufgerufen
	# wird — der Crash hätte sich erst beim ZWEITEN Start (mit existierendem
	# world_state-Save) gezeigt: "Invalid set index 'tree_positions' on base
	# 'null instance'".
	data      = WorldData.new()
	factory   = WorldFactory.new()
	factory3d = Factory3D.new()

	_save_system = deps.get("savesystem") as SaveSystem
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem fehlt in den Dependencies!", LOG_CAT)
	else:
		_save_system.register_save_provider(self)
		var saved: Dictionary = _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_restore_world(saved)
		else:
			Logger.log_info("Kein World-Save — nutze WorldGenerationService.", LOG_CAT)

	# WorldGenerationService aus Dependencies holen
	_world_gen = deps.get("world_gen") as WorldGenerationService
	if not is_instance_valid(_world_gen):
		Logger.log_warn("WorldGenerationService fehlt — nutze Defaults bei fehlenden Saves.", LOG_CAT)

	# EntityOrchestrator als Child erstellen — wird in on_world_scene_ready() genutzt.
	_entity_orchestrator = EntityOrchestrator.new()
	_entity_orchestrator.name = "EntityOrchestrator"
	add_child(_entity_orchestrator)

	_entity_spawner = WorldEntitySpawner.new(data, factory, _entity_orchestrator, _world_gen)
	_entity_spawner.register_entity_definitions()

	Logger.log_end("WorldService.configure()", t, LOG_CAT)
	Logger.log_info(
		"WorldService konfiguriert (Tag %d, %02d:00)." % [day_count, int(day_time)], LOG_CAT
	)


# ─────────────────────────────────────────────
# Phase 5: on_ready
# ─────────────────────────────────────────────
func on_ready() -> void:
	if Services.ticker:
		Services.ticker.register_service(self)
		Logger.log_debug("Bei ServiceTicker registriert.", LOG_CAT)
	else:
		Logger.log_warn("ServiceTicker fehlt — on_tick() wird nicht aufgerufen!", LOG_CAT)

	# Respawn-Callbacks injizieren — hier ist Services.respawn garantiert befüllt.
	# RespawnService kennt WorldService NICHT — er bekommt nur zwei schmale Callables.
	#
	# spawn_cb:  Callable(type_id, pos) -> Node3D  → ruft spawn_entity() auf
	# remove_cb: Callable(type_id, pos) -> void    → entfernt harvested-Marker
	#
	# Damit ist die zirkuläre Abhängigkeit vollständig gebrochen ohne lazy Services.world.
	var respawn := Services.respawn
	if is_instance_valid(respawn):
		respawn.register_config("oak_tree", 300.0)  # 5 Minuten
		respawn.register_config("iron_ore", 600.0)  # 10 Minuten

		respawn.set_spawn_callback(
			func(type_id: String, pos: Vector3) -> Node3D:
				return spawn_entity(type_id, pos)
		)
		respawn.set_remove_callback(
			func(type_id: String, pos: Vector3) -> void:
				if is_instance_valid(data):
					data.unmark_harvested(type_id, pos)
		)
		Logger.log_info("RespawnService konfiguriert: oak_tree=300s, iron_ore=600s.", LOG_CAT)
	else:
		Logger.log_warn("RespawnService nicht gefunden — kein Respawn.", LOG_CAT)

	Logger.log_info("WorldService bereit.", LOG_CAT)


# ─────────────────────────────────────────────
# Phase 7: Cleanup
# ─────────────────────────────────────────────
func on_cleanup() -> void:
	Logger.log_info("WorldService Cleanup.", LOG_CAT)
	# EntityOrchestrator ist ein Child-Node, wird automatisch freigegeben.
	# Explizit aufräumen falls wir mitten in einer Welt sind.
	if is_instance_valid(_entity_orchestrator) and _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()


# ─────────────────────────────────────────────
# Tick (via ServiceTicker — kein direktes _process()!)
# ─────────────────────────────────────────────
func on_tick(delta: float) -> void:
	if is_instance_valid(Services.game_manager) and Services.game_manager.is_playing():
		_update_time(delta)


# ─────────────────────────────────────────────
# Welt-Initialisierung (von World.gd._ready() aufgerufen)
# ─────────────────────────────────────────────


## Wird von World.gd._ready() aufgerufen.
## Zu diesem Zeitpunkt ist World.tscn garantiert im SceneTree —
## sicher Kinder hinzuzufügen ohne call_deferred.
func on_world_scene_ready(world_root: Node3D) -> void:
	var t := Logger.log_begin("on_world_scene_ready()", LOG_CAT)
	Logger.log_info(
		"World-Init gestartet. Scene: '%s'." % world_root.name, LOG_CAT
	)

	# Vorherige Welt aufräumen falls vorhanden (bei Szenenwechsel zurück zur Welt)
	if _entity_orchestrator.get_entity_count() > 0:
		Logger.log_info("Vorherige Entity-Session aufräumen...", LOG_CAT)
		_entity_orchestrator.on_world_unloaded()
		EventBus.world.emit_world_scene_unloaded()

	# --- Statische Geometrie (Factory) ---
	var generated_world: Node3D = factory.create_world()
	# Kinder in die echte Szene verschieben (Factory-Container ist temporär)
	for child in generated_world.get_children():
		generated_world.remove_child(child)
		world_root.add_child(child)
	generated_world.queue_free()
	Logger.log_debug("Statische Geometrie in World.tscn eingefügt.", LOG_CAT)

	# Terrain-Höhen-Callback in WorldGenerationService injizieren —
	# muss NACH factory.create_world() passieren, da terrain_generator erst dann existiert.
	if is_instance_valid(_world_gen) and is_instance_valid(factory.terrain_generator):
		_world_gen.set_height_callback(factory.terrain_generator.get_height_at)
		Logger.log_debug("Terrain-Höhen-Callback in WorldGenerationService gesetzt.", LOG_CAT)

	# --- EntityOrchestrator initialisieren ---
	_entity_orchestrator.initialize(world_root)

	# --- Entities spawnen (WorldEntitySpawner — siehe Klassen-Header) ---
	_entity_spawner.spawn_world_entities(world_root)

	# --- Pets und Kamera-State wiederherstellen (falls vorhanden im Save) ---
	# Bleibt hier (statt im Spawner): braucht get_tree() / call_deferred auf
	# DIESEM Node (WorldService), RefCounted-Spawner hat keinen sinnvollen
	# eigenen call_deferred-Ziel-Kontext für _restore_camera_state.
	_restore_pets(world_root)
	# v19: Kamera-Winkel/Zoom nach dem Spawnen wiederherstellen (deferred → Player ist im Tree)
	call_deferred("_restore_camera_state")

	# --- Welt bereit signalisieren ---
	# HUDManager lauscht auf dieses Signal und hängt das HUD ein.
	# WorldService kennt damit kein UI mehr — saubere Trennung.
	EventBus.world.emit_world_scene_ready(world_root)

	Logger.log_end("on_world_scene_ready()", t, LOG_CAT)
	Logger.log_info(
		"Welt bereit. Entities aktiv: %d." % _entity_orchestrator.get_entity_count(),
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────


func get_save_key() -> String:
	return SAVE_KEY


func get_save_data() -> Dictionary:
	return WorldSaveAdapter.to_save_dict(data, day_time, day_count)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


func get_formatted_time() -> String:
	var hours: int = int(day_time)
	var minutes: int = int((day_time - hours) * 60)
	return "%02d:%02d" % [hours, minutes]


## Spawnt eine Entity über den EntityOrchestrator.
## Öffentliche API für anderen Code (z.B. zukünftiger ChunkLoader).
func spawn_entity(type_id: String, position: Vector3, config: Dictionary = {}) -> Node3D:
	if not is_instance_valid(_entity_orchestrator):
		Logger.log_error("EntityOrchestrator fehlt!", LOG_CAT)
		return null
	return _entity_orchestrator.spawn_entity(type_id, position, config)


## Despawnt eine Entity über die UUID.
func despawn_entity(uuid: String) -> void:
	if not is_instance_valid(_entity_orchestrator):
		Logger.log_error("EntityOrchestrator fehlt!", LOG_CAT)
		return
	_entity_orchestrator.despawn_entity(uuid)


## Gibt Debug-Info über aktive Entities zurück (für SimpleTerminal).
func get_entity_debug_info() -> Dictionary:
	if not is_instance_valid(_entity_orchestrator):
		return {"error": "EntityOrchestrator fehlt"}
	return _entity_orchestrator.get_debug_info()


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _restore_pets(world_root_ref: Node3D) -> void:
	if not is_instance_valid(data) or not data.has_meta("saved_pets"):
		return
	var pet_data: Variant = data.get_meta("saved_pets")
	if not pet_data is Array:
		return
	for entry in pet_data:
		if not entry is Dictionary:
			continue
		var pos: Variant = str_to_var(entry.get("pos", "Vector3(0,1,0)"))
		if not pos is Vector3:
			continue
		var pet := PetComponent.new()
		pet._name = entry.get("name", "Pet")
		var col: Variant = str_to_var(entry.get("color", "Color(0.7,0.5,0.3,1)"))
		if col is Color:
			pet._color = col
		pet.position = pos
		world_root_ref.add_child(pet)
	Logger.log_info("Pets wiederhergestellt: %d" % (pet_data as Array).size(), LOG_CAT)


## v19: Kamera-Winkel und Zoom aus dem Save auf den Player anwenden.
## call_deferred aus on_world_scene_ready() → Player ist bereits im Tree.
func _restore_camera_state() -> void:
	if not is_instance_valid(data) or not data.has_meta("camera_state"):
		return
	var cam_state: Variant = data.get_meta("camera_state")
	if not cam_state is Dictionary:
		return
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: Object = players[0]
	if player.has_method("apply_camera_state"):
		player.apply_camera_state(cam_state)
		Logger.log_info("Kamera-State wiederhergestellt.", LOG_CAT)


func _update_time(delta: float) -> void:
	day_time += delta * time_speed
	if day_time >= 24.0:
		day_time = fmod(day_time, 24.0)
		day_count += 1
		EventBus.world.emit_time_of_day_changed(0)
		Logger.log_info("Neuer Tag: Tag %d beginnt." % day_count, LOG_CAT)


func _restore_world(state: Dictionary) -> void:
	var restored := WorldSaveAdapter.restore_from_dict(data, state)
	day_time = restored.get("day_time", 6.0)
	day_count = restored.get("day_count", 1)
