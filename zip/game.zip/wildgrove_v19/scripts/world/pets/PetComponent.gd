class_name PetComponent
extends CharacterBody3D

## PetComponent — Ein Pet das dem Spieler folgt.
## Wird instanziiert wenn ein Tier gefangen wird.

const LOG_CAT := "Pet"
const GRAVITY: float = 9.8

var _color:     Color   = Color(0.7, 0.5, 0.3)
var _body_size: Vector3 = Vector3(0.3, 0.4, 0.3)
var _name:      String  = "Pet"

var _follow_distance: float = 2.5
var _speed:           float = 4.0
var _idle_radius:     float = 1.5


func _ready() -> void:
	add_to_group("pets")
	_build_visuals()
	_build_collision()
	Logger.log_debug("Pet '%s' bereit." % _name, LOG_CAT)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0

	var player := _get_player()
	if is_instance_valid(player):
		var dist := global_position.distance_to(player.global_position)
		if dist > _follow_distance:
			var dir: Vector3 = player.global_position - global_position
			dir.y = 0.0
			if dir.length_squared() > 0.01:
				dir = dir.normalized()
				var t: float = min(1.0, (dist - _follow_distance) / 3.0)
				var spd: float = _speed * t
				velocity.x = move_toward(velocity.x, dir.x * spd, 12.0 * delta)
				velocity.z = move_toward(velocity.z, dir.z * spd, 12.0 * delta)
				look_at(global_position + dir, Vector3.UP)
		else:
			velocity.x = move_toward(velocity.x, 0.0, 6.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 6.0 * delta)

	move_and_slide()


func _get_player() -> Node3D:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return null
	return players[0] as Node3D


func _build_visuals() -> void:
	var bm := CapsuleMesh.new()
	bm.radius = _body_size.x * 0.5
	bm.height = _body_size.y
	var mat := StandardMaterial3D.new()
	mat.albedo_color = _color
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position.y = _body_size.y * 0.5
	add_child(mi)

	var lbl := Label3D.new()
	lbl.text = _name
	lbl.font_size = 36
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(0.6, 1.0, 0.6)
	lbl.position.y = _body_size.y * 1.3
	add_child(lbl)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh := CapsuleShape3D.new()
	sh.radius = _body_size.x * 0.4
	sh.height = _body_size.y
	col.shape = sh
	col.position.y = _body_size.y * 0.5
	add_child(col)
