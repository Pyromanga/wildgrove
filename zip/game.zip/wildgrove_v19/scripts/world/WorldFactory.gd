extends RefCounted
class_name WorldFactory

## WorldFactory — Erzeugt die STATISCHE Spielwelt (Geometrie + Licht + Player).
##
## WICHTIG — Was gehört NICHT hierher:
##   Entities (OakTree, IronOre, NPCs) → EntityOrchestrator (via WorldService)
##   Services, UI → jeweilige Manager
##
## Anti-Pattern VERHINDERT:
##   VERBOTEN: Node3D.new() + node.set_script(script)
##   GRUND: set_script() nach Node-Erstellung triggert _ready() ein zweites Mal
##          (Godot's Engine ruft _ready() beim Tree-Eintritt auf, und nochmal wenn
##          das Script gesetzt wird). Bei CharacterBody3D: undefiniertes Physik-Verhalten.
##   KORREKT: script.new() → direkte Instanz MIT Script von Anfang an.
##            Damit gibt es exakt einen _ready()-Aufruf nach add_child().

const LOG_CAT := "WorldFactory"


## Erzeugt die statische Welt-Geometrie ohne Entities.
## Gibt einen temporären Container-Node zurück — WorldService verschiebt dessen Kinder
## in world_root (die echte World.tscn).
##
## Enthält: Beleuchtung, Himmel, Boden, Player.
## NICHT enthalten: OakTree, IronOre, NPCs → werden von WorldService+EntityOrchestrator gespawnt.
## Terrain-Generator-Instanz — wird in create_world() erstellt und
## als öffentliche Variable exponiert damit WorldGenerationService die
## Höhe an beliebigen Positionen abfragen kann.
var terrain_generator: TerrainGenerator = null


func create_world() -> Node3D:
	var t := Logger.log_begin("create_world()", LOG_CAT)
	var world := Node3D.new()
	world.name = "WorldContainer"

	_add_environment(world)
	_add_terrain(world)   # Ersetzt _add_ground — echtes prozedurales Terrain
	_add_player(world, Vector3(0, 0, 0))

	Logger.log_end("create_world()", t, LOG_CAT)
	Logger.log_info(
		"Statische Welt erstellt. Nodes: %d." % world.get_child_count(), LOG_CAT
	)
	return world


# ─────────────────────────────────────────────
# Umgebung
# ─────────────────────────────────────────────


func _add_environment(world: Node3D) -> void:
	# Sonne
	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-45, 30, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	world.add_child(sun)

	# Prozeduraler Himmel
	var env_node := WorldEnvironment.new()
	env_node.name = "WorldEnvironment"
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.2, 0.5, 0.9)
	sky_mat.sky_horizon_color = Color(0.6, 0.8, 1.0)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.5
	env_node.environment = env
	world.add_child(env_node)

	Logger.log_debug("Umgebung (Sonne + Himmel) erstellt.", LOG_CAT)


# ─────────────────────────────────────────────
# Boden
# ─────────────────────────────────────────────


func _add_terrain(world: Node3D) -> void:
	terrain_generator = TerrainGenerator.new()
	# KRITISCH: size MUSS exakt ChunkManager.CHUNK_SIZE (64m) entsprechen.
	# Damit deckt das Haupt-Terrain GENAU den Bereich von Chunk (0,0) ab
	# ([-32,32]x[-32,32]) — ChunkManager überspringt (0,0) → KEIN Overlap,
	# keine doppelten Terrain-Layer mehr im Start-Bereich.
	# world_offset bleibt (0,0) — Start-Chunk ist bei Weltursprung zentriert.
	terrain_generator.size = 64.0
	# Höhere Auflösung für den Start-Chunk (bessere Detailqualität nahe Spawn).
	terrain_generator.resolution = 128
	terrain_generator.create(world)
	Logger.log_debug("Prozedurales Terrain erstellt (Start-Chunk, 64m).", LOG_CAT)


# ─────────────────────────────────────────────
# Player
# ─────────────────────────────────────────────


func _add_player(world: Node3D, pos: Vector3) -> void:
	## KORREKTE Instanziierung — KEIN set_script() nach new()!
	##
	## Falsch (Anti-Pattern):
	##   var p = CharacterBody3D.new()
	##   p.set_script(load("res://scripts/player/Player.gd"))  ← doppeltes _ready()!
	##
	## Richtig:
	##   var PlayerClass := load("res://scripts/player/Player.gd")
	##   var p: CharacterBody3D = PlayerClass.new()
	##   → _ready() feuert genau EINMAL nach add_child()

	var player_script: GDScript = load("res://scripts/player/Player.gd")
	if not player_script:
		Logger.log_error("Player.gd nicht ladbar — Pfad korrekt?", LOG_CAT)
		return

	var player: CharacterBody3D = player_script.new()
	player.name = "Player"

	# Y-Position: Terrain-Höhe am Spawn-Punkt + Sicherheitsabstand nach oben.
	# CharacterBody3D muss beim Start ÜBER dem Boden sein — startet er im Terrain,
	# greift is_on_floor() nie und der Spieler fällt endlos.
	# terrain_generator ist gesetzt nachdem _add_terrain() aufgerufen wurde.
	var spawn_y: float = 5.0
	if is_instance_valid(terrain_generator):
		spawn_y = terrain_generator.get_height_at(pos.x, pos.z) + 2.0
	player.position = Vector3(pos.x, spawn_y, pos.z)

	world.add_child(player)
	Logger.log_info(
		"Player instanziiert. Position: %s." % str(player.position), LOG_CAT
	)
