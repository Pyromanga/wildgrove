# res://scripts/world/WorldSaveAdapter.gd
class_name WorldSaveAdapter
extends RefCounted

## WorldSaveAdapter — Reine (De-)Serialisierung von WorldData <-> Save-Dictionary.
##
## EXTRAHIERT AUS WorldService.gd (Review-Session 4, "Files so klein wie
## möglich"). Komplett STATISCH und zustandslos — keine _init(), keine
## Member-Vars, kein Services.*-Zugriff. Nimmt WorldData + Dictionary, gibt
## Dictionary zurück (oder umgekehrt befüllt WorldData in-place). Reine
## Funktionen — Idealfall für Unit-Tests, siehe
## tests/unit/test_world_save_adapter.gd (inkl. Migrations-Test fürs
## Alt-Format unten).
##
## FORMAT-FIX (Session 4): tree_positions und ore_positions sind beide
## Array[Vector3] — wurden aber UNTERSCHIEDLICH serialisiert:
##   tree_positions: Array[String], ein var_to_str(Vector3) PRO EINTRAG
##   ore_positions:  EIN var_to_str() über das GESAMTE Array als ein String
## Gleiche Datenform, zwei Formate, kein erkennbarer Grund (vermutlich in
## getrennten Sessions entstanden). Jetzt: BEIDE im tree_positions-Format
## (lesbarer im JSON-Save — jede Position einzeln sichtbar, statt einem
## Godot-Syntax-Blob in einem String). restore_from_dict() liest BEIDE
## Formate für ore_positions (Migration für Saves von vor Session 4).
## tree_positions brauchte keine Migration — Format war schon immer so.


## WorldData -> Dictionary für SaveSystem.
## day_time/day_count leben auf WorldService (nicht WorldData) — deshalb als
## Parameter statt aus data zu lesen.
static func to_save_dict(data: WorldData, day_time: float, day_count: int) -> Dictionary:
	var tree_pos_strings: Array[String] = []
	for pos in data.tree_positions:
		tree_pos_strings.append(var_to_str(pos))

	# FIX (Session 4): gleiches Format wie tree_positions (siehe Klassen-Kommentar).
	var ore_pos_strings: Array[String] = []
	for pos in data.ore_positions:
		ore_pos_strings.append(var_to_str(pos))

	var result := {
		"day_time": day_time,
		"day_count": day_count,
		"tree_positions": tree_pos_strings,
		"ore_positions": ore_pos_strings,
		"player_pos": var_to_str(data.player_position),
		"harvested": var_to_str(data.harvested_objects),
	}

	# v19 FIX: Pets direkt im Save-Dict speichern.
	# Vorher: GameSaveService schrieb Pets ins data.set_meta("saved_pets", ...) ABER
	# get_save_data() las diesen Meta nie aus → Pets waren nach Neustart verloren.
	if data.has_meta("saved_pets"):
		result["saved_pets"] = data.get_meta("saved_pets")

	# Kamera-State ebenfalls persistieren (wird von GameSaveService vorher gesetzt)
	if data.has_meta("camera_state"):
		result["camera_state"] = data.get_meta("camera_state")

	return result


## Dictionary (aus SaveSystem) -> befüllt `data` in-place.
## Rückgabe: {"day_time": float, "day_count": int} — diese zwei Felder
## gehören WorldService (nicht WorldData), der Aufrufer übernimmt sie.
static func restore_from_dict(data: WorldData, state: Dictionary) -> Dictionary:
	var day_time: float = state.get("day_time", 6.0)
	var day_count: int = state.get("day_count", 1)

	# Baum-Positionen aus String-Array wiederherstellen
	var tree_strings: Variant = state.get("tree_positions", [])
	if tree_strings is Array:
		data.tree_positions = []
		for s in (tree_strings as Array):
			var pos: Variant = str_to_var(s)
			if pos is Vector3:
				data.tree_positions.append(pos)

	# Erz-Positionen — unterstützt ZWEI Formate (Migration, siehe Klassen-Kommentar):
	#   NEU (ab Session 4): Array[String], ein var_to_str(Vector3) pro Eintrag
	#   ALT (vor Session 4): EIN String, var_to_str() über das ganze Array
	data.ore_positions = []
	var ore_raw: Variant = state.get("ore_positions", [])
	if ore_raw is Array:
		# Neues Format (oder schlicht "keine Erze gespeichert" → leeres Array)
		for entry in (ore_raw as Array):
			var pos: Variant = str_to_var(entry) if entry is String else entry
			if pos is Vector3:
				data.ore_positions.append(pos)
	elif ore_raw is String:
		# Altes Format: ein String kodiert das gesamte Array
		var ore_array: Variant = str_to_var(ore_raw as String)
		if ore_array is Array:
			for p in (ore_array as Array):
				if p is Vector3:
					data.ore_positions.append(p)
		else:
			Logger.log_warn(
				"ore_positions (Alt-Format) im Save korrupt — nutze leeres Array.", "WorldSaveAdapter"
			)
	else:
		Logger.log_warn(
			"ore_positions im Save korrupt (weder Array noch String) — nutze leeres Array.", "WorldSaveAdapter"
		)

	var player_pos_raw: Variant = str_to_var(state.get("player_pos", "Vector3(0,0,0)"))
	data.player_position = player_pos_raw if player_pos_raw is Vector3 else Vector3.ZERO

	var harvested_raw: Variant = str_to_var(state.get("harvested", "{}"))
	data.harvested_objects = harvested_raw if harvested_raw is Dictionary else {}

	# v19 FIX: Pets aus dem Save-Dict zurück ins Meta laden, damit _restore_pets() sie findet.
	if state.has("saved_pets") and state["saved_pets"] is Array:
		data.set_meta("saved_pets", state["saved_pets"])
		Logger.log_debug(
			"Pet-Daten aus Save geladen: %d Pets." % (state["saved_pets"] as Array).size(),
			"WorldSaveAdapter"
		)

	# Kamera-State wiederherstellen (wird von WorldService._restore_camera_state() genutzt)
	if state.has("camera_state") and state["camera_state"] is Dictionary:
		data.set_meta("camera_state", state["camera_state"])

	Logger.log_info(
		"Welt-Zustand geladen: Tag %d, %02d:00, %d Bäume, %d Erze, %d geerntete Objekte."
		% [
			day_count, int(day_time),
			data.tree_positions.size(),
			data.ore_positions.size(),
			data.harvested_objects.size()
		],
		"WorldSaveAdapter"
	)

	return {"day_time": day_time, "day_count": day_count}
