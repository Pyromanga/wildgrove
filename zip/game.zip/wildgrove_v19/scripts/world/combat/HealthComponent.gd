class_name HealthComponent
extends Node

## HealthComponent — HP-Verwaltung für Spieler und feindliche NPCs.
## take_damage() → emittiert health_changed und ggf. died.

signal health_changed(current: int, maximum: int)
signal died

@export var max_health: int = 50
var current_health: int = 50
var is_dead: bool = false


func _ready() -> void:
	current_health = max_health


func take_damage(amount: int) -> void:
	if is_dead:
		return
	current_health = max(0, current_health - amount)
	health_changed.emit(current_health, max_health)
	if current_health <= 0:
		is_dead = true
		died.emit()


func heal(amount: int) -> void:
	if is_dead:
		return
	current_health = min(max_health, current_health + amount)
	health_changed.emit(current_health, max_health)


func reset() -> void:
	current_health = max_health
	is_dead = false
	health_changed.emit(current_health, max_health)
