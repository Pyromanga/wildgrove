extends CharacterBody3D
class_name EnemyNPC

## EnemyNPC — Feindlicher NPC mit einfacher KI.
## Zustände: IDLE → CHASE → ATTACK → DEAD
##
## v19: Angreifbar über das Context-Menü-System (get_actions() + Meta).
## Spieler sieht "Angreifen ⚔"-Option wenn Goblin in Reichweite.

const LOG_CAT := "EnemyNPC"
const GRAVITY: float = 9.8

enum State { IDLE, CHASE, ATTACK, DEAD }

var _color:           Color   = Color(0.7, 0.15, 0.15)
var _max_health:      int     = 30
var _player_damage:   int     = 15  # Schaden den der Spieler pro Angriff macht
var _damage:          int     = 5   # Schaden den der Goblin macht
var _speed:           float   = 2.5
var _detect_range:    float   = 8.0
var _attack_range:    float   = 1.5
var _attack_cooldown: float   = 1.5
var _xp_reward:       int     = 20
var _xp_skill:        String  = "combat"
var _drops:           Dictionary = {}

var _state:         State   = State.IDLE
var _state_timer:   float   = 0.0
var _attack_timer:  float   = 0.0
var _health:        HealthComponent
var _health_bar:    MeshInstance3D


func _ready() -> void:
	add_to_group("enemies")
	_build_visuals()
	_build_collision()
	_setup_health()
	# FIX: Goblin als interagierbares Ziel registrieren.
	# Player.get_context_actions() sucht "interactable_component"-Meta auf dem Ziel-Node.
	# Da EnemyNPC get_actions() implementiert, kann der Player direkt darauf zugreifen.
	set_meta("interactable_component", self)
	Logger.log_debug("EnemyNPC gespawnt.", LOG_CAT)


## Implementiert das "interactable_component"-Interface (duck-typed).
## Wird von Player.get_context_actions() aufgerufen.
func get_actions() -> Array:
	if _state == State.DEAD:
		return []
	var action := InteractableAction.new("attack_goblin", "Angreifen ⚔")
	action.duration = 0.7
	# Closure captured: _health als Referenz — wenn Enemy stirbt bevor Angriff fertig
	# ist _health.is_dead → take_damage() tut nichts (Guard in HealthComponent).
	action.on_complete = func():
		if is_instance_valid(_health) and not _health.is_dead:
			_health.take_damage(_player_damage)
			Logger.log_info("Spieler trifft Goblin: -%d HP." % _player_damage, LOG_CAT)
	return [action]


func _physics_process(delta: float) -> void:
	if _state == State.DEAD:
		return

	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0

	_attack_timer = max(0.0, _attack_timer - delta)
	_state_timer  = max(0.0, _state_timer - delta)

	var player := _get_player()
	if not is_instance_valid(player):
		_enter_idle()
		move_and_slide()
		return

	var dist := global_position.distance_to(player.global_position)

	match _state:
		State.IDLE:
			velocity.x = move_toward(velocity.x, 0.0, 5.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 5.0 * delta)
			if dist < _detect_range:
				_state = State.CHASE

		State.CHASE:
			if dist > _detect_range * 1.5:
				_enter_idle()
			elif dist < _attack_range:
				_state = State.ATTACK
			else:
				_move_toward(player.global_position, _speed, delta)

		State.ATTACK:
			velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)
			if dist > _attack_range * 1.3:
				_state = State.CHASE
			elif _attack_timer <= 0.0:
				_do_attack(player)
				_attack_timer = _attack_cooldown

	_update_health_bar()
	move_and_slide()


func _enter_idle() -> void:
	_state = State.IDLE
	_state_timer = 2.0


func _move_toward(target: Vector3, spd: float, delta: float) -> void:
	var dir := (target - global_position)
	dir.y = 0.0
	if dir.length_squared() > 0.01:
		dir = dir.normalized()
		velocity.x = move_toward(velocity.x, dir.x * spd, 10.0 * delta)
		velocity.z = move_toward(velocity.z, dir.z * spd, 10.0 * delta)
		look_at(global_position + dir, Vector3.UP)


func _do_attack(player: Node3D) -> void:
	Logger.log_debug("EnemyNPC greift an: %d Schaden." % _damage, LOG_CAT)
	var phc := player.find_child("HealthComponent", true, false) as HealthComponent
	if is_instance_valid(phc):
		phc.take_damage(_damage)
	else:
		EventBus.player.emit_player_died()


func _die() -> void:
	_state = State.DEAD
	Logger.log_info("EnemyNPC besiegt — Drops + XP.", LOG_CAT)
	EventBus.player.emit_xp(_xp_skill, _xp_reward)
	for item_id in _drops:
		EventBus.world.emit_loot_collected(item_id, _drops[item_id])
	get_tree().create_timer(1.5).timeout.connect(queue_free)


func _get_player() -> Node3D:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return null
	return players[0] as Node3D


func _setup_health() -> void:
	_health = HealthComponent.new()
	_health.name = "HealthComponent"
	_health.max_health = _max_health
	add_child(_health)
	_health.died.connect(_die)


func _build_visuals() -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = _color
	var bm := CapsuleMesh.new()
	bm.radius = 0.30
	bm.height = 1.0
	var mi := MeshInstance3D.new()
	mi.mesh = bm
	mi.material_override = mat
	mi.position.y = 0.7
	add_child(mi)

	var bar_mesh := BoxMesh.new()
	bar_mesh.size = Vector3(0.8, 0.06, 0.04)
	var bar_mat := StandardMaterial3D.new()
	bar_mat.albedo_color = Color(0.9, 0.1, 0.1)
	bar_mat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	_health_bar = MeshInstance3D.new()
	_health_bar.mesh = bar_mesh
	_health_bar.material_override = bar_mat
	_health_bar.position.y = 1.6
	add_child(_health_bar)

	var name_lbl := Label3D.new()
	name_lbl.text = "Goblin"
	name_lbl.font_size = 40
	name_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_lbl.modulate = Color(1, 0.4, 0.4)
	name_lbl.position.y = 1.85
	add_child(name_lbl)


func _update_health_bar() -> void:
	if not is_instance_valid(_health_bar):
		return
	var ratio: float = float(_health.current_health) / float(_health.max_health)
	_health_bar.scale.x = max(0.05, ratio)
	var mat := _health_bar.material_override as StandardMaterial3D
	if mat:
		mat.albedo_color = Color(1.0 - ratio, ratio * 0.8, 0.1)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh := CapsuleShape3D.new()
	sh.radius = 0.32
	sh.height = 1.0
	col.shape = sh
	col.position.y = 0.7
	add_child(col)


func on_spawn(_cfg: Dictionary) -> void:
	if is_instance_valid(_health):
		_health.reset()
	_state = State.IDLE


func on_despawn() -> void:
	pass
