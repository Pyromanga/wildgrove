extends Node
class_name ChunkManager

## ChunkManager — Lädt/entlädt Terrain-Chunks basierend auf Spielerposition.
##
## Jeder Chunk ist ein eigenständiges TerrainGenerator-Mesh + Physik.
## Chunks werden generiert wenn der Spieler in Render-Reichweite kommt
## und entladen wenn er zu weit weg ist.
##
## Koordinaten: Chunks sind in Chunk-Koordinaten (cx, cz) indiziert.
## Welt-Origin = Chunk (0,0). Chunk-Größe = CHUNK_SIZE Meter.

const LOG_CAT    := "ChunkManager"
const CHUNK_SIZE := 64.0   # Meter pro Chunk (kleiner = schnelleres Laden)
const LOAD_RADIUS  := 2    # Chunks um den Spieler herum laden (2 = 5×5 = 25 Chunks)
const UNLOAD_RADIUS := 3   # Chunks die weiter weg sind entladen

## Aktive Chunks: { Vector2i(cx, cz): Node3D }
var _chunks: Dictionary = {}

var _player_chunk: Vector2i = Vector2i(999, 999)  # Ungültiger Startwert
var _world_root: Node3D
var _seed: int = 0


func initialize(world_root: Node3D, world_seed: int) -> void:
	_world_root = world_root
	_seed = world_seed
	Logger.log_info(
		"ChunkManager initialisiert. Chunk-Größe: %.0fm, Radius: %d" % [CHUNK_SIZE, LOAD_RADIUS],
		LOG_CAT
	)


func _process(_delta: float) -> void:
	if not is_instance_valid(_world_root):
		return

	var player := _get_player()
	if not is_instance_valid(player):
		return

	var new_chunk := _world_to_chunk(player.global_position)
	if new_chunk == _player_chunk:
		return

	_player_chunk = new_chunk
	_update_chunks()


func _update_chunks() -> void:
	# Chunks in Reichweite laden
	for dz in range(-LOAD_RADIUS, LOAD_RADIUS + 1):
		for dx in range(-LOAD_RADIUS, LOAD_RADIUS + 1):
			var coord := Vector2i(_player_chunk.x + dx, _player_chunk.y + dz)
			if not _chunks.has(coord):
				_load_chunk(coord)

	# Entfernte Chunks entladen
	var to_unload: Array[Vector2i] = []
	for coord in _chunks:
		var dist: int = max(abs(coord.x - _player_chunk.x), abs(coord.y - _player_chunk.y))
		if dist > UNLOAD_RADIUS:
			to_unload.append(coord)

	for coord in to_unload:
		_unload_chunk(coord)


func _load_chunk(coord: Vector2i) -> void:
	# Chunk (0,0) überspringen — das Haupt-Terrain aus WorldFactory
	# deckt diesen Bereich bereits ab. Doppeltes Terrain würde Z-Fighting erzeugen.
	if coord == Vector2i(0, 0):
		_chunks[coord] = null  # Als "geladen" markieren ohne Node
		return

	var chunk_origin := _chunk_to_world(coord)
	Logger.log_debug("Lade Chunk %s @ %s" % [str(coord), str(chunk_origin)], LOG_CAT)

	var gen := TerrainGenerator.new()
	gen.size       = CHUNK_SIZE
	gen.resolution = 32   # Niedriger als Haupt-Terrain — Chunks müssen schnell laden
	gen.max_height = 4.0
	gen.water_level = 0.5
	# Deterministischer Seed pro Chunk — reproduzierbar, nahtlos (annähernd)
	gen.noise_seed = _seed ^ (coord.x * 73856093) ^ (coord.y * 19349663)

	var chunk_node := Node3D.new()
	chunk_node.name = "Chunk_%d_%d" % [coord.x, coord.y]
	chunk_node.position = Vector3(chunk_origin.x, 0.0, chunk_origin.y)
	_world_root.add_child(chunk_node)

	gen.create(chunk_node)
	_chunks[coord] = chunk_node

	# Entities für diesen Chunk spawnen (Bäume, Erze)
	_spawn_chunk_entities(coord, chunk_node, chunk_origin)


func _unload_chunk(coord: Vector2i) -> void:
	if not _chunks.has(coord):
		return
	var chunk_node = _chunks[coord]
	_chunks.erase(coord)
	if is_instance_valid(chunk_node):
		chunk_node.queue_free()
	Logger.log_debug("Chunk %s entladen." % str(coord), LOG_CAT)


func _spawn_chunk_entities(coord: Vector2i, _chunk_node: Node3D, origin: Vector2) -> void:
	if not is_instance_valid(Services.world):
		return

	var rng := RandomNumberGenerator.new()
	rng.seed = _seed ^ (coord.x * 1234567) ^ (coord.y * 7654321)

	# Bäume
	var tree_count := rng.randi_range(1, 4)
	for _i in range(tree_count):
		var lx := rng.randf_range(4.0, CHUNK_SIZE - 4.0)
		var lz := rng.randf_range(4.0, CHUNK_SIZE - 4.0)
		var wx: float = origin.x + lx
		var wz: float = origin.y + lz
		var h := _get_world_height(wx, wz)
		if h > 1.2:
			Services.world.spawn_entity("oak_tree", Vector3(wx, h, wz))

	# Tiere — jeder dritte Chunk bekommt ein Tier
	if (abs(coord.x) + abs(coord.y)) % 3 == 0:
		var animal_types := ["deer", "rabbit", "boar"]
		var animal_type: String = animal_types[rng.randi_range(0, 2)]
		var lx := rng.randf_range(8.0, CHUNK_SIZE - 8.0)
		var lz := rng.randf_range(8.0, CHUNK_SIZE - 8.0)
		var wx: float = origin.x + lx
		var wz: float = origin.y + lz
		var h := _get_world_height(wx, wz)
		if h > 1.2:
			Services.world.spawn_entity(animal_type, Vector3(wx, h, wz))


func _get_world_height(wx: float, wz: float) -> float:
	if is_instance_valid(Services.world) and \
	   is_instance_valid(Services.world.factory) and \
	   is_instance_valid(Services.world.factory.terrain_generator):
		return Services.world.factory.terrain_generator.get_height_at(wx, wz)
	return 1.5


func _world_to_chunk(pos: Vector3) -> Vector2i:
	return Vector2i(
		int(floor(pos.x / CHUNK_SIZE)),
		int(floor(pos.z / CHUNK_SIZE))
	)


func _chunk_to_world(coord: Vector2i) -> Vector2:
	return Vector2(coord.x * CHUNK_SIZE, coord.y * CHUNK_SIZE)


func _get_player() -> Node3D:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return null
	return players[0] as Node3D
