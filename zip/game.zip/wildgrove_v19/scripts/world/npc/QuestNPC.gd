extends StaticBody3D
class_name QuestNPC

## QuestNPC — Stationärer Quest-Geber.
##
## Ist interagierbar (InteractableComponent mit "talk"-Aktion) und
## zeigt einen Dialog wenn der Spieler spricht.
## Gibt Quests aus und schließt sie ab wenn die Objectives erfüllt sind.
##
## Drei Zustände:
##   HAS_QUEST    → bietet eine neue Quest an
##   QUEST_ACTIVE → Quest läuft, ermutigt den Spieler
##   QUEST_DONE   → Quest abgeschlossen, zeigt Belohnung

const LOG_CAT := "QuestNPC"

enum NPCState { HAS_QUEST, QUEST_ACTIVE, QUEST_DONE }

var _state: NPCState = NPCState.HAS_QUEST
var _quest_id := "quest_woodcutter_intro"
var _dialog_label: Label3D = null
var _interactable: InteractableComponent = null


func _ready() -> void:
	name = "QuestNPC_Waldläufer"
	add_to_group("npcs")
	_build_visuals()
	_build_collision()
	_setup_interactable()
	# Quest-Completion über EventBus lauschen (nicht Services.quest direkt)
	EventBus.quest.quest_completed.connect(_on_quest_completed)
	Logger.log_info("QuestNPC bereit.", LOG_CAT)


# ─────────────────────────────────────────────
# Visuals
# ─────────────────────────────────────────────


func _build_visuals() -> void:
	# Körper
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.25, 0.40, 0.65)  # Blaue Jacke

	var body_mesh := CapsuleMesh.new()
	body_mesh.radius = 0.28
	body_mesh.height = 1.1
	var body_mi := MeshInstance3D.new()
	body_mi.mesh = body_mesh
	body_mi.material_override = body_mat
	body_mi.position.y = 0.95
	add_child(body_mi)

	# Kopf
	var head_mat := StandardMaterial3D.new()
	head_mat.albedo_color = Color(0.88, 0.72, 0.58)  # Hautfarbe
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.22
	head_mesh.height = 0.44
	var head_mi := MeshInstance3D.new()
	head_mi.mesh = head_mesh
	head_mi.material_override = head_mat
	head_mi.position.y = 1.72
	add_child(head_mi)

	# Hut
	var hat_mat := StandardMaterial3D.new()
	hat_mat.albedo_color = Color(0.25, 0.18, 0.08)
	var hat_mesh := CylinderMesh.new()
	hat_mesh.top_radius = 0.20
	hat_mesh.bottom_radius = 0.28
	hat_mesh.height = 0.25
	var hat_mi := MeshInstance3D.new()
	hat_mi.mesh = hat_mesh
	hat_mi.material_override = hat_mat
	hat_mi.position.y = 1.98
	add_child(hat_mi)

	# Name-Label über dem NPC
	var name_lbl := Label3D.new()
	name_lbl.text = "Waldläufer Erik"
	name_lbl.font_size = 48
	name_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_lbl.modulate = Color(1.0, 0.9, 0.3)
	name_lbl.position.y = 2.4
	add_child(name_lbl)

	# Dialog-Label (initial unsichtbar)
	_dialog_label = Label3D.new()
	_dialog_label.text = ""
	_dialog_label.font_size = 36
	_dialog_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_dialog_label.modulate = Color(1.0, 1.0, 1.0, 0.9)
	_dialog_label.position.y = 2.9
	_dialog_label.visible = false
	add_child(_dialog_label)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.35
	sh.height = 1.5
	col.shape = sh
	col.position.y = 0.75
	add_child(col)


# ─────────────────────────────────────────────
# Interaktion
# ─────────────────────────────────────────────


func _setup_interactable() -> void:
	var d := InteractableData.new()
	d.id          = "talk_quest_npc"
	d.action_id   = "talk_quest_npc"
	d.label       = "Mit Erik sprechen"
	d.duration    = 0.3
	d.xp_type     = "none"
	d.xp_amount   = 0
	d.drops       = {}
	d.inspect_text = "Waldläufer Erik. Er sieht aus als hätte er eine Aufgabe für dich."

	_interactable = InteractableComponent.new()
	_interactable.data = d
	add_child(_interactable)

	# Entkoppelt: horcht auf EventBus statt _handle_completion zu überschreiben
	EventBus.world.interaction_finished.connect(_on_interaction_finished)


func _on_interaction_finished(action_id: String, _label: String) -> void:
	if action_id == "talk_quest_npc":
		match _state:
			NPCState.HAS_QUEST:   _offer_quest()
			NPCState.QUEST_ACTIVE: _check_and_encourage()
			NPCState.QUEST_DONE:  _show_completed_dialog()


func _offer_quest() -> void:
	Logger.log_info("NPC bietet Quest an: '%s'" % _quest_id, LOG_CAT)

	if not is_instance_valid(Services.quest):
		_show_dialog("Ich bräuchte deine Hilfe, aber\nder Quest-Service fehlt...")
		return

	# Quest starten
	var started := Services.quest.start_quest(_quest_id)
	if started:
		_state = NPCState.QUEST_ACTIVE
		_show_dialog("Gut, dass du da bist!\nFälle 3 Eichen für mich.\nDas Holz wird gebraucht.")
		Logger.log_info("Quest '%s' gestartet." % _quest_id, LOG_CAT)
	else:
		_show_dialog("Die Quest konnte nicht\ngestartet werden...")
		Logger.log_warn("Quest '%s' konnte nicht gestartet werden." % _quest_id, LOG_CAT)


func _check_and_encourage() -> void:
	if not is_instance_valid(Services.quest):
		return
	var progress := Services.quest.get_objective_progress(_quest_id, "obj_chop_trees")
	_show_dialog("Gut! Du hast schon\n%d/3 Bäume gefällt." % progress)


func _show_completed_dialog() -> void:
	_show_dialog("Danke! Das Holz werde\nich gut gebrauchen können.")


func _on_quest_completed(quest_id: String, _reward: QuestReward) -> void:
	if quest_id == _quest_id:
		_state = NPCState.QUEST_DONE
		Logger.log_info("Quest '%s' abgeschlossen — NPC-Status aktualisiert." % quest_id, LOG_CAT)


func _show_dialog(text: String) -> void:
	_dialog_label.text = text
	_dialog_label.visible = true
	# Auto-Hide nach 5 Sekunden
	var timer := get_tree().create_timer(5.0)
	timer.timeout.connect(func(): 
		if is_instance_valid(_dialog_label):
			_dialog_label.visible = false
	)
	# Auch Notification-Controller nutzen falls vorhanden
	EventBus.world.emit_interaction_reward_text(text.replace("\n", " "))


func on_spawn(_cfg: Dictionary) -> void:
	pass

func on_despawn() -> void:
	pass
