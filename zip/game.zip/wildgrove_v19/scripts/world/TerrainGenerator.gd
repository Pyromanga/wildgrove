class_name TerrainGenerator
extends RefCounted

## TerrainGenerator — Prozedurales Terrain mit Biomen, Hügeln, Flüssen und Seen.
##
## v19 Fixes:
##   - Wasser nur dort sichtbar wo Terrain tatsächlich tief ist (kein globales Overlay mehr)
##   - Mindesthöhe von 1.0 entfernt → Terrain kann unter Wasser-Level sinken
##   - max_height 4 → 14 für deutlich hügeligeres Gelände
##   - Biom-System: Wald, Savanne, Sumpf je nach Temperatur/Feuchtigkeits-Noise
##   - Halbtransparentes Wasser → Unterwasserhöhlen sichtbar

const LOG_CAT := "TerrainGen"

var size: float       = 120.0
var resolution: int   = 128
var max_height: float = 14.0
var water_level: float = 1.2   # Welteinheit Y, unter der Wasser gerendert wird
var noise_seed: int = 0

# Terrain-Farben pro Biom
const COL_DEEP_WATER  := Color(0.05, 0.18, 0.45)
const COL_SHALLOW     := Color(0.12, 0.38, 0.65)
const COL_SAND        := Color(0.82, 0.76, 0.52)
const COL_GRASS       := Color(0.20, 0.55, 0.16)
const COL_SAVANNA     := Color(0.62, 0.58, 0.22)
const COL_SWAMP       := Color(0.22, 0.38, 0.18)
const COL_HILL        := Color(0.42, 0.36, 0.24)
const COL_ROCK        := Color(0.52, 0.47, 0.42)
const COL_SNOW        := Color(0.93, 0.94, 0.96)
const COL_FOREST_DARK := Color(0.12, 0.38, 0.10)

var _noise: FastNoiseLite          # Haupt-Höhen-Noise
var _biome_noise: FastNoiseLite    # Biom-Noise (Temperatur/Feuchtigkeit)
var _detail_noise: FastNoiseLite   # Fein-Detail-Noise
var _rng: RandomNumberGenerator


func _init() -> void:
	_rng = RandomNumberGenerator.new()
	_rng.seed = noise_seed if noise_seed != 0 else int(Time.get_unix_time_from_system())

	# Haupt-Noise: sanfte Hügel mit großer Skala
	_noise = FastNoiseLite.new()
	_noise.seed = _rng.randi()
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_noise.fractal_octaves = 7
	_noise.fractal_lacunarity = 2.0
	_noise.fractal_gain = 0.50
	_noise.frequency = 0.008   # Niedrig = breitere Hügel

	# Biom-Noise: bestimmt Wald/Savanne/Sumpf – sehr groß-skalig
	_biome_noise = FastNoiseLite.new()
	_biome_noise.seed = _rng.randi()
	_biome_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_biome_noise.frequency = 0.004
	_biome_noise.fractal_octaves = 2

	# Detail-Noise: kleine Unebenheiten auf dem Terrain
	_detail_noise = FastNoiseLite.new()
	_detail_noise.seed = _rng.randi()
	_detail_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_detail_noise.frequency = 0.035
	_detail_noise.fractal_octaves = 4
	_detail_noise.fractal_gain = 0.45


func create(world: Node3D) -> void:
	var t := Logger.log_begin("TerrainGenerator.create()", LOG_CAT)

	var heights := _generate_heightmap()
	var terrain := _build_terrain_mesh(heights)
	terrain.name = "Terrain"
	world.add_child(terrain)

	# Wasser: halbtransparente Plane auf water_level.
	# Halbtransparenz → Spieler sieht Terrain unter Wasser (Unterwasserhöhlen!)
	# Die Plane überdeckt das gesamte Terrain, ABER durch alpha=0.82
	# ist der tiefere Boden weiterhin sichtbar – keine Cave-Clipping-Probleme.
	var water := _build_water_plane()
	water.name = "Water"
	world.add_child(water)

	var physics := _build_physics_body(heights)
	physics.name = "TerrainPhysics"
	world.add_child(physics)

	Logger.log_end("TerrainGenerator.create()", t, LOG_CAT)
	Logger.log_info(
		"Terrain: %dx%d, %.0fm×%.0fm, max_h=%.1f" % [resolution, resolution, size, size, max_height],
		LOG_CAT
	)


func get_height_at(x: float, z: float) -> float:
	var nx: float = x / size
	var nz: float = z / size
	return _sample_height(nx, nz)


# ─────────────────────────────────────────────
# Heightmap
# ─────────────────────────────────────────────


func _generate_heightmap() -> PackedFloat32Array:
	var n := resolution + 1
	var map := PackedFloat32Array()
	map.resize(n * n)

	var river_x_offset: float = _rng.randf_range(-0.15, 0.15)
	var river_amplitude: float = _rng.randf_range(0.05, 0.12)

	for z_i in range(n):
		for x_i in range(n):
			var nx: float = float(x_i) / float(resolution) - 0.5
			var nz: float = float(z_i) / float(resolution) - 0.5

			var h: float = _sample_height(nx, nz)

			# Fluss – schmalem Kanal entlang einer Sinus-Kurve absenken
			var river_x: float = sin(nz * PI * 2.2) * river_amplitude + river_x_offset
			var river_dist: float = abs(nx - river_x)
			var river_width: float = 0.028
			if river_dist < river_width:
				var t_r: float = 1.0 - river_dist / river_width
				h = lerp(h, 0.4, pow(t_r, 2.0))

			# Seen (flache Mulden)
			h = _apply_lake(h, nx, nz,  0.20, -0.25, 0.11)
			h = _apply_lake(h, nx, nz, -0.22,  0.18, 0.09)
			h = _apply_lake(h, nx, nz,  0.02,  0.30, 0.07)

			map[z_i * n + x_i] = h

	return map


func _sample_height(nx: float, nz: float) -> float:
	# Basis-Noise 0..1
	var raw: float = (_noise.get_noise_2d(nx, nz) + 1.0) * 0.5

	# Continent-Form: weicht das Zentrum leicht an → natürlichere Hügel-Verteilung
	var continent: float = 1.0 - (Vector2(nx, nz).length() * 1.2)
	continent = clamp(continent, 0.0, 1.0)
	raw = raw * 0.7 + raw * continent * 0.3

	# Detail-Noise addieren (kleine Unebenheiten, 15% Einfluss)
	var detail: float = (_detail_noise.get_noise_2d(nx * 3.0, nz * 3.0) + 1.0) * 0.5
	raw = raw * 0.85 + detail * 0.15

	# Power-Kurve → flacheres Tal, steilere Bergspitzen
	raw = pow(raw, 1.3)

	# KEIN Mindest-Boden mehr: Terrain kann unter water_level sinken → Seen/Flüsse echt
	return raw * max_height


func _apply_lake(h: float, nx: float, nz: float, cx: float, cz: float, radius: float) -> float:
	var dist: float = Vector2(nx - cx, nz - cz).length()
	if dist < radius:
		var t: float = 1.0 - dist / radius
		# Seeboden tief genug unter water_level damit Wasser sichtbar ist
		return lerp(h, 0.3, pow(t, 2.5))
	return h


# ─────────────────────────────────────────────
# Mesh-Bau
# ─────────────────────────────────────────────


func _build_terrain_mesh(heights: PackedFloat32Array) -> MeshInstance3D:
	var n := resolution + 1
	var step: float = size / float(resolution)
	var half: float = size * 0.5

	var verts   := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors  := PackedColorArray()
	var indices := PackedInt32Array()

	for z_i in range(n):
		for x_i in range(n):
			var h: float = heights[z_i * n + x_i]
			var vx: float = x_i * step - half
			var vz: float = z_i * step - half
			var nx: float = float(x_i) / float(resolution) - 0.5
			var nz: float = float(z_i) / float(resolution) - 0.5
			verts.append(Vector3(vx, h, vz))
			colors.append(_height_to_color(h, nx, nz))
			normals.append(Vector3.UP)  # Placeholder

	for z_i in range(resolution):
		for x_i in range(resolution):
			var i00: int = z_i * n + x_i
			var i10: int = i00 + 1
			var i01: int = (z_i + 1) * n + x_i
			var i11: int = i01 + 1
			indices.append(i00); indices.append(i01); indices.append(i10)
			indices.append(i10); indices.append(i01); indices.append(i11)

	# Normalen berechnen
	var tri_normals: Array[Vector3] = []
	for _i in range(verts.size()):
		tri_normals.append(Vector3.ZERO)
	for tri_i in range(0, indices.size(), 3):
		var a: int = indices[tri_i]
		var b: int = indices[tri_i + 1]
		var c: int = indices[tri_i + 2]
		var n_vec: Vector3 = (verts[b] - verts[a]).cross(verts[c] - verts[a]).normalized()
		tri_normals[a] += n_vec
		tri_normals[b] += n_vec
		tri_normals[c] += n_vec
	for i in range(verts.size()):
		normals[i] = tri_normals[i].normalized()

	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX]  = verts
	arr[Mesh.ARRAY_NORMAL]  = normals
	arr[Mesh.ARRAY_COLOR]   = colors
	arr[Mesh.ARRAY_INDEX]   = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.92
	mat.metallic = 0.0
	mat.render_priority = -1  # Terrain vor Wasser rendern

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	return mi


func _height_to_color(h: float, nx: float, nz: float) -> Color:
	var ratio: float = h / max_height
	var wl_ratio: float = water_level / max_height

	# Biom-Wert (0..1): bestimmt ob Gras, Savanne oder Sumpf
	var biome: float = (_biome_noise.get_noise_2d(nx, nz) + 1.0) * 0.5

	if ratio < wl_ratio * 0.4:
		return COL_DEEP_WATER
	elif ratio < wl_ratio * 0.8:
		return COL_SHALLOW
	elif ratio < wl_ratio:
		return COL_SHALLOW.lerp(COL_SAND, (ratio - wl_ratio * 0.8) / (wl_ratio * 0.2))
	elif ratio < wl_ratio + 0.04:
		return COL_SAND.lerp(_grass_color(biome), (ratio - wl_ratio) / 0.04)
	elif ratio < 0.40:
		# Vegetation: Biom-abhängig
		return _grass_color(biome)
	elif ratio < 0.55:
		return _grass_color(biome).lerp(COL_HILL, (ratio - 0.40) / 0.15)
	elif ratio < 0.70:
		return COL_HILL.lerp(COL_ROCK, (ratio - 0.55) / 0.15)
	elif ratio < 0.85:
		return COL_ROCK
	else:
		return COL_ROCK.lerp(COL_SNOW, (ratio - 0.85) / 0.15)


func _grass_color(biome: float) -> Color:
	if biome < 0.35:
		return COL_SWAMP.lerp(COL_FOREST_DARK, biome / 0.35)
	elif biome < 0.65:
		return COL_GRASS
	else:
		return COL_GRASS.lerp(COL_SAVANNA, (biome - 0.65) / 0.35)


# ─────────────────────────────────────────────
# Wasser
# ─────────────────────────────────────────────


func _build_water_plane() -> MeshInstance3D:
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(size, size)
	mesh.subdivide_width = 16
	mesh.subdivide_depth = 16

	# OPAKES Material — exakt wie v18.
	# Funktioniert weil Godot 4 Depth-Tests für opake Objekte garantiert:
	#   Terrain (render_priority=-1) → schreibt Depth-Buffer
	#   Wasser  (render_priority= 1) → testet Depth-Buffer
	#   → Wasser wird verdeckt wo Terrain höher liegt, sichtbar wo Terrain tiefer liegt.
	# KEIN TRANSPARENCY_ALPHA — das verschiebt Wasser in den transparenten Pass
	# und zerstört die Depth-Sort-Reihenfolge.
	var mat := StandardMaterial3D.new()
	mat.albedo_color  = Color(0.12, 0.38, 0.72, 1.0)   # Voll opak
	mat.roughness     = 0.08
	mat.metallic      = 0.20
	mat.render_priority = 1   # Nach Terrain (=-1) rendern → Depth-Test korrekt

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position.y = water_level
	return mi


func _build_physics_body(heights: PackedFloat32Array) -> StaticBody3D:
	var body := StaticBody3D.new()
	var col  := CollisionShape3D.new()
	var shape := HeightMapShape3D.new()

	shape.map_width = resolution + 1
	shape.map_depth = resolution + 1
	shape.map_data  = heights

	col.shape = shape
	body.add_child(col)

	var scale_xz: float = size / float(resolution)
	body.scale = Vector3(scale_xz, 1.0, scale_xz)

	return body
