# res://scripts/world/WorldEntitySpawner.gd
class_name WorldEntitySpawner
extends RefCounted

## WorldEntitySpawner — Platziert die initiale Entity-Population einer Welt.
##
## EXTRAHIERT AUS WorldService.gd (Review-Session 4, "Files so klein wie
## möglich"). WorldService.gd war mit 546 Zeilen die größte Datei im Projekt.
## Diese Klasse übernimmt den Teil "gegeben WorldData (Positionen aus Save
## ODER WorldGenerationService) → erzeuge die tatsächlichen Nodes in der
## Szene". Trennung: WorldSaveAdapter befüllt WorldData NUR mit Daten, DIESE
## Klasse erzeugt daraus Nodes. WorldService bleibt der dünne Koordinator.
##
## KEIN ServiceNode — RefCounted, lebt als Member-Var in WorldService.
## Bekommt alle benötigten Referenzen per _init() injiziert (kein globaler
## Services.*-Zugriff hier — macht das Testen mit Fake-Objekten leichter).

const LOG_CAT := "WorldEntitySpawner"

## Standard-Startpositionen als FALLBACK wenn WorldGen und kein Savegame vorhanden.
## Normalerweise werden diese durch WorldGenerationService.generate_world() ersetzt.
const DEFAULT_TREE_POSITIONS: Array[Vector3] = [
	Vector3(5, 0, 5),
	Vector3(-6, 0, 4),
	Vector3(8, 0, -3),
]
const DEFAULT_ORE_POSITIONS: Array[Vector3] = [
	Vector3(-4, 0, 6),
]

var _data: WorldData
var _factory: WorldFactory
var _entity_orchestrator: EntityOrchestrator
var _world_gen: WorldGenerationService  # kann null sein (siehe configure() in WorldService)


func _init(
	p_data: WorldData,
	p_factory: WorldFactory,
	p_entity_orchestrator: EntityOrchestrator,
	p_world_gen: WorldGenerationService
) -> void:
	_data = p_data
	_factory = p_factory
	_entity_orchestrator = p_entity_orchestrator
	_world_gen = p_world_gen


## Registriert alle bekannten Entity-Typen beim EntityOrchestrator.
## Neuer Entity-Typ? → hier eine Zeile hinzufügen (siehe architecture.md §9).
func register_entity_definitions() -> void:
	var t := Logger.log_begin("register_entity_definitions()", LOG_CAT)

	_entity_orchestrator.register_definition(
		"oak_tree",   "res://scripts/world/objects/OakTree.gd",        "trees")
	_entity_orchestrator.register_definition(
		"iron_ore",   "res://scripts/world/objects/IronOre.gd",         "ores")
	_entity_orchestrator.register_definition(
		"deer",       "res://scripts/world/animals/Deer.gd",            "animals")
	_entity_orchestrator.register_definition(
		"rabbit",     "res://scripts/world/animals/Rabbit.gd",          "animals")
	_entity_orchestrator.register_definition(
		"boar",       "res://scripts/world/animals/Boar.gd",            "animals")
	_entity_orchestrator.register_definition(
		"quest_npc",  "res://scripts/world/npc/QuestNPC.gd",            "npcs")
	_entity_orchestrator.register_definition(
		"goblin",     "res://scripts/world/combat/EnemyNPC.gd",         "enemies")

	Logger.log_end("register_entity_definitions()", t, LOG_CAT)
	Logger.log_debug("Entity-Definitionen registriert: oak_tree, iron_ore, ...", LOG_CAT)


## Spawnt Bäume, Erze, Tiere, Quest-NPC, Gegner und startet den ChunkManager.
## Erwartet, dass _data.tree_positions / _data.ore_positions bereits befüllt
## sind (von WorldSaveAdapter.restore_from_dict ODER WorldGenerationService).
##
## Rückgabe: {"trees_spawned": int, "ores_spawned": int} — für die
## Zusammenfassungs-Log-Zeile des Aufrufers (WorldService.on_world_scene_ready).
func spawn_world_entities(world_root_ref: Node3D) -> Dictionary:
	var t := Logger.log_begin("spawn_world_entities()", LOG_CAT)

	var tree_positions: Array[Vector3] = _data.tree_positions
	var ore_positions:  Array[Vector3] = _data.ore_positions

	if tree_positions.is_empty() and ore_positions.is_empty():
		# Kein Save — WorldGenerationService verwenden wenn verfügbar
		if is_instance_valid(_world_gen):
			Logger.log_info("Kein Save — generiere Welt via WorldGenerationService.", LOG_CAT)
			# Seed aus Tag-Zähler + Systemzeit für Reproduzierbarkeit im selben Spiel-Run
			var seed_val := int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
			_world_gen.generate_world(seed_val, _data)
			tree_positions = _data.tree_positions
			ore_positions  = _data.ore_positions
		else:
			# Letzter Fallback: Hardcodierte Standardpositionen
			Logger.log_warn("WorldGenerationService nicht verfügbar — nutze Hardcode-Defaults.", LOG_CAT)
			tree_positions = DEFAULT_TREE_POSITIONS
			ore_positions  = DEFAULT_ORE_POSITIONS
			# .duplicate(): DEFAULT_*_POSITIONS sind const — ohne Kopie würde ein
			# späteres data.tree_positions.append(...) die KONSTANTE selbst mutieren
			# (Arrays sind Referenztypen), und damit jede zukünftige Fallback-Welt
			# in diesem Prozess verseuchen.
			_data.tree_positions = DEFAULT_TREE_POSITIONS.duplicate()
			_data.ore_positions  = DEFAULT_ORE_POSITIONS.duplicate()
	else:
		Logger.log_debug(
			"Positionen aus Save: %d Bäume, %d Erze." % [tree_positions.size(), ore_positions.size()],
			LOG_CAT
		)

	# Bäume spawnen (nicht-geerntete)
	var trees_spawned := 0
	for pos in tree_positions:
		if not _data.is_tree_harvested(pos):
			_entity_orchestrator.spawn_entity("oak_tree", pos)
			trees_spawned += 1
		else:
			Logger.log_debug("Baum bei %s geerntet — RespawnService übernimmt." % str(pos), LOG_CAT)

	# Erze spawnen (nicht-abgebaute)
	var ores_spawned := 0
	for pos in ore_positions:
		if not _data.is_ore_harvested(pos):
			_entity_orchestrator.spawn_entity("iron_ore", pos)
			ores_spawned += 1
		else:
			Logger.log_debug("Erz bei %s abgebaut — RespawnService übernimmt." % str(pos), LOG_CAT)

	# Tiere spawnen — zufällig verteilt, weit genug vom Spieler
	_spawn_animals()

	# Quest-NPC (fest positioniert)
	_entity_orchestrator.spawn_entity("quest_npc", Vector3(8.0, 0.0, -5.0))

	# Goblins
	_spawn_enemies()

	# ChunkManager — lädt weitere Terrain-Chunks wenn Spieler sich entfernt
	# WICHTIG: Chunk (0,0) wird NICHT geladen — das Haupt-Terrain aus WorldFactory
	# ist bereits der Start-Chunk. ChunkManager überspringt diesen.
	_setup_chunk_manager(world_root_ref)

	Logger.log_end("spawn_world_entities()", t, LOG_CAT)
	Logger.log_info(
		"Entity-Spawning abgeschlossen: %d Bäume, %d Erze. Total aktiv: %d." % [
			trees_spawned, ores_spawned, _entity_orchestrator.get_entity_count()
		],
		LOG_CAT
	)

	return {"trees_spawned": trees_spawned, "ores_spawned": ores_spawned}


func _spawn_enemies() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system()) ^ 0x1337

	for _i in range(5):
		var x := rng.randf_range(-20.0, 20.0)
		var z := rng.randf_range(-20.0, 20.0)
		if Vector2(x, z).length() < 10.0:
			continue
		var h := 1.5
		if is_instance_valid(_factory.terrain_generator):
			h = _factory.terrain_generator.get_height_at(x, z)
		if h > 1.2:
			_entity_orchestrator.spawn_entity("goblin", Vector3(x, h, z))

	Logger.log_info("Feindliche NPCs gespawnt.", LOG_CAT)


func _setup_chunk_manager(world_root_ref: Node3D) -> void:
	var chunk_manager := ChunkManager.new()
	chunk_manager.name = "ChunkManager"
	world_root_ref.add_child(chunk_manager)
	var seed_val := int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	chunk_manager.initialize(world_root_ref, seed_val)
	Logger.log_info("ChunkManager gestartet.", LOG_CAT)


func _spawn_animals() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system()) ^ 0xABCDEF

	var animal_configs := [
		{"type": "deer",   "count": 4, "min_dist": 6.0},
		{"type": "rabbit", "count": 6, "min_dist": 3.0},
		{"type": "boar",   "count": 3, "min_dist": 7.0},
	]

	var all_positions: Array[Vector3] = []
	for cfg in animal_configs:
		var placed := 0
		var attempts := 0
		while placed < cfg["count"] and attempts < 60:
			attempts += 1
			var x := rng.randf_range(-25.0, 25.0)
			var z := rng.randf_range(-25.0, 25.0)
			var candidate := Vector3(x, 0.0, z)
			if candidate.length() < 8.0:
				continue
			var too_close := false
			for other in all_positions:
				if candidate.distance_to(other) < cfg["min_dist"]:
					too_close = true
					break
			if too_close:
				continue
			if is_instance_valid(_factory.terrain_generator):
				var h := _factory.terrain_generator.get_height_at(x, z)
				if h < 1.2:
					continue
				candidate.y = h
			all_positions.append(candidate)
			_entity_orchestrator.spawn_entity(cfg["type"], candidate)
			placed += 1

	Logger.log_info("Tiere gespawnt: %d total." % all_positions.size(), LOG_CAT)
