extends ServiceNode
class_name HUDManager

## HUDManager — Zentrale Steuerung des in-game HUD.
##
## KRITISCH: HUD hängt unter /root — NICHT unter der Welt-Szene.
## change_scene_to_file() freed die alte Szene komplett.
## Alles was Kind einer Szene ist wird mitgefreedt.
## CanvasLayer unter /root überlebt jeden Szenenwechsel.
##
## Lifecycle:
##   on_ready()  → HUD unter /root einhängen, einmalig
##   world_scene_ready → Controller neu bauen (zeigen auf neue Spieler-Instanz)
##   state_changed     → HUD ein-/ausblenden

const LOG_CAT := "HUD"

var hud: HUD = null
var controllers: Dictionary = {}

var _inventory: InventorySystem
var _player_states: PlayerStateService


func configure(deps: Dictionary) -> void:
	_inventory     = deps.get("inventory")    as InventorySystem
	_player_states = deps.get("playerstates") as PlayerStateService

	# HUD hier erstellen — aber noch nicht in den Tree.
	# on_ready() hängt ihn unter /root ein.
	hud = HUD.new()
	hud.name = "GameHUD"
	hud.visible = false


func on_ready() -> void:
	# Einmalig unter /root einhängen.
	# /root wird nie gefreedt — HUD überlebt alle Szenenwechsel.
	get_tree().root.call_deferred("add_child", hud)

	EventBus.world.world_scene_ready.connect(_on_world_scene_ready)
	EventBus.system.state_changed.connect(_on_state_changed)
	Logger.log_info("HUDManager bereit. HUD wird unter /root eingehängt.", LOG_CAT)


func on_cleanup() -> void:
	if is_instance_valid(hud):
		hud.queue_free()
	hud = null
	controllers.clear()


func get_controller(key: String) -> Object:
	return controllers.get(key)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _on_world_scene_ready(_scene_root: Node) -> void:
	if not is_instance_valid(hud):
		Logger.log_error("_on_world_scene_ready: HUD ist null!", LOG_CAT)
		return

	# Alte Controller-Nodes bereinigen
	# (zeigen auf Spieler/Entities der alten Session)
	for child in hud.get_children():
		hud.remove_child(child)
		child.free()
	controllers.clear()

	# Notification-Signal trennen bevor neu verbunden wird
	var conns := EventBus.world.interaction_reward_text.get_connections().duplicate()
	for conn in conns:
		EventBus.world.interaction_reward_text.disconnect(conn["callable"])

	# Controller neu aufbauen — referenzieren neue Spieler-Instanz
	var context := {"inventory": _inventory, "player_states": _player_states}
	controllers = HUDBuilder.build_all(hud, context)

	var notif := controllers.get("notification") as NotificationController
	if notif:
		EventBus.world.interaction_reward_text.connect(notif.show)

	hud.visible = true
	Logger.log_info("HUD aktiv. %d Controller." % controllers.size(), LOG_CAT)


func _on_state_changed(new_state: int) -> void:
	if not is_instance_valid(hud):
		return
	hud.visible = (new_state == GameEnums.State.PLAYING)
