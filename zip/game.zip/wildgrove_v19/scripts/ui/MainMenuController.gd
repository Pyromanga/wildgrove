extends Control
## MainMenuController — Controller für das Hauptmenü.
##
## BOOT-FAILURE-CHECK (Review-Session 4):
##   ServiceOrchestrator.boot() läuft als Autoload VOR dieser _ready().
##   Wenn Phase 1-3 fehlgeschlagen sind, ist ServiceOrchestrator.boot_ok=false
##   UND Services.* ist leer (Phase 7 "populate" wurde nie erreicht).
##   Vorher: Start-Button blieb sichtbar/klickbar, _on_start_pressed() loggte
##   nur einen Error — der Spieler sah ein scheinbar funktionierendes Menü.
##   Jetzt: Start-Button wird deaktiviert + Fehlertext eingeblendet.
##
##   Ersetzt den (toten) boot_failed-Listener aus dem nie geladenen Main.tscn —
##   siehe scripts/_archive/README.md.

const LOG_CAT := "MainMenu"


func _ready() -> void:
	$StartButton.pressed.connect(_on_start_pressed)
	_check_boot_status()
	Logger.log_info("MainMenu bereit.", LOG_CAT)


func _on_start_pressed() -> void:
	if is_instance_valid(Services.game_manager):
		Services.game_manager.change_state(GameEnums.State.PLAYING)
	else:
		Logger.log_error("GameManager nicht verfügbar!", LOG_CAT)


# ─────────────────────────────────────────────
# Boot-Status
# ─────────────────────────────────────────────


func _check_boot_status() -> void:
	if ServiceOrchestrator.boot_ok:
		return

	Logger.log_error(
		"Boot fehlgeschlagen (Phase '%s': %s) — Start-Button deaktiviert."
		% [ServiceOrchestrator.boot_failure_phase, ServiceOrchestrator.boot_failure_reason],
		LOG_CAT
	)

	var start_btn := $StartButton as Button
	start_btn.disabled = true

	var err := Label.new()
	err.name = "BootErrorLabel"
	err.text = (
		"⚠ Start fehlgeschlagen (Phase: %s)\n%s\n\nLog-Ausgabe prüfen (Logger / SimpleTerminal)."
		% [ServiceOrchestrator.boot_failure_phase, ServiceOrchestrator.boot_failure_reason]
	)
	err.modulate = Color(1.0, 0.4, 0.4)
	err.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	err.anchor_left = 0.0
	err.anchor_right = 1.0
	err.anchor_top = 0.0
	err.anchor_bottom = 0.0
	err.offset_top = 40
	err.offset_bottom = 160
	add_child(err)
