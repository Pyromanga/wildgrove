class_name JumpButtonComponent extends BaseUIComponent

func build(hud: HUD) -> JumpButtonController:
	var visuals := JumpButtonVisuals.new(hud)
	var ctrl := JumpButtonController.new()
	hud.add_child(ctrl)
	ctrl.setup(visuals)
	return ctrl
