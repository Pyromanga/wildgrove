class_name PlayerHPComponent extends BaseUIComponent

func build(hud: HUD) -> PlayerHPController:
	var visuals := PlayerHPVisuals.new(hud)
	var ctrl := PlayerHPController.new()
	hud.add_child(ctrl)
	ctrl.setup(visuals)
	return ctrl
