class_name SkillPanelComponent extends BaseUIComponent

func build(hud: HUD) -> SkillPanelController:
	var visuals := SkillPanelVisuals.new(hud)
	var ctrl := SkillPanelController.new()
	hud.add_child(ctrl)
	ctrl.setup(visuals)
	return ctrl
