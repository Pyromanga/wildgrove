class_name HUDBuilder

## HUDBuilder — Instanziiert und verbindet alle HUD-Komponenten.


static func build_all(hud: HUD, context: Dictionary) -> Dictionary:
	var registry: Dictionary = {}
	var ui_events: UIEvents = EventBus.ui

	# 1. Interaktions-Fortschrittsbalken
	registry["interaction"] = InteractionComponent.new().build(hud, EventBus.world)

	# 2. Interaktions-Button
	registry["interaction_button"] = InteractionButtonComponent.new().build(hud)

	# 3. Inventar
	var inv_svc := Services.inventory
	if is_instance_valid(inv_svc):
		var inv_ctrl := InventoryComponent.new().build(hud, inv_svc)
		registry["inventory"] = inv_ctrl
		if inv_ctrl is InventoryUIController:
			inv_ctrl.refresh()
	else:
		Logger.log_error("HUDBuilder: Services.inventory ist null — Inventar-UI fehlt!", "HUD")

	# 4. Floating Text (XP-Gains, Level-Ups)
	registry["floating_text"] = FloatingTextComponent.new().build(hud, EventBus.player)

	# 5. Benachrichtigungen (Reward-Texte nach Interaktionen)
	registry["notification"] = NotificationComponent.new().build(hud)

	# 6. Joystick-Visual
	registry["joystick"] = JoystickComponent.new().build(hud)

	# 7. Kontext-Button und Menü
	registry["context_button"] = ContextButtonComponent.new().build(hud, ui_events)
	registry["context_menu"]   = ContextMenuComponent.new().build(hud, ui_events)

	# 8. Pause-/Optionsmenü
	registry["pause_menu"] = PauseMenuComponent.new().build(hud)

	# 9. Skill-Panel (⚔-Button oben links)
	registry["skill_panel"] = SkillPanelComponent.new().build(hud)

	# 10. Quest-Panel (📜-Button oben links)
	registry["quest_panel"] = QuestPanelComponent.new().build(hud)

	# 11. Spieler-HP-Balken
	registry["player_hp"] = PlayerHPComponent.new().build(hud)

	# 12. Sprung-Button (rechts unten)
	registry["jump_button"] = JumpButtonComponent.new().build(hud)

	# 13. v19: Tod-Overlay mit Respawn-Button
	_build_death_screen(hud)

	return registry


## v19: Tod-Overlay.
## Wird sichtbar wenn player_died emittiert wird.
## "Respawn"-Button ruft player.respawn() auf und blendet das Overlay wieder aus.
static func _build_death_screen(hud: HUD) -> void:
	# Dunkelrotes, halbtransparentes Vollbild-Overlay
	var overlay := ColorRect.new()
	overlay.name = "DeathOverlay"
	overlay.color = Color(0.35, 0.0, 0.0, 0.82)
	overlay.anchor_left   = 0.0
	overlay.anchor_right  = 1.0
	overlay.anchor_top    = 0.0
	overlay.anchor_bottom = 1.0
	overlay.offset_left   = 0.0
	overlay.offset_right  = 0.0
	overlay.offset_top    = 0.0
	overlay.offset_bottom = 0.0
	overlay.mouse_filter  = Control.MOUSE_FILTER_STOP
	overlay.visible = false

	# Zentrierter Inhalt
	var center := VBoxContainer.new()
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_theme_constant_override("separation", 24)
	center.anchor_left   = 0.0
	center.anchor_right  = 1.0
	center.anchor_top    = 0.0
	center.anchor_bottom = 1.0
	overlay.add_child(center)

	var died_lbl := Label.new()
	died_lbl.text = "☠  Du bist gestorben  ☠"
	died_lbl.add_theme_font_size_override("font_size", 42)
	died_lbl.modulate = Color(1.0, 0.3, 0.3)
	died_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.add_child(died_lbl)

	var sub_lbl := Label.new()
	sub_lbl.text = "Alle Items bleiben erhalten."
	sub_lbl.add_theme_font_size_override("font_size", 20)
	sub_lbl.modulate = Color(0.9, 0.7, 0.7)
	sub_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.add_child(sub_lbl)

	var respawn_btn := Button.new()
	respawn_btn.text = "Respawn"
	respawn_btn.custom_minimum_size = Vector2(220, 60)
	# Respawn: Player.respawn() aufrufen → Overlay schließt sich via player_respawned-Signal
	respawn_btn.pressed.connect(func():
		var players := hud.get_tree().get_nodes_in_group("player")
		if not players.is_empty() and players[0].has_method("respawn"):
			players[0].respawn()
	)
	center.add_child(respawn_btn)

	hud.add_child(overlay)

	# Signal-Verbindungen
	EventBus.player.player_died.connect(func(): overlay.visible = true)
	EventBus.player.player_respawned.connect(func(): overlay.visible = false)
