class_name QuestPanelVisuals

## QuestPanelVisuals — v19: zeigt aktive UND abgeschlossene Quests.
##
## Änderungen:
##   - Zwei Abschnitte: "Aktive Quests" + "✓ Abgeschlossen"
##   - Abgeschlossene Quests bleiben sichtbar (grüner Haken, durchgestrichen)
##   - Aktive Quest-Rows werden korrekt bei jedem Objective-Update refreshed

var panel: PanelContainer
var toggle_button: Button
var _active_rows: Dictionary = {}      # { quest_id: {container, obj_container} }
var _completed_rows: Dictionary = {}   # { quest_id: container }

var _active_vbox: VBoxContainer
var _completed_vbox: VBoxContainer
var _completed_header: Label


func _init(parent: CanvasLayer) -> void:
	toggle_button = Button.new()
	toggle_button.name = "QuestToggleButton"
	toggle_button.text = "📜"
	toggle_button.custom_minimum_size = Vector2(80, 80)
	toggle_button.anchor_left   = 0.0
	toggle_button.anchor_right  = 0.0
	toggle_button.anchor_top    = 0.0
	toggle_button.anchor_bottom = 0.0
	toggle_button.offset_left   = 208
	toggle_button.offset_right  = 288
	toggle_button.offset_top    = 16
	toggle_button.offset_bottom = 96
	toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	toggle_button.pressed.connect(toggle)
	parent.add_child(toggle_button)

	panel = PanelContainer.new()
	panel.name = "QuestPanel"
	panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.08, 0.07, 0.04, 0.94)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)

	panel.anchor_left   = 0.0
	panel.anchor_right  = 0.0
	panel.anchor_top    = 0.0
	panel.anchor_bottom = 0.0
	panel.offset_left   = 16
	panel.offset_right  = 340
	panel.offset_top    = 110
	panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 0)
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)

	var active_title := Label.new()
	active_title.text = "Aktive Quests"
	active_title.add_theme_font_size_override("font_size", 18)
	active_title.modulate = Color(1.0, 0.95, 0.6)
	vbox.add_child(active_title)

	_active_vbox = VBoxContainer.new()
	_active_vbox.add_theme_constant_override("separation", 8)
	vbox.add_child(_active_vbox)

	# Separator
	var sep := HSeparator.new()
	vbox.add_child(sep)

	_completed_header = Label.new()
	_completed_header.text = "✓ Abgeschlossen"
	_completed_header.add_theme_font_size_override("font_size", 16)
	_completed_header.modulate = Color(0.5, 0.9, 0.5)
	_completed_header.visible = false
	vbox.add_child(_completed_header)

	_completed_vbox = VBoxContainer.new()
	_completed_vbox.add_theme_constant_override("separation", 4)
	vbox.add_child(_completed_vbox)

	panel.add_child(vbox)
	parent.add_child(panel)


func show_quest(quest_id: String, title: String, objectives: Array) -> void:
	if _active_rows.has(quest_id):
		_update_quest_row(quest_id, objectives)
		return

	var container := VBoxContainer.new()
	container.add_theme_constant_override("separation", 3)

	var title_lbl := Label.new()
	title_lbl.text = title
	title_lbl.add_theme_font_size_override("font_size", 15)
	title_lbl.modulate = Color(1.0, 0.9, 0.4)
	container.add_child(title_lbl)

	var obj_container := VBoxContainer.new()
	obj_container.name = "Objectives"
	container.add_child(obj_container)

	_active_vbox.add_child(container)
	_active_rows[quest_id] = {"container": container, "obj_container": obj_container}
	_update_quest_row(quest_id, objectives)


func _update_quest_row(quest_id: String, objectives: Array) -> void:
	if not _active_rows.has(quest_id):
		return
	var row: Dictionary = _active_rows[quest_id]
	var obj_container := row["obj_container"] as VBoxContainer
	for child in obj_container.get_children():
		obj_container.remove_child(child)
		child.free()
	for obj_data in objectives:
		var lbl := Label.new()
		var done: bool = obj_data["current"] >= obj_data["required"]
		var prefix := "✓ " if done else "○ "
		lbl.text = "%s%s  %d/%d" % [prefix, obj_data["label"], obj_data["current"], obj_data["required"]]
		lbl.add_theme_font_size_override("font_size", 13)
		lbl.modulate = Color(0.6, 1.0, 0.6) if done else Color(1, 1, 1, 0.8)
		obj_container.add_child(lbl)


func remove_active_quest(quest_id: String) -> void:
	if not _active_rows.has(quest_id):
		return
	var row: Dictionary = _active_rows[quest_id]
	var container := row["container"] as Control
	container.get_parent().remove_child(container)
	container.free()
	_active_rows.erase(quest_id)


## Quest in die "Abgeschlossen"-Sektion verschieben.
func move_to_completed(quest_id: String, title: String) -> void:
	# Aus aktiven Quests entfernen
	remove_active_quest(quest_id)

	if _completed_rows.has(quest_id):
		return

	# Abgeschlossen-Header einblenden
	_completed_header.visible = true

	var row := Label.new()
	row.text = "✓ %s" % title
	row.add_theme_font_size_override("font_size", 13)
	row.modulate = Color(0.55, 0.85, 0.55, 0.85)
	_completed_vbox.add_child(row)
	_completed_rows[quest_id] = row


func toggle() -> void:
	panel.visible = !panel.visible
