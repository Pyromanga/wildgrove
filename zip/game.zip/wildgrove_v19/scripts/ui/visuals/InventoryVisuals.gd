class_name InventoryVisuals

var panel: PanelContainer
var label: Label
var toggle_button: Button


func _init(parent: CanvasLayer) -> void:
	# ── Toggle-Button (immer sichtbar, oben links) ──
	toggle_button = Button.new()
	toggle_button.name = "InventoryToggleButton"
	toggle_button.text = "🎒"
	toggle_button.custom_minimum_size = Vector2(80, 80)
	toggle_button.anchor_left   = 0.02
	toggle_button.anchor_right  = 0.02
	toggle_button.anchor_top    = 0.02
	toggle_button.anchor_bottom = 0.02
	toggle_button.offset_right  = 80
	toggle_button.offset_bottom = 80
	toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	parent.add_child(toggle_button)

	# ── Inventar-Panel (initial versteckt) ──
	panel = PanelContainer.new()
	panel.name = "InventoryPanel"
	panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.05, 0.05, 0.90)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)

	# Oben links unter dem Button
	panel.anchor_left   = 0.02
	panel.anchor_right  = 0.02
	panel.anchor_top    = 0.02
	panel.anchor_bottom = 0.02
	panel.offset_top    = 90
	panel.offset_right  = 260
	panel.offset_bottom = 90 + 300

	label = Label.new()
	label.text = "(Leer)"
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(label)
	parent.add_child(panel)

	# Button verbindet sich mit toggle()
	toggle_button.pressed.connect(toggle)


func update_text(text: String) -> void:
	label.text = text


func toggle() -> void:
	panel.visible = !panel.visible
