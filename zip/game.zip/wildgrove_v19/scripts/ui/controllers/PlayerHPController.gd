class_name PlayerHPController
extends Node

var _visuals: PlayerHPVisuals


func setup(visuals: PlayerHPVisuals) -> void:
	_visuals = visuals
	EventBus.player.player_respawned.connect(_on_respawned)
	# Auf HealthComponent des Players warten
	call_deferred("_connect_player_health")


func _connect_player_health() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: Node = players[0]
	var hc := player.find_child("HealthComponent", true, false) as HealthComponent
	if is_instance_valid(hc):
		hc.health_changed.connect(_on_health_changed)
		_visuals.update(hc.current_health, hc.max_health)


func _on_health_changed(current: int, maximum: int) -> void:
	_visuals.update(current, maximum)


func _on_respawned() -> void:
	_connect_player_health()
