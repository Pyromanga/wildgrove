class_name SkillPanelController
extends Node

var _visuals: SkillPanelVisuals


func setup(visuals: SkillPanelVisuals) -> void:
	_visuals = visuals
	EventBus.player.xp_gained.connect(_on_xp_gained)
	EventBus.player.level_up.connect(_on_level_up)
	_refresh_all()


func _refresh_all() -> void:
	if not is_instance_valid(Services.skill_system):
		return
	for skill_id in Services.skill_system.skills:
		_refresh_skill(skill_id)


func _refresh_skill(skill_id: String) -> void:
	if not is_instance_valid(Services.skill_system):
		return
	var ss := Services.skill_system
	var xp_needed := ss.get_xp_to_next_level(skill_id)
	_visuals.update_skill(skill_id, ss.get_level(skill_id), ss.get_xp(skill_id), xp_needed)


func _on_xp_gained(skill_id: String, _amount: int) -> void:
	_refresh_skill(skill_id)


func _on_level_up(skill_id: String, _new_level: int) -> void:
	_refresh_skill(skill_id)
