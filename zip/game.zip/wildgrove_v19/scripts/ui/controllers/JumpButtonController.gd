class_name JumpButtonController
extends Node

# FIX: Sprung-Velocity erhöht (6 → 9) damit der Sprung merklich ist.
# Gravity=12 → Sprungbogen ~0.84s Luft, ~3.4m Höhe.
const JUMP_VELOCITY: float = 9.0
const LOG_CAT := "JumpBtn"

var _visuals: JumpButtonVisuals


func setup(visuals: JumpButtonVisuals) -> void:
	_visuals = visuals
	_visuals.connect_pressed(_on_jump_pressed)


func _on_jump_pressed() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: CharacterBody3D = players[0] as CharacterBody3D
	if not is_instance_valid(player):
		return
	# physics_process muss aktiv sein (Spieler nicht tot)
	if not player.is_physics_processing():
		return
	# Nur springen wenn auf dem Boden
	if player.is_on_floor():
		player.velocity.y = JUMP_VELOCITY
		Logger.log_debug("Sprung ausgelöst (%.1f m/s)." % JUMP_VELOCITY, LOG_CAT)
	else:
		Logger.log_debug("Sprung ignoriert (nicht auf dem Boden).", LOG_CAT)
