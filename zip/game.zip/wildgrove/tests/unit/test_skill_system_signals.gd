# res://tests/unit/test_skill_system_signals.gd
extends GutTest

## Signal-Tests für SkillSystem (H-07 / EventBus-Injektion).
##
## Testet:
##   - xp_gained-Signal aus MockEventBus triggert request_add_xp (on_ready-Connection)
##   - level_up-Signal wird emittiert wenn Schwellenwert erreicht
##   - on_cleanup() trennt alle Connections
##   - Kein globales Signal-Bleeding zwischen zwei Instanzen

var _bus:  MockEventBus
var _svc:  SkillSystem
var _save: SaveSystem

func before_each() -> void:
	_bus  = MockEventBus.new()
	_save = _make_stub_save()
	_svc  = SkillSystem.new()
	_svc.configure(ServiceDeps.from_dict({
		ServiceKeys.SAVE_SYSTEM: _save,
		ServiceKeys.EVENT_BUS:   _bus,
	}))
	_svc.on_ready()

func after_each() -> void:
	_svc.on_cleanup()
	_svc  = null
	_bus  = null
	_save = null

# ─────────────────────────────────────────────────────────────────────────────
# on_ready Signal-Connections
# ─────────────────────────────────────────────────────────────────────────────

func test_on_ready_connects_xp_gained_to_request_add_xp() -> void:
	assert_true(
		_bus.player().xp_gained.is_connected(_svc.request_add_xp),
		"on_ready() muss xp_gained mit request_add_xp verbinden."
	)

func test_xp_gained_signal_triggers_xp_addition() -> void:
	## KERNTEST: Dieser Test war vor dem Refactor unmöglich.
	## xp_gained kommt vom MockEventBus — kein globaler AutoLoad nötig.
	_bus.player().emit_xp("woodcutting", 50)
	assert_eq(_svc.get_xp("woodcutting"), 50,
		"xp_gained-Signal muss XP über request_add_xp addieren.")

func test_xp_gained_signal_accumulates_multiple_events() -> void:
	_bus.player().emit_xp("woodcutting", 30)
	_bus.player().emit_xp("woodcutting", 20)
	assert_eq(_svc.get_xp("woodcutting"), 50,
		"Mehrere xp_gained-Signale müssen akkumulieren.")

func test_xp_gained_signal_routes_to_correct_skill() -> void:
	_bus.player().emit_xp("mining", 40)
	assert_eq(_svc.get_xp("mining"), 40,     "Mining muss 40 XP haben.")
	assert_eq(_svc.get_xp("woodcutting"), 0, "Woodcutting muss 0 XP haben.")

# ─────────────────────────────────────────────────────────────────────────────
# level_up Signal
# ─────────────────────────────────────────────────────────────────────────────

func test_level_up_signal_emitted_on_threshold() -> void:
	## SkillSystem verwendet Fallback: level * 100 XP für den nächsten Level.
	## Level 1 → Level 2 braucht 100 XP.
	watch_signals(_bus.player())
	_bus.player().emit_xp("woodcutting", 100)
	assert_signal_emitted(_bus.player(), "level_up",
		"level_up muss emittiert werden wenn XP-Schwellenwert erreicht.")

func test_level_up_signal_carries_skill_and_level() -> void:
	watch_signals(_bus.player())
	_bus.player().emit_xp("woodcutting", 100)
	assert_signal_emitted_with_parameters(
		_bus.player(), "level_up", ["woodcutting", 2]
	)

func test_no_level_up_below_threshold() -> void:
	watch_signals(_bus.player())
	_bus.player().emit_xp("woodcutting", 99)
	assert_signal_not_emitted(_bus.player(), "level_up",
		"level_up darf nicht emittiert werden unter dem XP-Schwellenwert.")

func test_multiple_level_ups_in_one_xp_burst() -> void:
	## 300 XP: Level 1→2 (100 XP), 2→3 (200 XP) — beide in einem Signal.
	watch_signals(_bus.player())
	_bus.player().emit_xp("woodcutting", 300)
	var count = get_signal_emit_count(_bus.player(), "level_up")
	assert_eq(count, 2,
		"300 XP sollten zwei level_up-Signale auslösen (Level 2 und Level 3).")

# ─────────────────────────────────────────────────────────────────────────────
# on_cleanup
# ─────────────────────────────────────────────────────────────────────────────

func test_on_cleanup_disconnects_xp_gained() -> void:
	_svc.on_cleanup()
	assert_false(
		_bus.player().xp_gained.is_connected(_svc.request_add_xp),
		"on_cleanup() muss xp_gained disconnecten."
	)

func test_xp_gained_after_cleanup_does_not_add_xp() -> void:
	_svc.on_cleanup()
	_bus.player().emit_xp("woodcutting", 50)
	# Nach cleanup ist Connection getrennt — XP kommt nicht an
	assert_eq(_svc.get_xp("woodcutting"), 0,
		"Nach on_cleanup() darf xp_gained keine XP mehr addieren.")

# ─────────────────────────────────────────────────────────────────────────────
# Kein Signal-Bleeding
# ─────────────────────────────────────────────────────────────────────────────

func test_two_instances_dont_share_xp_from_same_signal_source() -> void:
	var bus2  := MockEventBus.new()
	var svc2  := SkillSystem.new()
	svc2.configure(ServiceDeps.from_dict({
		ServiceKeys.SAVE_SYSTEM: _make_stub_save(),
		ServiceKeys.EVENT_BUS:   bus2,
	}))
	svc2.on_ready()

	# Nur _bus.player().emit_xp — nicht bus2
	_bus.player().emit_xp("woodcutting", 50)

	assert_eq(_svc.get_xp("woodcutting"), 50, "Instanz 1 muss XP haben.")
	assert_eq(svc2.get_xp("woodcutting"), 0,  "Instanz 2 darf keine XP haben (kein Bleeding).")

	svc2.on_cleanup()

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

func _make_stub_save() -> SaveSystem:
	var stub := SaveSystem.new()
	stub.configure(ServiceDeps.from_dict({ServiceKeys.EVENT_BUS: MockEventBus.new()}))
	return stub
