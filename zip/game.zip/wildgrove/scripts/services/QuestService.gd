extends ServiceNode
class_name QuestService

## QuestService — Verwaltet den Fortschritt aller Quests.
##
## Abhängigkeiten (deps): ["data", "savesystem"]
##
## ARCHITEKTUR:
##   - QuestService hält KEINE Referenz auf InventorySystem oder SkillSystem
##   - Lauscht stattdessen auf EventBus.world.loot_collected und EventBus.player.xp_gained
##   - Das entkoppelt Quest-Fortschritt von konkreten Service-Implementierungen
##
## _data_service VERWENDUNG (STUB AUFGELÖST Session 3):
##   DataService wird genutzt um QuestDefinitionen zu laden wenn sie in
##   res://data/quests/ als .tres Ressourcen existieren. Das Interface ist vorbereitet
##   aber noch kein konkreter Pfad-Scan implementiert (QuestDefinition-Dateien fehlen noch).
##   Für jetzt: Logging dass der Service bereit ist, aber keine Quest-Definitionen gefunden.
##
## QUEST-OBJECTIVE-TYPEN (geplant):
##   COLLECT  → _check_collect_objective() — triggered by loot_collected
##   SKILL    → _check_skill_objective()   — triggered by xp_gained
##   INTERACT → _check_interact_objective() — triggered by interaction_finished
##   KILL     → _check_kill_objective()    — triggered by future combat events
##   TALK     → _check_talk_objective()    — triggered by future dialogue events

const LOG_CAT := "Quest"
const SAVE_KEY := "quest_progress"
const QUEST_DATA_PATH := "res://data/quests/"

var _data_service: DataService
var _save_system: SaveSystem

## Aktive Quests: { quest_id: { "status": "started", "objectives": { obj_id: current } } }
var active_quests: Dictionary = {}
## Abgeschlossene Quest-IDs
var completed_quests: Array[String] = []
## Freigeschaltete aber noch nicht gestartete Quests
var available_quests: Array[String] = []


# ─────────────────────────────────────────────
# Phase 4: Configure (Injection)
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	var t := Logger.log_begin("QuestService.configure()", LOG_CAT)

	_data_service = deps.get("data") as DataService
	_save_system = deps.get("savesystem") as SaveSystem

	if not is_instance_valid(_data_service):
		Logger.log_warn("DataService fehlt — Quest-Definitionen können nicht geladen werden.", LOG_CAT)
	if not is_instance_valid(_save_system):
		Logger.log_warn("SaveSystem fehlt — Quest-Fortschritt wird nicht gespeichert.", LOG_CAT)
	else:
		_save_system.register_save_provider(self)
		var saved: Dictionary = _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_restore_from_save(saved)

	Logger.log_end("QuestService.configure()", t, LOG_CAT)
	Logger.log_info(
		"Konfiguriert. Aktive Quests: %d, Abgeschlossen: %d."
		% [active_quests.size(), completed_quests.size()],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────


func on_ready() -> void:
	EventBus.world.loot_collected.connect(_on_loot_collected)
	EventBus.player.xp_gained.connect(_on_xp_gained)
	EventBus.world.interaction_finished.connect(_on_interaction_finished)

	# Quest-Definitionen aus DataService laden (vorbereitet, noch keine .tres vorhanden)
	_load_quest_definitions()

	Logger.log_info("QuestService aktiv. EventBus-Connections aufgebaut.", LOG_CAT)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────


func get_save_key() -> String:
	return SAVE_KEY


func get_save_data() -> Dictionary:
	return {
		"active": active_quests.duplicate(true),
		"completed": completed_quests.duplicate(),
		"available": available_quests.duplicate(),
	}


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


func start_quest(quest_id: String) -> bool:
	if quest_id.is_empty():
		Logger.log_error("start_quest(): quest_id ist leer!", LOG_CAT)
		return false

	if completed_quests.has(quest_id):
		Logger.log_debug("Quest '%s' bereits abgeschlossen." % quest_id, LOG_CAT)
		return false

	if active_quests.has(quest_id):
		Logger.log_debug("Quest '%s' ist bereits aktiv." % quest_id, LOG_CAT)
		return false

	active_quests[quest_id] = {"status": "started", "objectives": {}}
	available_quests.erase(quest_id)

	EventBus.quest.emit_quest_started(quest_id)
	Logger.log_info("Quest gestartet: '%s'." % quest_id, LOG_CAT)
	return true


func complete_quest(quest_id: String) -> void:
	if not active_quests.has(quest_id):
		Logger.log_warn(
			"complete_quest('%s'): Quest nicht aktiv — kann nicht abschließen." % quest_id, LOG_CAT
		)
		return

	active_quests.erase(quest_id)
	completed_quests.append(quest_id)

	# Zukünftig: Reward aus QuestDefinition holen und ausgeben
	# var def := _get_quest_definition(quest_id)
	# if def and def.reward: _distribute_reward(def.reward)
	var reward: QuestReward = null  # Placeholder bis Quest-Definitionen existieren

	EventBus.quest.emit_quest_completed(quest_id, reward)
	Logger.log_info("Quest abgeschlossen: '%s'." % quest_id, LOG_CAT)


func fail_quest(quest_id: String) -> void:
	if not active_quests.has(quest_id):
		Logger.log_warn("fail_quest('%s'): Quest nicht aktiv." % quest_id, LOG_CAT)
		return

	active_quests.erase(quest_id)
	EventBus.quest.emit_quest_failed(quest_id)
	Logger.log_warn("Quest fehlgeschlagen: '%s'." % quest_id, LOG_CAT)


func unlock_quest(quest_id: String) -> void:
	if completed_quests.has(quest_id) or active_quests.has(quest_id):
		return
	if not available_quests.has(quest_id):
		available_quests.append(quest_id)
		EventBus.quest.emit_quest_unlocked(quest_id)
		Logger.log_info("Quest freigeschalten: '%s'." % quest_id, LOG_CAT)


func update_objective(quest_id: String, objective_id: String, delta: int) -> void:
	if not active_quests.has(quest_id):
		return

	var objectives: Dictionary = active_quests[quest_id]["objectives"]
	var current: int = objectives.get(objective_id, 0)
	objectives[objective_id] = current + delta

	Logger.log_debug(
		"Objective '%s/%s': %d (+%d)." % [quest_id, objective_id, objectives[objective_id], delta],
		LOG_CAT
	)


func is_quest_active(quest_id: String) -> bool:
	return active_quests.has(quest_id)


func is_quest_completed(quest_id: String) -> bool:
	return completed_quests.has(quest_id)


func get_objective_progress(quest_id: String, objective_id: String) -> int:
	if not active_quests.has(quest_id):
		return 0
	return active_quests[quest_id]["objectives"].get(objective_id, 0)


# ─────────────────────────────────────────────
# Event-Handler (für Objective-Fortschritt)
# ─────────────────────────────────────────────


func _on_loot_collected(item_id: String, quantity: int) -> void:
	Logger.log_trace(
		"Loot: %dx '%s' — prüfe COLLECT-Objectives." % [quantity, item_id], {}, LOG_CAT
	)
	## STUB: Quest-Objectives vom Typ COLLECT prüfen.
	## Wenn QuestDefinition-Ressourcen existieren:
	##   for quest_id in active_quests:
	##       var def := _get_quest_definition(quest_id)
	##       for obj in def.objectives:
	##           if obj.type == QuestObjective.Type.COLLECT and obj.target_id == item_id:
	##               update_objective(quest_id, obj.id, quantity)
	##               _check_quest_completion(quest_id, def)


func _on_xp_gained(skill_name: String, amount: int) -> void:
	Logger.log_trace(
		"XP: +%d in '%s' — prüfe SKILL-Objectives." % [amount, skill_name], {}, LOG_CAT
	)
	## STUB: Quest-Objectives vom Typ SKILL prüfen.
	## Zukünftig: Wenn SkillSystem.get_level(skill_name) >= obj.required → complete objective


func _on_interaction_finished(label: String) -> void:
	Logger.log_trace(
		"Interaktion beendet: '%s' — prüfe INTERACT-Objectives." % label, {}, LOG_CAT
	)
	## STUB: Quest-Objectives vom Typ INTERACT prüfen.
	## Zukünftig: Interactable-ID matchen mit Objective.target_id


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _load_quest_definitions() -> void:
	## Lädt QuestDefinition-Ressourcen aus res://data/quests/.
	## DataService ist der korrekte Ort für statische Ressourcen — aber Quest-Definitionen
	## sind noch nicht im DataService integriert (DataService lädt nur PlayerData).
	##
	## STUB: Wenn data/quests/*.tres existieren, hier scannen und in einem Dictionary halten.
	## Für jetzt: Logging ob das Verzeichnis existiert.

	if not is_instance_valid(_data_service):
		Logger.log_warn("DataService fehlt — kann Quest-Definitionen nicht laden.", LOG_CAT)
		return

	if DirAccess.dir_exists_absolute(QUEST_DATA_PATH):
		Logger.log_debug(
			"Quest-Daten-Pfad vorhanden: '%s'. Quest-Definitionen noch nicht implementiert." % QUEST_DATA_PATH,
			LOG_CAT
		)
	else:
		Logger.log_debug(
			"Quest-Daten-Pfad '%s' existiert nicht — keine Quests geladen." % QUEST_DATA_PATH,
			LOG_CAT
		)


func _restore_from_save(saved_data: Dictionary) -> void:
	active_quests = saved_data.get("active", {})
	completed_quests = saved_data.get("completed", [])
	available_quests = saved_data.get("available", [])
	Logger.log_info(
		"Quest-State geladen: aktiv=%d, abgeschlossen=%d, verfügbar=%d."
		% [active_quests.size(), completed_quests.size(), available_quests.size()],
		LOG_CAT
	)
