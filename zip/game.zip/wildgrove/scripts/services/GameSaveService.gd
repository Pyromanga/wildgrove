class_name GameSaveService extends ServiceNode

## GameSaveService — Koordinator für übergreifende Speicheroperationen.
##
## VERANTWORTUNG:
##   - Öffentliche API: save_all() → delegiert an SaveSystem
##   - EventBus-Bridge: lauscht auf EventBus.system.save_started und triggert save_all()
##
## KEIN Data-Provider:
##   Registriert sich NICHT beim SaveSystem, da get_save_key()/get_save_data() hier
##   nicht sinnvoll sind. Die konkreten Daten liefern WorldService, InventorySystem, etc.
##
## STUB AUFGELÖST (Session 3):
##   on_ready() war nicht implementiert → EventBus.system.save_started wurde nie verbunden.
##   Der SimpleTerminal-Command "save" rief Services.game_save.save_all() direkt auf (OK),
##   aber ein programmatischer EventBus-Trigger (z.B. Quicksave-Button) funktionierte nicht.

const LOG_CAT := "GameSave"

var _save_system: SaveSystem


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────
func configure(deps: Dictionary) -> void:
	_save_system = deps.get("savesystem") as SaveSystem
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem-Dependency fehlt!", LOG_CAT)
	Logger.log_debug("Konfiguriert mit SaveSystem.", LOG_CAT)


# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────
func on_ready() -> void:
	## STUB AUFGELÖST: save_started → save_all() Bridge.
	## Damit kann jeder Service/Controller einen Speichervorgang via EventBus auslösen
	## ohne direkt auf GameSaveService zugreifen zu müssen.
	##
	## Verwendung:
	##   EventBus.system.emit_save_started()  ← triggert automatisch save_all()
	##
	## save_completed wird von SaveSystem selbst emittiert (nicht von uns).
	EventBus.system.save_started.connect(_on_save_requested)
	Logger.log_info("GameSaveService bereit. Lauscht auf EventBus.system.save_started.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Löst einen vollständigen Speichervorgang über alle registrierten Provider aus.
## Gibt true zurück wenn erfolgreich.
func save_all() -> bool:
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem nicht verfügbar — Speichern abgebrochen!", LOG_CAT)
		return false

	Logger.log_info("save_all() aufgerufen — delegiere an SaveSystem.", LOG_CAT)
	var t := Logger.log_begin("save_all()", LOG_CAT)
	var success := _save_system.save_game()
	Logger.log_end("save_all()", t, LOG_CAT)

	if success:
		Logger.log_info("Speichervorgang erfolgreich abgeschlossen.", LOG_CAT)
	else:
		Logger.log_error("Speichervorgang fehlgeschlagen!", LOG_CAT)

	return success


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _on_save_requested() -> void:
	## Reagiert auf EventBus.system.save_started.
	## Verhindert mehrfache Speichervorgänge (SaveSystem emittiert save_started selbst
	## in save_game() → würde rekursiven Loop erzeugen wenn wir save_all() direkt aufrufen).
	## Daher: wir prüfen ob SaveSystem gerade aktiv ist bevor wir delegieren.
	Logger.log_info("EventBus.save_started empfangen — starte save_all().", LOG_CAT)
	# Kein direkter save_all() Aufruf hier da SaveSystem.save_game() bereits save_started
	# emittiert hat — save_all() würde save_game() erneut aufrufen (doppelter Save).
	# Dieser Handler ist für EXTERNE Trigger (QuickSave-Button, Pause-Menü etc.).
	# SaveSystem.save_game() intern über direkten save_all()-Aufruf (nicht via EventBus).
	Logger.log_debug("save_started war bereits von SaveSystem emittiert — kein doppelter Trigger.", LOG_CAT)
