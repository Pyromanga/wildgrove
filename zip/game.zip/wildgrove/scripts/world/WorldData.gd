class_name WorldData
extends RefCounted

## WorldData — Reines Daten-Objekt für den Weltzustand.
##
## KEIN Node-Overhead — extends RefCounted (kein SceneTree nötig).
## Enthält nur Positionsdaten und Harvest-State.
## WorldService ist die einzige Stelle die WorldData erzeugt und befüllt.

var tree_positions: Array[Vector3] = []
var ore_positions: Array[Vector3] = []
var player_position: Vector3 = Vector3.ZERO
## Geerntete Objekte: { "tree_<pos>": true, "ore_<pos>": true }
var harvested_objects: Dictionary = {}


func add_tree(pos: Vector3) -> void:
	if not pos in tree_positions:
		tree_positions.append(pos)


func add_ore(pos: Vector3) -> void:
	if not pos in ore_positions:
		ore_positions.append(pos)


func mark_harvested(key: String) -> void:
	harvested_objects[key] = true
	Logger.log_debug("Als geerntet markiert: '%s'." % key, "WorldData")


func mark_tree_harvested(pos: Vector3) -> void:
	mark_harvested("tree_" + str(pos))


func mark_ore_harvested(pos: Vector3) -> void:
	mark_harvested("ore_" + str(pos))


func is_harvested(key: String) -> bool:
	return harvested_objects.has(key)


func get_tree_count() -> int:
	return tree_positions.size()


func get_ore_count() -> int:
	return ore_positions.size()
