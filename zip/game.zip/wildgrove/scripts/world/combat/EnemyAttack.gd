class_name EnemyAttack
extends RefCounted

## EnemyAttack — Interaktions-Setup für EnemyNPC.
##
## VERANTWORTUNG:
##   setup_interactable() → baut InteractableData + InteractableComponent

const LOG_CAT := "EnemyAttack"

static func setup_interactable(parent: Node3D) -> void:
	var d := InteractableData.new()
	d.id           = "attack_enemy"
	d.label        = "Angreifen"
	d.duration     = 0.7
	d.xp_type      = "combat"
	d.xp_amount    = 5
	d.drops        = {}
	d.inspect_text = "Ein Goblin. Feindselig und gefährlich."
	var comp := InteractableComponent.new()
	comp.name = "AttackInteractable"
	comp.data = d
	parent.add_child(comp)
	# BUG-FIX: InteractableComponent._handle_completion() wurde von einem
	# direkten parent._on_interacted()-Aufruf auf das 'interacted'-Signal
	# umgestellt (siehe AnimalBase/HarvestableEntity) — hier fehlte der
	# entsprechende .connect(). Dadurch lief die Angriffs-Interaktion optisch
	# durch (XP, Popup), aber EnemyNPC._on_interacted() — und damit der
	# eigentliche Schaden — wurde nie ausgelöst.
	if parent.has_method("_on_interacted"):
		comp.interacted.connect(parent._on_interacted)
