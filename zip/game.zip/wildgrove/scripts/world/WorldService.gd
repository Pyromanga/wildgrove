extends ServiceNode
# justified: add_child(_entity_orchestrator); queue_free(ChunkManager); on_world_scene_ready(Node3D).
class_name WorldService

## WorldService — Lifecycle + öffentliche API für die Spielwelt.
##
## Delegiert Verantwortlichkeiten an spezialisierte Klassen:
##   WorldSpawner          → Entities, Tiere, Wasser, Pets, Chunks spawnen
##   WorldSaveHandler      → Save/Restore-Logik (v28)
##   WorldEntityRegistry   → Entity-Definitionen registrieren (v28)
##   WorldTimeService      → Tageszeit verwalten
##   WorldFactory          → statische Geometrie erstellen
##   EntityOrchestrator    → Entity-Pooling + UUID-Verwaltung
##
## Abhängigkeiten: ["savesystem", "world_gen"]

const LOG_CAT := "World"
const SAVE_KEY := "world_state"

var data:     WorldData
var factory:  WorldFactory
var factory3d: Factory3D

var _save_system:    SaveSystem
var _world_gen:      WorldGenerationService
var _ticker:         ServiceTicker = null
var _respawn:        RespawnService = null
var _game_manager:   GameManager   = null
var _session_manager: SessionManager = null
var _entity_orchestrator: EntityOrchestrator
var _spawner:  WorldSpawner
var _time:     WorldTimeService
var _save_handler: WorldSaveHandler
var _chunk_manager: ChunkManager  # Stored so on_cleanup() can shut it down properly
var _bus:           IEventBus

## Werden in configure() aufgelöst und per set_entity_services() an EntityOrchestrator weitergereicht.
var _ent_skill:     SkillSystem         = null
var _ent_inventory: InventorySystem     = null
var _ent_stat_mod:  StatModifierService = null
var _ent_combat:    CombatSystem        = null
var _ent_equipment: EquipmentService    = null
var _ent_interact:  InteractionExecutor = null
var _ent_player_states: PlayerStateService = null
var _ent_data:      DataService         = null

## Computed properties — always current, never one tick stale.
var day_time: float:
	get: return _time.day_time if is_instance_valid(_time) else 0.0
var day_count: int:
	get: return _time.day_count if is_instance_valid(_time) else 0

# ─────────────────────────────────────────────
# Service-Lifecycle
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	_save_system     = deps.get_optional(ServiceKeys.SAVE_SYSTEM)    as SaveSystem
	_world_gen       = deps.get_optional(ServiceKeys.WORLD_GEN)      as WorldGenerationService
	_ticker          = deps.get_optional(ServiceKeys.TICKER)         as ServiceTicker
	_respawn         = deps.get_optional(ServiceKeys.RESPAWN)        as RespawnService
	_game_manager    = deps.get_optional(ServiceKeys.GAME_MANAGER)   as GameManager
	_session_manager = deps.get_optional(ServiceKeys.SESSION_MANAGER) as SessionManager
	# BUG-24: war fälschlich .require() — als einzige der ~15 Deps hier,
	# im Widerspruch zum dokumentierten Vertrag oben ("configure() ohne
	# optionale Deps → kein Crash, null-Guards greifen") und zu
	# test_configure_without_deps_does_not_crash(). Alle Nutzungsstellen
	# unten sind bereits (oder werden hiermit) null-safe gemacht.
	_bus             = deps.get_optional(ServiceKeys.EVENT_BUS)      as IEventBus

	_ent_skill          = deps.get_optional(ServiceKeys.SKILL_SYSTEM)         as SkillSystem
	_ent_inventory      = deps.get_optional(ServiceKeys.INVENTORY)             as InventorySystem
	_ent_stat_mod       = deps.get_optional(ServiceKeys.STAT_MODIFIERS)        as StatModifierService
	_ent_combat         = deps.get_optional(ServiceKeys.COMBAT)                as CombatSystem
	_ent_equipment      = deps.get_optional(ServiceKeys.EQUIPMENT)             as EquipmentService
	_ent_interact       = deps.get_optional(ServiceKeys.INTERACTION)  as InteractionExecutor
	_ent_player_states  = deps.get_optional(ServiceKeys.PLAYER_STATES)         as PlayerStateService
	_ent_data           = deps.get_optional(ServiceKeys.DATA)                  as DataService

	data      = WorldData.new()
	factory   = WorldFactory.new()
	factory3d = Factory3D.new()
	_time     = WorldTimeService.new()
	_time.set_event_bus(_bus)

	_entity_orchestrator      = EntityOrchestrator.new()
	_entity_orchestrator.name = "EntityOrchestrator"
	add_child(_entity_orchestrator)
	_entity_orchestrator.set_event_bus(_bus)
	WorldEntityRegistry.register_all(_entity_orchestrator)
	# factory3d stammt aus WorldService selbst (World-intern, kein dep nötig).
	# respawn, player_states, data (DataService) kommen aus den oben aufgelösten Deps.
	_entity_orchestrator.set_entity_services(
		_ent_skill, _ent_inventory, factory3d,
		_respawn, _ent_data, _ent_stat_mod,
		_ent_combat, _ent_equipment, self,
		_ent_interact, _ent_player_states
	)
	# NAHT-FIX: world_seed vor create_world() setzen damit WorldFactory
	# und ChunkManager denselben Noise-Seed verwenden → nahtlose Chunk-Grenzen.
	var seed_for_factory: int = data.world_seed if data.world_seed != 0 		else int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	if data.world_seed == 0:
		data.world_seed = seed_for_factory
	factory.world_seed = seed_for_factory

	_save_handler = WorldSaveHandler.new(data, _time)

	if is_instance_valid(_save_system):
		_save_system.register_save_provider(self)
		var saved := _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_save_handler.restore_world(saved)
			# day_time and day_count are now computed properties — no copy needed

	if not is_instance_valid(_world_gen):
		AppLogger.log_warn("WorldGenerationService fehlt.", LOG_CAT)

	AppLogger.log_info("WorldService konfiguriert.", LOG_CAT)

func on_ready() -> void:
	if is_instance_valid(_ticker):
		_ticker.register_service(self)

	if is_instance_valid(_bus):
		_bus.world().entity_despawn_requested.connect(_on_entity_despawn_requested)
		_bus.system().save_pre_flush.connect(_on_save_pre_flush)
	else:
		AppLogger.log_warn("EventBus fehlt — Despawn-/Save-Flush-Signale nicht verbunden.", LOG_CAT)

	# G-03: SessionManager.peer_cleanup_requested → ChunkManager-Tracking bereinigen.
	if is_instance_valid(_session_manager):
		_session_manager.peer_cleanup_requested.connect(_on_peer_cleanup_requested)

	var respawn := _respawn
	if is_instance_valid(respawn):
		# Bäume — aufsteigend nach Fäll-Schwierigkeit / XP
		respawn.register_config("willow_tree", 180.0)  # 3 min — schnell (15 XP)
		respawn.register_config("oak_tree",    300.0)  # 5 min — standard (25 XP)
		respawn.register_config("maple_tree",  480.0)  # 8 min — langsam (60 XP)
		# Erze — aufsteigend nach Mining-Level
		respawn.register_config("copper_ore",  420.0)  # 7 min — Einsteiger (20 XP)
		respawn.register_config("iron_ore",    600.0)  # 10 min — fortgeschritten (40 XP)
		respawn.set_spawn_callback(func(t: String, p: Vector3, pid: int = 1) -> Node3D: return spawn_entity(t, p, {}, pid))
		respawn.set_remove_callback(func(t: String, p: Vector3) -> void: data.unmark_harvested(t, p))

	AppLogger.log_info("WorldService bereit.", LOG_CAT)

## Warms up the MeshCache inside factory3d.
## Called by ServiceOrchestrator Phase S8.8 — encapsulates factory3d internals
## so the orchestrator never touches WorldService fields directly.
func warmup_mesh_cache() -> void:
	if not is_instance_valid(factory3d):
		AppLogger.log_warn("warmup_mesh_cache: factory3d nicht verfügbar — übersprungen.", LOG_CAT)
		return
	if factory3d.cache == null:
		factory3d.cache = MeshCache.new()
	factory3d.cache.build()
	AppLogger.log_info("MeshCache gebaut.", LOG_CAT)

func on_cleanup() -> void:
	if is_instance_valid(_bus) and _bus.system().save_pre_flush.is_connected(_on_save_pre_flush):
		_bus.system().save_pre_flush.disconnect(_on_save_pre_flush)
	# G-03: Peer-Cleanup-Signal trennen.
	if is_instance_valid(_session_manager) \
			and _session_manager.peer_cleanup_requested.is_connected(_on_peer_cleanup_requested):
		_session_manager.peer_cleanup_requested.disconnect(_on_peer_cleanup_requested)
	if is_instance_valid(_chunk_manager):
		_chunk_manager.queue_free()
		_chunk_manager = null
	if is_instance_valid(_entity_orchestrator) and _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()

func on_tick(delta: float) -> void:
	if is_instance_valid(_game_manager) and _game_manager.is_playing():
		_time.tick(delta)
		# day_time / day_count are computed properties — no copy needed

# ─────────────────────────────────────────────
# Welt-Initialisierung
# ─────────────────────────────────────────────

func on_world_scene_ready(world_root: Node3D) -> void:
	var t := AppLogger.log_begin("on_world_scene_ready()", LOG_CAT)

	if _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()
		if is_instance_valid(_bus):
			_bus.world().emit_world_scene_unloaded()

	# Statische Geometrie
	var generated := factory.create_world()
	for child in generated.get_children():
		generated.remove_child(child)
		world_root.add_child(child)
	generated.queue_free()

	# Terrain-Höhen-Callback: wird jetzt direkt an generate_world()/generate_world_async()
	# übergeben — kein persistentes set_height_callback() mehr (Architekturplan 1.5).

	_entity_orchestrator.initialize(world_root)

	# ChunkManager: stored on the service so on_cleanup() can shut it down properly.
	# Deterministic seed: read from WorldData so every session, server and client
	# generate the same world. Set once at world creation, never from the clock.
	if is_instance_valid(_chunk_manager):
		_chunk_manager.queue_free()
	_chunk_manager = ChunkManager.new()
	_chunk_manager.name = "ChunkManager"
	world_root.add_child(_chunk_manager)
	var seed_val: int = data.world_seed if data.world_seed != 0 \
		else int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	if data.world_seed == 0:
		data.world_seed = seed_val
		AppLogger.log_warn(
			"world_seed war 0 — neuer Seed generiert: %d. Für deterministische Welten in WorldData setzen." % seed_val,
			LOG_CAT
		)
	_chunk_manager.initialize(world_root, seed_val, func(type_id: String, pos: Vector3, pid: int = 1) -> Node3D: return spawn_entity(type_id, pos, {}, pid))

	# BUG-FIX: ChunkManager wurde nie beim ServiceTicker registriert und
	# WorldService.on_tick() ruft _chunk_manager.on_tick() auch nicht auf —
	# _sync_chunks() lief dadurch NIE, außer dem Spawn-Chunk wurde kein
	# einziger Chunk je geladen (auch keine Chunk-Bäume/-Tiere).
	if is_instance_valid(_ticker):
		_ticker.register_service(_chunk_manager)

	# WorldSpawner mit aktuellen Referenzen neu erstellen
	_spawner = WorldSpawner.new(
		_entity_orchestrator,
		factory.terrain_generator,
		_world_gen,
		data
	)
	var local_peer: int = _session_manager.get_local_peer_id() \
		if is_instance_valid(_session_manager) else 1

	# F-1: MultiplayerSpawner — repliziert vom Server gespawnte Entities an alle Clients.
	# Muss vor spawn_all() eingerichtet sein damit der Spawner bereits aktiv ist wenn
	# die ersten Entities hinzugefügt werden.
	# Nur auf Server aufsetzen — Clients empfangen Spawn-Events automatisch.
	if is_instance_valid(_session_manager) and _session_manager.is_server() \
			and _session_manager.has_active_peer():
		_setup_multiplayer_spawner(world_root)

	_spawner.spawn_all(world_root, local_peer)

	if is_instance_valid(_bus):
		_bus.world().emit_world_scene_ready(world_root)

	AppLogger.log_end("on_world_scene_ready()", t, LOG_CAT)
	AppLogger.log_info("Welt bereit. Entities: %d." % _entity_orchestrator.get_entity_count(), LOG_CAT)

# ─────────────────────────────────────────────
# Multiplayer (Sprint E)
# ─────────────────────────────────────────────

## F-1: Richtet einen MultiplayerSpawner für die Spielwelt ein.
## Läuft nur auf dem Server (Host/Tier 2-3) vor spawn_all().
##
## Verwendet spawn_function/despawn_function statt add_spawnable_scene(),
## weil das Projekt GDScript.new()-basiertes Instanziieren nutzt (keine .tscn-Wrapper).
## add_spawnable_scene() akzeptiert nur .tscn-Pfade und würde zur Laufzeit fehlschlagen.
##
## Godot ruft spawn_function(data) auf dem Client auf wenn der Server einen Node
## unter spawn_path hinzufügt. data ist ein frei wählbarer Variant — wir übergeben
## den registrierten script_path als String, der via path_map zu type_id aufgelöst wird.
func _setup_multiplayer_spawner(world_root: Node3D) -> void:
	var ms := MultiplayerSpawner.new()
	ms.name = "WorldMultiplayerSpawner"
	ms.spawn_path = NodePath("..")   # world_root selbst ist Spawn-Root

	# Path → TypeId-Map aus der EntityRegistry aufbauen.
	# Ermöglicht spawn_function() den richtigen type_id zu ermitteln
	# ohne den EntityOrchestrator direkt in der Closure zu referenzieren.
	var path_map: Dictionary = _entity_orchestrator.get_registry().get_path_to_type_map()
	var registry_ref := _entity_orchestrator.get_registry()  # Closure-Capture

	ms.spawn_function = func(data: Variant) -> Node:
		# data ist der script_path-String (vom Server beim Spawn übermittelt).
		var type_id: String = path_map.get(str(data), "")
		if type_id.is_empty():
			AppLogger.log_error(
				"MultiplayerSpawner.spawn_function: Unbekannter Pfad '%s'." % str(data),
				LOG_CAT
			)
			return null
		# Nur instanziieren — kein add_child, kein on_spawn, kein UUID-Tracking.
		# Der MultiplayerSpawner übernimmt add_child in world_root selbst.
		# State-Sync läuft via MultiplayerSynchronizer (Sprint E).
		return registry_ref.instantiate(type_id)

	ms.despawn_function = func(node: Node) -> void:
		# Client-seitig reicht queue_free — keine UUID-Buchführung nötig,
		# der Server hält den autoritativen Entity-Zustand.
		if is_instance_valid(node):
			node.queue_free()

	world_root.add_child(ms)
	AppLogger.log_info(
		"MultiplayerSpawner eingerichtet (%d Typen, Custom Spawn/Despawn)." % path_map.size(),
		LOG_CAT
	)

# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func get_save_key() -> String:
	return SAVE_KEY

func get_save_data() -> Dictionary:
	return _save_handler.get_save_data()

# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

func get_formatted_time() -> String:
	return _time.get_formatted_time()

## peer_id: Multiplayer-Autorität des gespawnten Nodes.
## Default 1 = Server-Autorität (Bäume, Erze, Gegner, Tiere).
## Für Player-Respawn die echte peer_id des Clients übergeben.
func spawn_entity(type_id: String, position: Vector3, config: Dictionary = {}, peer_id: int = 1) -> Node3D:
	if not is_instance_valid(_entity_orchestrator):
		return null
	var entity := _entity_orchestrator.spawn_entity(type_id, position, config, peer_id)
	# G-02: Player-Nodes beim ChunkManager registrieren damit alle Spieler Chunks laden.
	if is_instance_valid(entity) and type_id == "player" and is_instance_valid(_chunk_manager):
		_chunk_manager.add_player(entity)
	return entity

func despawn_entity(uuid: String) -> void:
	if not is_instance_valid(_entity_orchestrator):
		return
	# G-02: Player-Node aus Chunk-Tracking entfernen bevor er despawnt wird.
	if is_instance_valid(_chunk_manager):
		var entity := _entity_orchestrator.get_entity(uuid)
		if is_instance_valid(entity) and entity.is_in_group("player"):
			_chunk_manager.remove_player(entity)
	_entity_orchestrator.despawn_entity(uuid)

func get_entity_debug_info() -> Dictionary:
	if not is_instance_valid(_entity_orchestrator):
		return {}
	return _entity_orchestrator.get_debug_info()

func _on_entity_despawn_requested(uuid: String) -> void:
	despawn_entity(uuid)

## G-03: Wird von SessionManager.peer_cleanup_requested ausgelöst wenn ein Peer die Verbindung trennt.
## Entfernt alle Player-Nodes dieses Peers aus dem ChunkManager-Tracking.
## Der eigentliche Node-Despawn läuft separat über EntityOrchestrator (uuid-basiert).
func _on_peer_cleanup_requested(peer_id: int) -> void:
	if not is_instance_valid(_chunk_manager):
		return
	if not is_instance_valid(_entity_orchestrator):
		return
	# Alle Player-Nodes mit dieser multiplayer_authority aus dem Tracking entfernen.
	var player_nodes := _entity_orchestrator.get_entities_in_group("player")
	for player in player_nodes:
		if is_instance_valid(player) and player.get_multiplayer_authority() == peer_id:
			_chunk_manager.remove_player(player)
			AppLogger.log_info(
				"Peer %d: Player-Node aus Chunk-Tracking entfernt." % peer_id, LOG_CAT
			)

## Pre-Flush-Handler: Sichert Pet-Daten bevor SaveSystem auf Disk schreibt.
## Wird über EventBus.system.save_pre_flush ausgelöst (nicht direkt von GameSaveService).
func _on_save_pre_flush() -> void:
	collect_and_store_pet_data()

# ─────────────────────────────────────────────
# Öffentliche API — WorldData-Delegation
# Externe Aufrufer nutzen diese Wrapper statt direktem Datenzugriff.
# ─────────────────────────────────────────────

## Generischer Harvest-Marker für alle HarvestableEntity-Subklassen.
## type_id = EntityRegistry-Key (z.B. "oak_tree", "iron_ore", "copper_ore").
## Delegiert auf WorldData.make_key() → einheitliches Schema an allen drei
## Stellen: mark / unmark / is_harvested_by_type.
func mark_harvested(type_id: String, pos: Vector3) -> void:
	data.mark_harvested(WorldData.make_key(type_id, pos))

## Abwärtskompatible Wrapper — bleiben für externe Aufrufer erhalten.
func mark_tree_harvested(pos: Vector3) -> void:
	data.mark_tree_harvested(pos)

## Abwärtskompatibel.
func mark_ore_harvested(pos: Vector3) -> void:
	data.mark_ore_harvested(pos)

## Speichert Pet-Zustand vor dem Abspeichern.
func store_pet_save_data(pet_data: Array[Dictionary]) -> void:
	data.set_meta("saved_pets", pet_data)

## Scannt alle aktiven Pets und sichert deren Zustand via store_pet_save_data().
## Aufgerufen von _on_save_pre_flush() — nicht mehr direkt von GameSaveService.
func collect_and_store_pet_data() -> void:
	var pet_data: Array[Dictionary] = []
	for pet in get_tree().get_nodes_in_group("pets"):
		if pet is PetComponent:
			pet_data.append(pet.get_save_state())
	store_pet_save_data(pet_data)
	AppLogger.log_debug("Pets gesammelt und gespeichert: %d" % pet_data.size(), LOG_CAT)
