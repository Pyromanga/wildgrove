class_name WorldSpawner
extends RefCounted

## WorldSpawner — Entity-Spawning für die Spielwelt.
##
## Verantwortlich für:
##   - Bäume, Erze, Tiere, Quest-NPC, Goblins spawnen
##   - Pets wiederherstellen
##   - WaterBodies platzieren
##   - ChunkManager starten
##
## Kein Service — wird von WorldService als Hilfsklasse instanziiert.
## Bekommt alle nötigen Referenzen im Konstruktor.

const LOG_CAT := "WorldSpawner"

var _entity_orchestrator: EntityOrchestrator
var _terrain_generator: TerrainGenerator
var _world_gen: WorldGenerationService
var _data: WorldData


func _init(
	orchestrator: EntityOrchestrator,
	terrain_gen: TerrainGenerator,
	world_gen: WorldGenerationService,
	world_data: WorldData
) -> void:
	_entity_orchestrator = orchestrator
	_terrain_generator   = terrain_gen
	_world_gen           = world_gen
	_data                = world_data


## Haupt-Entry-Point: spawnt alles für eine frische Welt-Session.
func spawn_all(world_root: Node3D) -> void:
	var t := Logger.log_begin("WorldSpawner.spawn_all()", LOG_CAT)

	var tree_positions: Array[Vector3] = _data.tree_positions
	var ore_positions:  Array[Vector3] = _data.ore_positions

	if tree_positions.is_empty() and ore_positions.is_empty():
		_generate_positions()
		tree_positions = _data.tree_positions
		ore_positions  = _data.ore_positions

	var trees_spawned := 0
	for pos in tree_positions:
		if not _data.is_tree_harvested(pos):
			_entity_orchestrator.spawn_entity("oak_tree", pos)
			trees_spawned += 1

	var ores_spawned := 0
	for pos in ore_positions:
		if not _data.is_ore_harvested(pos):
			_entity_orchestrator.spawn_entity("iron_ore", pos)
			ores_spawned += 1

	_spawn_animals()
	var quest_h: float = 0.0
	if is_instance_valid(_terrain_generator):
		quest_h = _terrain_generator.get_height_at(8.0, -5.0)
	_entity_orchestrator.spawn_entity("quest_npc", Vector3(8.0, quest_h, -5.0))
	_spawn_enemies()
	_restore_pets(world_root)
	_place_water_bodies(world_root)
	_start_chunk_manager(world_root)

	Logger.log_end("WorldSpawner.spawn_all()", t, LOG_CAT)
	Logger.log_info(
		"Spawning: %d Bäume, %d Erze. Aktiv: %d." % [
			trees_spawned, ores_spawned, _entity_orchestrator.get_entity_count()
		], LOG_CAT
	)


func _generate_positions() -> void:
	if is_instance_valid(_world_gen):
		Logger.log_info("Kein Save — generiere via WorldGenerationService.", LOG_CAT)
		var seed_val := int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
		_world_gen.generate_world(seed_val, _data)
	else:
		Logger.log_warn("WorldGenerationService fehlt — nutze Hardcode-Defaults.", LOG_CAT)
		var defaults: Array[Vector3] = [Vector3(5,0,5), Vector3(-6,0,4), Vector3(8,0,-3)]
		_data.tree_positions = defaults
		_data.ore_positions  = [Vector3(-4,0,6)]


func _spawn_animals() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system()) ^ 0xABCDEF

	var configs := [
		{"type": "deer",   "count": 4, "min_dist": 6.0},
		{"type": "rabbit", "count": 6, "min_dist": 3.0},
		{"type": "boar",   "count": 3, "min_dist": 7.0},
	]

	var all_positions: Array[Vector3] = []
	for cfg in configs:
		var placed := 0
		var attempts := 0
		while placed < cfg["count"] and attempts < 60:
			attempts += 1
			var x := rng.randf_range(-25.0, 25.0)
			var z := rng.randf_range(-25.0, 25.0)
			var candidate := Vector3(x, 0.0, z)
			if candidate.length() < 8.0:
				continue
			var too_close := false
			for other in all_positions:
				if candidate.distance_to(other) < cfg["min_dist"]:
					too_close = true
					break
			if too_close:
				continue
			if is_instance_valid(_terrain_generator):
				var h := _terrain_generator.get_height_at(x, z)
				if h < 0.3:
					continue
				candidate.y = h
			all_positions.append(candidate)
			_entity_orchestrator.spawn_entity(cfg["type"], candidate)
			placed += 1

	Logger.log_info("Tiere gespawnt: %d." % all_positions.size(), LOG_CAT)


func _spawn_enemies() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system()) ^ 0x1337
	for _i in range(5):
		var x := rng.randf_range(-20.0, 20.0)
		var z := rng.randf_range(-20.0, 20.0)
		if Vector2(x, z).length() < 10.0:
			continue
		var h := 1.5
		if is_instance_valid(_terrain_generator):
			h = _terrain_generator.get_height_at(x, z)
		if h > 0.3:
			_entity_orchestrator.spawn_entity("goblin", Vector3(x, h, z))
	Logger.log_info("Feindliche NPCs gespawnt.", LOG_CAT)


func _restore_pets(world_root: Node3D) -> void:
	if not is_instance_valid(_data) or not _data.has_meta("saved_pets"):
		return
	var pet_data: Variant = _data.get_meta("saved_pets")
	if not pet_data is Array:
		return
	for entry in pet_data:
		if not entry is Dictionary:
			continue
		var pos: Variant = str_to_var(entry.get("pos", "Vector3(0,1,0)"))
		if not pos is Vector3:
			continue
		var pet := PetComponent.new()
		pet._name = entry.get("name", "Pet")
		var col: Variant = str_to_var(entry.get("color", "Color(0.7,0.5,0.3,1)"))
		if col is Color:
			pet._color = col
		pet.position = pos
		world_root.add_child(pet)
	Logger.log_info("Pets wiederhergestellt: %d." % (pet_data as Array).size(), LOG_CAT)


func _place_water_bodies(world_root: Node3D) -> void:
	if not is_instance_valid(_terrain_generator):
		return

	var sample_step: float = _terrain_generator.size / 8.0
	var water_centers: Array[Vector3] = []

	for zi in range(-4, 5):
		for xi in range(-4, 5):
			var lx: float = xi * sample_step
			var lz: float = zi * sample_step
			if _terrain_generator.get_height_at(lx, lz) < -0.5:
				water_centers.append(Vector3(lx, 0.0, lz))

	if water_centers.is_empty():
		return

	var used: Array[bool] = []
	for _i in range(water_centers.size()):
		used.append(false)
	var placed := 0

	for i in range(water_centers.size()):
		if used[i]:
			continue
		var center := water_centers[i]
		var min_x := center.x
		var max_x := center.x
		var min_z := center.z
		var max_z := center.z
		for j in range(water_centers.size()):
			if used[j]:
				continue
			if center.distance_to(water_centers[j]) < sample_step * 1.8:
				min_x = minf(min_x, water_centers[j].x)
				max_x = maxf(max_x, water_centers[j].x)
				min_z = minf(min_z, water_centers[j].z)
				max_z = maxf(max_z, water_centers[j].z)
				used[j] = true
		used[i] = true
		var w: float = max(max_x - min_x + sample_step, sample_step * 0.8)
		var l: float = max(max_z - min_z + sample_step, sample_step * 0.8)
		if w < 4.0 or l < 4.0:
			continue
		WaterBody.place(
			world_root,
			Vector3((min_x + max_x) * 0.5, 0.02, (min_z + max_z) * 0.5),
			Vector3(w, 2.5, l)
		)
		placed += 1

	Logger.log_info("WaterBodies platziert: %d." % placed, LOG_CAT)


func _start_chunk_manager(world_root: Node3D) -> void:
	var chunk_manager := ChunkManager.new()
	chunk_manager.name = "ChunkManager"
	world_root.add_child(chunk_manager)
	var seed_val := int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	chunk_manager.initialize(world_root, seed_val)
	Logger.log_info("ChunkManager gestartet.", LOG_CAT)
