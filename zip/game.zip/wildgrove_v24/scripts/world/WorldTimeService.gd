class_name WorldTimeService
extends RefCounted

## WorldTimeService — Tageszeit-Verwaltung.
## Wird von WorldService als Hilfsklasse gehalten und per on_tick(delta) getrieben.

const LOG_CAT := "WorldTime"

var day_time:  float = 6.0
var day_count: int   = 1
var time_speed: float = 0.05


func tick(delta: float) -> void:
	day_time += delta * time_speed
	if day_time >= 24.0:
		day_time = fmod(day_time, 24.0)
		day_count += 1
		EventBus.world.emit_time_of_day_changed(0)
		Logger.log_info("Neuer Tag: Tag %d." % day_count, LOG_CAT)


func get_formatted_time() -> String:
	var hours: int   = int(day_time)
	var minutes: int = int((day_time - hours) * 60)
	return "%02d:%02d" % [hours, minutes]


func restore(state: Dictionary) -> void:
	day_time  = state.get("day_time",  6.0)
	day_count = state.get("day_count", 1)


func get_save_data() -> Dictionary:
	return {"day_time": day_time, "day_count": day_count}
