extends CharacterBody3D
class_name EnemyNPC

## EnemyNPC — KI-State-Machine (IDLE → CHASE → ATTACK → DEAD).
## Visuals → EnemyVisuals.gd
## Interaktion/Angriff → EnemyAttack.gd

const LOG_CAT := "EnemyNPC"
const GRAVITY: float = 9.8

enum State { IDLE, CHASE, ATTACK, DEAD }

var _color:        Color   = Color(0.7, 0.15, 0.15)
var _max_health:   int     = 30
var _damage:       int     = 5
var _speed:        float   = 2.5
var _detect_range: float   = 8.0
var _attack_range: float   = 1.5
var _attack_cd:    float   = 1.5
var _xp_reward:    int     = 20
var _xp_skill:     String  = "combat"
var _drops:        Dictionary = {}

var _state:         State   = State.IDLE
var _attack_timer:  float   = 0.0
var _health:        HealthComponent
var _visuals:       EnemyVisuals


func _ready() -> void:
	add_to_group("enemies")
	_visuals = EnemyVisuals.new()
	_visuals.build(self, _color, _max_health, "Goblin")
	_build_collision()
	_setup_health()
	EnemyAttack.setup_interactable(self)
	Logger.log_debug("EnemyNPC gespawnt.", LOG_CAT)


func _physics_process(delta: float) -> void:
	if _state == State.DEAD:
		return
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0

	_attack_timer = maxf(0.0, _attack_timer - delta)
	var player := _get_player()
	if not is_instance_valid(player):
		_state = State.IDLE
		move_and_slide()
		return

	var dist: float = global_position.distance_to(player.global_position)
	match _state:
		State.IDLE:
			velocity.x = move_toward(velocity.x, 0.0, 5.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 5.0 * delta)
			if dist < _detect_range:
				_state = State.CHASE
		State.CHASE:
			if dist > _detect_range * 1.5:
				_state = State.IDLE
			elif dist < _attack_range:
				_state = State.ATTACK
			else:
				_move_toward(player.global_position, _speed, delta)
		State.ATTACK:
			velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)
			if dist > _attack_range * 1.3:
				_state = State.CHASE
			elif _attack_timer <= 0.0:
				_do_attack(player)
				_attack_timer = _attack_cd

	_visuals.update_health_bar(_health.current_health, _health.max_health)
	move_and_slide()


func _do_attack(player: Node3D) -> void:
	Logger.log_debug("Goblin greift an: %d Dmg." % _damage, LOG_CAT)
	var hc := player.get_node_or_null("HealthComponent") as HealthComponent
	if is_instance_valid(hc):
		hc.take_damage(_damage)


func _die() -> void:
	_state = State.DEAD
	EventBus.player.emit_xp(_xp_skill, _xp_reward)
	for item_id in _drops:
		EventBus.world.emit_loot_collected(item_id, _drops[item_id])
	var ic := get_node_or_null("AttackInteractable")
	if is_instance_valid(ic):
		ic.queue_free()
	get_tree().create_timer(1.5).timeout.connect(
		func() -> void:
			if is_instance_valid(self):
				queue_free()
	)
	Logger.log_info("Goblin besiegt. +%d %s XP." % [_xp_reward, _xp_skill], LOG_CAT)


func _move_toward(target: Vector3, spd: float, delta: float) -> void:
	var dir: Vector3 = target - global_position
	dir.y = 0.0
	if dir.length_squared() > 0.01:
		dir = dir.normalized()
		velocity.x = move_toward(velocity.x, dir.x * spd, 10.0 * delta)
		velocity.z = move_toward(velocity.z, dir.z * spd, 10.0 * delta)
		look_at(global_position + dir, Vector3.UP)


func _setup_health() -> void:
	_health = HealthComponent.new()
	_health.name       = "HealthComponent"
	_health.max_health = _max_health
	add_child(_health)
	_health.died.connect(_die)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.32
	sh.height = 1.0
	col.shape = sh
	col.position.y = 0.7
	add_child(col)


func _get_player() -> Node3D:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return null
	return players[0] as Node3D


func on_spawn(_cfg: Dictionary) -> void:
	if is_instance_valid(_health):
		_health.reset()
	_state = State.IDLE


func on_despawn() -> void:
	pass
