class_name EnemyAttack
extends RefCounted

## EnemyAttack — Interaktions-Setup und Angriffs-Callback für EnemyNPC.
## Extrahiert aus EnemyNPC.gd damit die KI-Klasse nicht mit UI-Interaction-Code vollläuft.

const LOG_CAT := "EnemyAttack"


static func setup_interactable(parent: Node3D) -> void:
	var d := InteractableData.new()
	d.id           = "attack_enemy"
	d.action_id    = "attack_enemy"
	d.label        = "Angreifen"
	d.duration     = 0.7
	d.xp_type      = "combat"
	d.xp_amount    = 5
	d.drops        = {}
	d.inspect_text = "Ein Goblin. Feindselig und gefährlich."
	var comp := InteractableComponent.new()
	comp.name = "AttackInteractable"
	comp.data = d
	parent.add_child(comp)
	EventBus.world.interaction_finished.connect(
		func(action_id: String, _label: String) -> void:
			_on_attack_finished(action_id, parent)
	)


static func _on_attack_finished(action_id: String, enemy: Node3D) -> void:
	if action_id != "attack_enemy":
		return
	if not is_instance_valid(enemy):
		return

	var sensors := enemy.get_tree().get_nodes_in_group("interaction_sensor")
	if sensors.is_empty():
		return
	var sensor: Node = sensors[0]
	if not sensor.has_method("get_current_target"):
		return
	var target: Node3D = sensor.get_current_target()
	if not (is_instance_valid(target) and (target == enemy or target.is_ancestor_of(enemy))):
		return

	var dmg := 10
	if is_instance_valid(Services.skill_system):
		dmg += Services.skill_system.get_level("combat") * 2

	var hc := enemy.get_node_or_null("HealthComponent") as HealthComponent
	if is_instance_valid(hc):
		hc.take_damage(dmg)
		Logger.log_debug("Spieler trifft: %d Dmg → %d/%d HP" % [dmg, hc.current_health, hc.max_health], LOG_CAT)
