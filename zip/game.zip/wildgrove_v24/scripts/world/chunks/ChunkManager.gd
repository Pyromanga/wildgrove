extends Node
class_name ChunkManager

## ChunkManager — Lädt/entlädt Terrain-Chunks basierend auf Spielerposition.
##
## ── KOORDINATEN-SYSTEM ────────────────────────────────────────────────────
## _chunk_to_world(coord) gibt das ZENTRUM des Chunks in Weltkoordinaten zurück.
## Das TerrainGenerator-Mesh für diesen Chunk spannt [center-32, center+32]
## in X und Z (size=64, zentriert). chunk_node.position = center.
##
## Für Entity-Platzierung gilt daher: lokale Koordinaten lx,lz ∈ [-28, 28]
## (Mesh-Bereich minus Randabstand), Weltposition = center + (lx, 0, lz).
## Höhen-Lookup: gen.get_height_at(lx, lz) — gen.size=64 passt zu diesem Bereich.
##
## gen.world_offset = center wird VOR gen.create() gesetzt, damit die
## Biome-Noise (global, weltkoordinaten-basiert) exakt zum gebauten Mesh passt.
##
## Chunk (0,0) hat Zentrum (0,0) = Weltursprung = identisch zum Haupt-Terrain
## aus WorldFactory (size=64, world_offset=(0,0)) → wird übersprungen.

const LOG_CAT       := "ChunkManager"
const CHUNK_SIZE    := 64.0
const LOAD_RADIUS   := 2
const UNLOAD_RADIUS := 3
const ENTITY_MARGIN := 6.0   # Abstand zum Chunk-Rand für Entity-Spawns

## Aktive Chunks: { Vector2i(cx, cz): Node3D | null }
var _chunks: Dictionary = {}

var _player_chunk: Vector2i = Vector2i(999, 999)
var _world_root: Node3D
var _seed: int = 0


func initialize(world_root: Node3D, world_seed: int) -> void:
	_world_root = world_root
	_seed = world_seed
	Logger.log_info(
		"ChunkManager initialisiert. Chunk-Größe: %.0fm, Radius: %d" % [CHUNK_SIZE, LOAD_RADIUS],
		LOG_CAT
	)


func _process(_delta: float) -> void:
	if not is_instance_valid(_world_root):
		return

	var player := _get_player()
	if not is_instance_valid(player):
		return

	var new_chunk := _world_to_chunk(player.global_position)
	if new_chunk == _player_chunk:
		return

	_player_chunk = new_chunk
	_update_chunks()


func _update_chunks() -> void:
	for dz in range(-LOAD_RADIUS, LOAD_RADIUS + 1):
		for dx in range(-LOAD_RADIUS, LOAD_RADIUS + 1):
			var coord := Vector2i(_player_chunk.x + dx, _player_chunk.y + dz)
			if not _chunks.has(coord):
				_load_chunk(coord)

	var to_unload: Array[Vector2i] = []
	for coord in _chunks:
		var dist: int = max(abs(coord.x - _player_chunk.x), abs(coord.y - _player_chunk.y))
		if dist > UNLOAD_RADIUS:
			to_unload.append(coord)

	for coord in to_unload:
		_unload_chunk(coord)


func _load_chunk(coord: Vector2i) -> void:
	# Chunk (0,0): Zentrum=(0,0)=Weltursprung — identisch zum Haupt-Terrain
	# aus WorldFactory (size=64, world_offset=(0,0)). Überspringen verhindert
	# doppelte Terrain-Layer/Z-Fighting im Start-Bereich.
	if coord == Vector2i(0, 0):
		_chunks[coord] = null
		return

	var center := _chunk_to_world(coord)
	Logger.log_debug("Lade Chunk %s @ Zentrum %s" % [str(coord), str(center)], LOG_CAT)

	var gen := TerrainGenerator.new()
	gen.size        = CHUNK_SIZE
	gen.resolution  = 32
	gen.max_height  = 12.0
	gen.sea_level   = 0.6
	# Detail-Noise: pro Chunk eigener Seed (Variation zwischen Chunks)
	gen.noise_seed  = _seed ^ (coord.x * 73856093) ^ (coord.y * 19349663)
	# Biome-Noise: world_offset = Chunk-Zentrum → globale Biome-Karte ist
	# über Chunk-Grenzen hinweg kontinuierlich (BIOME_SEED ist fix in TerrainGenerator).
	gen.world_offset = center

	var chunk_node := Node3D.new()
	chunk_node.name = "Chunk_%d_%d" % [coord.x, coord.y]
	chunk_node.position = Vector3(center.x, 0.0, center.y)
	_world_root.add_child(chunk_node)

	gen.create(chunk_node)
	_chunks[coord] = chunk_node

	_spawn_chunk_entities(coord, center, gen)
	_place_chunk_water(chunk_node, center, gen)


func _unload_chunk(coord: Vector2i) -> void:
	if not _chunks.has(coord):
		return
	var chunk_node = _chunks[coord]
	_chunks.erase(coord)
	if is_instance_valid(chunk_node):
		chunk_node.queue_free()
	Logger.log_debug("Chunk %s entladen." % str(coord), LOG_CAT)


## Spawnt Bäume/Tiere für einen Chunk.
## lx,lz sind LOKALE Koordinaten relativ zum Chunk-Zentrum (passend zu gen.size=64,
## gen.get_height_at erwartet exakt diesen Bereich). Weltposition = center + (lx,lz).
func _spawn_chunk_entities(coord: Vector2i, center: Vector2, gen: TerrainGenerator) -> void:
	if not is_instance_valid(Services.world):
		return

	var half: float = CHUNK_SIZE * 0.5 - ENTITY_MARGIN  # gültiger Bereich: [-28, 28]

	var rng := RandomNumberGenerator.new()
	rng.seed = _seed ^ (coord.x * 1234567) ^ (coord.y * 7654321)

	# Bäume
	var tree_count := rng.randi_range(1, 4)
	for _i in range(tree_count):
		var lx: float = rng.randf_range(-half, half)
		var lz: float = rng.randf_range(-half, half)
		var h: float = gen.get_height_at(lx, lz)
		if h > 0.3:
			Services.world.spawn_entity("oak_tree", Vector3(center.x + lx, h, center.y + lz))

	# Tiere — jeder dritte Chunk bekommt eines (deterministisch über Seed)
	if (abs(coord.x) + abs(coord.y)) % 3 == 0:
		var animal_types: Array[String] = ["deer", "rabbit", "boar"]
		var animal_type: String = animal_types[rng.randi_range(0, 2)]
		var lx: float = rng.randf_range(-half, half)
		var lz: float = rng.randf_range(-half, half)
		var h: float = gen.get_height_at(lx, lz)
		if h > 0.3:
			Services.world.spawn_entity(animal_type, Vector3(center.x + lx, h, center.y + lz))


func _place_chunk_water(chunk_node: Node3D, center: Vector2, gen: TerrainGenerator) -> void:
	## Platziert WaterBodies in Terrain-Senken dieses Chunks.
	## Analog zu WorldService._place_water_bodies, aber für dynamisch geladene Chunks.
	var half: float = CHUNK_SIZE * 0.5 - 4.0
	var sample_step: float = CHUNK_SIZE / 6.0

	var low_points: Array[Vector3] = []
	for zi in range(-3, 4):
		for xi in range(-3, 4):
			var lx: float = xi * sample_step
			var lz: float = zi * sample_step
			var h: float = gen.get_height_at(lx, lz)
			if h < -0.5:
				low_points.append(Vector3(lx, 0.0, lz))

	if low_points.is_empty():
		return

	# Einfach: alle Tiefpunkte zu einem einzigen Becken zusammenfassen
	var min_x := INF; var max_x := -INF
	var min_z := INF; var max_z := -INF
	for p in low_points:
		min_x = minf(min_x, p.x); max_x = maxf(max_x, p.x)
		min_z = minf(min_z, p.z); max_z = maxf(max_z, p.z)

	var w: float = max(max_x - min_x + sample_step, sample_step)
	var l: float = max(max_z - min_z + sample_step, sample_step)
	if w < 4.0 or l < 4.0:
		return

	var wx: float = center.x + (min_x + max_x) * 0.5
	var wz: float = center.y + (min_z + max_z) * 0.5
	WaterBody.place(chunk_node, Vector3(wx, 0.02, wz), Vector3(w, 2.5, l))


func _world_to_chunk(pos: Vector3) -> Vector2i:
	return Vector2i(
		int(round(pos.x / CHUNK_SIZE)),
		int(round(pos.z / CHUNK_SIZE))
	)


## Gibt das ZENTRUM des Chunks in Weltkoordinaten zurück (siehe Klassenkommentar).
func _chunk_to_world(coord: Vector2i) -> Vector2:
	return Vector2(coord.x * CHUNK_SIZE, coord.y * CHUNK_SIZE)


func _get_player() -> Node3D:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return null
	return players[0] as Node3D
