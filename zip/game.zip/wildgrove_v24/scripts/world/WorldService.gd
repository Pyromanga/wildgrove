extends ServiceNode
class_name WorldService

## WorldService — Lifecycle + öffentliche API für die Spielwelt.
##
## Delegiert Verantwortlichkeiten an spezialisierte Klassen:
##   WorldSpawner      → Entities, Tiere, Wasser, Pets, Chunks spawnen
##   WorldTimeService  → Tageszeit verwalten
##   WorldFactory      → statische Geometrie erstellen
##   EntityOrchestrator → Entity-Pooling + UUID-Verwaltung
##
## Abhängigkeiten: ["savesystem", "world_gen"]

const LOG_CAT := "World"
const SAVE_KEY := "world_state"

var data:     WorldData
var factory:  WorldFactory
var factory3d: Factory3D

var _save_system: SaveSystem
var _world_gen:   WorldGenerationService
var _entity_orchestrator: EntityOrchestrator
var _spawner:  WorldSpawner
var _time:     WorldTimeService

var day_time:  float  # Forwarding → _time.day_time
var day_count: int    # Forwarding → _time.day_count


# ─────────────────────────────────────────────
# Service-Lifecycle
# ─────────────────────────────────────────────

func configure(deps: Dictionary) -> void:
	_save_system = deps.get("savesystem") as SaveSystem
	_world_gen   = deps.get("world_gen")  as WorldGenerationService

	data      = WorldData.new()
	factory   = WorldFactory.new()
	factory3d = Factory3D.new()
	_time     = WorldTimeService.new()

	_entity_orchestrator      = EntityOrchestrator.new()
	_entity_orchestrator.name = "EntityOrchestrator"
	add_child(_entity_orchestrator)
	_register_entity_definitions()

	if is_instance_valid(_save_system):
		_save_system.register_save_provider(self)
		var saved := _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_restore_world(saved)

	if not is_instance_valid(_world_gen):
		Logger.log_warn("WorldGenerationService fehlt.", LOG_CAT)

	Logger.log_info("WorldService konfiguriert.", LOG_CAT)


func on_ready() -> void:
	if Services.ticker:
		Services.ticker.register_service(self)

	var respawn := Services.respawn
	if is_instance_valid(respawn):
		respawn.register_config("oak_tree", 300.0)
		respawn.register_config("iron_ore", 600.0)
		respawn.set_spawn_callback(func(t: String, p: Vector3) -> Node3D: return spawn_entity(t, p))
		respawn.set_remove_callback(func(t: String, p: Vector3) -> void: data.unmark_harvested(t, p))

	Logger.log_info("WorldService bereit.", LOG_CAT)


func on_cleanup() -> void:
	if is_instance_valid(_entity_orchestrator) and _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()


func on_tick(delta: float) -> void:
	if is_instance_valid(Services.game_manager) and Services.game_manager.is_playing():
		_time.tick(delta)
		day_time  = _time.day_time
		day_count = _time.day_count


# ─────────────────────────────────────────────
# Welt-Initialisierung
# ─────────────────────────────────────────────

func on_world_scene_ready(world_root: Node3D) -> void:
	var t := Logger.log_begin("on_world_scene_ready()", LOG_CAT)

	if _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()
		EventBus.world.emit_world_scene_unloaded()

	# Statische Geometrie
	var generated := factory.create_world()
	for child in generated.get_children():
		generated.remove_child(child)
		world_root.add_child(child)
	generated.queue_free()

	# Terrain-Höhen-Callback
	if is_instance_valid(_world_gen) and is_instance_valid(factory.terrain_generator):
		_world_gen.set_height_callback(factory.terrain_generator.get_height_at)

	_entity_orchestrator.initialize(world_root)

	# WorldSpawner mit aktuellen Referenzen neu erstellen
	_spawner = WorldSpawner.new(
		_entity_orchestrator,
		factory.terrain_generator,
		_world_gen,
		data
	)
	_spawner.spawn_all(world_root)

	EventBus.world.emit_world_scene_ready(world_root)

	Logger.log_end("on_world_scene_ready()", t, LOG_CAT)
	Logger.log_info("Welt bereit. Entities: %d." % _entity_orchestrator.get_entity_count(), LOG_CAT)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func get_save_key() -> String:
	return SAVE_KEY


func get_save_data() -> Dictionary:
	var tree_strings: Array[String] = []
	for pos in data.tree_positions:
		tree_strings.append(var_to_str(pos))

	var pets_raw: Variant = data.get_meta("saved_pets") if data.has_meta("saved_pets") else []

	var time_data := _time.get_save_data()
	return {
		"day_time":       time_data["day_time"],
		"day_count":      time_data["day_count"],
		"tree_positions": tree_strings,
		"ore_positions":  var_to_str(data.ore_positions),
		"player_pos":     var_to_str(data.player_position),
		"harvested":      var_to_str(data.harvested_objects),
		"saved_pets":     var_to_str(pets_raw),
	}


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

func get_formatted_time() -> String:
	return _time.get_formatted_time()


func spawn_entity(type_id: String, position: Vector3, config: Dictionary = {}) -> Node3D:
	if not is_instance_valid(_entity_orchestrator):
		return null
	return _entity_orchestrator.spawn_entity(type_id, position, config)


func despawn_entity(uuid: String) -> void:
	if is_instance_valid(_entity_orchestrator):
		_entity_orchestrator.despawn_entity(uuid)


func get_entity_debug_info() -> Dictionary:
	if not is_instance_valid(_entity_orchestrator):
		return {}
	return _entity_orchestrator.get_debug_info()


# ─────────────────────────────────────────────
# Öffentliche API — WorldData-Delegation
# Externe Aufrufer (Entities, Services) nutzen diese statt Services.world.data.*
# ─────────────────────────────────────────────


## Markiert einen Baum als geerntet. Aufgerufen von OakTree nach Interaktion.
func mark_tree_harvested(pos: Vector3) -> void:
	data.mark_tree_harvested(pos)


## Markiert ein Erz als geerntet. Aufgerufen von IronOre nach Interaktion.
func mark_ore_harvested(pos: Vector3) -> void:
	data.mark_ore_harvested(pos)


## Gibt den gespeicherten Pet-State zurück (für WorldService.get_save_data).
## Aufgerufen von GameSaveService vor dem Speichern.
func store_pet_save_data(pet_data: Array) -> void:
	data.set_meta("saved_pets", pet_data)

func _register_entity_definitions() -> void:
	_entity_orchestrator.register_definition("oak_tree",  "res://scripts/world/objects/OakTree.gd",       "trees")
	_entity_orchestrator.register_definition("iron_ore",  "res://scripts/world/objects/IronOre.gd",        "ores")
	_entity_orchestrator.register_definition("deer",      "res://scripts/world/animals/Deer.gd",           "animals")
	_entity_orchestrator.register_definition("rabbit",    "res://scripts/world/animals/Rabbit.gd",         "animals")
	_entity_orchestrator.register_definition("boar",      "res://scripts/world/animals/Boar.gd",           "animals")
	_entity_orchestrator.register_definition("quest_npc", "res://scripts/world/npc/QuestNPC.gd",           "npcs")
	_entity_orchestrator.register_definition("goblin",    "res://scripts/world/combat/EnemyNPC.gd",        "enemies")


func _restore_world(state: Dictionary) -> void:
	_time.restore(state)
	day_time  = _time.day_time
	day_count = _time.day_count

	var tree_strings: Variant = state.get("tree_positions", [])
	if tree_strings is Array:
		data.tree_positions = []
		for s in tree_strings:
			var pos: Variant = str_to_var(s)
			if pos is Vector3:
				data.tree_positions.append(pos)

	var ore_raw: Variant = str_to_var(state.get("ore_positions", "[]"))
	if ore_raw is Array:
		data.ore_positions = []
		for p in ore_raw:
			if p is Vector3:
				data.ore_positions.append(p)

	var player_pos_raw: Variant = str_to_var(state.get("player_pos", "Vector3(0,0,0)"))
	data.player_position = player_pos_raw if player_pos_raw is Vector3 else Vector3.ZERO

	var harvested_raw: Variant = str_to_var(state.get("harvested", "{}"))
	data.harvested_objects = harvested_raw if harvested_raw is Dictionary else {}

	var pets_raw: Variant = str_to_var(state.get("saved_pets", "[]"))
	if pets_raw is Array:
		data.set_meta("saved_pets", pets_raw)

	Logger.log_info(
		"Welt geladen: Tag %d %s, %d Bäume, %d Erze." % [
			day_count, get_formatted_time(),
			data.tree_positions.size(), data.ore_positions.size()
		], LOG_CAT
	)