# ImplementAgent.md — WildGrove Bug-Fix Execution Plan

**Scope:** Prio-3 ZIP + Meta-Review (WILDGROVE_META_REVIEW.md)
**Method:** Bug-by-bug with ZIP output after each logical group. Code is ground truth.
**Date:** 2026-06

---

## Working Rules

1. **One bug at a time** — fix, update tests + docs atomically, output ZIP, move on.
2. **No legacy comments** — completed TODOs and "xyz is fixed" notes are removed, not kept.
3. **Meta-check every fix** — before applying, re-verify the actual file matches what the review claims.
4. **Docs + tests always updated** — services.md, ADRs, test files stay in sync with every change.
5. **Trust the code, not the docs** — AGENT.md rule applies here too.
6. **No franchise names** — concepts only in all output.

---

## DONE ✅

#### BUG-1: A-01 — EquipmentService: Complete Save Failure ✅
- `get_save_key()` / `get_save_data()` — renamed to match ISaveProvider contract
- `configure()` resolves `savesystem` dep, registers as provider, calls `load_data()` on startup
- `BootstrapConfig.tres` equipment deps: `["stat_modifiers", "savesystem", "data"]`
- `SaveMigrationService.CURRENT_VERSION = 3`; `_migrate_v2_to_v3()` adds `"equipment": {}`
- Tests: method names fixed, MockSaveSystem added, round-trip tests added
- `services.md` equipment deps and CURRENT_VERSION corrected

#### BUG-2: A-02 — SaveSystem: No .bak Recovery ✅
- `_read_from_disk()` extracted to `_try_read_json()` helper
- On main file failure: tries `.bak` before returning `{}`
- Distinct log messages for each failure scenario

#### BUG-3: C-01 — `roll_critical()` assert No-Op in Release ✅
- `assert(multiplayer.is_server(), ...)` → `if not multiplayer.is_server(): return false`
- Contract documented in test

#### BUG-4: B-01/B-02 — StatModifierService, RewardDispatcher, GameSaveService: ServiceNode without reason ✅
- `extends ServiceNode` → `extends Service` in all three (zero SceneTree usage verified)
- `services.md` table rows and footnote ¹ updated
- ADR-003 Ablösung section updated with post-verification note

#### BUG-5: B-03 — ServiceOrchestrator MeshCache Layer Violation ✅
- `WorldService.warmup_mesh_cache()` added — encapsulates all `factory3d` internals
- ServiceOrchestrator S8.8 uses `Services.world.warmup_mesh_cache()` — no direct field access

#### BUG-6 + BUG-11: F-03 + B-05 — Session Teardown Race + Double Wrapper ✅
- `_is_session_active()` (GameManager state query, always false post-transition) removed
- `is_session_active()` now checks `_session_registry.get_all_names().is_empty()` — race-free
- All 3 call sites updated (`_on_state_changed`, `_teardown_all`, `boot_session S1`)
- Public double-wrapper collapsed into single public method

#### BUG-8: A-03 — services.md divergence ✅
- Fully resolved across BUG-1 (deps, version) and BUG-4 (ServiceNode rows + footnote)

---

## ROUND 8 — Testability/DI Review (AUDIT-04, Section H)

External review pasted by owner, covering 9 testability/DI findings. Tracked in
`docs/audit/AUDIT-04-testability-di.md`. Bug numbering continues from BUG-18 (BUG-7,
BUG-9..BUG-17 remain queued from prior rounds, untouched this round).

#### BUG-18: H-01 — ServiceValidator hardcoded disk load ✅
- `config: BootstrapConfig` injectable property added (analog `ServiceFactory.mounter`)
- `BootstrapConfig.load_default()` static loader added — single source of truth for the path
- `_load_config()` now: return injected `config`, else fallback-load once and cache
- Test: `tests/unit/test_service_validator.gd` (new)

---

## ROUND 13 — BUG-14: C-02 Authority Guards + C-03 Equipment Sync ✅

#### C-02: Authority Guards in alle Services ✅
Alle `receive_*_from_network()` / `on_*_confirmed()` Methoden haben jetzt denselben Guard:
```gdscript
if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
    Logger.log_error("...: Aufruf auf Nicht-Autorität — verweigert.", LOG_CAT)
    return
```
- `InventorySystem.on_item_add_confirmed()` — war ungeschützt (C-02 Original-Find)
- `QuestService.receive_start_quest_from_network()`
- `QuestService.receive_complete_quest_from_network()`
- `SkillSystem.receive_add_xp_from_network()`
- `EquipmentService.on_equip_confirmed()` (neu, C-03)
- `EquipmentService.on_unequip_confirmed()` (neu, C-03)

#### C-03: Equipment-Sync in NetworkBridge ✅
- `EquipmentService`: `request_equip()` / `on_equip_confirmed()` / `request_unequip()` / `on_unequip_confirmed()` — exakt dasselbe Muster wie InventorySystem
- `NetworkBridge`: `_equipment: EquipmentService` dep, `send_equip_item()` / `send_unequip_item()`, `@rpc _rpc_equip_item()` / `@rpc _rpc_unequip_item()`
- `BootstrapConfig.tres`: `"equipment"` als dep für `network_bridge` ergänzt

#### Phase S8.6: Late-Network-Inject ✅
NetworkBridge ↔ Services ist ein zirkulärer Dep — beide Seiten brauchen sich gegenseitig.
Lösung: alle vier Services (`inject_network_bridge()` Methode) + Phase S8.6 in `BootPipeline.boot_session()`:
```gdscript
for key in [INVENTORY, QUEST, SKILL_SYSTEM, EQUIPMENT]:
    svc.inject_network_bridge(net)  # via has_method() guard
```
Kein Dep-Zirkel, NetworkBridge wird nach vollem Boot in alle Empfänger injiziert.

#### Tests: 5 neue Tests in test_network_bridge.gd ✅
- `test_inventory_on_item_add_confirmed_allowed_in_tier1`
- `test_inventory_authority_guard_blocks_client_direct_call`
- `test_send_equip_item_tier1_calls_on_equip_confirmed`
- `test_send_unequip_item_tier1_calls_on_unequip_confirmed`
- `test_equipment_inject_network_bridge_sets_field`

---



#### World.gd → WorldService: EventBus statt Services-Locator ✅
- `WorldEvents`: neues Signal `world_scene_node_ready(world_root: Node3D)` + `emit_world_scene_node_ready()`.
- `World.gd`: `Services.world.on_world_scene_ready(self)` → `EventBus.world.emit_world_scene_node_ready(self)`.
- `WorldService.on_ready()`: connected auf `_bus.world().world_scene_node_ready`.
- `WorldService.on_cleanup()`: disconnected das Signal sauber.
- Begründung: World.gd ist ein SceneTree-Node ohne Service-Lifecycle — EventBus ist der korrekte Entkopplungspunkt. Das Timing-Problem (call_deferred feuerte zu früh) ist durch das Signal-Connect in `on_ready()` gelöst.

#### EntityContext.from_services(): Locator entfernt, fail-fast ✅
- Methode bleibt als named stub für Compile-Kompatibilität.
- Inhalt: `push_error()` + `return EntityContext.new()` — feuert sofort wenn unerwartet aufgerufen.
- Produktionspfad: `from_deps()`. Testpfad: `for_test()`.

#### UIContext.from_services(): Locator entfernt, fail-fast ✅
- Gleiche Behandlung wie EntityContext.from_services().
- Produktionspfad: `from_registry()`. Testpfad: `for_test()`.

#### Verbleibender legitimer Services.-Zugriff (dokumentiert, kein Handlungsbedarf)
- `Main.gd:30` — einmaliger Post-Boot-Existenzcheck, kein Business-Logik-Locator.
- `IntegrationTest.gd` — Testinfrastruktur, inspiziert Container von außen (Assertion-Ebene).
- `SimpleTerminal.gd` — Debug-Tool, bewusst außerhalb des DI-Graphen.
- `Services.populate_global/session/clear` in BootPipeline — Container-Befüllung, kein Auflösen.

---



#### ARCH-1 Bugfix: WorldService fehlende Entity-Dep-Resolution ✅
- `_ent_skill`, `_ent_inventory`, `_ent_stat_mod`, `_ent_combat`, `_ent_equipment`, `_ent_interact`
  waren in `configure()` nie aufgelöst — undeclared vars, immer `null`.
  Das ist der Grund warum `_entity_services_injected` immer `false` war und der
  Services-Locator-Fallback in `EntityOrchestrator.spawn_entity()` jedes Mal feuerte.
- Alle 7 Entity-Deps als `var _ent_*` deklariert und in `configure()` via `deps.get_optional()` aufgelöst.
- `_ent_player_states: PlayerStateService` als neue Entity-Dep ergänzt.
- `BootstrapConfig.tres` WorldService-deps: `"playerstates"` hinzugefügt.

#### ARCH-1 Erweiterung: PlayerStateService → TouchInput via DI ✅
- `EntityOrchestrator.set_entity_services()`: `player_states: PlayerStateService = null` (optionaler Parameter, kein Breaking Change).
- `EntityOrchestrator.spawn_entity()`: ruft nach `on_spawn()` `entity.inject_player_states()` auf wenn Methode vorhanden und `_entity_player_states` gesetzt.
- `Player.inject_player_states(svc)`: öffentliche Methode, delegiert an `input.inject_player_states(svc)`.
- `TouchInput._player_states: PlayerStateService` injiziert — kein `Services.player_states` mehr in `_unhandled_input()`.

#### InteractableComponent: Services-Locator-Fallback entfernt ✅
- `Services.interaction_executor` Fallback aus `start_default_interaction()` entfernt.
- Klarer `log_error` wenn `inject_context()` nicht aufgerufen wurde — fail-fast statt silent fallback.

#### MainMenuController: Services.save_system → inject_save_system() ✅
- `_save_system: SaveSystem` injiziertes Feld, `inject_save_system(svc)` public method.
- `ServiceOrchestrator._ready()`: ruft `_inject_save_system_into_main_menu()` nach `boot_global()`.
- `_inject_save_system_into_main_menu()` / `_do_inject_save_system()`: holt SaveSystem aus `_global_registry`, findet `MainMenuController` via `get_tree().current_scene`, injiziert per `call_deferred()`.
- Analog zum HUDManager-UIContext-Pattern (DEBT-2).

---



Verified H-02–H-06/H-09 all fixed (code-read confirmed). Implemented remaining open
structural items from `wildgrove_architektur_analyse.md` and `AUDIT-04`.

#### ARCH-2: ServiceTeardownManager — explizite Boot-Reihenfolge ✅
- `execute(registry, boot_order: Array[String] = [])` — neues optionales Argument
- BootPipeline speichert `_global_boot_order` + `_session_boot_order` nach Dependency-Resolve
- Beide `teardown.execute()` Aufrufe übergeben die jeweilige Order + resetten danach
- Fallback (leeres Array) bleibt kompatibel — kein Breaking Change
- Test: `tests/unit/test_teardown_order.gd` (neu, 5 Tests)

#### DEBT-3: BootPipeline Phase S8.8 warmup_mesh_cache — kein Services-Locator ✅
- `Services.world.warmup_mesh_cache()` → `session_registry.get_service(ServiceKeys.WORLD) as WorldService`
- BootPipeline ist jetzt vollständig ohne Services-Container testbar

#### ARCH-1 + BUG-3: EntityContext.from_deps() + spawn_entity(peer_id) ✅
- `EntityContext.from_deps(skill, inv, factory3d, respawn, data, stat_mod, combat, equip, world, interaction_executor, peer_id)` hinzugefügt — kein Services-Locator
- `EntityContext.from_services()` bleibt als `@deprecated`-Fallback
- `EntityOrchestrator.set_entity_services(...)` — Injection-Methode für alle 10 Entity-Services
- `EntityOrchestrator.spawn_entity(type_id, position, config, peer_id: int = 1)` — peer_id-Parameter
- spawn_entity nutzt from_deps() wenn set_entity_services() aufgerufen wurde; Fallback auf from_services() mit Log-Warn
- `WorldService.configure()` liest entity service deps (alle optional) + ruft `_entity_orchestrator.set_entity_services(...)` auf
- `WorldService.spawn_entity()` leitet peer_id weiter
- `BootstrapConfig.tres` WorldService-deps um entity service deps erweitert (alle optional)
- Test: `tests/unit/test_entity_context.gd` — 6 neue Tests für from_deps() + peer_id

#### DEBT-2: UIContext.from_services() — ServiceRegistry statt Services-Locator ✅
- `UIContext.from_registry(registry: ServiceRegistry)` hinzugefügt — canonical DI-Pfad
- `UIContext.from_services()` bleibt als `@deprecated`-Fallback
- `HUDManager._ui_context_factory: Callable` — default = from_services(), injectable via `set_ui_context_factory()`
- `HUDManager._on_world_scene_ready()` ruft `_ui_context_factory.call()` statt from_services()
- `ServiceOrchestrator.boot_session()` setzt Factory über `get_node_or_null("/root/HUDManager")` nach boot

#### H-06: ServiceInitializer + TeardownManager duck-typing → typsichere Guards ✅
- `scripts/interfaces/core/IServiceLifecycle.gd` erstellt — dokumentiert den Lifecycle-Vertrag
- `ServiceInitializer.run()`: `svc is Service or svc is ServiceNode` statt `has_method("configure")`
- `ServiceInitializer.run_on_ready()`: `svc is Service or svc is ServiceNode` statt `has_method("on_ready")`
- `ServiceTeardownManager.execute()`: `svc is Service or svc is ServiceNode` statt `has_method("on_cleanup")`

---

## QUEUE — P1 Fixes

#### BUG-7: F-01 — ISaveProvider missing `load_save_data()` on restore side ✅
**Won't fix as described — documented instead (verified in AUDIT-03).**
Code-Lese-Analyse: alle Provider lesen State selbst in `configure()` via `get_state_for()`.
Pull-Pattern ist Absicht. `load_save_data()` im Interface würde Push-Architektur erzwingen.
Fix: ISaveProvider.gd dokumentiert das Pull-Pattern explizit mit Beispiel-Code.

---

## DONE — P3 Cleanup

#### OBS-1: ServiceDefinition.interface_type — toter Code ✅
- `@export var interface_type: String = ""` entfernt aus `ServiceDefinition.gd`
- Kein einziger Nutzer im gesamten Codebase (grep-bestätigt)
- Kein Breaking Change: kein `.tres`-File setzt `interface_type`

#### OBS-2: ServiceTicker Fehlerresilienz — bereits implementiert ✅
- `_process()` und `_physics_process()` iterieren rückwärts mit `is_instance_valid()`-Guard
- Ungültige Einträge werden sauber entfernt — kein Handlungsbedarf

#### OBS-3: SaveSystem kein `on_cleanup()` ✅
- `on_cleanup()` ergänzt in `SaveSystem.gd` nach `configure()`
- Leert `_save_providers`, `_loaded_state`, `_active_player_id` — idempotent, sicher bei hartem Exit
- Tests: 3 neue Tests in `tests/unit/test_save_system.gd`
  - `test_on_cleanup_clears_providers()`
  - `test_on_cleanup_clears_active_session()`
  - `test_on_cleanup_is_idempotent()`



---

---

## ROUND 14 — BUG-12: Property-Tests, Lifecycle-Tests, Player.gd Tests ✅

#### E-03: Property-Based Tests für Core Math ✅
- `tests/unit/test_property_based.gd` — 25 Tests in 3 Klassen
- **P-01…P-06:** `calculate_damage()` Invarianten — MIN_DAMAGE-Floor für alle raw/resist-Kombinationen, TRUE-Schaden = raw (crit-immun), monotone Resistenz-Abnahme, Armor-Clamp bei 0.85, Post-condition-Stabilität, final >= 0
- **S-01…S-08:** `get_effective_stat()` Invarianten — Identität, FLAT_ADD-Additivität, PERCENT_ADD/MULTIPLY-Mathematik, Operationsreihenfolge (Vertrag aus StatModifier.gd), cross-stat-Isolation, Endlichkeit
- **M-01…M-08:** `migrate()` Invarianten — Idempotenz, schema_version = CURRENT_VERSION, Downgrade-Erkennung + downgrade_detected-Flag, v0/v1/v2-Chain, non-destructive equipment-Block-Insert, Input-Mutation verhindert

#### B-04: ServiceOrchestrator Lifecycle Tests ✅
- `tests/unit/test_service_orchestrator_lifecycle.gd` — 11 Tests (L-01…L-11)
- `is_session_active()` Race-Condition-frei: Registry-Zustand statt GameManager.get_state()
- Character-Switch: teardown_session() → neue Registry → boot_session() in korrekter Reihenfolge
- begin_session()/end_session() erhalten korrekte player_ids
- teardown_all(): Session-Registry vor Global-Registry (Reihenfolge L-09)
- Fehler-Paths (S2 ohne SaveSystem), Registry-Isolation nach Teardown

#### G-01 + G-02: Player.gd Tests + EnemyNPC Fallback ✅
- `tests/unit/test_player_gd.gd` — 14 Tests (PM/PL/EN)
- **PlayerMover (PM-01…PM-06):** Velocity-Physik, StatModifier-Integration, nil-Safety
- **Player Lifecycle (PL-01…PL-06):** Initial-State FREE, on_despawn() D-02-Fix-Absicherung, nil-safe inject, get_context_actions() ohne Sensor
- **EnemyNPC Fallback (EN-01…EN-04):** G-02 Fallback-Pfad reduziert HP, kein Crash ohne HC, is_dead-Guard, Timer-Null-Safety

## ROUND 15 — I-01: `on_*_confirmed` Public-API-Konsistenz ✅
*(Nachträglich geloggt — der Fix war bereits im Code und in AUDIT-03 als ✅ markiert, aber nie hier verzeichnet. Gegen den Code verifiziert, nicht nur gegen die Audit-Beschreibung übernommen.)*

#### I-01: `_on_*_confirmed` → `on_*_confirmed` öffentlich, typisiert ✅
- `QuestService.on_quest_start_confirmed(quest_id: String, player_id: int = 1)` — public, Authority Guard
- `QuestService.on_quest_complete_confirmed(quest_id: String, player_id: int = 1)` — public, Authority Guard
- `SkillSystem.on_xp_add_confirmed(skill_name: String, amount: int, player_id: int = 1)` — public, Authority Guard
- `receive_*_from_network()`-Wrapper-Schicht vollständig entfernt; `NetworkBridge` ruft `on_*_confirmed()` direkt — konsistent mit `InventorySystem`/`EquipmentService`
- `tests/unit/test_network_bridge_contract.gd` vollständig neu geschrieben: Sichtbarkeit, State-Äquivalenz zu `request_*()`, player_id-Routing, Tier-1-Routing, Abwesenheit der alten `receive_*`-Wrapper

## ROUND 16 — I-02: UI-Controller EventBus-Injektion ✅

#### I-02: `IUIContext.bus()` ersetzt direkten `EventBus.*`-Zugriff in UI-Controllern ✅
- `IUIContext.bus() -> IEventBus` — neuer Accessor, Basis-Vertrag `null` (wie alle anderen Getter)
- `UIContext.from_registry()` löst `IEventBus` aus `ServiceKeys.EVENT_BUS` auf — derselbe Registry-Key wie Services, kein zweiter Adapter
- 10 Controller umgestellt: `ContextButtonController`, `ContextMenuController`, `EquipmentUIController`, `FloatingTextController`, `InteractionButtonController`, `NotificationController`, `PauseMenuController`, `PlayerHPController`, `QuestPanelController`, `SkillPanelController` — alle nehmen jetzt `ctx: IUIContext` entgegen, lesen Events über `_ctx.bus().<namespace>()`; rohe Namespace-Parameter (`UIEvents`/`PlayerEvents`/`Object`) entfernt wo sie parallel zum AutoLoad-Zugriff existierten
- 7 `*Component.build()`-Fabriken + `HUDBuilder.build_all()` geben `ctx` jetzt an die obigen Controller weiter; tote `EventBus.ui`/`EventBus.player`-Lokalvariablen in `HUDBuilder` entfernt
- `ADR-012` dokumentiert die Entscheidung, schließt die UI-Hälfte von H-07/ADR-011 ab; Cross-Referenz von ADR-011 aus gesetzt
- Neuer Review-Blocker in `CONTRIBUTING.md` (2.1 Schichtentrennung + 7.8 Verbotene Muster)
- **Bewusst out-of-scope, als neuer P2-Befund I-02b dokumentiert:** `IEntityContext.get_event_bus() -> Node: return EventBus` — strukturell verwandt (behauptet Testbarkeit, Rückgabetyp verhindert sie), aber unbenutzt und außerhalb dieses Rounds
- **Tests:** `tests/unit/test_ui_context.gd` (8 Tests: Interface-Vertrag, `for_test()`-Isolation, `from_registry()`-Auflösung inkl. Regression auf bestehende Getter) + 3 Controller-Beispieltests (`test_notification_controller.gd`, `test_player_hp_controller.gd`, `test_skill_panel_controller.gd`) — je inklusive Gegenbeweis, dass der echte `EventBus`-AutoLoad die Controller nicht mehr erreicht. Restliche 7 Controller bleiben IV-03 (unverändert offen, nicht Teil dieses Fixes).

## ROUND 17 — I-03: Status-Effekte vollständig verdrahtet ✅

#### I-03: apply_weapon_on_hit() match auf StatusEffect.Kind — POISON + BURN ✅

Der Audit-Befund ("Fundament ohne Haus") war zur Zeit des Schreibens korrekt, wurde aber bereits teilweise behoben: `apply_weapon_on_hit()` existierte und war in `EnemyNPC._on_interacted()` eingehängt. Verbleibende Lücken vor diesem Round:
- `apply_weapon_on_hit()` hardcodiert `apply_poison()` statt per `match` auf `weapon.on_hit_effect` zu dispatchen — BURN wurde nie ausgelöst
- `test_equipment_ui.gd` hatte keinen Positiv-Test für `apply_weapon_on_hit()` mit injiziertem Equipment
- `before_each()` injizierte kein `MockEventBus` → `_bus.ui().emit_floating_text()` hätte im Positiv-Pfad gecrasht

**Fixes:**
- `CombatSystem.apply_weapon_on_hit()`: `match weapon.on_hit_effect` auf `StatusEffect.Kind` — POISON, BURN, unbekannte Werte mit `log_warn`. Stale Kommentare ("steht noch aus", "NICHT verdrahtet") entfernt
- `test_equipment_ui.gd`: `MockEventBus` in `before_each()` + `ServiceKeys.EQUIPMENT` korrekt injiziert; 5 neue `apply_weapon_on_hit`-Tests:
  - `test_apply_weapon_on_hit_does_nothing_without_equipment_service` — Negativ (Combat ohne Dep)
  - `test_apply_weapon_on_hit_with_poison_weapon_registers_status_effect` — Positiv (Giftdolch → 1 StatusEffect)
  - `test_apply_weapon_on_hit_poison_ticks_deal_damage` — Tick-Assertion (exakt 5 HP TRUE-Schaden nach 1s)
  - `test_apply_weapon_on_hit_with_burn_weapon_registers_burn_effect` — BURN-Waffe
  - `test_apply_weapon_on_hit_no_double_stack_same_source_target` — Kein-Stacking-Garantie
  - `test_weapon_without_on_hit_effect_skips_poison` — überarbeitet: prüft jetzt via `apply_weapon_on_hit()` statt direkt

## SPRINT F — Multiplayer-Correctness: Verbleibende Lücken aus Reviewer-Feedback

### F-2: `peer_id` in `WorldService.spawn_entity()` + Callbacks ✅

**Problem:** `WorldService.spawn_entity()` leitete keinen `peer_id`-Parameter weiter.
`RespawnService` und `ChunkManager` nutzten Closures ohne `peer_id` — für World-Entities
(Bäume, Erze, Gegner) korrekt (immer Server-Autorität), aber ein Player-Respawn hätte die
falsche Autorität erhalten.

**Fixes:**
- `WorldService.spawn_entity()`: neuer Parameter `peer_id: int = 1` — kein Breaking Change,
  alle bestehenden Callsites nutzen automatisch den Default.
- Respawn-Closure in `WorldService.on_ready()`: `func(t, p, pid: int = 1) -> Node3D`
  — leitet `pid` an `spawn_entity()` weiter.
- ChunkManager-Closure in `on_world_scene_ready()`: analog aktualisiert.
- `RespawnService._do_respawn()`: übergibt explizit `peer_id=1` an Spawn-Callback
  (dokumentiert: World-Entities sind immer Server-autoritär; Player-Respawn würde
  einen Queue-Eintrag mit `peer_id`-Feld brauchen — als zukünftiger Erweiterungspunkt markiert).
- `RespawnService`-Docstring: Callable-Signatur auf `(type_id, position, peer_id: int)` aktualisiert.

**Tests:** `test_respawn_service.gd` — 2 neue Tests:
- `test_respawn_calls_spawn_callback_with_peer_id_1` — verifiziert peer_id=1 für World-Entities
- `test_respawn_spawn_callback_old_signature_still_works` — Rückwärtskompatibilität (Callable ohne peer_id)

`test_world_service.gd` — 2 neue Tests:
- `test_spawn_entity_accepts_peer_id_parameter` — Signatur akzeptiert peer_id ohne Crash
- `test_spawn_entity_default_peer_id_is_1` — Default greift ohne explizite Angabe

---

### F-1: Custom Spawn/Despawn via `MultiplayerSpawner`-Signale ✅

**Problem:** `_setup_multiplayer_spawner()` nutzte `add_spawnable_scene()` mit `.gd`-Pfaden.
`MultiplayerSpawner.add_spawnable_scene()` akzeptiert ausschließlich `.tscn`-Pfade —
`.gd`-Pfade werden zur Laufzeit beim ersten Spawn-Versuch abgelehnt.

**Entscheidung gegen `.tscn`-Wrapper:** Das Projekt instanziiert Entities bewusst via
`GDScript.new()` (EntityRegistry, EntityPool). 8 leere `.tscn`-Wrapper-Dateien nur für
den MultiplayerSpawner wären Architektur-Fremdkörper.

**Fixes:**
- `EntityRegistry.get_path_to_type_map()` — neue Methode: gibt `{ script_path: type_id }` zurück.
  Umgekehrte Abbildung der internen `_definitions`-Map. Gibt eine Kopie zurück (kein shared state).
- `EntityOrchestrator.get_registry()` — neuer Accessor: gibt `_registry` nach außen für
  `WorldService._setup_multiplayer_spawner()`.
- `WorldService._setup_multiplayer_spawner()` umgeschrieben:
  - `ms.spawn_function`: Closure über `path_map` (einmalig gebaut) + `registry_ref`.
    Empfängt `data` (script_path-String vom Server), löst via `path_map` zu `type_id` auf,
    ruft `registry_ref.instantiate(type_id)` auf.
    Kein `add_child`, kein `on_spawn`, kein UUID-Tracking — der Spawner übernimmt `add_child`,
    State-Sync läuft via `MultiplayerSynchronizer`.
  - `ms.despawn_function`: Closure ruft `node.queue_free()` auf (Client-seitig ausreichend,
    Server hält autoritativen Zustand).
  - Log-Meldung zeigt jetzt `path_map.size()` statt hardcodierter 8.

**Tests:**
- `test_entity_registry_path_map.gd` (neu, 7 Tests): Leer-Map, Key/Value-Präsenz,
  Zwei-Typen, Leerpfad-Exclusion, Bijektivität, Kopie-Isolation.
- `test_world_service.gd` (4 neue Tests): Path-Map ≥ 8 Einträge, `player`-type_id vorhanden,
  keine leeren Keys, `get_registry()` Rückgabetyp.

---

### F-3: Player + EnemyNPC `MultiplayerSynchronizer` `replication_interval` ✅

**Problem:** `_setup_multiplayer_sync()` in `Player.gd` und `EnemyNPC.gd` setzte
`replication_interval` nicht → Sync lief per-frame (60+ Hz). Unnötige Netzwerklast,
besonders bei vielen gleichzeitigen Entities.

**Analyse Authority-Richtung:** Der Reviewer-Hinweis "Clients sehen andere Clients nicht"
ist in der aktuellen Implementierung bereits korrekt gelöst:
`EntityOrchestrator.spawn_entity()` ruft `set_multiplayer_authority(peer_id)` nach
`add_child()` und *vor* `on_spawn()`. `_setup_multiplayer_sync()` läuft in `on_spawn()` —
der Synchronizer wird also immer *nach* korrekter Authority erstellt.
Ein einzelner `MultiplayerSynchronizer` auf einem Node sendet vom Autoritäts-Peer zu allen
anderen, was Client→Server→andere-Clients korrekt abdeckt.

**Fixes:**
- `Player._setup_multiplayer_sync()`:
  - `sync.replication_interval = 0.05` (20 Hz) gesetzt
  - Kommentar erklärt Autorität + Sync-Richtung explizit
  - Kommentar-Header von "Sprint D" auf "Sprint E / F-3" aktualisiert
  - Log-Meldung nennt jetzt "20Hz"
- `EnemyNPC._setup_multiplayer_sync()`:
  - `sync.replication_interval = 0.1` (10 Hz) gesetzt
  - Begründung im Kommentar: Gegner weniger latenz-kritisch als Player
  - Log-Meldung nennt jetzt "10Hz"

**Tests:** `test_player_gd.gd` — 6 neue Tests (F3-01…F3-06):
- F3-01: Player hat `MultiplayerSync`-Child nach `on_spawn()`
- F3-02: Player-Interval = 0.05s (20 Hz)
- F3-03: Player-Config hat 3 Properties (position, rotation, velocity)
- F3-04: Authority-Reihenfolge — kein Crash wenn `set_multiplayer_authority()` vor `on_spawn()`
- F3-05: EnemyNPC-Stub-Sync hat Interval = 0.1s (10 Hz)
- F3-06: EnemyNPC-Sync hat 2 Properties (position, rotation — kein velocity)

---

### F-4: Docs + ADR-010 ✅

**`docs/services.md`:**
- `WorldService`-Deps-Zeile korrigiert: war `savesystem, data` (veraltet), jetzt
  `savesystem, event_bus` (required) + alle optionalen Deps explizit aufgelistet.
- `EntityOrchestrator`-Zeile: Hinweis auf `multiplayer_authority(peer_id)` ergänzt.
- `EntityRegistry`-Zeile: `get_path_to_type_map()` dokumentiert.
- `EnemyNPC`-Zeile: Sync-Interval 10 Hz vermerkt.
- Neuer Abschnitt "Multiplayer-Spawn-Replikation": Custom Spawn/Despawn-Callable-Muster,
  Begründung gegen `.tscn`-Wrapper.
- Neuer Abschnitt "RespawnService spawn_callback-Signatur": `peer_id`-Parameter dokumentiert.
- Neuer Abschnitt "MultiplayerSynchronizer-Intervalle": 20 Hz / 10 Hz, Sync-Richtung.

**`docs/adr/010-multiplayer-authority-tiers.md`:**
- Status-Header: Sprint-F-Konkretisierung vermerkt.
- Neuer Unterabschnitt "Spawn-Replikation (Sprint F)": Entscheidung gegen `.tscn`-Wrapper,
  Custom Callable-Mechanismus, Path-Map-Strategie, Authority-Reihenfolge beim Sync-Setup.

---

## Sprint F — KOMPLETT ✅

Alle drei Reviewer-Lücken geschlossen:
- **F-1** ✅ Custom Spawn/Despawn via `MultiplayerSpawner`-Signale (`.gd`-Pfad-Problem behoben)
- **F-2** ✅ `peer_id` in `WorldService.spawn_entity()` + alle Callbacks
- **F-3** ✅ `replication_interval` 20 Hz (Player) / 10 Hz (EnemyNPC); Authority-Reihenfolge verifiziert
- **F-4** ✅ ADR-010 + services.md nachgeführt



### SPRINT A — Legacy-Cleanup ✅

- `Services.gd` gelöscht; Autoload aus `project.godot` entfernt
- `from_services()`-Stubs gelöscht (`EntityContext`, `UIContext`); `HUDManager`-Default → fail-fast `push_error`
- `EntityOrchestrator.spawn_entity()`: `_entity_services_injected`-Guard + else-Fallback entfernt — `from_deps()` ist einziger Pfad
- `BootPipeline`: `Services.populate_global/session/clear*()`-Calls entfernt
- `SimpleTerminal.gd`, `Main.gd`, `IntegrationTest.gd`: alle `Services.xyz`-Live-Calls → `ServiceOrchestrator.get_service()` (neu hinzugefügt)
- Alle `# MIGRATION-010:`, `# TD-NN:`, `# H-0N:`, `# ARCH-NN:`, `# DEBT-NN:`, `# BUG-NN:`-Kommentare aus scripts/ + tests/ entfernt (159 + 50 Dateien)
- Keine `@deprecated`-Tags mehr vorhanden

### SPRINT B — `@rpc`-Annotationen + SessionManager ✅

#### `@rpc`-Fix: `call_local` → `call_remote` in `NetworkBridge`
Alle 6 `_rpc_*`-Methoden hatten `"call_local"` — damit führte der sendende Client jede
RPC-Funktion auch lokal aus. Der `_is_authority()`-Guard verhinderte zwar State-Mutation,
aber der Aufruf selbst war semantisch falsch und unnötig.
Geändert: `_rpc_add_item`, `_rpc_start_quest`, `_rpc_complete_quest`, `_rpc_add_xp`,
`_rpc_set_state`, `_rpc_equip_item`, `_rpc_unequip_item` → `"call_remote"`.

#### `send_set_state()` ergänzt in `NetworkBridge`
`_rpc_set_state()` existierte ohne öffentlichen `send_set_state()`-Wrapper. Analog zu allen
anderen `send_*()`-Methoden ergänzt.

#### `SessionManager` — neuer globaler Service
`scripts/services/SessionManager.gd` (extends ServiceNode, global scope):
- `create_server(port, max_clients)` → ENetMultiplayerPeer.create_server()
- `join_server(address, port)` → ENetMultiplayerPeer.create_client()
- `close()` → Peer entfernen, Slots leeren
- Player-Slot-Registry: `register_player_slot(peer_id, player_id)` / `get_player_id_for_peer(peer_id)`
- Lauscht auf `EventBus.system.host_game_requested` / `join_game_requested` (von MainMenuController)
- Emittiert `EventBus.system.hosting_started` / `joined_as_client` / `connection_to_server_failed` / `network_peer_disconnected`
- Emittiert eigene Signale: `peer_joined`, `peer_left`, `server_started`, `client_connected_to_server`, `client_connection_failed`, `server_connection_lost`

#### `ServiceKeys.SESSION_MANAGER` ergänzt
#### `BootstrapConfig.tres` — SessionManager in `global_services` eingetragen (load_steps 27→28)
#### `ServiceInstaller` — `SESSION_MANAGER` in `CRITICAL_GLOBAL` ergänzt

#### `SystemEvents.gd` — 6 neue Multiplayer-Events
`host_game_requested(port)`, `join_game_requested(address, port)`, `hosting_started(port)`,
`joined_as_client()`, `connection_to_server_failed()`, `network_peer_disconnected()`

#### `BootPipeline` — Phase S8.7: Lokaler Spieler-Slot registrieren
Nach Phase S8.6 (Late-Network-Inject): `SessionManager.register_player_slot(local_peer, player_id)`.

#### `ServiceOrchestrator`
- `_connect_session_manager()` nach `boot_global()`: verbindet `client_connected_to_server` →
  `_on_client_connected_to_server()` — Auto-Boot-Session für Clients mit player_id `"client_N"`.

#### `MainMenuController` — Multiplayer-UI State Machine
4 Zustände: `CHARACTERS`, `NET_SETUP`, `HOST_ACTIVE`, `CONNECTING`.
[Multiplayer]-Button → NET_SETUP-Panel mit Host- und Join-Sektion.
Host-Flow: Port-Eingabe → `emit_host_game_requested()` → `hosting_started` → HOST_ACTIVE → Char-Wahl.
Join-Flow: IP+Port → `emit_join_game_requested()` → `joined_as_client` (auto via Orchestrator) → PLAYING.

#### `MainMenu.tscn` — NetPanel-Nodes ergänzt
`NetPanel/HostSection/{HostPortEdit, StartHostButton}`,
`NetPanel/JoinSection/{JoinAddressEdit, JoinPortEdit, StartJoinButton}`,
`NetPanel/BackButton`, `CenterContainer/MultiplayerButton`, `CenterContainer/StatusLabel`.

#### Tests: `tests/unit/test_session_manager.gd` — 12 Tests (SM-01…SM-12)
- `@rpc("any_peer", "call_remote", "reliable")` auf alle `_rpc_*`-Methoden in NetworkBridge
- `SessionManager`: create_server/join_server, peer_connected/disconnected, Player-Slot-Registry
- Host/Join-UI (minimal)
- `NetworkBridge.send_*()` für Quest, Inventory, Equipment (analog send_add_xp)

### SPRINT C — World Authority + EnemyAI-Gate ✅

- `set_multiplayer_authority(1)` in `EnemyNPC._ready()`, `IronOre._ready()`, `OakTree._ready()`, `AnimalBase._ready()`, `PetComponent._ready()`
- `_physics_process()` hinter `if not is_multiplayer_authority(): return` in: `EnemyNPC`, `AnimalBase`, `PetComponent`
- `EnemySpawner` ist `RefCounted` (kein Node) — kein Authority-Call nötig; Authority der gespawnten Entities liegt bei `EnemyNPC` selbst

### SPRINT E — Multiplayer-Correctness: Entity Authority + Spawning + Snapshot-Timing ✅

**Gefundene Lücken nach Sprint D (Code-Review):**

#### E-1: `set_multiplayer_authority(peer_id)` auf gespawnten Entities ✅
- `EntityOrchestrator.spawn_entity()`: nach `add_child()` wird `entity.set_multiplayer_authority(peer_id)` aufgerufen wenn `peer_id != 1`
- Server-Entities (EnemyNPC, Tiere, Objekte) behalten peer 1 aus `_ready()` — idempotent, kein Overhead

#### E-2: `WorldSpawner` übergibt `peer_id` beim Player-Spawn ✅
- `WorldSpawner.spawn_all(world_root, peer_id: int = 1)` — neuer Parameter
- `WorldService.on_world_scene_ready()`: ermittelt `local_peer` via `_session_manager.get_local_peer_id()` und übergibt ihn an `spawn_all()`
- `WorldService`: `_session_manager: SessionManager` neue optionale Dep; in `configure()` aufgelöst
- `BootstrapConfig.tres`: `"session_manager"` zu `world`-deps ergänzt (Global-Service, via fallback_registry auflösbar)

#### E-3: `MultiplayerSpawner` für Welt-Entities ✅
- `WorldService._setup_multiplayer_spawner(world_root)`: erstellt `MultiplayerSpawner`, registriert alle 8 Entity-Pfade, hängt ihn als Child in `world_root`
- Aufruf in `on_world_scene_ready()` vor `spawn_all()` — nur wenn Server mit aktivem Peer
- Solo (Tier 1) und Tests: Bedingung nicht erfüllt, kein Spawner, kein Overhead

#### E-4: Initial-Snapshot-Timing korrigiert ✅
- **Vorher (Sprint D, falsch):** Server schickt Snapshot bei `peer_connected` — Client hat noch keine Session, `apply_remote_state()` war geblockt
- **Jetzt:** Client fordert Snapshot selbst an nach vollständigem Session-Boot
- `NetworkBridge.send_request_initial_state()`: Client-Methode, ruft `rpc_id(1, "_rpc_client_requests_initial_state")`
- `NetworkBridge._rpc_client_requests_initial_state()`: `@rpc("any_peer", "call_remote", "reliable")` — Server antwortet mit `rpc_id(requester, "_rpc_receive_initial_state", state)`
- `BootPipeline` Phase S8.9: ruft `net.send_request_initial_state()` nach S8.8 (MeshCache)
- `SaveSystem.apply_remote_state()`: Guard auf `_active_player_id` entfernt — Client hat zu diesem Zeitpunkt bereits eine aktive Session

#### Initial-Snapshot an neue Peers
- `SaveSystem.get_full_state()` — gibt `_loaded_state.duplicate()` zurück (flache Kopie)
- `SaveSystem.apply_remote_state(state)` — übernimmt Server-Snapshot auf Client; Guard wenn Session bereits aktiv
- `NetworkBridge._save_system: SaveSystem` — neue optionale Dep; in `configure()` aufgelöst
- `NetworkBridge._on_peer_connected()`: Server ruft `rpc_id(peer_id, "_rpc_receive_initial_state", state)` nach `emit_save_pre_flush()` (via `get_full_state()`)
- `NetworkBridge._rpc_receive_initial_state(state)`: `@rpc("authority", "call_remote", "reliable")` — Client empfängt und ruft `_save_system.apply_remote_state()` auf
- `BootstrapConfig.tres`: `"savesystem"` zu `network_bridge`-deps ergänzt

#### MultiplayerSynchronizer — Player
- `Player._setup_multiplayer_sync()`: erstellt `MultiplayerSynchronizer` mit `SceneReplicationConfig` für `position`, `rotation`, `velocity`
- Aufruf in `on_spawn()` nach `set_physics_process(true)`

#### MultiplayerSynchronizer — EnemyNPC
- `EnemyNPC._setup_multiplayer_sync()`: erstellt `MultiplayerSynchronizer` für `position`, `rotation` (kein `velocity` — Clients führen keinen `_physics_process` aus, Sprint C)
- Aufruf in `_ready()` nach `EnemyAttack.setup_interactable()`

---

## ROUND 18 — I-02b: IEntityContext.get_event_bus() → IEventBus ✅

- `IEntityContext.get_event_bus()` Rückgabetyp `Node` → `IEventBus`, Default-Impl gibt `null` (kein AutoLoad-Hardcode mehr)
- `EntityContext`: `_bus: IEventBus`-Feld + `get_event_bus()` Override; `from_deps()` nimmt optionalen `bus`-Parameter
- `EntityOrchestrator.spawn_entity()`: leitet `_bus` an `EntityContext.from_deps()` weiter
- `test_entity_context.gd`: 3 alte Tests durch 3 neue ersetzt — `null`-by-default, MockEventBus-Injectable, Basis-Interface gibt kein AutoLoad zurück

---

## ROUND 19 — II-02: CombatSystem.player_melee_damage() SkillSystem als Dep ✅

- `CombatSystem`: `_skill_system: SkillSystem`-Feld, in `configure()` über `ServiceKeys.SKILL_SYSTEM` (optional) gelesen
- `player_melee_damage(skill_system, player_id)` → `player_melee_damage(player_id)` — Parameter entfernt
- `EnemyNPC._on_interacted()`: `var skill`-Lokale entfernt, `combat.player_melee_damage("player")` direkt
- `BootstrapConfig.tres`: `deps` für `combat` um `"skill_system"` erweitert
- `test_combat_system.gd`: `before_each()` injiziert `MockEventBus`; Skill-Test erstellt eigene `CombatSystem`-Instanz mit `SkillSystem`-Dep; alle seeded-RNG-Tests bekommen `EVENT_BUS` aus `_bus`

---

## ROUND 20 — I-05: Authority Guards (retroaktiv verifiziert) ✅

Alle drei Methoden (`on_item_add_confirmed`, `on_equip_confirmed`, `on_unequip_confirmed`) haben Guards bereits seit C-02 (Round 13). Finding war zum Zeitpunkt des Audits korrekt; wurde seither behoben. Keine Code-Änderungen nötig.

---

## ROUND 21 — II-01: lint_services_access.sh ✅

- `scripts/ci/lint_services_access.sh` erstellt (analog zu `lint_servicenode.sh`)
- Prüft: keine Live-Calls auf `Services.<name>` in `scripts/ui/`, `scripts/player/`, `scripts/world/combat/`, `scripts/world/objects/`, `scripts/interaction/`
- Kommentare und Docstrings korrekt ausgeschlossen (inline `#`-Splitting)
- ALLOWLIST für dokumentierte Ausnahmen (derzeit leer — alle Verletzungen behoben)
- Läuft sauber durch auf aktuellem Stand: `OK  Keine direkten Services.xyz-Calls in UI/Entity-Schichten gefunden.`

---

## ROUND 22 — IV-03: 7 UI-Controller Tests ✅

Neue Testdateien für verbleibende Controller:
- `test_context_button_controller.gd` — proximity_changed → Button sichtbar; AutoLoad-Isolation
- `test_context_menu_controller.gd` — request_context_menu-Verbindung; show([]) kein Crash; Isolation
- `test_floating_text_controller.gd` — xp_gained → Label spawnt in Canvas; Isolation
- `test_interaction_button_controller.gd` — proximity_changed → Button aktiv; Isolation
- `test_pause_menu_controller.gd` — _on_save() emittiert save_requested auf Mock; Isolation
- `test_quest_panel_controller.gd` — quest_started → panel sichtbar; Isolation

Jede Datei: 3 Tests — Signal-Verbindung auf injiziertem Bus, Positiv-Pfad via Mock, AutoLoad-Isolation.

---

## ROUND 23 — III-02/III-03/IV-01/IV-02 + AUDIT-03 Abschluss ✅

**III-02:** ADR-004 nachgeführt — Entscheidungstabelle, Negativ/Risiken, Tech-Debt-Abschnitt alle auf ✅-Stand (I-01 war Round 15).

**III-03:** ADR-001 Ablösungsbedingung war bereits korrekt formuliert (SceneTree-Kopplung, nicht Constructor-Syntax). Retroaktiv verifiziert, kein Handlungsbedarf.

**IV-01:** Round-Trip-Tests für alle drei Services nachträglich verifiziert — bereits vorhanden in `test_inventory_system.gd`, `test_quest_service.gd`, `test_skill_system.gd`.

**IV-02:** `test_network_bridge_contract.gd` — 3 neue Tier-Tests:
- `test_tier1_request_add_xp_calls_on_confirmed_locally` — kein Peer → lokaler Aufruf
- `test_tier2_request_add_xp_does_not_call_on_confirmed_locally` — MockNetworkBridgeAsPeer → kein lokaler State
- `test_tier2_skill_request_add_xp_routes_via_rpc_not_local` — SkillSystem._network = MockBridge → XP bleibt 0

`MockNetworkBridgeAsPeer` überschreibt `has_peer()→true`, `is_server()→false`, `get_local_peer_id()→2` und trackt RPC-Aufrufe ohne echtes SceneTree-Multiplayer.

**AUDIT-03 komplett:** Alle 20 Findings (I-01 bis IV-03) sind ✅.



Merged into `docs/audit/AUDIT-03-meta-review.md`.
Completed findings marked ✅ and removed from open-items list as each bug is fixed.

---

## ROUND 24 — Runtime-Verified Bugs (erste echte Godot-Ausführung + GUT-Lauf)

Erster Durchlauf mit tatsächlich ausgeführtem Godot-Build (`wildgrove_2026-07-02_01-34-14.log`)
und GUT-Testlauf (`gut-output.log`, 95 von 1002 Tests fehlgeschlagen). AGENT.md Punkt "Nothing
has been executed" ist damit für diese Session hinfällig — mehrere Befunde sind runtime-only
und wären durch reines Lesen nicht aufgefallen.

#### BUG-19: `BootstrapConfig.tres` — ungültiges `#`-Kommentarzeichen zerstört WorldService-Deps ✅
- **Root Cause:** `.tres` ist INI-artig, Kommentare beginnen mit `;`, nicht `#`. Eine Zeile
  `# ARCH-1: entity service deps für EntityContext.from_deps() — alle optional.` direkt vor
  `Resource_worldservice`s `deps`-Property hat die Parser-Zuordnung zerstört — `deps` fiel
  still auf `[]` zurück statt der 15 deklarierten Einträge.
- **Kaskade (alles ein einziger Root Cause, bestätigt durch Logzeilen 219–392 und den
  GUT-Lauf mit identischer `require('event_bus') FEHLT`-Signatur in 24+ Tests):**
  - `ServiceDeps.require('event_bus')` in `WorldService.configure()` schlägt fehl → `_bus` bleibt `null`.
  - `WorldService.on_ready()` crasht bei `_bus.world()` ("Nonexistent function 'world' in base 'Nil'"),
    bevor `respawn.set_spawn_callback()` erreicht wird.
  - `RespawnService.on_tick()`: Assertion "`_spawn_cb` fehlt" — direkte Folge des obigen Crashs.
  - `WorldGenerationService` wird ebenfalls nicht injiziert (`WARN: WorldGenerationService fehlt`).
- **Fix:** `#` → `;` in `config/BootstrapConfig.tres`. Keine Code-Änderung nötig, reiner Datenfehler.
- **Sweep:** `grep -rn "^#" --include=*.tres .` — keine weiteren Treffer im Projekt.
- Test: `test_bootstrap_config_integration.gd::test_world_service_deps_are_fully_declared` (neu) —
  prüft die geladenen `deps`-Werte direkt statt nur Auflösbarkeit (die bestehenden Tests hätten
  eine leere `deps`-Liste nicht bemerkt, da weniger Deps für den Resolver *leichter* aufzulösen sind).

#### BUG-20: `ServiceInstaller.RECOMMENDED_SESSION` — fehlende Array[String]-Typisierung ✅
- **Root Cause:** `const RECOMMENDED_SESSION := ["respawn", ...]` (Typinferenz via `:=`) ergibt
  einen untypisierten `Array`, nicht `Array[String]`. `_check(recommended: Array[String])`
  erwartet aber den typisierten Array — Engine-Fehler "Invalid type in function '_check'... argument 3"
  beim Aufruf, `install_session()` liefert dadurch `false` zurück.
- **Symptom:** `Phase C7 FAIL — kritischer Session-Service fehlt`, obwohl alle kritischen Services
  (`CRITICAL_SESSION`) tatsächlich registriert waren — der Fehler lag ausschließlich in der
  Typisierung der *empfohlenen* (nicht kritischen) Liste.
- **Fix:** `const RECOMMENDED_SESSION: Array[String] = [...]` — explizite Typisierung.
- Test: `tests/unit/test_service_installer.gd` (neu, 4 Tests) — Typ-Check direkt + Verhaltens-Tests
  für install_session() mit/ohne kritische bzw. empfohlene Services.

#### BUG-21: `MainMenuController.inject_save_system()` — nie aufgerufen, Charakterliste immer leer ✅
- **Root Cause:** `inject_save_system()` existiert seit ADR-012 als vorgesehener DI-Punkt, aber
  kein Aufrufer wurde je gebaut (`ServiceOrchestrator._wire_hud()` deckt nur die Session-HUD ab,
  nicht das App-Scope-MainMenu — dokumentiert, aber nie umgesetzt, siehe ADR-012 Zeile 83).
  `_save_system` blieb dauerhaft `null`.
- **Symptom:** `_refresh_character_list()` loggt `SaveSystem nicht injiziert.` und bricht ab —
  gespeicherte Charaktere erscheinen nie im Hauptmenü, Spieler kann nie einen bestehenden
  Spielstand fortsetzen (nur "Neuer Charakter" funktioniert, da das ohne SaveSystem auskommt).
- **Fix:** Push-Pattern analog `WorldScopeInitializer` (bereits etabliert, kein neuer Mechanismus):
  - `scripts/ui/MenuScopeInitializer.gd` (neu) — Child-Node in `MainMenu.tscn`, emittiert
    `menu_ready(menu_root: Control)` in `_ready()`.
  - `MainMenu.tscn`: `MenuScopeInitializer`-Node unter Root ergänzt.
  - `ServiceOrchestrator._ready()`: `_watch_for_menu_initializer()` — `get_tree().node_added`
    lauscht **dauerhaft** (nicht one-shot wie beim World-Pendant, da MainMenu bei jedem
    `main_menu_requested` neu geladen wird) auf `MenuScopeInitializer`-Instanzen und injiziert
    `SaveSystem` aus dem App-Scope in den MainMenuController-Root.
- Test: `tests/unit/test_main_menu_controller.gd` (neu, 3 Tests) — Injektion füllt Charakterliste,
  fehlende Injektion lässt sie leer (reproduziert exakt den Log-Befund), `MenuScopeInitializer`
  emittiert den korrekten Parent.
- `docs/services.md`: BUG-21-Hinweis im EventBus/DI-Abschnitt ergänzt (kein `IUIContext`-Fall,
  separater Mechanismus).

#### BUG-22: `TerminalController.handle_button_input()` — `global_position` auf Touch-Events ✅
- **Root Cause:** `InputEventScreenTouch`/`InputEventScreenDrag` haben nur `position` (Viewport-
  lokal), kein `global_position` — das existiert nur auf `InputEventMouseButton`/`MouseMotion`.
  Der Code griff für beide Eventfamilien einheitlich auf `.global_position` zu.
- **Symptom:** Bei jedem Touch auf den Terminal-Toggle-Button: `Invalid access to property or key
  'global_position' on a base object of type 'InputEventScreenTouch'` (Zeilen 25 + 30, wiederholt
  bei jedem Touch — betrifft ausschließlich mobile/Touch-Eingabe, Maus war nie betroffen).
- **Fix:** `_event_position(event: InputEvent) -> Vector2` Helper — liefert `global_position` für
  Maus-Events, `position` für Touch/Drag-Events. Ersetzt alle 3 `.global_position`-Zugriffe in
  `handle_button_input()` (inkl. Zeile 34, die denselben Bug für Drag noch nicht gezeigt hatte,
  aber denselben Fehler produziert hätte).
- Test: `tests/unit/test_terminal_controller.gd` (neu) — Drag/Toggle mit `InputEventScreenTouch`
  und `InputEventScreenDrag`, keine Errors, Button bewegt sich korrekt.

**Nicht Teil dieser Runde (aus GUT-Log ersichtlich, aber nicht Ursache der App-Log-Crashes):**
`require('savesystem') FEHLT` (10 Vorkommen) und diverse `GameSave`/`Equipment`-Fehler in
Tests, die eigene Mock-Wiring-Lücken zu sein scheinen (unverifiziert) — als Folgearbeit
vorgemerkt, nicht in dieser Runde angefasst.

`QueuePresentKHR failed / VK_ERROR_SURFACE_LOST_KHR` am Logende: Vulkan-Renderer-/Fenster-Fehler
beim Schließen, kein GDScript-Code-Pfad betroffen — keine Änderung, als Infra-Beobachtung notiert.

---

## ROUND 25 — Regression + systemischer Test-Fixture-Rückstand (neuer GUT-Lauf: 99 Failing, neues Game-Log)

Ausgangslage: Nutzer hat nach Runde 24 ein frisches Game-Log
(`wildgrove_2026-07-02_01-53-45.log`) und einen frischen GUT-Lauf
(`gut-test-log__2_.zip`, 99/1010 Failing, vorher 95/1002) geliefert.

#### BUG-23: BUG-21-Fix hält im echten Betrieb nicht — MainMenuController/SaveSystem-Injection

Das neue Game-Log zeigt den EXAKT gleichen Fehler wie vor dem BUG-21-Fix in
Runde 24 ("[ERROR] [MainMenuController] SaveSystem nicht injiziert."), obwohl
BUG-21 als ✅ dokumentiert war. Auffällig: im Log fehlen komplett die
INFO-Zeilen von `BootPipeline.boot_app()` (z. B. "APP BOOT START", "Phase 1
OK" etc.) vor dem Fehler — das deutet darauf hin, dass `ServiceOrchestrator`
(Autoload #4) zum Zeitpunkt von `MainMenuController._ready()` noch nicht
(vollständig) gelaufen ist, entgegen der eigentlich garantierten
Autoload-vor-Hauptszene-Reihenfolge. Konnte die genaue Ursache dafür NICHT
zweifelsfrei statisch verifizieren (kein Godot zum Ausführen verfügbar) —
siehe Diagnose-Log unten für den nächsten Capture.

Root-Cause-unabhängiger Fix (robust gegen die exakte Ready-Reihenfolge):
- `MainMenuController.inject_save_system()` ruft jetzt selbst
  `_refresh_character_list()` auf, wenn die aktuelle Ansicht CHARAKTERE zeigt
  (Selbstheilung — die Charakterliste füllt sich, sobald die Injektion
  eintrifft, egal wann).
- Log-Level für "SaveSystem noch nicht injiziert" von ERROR auf WARN
  runtergestuft (erwarteter Zwischenzustand, kein echter Fehler — hat auch
  GUT-Tests unnötig als failed markiert).
- `ServiceOrchestrator._ready()`: Diagnose-Log als allererste Zeile, damit
  ein künftiger Log-Capture sofort zeigt ob/wann der Autoload überhaupt
  läuft.
- Tests in `test_main_menu_controller.gd` aktualisiert/ergänzt (Selbstheilung
  jetzt explizit getestet).

**NICHT abgeschlossen** — falls der nächste Log-Capture (mit dem neuen
Diagnose-Log) zeigt, dass `ServiceOrchestrator` wirklich zu spät oder gar
nicht läuft, ist das ein separater, tieferliegender Boot-Order-Bug, der noch
untersucht werden muss.

#### BUG-24: `WorldService.configure()` — `event_bus` fälschlich `.require()` statt `.get_optional()` ✅

Einzige der ~15 Deps in `WorldService.configure()`, die `.require()` nutzte —
im Widerspruch zum eigenen Doc-Kommentar der Testdatei ("configure() ohne
optionale Deps → kein Crash, null-Guards greifen") und zu
`test_configure_without_deps_does_not_crash()`. Fix: `get_optional()` +
Null-Guards an allen `_bus`-Nutzungsstellen (`on_ready()`, `on_cleanup()`,
`on_world_scene_ready()`). Behebt 7 von 9 Failures in
`test_world_service.gd` (die restlichen 2 sind ein separates, unten
vermerktes EntityOrchestrator-Problem).

#### Systemischer Test-Fixture-Rückstand: fehlende `MockEventBus`/`SaveSystem`-Injection ✅ (teilweise)

Dominante Fehlersignatur im neuen GUT-Lauf: `require('event_bus') FEHLT`
(225×) und `require('savesystem') FEHLT` (92×) über 29 Testdateien verteilt.
Ursache: mehrere Services verlangen `event_bus`/`savesystem` inzwischen als
Pflicht-Dependency (`.require()`), aber viele `before_each()`-Fixtures wurden
nie mit `MockEventBus`/`SaveSystem`-Instanzen nachgezogen — Runde 24 war der
ERSTE echte GUT-Lauf überhaupt, das war vorher nie sichtbar.

Diese Runde gefixt: `test_game_manager.gd` (11), `test_network_bridge.gd`
(8 von 11 — 3 sind separate, unten vermerkte Probleme),
`test_world_service.gd` (7 von 9 via BUG-24).

**NICHT abgeschlossen** — noch offen (gleiche Ursache, mechanisch
nachziehbar): `test_boot_pipeline.gd`, `test_player_state_service.gd`,
`test_harvestable_entity.gd`, `test_game_save_service_signals.gd`,
`test_inventory_system.gd`, `test_network_bridge_contract.gd`,
`test_service_factory.gd`, `test_service_validator.gd`,
`test_session_manager.gd`, `test_bootstrap_config_integration.gd`,
`test_combat_system.gd`, `test_equipment_service.gd`,
`test_game_save_service.gd`, `test_property_based.gd`, `test_quest_npc.gd`,
`test_quest_service_signals.gd`, `test_stat_modifier.gd`,
`test_player_gd.gd`, `test_player_state_service_signals.gd`,
`test_quest_custom_trigger.gd`, `test_quest_service.gd`,
`test_service_deps.gd`, `test_service_installer.gd`,
`test_service_orchestrator_lifecycle.gd`, `test_skill_system_signals.gd`.

#### Separat vermerkt, NICHT in dieser Runde angefasst (andere Ursache):
- `EntityOrchestrator.spawn_entity()` loggt ERROR ("Kein world_root") bei
  absichtlichen Negativ-Pfad-Tests (uninitialisiert) — GUT markiert das als
  "Unexpected Error" obwohl der Test genau das erwartet. Betrifft
  `test_world_service.gd` (2 Tests) und `test_network_bridge.gd` (1 Test).
- `test_join_game_invalid_address_returns_false`: ENet-eigene Engine-Logs bei
  ungültiger Adresse — gleiche Kategorie (erwarteter Negativ-Pfad, von GUT
  als Fehler gewertet).
- `test_inventory_request_add_item_tier1_without_data`: erwarteter
  "Item-ID unbekannt"-Log, gleiche Kategorie.
- Mögliche generelle Lösung für alle drei: prüfen ob GUT eine
  `expect_error`/`ignore_pending_errors`-API hat und projektweit einführen,
  statt einzelne Log-Level zu ändern.

#### BUG-25: `TerminalController` — Touch-Drag durch `emulate_mouse_from_touch` doppelt angewendet ✅

Nutzer-Report: Der Terminal-Toggle/Close-Button ließ sich seit dem
BUG-22-Fix (Touch-Support für `handle_button_input()`) nicht mehr draggen.
Ursache: `project.godot` hat `pointing/emulate_touch_from_mouse` UND
`pointing/emulate_mouse_from_touch` aktiv — pro physischer Berührung kommen
also ZWEI Events an (z. B. echtes `InputEventScreenDrag` +
dazu emuliertes `InputEventMouseMotion`). Vor BUG-22 wurden Touch-Events
komplett ignoriert (nur Maus verarbeitet → ein Event pro Geste, funktionierte
zufällig). Seit BUG-22 beide Familien verarbeitet werden, wird die
Drag-Bewegung doppelt angewendet → Button "hakelig"/nicht sauber draggbar.

Fix: `TerminalController` sperrt jetzt auf die Event-Familie (Touch ODER
Maus), die die Geste gestartet hat, und ignoriert das jeweils andere
(emulierte) Event bis zum Release. Zwei neue Regressionstests in
`test_terminal_controller.gd`.

## ROUND 26 — BUG-23 tatsächlicher Root-Cause-Fix (Nutzer-Report + Live-Log)

Nutzer-Report: "Neues Spiel" tut nach Klick nichts, Spiel bleibt im
Hauptmenü hängen. Mitgeliefertes Terminal-Log (kompletter Export, nicht nur
Clipboard) zeigt ab dem allerersten Frame:

```
[DEBUG] [Terminal] SimpleTerminal bereit. Befehle: 16
[WARN]  [MainMenuController] SaveSystem noch nicht injiziert — warte auf Push.
[INFO]  [MainMenuController] MainMenuController bereit.
[INFO]  [MainMenuController] Neuer Charakter: 'charakter_...'.
[INFO]  [Events/System] Session angefordert für Charakter 'charakter_...'.
```
— und danach nichts mehr. Insbesondere fehlt komplett die in Round 25 als
Diagnose ergänzte allererste Zeile von `ServiceOrchestrator._ready()`
("_ready() gestartet."). `emit_session_requested()` feuert (Log-Zeile
existiert), aber `ServiceOrchestrator._on_session_requested()` reagiert nie
— kein `╔══ CHARACTER BOOT START ══╗` folgt.

**Root Cause:** `ServiceOrchestrator._ready()` verdrahtete
`EventBus.system.session_requested.connect(_on_session_requested)` sowie
`_watch_for_menu_initializer()` erst NACH `boot_app()`. Jeder Request, der
ankommt bevor dieser Connect passiert ist (Timing-Race zwischen Autoload-
Boot und Main-Szene — die exakte Ursache dafür ließ sich ohne laufendes
Godot nicht weiter eingrenzen, siehe Round 25), geht spurlos verloren:
kein Fehler, keine Log-Zeile, einfach nie eine Reaktion. Das erklärt sowohl
die fehlende SaveSystem-Injektion als auch das tote "Neues Spiel".

**Fix (root-cause-unabhängig, siehe Round-25-Notiz zur selben Strategie):**
- `ServiceOrchestrator._ready()`: `session_requested`-Connect und
  `_watch_for_menu_initializer()` jetzt VOR `boot_app()`.
- Neues `_boot_complete`-Flag + `_pending_session_request`-Puffer:
  `_on_session_requested()` puffert den Request statt ihn zu verlieren,
  falls er vor Boot-Abschluss ankommt; `_ready()` holt ihn nach
  erfolgreichem `boot_app()` automatisch nach.
- Boot-Fehler waren zusätzlich strukturell unsichtbar: der einzige
  `boot_failed`-Listener saß in `Main.gd`/`Main.tscn`, das nie geladen wird
  (`run/main_scene` ist `MainMenu.tscn` direkt, `Main.tscn` ist totes Code).
  `ServiceOrchestrator` loggt Boot-Fehler jetzt zusätzlich selbst laut per
  `AppLogger.log_error()`, und `MainMenuController` hört jetzt ebenfalls auf
  `boot_failed` und zeigt eine sichtbare Status-Meldung statt stillem Hängen.

**Nicht behoben, weil nicht statisch verifizierbar:** die genaue Ursache
der Race selbst (warum `boot_app()`/der Connect überhaupt so spät dran sein
kann) bleibt offen — der Puffer-Fix macht das Verhalten aber unabhängig
davon korrekt. Falls das Problem weiter auftritt, bitte den nächsten
Log-Export schicken: eine `"Session-Request '...' vor Boot-Abschluss —
wird gepuffert."`-WARN-Zeile würde die Race jetzt live bestätigen, statt
dass der Klick einfach nichts tut.

## ROUND 27 — BUG-23 tatsächliche Root Cause gefunden (dank vollständigem GUT-Compile-Log)

Der Nutzer lieferte den `exportlog`-Export (nicht nur Clipboard) UND einen
frischen GUT-Lauf. Der GUT-Lauf enthält, was in keinem bisherigen Log zu
sehen war — den nativen Godot-Compile-Fehler ganz am Anfang:

```
SCRIPT ERROR: Parse Error: Expression is of type "Control" so it can't be
  of type "MainMenuController".
    at: GDScript::reload (res://scripts/core/ServiceOrchestrator.gd:147)
SCRIPT ERROR: Parse Error: Invalid cast. Cannot convert from "Control" to
  "MainMenuController".
    at: GDScript::reload (res://scripts/core/ServiceOrchestrator.gd:151)
ERROR: Failed to load script "res://scripts/core/ServiceOrchestrator.gd"
  with error "Parse error".
ERROR: Failed to create an autoload, script
  'res://scripts/core/ServiceOrchestrator.gd' is not compiling.
```

**Root Cause:** `MainMenuController.gd` deklarierte `extends Node`, ist in
`MainMenu.tscn` aber auf einem `[node name="MainMenu" type="Control"]`
angeheftet. `ServiceOrchestrator._on_menu_initializer_ready(menu_root:
Control)` prüft `menu_root is MainMenuController` und castet
`menu_root as MainMenuController` — der GDScript-Static-Type-Checker sieht
`Control` und `MainMenuController` (deklariert als direktes `Node`-Kind,
nicht `Control`-Kind) als zwei unverwandte Zweige derselben Hierarchie und
lehnt den Cast als statisch unmöglich ab. Das ist kein Warning, sondern ein
harter Compile-Fehler — `ServiceOrchestrator.gd` kompiliert dadurch
komplett nicht, der Autoload wird nie erstellt, `_ready()` läuft NIE (auch
nicht die Round-26-Diagnosezeile, auch nicht der neue Puffer-Pfad — beides
erklärt, warum Round 26 keine Wirkung zeigte: der Fix saß in totem Code).

Das erklärt rückwirkend JEDEN bisherigen Befund zu BUG-23 (Round 24, 25, 26)
lückenlos: keine SaveSystem-Injektion, keine Reaktion auf
`session_requested`, keine Boot-Logs — weil der komplette Autoload nie
existierte, nicht wegen eines Timing-Races.

**Fix:** `MainMenuController.gd`: `extends Node` → `extends Control`
(passend zum tatsächlichen Node-Typ in `MainMenu.tscn`). Damit ist
`MainMenuController` ein echter `Control`-Nachkomme, der Cast in
`ServiceOrchestrator._on_menu_initializer_ready()` ist statisch gültig,
`ServiceOrchestrator.gd` kompiliert wieder, der Autoload läuft.

**Sweep:** alle anderen `WorldScopeInitializer`/`MenuScopeInitializer`-
artigen Cross-Script-Casts geprüft (`WorldScopeInitializer.world_ready`
→ `Node3D`, `World.gd` → `extends Node3D`) — dort stimmen Skript-Basisklasse
und Scene-Root-Typ überein, kein weiterer Fall dieses Musters gefunden.

Die Round-26-Änderungen (Listener vor `boot_app()`, Session-Request-Puffer,
sichtbare `boot_failed`-Anzeige) bleiben als zusätzliche Robustheit
erhalten, waren aber nicht die eigentliche Lösung.

## Output Format

Each round produces a downloadable ZIP of the full project with all changes applied.
ZIP name: `wildgrove_fixed_round_N.zip`

