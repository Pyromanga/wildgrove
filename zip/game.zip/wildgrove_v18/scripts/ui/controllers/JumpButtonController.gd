class_name JumpButtonController
extends Node

const JUMP_VELOCITY: float = 6.0
const LOG_CAT := "JumpBtn"

var _visuals: JumpButtonVisuals


func setup(visuals: JumpButtonVisuals) -> void:
	_visuals = visuals
	_visuals.connect_pressed(_on_jump_pressed)


func _on_jump_pressed() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: CharacterBody3D = players[0] as CharacterBody3D
	if not is_instance_valid(player):
		return
	# Nur springen wenn auf dem Boden
	if player.is_on_floor():
		player.velocity.y = JUMP_VELOCITY
		Logger.log_debug("Sprung ausgelöst.", LOG_CAT)
