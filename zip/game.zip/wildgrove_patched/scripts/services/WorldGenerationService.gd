extends ServiceNode
class_name WorldGenerationService

## WorldGenerationService — Prozedurales Welt-Layout.
##
## DESIGN:
##   Trennt "wo spawnen Entities" (WorldGenerationService) von
##   "was ist gerade in der Welt aktiv" (WorldService/EntityOrchestrator).
##
##   WorldService ruft generate_world_layout() einmalig auf wenn kein Save vorhanden ist.
##   Das Ergebnis wird in WorldData gespeichert und von dort beim nächsten Start geladen.
##
## BIOME-KONZEPT:
##   Biome sind rechteckige Zonen im Welt-Grid.
##   Jede Zone hat Spawnregeln für Entity-Typen.
##   Erweiterbar ohne Änderungen am Core.
##
## Abhängigkeiten: []  (kein Service-Overhead — reiner Algorithmus)

const LOG_CAT := "WorldGen"

## Welt-Konfig — zentral einstellbar
const WORLD_HALF_SIZE := 40         ## Welt geht von -40 bis +40 in X/Z
const MIN_ENTITY_SPACING := 4.0     ## Minimaler Abstand zwischen Entities (Meter)
const MAX_PLACEMENT_TRIES := 20     ## Wie oft versuchen wir eine Position zu platzieren?

## Biome-Definitionen: { "name": { spawn_rules: [...], bounds: Rect2 } }
## Bounds: Rect2(x_min, z_min, width, depth) im Welt-Koordinatensystem
var biomes: Array[Dictionary] = []


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────
func configure(_deps: Dictionary) -> void:
	_register_biomes()
	Logger.log_info(
		"WorldGenerationService konfiguriert. Biome: %d." % biomes.size(), LOG_CAT
	)


func on_ready() -> void:
	Logger.log_info("WorldGenerationService bereit.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Generiert ein komplettes Welt-Layout und gibt es als WorldData zurück.
## Wird von WorldService aufgerufen wenn kein Save vorhanden ist.
##
## Gibt ein Dictionary zurück:
##   { "tree_positions": Array[Vector3], "ore_positions": Array[Vector3] }
func generate_world_layout(seed_value: int = 0) -> Dictionary:
	var t := Logger.log_begin("generate_world_layout(seed=%d)" % seed_value, LOG_CAT)

	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value if seed_value != 0 else int(Time.get_unix_time_from_system())

	var tree_positions: Array[Vector3] = []
	var ore_positions: Array[Vector3]  = []
	var all_placed: Array[Vector3]     = []  # Alle platzierten Positionen für Spacing-Check

	for biome in biomes:
		var rules: Array = biome.get("spawn_rules", [])
		var bounds: Rect2 = biome.get("bounds", Rect2(-WORLD_HALF_SIZE, -WORLD_HALF_SIZE, WORLD_HALF_SIZE * 2, WORLD_HALF_SIZE * 2))

		for rule in rules:
			var type_id: String  = rule.get("type_id", "")
			var count: int       = rule.get("count", 0)
			var y_level: float   = rule.get("y_level", 0.0)

			var placed := 0
			for _attempt in range(count * MAX_PLACEMENT_TRIES):
				if placed >= count:
					break

				var x := rng.randf_range(bounds.position.x, bounds.position.x + bounds.size.x)
				var z := rng.randf_range(bounds.position.y, bounds.position.y + bounds.size.y)
				var pos := Vector3(x, y_level, z)

				if _is_valid_position(pos, all_placed):
					all_placed.append(pos)
					match type_id:
						"oak_tree":  tree_positions.append(pos)
						"iron_ore":  ore_positions.append(pos)
					placed += 1

			Logger.log_debug(
				"Biome '%s' / '%s': %d/%d platziert." % [biome.get("name", "?"), type_id, placed, count],
				LOG_CAT
			)

	var result := {
		"tree_positions": tree_positions,
		"ore_positions":  ore_positions,
	}

	Logger.log_end("generate_world_layout()", t, LOG_CAT)
	Logger.log_info(
		"Welt generiert: %d Bäume, %d Erze." % [tree_positions.size(), ore_positions.size()],
		LOG_CAT
	)
	return result


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

## Registriert alle Biome und ihre Spawn-Regeln.
## Hier zentral erweitern um neue Biome / Entity-Typen hinzuzufügen.
func _register_biomes() -> void:
	biomes.clear()

	# ── Wald-Zone (Nordwest) ──
	biomes.append({
		"name": "forest_nw",
		"bounds": Rect2(-WORLD_HALF_SIZE, -WORLD_HALF_SIZE, WORLD_HALF_SIZE, WORLD_HALF_SIZE),
		"spawn_rules": [
			{ "type_id": "oak_tree", "count": 12, "y_level": 0.0 },
		]
	})

	# ── Wald-Zone (Südost) ──
	biomes.append({
		"name": "forest_se",
		"bounds": Rect2(5, 5, WORLD_HALF_SIZE - 5, WORLD_HALF_SIZE - 5),
		"spawn_rules": [
			{ "type_id": "oak_tree", "count": 8, "y_level": 0.0 },
		]
	})

	# ── Steinbruch (Ost) ──
	biomes.append({
		"name": "quarry_east",
		"bounds": Rect2(15, -20, 25, 30),
		"spawn_rules": [
			{ "type_id": "iron_ore", "count": 5, "y_level": 0.0 },
		]
	})

	Logger.log_debug(
		"Biome registriert: %s" % str(biomes.map(func(b): return b["name"])),
		LOG_CAT
	)


## Prüft ob eine Position gültig ist (ausreichend Abstand zu allen bereits platzierten).
func _is_valid_position(pos: Vector3, placed: Array[Vector3]) -> bool:
	for existing in placed:
		if pos.distance_to(existing) < MIN_ENTITY_SPACING:
			return false
	return true
