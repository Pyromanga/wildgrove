extends ServiceNode
class_name RespawnService

## RespawnService — Verwaltet das Nachwachsen von geernteten Welt-Objekten.
##
## DESIGN:
##   Jede Entity-Definion hat einen konfigurierbaren Cooldown (Sekunden Spielzeit).
##   Nach dem Despawn (entity_despawned-Event) wird ein Timer gestartet.
##   Nach Ablauf wird die Entity an ihrer ursprünglichen Position neu gespawnt
##   und aus WorldData.harvested_objects entfernt — sie ist wieder erntbar.
##
## Konfiguration (in _register_respawn_rules()):
##   _respawn_rules["oak_tree"] = { "cooldown": 300.0 }   # 5 Minuten
##   _respawn_rules["iron_ore"] = { "cooldown": 600.0 }   # 10 Minuten
##
## Abhängigkeiten: ["world"]  (zum Spawnen via WorldService)
##
## WICHTIG: Nutzt on_tick() statt _process() — konform mit ServiceTicker-Vertrag.

const LOG_CAT := "RespawnService"

## Format: { "oak_tree": { "cooldown": 300.0 } }
var _respawn_rules: Dictionary = {}

## Aktive Respawn-Einträge die auf ihren Timer warten.
## Format: Array[{ "type_id": String, "position": Vector3, "remaining": float }]
var _pending: Array = []

var _world: WorldService


# ─────────────────────────────────────────────
# Phase 4: Configure (DI)
# ─────────────────────────────────────────────
func configure(deps: Dictionary) -> void:
	_world = deps.get("world") as WorldService
	if not is_instance_valid(_world):
		Logger.log_warn("WorldService fehlt — Respawn nicht aktiv.", LOG_CAT)

	_register_respawn_rules()
	Logger.log_info(
		"RespawnService konfiguriert. Regeln: %s" % str(_respawn_rules.keys()), LOG_CAT
	)


# ─────────────────────────────────────────────
# Phase 5: on_ready
# ─────────────────────────────────────────────
func on_ready() -> void:
	# entity_despawned trägt jetzt die Position mit — kein fragiles Key-Parsing mehr.
	EventBus.world.entity_despawned.connect(_on_entity_despawned)

	if Services.ticker:
		Services.ticker.register_service(self)
	else:
		Logger.log_warn("ServiceTicker fehlt — Respawn-Timer laufen nicht!", LOG_CAT)

	Logger.log_info("RespawnService bereit. Überwacht entity_despawned.", LOG_CAT)


# ─────────────────────────────────────────────
# Tick — Timer-Countdown
# ─────────────────────────────────────────────
func on_tick(delta: float) -> void:
	if _pending.is_empty():
		return

	var to_respawn: Array = []
	for entry in _pending:
		entry["remaining"] -= delta
		if entry["remaining"] <= 0.0:
			to_respawn.append(entry)

	for entry in to_respawn:
		_pending.erase(entry)
		_do_respawn(entry["type_id"], entry["position"])


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Gibt die konfigurierten Cooldown-Regeln zurück (lesbar für Debug-Commands).
func get_rules() -> Dictionary:
	return _respawn_rules.duplicate()


## Gibt alle ausstehenden Respawn-Einträge zurück (für Debug/Save).
func get_pending() -> Array:
	return _pending.duplicate(true)


## Ändert den Cooldown einer Entity-Klasse zur Laufzeit.
## Nützlich für Balancing-Tweaks ohne Neustart.
func set_cooldown(type_id: String, seconds: float) -> void:
	if not _respawn_rules.has(type_id):
		_respawn_rules[type_id] = {}
	_respawn_rules[type_id]["cooldown"] = max(seconds, 0.0)
	Logger.log_info(
		"Cooldown für '%s' auf %.1f Sekunden gesetzt." % [type_id, seconds], LOG_CAT
	)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _register_respawn_rules() -> void:
	_respawn_rules["oak_tree"] = { "cooldown": 180.0 }   # 3 Minuten
	_respawn_rules["iron_ore"] = { "cooldown": 300.0 }   # 5 Minuten


func _on_entity_despawned(type_id: String, _uuid: String, position: Vector3) -> void:
	if not _respawn_rules.has(type_id):
		return
	if position == Vector3.ZERO:
		Logger.log_warn("entity_despawned ohne Position für '%s' — kein Respawn." % type_id, LOG_CAT)
		return

	var cooldown: float = _respawn_rules[type_id].get("cooldown", 120.0)
	_pending.append({
		"type_id": type_id,
		"position": position,
		"remaining": cooldown,
	})

	Logger.log_info(
		"Respawn geplant: '%s' bei %s in %.0f Sekunden." % [type_id, str(position), cooldown],
		LOG_CAT
	)


func _do_respawn(type_id: String, position: Vector3) -> void:
	if not is_instance_valid(_world):
		Logger.log_error("_do_respawn: WorldService nicht mehr valid!", LOG_CAT)
		return

	# Harvested-Markierung entfernen damit WorldService beim nächsten Laden nicht überspringt
	match type_id:
		"oak_tree":
			_world.data.harvested_objects.erase(
				"tree_%d_%d_%d" % [int(position.x), int(position.y), int(position.z)]
			)
		"iron_ore":
			_world.data.harvested_objects.erase(
				"ore_%d_%d_%d" % [int(position.x), int(position.y), int(position.z)]
			)

	var entity := _world.spawn_entity(type_id, position)
	if is_instance_valid(entity):
		Logger.log_info(
			"Respawn erfolgreich: '%s' bei %s." % [type_id, str(position)], LOG_CAT
		)
	else:
		Logger.log_error(
			"Respawn fehlgeschlagen: '%s' bei %s." % [type_id, str(position)], LOG_CAT
		)
