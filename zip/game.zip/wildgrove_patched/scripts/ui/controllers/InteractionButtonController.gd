class_name InteractionButtonController
extends Node

## InteractionButtonController — zeigt/versteckt den Interaktions-Button.
##
## Muss via hud.add_child(ctrl) in den SceneTree eingehängt werden damit
## _ready() und _process() feuern. Das erledigt InteractionButtonComponent.build().
##
## FIX (Stub aufgelöst): _process()-Polling durch EventBus.world.proximity_changed
## ersetzt. InteractionSensor emittiert jetzt proximity_changed wenn sich der
## nächste Interagierbare ändert — kein Frame-by-Frame get_nodes_in_group() mehr.

var _visuals: InteractionButtonVisuals
var _has_target: bool = false
var _is_busy: bool = false


func setup(visuals: InteractionButtonVisuals) -> void:
	_visuals = visuals
	# Button.pressed → Standard-Interaktion auf dem nächsten Interagierbaren
	_visuals.button.pressed.connect(_on_pressed)


func _ready() -> void:
	EventBus.world.interaction_started.connect(_on_interaction_started)
	EventBus.world.interaction_finished.connect(_on_interaction_ended)
	EventBus.world.interaction_cancelled.connect(_on_interaction_ended)
	# Stub aufgelöst: event-getrieben statt Polling
	EventBus.world.proximity_changed.connect(_on_proximity_changed)
	_update_button()


func _on_pressed() -> void:
	# Player aus Gruppe holen — identisches Pattern wie ContextMenuController
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		Logger.log_warn("InteractionButton: kein Player in Gruppe 'player'.", "InteractionBtn")
		return
	var player := players[0]
	# Direkte Standard-Interaktion (erste Aktion des nächsten Interagierbaren)
	if player.has_method("get_context_actions"):
		var actions: Array = player.get_context_actions()
		# Erste Aktion ist die Haupt-Aktion (Untersuchen ist Index 1)
		for action in actions:
			if action is InteractableAction and action.id != action.id.replace("_inspect", "") + "_inspect":
				# Überspringe reine Inspect-Aktionen — Button soll Haupt-Aktion auslösen
				if not action.id.ends_with("_inspect"):
					if is_instance_valid(Services.interaction_executor):
						Services.interaction_executor.execute_action(action)
					return
	Logger.log_warn("InteractionButton: keine ausführbare Aktion gefunden.", "InteractionBtn")


func _on_proximity_changed(target: Node3D, in_range: bool) -> void:
	var new_has_target := in_range and is_instance_valid(target)
	if new_has_target != _has_target:
		_has_target = new_has_target
		_update_button()


func _on_interaction_started(_action_id: String, _label: String, _duration: float) -> void:
	_is_busy = true
	_update_button()


func _on_interaction_ended(_action_id: String, _label: String) -> void:
	_is_busy = false
	_update_button()


func _update_button() -> void:
	if is_instance_valid(_visuals):
		_visuals.set_active(_has_target and not _is_busy)
