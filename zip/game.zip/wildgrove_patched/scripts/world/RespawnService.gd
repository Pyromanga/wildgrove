extends ServiceNode
class_name RespawnService

## RespawnService — Nachhaltiges Respawn-System für World-Entities.
##
## Verantwortung:
##   - Geerntete Entities in eine Respawn-Queue eintragen
##   - Pro Entity-Typ konfigurierbaren Cooldown abwarten
##   - Nach Cooldown: Entity via WorldService.spawn_entity() wieder spawnen
##   - WorldData.harvested_objects entsprechend aufräumen
##
## Konfiguration (von WorldService.configure() aufgerufen):
##   respawn_service.register_config("oak_tree",  300.0)  # 5 Minuten
##   respawn_service.register_config("iron_ore",  600.0)  # 10 Minuten
##
## ABHÄNGIGKEIT:
##   RespawnService braucht WorldService aber WorldService braucht RespawnConfig
##   (registriert configs IN configure()). Das wäre ein Kreislauf wenn über deps
##   injiziert. Lösung: RespawnService holt WorldService LAZY via Services.world
##   in on_tick() / _find_last_harvested_position(). Das ist sicher weil Services
##   erst nach allen configure()-Calls befüllt werden (Phase 7 > Phase 4).
##
## Abhängigkeiten (deps): [] — kein dep, lazy via Services.world

const LOG_CAT := "RespawnService"

## { type_id: RespawnConfig }
var _configs: Dictionary = {}

## Respawn-Queue: Array von { "type_id": String, "position": Vector3, "spawn_at": float }
## spawn_at = Time.get_ticks_msec() + cooldown_ms
var _queue: Array = []


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────

func configure(_deps: Dictionary) -> void:
	# Keine Abhängigkeiten via DI — WorldService wird lazy über Services.world geholt.
	Logger.log_debug("RespawnService konfiguriert (lazy world-ref).", LOG_CAT)


# ─────────────────────────────────────────────
# Phase 5: on_ready
# ─────────────────────────────────────────────

func on_ready() -> void:
	EventBus.world.entity_despawned.connect(_on_entity_despawned)
	if Services.ticker:
		Services.ticker.register_service(self)
	Logger.log_info("RespawnService bereit.", LOG_CAT)


# ─────────────────────────────────────────────
# Phase 7: on_cleanup
# ─────────────────────────────────────────────

func on_cleanup() -> void:
	_queue.clear()
	Logger.log_debug("RespawnService: Queue geleert.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Registriert Respawn-Einstellungen für einen Entity-Typ.
## Muss vor dem ersten entity_despawned-Event aufgerufen werden
## (am besten in WorldService.configure() oder on_ready()).
func register_config(entity_type: String, cooldown_secs: float, max_instances: int = 0) -> void:
	var cfg := RespawnConfig.new()
	cfg.entity_type   = entity_type
	cfg.cooldown_secs = cooldown_secs
	cfg.max_instances = max_instances
	_configs[entity_type] = cfg
	Logger.log_debug(
		"Respawn-Config: '%s' → %.0fs Cooldown (max: %s)."
		% [entity_type, cooldown_secs, str(max_instances) if max_instances > 0 else "∞"],
		LOG_CAT
	)


## Gibt alle ausstehenden Respawn-Einträge zurück (für Debug-Terminal).
func get_queue_debug() -> Array:
	var now := Time.get_ticks_msec()
	var result := []
	for entry in _queue:
		result.append({
			"type":        entry["type_id"],
			"pos":         entry["position"],
			"remaining_s": max(0.0, (entry["spawn_at"] - now) / 1000.0)
		})
	return result


# ─────────────────────────────────────────────
# Tick — prüft Queue ob Einträge fällig sind
# ─────────────────────────────────────────────

func on_tick(_delta: float) -> void:
	if _queue.is_empty():
		return
	var world := Services.world
	if not is_instance_valid(world):
		return

	var now := Time.get_ticks_msec()
	var i := _queue.size() - 1
	# Rückwärts iterieren damit wir sicher löschen können
	while i >= 0:
		var entry: Dictionary = _queue[i]
		if now >= entry["spawn_at"]:
			_queue.remove_at(i)
			_do_respawn(entry["type_id"], entry["position"])
		i -= 1


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _on_entity_despawned(type_id: String, _uuid: String) -> void:
	## Wird von EntityOrchestrator via EventBus emittiert nach jedem Despawn.
	## Wir brauchen die Position — die steckt in WorldData.harvested_objects.
	## EntityOrchestrator emittiert leider keine Position im entity_despawned-Signal.
	## Lösung: WorldService.data.harvested_objects enthält zuletzt geerntete Positionen.
	## Wir rekonstruieren die Position aus dem letzten Eintrag in harvested_objects.

	if not _configs.has(type_id):
		# Kein Respawn für diesen Typ konfiguriert
		return

	var cfg: RespawnConfig = _configs[type_id]
	var cooldown_ms := int(cfg.cooldown_secs * 1000.0)

	## Position ermitteln — aus WorldData nach Typ
	var position := _find_last_harvested_position(type_id)
	if position == Vector3.INF:
		Logger.log_warn(
			"_on_entity_despawned('%s'): Position nicht gefunden — kein Respawn." % type_id,
			LOG_CAT
		)
		return

	var entry := {
		"type_id":  type_id,
		"position": position,
		"spawn_at": Time.get_ticks_msec() + cooldown_ms,
	}
	_queue.append(entry)

	Logger.log_info(
		"Respawn eingeplant: '%s' bei %s in %.0fs." % [type_id, str(position), cfg.cooldown_secs],
		LOG_CAT
	)


func _find_last_harvested_position(type_id: String) -> Vector3:
	## Sucht die zuletzt als geerntet markierte Position für den gegebenen Typ.
	var world := Services.world
	if not is_instance_valid(world) or not is_instance_valid(world.data):
		return Vector3.INF

	var source_positions: Array[Vector3] = []

	match type_id:
		"oak_tree": source_positions = world.data.tree_positions
		"iron_ore":  source_positions = world.data.ore_positions
		_:
			Logger.log_warn("_find_last_harvested_position: unbekannter Typ '%s'." % type_id, LOG_CAT)
			return Vector3.INF

	# Bereits in Queue stehende Positionen ausschließen (kein Doppel-Respawn)
	var queued_positions: Array = []
	for entry in _queue:
		if entry["type_id"] == type_id:
			queued_positions.append(entry["position"])

	for pos in source_positions:
		var key := _make_key(type_id, pos)
		if world.data.harvested_objects.has(key):
			if not pos in queued_positions:
				return pos

	return Vector3.INF


func _do_respawn(type_id: String, position: Vector3) -> void:
	var world := Services.world
	if not is_instance_valid(world):
		Logger.log_error("_do_respawn: WorldService ist nicht mehr valid!", LOG_CAT)
		return

	# Harvested-Marker entfernen damit Entity nicht sofort wieder überspungen wird
	var key := _make_key(type_id, position)
	if world.data.harvested_objects.has(key):
		world.data.harvested_objects.erase(key)
		Logger.log_debug("Harvested-Marker '%s' entfernt." % key, LOG_CAT)

	var entity := world.spawn_entity(type_id, position)
	if is_instance_valid(entity):
		Logger.log_info(
			"Respawn erfolgreich: '%s' bei %s." % [type_id, str(position)], LOG_CAT
		)
	else:
		Logger.log_error(
			"Respawn fehlgeschlagen: '%s' bei %s." % [type_id, str(position)], LOG_CAT
		)


static func _make_key(type_id: String, pos: Vector3) -> String:
	match type_id:
		"oak_tree": return "tree_%d_%d_%d" % [int(pos.x), int(pos.y), int(pos.z)]
		"iron_ore":  return "ore_%d_%d_%d"  % [int(pos.x), int(pos.y), int(pos.z)]
		_:           return "%s_%d_%d_%d"  % [type_id, int(pos.x), int(pos.y), int(pos.z)]
