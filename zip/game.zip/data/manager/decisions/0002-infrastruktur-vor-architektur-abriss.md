# 0002 — Infrastruktur vor Architektur-Abriss

Zeit: 2026-08-02 11:25 UTC
Rolle: manager

## Gewählt
Erst Manager-Protokoll/Scripts bauen, Architektur-Entscheidung (ADR-Abriss) verschieben auf ersten echten Manager-Lauf (Roadmap Phase 1)

## Verworfene Alternativen
- Sofort ADRs/Code sichten und Abriss-Plan erstellen (ohne Ausführung)
- Sofort loslegen und direkt umsetzen

## Begründung
Mensch: Kontextlimits zwingen zu kleinen Schritten zwischen Sessions — Infrastruktur, die genau dieses Problem löst, ist aktuell wichtiger als ein Rewrite, der ohne sie sowieso nicht sauber durchgezogen werden könnte.
