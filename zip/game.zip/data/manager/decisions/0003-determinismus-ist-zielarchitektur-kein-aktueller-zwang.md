# 0003 — Determinismus ist Zielarchitektur, kein aktueller Zwang

Zeit: 2026-08-02 11:25 UTC
Rolle: manager

## Gewählt
Scripts/Makefile-Targets wo sinnvoll und schnell baubar (z.B. eventbus-direct), sonst normales Editieren erlaubt — volle Script-Pflicht erst wenn Manager autonom läuft (Roadmap Phase 2)

## Verworfene Alternativen
- Sofort volle Determinismus-Pflicht (jede Änderung = Script)

## Begründung
Mensch explizit: 'kein Muss für den Anfang, das ist die Ziel-Architektur' — Overhead jetzt würde die eigentlich dringende Infrastruktur-Arbeit verlangsamen.
