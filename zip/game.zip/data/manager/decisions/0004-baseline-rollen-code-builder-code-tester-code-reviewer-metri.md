# 0004 — Baseline-Rollen: code-builder, code-tester, code-reviewer, metrik-master

Zeit: 2026-08-02 11:25 UTC
Rolle: manager

## Gewählt
Vier Rollen als Startpunkt, Manager darf Hierarchie jederzeit ändern (muss es aber loggen)

## Verworfene Alternativen
- Flachere Struktur ohne festen Manager (Peer-Agents ohne Koordinationsinstanz)
- Zusätzliche Rolle sofort (z.B. content-designer für Tier/Pflanzen-Daten) schon jetzt mit anlegen

## Begründung
Vom Menschen als Grundlage vorgegeben; content-designer o.ä. macht erst in Roadmap Phase 4 (Spielkonzept) Sinn, nicht vorher — sonst Rolle ohne Aufgabe.
