# 0009 — Erster Self-Healing-Fall: Manager reagiert statt zu beraten

Zeit: 2026-08-02 11:35 UTC
Rolle: manager

## Gewählt
Explizite Beratungspflicht in MANAGER.md verankert (§1a): der Manager muss Verbesserungsvorschläge VOR Kritik einbringen, nicht danach. Zusätzlich: Sequenz-Gate 'kein Test-Pipeline-Aufbau vor Grundprojekt-Freigabe' in ROADMAP.md Phase 3 festgeschrieben, damit es keine künftige Session vergisst.

## Verworfene Alternativen
- Nur den einen Vorfall entschuldigen (siehe Decision 0006 als Präzedenzfall) ohne neue Struktur
- Abwarten, ob es sich wiederholt, bevor eine Regel draus wird

## Begründung
Mensch: 'das haette von dir kommen sollen, du sollst mich beraten nicht andersherum.' Zweiter Vorfall in derselben Session nach Decision 0006 (Protokollbruch) -- das ist ein Muster, kein Einzelfall, und Muster gehoeren als Prinzip ins Protokoll, nicht nur als Einzel-Decision.
