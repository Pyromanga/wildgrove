extends ServiceNode
class_name HUDManager

## HUDManager — Zentrale Steuerung des in-game HUD.
##
## Das HUD-CanvasLayer hängt unter /root (nicht unter der Welt-Szene).
## Damit überlebt es jeden Szenen-Wechsel ohne Umbauerei.
##
## Lifecycle:
##   configure()        → DI, erstellt HUD-Node
##   on_ready()         → Hängt HUD unter /root, connected world_scene_ready
##   attach_to_scene()  → Baut Controller neu (bei jedem Welt-Laden)
##   hide_hud()         → Im Hauptmenü/anderen Szenen
##   show_hud()         → Wenn Welt aktiv

const LOG_CAT := "HUD"

var hud: HUD = null
var controllers: Dictionary = {}

var _inventory: InventorySystem
var _player_states: PlayerStateService


func configure(deps: Dictionary) -> void:
	_inventory     = deps.get("inventory")     as InventorySystem
	_player_states = deps.get("playerstates")  as PlayerStateService

	if not is_instance_valid(_inventory):
		Logger.log_warn("'inventory' fehlt in HUDManager.configure()!", LOG_CAT)
	if not is_instance_valid(_player_states):
		Logger.log_warn("'playerstates' fehlt in HUDManager.configure()!", LOG_CAT)

	hud = HUD.new()
	hud.name = "GameHUD"
	hud.visible = false   # Initial versteckt — wird in show_hud() eingeblendet
	Logger.log_debug("HUD-Node erstellt.", LOG_CAT)


func on_ready() -> void:
	# HUD direkt unter /root hängen — überlebt jeden Szenen-Wechsel.
	# CanvasLayer unter /root wird immer gerendert, unabhängig von der aktiven Szene.
	get_tree().root.add_child(hud)
	Logger.log_debug("HUD unter /root eingehängt.", LOG_CAT)

	# Auf Szenen-Events lauschen
	EventBus.world.world_scene_ready.connect(_on_world_scene_ready)
	EventBus.system.state_changed.connect(_on_game_state_changed)
	Logger.log_info("HUDManager bereit.", LOG_CAT)


func on_cleanup() -> void:
	if is_instance_valid(hud):
		hud.queue_free()
	hud = null
	controllers.clear()
	Logger.log_debug("HUDManager bereinigt.", LOG_CAT)


func get_controller(key: String) -> Object:
	return controllers.get(key)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _on_world_scene_ready(_scene_root: Node) -> void:
	## Bei jedem Welt-Laden: Controller neu aufbauen und HUD zeigen.
	## Das HUD selbst bleibt unter /root — nur die Controller werden neu erstellt
	## weil sie auf den neuen Spieler/Entities der neuen Szene zeigen müssen.
	Logger.log_debug("Welt bereit — HUD-Controller neu aufbauen.", LOG_CAT)

	# Alte Controller-Nodes aus HUD entfernen (die vom letzten Load stammen)
	# Controller-Nodes aus HUD entfernen — direkt freigeben statt queue_free
	# damit _setup_controllers() sauber auf einen leeren HUD aufbaut
	for child in hud.get_children():
		hud.remove_child(child)
		child.free()
	controllers.clear()

	# Notification-Signal trennen — Kopie des Arrays damit wir sicher iterieren können
	var conns: Array = EventBus.world.interaction_reward_text.get_connections().duplicate()
	for conn in conns:
		EventBus.world.interaction_reward_text.disconnect(conn["callable"])

	_setup_controllers()

	var notif := controllers.get("notification") as NotificationController
	if notif:
		EventBus.world.interaction_reward_text.connect(notif.show)

	hud.visible = true
	Logger.log_info("HUD aktiv. %d Controller." % controllers.size(), LOG_CAT)


func _on_game_state_changed(new_state: int) -> void:
	## HUD verstecken wenn nicht im PLAYING-State.
	if not is_instance_valid(hud):
		return
	var playing: bool = (new_state == GameEnums.State.PLAYING)
	hud.visible = playing
	Logger.log_debug("HUD visible: %s (state=%d)" % [str(playing), new_state], LOG_CAT)


func _setup_controllers() -> void:
	Logger.log_debug("Baue HUD-Controller...", LOG_CAT)
	controllers = HUDBuilder.build_all(hud, {})
	Logger.log_debug("Controller gebaut: %d" % controllers.size(), LOG_CAT)
