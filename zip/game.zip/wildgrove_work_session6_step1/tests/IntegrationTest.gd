# IntegrationTest.gd
# GUT ist installiert (res://addons/gut/).
# Dieser Test braucht den echten ServiceOrchestrator — läuft nicht headless ohne Scene.
# Für CI: Unit-Tests in tests/unit/ via `godot --headless -s addons/gut/gut_cmdln.gd -gdir=res://tests/unit/ -gexit`

extends GutTest

## IntegrationTest — Prüft ob der Boot-Prozess korrekt abläuft.
## Benötigt laufende Szene mit ServiceOrchestrator.

func before_all() -> void:
	if not EventBus.system.services_initialized.is_connected(_on_services_ready):
		EventBus.system.services_initialized.connect(_on_services_ready, CONNECT_ONE_SHOT)

func _on_services_ready() -> void:
	Logger.log_info("IntegrationTest: Services bereit — starte Tests.", "Test")
	test_check_services_integrity()

func test_check_services_integrity() -> void:
	assert_not_null(Services.save_system,   "SaveSystem muss registriert sein")
	assert_not_null(Services.data,          "DataService muss registriert sein")
	assert_not_null(Services.inventory,     "InventorySystem muss registriert sein")
	assert_not_null(Services.skill_system,  "SkillSystem muss registriert sein")
	assert_not_null(Services.world,         "WorldService muss registriert sein")
	assert_not_null(Services.player_states, "PlayerStateService muss registriert sein")
	Logger.log_info("Alle Service-Assertions bestanden.", "Test")
