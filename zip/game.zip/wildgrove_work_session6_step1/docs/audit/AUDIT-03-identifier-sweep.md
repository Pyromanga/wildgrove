# WildGrove — Audit Round 2: Systematic Undefined-Identifier Sweep

Companion to `AUDIT-01` and `AUDIT-02`. This round executes the first item from
`AGENT.md`'s pickup list: a project-wide, mechanical sweep for the exact bug class that broke
`SkillSystem.gd` in round 1 — a renamed, removed, or never-declared identifier still
referenced somewhere in the same file.

## Method

A custom static-analysis script (not a real GDScript parser — no such tool was available in
this sandbox) walked all 181 `.gd` files outside `addons/` and `tests/`, for each file:
collected every locally-declared name (top-level `var`/`const`, function names, *single-line*
function parameters, `for`-loop variables, `enum`/`signal` names), built a project-wide
registry of `class_name` declarations and `project.godot` autoloads, then flagged any
identifier used immediately before `.` or `[` that wasn't in any of those sets and wasn't a
manually-curated list of ~100 Godot built-in types/properties.

This is a heuristic, not a parser — it has known blind spots (multi-line function signatures,
inner classes, lambda parameters, Godot built-in properties I didn't think to list). It found
66 raw candidates across 45 files. Every single one was manually reviewed against the actual
source before being reported here; nothing below is an unverified grep hit.

**Result: 64 of 66 candidates were false positives**, overwhelmingly from two causes: (1) the
script's lower confidence on signatures that wrap across multiple lines, which made legitimate
function parameters look "undeclared," and (2) Godot built-in Node properties (`velocity`,
`global_position`, `rotation`, `multiplayer`, `name`) and built-in classes (`StyleBoxFlat`,
`ProgressBar`, `FastNoiseLite`, etc.) that weren't in my curated builtin list. **Two candidates
were real, confirmed bugs**, both of the same class as round 1's `SkillSystem` finding.

---

## Finding 2 (new) — `WorldService.gd` still runs the pre-A-15-fix `HUDManager` wiring, and it's now doubly broken

**Files:** `scripts/world/WorldService.gd` lines 88–93, `scripts/ui/HUDManager.gd`,
`scripts/core/ServiceOrchestrator.gd`

`docs/review.md` claims, under finding **A-15**:

> WorldService instanziiert UI und reicht Service-Referenzen hinein [MITTEL] ✅ BEHOBEN v42 —
> HUDManager.boot(tree) als statische Methode. ServiceOrchestrator ruft sie nach
> session_ready.emit() auf — kein WorldService-Coupling.

What's actually true:

1. `HUDManager.gd` genuinely has the described fix: `static func boot(tree: SceneTree) ->
   HUDManager` exists, creates the manager, calls a now-zero-argument `initialize()`, adds it
   to the tree, returns it. The doc comment on this method explicitly states *"Wird von
   ServiceOrchestrator nach session_ready aufgerufen"* (called by ServiceOrchestrator after
   session_ready).
2. **`ServiceOrchestrator.gd` never calls it.** `grep -n "HUDManager" scripts/core/ServiceOrchestrator.gd`
   returns zero matches. The described caller doesn't exist anywhere in the codebase. The only
   two places `HUDManager.new()` appears are inside `HUDManager.boot()` itself, and —
3. **`WorldService.gd`'s `on_ready()`**, which still runs the old pattern this ADR/review entry
   claims was removed:
   ```gdscript
   # HUDManager: kein Service (Lifecycle-Mismatch, TD-05) — WorldService instanziiert
   # und hängt ihn in den SceneTree. HUDManager verwaltet seinen eigenen Lifecycle.
   _hud_manager = HUDManager.new()
   _hud_manager.name = "HUDManager"
   _hud_manager.initialize(Services.inventory, Services.player_states)
   get_tree().root.call_deferred("add_child", _hud_manager)
   ```
   Two independent problems with just these four lines: `_hud_manager` is never declared
   anywhere in `WorldService.gd` (checked the full `var` list at the top of the class — it's
   not there), and `.initialize(Services.inventory, Services.player_states)` is called with two
   arguments against `HUDManager.initialize()`, which — per the *current* version of
   `HUDManager.gd` — takes **zero** arguments. Even if `_hud_manager` had been declared, this
   call would still fail; the method signature it's calling no longer exists.

**Why this is worse than it looks at first glance:** this code sits inside `WorldService.on_ready()`,
which Godot calls during every single session boot (the comments immediately above it, in the
same function, are wiring up `EventBus` save hooks and respawn config — this isn't a rarely-hit
code path, it's core boot sequencing). GDScript resolves identifiers statically when a script is
loaded; an assignment to an undeclared bare name is normally a load-time error, not something
that fails quietly at the moment it executes. **The practical implication is that
`WorldService.gd` itself may fail to load at all**, which would cascade into respawn config never
registering, pet save-restoration never wiring up, and the HUD never appearing — i.e., this is a
plausible explanation for "the world doesn't load" as a symptom, not just "the HUD is missing."
I want to flag the honest limit of this claim: I could not execute Godot in this sandbox to
confirm load-vs-runtime failure timing definitively; the call-site analysis (undeclared
identifier, wrong-arity call) is solid static evidence regardless of exactly when it surfaces.

**Likely fix shape** (for the implementation plan, not applied here): delete lines 88–93 from
`WorldService.on_ready()` entirely, and add the actual call `ServiceOrchestrator` is supposed to
make — `HUDManager.boot(get_tree())` — at the point after `session_ready` is emitted, matching
what `HUDManager.gd`'s own doc comment already describes. This is a case where the fix is fully
specified by the codebase's own (correct) self-documentation; it just was never wired in.

---

## Finding 3 (new) — `Bar3D` is referenced as a type in two files but doesn't exist anywhere in the project

**Files:** `scripts/services/Factory3D.gd` line 43, `scripts/interaction/InteractableComponent.gd`
lines 25, 113, 168, 172, 174, 178, 179

`Factory3D.gd` declares `func create_3d_bar(parent: Node3D) -> Bar3D:` and instantiates
`Bar3D.new()` inside it, calling a custom `.setup(fill)` method on the result — clearly meant
to be a small custom Node3D-derived class with its own API, not a Godot built-in (there is no
built-in `Bar3D` node type in Godot 4). `InteractableComponent.gd` separately declares
`var _bar_3d: Factory3D.Bar3D = null` and uses it across 6 more lines to drive the 3D progress
bar shown during gathering interactions (the fill animation that plays while chopping a tree
or mining ore).

I searched the entire project for `class_name Bar3D` and for any file named `Bar3D.gd` —
neither exists. This type is referenced as if it were defined, in two separate files, and isn't
defined anywhere. Both files use it in type-annotation positions (a function return type, a
variable type), which GDScript resolves at parse time — meaning both `Factory3D.gd` and
`InteractableComponent.gd` are plausible candidates for a load-time failure, the same caveat as
Finding 2 above (not executed in this sandbox, so "plausible candidate for load failure" rather
than "confirmed runtime trace").

**Blast radius, if this fails to load:** `InteractableComponent` is the component class for
interactable world objects generally (the same file `AUDIT-01` already touched for its
`IUIContext` migration) — if it fails to load, that's not a cosmetic miss on one progress bar,
it's the interaction system broadly. This is worth verifying first, ahead of Finding 2, simply
because "can the player interact with anything" gates everything else.

**Likely fix shape:** either `Bar3D` was meant to be a small inner class (`class Bar3D extends
Node3D: ...` nested inside `Factory3D.gd`, with a `setup(fill_node)` and presumably an
`update(value: float)` method matching the `tween_method(func(v): _bar_3d.update(v), ...)` call
in `InteractableComponent.gd`) that was never written, or it was meant to be its own
`Bar3D.gd` file with `class_name Bar3D` that got deleted or never committed. Either is a small,
well-scoped fix — the call sites already describe the exact API surface needed
(`.setup(fill)`, `.update(float)`, `.visible`) — but it needs a human decision on which shape
is intended before implementing.

---

## What this round confirms about the sweep methodology

Two real bugs found per ~60 reviewed candidates is a useful hit rate for a heuristic this
rough — it's not a substitute for actually compiling the project, but it's a cheap, bounded way
to surface this exact bug class without one. **Recommendation for the implementation plan:**
once Godot is available in whatever environment actually builds this project, the single
highest-value, lowest-effort verification step is just opening the project in the editor once —
Godot's own script editor will immediately surface every one of these as a parse error in the
"Errors" panel, which is strictly more reliable than this heuristic and would take minutes, not
the hour-plus this manual sweep took. This audit's value was working without that tool
available; it shouldn't replace it once it is.

## Scope note

This round only covers the identifier-sweep slice of `AGENT.md`'s "Not Yet Audited" list. Still
untouched: `scripts/ui/components/`, `scripts/ui/visuals/` beyond what the sweep happened to
touch, the rest of `scripts/world/`, all `.tscn` scene-level wiring, the existing test files'
content, and `docs/principles.md` / `docs/services.md` / `docs/history.md` /
`CONTRIBUTING.md` / `docs/MIGRATION*.md`. Per `AGENT.md`'s own pacing rule, that's intentional
— this is one bounded round, not the whole remaining backlog.
