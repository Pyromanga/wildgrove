# WildGrove — Audit Round 6: World Entity Layer Review

Companion to `AUDIT-01`–`06`. This round covers `scripts/world/` (39 files, ~3,600 lines) —
the last code-level item from `AGENT.md`'s original pickup list.

## Method

Systematic `get_node()`/`get_node_or_null()` sweep across the whole layer (the bug class that
broke `MainMenuController`), full reads of the core spawn-pipeline files
(`World.gd`, `WorldFactory.gd`, `WorldSpawner.gd`, `ChunkManager.gd`,
`ChunkEntitySpawner.gd`), and full reads of the pet save/restore subsystem
(`PetRestorer.gd`, parts of `PetComponent.gd`, `WorldSaveHandler.gd`) as a deeper spot check
on a stateful feature in the same risk class as `SaveSystem`. Entity-type strings were
cross-checked against `WorldEntityRegistry` end to end (spawner call sites →
registered types).

## Headline: like the UI layer, this is mostly solidly wired — with one finding that widens an existing bug's blast radius

**Only 2 `get_node()`-family calls exist in this whole layer.** One
(`EnemyNPC.gd:136`, `player.get_node_or_null("HealthComponent")`) was already verified correct
in `AUDIT-06`. The other, `EnemyNPC.gd:176`'s `get_node_or_null("AttackInteractable")`, I
traced to its creation site: `EnemyAttack.setup_interactable(parent)` does
`comp.name = "AttackInteractable"` then `parent.add_child(comp)`, and `EnemyNPC.gd` calls
`EnemyAttack.setup_interactable(self)` during its own setup. Correctly wired — the name and
parentage match exactly.

**Entity-type strings are consistent end to end.** `WorldSpawner.spawn_all()` spawns
`"oak_tree"`, `"iron_ore"`, `"quest_npc"`, `"player"`; `EnemySpawner.gd` spawns `"goblin"` and,
via a config array, `"deer"`/`"rabbit"`/`"boar"`; `ChunkEntitySpawner.gd` independently spawns
the same `"oak_tree"` and `"deer"`/`"rabbit"`/`"boar"` set for dynamically-loaded chunks. All
of these match `WorldEntityRegistry.register_all()`'s registered definitions exactly — no
typos, no drift between the static start-chunk spawn list and the dynamic per-chunk one.

**One thing I flagged as a likely bug and then ruled out, worth documenting since it shows the
checking process working, not just the findings:** `ChunkEntitySpawner._spawn_trees()` and
`_spawn_animal()` call `gen.get_height_at(lx, lz)` using *chunk-local* coordinate offsets, then
spawn the entity at *world* coordinates (`center.x + lx, center.y + lz`). At first read this
looks exactly like a local/world coordinate-space bug. It isn't: `ChunkManager._load_chunk()`
gives each chunk's `TerrainGenerator` its own `world_offset = center` (line 86), and
`get_height_at()` internally adds `world_offset` to its input before sampling — so the
local-coordinate call is correct *because* each generator is pre-offset to its own chunk's
position. Confirmed by reading both sides before concluding either way.

---

## Finding 3 (escalation) — the missing `Bar3D` class also breaks enemy NPC setup, not just gathering interactables

`AUDIT-03`'s Finding 3 established that `Bar3D` is referenced as a type in `Factory3D.gd` and
`InteractableComponent.gd` but doesn't exist anywhere in the project, and that
`InteractableComponent` drives the 3D progress bar for gathering interactions (trees, ore).
This round found a second, independent consumer: `EnemyAttack.setup_interactable()` —
called by *every* `EnemyNPC.gd` during its own setup (`EnemyAttack.setup_interactable(self)`)
— does `InteractableComponent.new()` to build the "Angreifen" (attack) interaction. If
`InteractableComponent.gd` fails to load because of the undefined `Bar3D` type annotation on
its `_bar_3d` field, that's not just gathering interactables broken — every enemy NPC
(goblins, and whatever else spawns through `EnemySpawner`) would fail to complete its own
setup. This doesn't change the fix needed (still: define `Bar3D` somewhere, the API surface is
already fully specified by existing call sites), but it does mean the actual blast radius is
"the interaction system and everything that depends on it for combat too," not just
"harvesting." Worth keeping in mind when prioritizing — this single missing class touches more
of the game than it first appeared to.

---

## Finding 8 (minor) — a magic-number landmine: chunk size duplicated instead of referenced

`WorldFactory._add_terrain()` sets `terrain_generator.size = 64.0` with a comment explicitly
stating: *"size MUSS exakt ChunkManager.CHUNK_SIZE (64m) entsprechen"* — size MUST exactly
match `ChunkManager.CHUNK_SIZE` — to avoid the start chunk's terrain overlapping with the
dynamically-loaded chunk grid. `ChunkManager.CHUNK_SIZE` is a public `const` (`:= 64.0`),
directly accessible as `ChunkManager.CHUNK_SIZE` from any other script without needing an
instance. The comment correctly identifies the coupling but the code doesn't enforce it —
`64.0` is duplicated as a bare literal instead of referencing the constant it's required to
match.

This isn't a bug today (both values happen to currently agree), but it's exactly the shape of
landmine this audit series keeps surfacing elsewhere: a constraint that's documented but not
enforced, one accidental edit away from silently breaking (in this case: reintroducing
overlapping terrain geometry at the world origin, the exact bug this code's own history says it
was written to prevent). One-line fix: `terrain_generator.size = ChunkManager.CHUNK_SIZE`.

---

## Pet save/restore subsystem: correctly round-trips

Read `PetRestorer.gd` (restore side), the relevant parts of `PetComponent.gd` (save side via
`get_save_state()`), and `WorldService.collect_and_store_pet_data()` (the collection step that
runs on `save_pre_flush`). All three agree on field names (`"pos"`, `"color"`, `"name"`) and
both sides defensively type-check after `str_to_var()` round-trips (e.g.
`if pos is Vector3: ... else: continue`, never trusting deserialized data blindly). No issues
found.

## `WorldSaveHandler.gd`: same defensive quality as `SaveSystem.gd`

Every field restored from saved state is type-checked with a sane fallback before being
assigned (`if ore_raw is Array`, `player_pos_raw if player_pos_raw is Vector3 else
Vector3.ZERO`, `harvested_raw if harvested_raw is Dictionary else {}`). This is the same
defensive discipline `AUDIT-05` found in `SaveSystem.gd` — consistent quality across the two
files responsible for save-data integrity in this project, which is good corroborating evidence
that the "no atomic write" correction from `AUDIT-05` wasn't a fluke; save-path code generally
gets more care than the stateful-wiring code that's been the source of most bugs in this audit
series.

---

## What this round didn't cover

Full line-by-line reads of `AnimalBase.gd`, `AnimalVisualBuilder.gd`, `Boar.gd`/`Deer.gd`/
`Rabbit.gd`, `QuestNPC.gd`/`QuestNPCDialogController.gd`, `EnemyAI.gd`, `EnemyVisuals.gd`,
`WeaponVisual3D.gd`, `OakTree.gd`/`IronOre.gd`, `WaterBody.gd`/`WaterBodyPlacer.gd`,
`TerrainColorizer.gd`/`TerrainMeshBuilder.gd`, `WorldGenerationService.gd`, `RespawnService.gd`/
`RespawnConfig.gd`, `WorldTimeService.gd`, `WorldData.gd` — these were not read line by line.
Given that (a) the project-wide identifier sweep in `AUDIT-03` already covered all of these for
undeclared-identifier bugs, (b) the `get_node()` sweep this round covered all of them for the
path-mismatch bug class, and (c) the consistent quality found everywhere actually read this
round, I'm treating this layer as adequately covered for this audit series at this depth,
the same call made for the UI layer in `AUDIT-06`.

## Series status

This closes the last code-level item from `AGENT.md`'s original pickup list. What remains is
the prose-documentation slice: `docs/principles.md`, `docs/services.md`, `docs/history.md`,
`CONTRIBUTING.md`, `docs/MIGRATION.md`, `docs/MIGRATION-010.md` — none of which have been read
in full across this whole series. After that, the series has covered everything `AGENT.md`
originally scoped, and the next step per `AGENT.md`'s own closing section is synthesizing the
7 rounds so far into a single prioritized implementation plan.
