# WildGrove — Audit Round 1: ADR Meta-Analysis

Companion to `AUDIT-01-pain-points-and-review-verification.md`. That document is about
*verification* (does the code match what's claimed). This document is about *judgment* (is
the decision itself sound, or is it enterprise cosplay). Each ADR gets: what it actually
solves, whether the reasoning holds up, and where it shades into accepted-but-undeserved
technical debt rather than a genuinely closed decision.

**Framing, since you explicitly said this is allowed to be over-engineered on purpose:** I'm
not scoring these against "what a one-day solo prototype needs." I'm scoring them against
"is this a real decision with a real problem behind it, argued honestly, with risks stated
plainly" — which is the right bar for something meant to last 20 years. Cargo-cult
enterprise patterns fail that bar even in a codebase that's *supposed* to be over-engineered,
because the tell isn't "this is complex," it's "this is complex and the complexity doesn't
trace back to an actual problem."

---

## ADR-001 — Service Locator instead of full DI container

**Verdict: Sound, and honestly argued.**

This is the strongest possible version of this ADR. It doesn't pretend Service Locator is a
good pattern in the abstract — it explicitly states the downsides (implicit dependencies,
escape-hatch risk, no compile-time layer enforcement) and picks a hybrid specifically because
GDScript's `_init()` can't do real constructor injection through the `ServiceFactory`'s
`load(path).new()` instantiation path. The "Ablösung" section is unusually good practice: it
states a concrete trigger condition (GDScript gaining typed constructor params) rather than
"revisit later" hand-waving. This is not cargo cult — it's a real constraint-driven decision.

One real risk, correctly named in the ADR itself but worth re-emphasizing: the mitigation is
**convention enforced by code review** ("`Services.xyz` aus Entities ist Review-Blocker"),
with a "future: linter" aspiration that doesn't exist yet. For a solo developer, "review
blocker" means nothing — there's no second reviewer. This is the actual gap, not the pattern
choice. **Recommendation for the implementation plan:** a CI grep-check (`grep -rn
"Services\." scripts/world/ scripts/player/ scripts/ui/components/` failing the build on any
hit outside an allow-list) would convert this from an honor system into an enforced rule, and
it's cheap — much cheaper than the GDScript-linter-plugin aspiration mentioned in the ADR.

---

## ADR-002 — EventBus with typed namespaces

**Verdict: Sound, proportionate.**

Genuinely solves a real problem (signal name collisions / discoverability at scale) with a
proportionate solution (namespace objects, not a message-bus framework with priorities,
filters, or async dispatch). The honestly-stated risk — Godot signals are synchronous, so a
large fan-out emission blocks the main thread — is correctly deferred rather than
over-solved with premature event batching infrastructure. This is the right amount of
engineering for the problem.

---

## ADR-003 — `ServiceNode` (Node) vs `Service` (RefCounted) split

**Verdict: Sound decision, but the "Ablösung" claim is overstated.**

The decision tree itself ("does this need `add_child()`/`_ready()`/`get_tree()`?") is clean
and the right level of ceremony for a real Godot-specific tradeoff (Node overhead vs.
SceneTree access). The audit methodology described for the Session 5/6 migrations (checking
for `get_node()`, `add_child()`, `queue_free()` from external callers before reclassifying a
service) is legitimately rigorous — exactly the kind of "check the call sites, not the
intent" verification this whole audit is asking for elsewhere.

The overstatement: the ADR's closing section says *"Backlog-Tabelle ist jetzt leer"* and
frames the migration as essentially complete, while in the same breath listing ~10 remaining
`ServiceNode` services (`CombatSystem`, `SceneManager`, `GameManager`, `WorldService`,
`WorldGenerationService`, `RespawnService`, `InteractionExecutor`, `GameSaveService`,
`StatModifierService`, `RewardDispatcher`) as "not reviewed under this backlog, not
necessarily wrong, just unaudited." That's an honest caveat buried in the text, but the
**Status:** field at the top of the file reads "Migrations-Backlog vollständig abgearbeitet"
(fully worked through) — which overstates what actually happened (6 of ~16 `ServiceNode`
services were audited; the rest are simply unexamined, not confirmed correct). A reader
skimming just the status line gets a falsely complete picture. This is a smaller-scale
version of the same "status field is more confident than the body text" pattern as Finding 4
in the companion audit.

**Also worth flagging:** `ServiceTicker`/`ServiceRegistry`/`ServiceFactory` are described as
working "duck-typed über `has_method()`" across both base classes. That's a real type-safety
gap — nothing stops a service from implementing `on_tick()` with the wrong signature and
failing silently or with a confusing error at call time rather than at load time. Acceptable
for now, but worth a line in `principles.md` (unverified — not yet read) about what the
expected method signatures are, since GDScript's duck typing won't catch a mismatch for you.

---

## ADR-004 — `request_*()` / `on_*_confirmed()` naming convention

**Verdict: The pattern is sound. The ADR's own debt tracking is stale (see companion audit,
Finding 4a) — verified false as of current code.**

The pattern itself is a legitimately cheap way to buy future-proofing: today it's a same-frame
local call, tomorrow the same method names become RPC boundaries, and callers never need to
change. That's good design — low cost today, real optionality later, no premature server
infrastructure (the ADR explicitly and correctly rejects "build server code now" as overkill
for the current stage).

The problem isn't the decision, it's that **the ADR text is a debt ledger that nobody is
re-checking against the code it describes.** It says `QuestService` and `SkillSystem` haven't
adopted the pattern yet; both have. That's not a minor staleness issue — it actively misleads
anyone using this ADR to decide what to work on next. **Recommendation:** either (a) ADRs
should not carry living "open tech debt" lists that need re-verification — that's what
`review.md` is supposedly for, per its own stated purpose — or (b) if they do, closure of an
ADR-tracked debt item needs to update both the ADR *and* be grep-verified, the same
discipline ADR-003's Session 5/6 migration used and ADR-004's didn't.

---

## ADR-005/006 — `ISaveProvider` pattern / `EntityContext` injection

**Verdict: Both sound decisions. ADR-006's debt claim is stale (verified false, see companion
audit Finding 4b). ADR-005's "known tech debt" list is the one place in this whole ADR set
where I'd push back hardest on priority, not soundness.**

The provider pattern (ADR-005) is a clean, low-coupling answer to "who saves what" — new
service, two methods, one `configure()` line, no `SaveSystem` change. Good decision.

But its "Bekannter Tech Debt" section quietly lists, as accepted-and-deferred:

- No atomic write (a crash mid-`file.store_string()` corrupts the save)
- No rotating backup
- No save slots
- No partial save

For a game whose entire pitch is long-session progression (skills, farming, village-building,
quests — exactly the kind of game where losing a save is a player-trust-destroying event),
**"no atomic write" sitting in a bulleted "known debt" list, at the same visual weight as "no
save slots yet," is the single clearest example in this codebase of a lazy workaround being
accepted where better code should have been required.** This isn't hard to fix — write to
`savegame.tmp`, then `DirAccess.rename()` to `savegame.json` — and it's the kind of fix that's
nearly free now and very expensive to retrofit once there's real save data nobody wants to
risk migrating mid-fix. I'd flag this for the implementation plan above almost everything
else architectural, specifically because it's cheap, well-understood, and protects against an
unrecoverable failure mode (player data loss) rather than a recoverable one (a bug you can
patch).

EntityContext injection (ADR-006) is the same pattern as ADR-001's hybrid DI, applied to
entities instead of services, and for the same good reason (SceneTree instantiation forecloses
constructor injection). Sound. Its `for_test()` story is real and matches `IUIContext`'s
parallel pattern (see companion audit) — consistent design language across the codebase,
which is a genuine positive sign for long-term maintainability.

---

## ADR-007 — `INetworkAdapter` (superseded by ADR-010)

**Verdict: A real decision that turned out to be wrong, retired cleanly. This is the system
working as intended, not a failure.**

What makes this one worth calling out positively: the ADR doesn't pretend it was always going
to be replaced. It states plainly why it was wrong (it abstracted *transport* but never
answered *who has authority* or *how is state partitioned per player* — the two questions
that actually mattered) and that Godot's built-in `MultiplayerAPI` already solves the problem
it was trying to reinvent. Verified clean in the companion audit: the superseded files were
actually deleted, not left as zombies. This is the ADR process doing exactly what it's
supposed to do — documenting a decision, then documenting why it was wrong, without
pretending otherwise. More of this, not less.

---

## ADR-008 — `CombatSystem` with `DamageRecord` + `DamageType`

**Verdict: The strongest-engineered ADR in the set, and verified accurate against the code
(companion audit, Finding 6).**

Centralizing damage calculation behind a pure function (`calculate_damage()`) with an
injectable RNG for deterministic testing is genuinely good engineering, not over-engineering
— it's the kind of thing that pays for itself the first time someone needs to write a combat
balance test or debug a "why did that crit happen" report. The resistance-mitigation cap
(`max 0.85`, "nie Immunität") is a small but real game-design-aware detail — someone thought
about what happens at the edges, not just the happy path.

The one thing worth tracking forward, already self-flagged in the ADR as intentional: status
effects (`apply_poison`/`apply_burn`) are implemented and tested but **bewusst NICHT
verdrahtet** (deliberately not wired) to any actual weapon or skill. That's an honest, clearly
labeled "foundation without integration" — not a lazy workaround, a sequencing choice. Fine as
is, just worth keeping on the visible backlog rather than letting it quietly age into a thing
nobody remembers exists (review.md's S-02 already tracks this, which is the right place for
it).

---

## ADR-009 — Global vs. Session services (two-registry model)

**Verdict: Sound reasoning, verified accurate against `BootstrapConfig.tres` (companion audit,
Finding 6) — but this is the largest single chunk of architectural complexity in the project,
and it's also the least exercised.**

The problem it solves is real: character switching without an app restart, with clean
teardown so stale service references can't leak. The three options are argued honestly (the
ADR doesn't pretend "just restart the app" or "ad-hoc partial reinit" are acceptable, and
explains exactly why each fails). The boot-flow and teardown-flow sequencing is specific
enough to actually implement from, not just gesture at.

The flag here isn't soundness, it's risk concentration. This is two service registries, a
dependency resolver that needs to handle cross-registry references, and a teardown manager —
real complexity — protecting a feature (character switching) that, as far as this audit
verified, has no test exercising the actual switch-character flow end to end. Combined with
the demonstrated pattern elsewhere in this codebase (claims of correctness that don't survive
contact with the actual call sites), **this is the part of the architecture most likely to be
the next `SkillSystem`-style surprise** — not because the design is wrong, but because it's
exactly the kind of multi-step, stateful, cross-cutting flow that's easy to get subtly wrong
in one of N services and hard to notice without an integration test specifically for "switch
character, verify old session's services are fully torn down and new session's are
correctly scoped." Recommend this as a concrete addition to the test backlog, ranked above
most cosmetic cleanup.

---

## ADR-010 — Multiplayer authority tiers (Listen-Server/Dedicated-Server duality)

**Verdict: The best-reasoned document in the project, and it knows its own cost.**

This ADR is unusual in a good way: it's explicitly a response to an external review that
called out a real, specific architectural lie (the codebase talked about being
"server-authoritative" while every concrete data structure — `InventorySystem._items`,
`PlayerStateService._current` — was hard-coded single-player). Rather than picking a
comfortable middle ground, it correctly identifies that "Hosted Coop" and "dedicated server"
don't need separate codebases (citing the real-world precedent of how established
listen-server/dedicated-server games solve this with Tier-as-runtime-property rather than
Tier-as-build-flag) and rejects the tempting full-server-farm option as solving a problem
nobody has yet. The reasoning is specific, cites actual file:line evidence for its own
problem statement, and the "Reihenfolge" section sequences the work correctly (multi-tenancy
before any RPC wiring, Tier 2 proven before Tier 3 is even started).

The honest cost, which the ADR states plainly rather than burying: this requires migrating
`InventorySystem`, `PlayerStateService`, `EntityOrchestrator`, and `CombatSystem` to be keyed
by `player_id`/`peer_id` *before* a single RPC is wired — and per `docs/review.md`, that
migration (MIGRATION-010) is only through Phase 0–3 of what's apparently a 5-phase plan
("Phase 4+5 → Session 9+"). That's fine as a sequencing choice. What I'd flag for the
implementation plan: **this is a lot of forward-looking architecture for systems whose
single-player path was, until this audit, silently broken** (Finding 1, companion doc). The
honest prioritization question for a 20-year foundation isn't "is multiplayer architecture
worth doing" — it clearly is, and ADR-010 argues for it well — it's "should Phase 4/5 of a
multiplayer migration proceed before the single-player skill loop has a passing test,"
and I'd argue no. Sequencing, not soundness, is the issue here.

---

## Cross-ADR pattern, stated once instead of ten times

Every ADR in this set that includes a "Bekannter Tech Debt" or "Ablösung" section is, in
effect, making a promissory claim about future verification that nothing in the current
process actually enforces. Three of ten ADRs were spot-checked against the code in this round
(004, 006 directly; 003's closure claim indirectly) and two were stale. That's not a damning
hit rate given the small sample, but it's exactly the prior the "trust code, not comments"
instruction was warning about, and it generalizes: **any ADR debt item or status claim in this
project should be treated as "as of the date written" until grep-verified, not as current
truth.** This is the single most actionable structural recommendation in this entire audit —
more valuable than fixing any individual ADR's staleness, because it prevents the next ten.
