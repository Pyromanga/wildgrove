# WildGrove — Audit Round 3: Scene File (`.tscn`) Wiring

Companion to `AUDIT-01`/`02`/`03`. This round covers the `.tscn` scene-wiring slice from
`AGENT.md`'s pickup list — the one category of bug invisible to a script-only read, because
node trees and editor-set paths live in `.tscn` files, not `.gd` files.

## Scope and method

The project has only 3 scene files: `scenes/Main.tscn`, `scenes/MainMenu.tscn`,
`scenes/World.tscn` (everything else is built programmatically via `.new()`/`add_child()`,
consistent with the Factory-pattern code seen throughout earlier rounds). All three were read
in full. For each, I checked: do `ext_resource` script paths resolve to real files; are there
any editor-made `[connection]` signal bindings to verify against actual method names; and —
the thing that actually turned up a bug — do any scripts attached to these scenes call
`get_node()`/`get_node_or_null()` with a path, and if so, does that path match the real node
tree as declared in the `.tscn`, not just what a developer assumed it was.

---

## Finding 4 — CRITICAL: the main menu cannot start a game at all

**File:** `scripts/ui/MainMenuController.gd`, lines 110–115, cross-checked against
`scenes/MainMenu.tscn`.

```gdscript
func _get_character_list() -> Node:
    return get_node_or_null("CharacterList")

func _get_new_game_button() -> Button:
    return get_node_or_null("NewGameButton") as Button
```

`MainMenuController.gd` is attached to the scene's root node, `MainMenu`. Both lookups are
relative paths, meaning Godot looks for `CharacterList`/`NewGameButton` as **direct children**
of `MainMenu`. But the actual scene tree in `MainMenu.tscn` is:

```
MainMenu (Control, script attached)
├── Background (ColorRect)
└── CenterContainer (VBoxContainer)
    ├── TitleLabel
    ├── SubtitleLabel
    ├── Spacer
    ├── CharacterList (VBoxContainer)   ← actual path: "CenterContainer/CharacterList"
    ├── Divider
    └── NewGameButton (Button)          ← actual path: "CenterContainer/NewGameButton"
```

Both target nodes are grandchildren of `MainMenu`, nested under `CenterContainer`. The bare
paths used in the script don't match anything, so both getters always return `null`. I checked
for the one thing that could make this a non-issue — a `%NodeName` unique-name binding, which
would let a bare name resolve regardless of nesting — and confirmed `MainMenu.tscn` has no
`unique_name_in_owner` flags set on either node, and the script doesn't use the `%` prefix
anywhere. There's no escape hatch here; the paths are simply wrong.

**This doesn't crash — which is exactly why it's dangerous.** Every call site defensively
checks the result before using it:

```gdscript
func _add_character_button(player_id: String) -> void:
    var list := _get_character_list()
    if not list:
        return                      # ← always hits this, silently, no error logged

func _update_new_game_button(existing_saves: Array[String]) -> void:
    var btn := _get_new_game_button()
    if btn:                         # ← never true
        btn.text = ...
        btn.pressed.connect(_on_new_game_pressed, CONNECT_ONE_SHOT)
```

The practical effect, traced end to end:

- `_refresh_ui()` runs on every `_ready()` and on every return to the menu. It calls
  `_add_character_button()` once per existing save — which immediately no-ops every time, so
  **no character-select buttons are ever created**, regardless of how many saves exist.
- `_update_new_game_button()` also no-ops every time, which means **`NewGameButton.pressed` is
  never connected to `_on_new_game_pressed()`**. The button is visually present (it's declared
  directly in the `.tscn` with its default text), but clicking it does nothing — no signal
  handler is attached.
- `_on_new_game_pressed()` and `_on_character_selected()` are both correctly implemented
  (verified — they call `EventBus.system.emit_session_requested(...)` exactly as the flow
  comment at the top of the file describes) and **are completely unreachable from the UI**, for
  exactly the same reason.

There is no other entry point into gameplay in this codebase — `MainMenu.tscn` is the
project's actual `run/main_scene` (confirmed in `project.godot`). **As currently wired, a
fresh checkout of this project cannot reach gameplay at all** — not "the skill system breaks
when you chop a tree" (Finding 1), not "the HUD doesn't appear" (Finding 2) — the player never
gets past a static title screen with one inert button. Every other finding in this audit
series is downstream of this one in the sense that none of them are reachable through normal
play until this is fixed.

**Fix is a one-line-per-getter path correction:**
```gdscript
return get_node_or_null("CenterContainer/CharacterList")
return get_node_or_null("CenterContainer/NewGameButton") as Button
```
or, more robustly against future layout changes, mark both nodes `unique_name_in_owner = true`
in the scene and reference them as `%CharacterList` / `%NewGameButton` instead, which survives
re-nesting. I'd recommend the `%` approach specifically because this bug class — a path that
was correct once and silently broke when someone added a wrapping container — is exactly the
kind of drift this whole audit keeps finding elsewhere in the codebase, and unique names are
structurally immune to it.

---

## Finding 5 (minor, currently dormant) — `Main.tscn` is an orphaned scene that contradicts its own script's documentation

`scenes/Main.tscn` instantiates two nodes: `Main` (script: `Main.gd`) and a child node named
`ServiceOrchestrator` (script: `ServiceOrchestrator.gd`). But `ServiceOrchestrator.gd` is
*also* registered as a project autoload (`project.godot`'s `[autoload]` block), and `Main.gd`'s
own top-of-file doc comment says, in German, explicitly: *"ServiceOrchestrator ist ein
Autoload (/root/ServiceOrchestrator), kein Kind-Node von Main.tscn"* — ServiceOrchestrator is
an Autoload, **not** a child node of Main.tscn. The scene contradicts the comment in the script
it's paired with.

I checked whether this matters in practice: `project.godot`'s `run/main_scene` is set to
`res://scenes/MainMenu.tscn`, not `Main.tscn`, and a project-wide grep for `"Main.tscn"` found
no `load()`/`preload()`/`change_scene_to_file()` reference to it anywhere — the only mention of
the string "Main.tscn" in the entire codebase is inside `Main.gd`'s own comment, referring to
itself. So this scene is currently orphaned — never loaded by anything — which means the
contradiction is dormant, not actively causing a bug today.

I'm still flagging it, for two reasons: first, it's exactly the kind of "Altlast" (cruft) the
original ask was about — a scene file nobody deleted after the boot architecture changed to
autoload-based, left half-consistent with itself. Second, if anyone ever does wire `Main.tscn`
back in (e.g. for a manual smoke-test scene, or because a future contributor doesn't know it's
dead), it would silently boot a second, parallel `ServiceOrchestrator` instance alongside the
autoload one — double service registries, double boot pipeline execution — and nothing in
`ServiceOrchestrator.gd`'s `_ready()` guards against running twice (no idempotency check, no
singleton-instance comparison). Recommend either deleting `Main.tscn` outright, since
`Main.gd`'s own comment says it's optional, or fixing it to not duplicate the autoload.

---

## What's clean in this round

Worth stating plainly: there are zero `[connection]` blocks in any of the 3 `.tscn` files,
meaning there is no editor-only signal wiring hiding anywhere in this project — every signal
connection is made in script, via `EventBus` or direct `.connect()` calls, which is consistent
with `ADR-002`'s namespacing decision and means a script-only read (as in rounds 1 and 2) isn't
missing a whole category of hidden wiring beyond what this round specifically checked (node
paths). All four `ext_resource` script paths across the three scenes resolve to real files.
`World.gd` does zero `get_node()` calls, so it isn't exposed to the same path-mismatch risk
that broke `MainMenuController.gd`.

---

## Scope note

This closes the `.tscn` item from `AGENT.md`'s pickup list — there were only 3 scene files, so
this round is complete for that slice, not partial. Still open: `scripts/ui/components/` and
`scripts/ui/visuals/` for logic-level review (not just identifier existence, which round 2
already covered project-wide), the rest of `scripts/world/` for the same, the existing test
files' actual content/correctness, `docs/principles.md`/`services.md`/`history.md`/
`CONTRIBUTING.md`/`MIGRATION*.md`, and — still the single highest-leverage next step whenever
it's available — actually opening this project in the Godot editor, which would have caught
Finding 4 immediately via a runtime null-reference pattern (or, if Godot's editor warns on
unused signal-eligible nodes, possibly even pre-emptively) and confirms or refutes the
load-time-failure hypotheses raised in `AUDIT-03`'s Findings 2 and 3.
