# WildGrove — Audit Round 4: Test Suite Content Review (+ one correction to round 1)

Companion to `AUDIT-01`–`04`. This round covers the test-content slice from `AGENT.md`'s
pickup list: do the 7 unit test files and `IntegrationTest.gd` actually test current APIs, and
is anything about them itself unreliable.

**Important context, provided by the project owner after round 3:** none of these tests have
actually been executed even once since the major rebuild this session's zip represents. That
changes what "this test file is accurate" means below — it's a static claim (the test calls
methods that exist, with matching signatures, on the classes it claims to test), not a claim
that the test currently passes or has ever been run. Treat everything in this document as
"verified by reading," same standard as every prior round.

---

## Headline result: the pure-logic test files are good. The gap is structural, not quality.

I cross-checked every call in all 7 `tests/unit/*.gd` files against the actual method
signatures in the services/resources they claim to test: `test_combat_system.gd` (489 lines,
33 test functions) against `CombatSystem.gd`/`DamageRecord.gd`/`CombatProfile.gd`,
`test_quest_objective.gd` against `QuestObjectiveHandler.gd`/`QuestProgressRecord.gd`,
`test_save_system.gd` (301 lines) against `SaveSystem.gd`, `test_stat_modifier.gd` against
`StatModifierService.gd`/`StatModifier.gd`, `test_entity_context.gd` against `EntityContext.gd`,
`test_equipment_service.gd` against `EquipmentService.gd`, `test_save_migration.gd` against
`SaveMigrationService.gd`. **All 7 use current, real method names and signatures — none are
testing a stale or removed API.** `test_combat_system.gd` in particular is genuinely
well-designed: it explicitly handles the fact that `calculate_damage()` rolls a real, unseeded
crit chance in most tests (documented helper `_assert_damage_matches_expected_or_crit()` that
accepts either the base or crit-multiplied value, rather than being flaky ~5% of the time or
ignoring the randomness), and separately has a dedicated deterministic test using injected RNG
for the cases that need exact values. `test_save_system.gd` explicitly tests `.bak`-file
handling (excluded from listing, removed on delete) — see the correction below for why that
matters.

So the quality bar on these 7 files is good. The actual gap, visible once you compare this
list against the bugs found in rounds 1–3, is about **what has zero coverage, not about the
coverage that exists being wrong**: `SkillSystem` (Finding 1), `WorldService`'s HUD wiring
(Finding 2), `Factory3D`/`InteractableComponent`'s `Bar3D` (Finding 3), and
`MainMenuController` (Finding 4) have no tests at all. Every one of those is the
stateful, Node-lifecycle, manually-wired layer; every one of the 7 covered classes is either a
pure static-function class or a `RefCounted` service with no `SceneTree` dependency. That's not
a coincidence — `tests/README.md` says as much explicitly (see below) — but it means the test
suite's coverage shape exactly mirrors where the bugs aren't, not where they are.

---

## Correction to `AUDIT-02`: the atomic-save-write claim was wrong, and it's wrong for the exact reason this audit series exists

In `AUDIT-02-adr-meta-analysis.md`, I wrote that ADR-005's "Bekannter Tech Debt" list — no
atomic write, no backup, no save slots — was real and current, and used "no atomic write" as
the clearest example in the whole project of a lazy workaround being accepted where better code
should have been required.

That was wrong, and I want to be specific about how it was wrong rather than just quietly
fixing it. I based that claim on reading ADR-005's *prose description* of the save system's
state, not on reading `SaveSystem.gd` itself. Having now actually read `SaveSystem.gd` while
checking its test file: it has a fully implemented `_atomic_write(path, data)` (writes to
`path + ".tmp"`, copies the existing file to `path + ".bak"` as a backup before replacing it,
then does `DirAccess.rename_absolute()` for the atomic swap), and `test_save_system.gd`
correctly exercises the `.bak` side effects (excluded from `list_local_saves()`, removed
together with the main file on delete). **The thing I flagged as the project's clearest example
of accepted technical debt is, in fact, already fixed, tested, and working correctly per static
review.** ADR-005's text is stale in the same direction `AUDIT-01` Finding 4 already documented
for ADR-004 and ADR-006 — debt marked open that's actually closed — I just hadn't re-verified
it myself yet when I wrote `AUDIT-02`.

I'm leaving this correction here rather than silently editing `AUDIT-02`, on the same
principle `AGENT.md` states for everything else in this project: a claim that turns out to be
wrong should be visible as a correction, not quietly disappeared, so whoever is cross-checking
this audit series can see the mistake and the fix both. **Practical effect: remove "atomic save
write" from any implementation-plan priority list built from `AUDIT-02` — it's done.** What's
still genuinely open per ADR-005's list and not yet independently re-verified by me: save
slots (multiple characters per save — actually, `SaveSystem.gd`'s `get_save_path(player_id)`
and `has_save_for(player_id)`/`list_local_saves()` suggest per-player-id saves already exist in
some form, which would mean this item may also be stale; I have not fully traced this and am
flagging it as unverified rather than asserting either way) and partial/incremental save
(unverified).

---

## Finding 6 — `IntegrationTest.gd`'s only test likely never runs its assertions

```gdscript
func before_all() -> void:
    if not EventBus.system.services_initialized.is_connected(_on_services_ready):
        EventBus.system.services_initialized.connect(_on_services_ready, CONNECT_ONE_SHOT)

func _on_services_ready() -> void:
    test_check_services_integrity()
```

This test doesn't run its assertions directly — it connects a listener to
`EventBus.system.services_initialized` and only runs `test_check_services_integrity()` if that
signal fires *after* `before_all()` executes. `ServiceOrchestrator` is a project autoload; per
Godot's autoload/scene loading order, autoloads instantiate and run their own `_ready()`-driven
boot sequence before the main scene (or, in a `gut_cmdln.gd`-driven headless test run, before
GUT's own test-discovery script) loads. That means there's a real chance
`services_initialized` already fired — once, since it's presumably a one-shot lifecycle
signal — before this test file's `before_all()` ever gets a chance to connect to it. If that's
the case, the connection is made *after* the signal already fired, the listener never triggers,
and `test_check_services_integrity()` silently never runs. GUT would very plausibly report this
as a passing or empty test (zero assertions made, zero failures), not as a failure — which is
the worst outcome for a sanity check, since it looks green while verifying nothing.

I want to be precise about confidence here: this is reasoned from Godot's documented autoload
execution order, not confirmed by running it (no Godot binary available in this sandbox, and
per the project owner, the suite hasn't been run yet regardless). It's a plausible, specific,
checkable hypothesis, not a certainty — but it's exactly the kind of thing that's cheap to
confirm the first time someone actually runs the suite (watch whether
`"IntegrationTest: Services bereit — starte Tests."` appears in the log output), and worth
checking specifically because this is the one test in the whole suite that would have a chance
of catching boot-pipeline-level issues like Findings 1–4 across this audit series, if it runs
at all.

**Separately:** even if the race condition isn't real, or doesn't manifest, this test asserts
only `assert_not_null` on six services. `SkillSystem` is in that list (`Services.skill_system`)
— but `assert_not_null` only checks that the *service object exists and was registered*, not
that calling any of its methods works. Given Finding 1 (`SkillSystem._ensure_player()` crashes
on an undeclared identifier), this test would pass cleanly even with that bug present, because
nothing in it ever calls `request_add_xp()`. Worth treating "the service was registered" and
"the service works" as two different claims that need two different tests going forward.

---

## Finding 7 (minor) — `tests/README.md` documents 3 of the 7 actual test files

```
tests/
  unit/
    test_save_migration.gd     ← SaveMigrationService — pure functions
    test_quest_objective.gd    ← QuestObjectiveHandler — pure functions
    test_entity_context.gd     ← EntityContext.for_test() — kein AutoLoad
  IntegrationTest.gd
```

The actual `tests/unit/` directory has 7 files — the three above plus `test_combat_system.gd`,
`test_equipment_service.gd`, and `test_save_system.gd`. The README's own framing section ("Warum
diese drei Klassen zuerst?" — why these three first) reads as a snapshot from an earlier point
in the project's history that was never updated as more tests were added. Low severity, same
root cause as everything else in this audit series: a doc that was accurate once, and nothing
forces it to stay that way as the code keeps moving.

---

## What I did not check this round

The actual *behavioral correctness* of each test's assertions (e.g., whether
`test_armor_clamped_at_max_85_percent()`'s expected value is the right one given
`CombatSystem`'s actual clamp constant) was spot-checked for a handful of cases, not
exhaustively re-derived for all ~140 assertions across 7 files — that level of verification is
better done by actually running the suite once Godot is available, which would either confirm
or refute all of it in one pass far more cheaply than continuing to do it by hand here. Also
not done: tracing whether `GameSaveService`, `RewardDispatcher`, `NetworkBridge`, or any of the
other `ServiceNode`-based services flagged as "unaudited" back in `AUDIT-02`'s ADR-003 section
have any test coverage at all (a quick `ls tests/unit/` answer is "no," since none of the 7
files reference them, but I haven't separately verified each of those services' actual
correctness the way I did for the 7 that do have tests).
