# WildGrove — Audit Round 5: UI Layer Logic Review (components/controllers/visuals)

Companion to `AUDIT-01`–`05`. This round covers the `scripts/ui/` logic-level review from
`AGENT.md`'s pickup list — 47 files, ~2,066 lines, the Component→Controller→Visuals triad
architecture that assembles the in-game HUD.

## Headline result: this is the most solid layer audited so far

Unlike every prior round, this one is mostly a confirmation, not a bug list. Three systematic
checks, each covering the whole layer rather than spot-checking:

1. **Every `HUDBuilder.build_all()` call matches its target's actual signature**, all 13 of
   them (`InteractionComponent`, `InteractionButtonComponent`, `InventoryComponent`,
   `FloatingTextComponent`, `NotificationComponent`, `JoystickComponent`,
   `ContextButtonComponent`, `ContextMenuComponent`, `PauseMenuComponent`,
   `SkillPanelComponent`, `QuestPanelComponent`, `PlayerHPComponent`, `JumpButtonComponent`).
   Checked by extracting every `.build()` signature directly from the component files and
   diffing against `HUDBuilder.gd`'s call sites by hand — no mismatches.
2. **Zero stale `EventBus.namespace.signal` references project-wide.** I wrote a script that
   extracts every signal/method declared in each of the 5 `EventBus` namespace classes
   (`PlayerEvents`, `WorldEvents`, `SystemEvents`, `UIEvents`, `QuestEvents`) and cross-checked
   every `EventBus.x.y` usage across the entire codebase (not just `scripts/ui/`) against that
   set. Result: 0 mismatches out of however many call sites exist. This is real, structural
   evidence that ADR-002's namespacing decision is being followed correctly everywhere, not
   just in the files I happened to read by hand in earlier rounds.
3. **The one other `get_node_or_null()` call in this layer besides `MainMenuController`'s
   (round 3, Finding 4) is correct.** `PlayerHPController._try_initial_sync()` looks up
   `player.get_node_or_null("HealthComponent")`; `PlayerSetup._build_health()` literally sets
   `health.name = "HealthComponent"` on the node it creates. Matches exactly.

Three controllers were read in full as deeper spot checks (`PauseMenuController.gd`,
`ContextMenuController.gd`, plus `PlayerHPController.gd` above) and all three are genuinely
well-written: defensive validity checks (`is_instance_valid()`) before every cross-node access,
fallback creation logic when an expected node isn't found rather than crashing, and — notably
— `ContextMenuController.gd` has an inline comment documenting a prior fix (replacing a fragile
`Engine.get_main_loop().root` lookup with `_hud.get_tree()` specifically for testability) that
I verified is actually applied correctly, not just claimed. `Settings.gd` and `Player.gd`
(`get_context_actions()`) both match exactly what the controllers that depend on them expect.

---

## The one real pattern worth flagging, stated as a structural observation rather than a new bug

Every controller in this layer except one finds its target nodes via
`get_tree().get_nodes_in_group(...)` — a lookup that's resilient to the node tree being
restructured, since it doesn't care how deeply nested the target is. The **one** controller
that instead used a literal relative path (`get_node_or_null("CharacterList")`,
`get_node_or_null("NewGameButton")`) is `MainMenuController.gd` — and that's exactly the file
`AUDIT-04`'s Finding 4 found broken, for precisely the reason path-based lookups are fragile:
someone added a wrapping `CenterContainer` and the path silently stopped resolving. This isn't
a new finding, but it's a useful confirmation of *why* that bug happened in an otherwise
careful codebase, and it sharpens the recommendation already made in `AUDIT-04`: standardize on
group-based lookups (or `%unique_name` bindings) project-wide, and treat any future literal
`get_node("path/like/this")` as a review smell specifically because this layer's own track
record shows it's the one pattern that actually broke.

---

## One minor stale-doc note, same family as everything in `AUDIT-01` Finding 4 and `AUDIT-02`

`scripts/ui/HUD.gd`'s top-of-file comment says *"Wird von HUDManager.configure() als Instanz
erstellt"* (created as an instance by `HUDManager.configure()`). `HUDManager.gd` has no
`configure()` method — the method that actually creates `HUD.new()` is `initialize()`. Trivial
on its own; flagging only because it's another small data point for the same pattern this audit
series keeps finding: comments describing a prior method name that got renamed and the comment
never followed.

---

## A finding that connects this round back to round 2, and raises its priority

I traced where `EventBus.world.world_scene_ready` — the signal `HUDManager` listens for to
actually call `HUDBuilder.build_all()` and assemble all 13 working components found above — is
emitted from. It's `WorldService.gd` line 165, inside `on_world_scene_ready(world_root)`. That's
a *different function* than the one containing the undeclared-`_hud_manager` bug from `AUDIT-03`
Finding 2 (`on_ready()`) — but it's the **same file**. GDScript compiles a script as a whole; if
`on_ready()`'s undeclared-identifier assignment causes `WorldService.gd` to fail to load (the
open question `AUDIT-03` flagged as plausible-but-unconfirmed), then `on_world_scene_ready()`
never runs either, `world_scene_ready` is never emitted, and **none of this round's positive
findings — the correctly-wired 13-component HUD assembly — ever get a chance to execute**, even
after `AUDIT-04`'s `MainMenuController` fix lets a player reach the world.

This re-prioritizes `AUDIT-03` Finding 2 upward: it's not just "the HUD doesn't appear," it's
"the HUD doesn't appear, and everything this round confirms is correctly built sits dormant,
unreachable, behind it." Fixing `WorldService.on_ready()` is the single highest-leverage item
across all 6 rounds of this audit so far — it's the one bug whose fix unblocks the most
already-working code.

---

## Scope note

This closes the UI-layer item from `AGENT.md`'s pickup list at the depth applied in this
round: systematic checks across the whole layer (build signatures, EventBus references, the
two `get_node` call sites) plus full reads of 3 of 13 controllers as deeper spot checks. The
remaining 10 controllers and all 13 `*Visuals.gd` files were not read line-by-line — given the
consistent quality found in what was sampled, and that the systematic checks already cover the
two bug classes that have actually mattered so far (signature mismatches, stale references),
I'm treating this layer as adequately covered for this audit series rather than continuing to
read every remaining file by hand. If a future pass wants full coverage, the remaining files are
listed in the round's initial `find scripts/ui -name "*.gd"` output, available to re-run.

Still open from `AGENT.md`'s original list: the rest of `scripts/world/` (entity layer logic
beyond round 2's identifier sweep), and the prose docs (`principles.md`, `services.md`,
`history.md`, `CONTRIBUTING.md`, `MIGRATION.md`, `MIGRATION-010.md`).
