# WildGrove — Audit Round 1: Pain Points & Review-vs-Reality Verification

**Auditor:** Claude (Sonnet 4.6), independent pass on the `session9_fixes` zip
**Methodology:** Static reading of source files only. No Godot binary available in this
environment (sandboxed, no network), so nothing here was *executed* — every claim below is
backed by a direct file/line citation, not by trusting any `.md` file's prose. Where
`docs/review.md` or an ADR makes a claim, it was checked against the `.gd` file it claims to
describe, not the other way around. This is explicitly in response to: "vertraue dem Code
nicht den Kommentaren."

**Scope of this round:** I read all 10 ADRs, `docs/review.md` in full, spot-checked roughly
20 of the 181 `.gd` files (prioritizing every file `docs/review.md` claims was "✅ BEHOBEN
v42"), the CI workflow you pasted, `BootstrapConfig.tres`, `project.godot`, and did
project-wide greps for IP references, `.bak` files, and a few smell patterns. I did **not**
read the UI `Visuals`/`Components` layer (~25 files), the `world/` entity layer in depth
(~25 files), `principles.md`, `services.md`, `history.md`, `CONTRIBUTING.md`,
`MIGRATION.md`/`MIGRATION-010.md` in full, or any `.tscn` scene wiring. That is explicitly
deferred — see "Not Yet Audited" at the bottom. Treat this document as round 1 of N, not a
complete audit.

---

## TL;DR — the one sentence that matters

**Ten ADRs, an 8-phase boot pipeline, a topological-sort dependency resolver, two service
registries, and a multiplayer-authority-tier model exist on top of a skill/XP system that
crashes the instant a player gains XP — and nothing in the test suite or CI pipeline would
catch it, because there's no test for that file and the CI step that runs tests is wired to
report success even when every test fails.** The architecture is not fake — most of it is
real and reasonably well-reasoned (see AUDIT-02). The problem is that documentation
confidence (checkmarks, "✅ BEHOBEN") has outpaced verification, in both directions: some
things marked fixed are broken, and some things marked as open debt are already fixed. The
docs are not a reliable map of the code's actual state. That's the core finding.

---

## Finding 1 — CRITICAL: `SkillSystem.gd` is dead on arrival

**File:** `scripts/services/SkillSystem.gd`, lines 27–31

```gdscript
func _ensure_player(player_id: int) -> Dictionary:
    if not skills.has(player_id):
        _players[player_id] = {}
        _init_player_skills(player_id)
    return skills[player_id]
```

`skills` is never declared anywhere in this file. The class's actual state dictionary is
`_players` (declared line 20, `var _players: Dictionary = {}`). There is no autoload, no
parent-class member, and no global named `skills` or `Skills` (checked `project.godot`'s
`[autoload]` block and the base class `Service.gd` directly — neither defines it). This is a
plain undeclared-identifier reference.

`_ensure_player()` is called from both public mutation paths:
- `request_add_xp()` → line 111
- `_on_xp_add_confirmed()` → line 123 (the actual XP-writing method)

Both are called every single time a player gains XP for woodcutting, mining, farming, or
combat — i.e., the entire RuneScape-style skill loop that the project's concept is built
around. There is no code path that grants XP without going through `_ensure_player()`. This
is not an edge case; it is the hot path.

**Why this matters for the "trust code, not comments" instruction:** `docs/review.md`
explicitly claims, under finding **B-05**:

> `SkillSystem.skills` war `public var` [KAPSELUNG] ✅ BEHOBEN v42 — `_players` privat.
> `get_skill_ids()` als einziger öffentlicher Accessor.

This is a textbook example of the failure mode you described. The *rename* from a public
`skills` to a private `_players` happened — but only partially. Three call sites inside the
same file (`_ensure_player`, twice) were never updated. The review correctly verifies that
*external* callers no longer reach into `skills` directly (that part of B-05 is true — see
Finding 1a below) but never noticed that the *internal* implementation still references the
old name. A documentation-level or grep-for-callers review style would miss this; only
reading the method bodies catches it.

**Severity:** Critical. This is your core gameplay loop, currently non-functional.
**Test coverage:** None. `tests/unit/` has 7 files (`test_stat_modifier`,
`test_quest_objective`, `test_save_migration`, `test_entity_context`, `test_save_system`,
`test_equipment_service`, `test_combat_system`) — zero for `SkillSystem`, despite it being
exactly the kind of pure-logic `Service` (per ADR-003) that's trivial to unit test.

### Finding 1a — the *correct* part of B-05, for fairness

The external-caller side of B-05 is genuinely true: I checked `SkillPanelController.gd` and
confirmed it goes through `_ctx.get_skill_system().get_skill_ids()` rather than touching any
internal dict directly. So B-05 is half-right — the encapsulation contract for *external*
consumers was correctly implemented; the *internal* implementation was not finished and
nothing caught it. Flagging this because a useful audit should say what's actually fine, not
just pile on.

---

## Finding 2 — CI pipeline cannot fail (the workflow you pasted)

You pasted `Build Android APK` as a separate document, not in the zip, and asked me to write
it up as a settled reference doc (done separately, see `docs/ci-pipeline.md`). Here's the
critique that belongs with it:

1. **Format check is non-blocking by design:**
   ```yaml
   - name: Format check (gdformat)
     run: |
       pip install --quiet gdtoolkit
       find project -name "*.gd" | grep -v "addons/" | xargs gdformat --check || true
   ```
   The trailing `|| true` means this step always exits 0. A format violation never fails CI.
   That may be an intentional choice (warn, don't block) — but as written there's no visible
   warning either; the output is just buried in a green log.

2. **Unit tests are non-blocking by design:**
   ```yaml
   - name: Run GUT tests
     run: |
       cd project
       godot --headless -s res://addons/gut/gut_cmdln.gd \
         -gdir=res://tests \
         -gexit \
         2>&1 || true
   ```
   This is the serious one. `|| true` here means **the CI job is green even if every single
   test fails, including a hard crash of the test runner itself.** Combined with Finding 1
   (a crashing core system with zero test coverage), this means the pipeline currently
   provides no actual signal about whether the game's core loop works. A green checkmark on
   this repo currently means "the export step produced a binary," nothing about correctness.

3. **The JUnit report step likely has nothing to publish:**
   ```yaml
   - name: Publish test report
     uses: mikepenz/action-junit-report@v4
     if: always()
     with:
       report_paths: 'project/results.xml'
   ```
   GUT's CLI runner needs an explicit export flag (commonly `-gjunit_export_path=...`) to
   produce a JUnit XML file. The invocation above does not pass one. I could not execute this
   to confirm `results.xml` is never created (no Godot binary / network in this sandbox), but
   based on reading GUT's CLI interface, this step is likely either silently finding nothing
   to publish or failing in a way that's easy to miss because nothing upstream of it can fail
   the job anyway. **This needs to be verified by actually running the pipeline once** — I'm
   flagging it as "likely," not "confirmed," in the spirit of not inventing certainty I don't
   have.

4. **`Force asset import` also swallows errors** (`2>&1 || true`) — same pattern, same risk:
   an import failure (e.g. a broken `.tres` reference) would silently produce an empty/stale
   asset cache for the subsequent export step rather than failing loudly.

5. **Version-code derivation is fragile:** the "Set version code from git commit count" step
   does `git init /tmp/gitref`, adds your repo as a remote, does a `--depth=1` fetch of a
   single SHA, then runs `git rev-list --count HEAD`. A depth-1 fetch of one commit gives a
   `rev-list --count` of 1, always — this does not actually count total commits, it just
   reconstructs "1" every time (the `--depth=1` defeats the purpose of the count). The
   fallback (`echo "1"`) and the real path produce the same wrong answer, so the bug is
   invisible — version code is silently always `0.1.1` or close to it, not a real release
   counter. Real fix: either do a full clone (no `--depth`) or use `github.run_number`
   directly instead of git history at all — it's already available as a GitHub Actions
   context value.

**Net effect:** the CI pipeline reliably builds an APK but currently asserts nothing about
correctness, formatting, or a meaningful version number. For a project explicitly aiming at
a 20+ year foundation, the test-gating issue (#2) is the one to fix first — it's the reason
Finding 1 could ship to a device without anyone noticing until they tried to chop a tree.

---

## Finding 3 — ADR index has broken links, on every entry

`docs/adr/000-index.md` lives at `docs/adr/000-index.md`. Its table links use paths like:

```markdown
| [001](adr/001-service-locator-pattern.md) | ...
```

Since the index file is *already inside* `docs/adr/`, this relative path resolves to
`docs/adr/adr/001-service-locator-pattern.md`, which does not exist. All 10 links in the
index are broken in the same way. Separately, two of those ten point to filenames that don't
exist at all even with the prefix fixed: the index lists `005-save-provider-pattern.md` and
`006-entity-context-injection.md` as two separate files, but they were merged at some point
into the single `005-006-save-provider-entity-context.md` that actually exists on disk. The
index was never updated to reflect that merge. Minor in isolation, but it's the same root
cause as Finding 1: a structural change happened (file merge) and one of the two places that
needed to know about it didn't get updated.

---

## Finding 4 — ADRs themselves contain stale "known tech debt," in *both* directions

This is worth its own finding because it's the clearest evidence that **no prose document in
this repo — not `review.md`, not the ADRs — is reliable as a snapshot of current code state.**
Two examples, opposite directions:

**4a — ADR-004 claims debt that's already paid off.** ADR-004 ("request_/on_*_confirmed
pattern") lists as open tech debt:

> `QuestService` und `SkillSystem` haben die Konvention noch nicht vollständig umgesetzt

I checked both. `SkillSystem.gd` has `request_add_xp()` / `_on_xp_add_confirmed()`.
`QuestService.gd` has `request_start_quest()` / `_on_quest_start_confirmed()` and
`request_complete_quest()` / `_on_quest_complete_confirmed()`. The pattern is fully
implemented in both. The ADR's debt list is simply wrong as of the current code — it
describes a past state.

**4b — ADR-006 claims debt that's already paid off.** ADR-006 ("EntityContext injection")
lists as open tech debt:

> `Player.gd` nutzt noch `Services.player_states`, `Services.game_manager` direkt in
> `_physics_process()`

I checked `Player.gd`. It contains the comments `## on_spawn() — Einstiegspunkt via
EntityOrchestrator. Kein Services.xyz.` and `# Physics-Loop — kein Services.xyz-Zugriff`, and
a grep for `Services\.` in that file returns zero actual usages (only those two comments,
which are denials, not calls). This debt item is also already resolved.

**Why I'm flagging stale-pessimism as much as stale-optimism (Finding 1):** if a future agent
(or you) reads ADR-004 or ADR-006's "known tech debt" sections and spends time "fixing"
something that's already fixed, that's wasted work — same root failure as Finding 1 wasting
trust on something broken. The lesson is the same either way: **ADR "known tech debt"
sections and `review.md` checkmarks are not reliable without re-verification against the
actual file.** Whatever review process produced these documents was checking intent against
text, not text against code, exactly as `docs/review.md` itself self-diagnoses for the v39
external review pass.

---

## Finding 5 — real franchise IP references exist in 4 files, not just the README

You flagged this explicitly: no more references to real games, concepts only. I found real
game-name references in:

| File | Line | Content |
|---|---|---|
| `README.md` | throughout | "RuneScape × Animal Crossing × Stardew Valley × Zelda" framing |
| `project.godot` | line 2 | `; WildGrove — RuneScape × Animal Crossing × Stardew Valley × Zelda` |
| `scripts/resources/PlayerStats.gd` | line 31 | `## ─── Hunger (optional: Stardew-Mechanik) ───` |
| `docs/adr/010-multiplayer-authority-tiers.md` | line 40 | names all four franchises plus a claim about how RuneScape's own server architecture works |

I rewrote `README.md` in this round (see deliverable). I deliberately **did not** touch
`project.godot`, `PlayerStats.gd`, or `ADR-010` in this pass — those are live project files /
an accepted architecture decision record, and you asked for analysis-and-planning first,
implementation later. They're listed here so the cleanup is tracked and doesn't get
silently dropped; `AGENT.md` carries this forward as an explicit follow-up task.

---

## Finding 6 — things that actually are fine (so this isn't one-sided)

To honor "sei sehr kritisch" without becoming a document that cries wolf on everything, here's
what I checked and found **accurate**:

- The `scripts/debug/` cleanup claimed in `docs/review.md`'s "Cleanup-Checkliste" is real —
  the folder now contains exactly the 3 production files claimed (`SimpleTerminal.gd`,
  `SimpleTerminalUI.gd`, `TerminalController.gd`), no leftover `.md` duplicates, no `.bak`
  files anywhere in the tree.
- `A-13` (UI layer bypassing `EventBus`/`IUIContext` and touching `Services.xyz` directly) —
  verified fixed. `grep -rn "Services\." scripts/ui/controllers/` returns only a comment, not
  a live call. `IUIContext`/`UIContext` exist as described and `SkillPanelController`
  genuinely uses injected `_ctx`, not the global locator.
- `A-16` (`ServiceOrchestrator` / `GameManager` dual source of truth) — verified fixed.
  `_session_active` field is gone; `_is_session_active()` queries `GameManager` directly, as
  claimed.
- ADR-008's combat system tech debt resolution (TD-10/TD-11/TD-12/TD-13: resistance profiles,
  unified melee damage path, status-effect API, injectable RNG for deterministic crit testing)
  — verified accurate against `CombatSystem.gd`. The injectable `_rng` via
  `configure({"rng": seeded_rng})` is real and matches the ADR's description precisely.
- ADR-007's supersession by ADR-010 — verified clean. `INetworkAdapter`/`LocalNetworkAdapter`
  were genuinely deleted, not left as dead files (`find . -iname "*NetworkAdapter*"` returns
  nothing).
- `BootstrapConfig.tres`'s global/session service split matches what ADR-009 documents,
  modulo a couple of services (`equipment`, `network_bridge`) added later — normal, additive
  drift, not contradiction.

So the overall picture is: **the architecture work is mostly real and mostly accurately
described.** The failure mode isn't "this project is fake enterprise theater" — it's "the
documentation's confidence in its own checkmarks has started to outrun what's actually been
re-verified, and the one place that slipped through is the single most load-bearing file in
the whole gameplay loop."

---

## Prioritized pain points (my independent read, not from any existing doc)

1. **Core loop is broken and untested** (Finding 1). Fix `SkillSystem._ensure_player()`,
   then write `test_skill_system.gd` before anything else — this should be priority zero
   regardless of how much architecture work is queued up.
2. **CI gives false confidence** (Finding 2). The `|| true` on the test-run step is actively
   dangerous for a project that wants to scale to "20+ years, multiple contributors" — it
   means the single mechanism meant to catch exactly Finding-1-class bugs is disabled.
3. **Save system has no atomic write / no backup**, acknowledged in ADR-005 as "known tech
   debt" — for a long-lived project this is a player-data-loss risk, not a nice-to-have. It's
   currently filed at the same priority as cosmetic debt, which undersells it.
4. **Documentation-reality drift is structural, not incidental.** Finding 1, 3, and 4 are three
   independent instances of the same root cause: prose gets updated optimistically (or just
   not updated) when code changes, and nothing forces re-verification. A process fix (e.g.,
   "ADR/tech-debt closure requires a grep-verified call-site check, recorded in the PR, not
   just an editor's confidence") would prevent the next ten of these, not just patch this one.
5. **Two-registry session model (ADR-009) + multiplayer-authority-tier model (ADR-010)** are
   the largest concentration of architectural complexity in the project and are *also* the
   least exercised by tests or runtime — they're the area most likely to silently rot the same
   way `SkillSystem` did, because nothing currently forces a second player into a session to
   prove multi-tenancy actually works end to end.
6. **IP references scattered across 4 files** (Finding 5) — low severity, but worth doing as
   one atomic cleanup pass with a checklist, not piecemeal, given the demonstrated pattern of
   partial renames leaving stragglers.

---

## Not Yet Audited (explicit scope for the next pass)

So a follow-up agent — or you — knows exactly what hasn't been checked yet and shouldn't be
assumed clean just because it isn't mentioned above:

- `scripts/ui/components/`, `scripts/ui/visuals/` (~25 files) — not read at all.
- `scripts/world/` entity layer beyond the spot checks above (animals, combat, chunks, terrain,
  water, npc — ~25 files) — not read.
- `docs/principles.md`, `docs/services.md`, `docs/history.md`, `CONTRIBUTING.md`,
  `docs/MIGRATION.md`, `docs/MIGRATION-010.md` — not read in full, only referenced where the
  ADRs pointed at them.
- All `.tscn` scene files — node wiring (signal connections made in the editor, not in script)
  was not inspected at all. Given the bugs already found in script-level wiring, scene-level
  wiring is an equally plausible place for the same class of drift.
- `tests/IntegrationTest.gd` and the 7 existing unit test files — not read for correctness,
  only confirmed to exist and confirmed `SkillSystem` has no equivalent.
- A full project-wide sweep for the `skills`-style bug pattern (a renamed private field with a
  stale reference left behind) was **not** done systematically — Finding 1 was found because
  it's the one `docs/review.md` specifically claimed was fixed (B-05), which made it a natural
  first place to check given the "don't trust comments" instruction. A grep-based sweep for
  similarly-shaped renames across all 181 files would be a reasonable next step.
- Nothing in this audit was executed. Godot itself was not available in this sandbox (no
  network to fetch the binary). Static reading is strong evidence for Finding 1 specifically
  (an undeclared identifier is about as unambiguous as static analysis gets in GDScript) but
  weaker evidence for runtime-only failure modes (race conditions, signal connection order,
  scene-tree timing bugs) that this round cannot rule out either way.
