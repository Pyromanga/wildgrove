# WildGrove — Code Review & Architecture Analysis

> **Stand:** v42 — Session 8 abgeschlossen.
> Vollständige Archiv-History → `docs/history.md`

---

## 🗑️ Cleanup-Backlog — Klassifikation: Stubs · Duplikate · Legacy (Session 9)

> Basis: vollständige Codebase-Lektüre aller `.gd`-Dateien und Dokumentation (nicht nur Doku-Lektüre).
> Drei sauber getrennte Kategorien: was absichtlich leer ist, was doppelt liegt, was entfernt werden kann.

---

### Kategorie 1 — Stubs: Legitime Leerstellen (kein Handlungsbedarf)

| Datei | Methode(n) | Warum legitim |
|-------|-----------|---------------|
| `scripts/core/Service.gd` | `configure()`, `on_ready()`, `on_cleanup()` | GDScript-Interface-Ersatz: Basisklasse mit `pass`, Unterklassen überschreiben. Korrektes Muster (ADR-003). |
| `scripts/core/ServiceNode.gd` | `configure()`, `on_ready()`, `on_cleanup()` | Identische Begründung, Node-Variante. |
| `scripts/interfaces/core/ITickable.gd` | `on_tick()`, `on_cleanup()` | Formales Interface — `pass` ist die einzig mögliche GDScript-Implementierung. |
| `scripts/interfaces/core/IEntityContext.gd` | alle `get_*()` geben `null` zurück | Absichtlich: Subklassen (`EntityContext`, `MockEntityContext`) implementieren, Basis gibt nil-safe Default. |
| `scripts/interfaces/core/IUIContext.gd` | alle `get_*()` geben `null` zurück | Analog IEntityContext. Neu in v42. |
| `scripts/world/animals/AnimalBase.gd:54` | `_setup_visuals()` → `pass` | Designed für Unterklassen (Rabbit, Boar, Deer) — kein Bug, kein Altlast. |

**Fazit:** Keine dieser Stellen anfassen. In GDScript sind `pass`-Bodies in Basisklassen das einzige Pattern für abstrakte Methoden — das ist kein Bug, das ist die Sprache.

---

### Kategorie 2 — Stubs: Offene Implementierungen (Feature pending)

| ID | Datei | Stelle | Beschreibung | Priorität |
|----|-------|--------|-------------|-----------|
| S-01 | `scripts/services/CombatSystem.gd:185` | `roll_critical()` | `## TODO: crit_chance += _stat_modifiers.get_effective_stat(...)` — kein ADR, kein Issue. Fundament (StatModifier-Integration) ist fertig, kein Equipment/Skill nutzt `crit_chance` bisher. | Niedrig — beim ersten Skill/Equip mit `crit_chance`-Modifikator schließen. |
| S-02 | `scripts/services/CombatSystem.gd` | `apply_poison()` / `apply_burn()` | API implementiert und getestet. Kein einziger Aufrufer im Produktionscode (weder Waffe noch Skill löst sie aus). | Mittel — TD-12-Backlog. Anschlusspunkt via `EquipmentService.get_equipped_weapon()` bereit. |
| S-03 | `scripts/services/NetworkBridge.gd` | gesamte Datei | In Tier 1 (Solo) nie aktiv. `@rpc`-Methoden für Inventory, Quest, SkillSystem Phase 3 implementiert; Phase 4+5 (EntityOrchestrator, CombatSystem) laut MIGRATION-010 noch offen. | Niedrig — erst relevant wenn Tier 2/3 Sprint beginnt (ADR-010). |
| S-04 | `scripts/world/animals/AnimalBase.gd:196` | zweites `pass` (untere Funktion) | Tier-1-Stub in `on_despawn()` — Animals disconnecten keine EventBus-Signals weil sie keine connecten. Derzeit korrekt; wenn `AnimalBase` Signals nutzt, muss das gefüllt werden. | Niedrig — kein aktueller Fehler. |

---

### Kategorie 3 — Duplikate: Zwei Quellen für dieselbe Wahrheit

> Hintergrund: `scripts/debug/MIGRATION.md` beschreibt eine geplante Migration von `scripts/debug/` nach `docs/`. Laut Mapping sind **alle** Dateien migriert — die Originale in `scripts/debug/` hätten danach gelöscht werden sollen (`MIGRATION.md` Schritt 4). Das ist nie passiert.

| Doppelte Datei | Canonical (behalten) | Status der Divergenz |
|----------------|---------------------|----------------------|
| `scripts/debug/architecture.md` | `docs/architecture.md` | Debug-Version veraltet (kein Staleness-Hinweis). |
| `scripts/debug/principles.md` | `docs/principles.md` | Identisch bis auf Header-Leerzeichen — safe to delete. |
| `scripts/debug/services.md` | `docs/services.md` | Debug-Version fehlen: `RespawnService`, `RewardDispatcher`, `WorldGenerationService`, alle EventBus-Signals. Stark veraltet. |
| `scripts/debug/review.md` | `docs/review.md` | Größte Divergenz: 347 Zeilen (debug) vs 254 Zeilen (docs). Debug-Version enthält mehr historische Session-Findings (v28–v35), aber keine aktuellen (v39–v42). `docs/review.md` ist die gepflegte Quelle. |
| `scripts/debug/workflow.md` | `docs/workflow.md` | Diff: 0 Unterschiede — exakt identisch. |
| `scripts/debug/adr/` (9 ADRs) | `docs/adr/` (10 ADRs) | Debug fehlt ADR-010. ADR-007 in debug: 101 Zeilen (ausführliche Ursprungsversion); docs: 18 Zeilen (korrekte Kurzform „Abgelöst von ADR-010"). Debug-ADRs sind veraltet und irreführend. |

**Aktion:** Alle sechs Einträge aus `scripts/debug/` löschen. `scripts/debug/` behält danach nur die drei Produktionsdateien: `SimpleTerminal.gd`, `SimpleTerminalUI.gd`, `TerminalController.gd`.

---

### Kategorie 4 — Legacy / Altlast: Sicher löschbar

| ID | Datei | Begründung | Aktion |
|----|-------|-----------|--------|
| L-01 | `scripts/events/SystemEvents.gd.bak` | Backup-Datei aus manuellem Edit. Inhalt = SystemEvents.gd ohne 5 Signals (session_*, save_pre_flush, save_slot_deleted). Kein Produktionscode, keine Referenzen. | Löschen. |
| L-02 | `scripts/debug/Management.md` | Früher: World Management & Multiplayer Authority Matrix. Inhalt vollständig aufgegangen in `docs/adr/010-multiplayer-authority-tiers.md` + `docs/architecture.md` Abschnitt 5. | Löschen. |
| L-03 | `scripts/debug/todo.md` | Früher: 10 Enterprise-Architecture-TODOs. Alle als ✅ in `docs/review.md` Abschnitt „v29 TODOs" dokumentiert. | Löschen. |
| L-04 | `scripts/debug/MIGRATION.md` | Migrations-Guide dessen Zweck erfüllt ist — er dokumentiert die Migration nach `docs/`, die `docs/` selbst beweist. Kein Leser profitiert noch davon. | Löschen. |
| L-05 | `scripts/debug/coding.md` | Inhalt vollständig in `docs/principles.md` integriert (Best Practices, GDScript-Fallen, Enterprise-Prinzipien). | Löschen. |

---

### Kategorie 5 — Deprecated-Code: Noch im Produktionscode

| ID | Datei | Stelle | Problem | Aktion |
|----|-------|--------|---------|--------|
| C-01 | `scripts/services/DataService.gd` | `set_player_stat()` | ✅ BEHOBEN v42 — Methode entfernt. Keine aktiven Caller vorhanden (grep-verifiziert). |

---

### Cleanup-Checkliste — ✅ Session 9 angewendet

**Duplikate aus `scripts/debug/` entfernt:** ✅ `architecture.md`, `principles.md`, `services.md`, `review.md`, `workflow.md`, `coding.md`, `adr/`

**Legacy entfernt:** ✅ `SystemEvents.gd.bak`, `Management.md`, `todo.md`, `MIGRATION.md`

**Deprecated Code entfernt:** ✅ `DataService.set_player_stat()` — keine Caller, direkt gelöscht.

**Ergebnis:** `scripts/debug/` enthält nur noch `SimpleTerminal.gd`, `SimpleTerminalUI.gd`, `TerminalController.gd`. Kein doppelter Dokumentationspfad mehr.

---

## 🔴 Aktuelle Findings (v39 — Externe Architektur-Review)

> Quelle: `WildGrove_external-review_v39.md`, unabhängige Code-Lektüre (nicht nur Doku-Lektüre).
> Wiederholt nicht, was oben bereits selbst gefunden und behoben wurde — deckt Dinge auf,
> die sechs interne Review-Sessions nicht gefunden haben, größtenteils weil sie textuell/intentional
> prüften (\"ist der ADR umgesetzt?\"), nicht codebase-weit (\"wer ruft diese Methode tatsächlich
> noch auf, nachdem sich die Signatur geändert hat?\").

### A-12: Single-Tenant-Fundament ✅ BEHOBEN v42

Multi-Tenanz aller Session-Services, NetworkBridge, INetworkAdapter entfernt (MIGRATION-010 Phasen 0–3).
Phase 4+5 (Tier-2-Verdrahtung) → Session 9+. Details: `docs/history.md`

### A-13: UI-Layer durchbricht dieselbe Schichten-Regel, die für Entities als A-01 KRITISCH galt [KRITISCH] ✅ BEHOBEN v42

**Problem:** `docs/architecture.md` Abschnitt 1 ist explizit: Presentation Layer nur lesen via EventBus, nie direkt Services mutieren. Im UI-Layer existierte exakt das A-01-Muster ungefixt.

**Status:** ✅ Behoben v42 — `IUIContext` Interface + `UIContext` Implementierung eingeführt (analog `IEntityContext`). `SkillPanelController`, `QuestPanelController` bekommen `ctx: IUIContext` injiziert statt `Services.xyz`. `InteractionButtonController`, `ContextMenuController`, `PauseMenuController` nutzen `EventBus.ui.emit_interaction_execute_requested()`, `emit_scene_reload_requested()`, `emit_main_menu_requested()` — neue Signals in `UIEvents`. `InteractionExecutor` und `SceneManager`/`GameManager` lauschen darauf. `HUDBuilder.build_all()` nimmt `IUIContext` statt `Dictionary`. Verbleibend ohne Fix: `MainMenuController.save_system` (globaler Service außerhalb Session) — vertretbar.

---

### A-14: `Services.hud` referenziert ein seit A-03 entferntes Property [HOCH] ✅ BEHOBEN v42

War identisch mit B-06 (unten) — in v42 gemeinsam geschlossen.

---

### A-15: `WorldService` instanziiert UI und reicht Service-Referenzen hinein [MITTEL] ✅ BEHOBEN v42

**Status:** `HUDManager.boot(tree)` als statische Methode. `ServiceOrchestrator` ruft sie nach `session_ready.emit()` auf — kein `WorldService`-Coupling. `HUDManager` bootstrappt sich vollständig selbst über EventBus-Signals.

---

### A-16: `GameManager` und `ServiceOrchestrator` — zwei unsynchronisierte Wahrheits-Quellen [MITTEL] ✅ BEHOBEN v42

**Status:** `ServiceOrchestrator._session_active` Flag entfernt. Neue private Methode `_is_session_active()` fragt `GameManager.get_state()` ab — einzige Wahrheitsquelle. Invariante `session_active == (GameManager.get_state() == PLAYING)` ist jetzt strukturell erzwungen.

---

## ⚠️ Minor Findings (bekannt, kein akuter Bug)

| # | Beschreibung | Status |
|---|-------------|--------|
| M-01 | `AnimalBase`, `EnemyNPC`, `PetComponent` nutzen `const GRAVITY: float = 9.8` statt ProjectSettings-Wert | ✅ Behoben v42 — alle drei auf `var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)` umgestellt. |
| M-04 | Session-Referenzen in Produktionscode (`## Bug-Fix Session 5`) | Teilweise bereinigt v37 — Sweep nur für berührte Dateien. Kein projektweiter Sweep. Beim nächsten Touch bereinigen. |
| M-05 | Fehlende statische Typ-Annotationen (`Array` statt `Array[T]`). | ✅ Behoben v42 — 16 Stellen in 14 Dateien annotiert. Logger-interne Arrays (Engine-Dict-Returns) bewusst ausgelassen. |
| M-12 | Starre 200-Zeilen-Grenze war zu undifferenziert. | ✅ Behoben v42 — Regel in `docs/principles.md` ersetzt: Dateigröße als Indikator für kurze Investigation, nicht als automatische Aufteilen-Pflicht. |
| M-13 | `tests/unit/` deckt Service-/Entity-Logik ab, aber 0 von ca. 35 Dateien unter `scripts/ui/` haben Tests. Das ist exakt der Layer, in dem A-13/A-14 lebten — kein Zufall: Testbarkeit hätte Entkopplung erzwungen. | Offen — hängt an A-13 (zuerst beheben, dann testbar). A-13 ist ✅ — M-13 kann jetzt angegangen werden. |
| M-14 | `docs/architecture.md` trägt eigenen Staleness-Hinweis (nicht gepflegt seit v32, jetzt v42). Tech-Debt-Tabelle TD-02 stimmt nicht mehr (3/6 Services migriert zu `Service`, Rest offen). | Offen — Überarbeitung fällig. Entweder die Tabelle aktualisieren oder `docs/review.md` als primäre Tech-Debt-Quelle deklarieren und `docs/architecture.md` zu reiner Struktur-Referenz machen. |

---

## 🔴 Aktuelle Findings (v42 — Code-Lektüre Session 8)

> Gefunden beim Bereinigen von Legacy-Kommentaren nach der MIGRATION-010-Implementierung.

### B-01: `SkillPanelController` iterierte nach Migration über `peer_id`s statt `skill_id`s [LAUFZEIT-BUG] ✅ BEHOBEN v42

`SkillSystem.get_skill_ids(player_id)` ergänzt, `_players` privat, `SkillPanelController` nutzt jetzt `ss.get_skill_ids()` statt direkten Dict-Zugriff.

### B-02: `QuestNPC.on_despawn()` leakte drei EventBus-Signals [SIGNAL-LEAK] ✅ BEHOBEN v42

`on_despawn()` disconnectet alle drei Signals mit `is_connected()`-Guard.

### B-03: `EnemyNPC.on_despawn()` trennte `_health.died` nicht [RACE CONDITION] ✅ BEHOBEN v42

`on_despawn()` disconnectet `_health.died` mit `is_instance_valid(_health)`-Guard.

### B-04: `RewardDispatcher`-Kommentar behauptete falsche Abhängigkeit [DOKU-BUG] ✅ BEHOBEN v42

Kommentar korrigiert.

### B-05: `SkillSystem.skills` war `public var` [KAPSELUNG] ✅ BEHOBEN v42

`_players` privat. `get_skill_ids()` als einziger öffentlicher Accessor.

### B-06: `PauseMenuController` griff auf `Services.hud` zu — Property existiert nicht [LAUFZEIT-FEHLER] ✅ BEHOBEN v42

`EventBus.ui.emit_notification()` statt `Services.hud`. `_get_hud_canvas()` sucht via Gruppe `hud_canvas`. `UIEvents.notification_requested` neu hinzugefügt.

---

## 📋 Session 9 — Priorisierte Vorschläge

**Block 1 — Cleanup (Vorbedingung für alles andere):**

Alle Aufgaben aus der Cleanup-Checkliste oben abarbeiten. Kein inhaltliches Risiko, nur `rm`-Befehle und das Entfernen einer toten Methode. Danach: keine doppelten Dokumentationspfade mehr, kein `SystemEvents.gd.bak`, kein DEPRECATED-Code ohne Caller.

**Block 2 — Offene Bugs:**

- **M-13 (UI-Tests)** — A-13 ist behoben, UIContext ist injizierbar, MockUIContext ist in 5 Minuten geschrieben. Drei Controller als Start: `SkillPanelController`, `QuestPanelController`, `NotificationController`.

**Block 3 — Feature-Verdrahtung:**

- **S-02 / TD-12: Status-Effekt-Integration** — `apply_poison()` / `apply_burn()` aus `CombatSystem` mit Gameplay verbinden. Anschlusspunkt: `EquipmentService.get_equipped_weapon()` (neu in v42) → `CombatSystem.player_melee_damage()` liest `on_hit_effect` / `on_hit_ticks` / `on_hit_damage_per_tick`. Verdrahtung in `EnemyNPC._on_interacted()` wo `_health` verfügbar ist.
- **S-01: crit_chance** — kleiner TODO in `roll_critical()`, erst sinnvoll wenn ein Equipment oder Skill `crit_chance` als StatModifier liefert.

**Block 4 — Technische Schuld:**

- **M-14: `docs/architecture.md` aktualisieren** — TD-02-Status, Boot-Pipeline, aktueller Service-Stand.
- **M-01: GRAVITY** — `ProjectSettings.get_setting("physics/3d/default_gravity")` statt Konstante.
- **M-05: Untyped Arrays** — `_save_providers: Array[ISaveProvider]`, `actions: Array[InteractableAction]` etc. — sichere Einzeländerungen.
- **27: `MainMenuController` UX** — Charakter-Lösch-Button, Bestätigungsdialog. `Services.save_system` bleibt dort vertretbar (globaler Service, kein Session-Scope).
