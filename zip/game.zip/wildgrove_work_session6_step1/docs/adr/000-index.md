# Architecture Decision Records — WildGrove

ADRs dokumentieren **warum** Entscheidungen getroffen wurden, nicht nur was entschieden wurde.  
Sie sind unveränderliche Geschichte: ein ADR wird nie gelöscht, nur durch einen neuen ADR abgelöst.

---

## Index

| Nr. | Titel | Status | Datum |
|-----|-------|--------|-------|
| [001](adr/001-service-locator-pattern.md) | Service Locator statt vollständigem DI-Container | Akzeptiert | 2026-06 |
| [002](adr/002-eventbus-namespacing.md) | EventBus mit typisierten Namespaces | Akzeptiert | 2026-06 |
| [003](adr/003-servicenode-vs-service.md) | ServiceNode (Node) vs Service (RefCounted) als Basisklassen | Akzeptiert | 2026-06 |
| [004](adr/004-request-confirmed-pattern.md) | request_/on_*_confirmed als Networking-Kontrakt | Akzeptiert | 2026-06 |
| [005](adr/005-save-provider-pattern.md) | ISaveProvider-Interface statt zentraler Save-Logik | Akzeptiert | 2026-06 |
| [006](adr/006-entity-context-injection.md) | EntityContext-Injection statt direktem Services-Zugriff in Entities | Akzeptiert | 2026-06 |
| [007](adr/007-network-adapter.md) | INetworkAdapter-Interface + LocalNetworkAdapter als Offline-Stub | Abgelöst von ADR-010 | 2026-06 |
| [008](adr/008-combat-system.md) | CombatSystem mit DamageRecord + DamageType | Akzeptiert | 2026-06 |
| [009](adr/009-global-vs-session-services.md) | Global-Services vs. Session-Services — Charakter-Wechsel ohne App-Neustart | Akzeptiert | 2026-06 |
| [010](adr/010-multiplayer-authority-tiers.md) | Multiplayer-Authority — Listen-Server/Dedicated-Server-Dualität auf Godots MultiplayerAPI | Akzeptiert | 2026-06 |

---

## ADR-Template

Neue ADRs mit dieser Vorlage anlegen: `docs/adr/NNN-kurztitel.md`

```markdown
# ADR-NNN: Titel

**Status:** Vorgeschlagen | Akzeptiert | Abgelehnt | Abgelöst von ADR-XXX  
**Datum:** YYYY-MM  
**Kontext:** [Wer ist betroffen?] [Welche Systeme?]

## Problem

[Welches Problem löst diese Entscheidung? Was war der Auslöser?]

## Optionen

### Option A: [Name]
[Beschreibung]
- ✅ Vorteile
- ❌ Nachteile

### Option B: [Name]
[Beschreibung]
- ✅ Vorteile
- ❌ Nachteile

## Entscheidung

[Welche Option wurde gewählt und warum?]

## Konsequenzen

### Positiv
- [Was wird besser?]

### Negativ / Risiken
- [Was wird schlechter oder welche neuen Probleme entstehen?]

### Mitigationen
- [Wie werden die Risiken abgefedert?]

## Ablösung

[Leer lassen bis dieser ADR durch einen neuen abgelöst wird]
```
