# Docs-Migration Guide

Dieser Guide erklärt welche alten Dokumentationsdateien durch welche neuen ersetzt werden, und wie die Migration Schritt für Schritt erfolgt.

---

## Mapping: Alt → Neu

| Alte Datei | Neue Datei | Status |
|-----------|-----------|--------|
| `scripts/debug/architecture.md` | `docs/architecture.md` | ✅ Ersetzt |
| `scripts/debug/principles.md` | `docs/principles.md` | ✅ Ersetzt |
| `scripts/debug/coding.md` | `docs/principles.md` (integriert) | ✅ Ersetzt |
| `scripts/debug/services.md` | `docs/services.md` | ✅ Ersetzt |
| `scripts/debug/review.md` | `docs/review.md` | ✅ Ersetzt + erweitert |
| `scripts/debug/workflow.md` | `docs/workflow.md` | ✅ Ersetzt |
| `scripts/debug/Management.md` | `docs/adr/001–006` + `docs/architecture.md` Abschnitt 5 | ✅ Inhalt integriert |
| `scripts/debug/todo.md` | `docs/review.md` Abschnitt "v29 TODOs" | ✅ Inhalt integriert |
| *(neu)* | `CONTRIBUTING.md` | ✅ Neu angelegt |
| *(neu)* | `docs/adr/000-index.md` | ✅ Neu angelegt |
| *(neu)* | `docs/adr/001–006` | ✅ Neu angelegt |

---

## Migrations-Schritte

### Schritt 1 — Neue Dateien ins Repo kopieren
```
CONTRIBUTING.md          → /CONTRIBUTING.md (Projekt-Root)
docs/architecture.md     → /docs/architecture.md
docs/principles.md       → /docs/principles.md
docs/services.md         → /docs/services.md
docs/review.md           → /docs/review.md
docs/workflow.md         → /docs/workflow.md
docs/adr/000-index.md    → /docs/adr/000-index.md
docs/adr/001-*.md        → /docs/adr/
...
```

### Schritt 2 — Alte Dateien deprecaten (nicht sofort löschen)
Jeden Header der alten Datei mit einem Deprecation-Hinweis versehen:

```markdown
> ⚠️ DEPRECATED — Diese Datei wird nicht mehr gepflegt.
> Aktuelle Version: `docs/architecture.md`
> Diese Datei kann nach Bestätigung gelöscht werden.
```

### Schritt 3 — Cross-Referenzen aktualisieren
Stellen im Code die auf die alten Docs verweisen:
- `scripts/core/Service.gd` — kein Verweis
- `scripts/interfaces/core/NetworkContract.gd` — kein Verweis
- SimpleTerminal help-Text — falls vorhanden, auf neue Pfade zeigen

### Schritt 4 — Alte Dateien löschen
Nach einer Cooling-Off-Periode (eine Session ohne Probleme):
```
rm scripts/debug/architecture.md
rm scripts/debug/principles.md
rm scripts/debug/coding.md
rm scripts/debug/services.md
rm scripts/debug/review.md
rm scripts/debug/workflow.md
rm scripts/debug/Management.md
rm scripts/debug/todo.md
```

`scripts/debug/` behält nur:
- `SimpleTerminal.gd`
- `SimpleTerminalUI.gd`
- `TerminalController.gd`

---

## Was sich inhaltlich geändert hat

### docs/architecture.md (vs. alter architecture.md)
- **Neu:** Explizites Schichtenmodell-Diagramm
- **Neu:** Vollständige Boot-Pipeline-Tabelle
- **Neu:** Networking-Kontrakt-Sektion
- **Neu:** Bekannte Tech-Debt-Tabelle mit Prioritäten
- **Neu:** Priorisierte nächste Sessions
- **Aktualisiert:** Suffix-Konventionstabelle um AI, NPC, Data, Definition erweitert

### docs/services.md (vs. alter services.md)
- **Entfernt:** Veraltete Einträge (factory3d als eigenständiger Service, ui_canvas)
- **Neu:** `RespawnService`, `RewardDispatcher`, `WorldGenerationService` vollständig dokumentiert
- **Neu:** Tech-Debt-Marker (¹²³) pro Service
- **Neu:** Vollständige Change-Impact-Matrix
- **Aktualisiert:** Alle EventBus-Signals mit Emittent und Empfänger

### docs/review.md (vs. alter review.md)
- **Behalten:** Alle v28 Findings als Geschichte (✅)
- **Behalten:** Alle v29 TODOs als Geschichte (✅)
- **Neu:** 9 neue Architektur-Findings (A-01 bis A-09) aus externem Audit
- **Neu:** Minor-Findings-Tabelle
- **Neu:** Priorisierte Session-Planung

### docs/principles.md (vs. alter principles.md + coding.md)
- **Integriert:** Inhalt aus `coding.md` (GDScript-Fallen, Enterprise-Prinzipien)
- **Neu:** Networking-Readiness-Check als Prinzip (Abschnitt 7)
- **Neu:** Explicit AUTHORITY/CHEAT-RISK Kommentar-Konvention
- **Aktualisiert:** request_/confirmed_-Pattern als Naming-Convention
