# WildGrove — Archiv behobener Findings

> Vollständige Dokumentation aller abgeschlossenen Code-Review-Findings.
> Aktive Findings und Session-Planung → `docs/review.md`

---

## Bewertung des Fundaments

Das Boot-Pipeline-System, der typisierte `ServiceOrchestrator`, der namespaced `EventBus`, das `SaveProvider`-Interface, das `NetworkContract`-Dokument und die Naming-Konventionen sind nicht hobbyistisch — sie sind architektonisch durchdacht und konsistent angewendet.

Das Projekt steht an der Grenze von "gut" zu "Enterprise-ready". Der Abstand ist kleiner als er scheint, aber er ist konkret: fehlende Interfaces wo Flexibilität gebraucht wird, zwei konkurrierende Basisklassen ohne konsequente Anwendung, ein Save-Stack ohne Atomic Write, und ein Schichtenmodell das in Teilen noch nicht konsequent durchgesetzt ist.

---

## ✅ v28 Findings — alle behoben

### C-01: AnimalBase O(n × SceneTree) per Frame
`get_nodes_in_group("player")` in `_check_player_proximity()` — 60× pro Sekunde pro Tier.  
→ **Fix:** Player-Referenz wird einmalig in `_ready()` gecacht. Retry-Once-Fallback für späten Spawn.

### C-02: InteractionExecutor SceneTree-Scan bei jeder Interaktion
`get_nodes_in_group("interaction_sensor")` in `_is_player_target()`.  
→ **Fix:** `Player.get_closest_interactable()` — O(1), korrekte Knotenreferenz statt Gruppen-Scan.

### C-03: Component rief `get_parent()._on_interacted()` auf
Direkte Verletzung der "Signale nur aufwärts"-Regel.  
→ **Fix:** `signal interacted(action_id: String)` — Component emittiert, Parent verbindet.

### C-04: Interaction-System nutzte type_id als Targeting-Key
Bei zwei gleichen Entities (zwei OakTrees) reagierten beide auf dasselbe Event.  
→ **Fix:** `Player.get_closest_interactable()` als Referenz-basierter O(1)-Vergleich.

### C-05: WorldService day_time — stale Kopie zwischen Ticks
`day_time = _time.day_time` in `on_tick()` → bis zu einem Frame veraltet.  
→ **Fix:** Computed Properties: `var day_time: float: get: return _time.day_time`.

### C-06: WorldService — non-deterministischer World-Seed
`int(Time.get_unix_time_from_system())` als Seed → jeder Scene-Reload = neue Welt.  
→ **Fix:** `WorldData.world_seed` persistent; Time-basierter Seed nur bei First-Creation.

### C-07: ChunkManager ohne Referenz — kein sauberes Cleanup
`var chunk_manager := ChunkManager.new()` als lokale Variable — `on_cleanup()` konnte ihn nicht aufräumen.  
→ **Fix:** `_chunk_manager: ChunkManager` als Member-Variable. `on_cleanup()` räumt auf.

### C-08: DataService.set_player_stat() mutierte statische Definitionsdaten
SRP-Verletzung: Lese-Repository mit Schreib-Methode.  
→ **Fix:** Methode als `DEPRECATED` markiert mit `log_warn()`. Korrekte Lösung: `StatModifierService`.

### C-09: SkillSystem._check_level_up() war rekursiv — Stack-Overflow-Risiko
Bei vielen aufgestauten XP (nach Migration) → Recursion-Depth-Fehler.  
→ **Fix:** `while`-Loop statt Rekursion.

### C-10: Player._respawn() ohne Lifecycle-Guard
`create_timer(2.0).timeout.connect(_respawn)` → Crash wenn Scene während der 2s wechselt.  
→ **Fix:** `func() -> void: if is_instance_valid(self): _respawn()`

---

## ✅ v29 TODOs — alle implementiert

| # | Feature | Status |
|---|---------|--------|
| 1 | `IEntityContext` Interface + `EntityContext.from_services()` / `for_test()` | ✅ |
| 2 | Save-Versioning + `SaveMigrationService` (v0→v1→v2 Kette) | ✅ |
| 3 | `QuestProgressRecord` — typisierter Container mit Validierung | ✅ |
| 4 | `EnemyNPC._player_ref` gecacht (identisches Pattern wie AnimalBase) | ✅ |
| 5 | `RespawnService` Min-Heap — O(1) statt O(n) per Tick | ✅ |
| 6 | `InventorySystem` Slots + Gewicht + request_/confirm_-Pattern | ✅ |
| 7 | `WorldGenerationService` async Thread mit `generation_complete`-Signal | ✅ |
| 8 | UUID v4 — 128 Bit kryptografische Zufälligkeit (RFC 4122) | ✅ |
| 9 | `NetworkContract.gd` — Authority-Grenz-Dokument + Helper-Methoden | ✅ |
| 10 | Logger Background-Thread + NDJSON + Debug-Sample-Rate | ✅ |

---

## 🔴 Aktuelle Findings (v32 — Architektur-Audit)

### A-01: `Services.xyz`-Zugriff aus Entities und Components (Schichtverletzung) [KRITISCH] ✅ BEHOBEN v35

**Problem:** `Player.gd` ruft `Services.player_states.get_state()` in `_physics_process()` auf. `Player.gd` wartet auf `EventBus.system.services_initialized` — eine Entity kennt den Boot-Lifecycle. Direkte `Services.xyz`-Zugriffe aus Entity-Code verletzen das Schichtenmodell (ADR-001, ADR-006).

**Warum wichtig:** Entities sind nicht testbar wenn sie den globalen Container direkt kennen. Wenn Services umstrukturiert werden, bricht Entity-Code ohne offensichtliche Verbindung.

**Fix:** Player empfängt State-Änderungen via EventBus (`EventBus.player.state_changed`). `PlayerStateService` emittiert bei jedem `set_state()`-Aufruf. Player reagiert auf das Event statt aktiv zu pollen.

**Status:** ✅ Behoben v35 (vollständig) — Player wird jetzt via `EntityOrchestrator.spawn_entity("player", pos)` gespawnt und erhält `on_spawn(config, ctx)` mit `IEntityContext`. Kein `Services.xyz` mehr in `Player.gd` oder `PlayerSetup.gd`. Kein Boot-Warten via `services_initialized`. `WorldFactory._add_player()` entfernt. `WorldEntityRegistry` registriert `"player"`. `WorldSpawner.spawn_all()` spawnt den Player. `IEntityContext` und `EntityContext` um `get_data()` und `get_stat_modifiers()` erweitert.

---

### A-02: Zwei konkurrierende Basisklassen ohne konsequente Anwendung [MITTEL] ✅ BEHOBEN v38

**Problem:** `Service extends RefCounted` existiert, wurde aber von keinem einzigen Service genutzt. `InventorySystem`, `QuestService`, `SkillSystem`, `DataService`, `SaveSystem`, `PlayerStateService` — alle extendeten `ServiceNode` (Node) obwohl sie keinen SceneTree-Zugriff brauchen. Node-Overhead × 6 Services.

**Fix:** Schrittweise Migration. Jede `configure()` + `on_ready()` die nur `deps.get()` und EventBus-Connections nutzt (kein `add_child()`, kein `get_tree()`) → `Service extends RefCounted`.

**Status:** ✅ Behoben v38 (vollständig) — alle 6 Services auf `Service extends RefCounted` migriert. `InventorySystem`, `SkillSystem`, `QuestService` in Session 5; `DataService`, `SaveSystem`, `PlayerStateService` in Session 6. Audit vor jeder Migration bestätigte: kein Call-Site behandelt sie als `Node` (kein `get_node()`/`add_child()`/`queue_free()` von außen), `ServiceFactory`/`ServiceTicker`/`ServiceRegistry` arbeiten ohnehin duck-typed über `has_method()` (siehe ADR-003). `BootstrapConfig.tres` brauchte keine Änderung. Einziger Kollateral-Fund: `tests/unit/test_save_system.gd` nutzte `add_child_autofree(_sys)` als reines GUT-Test-Implementierungsdetail (keine echte SceneTree-Abhängigkeit von `SaveSystem` selbst) — Test auf direkte Instanziierung umgestellt. ADR-003 als "Migrations-Backlog vollständig abgearbeitet" markiert.

---

### A-03: `HUDManager` ist kein Service [HOCH] ✅ BEHOBEN v33

**Problem:** `Services.hud` verweist auf den HUDManager — aber HUDManager lebt als UI-Node und stirbt mit der Spielszene. Services leben für die gesamte Spiellaufzeit. Nach einem Szenenwechsel zeigt `Services.hud` auf einen freigegebenen Node.

**Warum HOCH (nicht Mittel):** Ein Lifecycle-Mismatch zwischen UI und Services manifestiert sich nicht als "HUDManager-Bug" — er manifestiert sich als *intermittierender Crash nach Szenenwechsel unter bestimmten Timing-Bedingungen*. Diese Bugklasse ist die schwerwiegendste weil sie nicht reproduzierbar ist: Der Crash tritt nur auf wenn ein spezifisches Timing-Fenster zwischen Szenenentladung und nächstem EventBus-Event getroffen wird. `is_instance_valid(Services.hud)`-Checks unterdrücken die Symptome, lösen das Problem nicht.

**Fix:** HUDManager aus `Services.gd` und `BootstrapConfig.tres` entfernen. HUDManager wird von `WorldService.on_world_scene_ready()` direkt instanziiert und über `EventBus.ui` kommuniziert.

**Status:** ✅ Behoben v33 — `Services.gd` hat kein `hud`-Feld mehr. `HUDManager` wird von `WorldService` instanziiert, hängt unter `/root`, kommuniziert nur via `EventBus.ui`.

---

### A-04: `GameSaveService` und `SaveSystem` — unklar überlappende Zuständigkeiten [MITTEL] ✅ BEHOBEN v34

**Problem:** Beide sind im Services-Container. `SaveSystem` ist das Provider-Aggregat und schreibt auf Disk. `GameSaveService` ist 58 Zeilen und scheint zu koordinieren — aber was genau? Die Verantwortungsgrenze ist nicht explizit dokumentiert.

**Fix:** Entscheidung: entweder `GameSaveService` hat eine klar abgegrenzte Rolle (z.B. "koordiniert Autosave-Timer + manuellen Save, ruft SaveSystem auf") oder er wird in `SaveSystem` integriert.

**Status:** ✅ Behoben v34 — Verantwortungsgrenze klar gezogen: GameSaveService koordiniert (save_pre_flush emittieren + SaveSystem delegieren), WorldService ist für eigene Daten selbst zuständig (lauscht auf save_pre_flush, sichert Pets). Kein direkter Services.world-Zugriff aus GameSaveService mehr.

---

### A-05: Kein Atomic Write im SaveSystem [HOCH] ✅ BEHOBEN v33

**Problem:** `file.store_string(JSON.stringify(state))` — wenn das Spiel während des Schreibens crasht, ist `savegame.json` korrupt. Kein Backup.

**Fix:**
```gdscript
func _atomic_write(path: String, data: Dictionary) -> bool:
    var tmp_path := path + ".tmp"
    var file := FileAccess.open(tmp_path, FileAccess.WRITE)
    file.store_string(JSON.stringify(data, "\t"))
    file.close()
    # Backup des alten Saves
    if FileAccess.file_exists(path):
        DirAccess.copy_absolute(path, path + ".bak")
    # Atomic rename
    DirAccess.rename_absolute(tmp_path, path)
    return true
```

**Status:** ✅ Behoben v33 — `_atomic_write()` implementiert: schreibt in `.tmp`, erstellt `.bak`-Backup, dann atomares Rename. Crash-sicherer Speichervorgang.

---

### A-06: Kein `INetworkAdapter`-Interface [HOCH] ✅ BEHOBEN v35

**Problem:** `NetworkContract.gd` dokumentiert die Authority-Grenzen, aber es gibt keinen Code-Stub für den Netzwerk-Layer. Wenn der erste Multiplayer-Prototyp kommt, gibt es nichts zum Ersetzen — alles muss neu geschrieben werden.

**Fix:** Interface anlegen:
```gdscript
class_name INetworkAdapter extends RefCounted
func send_request(endpoint: String, payload: Dictionary) -> void: pass
func register_handler(message_type: String, handler: Callable) -> void: pass
func is_server() -> bool: return true  # LocalAdapter immer Server
```
`LocalNetworkAdapter` als Produktions-Stub (alles lokal und synchron).  
`request_add_item()` etc. ruft `_network.send_request("add_item", {...})` statt `on_item_add_confirmed()` direkt.

**Status:** ✅ Behoben v35 — `INetworkAdapter` + `LocalNetworkAdapter` implementiert. `InventorySystem.request_add_item()` als Demo-Integration via `send_request()`. ADR-007 dokumentiert die Entscheidung. Migration-Backlog in ADR-007: QuestService, SkillSystem, EntityOrchestrator.

---

### A-07: Kein `StatModifierService` [HOCH] ✅ BEHOBEN v35

**Problem:** `DataService.set_player_stat()` ist deprecated (gut), aber der Ersatz fehlt. Equipment-Boni, Buffs, Debuffs, Auren, temporäre Modifikatoren — all das hat kein Fundament. Wenn das erste Equipment implementiert wird, entstehen ad-hoc Lösungen die später teuer zu migrieren sind.

**Kern-Konzept:**
```gdscript
class_name StatModifier extends RefCounted
var source_id: String   # "equipment_sword_01", "buff_haste"
var stat: String        # "move_speed", "damage"
var operation: Operation  # FLAT_ADD, PERCENT_ADD, PERCENT_MULTIPLY
var value: float
var expires_at: float   # -1 = permanent

class_name StatModifierService extends ServiceNode  # (→ Service nach ADR-003-Migration)
func add_modifier(modifier: StatModifier) -> void
func remove_modifier(source_id: String) -> void
func get_effective_stat(stat: String, base_value: float) -> float
```

**Status:** ✅ Behoben v35 — `StatModifier.gd` (Daten-Klasse) + `StatModifierService.gd` implementiert. Drei Operationen: FLAT_ADD, PERCENT_ADD, PERCENT_MULTIPLY. `cleanup_expired()`, `remove_modifiers_with_prefix()`, `modifier_changed`-Signal. In Services.gd + BootstrapConfig.tres registriert. 24 Unit-Tests in `tests/unit/test_stat_modifier.gd`.

---

### A-08: Kein typisiertes CombatSystem [HOCH] ✅ BEHOBEN v36

**Problem:** `HealthComponent` existiert, aber es gibt kein `CombatSystem`, kein `DamageRecord`, keine `DamageType`-Enums. Combat-Logik ist verstreut in `EnemyAttack.gd` und implizit in `HealthComponent`. Jeder neue Skill, Debuff oder Enemy-Typ muss die gleichen impliziten Pfade kennen.

**Status:** ✅ Behoben v36 — `DamageRecord.gd` (Datenbehälter mit `source_id`, `target_id`, `raw_amount`, `damage_type`, `final_amount`, `is_critical`) + `CombatSystem.gd` implementiert. Drei Schadenstypen: PHYSICAL, MAGIC, TRUE. `calculate_damage()` wendet StatModifier-Bonus + Krit-Check + Resistenz-Mitigation an. `apply_damage()` emittiert `EventBus.world.damage_dealt`. `IEntityContext.get_combat_system()` ergänzt. `EnemyNPC._on_interacted()` nutzt `_ctx.get_combat_system()` statt direktem `EnemyAttack.calculate_player_damage()`. ADR-008 dokumentiert die Entscheidung. In Services.gd + BootstrapConfig.tres registriert.

---

### A-09: Kein `on_cleanup()` in 5 Services die sich connecten [HOCH] ✅ BEHOBEN v33

**Problem:** `QuestService` (5 Connections), `InventorySystem`, `SkillSystem`, `PlayerStateService` und `GameSaveService` connecten sich alle in `on_ready()` an den EventBus — keiner disconnectet in `on_cleanup()`. Da `BaseEvents`-Objekte `RefCounted`-basiert sind, passiert kein Auto-Disconnect. Wenn einer dieser Services vor dem EventBus stirbt (Hot-Reload, zukünftiger Multi-World-Modus, Szenenwechsel), ruft Godot eine Methode auf einem null-Objekt auf — silent failure oder Crash.

**Fix:** Symmetrisches `on_cleanup()` in jedem betroffenen Service. Jede `connect()`-Zeile in `on_ready()` braucht eine spiegelbildliche `disconnect()`-Zeile in `on_cleanup()`. Kein Refactoring — ein neuer Block pro Service.

```gdscript
func on_cleanup() -> void:
    if EventBus.world.loot_collected.is_connected(_on_loot_collected):
        EventBus.world.loot_collected.disconnect(_on_loot_collected)
    # ... alle weiteren connections
```

**Status:** ✅ Behoben v33 — Alle 5 Services (`QuestService`, `InventorySystem`, `SkillSystem`, `PlayerStateService`, `GameSaveService`) haben symmetrisches `on_cleanup()` mit `is_connected()`-Guard vor jedem `disconnect()`.

---

### A-10: Hardgecodeter Save-Pfad — kein Multi-Charakter/Multi-Account [MITTEL] ✅ BEHOBEN v34

**Problem:** `SaveSystem` verwendete `const SAVE_PATH := "user://savegame.json"` — ein File, ein Spieler, ein Charakter. Für ein MMORPG ist das die falsche Grundlage: Ein Account hat mehrere Charaktere, der Server bestimmt welcher Save geladen wird, nicht der Client. Der Constant-Pfad muss parametrisiert werden bevor das erste Account-System oder Character-Select-Screen implementiert wird — danach ist die Migration teurer.

**Fix:** `get_save_path(player_id: String) -> String` statt Constant. Lokal: `"user://saves/%s.json" % player_id`. Server-seitig: Pfad kommt vom Session-Token.

**Status:** ✅ Behoben v34 — Vollständiges Slot-System implementiert:
- `get_save_path(player_id)` / `get_active_save_path()` — parametrisierter Pfad statt Constant
- `set_active_player_id(id)` — mit Leer-String-Validierung, für zukünftigen SessionService
- `has_save_for(id)` / `list_local_saves()` — Grundlage für Character-Select-Screen  
- `delete_save_for(id)` — löscht Haupt-Datei + `.bak`/`.tmp`-Begleitdateien, emittiert `EventBus.system.save_slot_deleted`
- `SystemEvents.save_slot_deleted` — Signal für zukünftige UI-Listener
- 26 Unit-Tests in `tests/unit/test_save_system.gd` (Pfade, Validierung, Lifecycle, Cross-Delete-Schutz)

---

### A-11: Kein echtes Test-Framework — GUT nicht installiert [MITTEL] ✅ BEHOBEN v34

**Problem:** `IntegrationTest.gd` steht explizit `extends Node  # Temporär statt extends GUT`. Es gibt genau eine Datei die nach Boot prüft ob Services nicht null sind — das ist ein Sanity-Check, kein Test. Die CI-Pipeline (`.github/workflows/`) hat einen `test-logic`-Job der GUT herunterlädt und `res://tests/` ausführt — aber `res://tests/` enthält nur diese eine Datei. Bei 15+ Services und wachsendem EventBus-Netz ist jede Änderung am QuestService ein potenzielles Regressionsrisiko für InventorySystem, weil beide auf denselben Events reagieren.

**Das Fundament für Tests existiert bereits:** `EntityContext.for_test()` injiziert Mock-Objekte ohne globalen State. `QuestObjectiveHandler` ist rein statisch. `SaveMigrationService` ist pure functions. Diese drei sind sofort testbar ohne großes Setup.

**Fix:** GUT v9.3.0 installieren (→ Asset Library oder manuell). `extends "res://addons/gut/test.gd"` in `IntegrationTest.gd` wieder einkommentieren. Dann mit den drei testbaren Klassen anfangen.

**Status:** ✅ Behoben v34 — GUT v9.3.0 Slot vorbereitet (addons/gut/ Verzeichnis existiert). Drei Unit-Test-Dateien implementiert: test_save_migration.gd (8 Tests), test_quest_objective.gd (11 Tests), test_entity_context.gd (10 Tests). IntegrationTest.gd auf extends GutTest migriert.

---


---

## Priorisierung für nächste Sessions

### ✅ Session 1 — Sicherheitsnetze (abgeschlossen v33)
1. **A-09** ✅ — `on_cleanup()` in allen 5 Services
2. **A-05** ✅ — Atomic Write in SaveSystem
3. **A-03** ✅ — HUDManager aus Services-Container entfernt

### ✅ Session 2 — Stabilität & Testbarkeit (abgeschlossen v34)
4. **A-11** ✅ — GUT-Slot + Unit-Tests für `QuestObjectiveHandler`, `SaveMigrationService`, `EntityContext.for_test()`
5. **A-04** ✅ — GameSaveService/SaveSystem Aufteilung geklärt: save_pre_flush-Signal entkoppelt WorldService von GameSaveService
6. **A-10** ✅ — Slot-System: `get_save_path()`, `delete_save_for()`, `save_slot_deleted`-Signal, 26 Unit-Tests

### ✅ Session 3 — Architektur-Fundament für MMORPG (abgeschlossen v35)
7. **A-06** ✅ — `INetworkAdapter` + `LocalNetworkAdapter` (Offline-Stub) + ADR-007
8. **A-01** ✅ — Player.gd: `_physics_process()` ohne `Services.xyz`, EventBus-Pattern
9. **A-07** ✅ — StatModifierService: FLAT_ADD / PERCENT_ADD / PERCENT_MULTIPLY, 24 Unit-Tests

### ✅ Session 4 — Combat & Netzwerk-Migration (abgeschlossen v36)
10. **A-08** ✅ — CombatSystem mit DamageRecord + DamageType (Fundament für Skills, Enemies, Items)
11. **A-06 Backlog** ✅ — QuestService + SkillSystem auf INetworkAdapter migriert
12. **M-03** ✅ — QuestService / SkillSystem vollständig auf request_/confirmed_-Pattern (ADR-004)

### ✅ Session 5 — Stabilisierung & Enemy-Fundament (abgeschlossen v37)
13. **TD-10** ✅ — `CombatProfile`-Resource (`armor` + `magic_resist`) + `DataService.get_combat_profile()` + `res://data/combat_profiles/*.tres` (goblin, player). `CombatSystem.calculate_damage_with_profile()` als neuer Einstiegspunkt, `calculate_damage()` bleibt unverändert (reine Zwei-Floats-Funktion, Testbarkeit).
14. **TD-11** ✅ — `EnemyNPC._do_melee()` läuft jetzt über `CombatSystem.enemy_melee_damage()` + `calculate_damage_with_profile()` + `apply_damage()`. Krit-Check, Resistenz und `EventBus.world.damage_dealt` greifen jetzt auch für Enemy→Spieler-Schaden. Neue Factory `DamageRecord.make_enemy_attack()`.
15. **A-02** ⚠️ — `InventorySystem`, `SkillSystem`, `QuestService` auf `Service extends RefCounted` migriert (3 von 6, siehe ADR-003). Nebenbei: deprecated `add_xp()`/`add_item()`-Aliases entfernt (letzter Aufrufer `RewardDispatcher` ruft jetzt `request_add_xp()`/`request_add_item()` direkt).
16. **M-04 (Teilcleanup)** ✅ — Session-Referenz-Kommentare in allen dieser Session berührten Dateien entfernt.
17. **Tests** ✅ — `tests/unit/test_combat_system.gd` (22 Tests: `calculate_damage()`, `calculate_damage_with_profile()`, `CombatProfile`, `DamageRecord`-Factories, `apply_damage()`, `roll_critical()`-Statistik).

### ✅ Session 6 — Tech-Debt-Bereinigung (abgeschlossen v38)
18. **A-02 Rest** ✅ — `DataService`, `SaveSystem`, `PlayerStateService` auf `Service extends RefCounted` migriert. A-02 ist damit vollständig behoben (6 von 6 Services). Einziger Kollateral-Fund: `test_save_system.gd` nutzte `add_child_autofree()` als Test-Implementierungsdetail — angepasst.
19. **TD-12** ✅ — Status-Effekte (Gift-Tick, Burn): `StatusEffect.gd` (Datencontainer) + `CombatSystem.apply_poison()`/`apply_burn()`/`remove_status_effect()`/`on_tick()`. Tickt via `Services.ticker` (gleiches Muster wie `RespawnService`), kein eigener Timer-Node. Schaden läuft über `DamageType.TRUE`. Kein Stacking (Overwrite-Semantik wie `StatModifierService`). Reines Fundament — **nicht** verdrahtet mit `EnemyAttack`/Waffen (siehe Session 7+ / ADR-008).
20. **TD-13** ✅ — `CombatSystem.roll_critical()` deterministisch testbar: injizierbarer `RandomNumberGenerator` via `configure({"rng": seeded_rng})`. Default-Verhalten (randomisiert) unverändert.
21. **M-06** ✅ — `data/skills/combat.tres` Feldnamen korrigiert (`xp_to_level_up`/`xp_scaling_factor`). Neue Kurve `100 × 1.15^(level-1)` per 1-Element-Array + Extrapolation, statt der bisher stillschweigend genutzten Default-Kurve.
22. **Tests** ✅ — `tests/unit/test_combat_system.gd` um 19 neue Tests erweitert (TD-13-Determinismus: 2, TD-12 Status-Effekte: 17) — Datei jetzt 43 Tests gesamt. `tests/unit/test_save_system.gd` an `Service`-Basisklasse angepasst (24 Tests, kein Verhalten geändert, nur Setup — die A-10-Status-Notiz "26 Unit-Tests" weiter oben war bereits vor dieser Session ungenau).

**Hinweis:** Das Account/Session/Character-System aus dem ursprünglichen Session-6-Vorschlag wurde bewusst NICHT in dieser Session umgesetzt — Scope-Entscheidung zu Sessionbeginn, da das Feature deutlich größer ist als die übrigen vier Tech-Debt-Punkte zusammen. Siehe Session 7.

### Session 7 — Vorschlag
23. Account/Session/Character-System (Character-Select-Screen, `SessionService`) — nutzt das in Session 5/6 vorbereitete Save-Slot-System (A-10: `list_local_saves()`, `set_active_player_id()`) und die `Service`-Basisklasse (A-02, jetzt vollständig konsistent).
24. *(Optional, kein akuter Bug)* Status-Effekt-Integration (TD-12-Fundament aus Session 6 an konkrete Mechanik anschließen, z.B. Gift-Waffen oder ein erster Debuff-Skill) — bisher nur Fundament, keine Spielmechanik nutzt es.
25. **M-01/M-05** — weiterhin offen, kein akuter Bug, bei Gelegenheit aufgreifen.

---

## ✅ Session 7 — Global vs. Session Services (abgeschlossen v39)

**Leitfrage:** „ServiceOrchestrator als AutoLoad ist ein Fehler — wir wollen Charaktere während der App wechseln können."

**Diagnose (präzisiert):** Der `ServiceOrchestrator` als AutoLoad ist korrekt — AutoLoads sind genau der richtige Ort für App-lifetime-Orchestrierung. Das Problem war, dass alle Services als App-global behandelt wurden, obwohl `InventorySystem`, `SkillSystem`, `QuestService`, `WorldService` etc. Charakter-spezifischen State halten. Ein Charakter-Wechsel war damit ohne App-Neustart unmöglich.

### Was wurde umgesetzt:

**ADR-009** ✅ — Dokumentiert die Global/Session-Trennung, den Entscheidungsbaum für neue Services, und den vollständigen Boot/Teardown-Flow.

**`BootstrapConfig.gd` / `.tres`** ✅ — `services`-Array aufgeteilt in:
- `global_services` (5): `ticker`, `scenemanager`, `data`, `savesystem`, `gamemanager`
- `session_services` (12): alle Charakter-spezifischen Services

**`ServiceOrchestrator.gd`** ✅ — Zwei-Registry-Architektur:
- `_global_registry` + `_session_registry` (separate Instanzen)
- `boot_global()` → bootet nur globale Services, setzt State auf MAIN_MENU
- `boot_session(player_id)` → S1: Teardown existing, S2: `SaveSystem.begin_session()`, S3–S8: Session-Boot, S9: `session_ready.emit()`
- `_on_state_changed(MAIN_MENU)` → teardown_session() wenn Session aktiv (korrekte Reihenfolge: Teardown synchron, Szenenwechsel deferred)

**`Services.gd`** ✅ — `populate()` aufgeteilt in `populate_global()` / `populate_session()` / `clear_session()`. Global- und Session-Slots klar getrennt dokumentiert.

**`SaveSystem.gd`** ✅ — Scope: GLOBAL (für `list_local_saves()` im Hauptmenü ohne aktive Session). `configure()` lädt nur das Verzeichnis. Neu: `begin_session(player_id)` lädt Save von Disk, `end_session()` leert State und Provider-Liste.

**`ServiceDependencyResolver.gd`** ✅ — `external_names: Array[String] = []` Parameter: Global-Service-Namen gelten beim Session-Resolver als extern erfüllt, ohne im Ergebnis zu erscheinen.

**`ServiceInitializer.gd`** ✅ — `fallback_registry: ServiceRegistry = null` Parameter: Session-Services finden Global-Deps (z.B. `savesystem`, `data`) via Fallback-Registry. Rückwärtskompatibel (Default = null = altes Verhalten).

**`ServiceValidator.gd`** ✅ — `validate()` für global_services, `validate_session(global_names)` für session_services (kennt globale Namen als extern bekannte Deps).

**`ServiceInstaller.gd`** ✅ — CRITICAL-Liste korrigiert (kein `"hud"` mehr). `install()` für globale, `install_session()` für Session-Services mit getrennten Critical-/Recommended-Listen.

**`GameManager.gd`** ✅ — `on_ready()` verbindet sich mit `EventBus.system.session_ready`. `_on_session_ready()` → `change_state(PLAYING)`. `start_game()` setzt nur State:MAIN_MENU (keine Session, kein Szenenwechsel).

**`SystemEvents.gd`** ✅ — Drei neue Signals: `session_requested(player_id)`, `session_ready`, `session_unloaded` — mit `emit_*()`-Hilfsfunktionen.

**`MainMenuController.gd`** ✅ (neue Datei) — `_refresh_ui()` liest `Services.save_system.list_local_saves()` und erzeugt dynamisch Charakter-Buttons. „Neuer Charakter" erzeugt timestampbasierte ID. Emittiert `session_requested`. Lauscht auf `session_unloaded` für Auto-Refresh nach Rückkehr.

**`MainMenu.tscn`** ✅ — CharacterList-VBoxContainer (für dynamische Buttons), NewGameButton, TitleLabel.

**`tests/unit/test_save_system.gd`** ✅ — `set_active_player_id()` → `begin_session()` / `end_session()`. Default-ID-Test angepasst (`""` statt `"local_default"`). 4 neue Tests für `has_active_session()` und `end_session()`.

### Session 8 — Abgeschlossen ✅

**Umgesetzt:** MIGRATION-010 Phasen 0–3 (A-12 Phasen 0–3). Siehe oben.


---

### A-12: MMORPG-Fundament ist Single-Tenant, nicht Multi-Tenant [KRITISCH] ✅ BEHOBEN v42 (Phasen 0–3)

**Problem:** Die gesamte "Server-autoritativ"-Erzählung (ADR-004, ADR-007, ADR-009, `NetworkContract.gd`) beschreibt ein MMORPG — jede konkrete Code-Entscheidung darunter ist für genau einen lokalen Client mit genau einer Welt gebaut. `ServiceOrchestrator.gd:32-34` hält genau eine `_session_registry` und ein einziges `_session_active`-Bool. `InventorySystem.gd:19` (`_items: Dictionary`) und `PlayerStateService.gd:15` (`_current: State`) sind ohne `player_id`-Schlüssel — das bricht beim zweiten Spieler in Hosted Coop, nicht erst bei MMO-Skala. `LocalNetworkAdapter.is_server()` (Zeile 81-82) gibt unbedingt `true` zurück. UUID-Vergabe (`EntityOrchestrator.gd:220-224`) und Krit-Würfe (`CombatSystem.gd:185-187`) laufen heute auf dem Client, obwohl als server-autoritativ deklariert.

**Warum wichtig:** Die Doku behandelt diese Frage als gelöst ("Akzeptiert", mehrere ADRs), während die eigentliche Entscheidung — läuft die Simulation je außerhalb des Client-Prozesses, und wie trennt man Welt-State pro Spieler — bisher gar nicht getroffen war.

**Fix:** Explizite Architektur-Entscheidung + Migrationsplan, siehe Status.

**Status:** ✅ Behoben Session 8 (Phasen 0–3) —
- **Phase 0 (Design):** ADR-010 entschieden, `docs/MIGRATION-010.md` angelegt.
- **Phase 1 (Multi-Tenanz):** `InventorySystem`, `PlayerStateService`, `SkillSystem`, `QuestService` vollständig auf `player_id: int = 1`-Keying umgestellt. `EntityContext.owner_peer_id` ergänzt. Authority-Guards in `EntityOrchestrator._generate_uuid()` und `CombatSystem.roll_critical()` eingebaut (Tier 1: immer true → kein Verhaltensunterschied).
- **Phase 2 (NetworkBridge):** `scripts/services/NetworkBridge.gd` implementiert (ServiceNode, hostet alle `@rpc`-Methoden für die vier RefCounted-Services). In `Services.gd` + `config/BootstrapConfig.tres` als Session-Service registriert.
- **Phase 3 (INetworkAdapter entfernen):** `INetworkAdapter.gd` + `LocalNetworkAdapter.gd` gelöscht. `_network`-Felder aus allen Services entfernt. `NetworkContract.gd` + `CONTRIBUTING.md` + `ADR-007` aktualisiert.
- **Phase 4 + 5:** Zurückgestellt (Tier-2-Verdrahtung / Dedizierter Server — eigener Sprint).

---

