# Migrationsplan: ADR-010 — Multiplayer-Authority

> Setzt ADR-010 in konkrete, einzeln abnehmbare Schritte um. Dieses Dokument ist
> selbst kein ADR (keine Entscheidung, sondern Ausführungsplan) — Status-Updates
> hier (✅/🔲) sind erwünscht, im Gegensatz zu ADRs, die unveränderliche Historie sind.
>
> **Geltungsbereich:** Nur die Themen aus ADR-010 (Netzwerk-Autorität, Multi-Tenanz
> der Session-Services). Die übrigen Befunde der externen Review (UI-Schichtverletzungen
> Abschnitt 2, `scripts/debug/`-Dokugrab Abschnitt 4.1, GameManager/ServiceOrchestrator-
> State-Duplikation Abschnitt 3.2) sind **nicht** Teil dieses Plans — eigene Arbeit,
> eigene Entscheidung, wann das angegangen wird.

---

## Reihenfolge im Überblick

| Phase | Inhalt | Risiko | Voraussetzung |
|---|---|---|---|
| 0 | Bridge-Design-Entscheidung (RefCounted ↔ Node-RPC) | Niedrig (nur Entwurf) | ADR-010 |
| 1 | Multi-Tenanz: Session-Services auf `peer_id`-Keying umstellen | **Hoch** — größter Eingriff | Phase 0 |
| 2 | `NetworkBridge`-Infrastruktur bauen | Mittel | Phase 1 |
| 3 | `INetworkAdapter`/`LocalNetworkAdapter` entfernen, Doku aktualisieren | Niedrig (Aufräumarbeit) | Phase 2 |
| 4 | Tier 2 verdrahten: `ENetMultiplayerPeer`, Host-Flow | Mittel | Phase 3 |
| 5 | Tier 3 (dedizierter Server) | — | Zurückgestellt, eigener Sprint |

Phase 1 ist bewusst vor jeglicher echten Netzwerk-Verdrahtung platziert — sie betrifft
auch Tier 1 (Solo) strukturell, aber **risikolos**, wenn der unten beschriebene
Default-Parameter-Trick genutzt wird.

---

## Phase 0 — Bridge-Design-Entscheidung

**Problem (ADR-010, Risiken):** Godots `multiplayer_authority`/`rpc_id()`/`@rpc` sind
an `Node` gebunden (RPC-Dispatch läuft über `NodePath`). Vier der fünf betroffenen
Services sind laut ADR-003 bewusst `Service` (`RefCounted`), nicht `Node`:

| Service | Basisklasse | Datei |
|---|---|---|
| `InventorySystem` | `Service` (RefCounted) | `scripts/services/InventorySystem.gd:1-2` |
| `QuestService` | `Service` (RefCounted) | `scripts/services/QuestService.gd:1-2` |
| `SkillSystem` | `Service` (RefCounted) | `scripts/services/SkillSystem.gd:1-2` |
| `PlayerStateService` | `Service` (RefCounted) | `scripts/services/PlayerStateService.gd:1-2` |
| `CombatSystem` | `ServiceNode` (Node) | `scripts/services/CombatSystem.gd:1-2` |
| `EntityOrchestrator` | `Node` (direkt) | `scripts/core/EntityOrchestrator.gd:1-2` |

**Entscheidung für diesen Plan:** Ein einziger neuer `NetworkBridge`-Service
(`ServiceNode`, session-scoped) hostet alle `@rpc`-Methoden für die vier
`RefCounted`-Services und delegiert intern an `Services.inventory`, `Services.quest`,
`Services.skill_system`, `Services.player_states`. `CombatSystem` und
`EntityOrchestrator` sind bereits Node-basiert und bekommen ihre `@rpc`-Methoden
**direkt** auf sich selbst (kein Bridge-Umweg nötig) — in Phase 4, wenn ihre
RPC-Pfade tatsächlich verdrahtet werden.

Begründung gegen "jeden Service zu `ServiceNode` migrieren": ADR-003 hat
`InventorySystem`/`SkillSystem`/`QuestService` bewusst von `ServiceNode` zu `Service`
migriert (TD-02, "kein SceneTree-Zugriff nötig"). Das zurückzudrehen widerspräche
einer bereits getroffenen, dokumentierten Entscheidung ohne neuen Grund — der
NetworkBridge-Ansatz hält diese Entscheidung intakt und fügt nur eine dünne,
zusätzliche Schicht hinzu, die ohnehin nötig wäre (RPC-Empfang muss *irgendwo*
landen, bevor er an die Geschäftslogik weitergereicht wird).

**Neue Datei (Phase 2):** `scripts/services/NetworkBridge.gd`
**Neuer Eintrag in `config/BootstrapConfig.tres`:** `session_services`, deps:
`["inventory", "quest", "skill_system", "playerstates"]`

---

## Phase 1 — Multi-Tenanz der Session-Services

### Warum das vor jeder Netzwerk-Verdrahtung passieren muss

ADR-009 bleibt gültig: eine Session lädt genau einen Save, das ist für **Tier 1**
korrekt und bleibt es. Aber für **Tier 2** gilt: der Host lädt *eine* Session/Welt,
in der gleichzeitig **mehrere** Spieler-Avatare aktiv sind. Die Inventar-, Quest-,
Skill- und Zustands-Daten **jedes** verbundenen Spielers müssen in derselben
Session-Instanz nebeneinander existieren — nicht in N parallelen Sessions (das wäre
das in ADR-010 explizit abgelehnte Server-Farm-Modell), sondern als zusätzliche
Dimension *innerhalb* der einen Session.

Konkret betroffen (Datei:Zeile, Stand v39):

| Datei | Heute (Single-Tenant) | Ziel (Multi-Tenant) |
|---|---|---|
| `InventorySystem.gd:19` | `var _items: Dictionary` (`item_id → qty`) | `var _items: Dictionary` (`peer_id → {item_id → qty}`) |
| `InventorySystem.gd:34` | `var current_weight: float` | `var current_weight: Dictionary` (`peer_id → float`) |
| `PlayerStateService.gd:15` | `var _current: State` | `var _current: Dictionary` (`peer_id → State`) |
| `SkillSystem.gd:29` | `var skills: Dictionary` (`skill_name → {...}`) | `var skills: Dictionary` (`peer_id → {skill_name → {...}}`) |
| `QuestService.gd:36-37` | `active_quests`/`completed_quests` flach | beide zusätzlich nach `peer_id` verschachtelt |

### Der Mechanismus, der das Risiko klein hält

Jede öffentliche Methode bekommt einen neuen Parameter `player_id: int = 1`
(Godots `multiplayer.get_unique_id()` liefert **per Default `1`**, solange kein
`MultiplayerPeer` gesetzt ist — exakt der "Solo ist der Trivialfall"-Gedanke aus
ADR-010, jetzt als konkreter Code-Mechanismus). Beispiel:

```gdscript
# Vorher:
func request_add_item(item_id: String, quantity: int = 1) -> bool:

# Nachher:
func request_add_item(item_id: String, quantity: int = 1, player_id: int = 1) -> bool:
```

**Folge:** Bestehende Aufrufer, die kein `player_id` übergeben, verhalten sich exakt
wie heute — kein Call-Site-Zwang in Phase 1. Geprüft (Grep über alle Aufrufer von
`request_add_item`, `get_all_items`, `set_state`, `get_state`, `request_add_xp`,
`request_start_quest`, `active_quests`, `skills[`):

```
scripts/ui/controllers/InventoryUIController.gd
scripts/ui/controllers/QuestPanelController.gd
scripts/services/RewardDispatcher.gd
scripts/interaction/InteractionExecutor.gd
scripts/quest/QuestReward.gd
scripts/debug/SimpleTerminal.gd
tests/unit/test_combat_system.gd
```

Sieben Aufrufer-Dateien außerhalb der Services selbst — alle bleiben in Phase 1
unverändert. Sie werden erst in Phase 4 angefasst, wenn ein zweiter Spieler real
existiert und die UI tatsächlich zwischen "meine Daten" und "Daten von Spieler X"
unterscheiden muss.

### Offene Design-Frage, die in Phase 1 mit-entschieden werden muss

`InventorySystem.max_slots`/`max_weight` (Zeilen 31, 37) sind heute Service-globale
Felder, obwohl sie laut TODO #6-Kommentar (Zeile 26-27) bereits aus `PlayerData` pro
Charakter geladen werden — das ist also bereits konzeptionell pro-Spieler-Daten, nur
noch nicht so gespeichert. Empfehlung: `max_slots`/`max_weight` werden Teil des
gleichen `peer_id`-keyed Dictionaries wie `_items`, befüllt beim ersten Auftreten
eines `peer_id` (Spieler-Join), nicht erst bei echtem Netzwerk-Join.

### Begleitend: `EntityContext` bekommt `owner_peer_id`

`EntityContext.from_services()` (`scripts/core/EntityContext.gd:28-37`) wird pro
`spawn_entity()`-Aufruf neu erstellt (`EntityOrchestrator.gd:122-128`) — das ist
bereits der richtige Ort, um `owner_peer_id: int` zu ergänzen (Default `1`). Dann
muss `Player.gd` (und jede andere Entity, die Session-Services aufruft) `peer_id`
nicht selbst kennen oder herleiten — sie reicht `ctx.owner_peer_id` einfach durch.
Das hält die in ADR-006 etablierte Abschirmung (Entity kennt `Services.xyz` nicht
direkt) intakt, statt sie für die Multi-Tenanz-Umstellung aufzuweichen.

### Reihenfolge innerhalb Phase 1

1. `InventorySystem` (am gründlichsten von der Review belegt — guter erster Schritt)
2. `PlayerStateService` (kleinste Datei, 93 Zeilen — guter Test des Musters)
3. `SkillSystem`, `QuestService` (gleiches `_network`-Pattern, gleiches Risiko)
4. `EntityContext.owner_peer_id` ergänzen, `Player.gd` anpassen
5. Tests: `tests/unit/test_combat_system.gd` (einziger betroffener Test, prüft
   indirekt `player_melee_damage` — Signatur-Check, kein Verhaltensrisiko durch
   Default-Parameter)

### Authority-Gating als Trittbrett (gehört thematisch hierher, nicht in Phase 4)

Da Phase 1 ohnehin jede Methode anfasst, wird hier gleich die in Review 1.2 belegte
Lücke geschlossen — beide Stellen sind heute nur als Kommentar markiert, nicht als
Code durchgesetzt:

- `EntityOrchestrator._generate_uuid()` (`scripts/core/EntityOrchestrator.gd:220-224`)
- `CombatSystem.roll_critical()` (`scripts/services/CombatSystem.gd:185-187`)

Beide werden mit einer Guard-Klausel versehen (`if not (multiplayer.has_multiplayer_peer() == false or multiplayer.is_server()): return` — exakte Formulierung in Phase 4, wenn die `@rpc`-Annotation feststeht), sodass sie nicht mehr nur kommentiert, sondern strukturell auf die Autorität beschränkt sind. `CombatSystem` fehlt zusätzlich komplett in `NetworkContract.gd`s Authority-Matrix (Zeile 21-28 listet `InventorySystem`, `QuestService`, `EntityOrchestrator`, `PlayerStateService`, `SkillSystem` — nicht `CombatSystem`) — wird in Phase 3 ergänzt.

---

## Phase 2 — `NetworkBridge`-Infrastruktur

Neue Datei `scripts/services/NetworkBridge.gd` (Konzept, keine vollständige
Implementierung — die folgt in der Umsetzungsphase):

```gdscript
extends ServiceNode
class_name NetworkBridge

# Empfängt RPCs, übersetzt sie in lokale Aufrufe der RefCounted-Services.
# call_local=true: Host führt die Confirm-Methode auch lokal aus (für sein eigenes UI).

@rpc("any_peer", "call_local", "reliable")
func _rpc_add_item(item_id: String, qty: int) -> void:
    if not multiplayer.is_server():
        return  # nur Autorität mutiert (Tier 2: Host: lockere Validierung; Tier 3: Server: strenge Validierung)
    var sender := multiplayer.get_remote_sender_id()
    var player_id := sender if sender != 0 else 1   # 0 = lokaler Aufruf (kein Netzwerk)
    Services.inventory.on_item_add_confirmed(item_id, qty, player_id)

# ... analog für quest.start_confirmed, quest.complete_confirmed,
#     skill.add_xp_confirmed, playerstate.set_confirmed
```

`request_*()`-Methoden in den vier Services rufen künftig
`Services.network_bridge.rpc_id(get_authority_peer_id(), "_rpc_add_item", ...)`
statt `_network.send_request(...)`. `get_authority_peer_id()` ist `1` (Host) wenn
ein `MultiplayerPeer` gesetzt ist, sonst bedeutungslos (kein RPC nötig — direkter
lokaler Aufruf bleibt für Tier 1 der schnellste Pfad, siehe Phase 4).

**Validierungsstrenge (ADR-010, Tier 2 vs. Tier 3):** Die `if not multiplayer.is_server()`-Guards in `NetworkBridge` sind identisch für beide Tiers — der Unterschied liegt ausschließlich in der *Tiefe* der Prüfung, die `on_*_confirmed()` selbst durchführt (z. B. Tier 3 prüft Cooldowns/Distanz/Rate-Limits, die Tier 2 heute schon teilweise hat). Das ist kein Gegenstand dieses Plans, sondern laufende Service-interne Arbeit.

---

## Phase 3 — `INetworkAdapter` entfernen, Doku aktualisieren

1. Löschen: `scripts/interfaces/core/INetworkAdapter.gd`, `scripts/services/LocalNetworkAdapter.gd`
2. In `InventorySystem.gd`, `QuestService.gd`, `SkillSystem.gd`: `_network`-Feld und
   die zugehörige `configure()`-Fallback-Logik (`LocalNetworkAdapter.new()`) entfernen,
   durch `Services.network_bridge`-Aufruf ersetzen (s. Phase 2).
3. `NetworkContract.gd` aktualisieren:
   - Implementierungshinweis von "`INetworkAdapter`" auf "Godot RPC /
     `multiplayer_authority`, siehe `NetworkBridge.gd`" ändern.
   - `CombatSystem` zur Authority-Matrix (Zeile 21-28) hinzufügen —
     `roll_critical` als server-autoritativ deklarieren (schließt Review 1.2).
4. `CONTRIBUTING.md` Abschnitt 2.3 (Zeilen 47-59) sowie die Code-Beispiele an
   Zeilen 151 und 196 aktualisieren — referenzieren aktuell `INetworkAdapter`.
5. `config/BootstrapConfig.tres`: `network`-Dependency-Deklaration war nie nötig
   (verifiziert — kein Service deklariert `"network"` in `deps`, der Fallback lief
   immer über die `configure()`-interne `LocalNetworkAdapter.new()`-Erzeugung). Kein
   Änderungsbedarf hier, nur zur Vollständigkeit dokumentiert.

---

## Phase 4 — Tier 2 verdrahten

1. Host-Flow: `ENetMultiplayerPeer.create_server(port)`,
   `multiplayer.multiplayer_peer = peer`.
2. Join-Flow: `ENetMultiplayerPeer.create_client(address, port)`.
3. `NetworkBridge` als Empfangsstelle für `multiplayer.peer_connected`/
   `peer_disconnected` — bei Connect: `EntityOrchestrator.spawn_entity()` für den
   neuen Peer (UUID-Vergabe läuft jetzt über den in Phase 1 ergänzten Authority-Guard).
4. UI-Controller, die heute implizit "den einen Spieler" zeigen (`InventoryUIController`,
   `QuestPanelController` — aus der Liste in Phase 1), bekommen hier ihren tatsächlichen
   `player_id`-Parameter (lokal: `multiplayer.get_unique_id()`), nicht mehr den
   Default `1`. Das ist der einzige Punkt, an dem die in Phase 1 zurückgestellten
   sieben Aufrufer-Dateien angefasst werden.
5. Playtest-Meilenstein: zwei Geräte, ein Host, eine Welt, getrennte Inventare.

---

## Phase 5 — Tier 3 (zurückgestellt)

Bewusst nicht Teil dieses Plans (ADR-010, Konsequenzen/Negativ). Backlog-Eintrag,
damit er nicht wie der UUID-Kommentar aus Review 1.2 stillschweigend verschwindet:

- `--headless`-Build-Flag, zweite `BootstrapConfig`-Variante ohne Rendering-Services
- Strengere Validierung in allen `on_*_confirmed()` (Rate-Limits, Plausibilitätsprüfung)
- `ISaveProvider`-Backing-Implementierung für DB statt `user://saves/*.json` (ADR-005
  bleibt dabei unverändert — nur eine zweite Implementierung, kein Redesign)
- Trigger für diesen Schritt: siehe ADR-010, Abschnitt "Ablösung"

---

## Test-Strategie pro Phase

| Phase | Was testen |
|---|---|
| 1 | Bestehende Service-Tests laufen unverändert (Default-Parameter greift). Neue Tests: `request_add_item(..., player_id=2)` mutiert nicht `player_id=1`s Inventar. |
| 2 | `NetworkBridge` mit `MockMultiplayerAPI`/zwei lokalen `SceneTree`-Instanzen (Godots übliches RPC-Testmuster) — kein echtes Netzwerk nötig. |
| 3 | Grep-Sweep (wie in Review 4.1 gefordert): `grep -rn "INetworkAdapter\|LocalNetworkAdapter"` muss leer sein nach Phase 3. |
| 4 | Manueller Playtest mit zwei Geräten/Instanzen — kein automatisierter Netzwerktest in diesem Plan vorgesehen (zukünftige Arbeit). |

---

## Checkliste

- [x] Phase 0: Bridge-Entwurf abgenommen — ADR-010 akzeptiert, MIGRATION-010.md angelegt (Session 8)
- [x] Phase 1: `InventorySystem`, `PlayerStateService`, `SkillSystem`, `QuestService` multi-tenant (Session 8)
- [x] Phase 1: `EntityContext.owner_peer_id`, `EntityOrchestrator`/`CombatSystem` Authority-Guards (Session 8)
- [x] Phase 2: `NetworkBridge.gd` + `BootstrapConfig.tres`-Eintrag (Session 8)
- [x] Phase 3: `INetworkAdapter`/`LocalNetworkAdapter` entfernt, `NetworkContract.gd`/`CONTRIBUTING.md`/`ADR-007` aktualisiert (Session 8)
- [ ] Phase 4: Host-/Join-Flow, Playtest mit zwei Geräten
- [ ] Phase 5: als Backlog dokumentiert, nicht vergessen (nicht gestartet)
