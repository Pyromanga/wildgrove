extends Service
class_name SaveSystem

## SaveSystem — Atomic-Write-gesicherter Aggregator für alle ISaveProvider.
##
## SCOPE: GLOBAL (ADR-009) — läuft für die gesamte App-Lifetime.
##   configure()     → nur Verzeichnis sicherstellen, kein Laden
##   begin_session() → lädt Spielstand für den gewählten Charakter (bei Session-Start)
##   end_session()   → leert geladenen State und Providers (bei Session-Ende)
##
## WARUM GLOBAL (nicht session):
##   list_local_saves() und has_save_for() müssen im Hauptmenü ohne
##   aktive Session nutzbar sein (Character-Select-Screen, ADR-009).
##
## MULTI-CHARAKTER-DESIGN (A-10 + ADR-009):
##   - get_save_path(player_id) berechnet den Pfad dynamisch
##   - Lokal: "user://saves/<player_id>.json"
##   - Server-seitig: Pfad kommt vom Session-Token

const LOG_CAT := "SaveSystem"
const SAVE_DIR := "user://saves/"

## Aktive Player-ID der laufenden Session. Leer wenn keine Session aktiv.
var _active_player_id: String = ""

var _save_providers: Array[ISaveProvider] = []
var _loaded_state: Dictionary = {}


# ─────────────────────────────────────────────
# Phase 4: Configure (Global-Boot)
# ─────────────────────────────────────────────


## configure() läuft beim globalen Boot — nur Infrastruktur, kein Charakter-State.
## begin_session() lädt den tatsächlichen Spielstand wenn der Charakter ausgewählt wird.
func configure(_deps: Dictionary) -> void:
	_ensure_save_dir()
	Logger.log_info("SaveSystem bereit (Slot-Management aktiv, noch keine Session).", LOG_CAT)


# ─────────────────────────────────────────────
# Session-Lifecycle (ADR-009)
# ─────────────────────────────────────────────


## Wird von ServiceOrchestrator.boot_session() aufgerufen bevor Session-Services booten.
## Lädt den Spielstand für player_id von Disk und hält ihn in _loaded_state.
## Session-Services können danach via get_state_for(key) darauf zugreifen.
func begin_session(player_id: String) -> void:
	if player_id.strip_edges().is_empty():
		Logger.log_warn("begin_session: Leere Player-ID — ignoriert.", LOG_CAT)
		return

	_active_player_id = player_id

	if has_save():
		var raw := _read_from_disk()
		_loaded_state = SaveMigrationService.migrate(raw)
		Logger.log_info(
			"Session gestartet: '%s' (Schema v%d)." % [
				player_id, _loaded_state.get("schema_version", 0)
			], LOG_CAT
		)
	else:
		_loaded_state = {}
		Logger.log_info(
			"Session gestartet: '%s' (kein Spielstand — Neustart)." % player_id, LOG_CAT
		)


## Wird von ServiceOrchestrator._teardown_session_internal() aufgerufen.
## Leert geladenen State und Provider-Liste — SaveSystem bleibt als Global-Service erhalten.
func end_session() -> void:
	_loaded_state = {}
	_save_providers.clear()
	_active_player_id = ""
	Logger.log_info("Session beendet — State und Providers geleert.", LOG_CAT)


# ─────────────────────────────────────────────
# Player-ID / Pfad-Management
# ─────────────────────────────────────────────


## Berechnet den Save-Pfad für eine Player-ID.
func get_save_path(player_id: String) -> String:
	return SAVE_DIR + player_id + ".json"


func get_active_save_path() -> String:
	return get_save_path(_active_player_id)


func get_active_player_id() -> String:
	return _active_player_id


func has_active_session() -> bool:
	return not _active_player_id.is_empty()


# ─────────────────────────────────────────────
# Provider Management (ISaveProvider-Pattern)
# ─────────────────────────────────────────────


func register_save_provider(provider: ISaveProvider) -> void:
	if not provider in _save_providers:
		_save_providers.append(provider)
		Logger.log_debug("Provider registriert: %s" % provider.get_save_key(), LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


func get_state_for(key: String) -> Dictionary:
	var sub: Variant = _loaded_state.get(key)
	return sub if sub is Dictionary else {}


func save_game() -> bool:
	if not has_active_session():
		Logger.log_warn("save_game() ohne aktive Session — ignoriert.", LOG_CAT)
		return false

	Logger.log_info("Speichervorgang gestartet (Charakter: '%s')..." % _active_player_id, LOG_CAT)
	EventBus.system.emit_save_started()

	var full_state: Dictionary = {
		"schema_version": SaveMigrationService.CURRENT_VERSION,
		"player_id":      _active_player_id,
		"timestamp":      Time.get_datetime_string_from_system(),
	}

	for provider in _save_providers:
		if is_instance_valid(provider):
			full_state[provider.get_save_key()] = provider.get_save_data()

	var success := _write_to_disk(full_state)
	EventBus.system.emit_save_completed(success)
	return success


# ─────────────────────────────────────────────
# Slot-Management (für Character-Select-Screen)
# ─────────────────────────────────────────────


func has_save() -> bool:
	if _active_player_id.is_empty():
		return false
	return FileAccess.file_exists(get_active_save_path())


func has_save_for(player_id: String) -> bool:
	return FileAccess.file_exists(get_save_path(player_id))


## Listet alle lokalen Save-Dateien auf.
## Gibt Array[String] mit Player-IDs zurück (ohne .json-Extension).
## Nutzbar auch ohne aktive Session (SaveSystem ist global).
func list_local_saves() -> Array[String]:
	var result: Array[String] = []
	var dir := DirAccess.open(SAVE_DIR)
	if not dir:
		return result
	dir.list_dir_begin()
	var fname := dir.get_next()
	while fname != "":
		if fname.ends_with(".json") and not fname.ends_with(".bak"):
			result.append(fname.trim_suffix(".json"))
		fname = dir.get_next()
	dir.list_dir_end()
	return result


## Löscht den persistierten State für eine Player-ID inklusive Begleitdateien.
func delete_save_for(player_id: String) -> bool:
	if player_id.strip_edges().is_empty():
		Logger.log_warn("delete_save_for: Leere Player-ID — ignoriert.", LOG_CAT)
		return false

	var path := get_save_path(player_id)
	if not FileAccess.file_exists(path):
		Logger.log_warn("delete_save_for: Keine Save-Datei für '%s'." % player_id, LOG_CAT)
		return false

	if player_id == _active_player_id:
		Logger.log_warn(
			"delete_save_for: Aktiver Spielstand '%s' wird gelöscht." % player_id, LOG_CAT
		)

	var err := DirAccess.remove_absolute(path)
	if err != OK:
		Logger.log_error(
			"delete_save_for: Fehler beim Löschen von '%s' (Error %d)." % [path, err], LOG_CAT
		)
		return false

	if FileAccess.file_exists(path + ".bak"):
		DirAccess.remove_absolute(path + ".bak")
	if FileAccess.file_exists(path + ".tmp"):
		DirAccess.remove_absolute(path + ".tmp")

	Logger.log_info("Save-Slot '%s' gelöscht." % player_id, LOG_CAT)
	EventBus.system.emit_save_slot_deleted(player_id)
	return true


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _ensure_save_dir() -> void:
	if not DirAccess.dir_exists_absolute(SAVE_DIR):
		var err := DirAccess.make_dir_recursive_absolute(SAVE_DIR)
		if err != OK:
			Logger.log_error(
				"Konnte Save-Verzeichnis nicht anlegen: %s (Error %d)" % [SAVE_DIR, err], LOG_CAT
			)


func _write_to_disk(state: Dictionary) -> bool:
	return _atomic_write(get_active_save_path(), state)


func _atomic_write(path: String, data: Dictionary) -> bool:
	var tmp_path := path + ".tmp"

	var file := FileAccess.open(tmp_path, FileAccess.WRITE)
	if not file:
		Logger.log_error("Atomic Write: Konnte tmp-Datei nicht öffnen: %s" % tmp_path, LOG_CAT)
		return false
	file.store_string(JSON.stringify(data, "\t"))
	file.close()

	if FileAccess.file_exists(path):
		var backup_err := DirAccess.copy_absolute(path, path + ".bak")
		if backup_err != OK:
			Logger.log_warn("Backup fehlgeschlagen (Error %d) — fahre fort." % backup_err, LOG_CAT)

	var rename_err := DirAccess.rename_absolute(tmp_path, path)
	if rename_err != OK:
		Logger.log_error("Atomic Rename fehlgeschlagen (Error %d)!" % rename_err, LOG_CAT)
		return false

	return true


func _read_from_disk() -> Dictionary:
	var path := get_active_save_path()
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if not file:
		return {}

	var json_text := file.get_as_text()
	file.close()

	var json := JSON.new()
	var error = json.parse(json_text)
	if error != OK:
		Logger.log_error("JSON Parse-Fehler für '%s'!" % path, LOG_CAT)
		return {}

	return json.data if json.data is Dictionary else {}
