extends Service
class_name SkillSystem
## implements ISaveProvider

## SkillSystem — Berechnet XP-Fortschritt und Level-Ups.
## Abhängigkeiten (deps): ["data", "savesystem"]
##
## MIGRATION-010 Phase 1: Multi-Tenanz — skills ist jetzt { peer_id: { skill_id: {...} } }.
## Öffentliche Methoden bekommen player_id: int = 1 — bestehende Aufrufer unverändert.
##

const LOG_CAT := "SkillSystem"
const SAVE_KEY := "skills"

var _data_service: DataService
var _save_system:  SaveSystem
var _definitions:  Dictionary = {}   # { skill_id: SkillDefinition }

## Multi-Tenant State: { peer_id: { skill_id: { "xp": int, "level": int } } }
var _players: Dictionary = {}


# ─────────────────────────────────────────────
# Intern: Bucket per Player
# ─────────────────────────────────────────────

func _ensure_player(player_id: int) -> Dictionary:
	if not skills.has(player_id):
		_players[player_id] = {}
		_init_player_skills(player_id)
	return skills[player_id]


func _init_player_skills(player_id: int) -> void:
	if not _definitions.is_empty():
		for skill_id in _definitions:
			_players[player_id][skill_id] = {"xp": 0, "level": 1}
	else:
		_players[player_id] = {
			"woodcutting": {"xp": 0, "level": 1},
			"mining":      {"xp": 0, "level": 1},
			"farming":     {"xp": 0, "level": 1},
			"combat":      {"xp": 0, "level": 1},
		}


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	_data_service = deps.get("data")       as DataService
	_save_system  = deps.get("savesystem") as SaveSystem

	_init_definitions()

	# Lokalen Spieler (peer=1) initialisieren
	_ensure_player(1)

	if _save_system:
		_save_system.register_save_provider(self)
		var saved: Dictionary = _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_restore_from_save(saved)

	Logger.log_info(
		"Initialisiert. %d Skill-Definitionen." % _definitions.size(), LOG_CAT
	)


# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────


func on_ready() -> void:
	EventBus.player.xp_gained.connect(request_add_xp)
	Logger.log_info("SkillSystem mit EventBus verbunden.", LOG_CAT)


func on_cleanup() -> void:
	if EventBus.player.xp_gained.is_connected(request_add_xp):
		EventBus.player.xp_gained.disconnect(request_add_xp)
	Logger.log_info("SkillSystem cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────


func get_save_key() -> String:
	return SAVE_KEY


func get_save_data() -> Dictionary:
	# Format: { "1": { skill_id: {xp, level} }, "2": {...} }
	var out: Dictionary = {}
	for pid in _players:
		out[str(pid)] = (_players[pid] as Dictionary).duplicate(true)
	return out


# ─────────────────────────────────────────────
# Öffentliche API — request_/on_*_confirmed Pattern (ADR-004)
# ─────────────────────────────────────────────


## Client-seitige Anfrage: XP zu einem Skill addieren. Default player_id=1 → Tier 1 unverändert.
func request_add_xp(skill_name: String, amount: int, player_id: int = 1) -> void:
	var bucket := _ensure_player(player_id)
	if not bucket.has(skill_name):
		Logger.log_warn("Unbekannter Skill: '%s'" % skill_name, LOG_CAT)
		return
	if amount <= 0:
		return
	# Tier 1: direkter Aufruf. Tier 2/3: NetworkBridge übernimmt in Phase 4.
	_on_xp_add_confirmed({"skill_name": skill_name, "amount": amount, "player_id": player_id})


## Authority-Mutation: schreibt XP für player_id.
func _on_xp_add_confirmed(payload: Dictionary) -> void:
	var skill_name: String = payload.get("skill_name", "")
	var amount: int        = payload.get("amount", 0)
	var player_id: int     = payload.get("player_id", 1)
	var bucket := _ensure_player(player_id)
	if skill_name.is_empty() or not bucket.has(skill_name):
		Logger.log_error("_on_xp_add_confirmed: Skill '%s' unbekannt!" % skill_name, LOG_CAT)
		return
	bucket[skill_name]["xp"] += amount
	Logger.log_debug("+%d XP in '%s' für Spieler %d (gesamt: %d)" % [amount, skill_name, player_id, bucket[skill_name]["xp"]], LOG_CAT)
	_check_level_up(skill_name, player_id)


func get_level(skill_name: String, player_id: int = 1) -> int:
	var bucket: Dictionary = _players.get(player_id, {})
	return (bucket.get(skill_name, {"level": 1}) as Dictionary)["level"]


func get_xp(skill_name: String, player_id: int = 1) -> int:
	var bucket: Dictionary = _players.get(player_id, {})
	return (bucket.get(skill_name, {"xp": 0}) as Dictionary)["xp"]


func get_xp_to_next_level(skill_name: String, player_id: int = 1) -> int:
	var def: SkillDefinition = _definitions.get(skill_name)
	if not def:
		return 100
	return def.get_xp_required(get_level(skill_name, player_id))


func has_skill(skill_name: String, player_id: int = 1) -> bool:
	var bucket: Dictionary = _players.get(player_id, {})
	return bucket.has(skill_name)

func get_skill_ids(player_id: int = 1) -> Array[String]:
	## Gibt die IDs aller Skills für player_id zurück.
	## Einziger erlaubter Weg um über Skills zu iterieren — schützt vor
	## direktem Zugriff auf die interne Multi-Tenant-Struktur (B-05).
	var bucket: Dictionary = _players.get(player_id, {})
	var result: Array[String] = []
	for key in bucket:
		result.append(key as String)
	return result


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _init_definitions() -> void:
	if is_instance_valid(_data_service):
		_definitions = _data_service.get_all_skills()

	if _definitions.is_empty():
		Logger.log_debug("Keine SkillDefinitions in DataService — nutze Fallback-Skills.", LOG_CAT)
	else:
		Logger.log_debug("Skills aus DataService geladen: %s" % str(_definitions.keys()), LOG_CAT)


func _check_level_up(skill_name: String, player_id: int) -> void:
	var bucket := _ensure_player(player_id)
	var entry: Dictionary = bucket[skill_name]
	var def:   SkillDefinition = _definitions.get(skill_name)

	while true:
		var xp_needed: int
		if def:
			if def.max_level >= 0 and entry["level"] >= def.max_level:
				return
			xp_needed = def.get_xp_required(entry["level"])
		else:
			xp_needed = entry["level"] * 100

		if entry["xp"] < xp_needed:
			break

		entry["xp"]   -= xp_needed
		entry["level"] += 1
		Logger.log_info(
			"LEVEL UP! Spieler %d — '%s' ist jetzt Level %d." % [player_id, skill_name, entry["level"]], LOG_CAT
		)
		EventBus.player.emit_level_up(skill_name, entry["level"])


func _restore_from_save(saved: Dictionary) -> void:
	# Format: { "1": { skill_id: {xp, level} }, "2": {...} }
	for pid_str in saved:
		var pid: int = int(pid_str)
		var raw: Dictionary = saved[pid_str] as Dictionary if saved[pid_str] is Dictionary else {}
		var bucket := _ensure_player(pid)
		for skill_name in raw:
			if bucket.has(skill_name):
				bucket[skill_name] = raw[skill_name]
			else:
				Logger.log_debug("Veralteter Skill im Save: '%s' (Spieler %d) — übersprungen." % [skill_name, pid], LOG_CAT)
