# res://scripts/core/EntityContext.gd
class_name EntityContext extends IEntityContext

## EntityContext — Produktions-Implementierung von IEntityContext.
##
## Wird von EntityOrchestrator erstellt und in on_spawn() injiziert.
## Hält keine Services selbst — delegiert an die übergebenen Instanzen.
##
## MIGRATION-010 Phase 1: owner_peer_id ergänzt (Default 1 = lokaler Solo-Spieler).
## Entities reichen diesen Wert an Service-Aufrufe durch statt player_id selbst
## herzuleiten — hält die ADR-006-Abschirmung (kein Services.xyz in Entities) intakt.

var _skill_system:    SkillSystem          = null
var _inventory:       InventorySystem       = null
var _factory:         Factory3D             = null
var _respawn:         RespawnService        = null
var _data:            DataService           = null
var _stat_modifiers:  StatModifierService   = null
var _combat_system:   CombatSystem          = null
var _equipment:       EquipmentService      = null

## peer_id des Spielers, dem diese Entity gehört.
## Default 1 = lokaler Spieler (Tier 1 / Solo-Modus, kein MultiplayerPeer gesetzt).
## In Tier 2/3 wird dieser Wert von EntityOrchestrator.spawn_entity() gesetzt.
var owner_peer_id: int = 1


## Erstellt einen EntityContext aus dem laufenden Services-Container.
## Wird von EntityOrchestrator.spawn_entity() aufgerufen.
static func from_services(peer_id: int = 1) -> EntityContext:
	var ctx := EntityContext.new()
	ctx._skill_system   = Services.skill_system
	ctx._inventory      = Services.inventory
	ctx._factory        = Services.factory3d
	ctx._respawn        = Services.respawn
	ctx._data           = Services.data
	ctx._stat_modifiers = Services.stat_modifiers
	ctx._combat_system  = Services.combat
	ctx._equipment      = Services.equipment
	ctx.owner_peer_id   = peer_id
	return ctx


## Erstellt einen minimalen Kontext für Unit-Tests.
## Felder können danach direkt gesetzt werden:
##   var ctx = EntityContext.for_test()
##   ctx._skill_system = MockSkillSystem.new()
##   ctx.owner_peer_id = 42
static func for_test(peer_id: int = 1) -> EntityContext:
	var ctx := EntityContext.new()
	ctx.owner_peer_id = peer_id
	return ctx


# ─────────────────────────────────────────────
# IEntityContext Overrides
# ─────────────────────────────────────────────

func get_skill_system() -> SkillSystem:
	return _skill_system

func get_inventory() -> InventorySystem:
	return _inventory

func get_factory() -> Factory3D:
	return _factory

func get_respawn() -> RespawnService:
	return _respawn

func get_data() -> DataService:
	return _data

func get_stat_modifiers() -> StatModifierService:
	return _stat_modifiers

func get_combat_system() -> CombatSystem:
	return _combat_system

func get_equipment() -> EquipmentService:
	return _equipment
