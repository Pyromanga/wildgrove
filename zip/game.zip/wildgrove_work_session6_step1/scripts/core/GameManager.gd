extends ServiceNode
class_name GameManager

const LOG_CAT := "GameManager"

var _current_state: GameEnums.State = GameEnums.State.BOOT
var _scene_manager: SceneManager
var _config: GameConfig


func configure(deps: Dictionary) -> void:
	_scene_manager = deps.get("scenemanager")
	_config = load("res://config/GameConfig.tres") as GameConfig
	if not _config:
		Logger.log_warn("GameConfig.tres nicht geladen — Übergänge unkontrolliert.", LOG_CAT)


func on_ready() -> void:
	# Session-Ready-Signal: wenn Session-Services gebootet sind → PLAYING
	EventBus.system.session_ready.connect(_on_session_ready)
	EventBus.ui.main_menu_requested.connect(
		func() -> void: change_state(GameEnums.State.MAIN_MENU)
	)
	Logger.log_debug("GameManager lauscht auf session_ready.", LOG_CAT)


## start_game() setzt den initialen State ohne einen Szenenwechsel auszulösen.
## MainMenu.tscn ist bereits die laufende Startszene (project.godot: run/main_scene).
## Keine Session wird hier gestartet — der Spieler wählt im Hauptmenü einen Charakter.
func start_game() -> void:
	_current_state = GameEnums.State.MAIN_MENU
	Logger.log_info("State initialisiert: MAIN_MENU (warte auf Charakter-Auswahl).", LOG_CAT)
	EventBus.system.emit_state_changed(_current_state)


func _on_session_ready() -> void:
	Logger.log_info("Session bereit — wechsle zu PLAYING.", LOG_CAT)
	change_state(GameEnums.State.PLAYING)


func change_state(new_state: GameEnums.State) -> void:
	if new_state == _current_state:
		return

	if not StateValidator.is_transition_allowed(_current_state, new_state, _config):
		return

	Logger.log_info(
		(
			"State: %s → %s"
			% [GameEnums.State.keys()[_current_state], GameEnums.State.keys()[new_state]]
		),
		LOG_CAT
	)
	_current_state = new_state

	if _scene_manager:
		_scene_manager.transition_to_state(_current_state)

	EventBus.system.emit_state_changed(_current_state)


func get_state() -> GameEnums.State:
	return _current_state


func is_playing() -> bool:
	return _current_state == GameEnums.State.PLAYING
