# Tests — WildGrove

## Setup

GUT v9.3.0 muss installiert sein. Ohne GUT laufen nur die Stubs in `tests/`.

### GUT installieren

```
Project → Asset Library → "Gut - Godot Unit Testing" → Install
```

Oder manuell: https://github.com/bitwes/Gut/releases/tag/v9.3.0
→ Ordner als `res://addons/gut/` ablegen
→ Project → Project Settings → Plugins → GUT aktivieren

### Tests ausführen

```
# Via GUT-Panel (empfohlen):
Project → Tools → GUT

# Via CLI (CI):
godot --headless -s addons/gut/gut_cmdln.gd -gdir=res://tests/ -gexit
```

---

## Test-Struktur

```
tests/
  unit/                              ← Isolierte Unit-Tests (kein SceneTree nötig)
    test_save_migration.gd           ← SaveMigrationService — pure functions
    test_quest_objective.gd          ← QuestObjectiveHandler — pure functions
    test_entity_context.gd           ← EntityContext.for_test() — kein AutoLoad
    test_stat_modifier.gd            ← StatModifier + StatModifierService (inkl. Multi-Tenancy)
    test_save_system.gd              ← SaveSystem — atomic write, slot management
    test_equipment_service.gd        ← EquipmentService (inkl. Multi-Tenancy, ISaveProvider)
    test_combat_system.gd            ← CombatSystem — damage calculation, status effects
    test_skill_system.gd             ← SkillSystem — XP, level-up, multi-tenancy
    test_state_validator.gd          ← ServiceValidator — config checks
    test_network_bridge.gd           ← NetworkBridge — authority tiers
    test_biome_registry.gd           ← BiomeRegistry — biome lookup
    test_goblin_loot.gd              ← LootTable — drop randomization
    test_enemy_npc_pool_reuse.gd     ← EntityPool — acquire/release cycle
    test_factory3d_nature.gd         ← Factory3D — nature object creation
    test_inventory_ui_signal.gd      ← InventoryUIController — signal routing
  IntegrationTest.gd                 ← Boot-Sanity-Check (braucht echten ServiceOrchestrator)
```

---

## Konventionen

- Unit-Tests: `extends GutTest` (GUT v9 API)
- Dateien: `test_*.gd` — GUT matched automatisch
- Assertions: `assert_eq`, `assert_true`, `assert_not_null` (GUT-API)
- Kein `Services.xyz` in Unit-Tests — `EntityContext.for_test()` oder direkte Instanziierung
- Jeder `describe_*`-Block gruppiert verwandte Tests

---

## Coverage-Übersicht (Stand Prio 3)

| System | Tests | Lücken |
|--------|-------|--------|
| `StatModifierService` | ✅ vollständig + Multi-Tenancy | — |
| `EquipmentService` | ✅ vollständig + Multi-Tenancy + ISaveProvider | WeaponVisual3D-Attachment (braucht SceneTree) |
| `CombatSystem` | ✅ damage calc, krit, resistenz, status-effekte | apply_weapon_on_hit (braucht Services) |
| `SkillSystem` | ✅ XP, level-up, multi-tenancy | — |
| `SaveSystem` | ✅ atomic write, slot management | — |
| `SaveMigrationService` | ✅ v1→v2→v3 Migration | — |
| `InventorySystem` | ⚠ signal-routing test; keine add/remove-Tests | item limit, weight |
| `QuestService` | ✅ objectives, completion, rewards | — |
| `ChunkManager` | ❌ kein Test | on_tick, chunk load/unload |
| `WorldGenerationService` | ❌ kein Test | position generation, min-distance |

**Nächster Schritt:** ChunkManager- und WorldGenerationService-Tests, Farming/Season (Prio 4).

---

## Warum diese Klassen zuerst?

| Klasse | Warum sofort testbar |
|--------|---------------------|
| `SaveMigrationService` | Reine statische Funktionen — kein State, kein SceneTree |
| `QuestObjectiveHandler` | Reine statische Funktionen — nur Dictionary-Input |
| `EntityContext.for_test()` | Liefert isolierten Kontext — kein AutoLoad nötig |
| `StatModifierService` | RefCounted-artig, kein SceneTree |
| `EquipmentService` | Extends Service (RefCounted) — direkt instanziierbar |
