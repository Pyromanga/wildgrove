# res://scripts/player/PlayerMover.gd
class_name PlayerMover
extends RefCounted

const LOG_CAT := "PlayerMover"

## Direkt gesetzte Stats (von Player._apply_stats() via Services.data).
## _stats (PlayerData-Resource) wird nicht mehr benötigt — DataService ist
## die Single Source of Truth, Player injiziert die Werte als floats.
var speed: float = 6.0
var gravity: float = 12.0

## Referenz auf StatModifierService — via Player.on_spawn(ctx) injiziert.
## Nil-safe: wenn kein Service verfügbar, fällt get_current_speed() auf speed zurück.
var _stat_modifiers: StatModifierService = null

var _last_speed_log: float = 0.0


## Injiziert den StatModifierService nach dem Spawn.
## Wird von Player.on_spawn(ctx) aufgerufen.
func inject_stat_modifiers(svc: StatModifierService) -> void:
	_stat_modifiers = svc
	Logger.log_debug("StatModifierService injiziert.", LOG_CAT)


func get_current_speed() -> float:
	var current_speed: float
	if is_instance_valid(_stat_modifiers):
		current_speed = _stat_modifiers.get_effective_stat("move_speed", speed)
	else:
		current_speed = speed

	if not is_equal_approx(current_speed, _last_speed_log):
		Logger.log_info(
			"Speed Update: %.2f (Base: %.2f)" % [current_speed, speed],
			LOG_CAT
		)
		_last_speed_log = current_speed

	return current_speed


const MAX_FALL_SPEED: float = 50.0  # Terminal velocity — verhindert unbegrenzten Fall-Log-Spam

var _last_gravity_log: float = 0.0   # Letzte geloggte vel.y für Throttling


func calculate_velocity(
	current_vel: Vector3, direction: Vector3, delta: float, on_floor: bool
) -> Vector3:
	var effective_speed: float = get_current_speed()
	var target_vel: Vector3 = direction * effective_speed
	var vel: Vector3 = current_vel

	const ACCEL: float = 10.0

	vel.x = lerp(vel.x, target_vel.x, ACCEL * delta)
	vel.z = lerp(vel.z, target_vel.z, ACCEL * delta)

	if on_floor:
		vel.y = 0.0
	else:
		vel.y -= gravity * delta
		# Terminal velocity — ohne Deckel fällt der Spieler durch Kollisionen bei hoher Geschwindigkeit
		vel.y = maxf(vel.y, -MAX_FALL_SPEED)
		# Log-Throttling: nur loggen wenn vel.y sich um mehr als 5 geändert hat
		# Verhindert hunderte identische Log-Zeilen pro Sekunde
		if abs(vel.y - _last_gravity_log) > 5.0:
			Logger.log_trace(
				"Gravity: vel.y=%.1f (gravity=%.1f)" % [vel.y, gravity], {}, LOG_CAT
			)
			_last_gravity_log = vel.y

	return vel
