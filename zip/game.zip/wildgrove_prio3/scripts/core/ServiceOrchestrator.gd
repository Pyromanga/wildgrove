extends Node

## ServiceOrchestrator — Zentrale Boot- und Teardown-Drehscheibe.
##
## AutoLoad #5 (nach Logger, EventBus, SimpleTerminal, Services).
## Lebt für die gesamte Spiellaufzeit und überlebt alle Szenenwechsel.
##
## Zwei-Registry-Architektur (ADR-009):
##   _global_registry  — app-lifetime (ticker, scenemanager, data, gamemanager, savesystem)
##   _session_registry — charakter-lifetime (inventory, skills, quests, world, ...)
##
## Global-Boot-Pipeline (beim App-Start):
##   Phase 1 — Validate:    ServiceValidator prüft global_services in BootstrapConfig.tres
##   Phase 2 — Resolve:     ServiceDependencyResolver (Kahn's Algorithmus)
##   Phase 3 — Instantiate: ServiceFactory erzeugt Instanzen
##   Phase 4 — Configure:   ServiceInitializer ruft configure(deps) auf
##   Phase 5 — Activate:    ServiceInitializer ruft on_ready() auf
##   Phase 6 — Tick Start:  ServiceTicker wird gestartet
##   Phase 7 — Install:     Services.populate_global() befüllt den Container
##   Phase 8 — Game Start:  GameManager.start_game() → State: MAIN_MENU
##
## Session-Boot-Pipeline (bei Charakter-Auswahl via EventBus.system.session_requested):
##   Phase S1 — Teardown:   Bestehende Session abräumen (falls vorhanden)
##   Phase S2 — Load Save:  SaveSystem.begin_session(player_id) lädt Spielstand von Disk
##   Phase S3–S7:           Identisch zu Phasen 1–5, aber für session_services
##   Phase S8 — Install:    Services.populate_session() befüllt Session-Slots
##   Phase S9 — Ready:      EventBus.system.session_ready.emit()
##                          → GameManager._on_session_ready() → change_state(PLAYING)

const LOG_CAT := "Orchestrator"

var _global_registry := ServiceRegistry.new()
var _session_registry := ServiceRegistry.new()


## Einzige Wahrheitsquelle für "ist eine Session aktiv" — kein eigenes Flag mehr (A-16).
## GameManager ist Autorität über den App-State.
func _is_session_active() -> bool:
	var gm := _global_registry.get_service("gamemanager") as GameManager
	return is_instance_valid(gm) and gm.get_state() == GameEnums.State.PLAYING

var validator := ServiceValidator.new()
var resolver := ServiceDependencyResolver.new()
var factory := ServiceFactory.new()
var initializer := ServiceInitializer.new()
var installer := ServiceInstaller.new()
var teardown := ServiceTeardownManager.new()


func _ready() -> void:
	EventBus.system.session_requested.connect(_on_session_requested)
	EventBus.system.state_changed.connect(_on_state_changed)
	boot_global()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_CRASH:
		_teardown_all()


# ─────────────────────────────────────────────
# Global Boot
# ─────────────────────────────────────────────


func boot_global() -> void:
	Logger.log_info("╔══ GLOBAL BOOT START ══╗", LOG_CAT)
	var started := Time.get_ticks_msec()

	# Phase 1: Validierung
	var defs := validator.validate()
	if defs.is_empty():
		Logger.log_error("Phase 1 FAIL — global_services leer oder defekt.", LOG_CAT)
		EventBus.system.boot_failed.emit("validate_global", "BootstrapConfig.global_services ungültig")
		return
	Logger.log_info("Phase 1 OK — %d globale Definitionen." % defs.size(), LOG_CAT)

	# Phase 2: Dependency-Auflösung
	var ordered := resolver.resolve(defs)
	if ordered.is_empty():
		Logger.log_error("Phase 2 FAIL — Zirkuläre Abhängigkeiten in global_services.", LOG_CAT)
		EventBus.system.boot_failed.emit("resolve_global", "Dependency-Fehler")
		return
	Logger.log_info("Phase 2 OK — Reihenfolge: [%s]" % ", ".join(ordered), LOG_CAT)

	# Phase 3: Instanziierung (sortierte Reihenfolge)
	var ordered_defs := _sort_defs(defs, ordered)
	var ok := factory.instantiate_all(ordered_defs, _global_registry, self)
	if not ok:
		Logger.log_error("Phase 3 FAIL — Global-Service konnte nicht instanziiert werden.", LOG_CAT)
		EventBus.system.boot_failed.emit("factory_global", "Instanziierung fehlgeschlagen")
		return
	Logger.log_info("Phase 3 OK — Alle Global-Services instanziiert.", LOG_CAT)

	# Phase 4: Configure
	initializer.run(ordered, _global_registry)
	Logger.log_info("Phase 4 OK — configure() abgeschlossen.", LOG_CAT)

	# Phase 5: on_ready
	initializer.run_on_ready(ordered, _global_registry)
	Logger.log_info("Phase 5 OK — on_ready() abgeschlossen.", LOG_CAT)

	# Phase 6: Ticker
	var ticker := _global_registry.get_service("ticker") as ServiceTicker
	if ticker:
		ticker.start_ticking()
		Logger.log_info("Phase 6 OK — Ticker gestartet.", LOG_CAT)
	else:
		Logger.log_warn("Phase 6 — Kein Ticker in Global-Registry.", LOG_CAT)

	# Phase 7: Services-Container (nur globale Slots)
	installer.install(_global_registry)
	Services.populate_global(_global_registry)
	Logger.log_info("Phase 7 OK — Globale Services im Container.", LOG_CAT)

	# Phase 8: GameManager → MAIN_MENU
	var gm := _global_registry.get_service("gamemanager")
	if gm is GameManager:
		Logger.log_info("Phase 8 — GameManager.start_game().", LOG_CAT)
		gm.start_game()
	else:
		Logger.log_warn("Phase 8 — GameManager nicht in Registry.", LOG_CAT)

	EventBus.system.services_initialized.emit()

	var elapsed := Time.get_ticks_msec() - started
	Logger.log_info("╚══ GLOBAL BOOT FERTIG (%d ms) ══╝" % elapsed, LOG_CAT)


# ─────────────────────────────────────────────
# Session Boot
# ─────────────────────────────────────────────


func _on_session_requested(player_id: String) -> void:
	boot_session(player_id)


func boot_session(player_id: String) -> void:
	Logger.log_info("╔══ SESSION BOOT START (Charakter: '%s') ══╗" % player_id, LOG_CAT)
	var started := Time.get_ticks_msec()

	# Phase S1: Bestehende Session abräumen
	if _is_session_active():
		Logger.log_info("Phase S1 — Bestehende Session wird abgerissen.", LOG_CAT)
		_teardown_session_internal()
	else:
		Logger.log_info("Phase S1 — Keine bestehende Session.", LOG_CAT)

	# Phase S2: Save laden
	var save_sys := _global_registry.get_service("savesystem") as SaveSystem
	if save_sys:
		save_sys.begin_session(player_id)
		Logger.log_info("Phase S2 OK — Session für '%s' geladen." % player_id, LOG_CAT)
	else:
		Logger.log_error("Phase S2 FAIL — SaveSystem nicht in Global-Registry!", LOG_CAT)
		EventBus.system.boot_failed.emit("session_save", "SaveSystem fehlt")
		return

	# Globale Namen für Cross-Registry-Dep-Auflösung
	var global_names := _global_registry.get_all_names()

	# Phase S3: Validierung
	var defs := validator.validate_session(global_names)
	if defs.is_empty():
		Logger.log_error("Phase S3 FAIL — session_services leer oder defekt.", LOG_CAT)
		EventBus.system.boot_failed.emit("validate_session", "BootstrapConfig.session_services ungültig")
		return
	Logger.log_info("Phase S3 OK — %d Session-Definitionen." % defs.size(), LOG_CAT)

	# Phase S4: Dependency-Auflösung (global_names als extern bekannt)
	var ordered := resolver.resolve(defs, global_names)
	if ordered.is_empty():
		Logger.log_error("Phase S4 FAIL — Zirkuläre Abhängigkeiten in session_services.", LOG_CAT)
		EventBus.system.boot_failed.emit("resolve_session", "Dependency-Fehler")
		return
	Logger.log_info("Phase S4 OK — Reihenfolge: [%s]" % ", ".join(ordered), LOG_CAT)

	# Phase S5: Instanziierung
	var ordered_defs := _sort_defs(defs, ordered)
	_session_registry = ServiceRegistry.new()
	var ok := factory.instantiate_all(ordered_defs, _session_registry, self)
	if not ok:
		Logger.log_error("Phase S5 FAIL — Session-Service konnte nicht instanziiert werden.", LOG_CAT)
		EventBus.system.boot_failed.emit("factory_session", "Instanziierung fehlgeschlagen")
		return
	Logger.log_info("Phase S5 OK — Alle Session-Services instanziiert.", LOG_CAT)

	# Phase S6: Configure (mit Global-Registry als Fallback für Cross-Deps)
	initializer.run(ordered, _session_registry, _global_registry)
	Logger.log_info("Phase S6 OK — configure() abgeschlossen.", LOG_CAT)

	# Phase S7: on_ready
	initializer.run_on_ready(ordered, _session_registry, _global_registry)
	Logger.log_info("Phase S7 OK — on_ready() abgeschlossen.", LOG_CAT)

	# Phase S8: Services-Container (Session-Slots)
	installer.install_session(_session_registry)
	Services.populate_session(_session_registry)
	Logger.log_info("Phase S8 OK — Session-Services im Container.", LOG_CAT)

	# Phase S8.5: MeshCache warm-up — einmalig BEVOR erste Entity spawnt.
	# Alle GPU-Ressourcen (Meshes, Materialien) werden hier gebaut.
	# Ergebnis: kein CylinderMesh.new() / SphereMesh.new() mehr zur Laufzeit.
	if is_instance_valid(Services.world) and Services.world.factory3d != null:
		if Services.world.factory3d.cache == null:
			Services.world.factory3d.cache = MeshCache.new()
		Services.world.factory3d.cache.build()
		Logger.log_info("Phase S8.5 OK — MeshCache gebaut.", LOG_CAT)
	else:
		Logger.log_warn("Phase S8.5 — WorldService oder factory3d nicht verfügbar, MeshCache übersprungen.", LOG_CAT)

	var elapsed := Time.get_ticks_msec() - started
	Logger.log_info("╚══ SESSION BOOT FERTIG (%d ms) ══╝" % elapsed, LOG_CAT)

	# Phase S9: Session ready → GameManager wechselt zu PLAYING.
	# HUDManager lauscht selbst auf session_ready (ADR-003 — Orchestrator
	# kennt HUDManager nicht namentlich).
	EventBus.system.emit_session_ready()


# ─────────────────────────────────────────────
# Session Teardown
# ─────────────────────────────────────────────


## Reagiert auf state_changed — reißt Session ab wenn Rückkehr ins Hauptmenü.
func _on_state_changed(new_state: int) -> void:
	if new_state == GameEnums.State.MAIN_MENU and _is_session_active():
		Logger.log_info("State → MAIN_MENU mit aktiver Session — teardown.", LOG_CAT)
		_teardown_session_internal()
		EventBus.system.emit_session_unloaded()


func _teardown_session_internal() -> void:
	Logger.log_info("── Session-Teardown gestartet", LOG_CAT)
	Services.clear_session()
	teardown.execute(_session_registry)
	_session_registry = ServiceRegistry.new()

	var save_sys := _global_registry.get_service("savesystem") as SaveSystem
	if save_sys:
		save_sys.end_session()

	Logger.log_info("── Session-Teardown fertig", LOG_CAT)


# ─────────────────────────────────────────────
# App Teardown
# ─────────────────────────────────────────────


func _teardown_all() -> void:
	Logger.log_info("── App-Teardown gestartet", LOG_CAT)
	if _is_session_active():
		_teardown_session_internal()
	Services.clear()
	teardown.execute(_global_registry)
	Logger.log_info("── App-Teardown fertig", LOG_CAT)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _sort_defs(defs: Array[ServiceDefinition], ordered: Array[String]) -> Array[ServiceDefinition]:
	var def_map: Dictionary = {}
	for d in defs:
		def_map[d.service_name.to_lower()] = d
	var result: Array[ServiceDefinition] = []
	for name in ordered:
		if def_map.has(name):
			result.append(def_map[name])
	return result


# ─────────────────────────────────────────────
# Debug API (für SimpleTerminal)
# ─────────────────────────────────────────────


## Gibt alle registrierten Service-Namen zurück (global + session).
func get_registered_names() -> Array[String]:
	var names := _global_registry.get_all_names()
	names.append_array(_session_registry.get_all_names())
	return names


## Gibt Laufzeit-Info über einen einzelnen Service zurück.
func get_service_info(service_name: String) -> Dictionary:
	var svc := _global_registry.get_service(service_name)
	var def := _global_registry.get_definition(service_name)
	var scope := "global"
	if svc == null:
		svc = _session_registry.get_service(service_name)
		def = _session_registry.get_definition(service_name)
		scope = "session"
	if svc == null:
		return {"error": "Service '%s' nicht gefunden." % service_name}
	return {
		"name": service_name,
		"scope": scope,
		"class": svc.get_class(),
		"valid": is_instance_valid(svc),
		"deps": def.deps if def else [],
	}


## Gibt true zurück wenn eine Session aktiv ist.
func is_session_active() -> bool:
	return _is_session_active()
