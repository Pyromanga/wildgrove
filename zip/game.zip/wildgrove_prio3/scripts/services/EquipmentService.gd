# res://scripts/services/EquipmentService.gd
extends Service
class_name EquipmentService

## EquipmentService — Verwaltet ausgerüstete Items pro Slot.
##
## DESIGN: Slot-basiert (String-Key wie "weapon"), nicht hart auf "die eine
## Waffe" verdrahtet. Jeder Slot bekommt seine eigene StatModifier-source_id
## ("equipment_<slot>") und sein eigenes optionales 3D-Visual — verschiedene
## Slots überschreiben sich dadurch nie gegenseitig, sie koexistieren parallel.
##
## MULTI-TENANCY (Prio 3):
##   _equipped:  { peer_id: { slot: ItemDefinition } }
##   _visuals:   { peer_id: { slot: WeaponVisual3D } }
##   Alle öffentlichen Methoden akzeptieren player_id: int = 1 als letzten Parameter.
##   Vollständig rückwärtskompatibel — bestehende Aufrufer ohne player_id verwenden player 1.
##
## PERSISTENZ (Prio 3):
##   Implementiert ISaveProvider. Save-Key: "equipment".
##   Format: { "peer_id_str": { "weapon": "item_id", "helmet": null, ... } }
##   Benötigt DataService in deps für ItemDefinition-Lookup beim Load.
##   Migration: SaveMigrationService v3 ergänzt leeres "equipment"-Objekt für Saves < v3.
##
## VERANTWORTUNG:
##   equip()/unequip()        → Item in einen Slot setzen/entfernen.
##   get_equipped_weapon()    → Bequemlichkeits-Accessor für CombatSystem.
##
## NICHT VERANTWORTLICH für:
##   - Inventar-Abzug beim Equip (InventorySystem bleibt Quelle der Wahrheit
##     über Item-Besitz — Verdrahtung "equip aus Inventar" ist UI-/Interaction-
##     Schicht, nicht dieser Service)
##
## VERWENDUNG:
##   Services.equipment.equip("weapon", iron_sword_def, player.visuals)
##   Services.equipment.unequip("weapon")
##   var weapon := Services.equipment.get_equipped_weapon()  # für CombatSystem

const LOG_CAT := "Equipment"

## Präfix für StatModifier-source_ids — Komplett-Cleanup via remove_modifiers_with_prefix().
const SOURCE_PREFIX := "equipment_"
const SLOT_WEAPON   := "weapon"

var _stat_modifiers: StatModifierService = null
var _data: DataService = null  # für ItemDefinition-Lookup beim Save-Load

## _equipped:  { player_id (int): { slot (String): ItemDefinition } }
var _equipped: Dictionary = {}

## _visuals:   { player_id (int): { slot (String): WeaponVisual3D } }
var _visuals: Dictionary = {}

## Emittiert wenn ein Slot equipped/unequipped wurde. item_def == null bei unequip.
signal equipment_changed(slot: String, item_def: ItemDefinition)


# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	_stat_modifiers = deps.get("stat_modifiers") as StatModifierService
	_data = deps.get("data") as DataService
	if not is_instance_valid(_stat_modifiers):
		Logger.log_debug("StatModifierService nicht in deps — Equipment-Boni nicht verfügbar.", LOG_CAT)
	Logger.log_info("EquipmentService konfiguriert (Multi-Tenant + Persistenz).", LOG_CAT)


func on_ready() -> void:
	Logger.log_info("EquipmentService bereit.", LOG_CAT)


func on_cleanup() -> void:
	for pid in _visuals.keys():
		var slots: Dictionary = _visuals[pid]
		for slot in slots.keys():
			var wv: WeaponVisual3D = slots[slot]
			if is_instance_valid(wv):
				wv.detach()
				wv.queue_free()
	_visuals.clear()

	if is_instance_valid(_stat_modifiers):
		for pid in _equipped.keys():
			_stat_modifiers.remove_modifiers_with_prefix(SOURCE_PREFIX, pid)

	_equipped.clear()
	Logger.log_info("EquipmentService cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# ISaveProvider
# ─────────────────────────────────────────────


func save_key() -> String:
	return "equipment"


func save_data() -> Dictionary:
	## Serialisiert alle ausgerüsteten Items: { "peer_id_str": { "slot": "item_id"|null } }
	var result: Dictionary = {}
	for pid in _equipped:
		var slots: Dictionary = _equipped[pid]
		var serialized: Dictionary = {}
		for slot in slots:
			var item: ItemDefinition = slots[slot]
			serialized[slot] = item.id if is_instance_valid(item) else null
		result[str(pid)] = serialized
	return result


func load_data(data: Dictionary) -> void:
	## Deserialisiert — benötigt DataService für item_id → ItemDefinition Lookup.
	_equipped.clear()
	if not is_instance_valid(_data):
		Logger.log_warn("load_data: DataService fehlt — Equipment wird nicht wiederhergestellt.", LOG_CAT)
		return

	for pid_str in data:
		var pid: int = int(pid_str)
		var slots: Dictionary = data[pid_str]
		_equipped[pid] = {}
		for slot in slots:
			var item_id = slots[slot]
			if item_id == null or item_id == "":
				continue
			var item: ItemDefinition = _data.get_item(item_id)
			if is_instance_valid(item):
				_equipped[pid][slot] = item
				_apply_stat_bonus(slot, item, pid)
			else:
				Logger.log_warn("load_data: Item '%s' nicht gefunden — Slot '%s' bleibt leer." % [item_id, slot], LOG_CAT)
	Logger.log_info("Equipment geladen (%d Spieler)." % _equipped.size(), LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Rüstet item_def in slot aus. Slots sind exklusiv (ein zweites equip() auf
## denselben Slot ruft zuerst unequip() auf — symmetrisch zu StatModifierService).
## [param visuals] Optional — nur nötig wenn item_def ein 3D-Visual besitzt.
## [return] false bei ungültigen Parametern.
func equip(slot: String, item_def: ItemDefinition, visuals: PlayerVisuals = null, player_id: int = 1) -> bool:
	if slot.is_empty():
		Logger.log_error("equip: slot darf nicht leer sein!", LOG_CAT)
		return false
	if not is_instance_valid(item_def):
		Logger.log_error("equip: item_def ungültig.", LOG_CAT)
		return false

	unequip(slot, player_id)

	_player_equipped(player_id)[slot] = item_def
	_apply_stat_bonus(slot, item_def, player_id)

	if item_def is WeaponDefinition and is_instance_valid(visuals):
		var wv := WeaponVisual3D.new()
		wv.attach_to(visuals, item_def as WeaponDefinition)
		_player_visuals(player_id)[slot] = wv

	Logger.log_info("Ausgerüstet: '%s' in Slot '%s' (player %d)." % [item_def.display_name, slot, player_id], LOG_CAT)
	equipment_changed.emit(slot, item_def)
	return true


## Entfernt das Item aus slot. Räumt StatModifier + Visual symmetrisch ab.
## [return] false wenn der Slot bereits leer war.
func unequip(slot: String, player_id: int = 1) -> bool:
	var equipped := _player_equipped(player_id)
	if not equipped.has(slot):
		return false

	if is_instance_valid(_stat_modifiers):
		_stat_modifiers.remove_modifier(_source_id(slot), player_id)

	var visuals := _player_visuals(player_id)
	if visuals.has(slot):
		var wv: WeaponVisual3D = visuals[slot]
		if is_instance_valid(wv):
			wv.detach()
			wv.queue_free()
		visuals.erase(slot)

	var removed: ItemDefinition = equipped[slot]
	equipped.erase(slot)

	Logger.log_info("Entfernt: '%s' aus Slot '%s' (player %d)." % [removed.display_name, slot, player_id], LOG_CAT)
	equipment_changed.emit(slot, null)
	return true


## Gibt das ausgerüstete Item in slot zurück, oder null wenn leer.
func get_equipped(slot: String, player_id: int = 1) -> ItemDefinition:
	return _player_equipped(player_id).get(slot)


## Bequemlichkeits-Accessor für CombatSystem.
## [return] null wenn der Slot leer ist oder kein WeaponDefinition enthält.
func get_equipped_weapon(slot: String = SLOT_WEAPON, player_id: int = 1) -> WeaponDefinition:
	var item: ItemDefinition = _player_equipped(player_id).get(slot)
	return item as WeaponDefinition if item is WeaponDefinition else null


func is_equipped(slot: String, player_id: int = 1) -> bool:
	return _player_equipped(player_id).has(slot)


## Räumt alle Slots eines Spielers — bei Disconnect/Session-Ende.
func clear_player(player_id: int) -> void:
	for slot in _player_equipped(player_id).keys():
		unequip(slot, player_id)
	_equipped.erase(player_id)
	_visuals.erase(player_id)
	Logger.log_info("Equipment für player %d geleert." % player_id, LOG_CAT)


# ─────────────────────────────────────────────
# Debug-API
# ─────────────────────────────────────────────


## Gibt alle aktuell belegten Slots als lesbare Liste zurück. Für Terminal-Commands.
func get_debug_report(player_id: int = 1) -> Array[String]:
	var result: Array[String] = []
	for slot in _player_equipped(player_id):
		var item: ItemDefinition = _player_equipped(player_id)[slot]
		result.append("[%s] %s" % [slot, item.display_name])
	return result


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _source_id(slot: String) -> String:
	return SOURCE_PREFIX + slot


func _player_equipped(player_id: int) -> Dictionary:
	if not _equipped.has(player_id):
		_equipped[player_id] = {}
	return _equipped[player_id]


func _player_visuals(player_id: int) -> Dictionary:
	if not _visuals.has(player_id):
		_visuals[player_id] = {}
	return _visuals[player_id]


## Übersetzt die Boni eines ausgerüsteten Items in StatModifier(e).
func _apply_stat_bonus(slot: String, item_def: ItemDefinition, player_id: int) -> void:
	if not is_instance_valid(_stat_modifiers):
		return
	if item_def is WeaponDefinition:
		var weapon := item_def as WeaponDefinition
		if weapon.damage_bonus != 0.0:
			_stat_modifiers.add_modifier(StatModifier.permanent(
				_source_id(slot), "damage_bonus", StatModifier.Operation.FLAT_ADD, weapon.damage_bonus
			), player_id)
