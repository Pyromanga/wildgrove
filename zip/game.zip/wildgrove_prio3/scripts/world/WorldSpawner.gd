class_name WorldSpawner
extends RefCounted

## WorldSpawner — Koordiniert das Spawning aller Welt-Entities.
##
## Delegiert an spezialisierte Klassen:
##   EnemySpawner    → Tiere + Feinde
##   WaterBodyPlacer → Wasser-Platzierung
##   PetRestorer     → Gespeicherte Pets wiederherstellen
##
## ChunkManager wird direkt in WorldService.on_world_scene_ready() gestartet.
## Kein Service — wird von WorldService als Hilfsklasse instanziiert.

const LOG_CAT := "WorldSpawner"

var _entity_orchestrator: EntityOrchestrator
var _terrain_generator: TerrainGenerator
var _world_gen: WorldGenerationService
var _data: WorldData

var _enemy_spawner: EnemySpawner
var _water_placer: WaterBodyPlacer
var _pet_restorer: PetRestorer


func _init(
	orchestrator: EntityOrchestrator,
	terrain_gen: TerrainGenerator,
	world_gen: WorldGenerationService,
	world_data: WorldData
) -> void:
	_entity_orchestrator = orchestrator
	_terrain_generator   = terrain_gen
	_world_gen           = world_gen
	_data                = world_data

	_enemy_spawner = EnemySpawner.new(orchestrator, terrain_gen)
	_water_placer  = WaterBodyPlacer.new(terrain_gen)
	_pet_restorer  = PetRestorer.new(world_data)


## Haupt-Entry-Point: spawnt alles für eine frische Welt-Session.
func spawn_all(world_root: Node3D) -> void:
	var t := Logger.log_begin("WorldSpawner.spawn_all()", LOG_CAT)

	var tree_positions: Array[Vector3] = _data.tree_positions
	var ore_positions:  Array[Vector3] = _data.ore_positions

	if tree_positions.is_empty() and ore_positions.is_empty():
		_generate_positions()
		tree_positions = _data.tree_positions
		ore_positions  = _data.ore_positions

	var trees_spawned := 0
	for pos in tree_positions:
		if not _data.is_tree_harvested(pos):
			_entity_orchestrator.spawn_entity("oak_tree", pos)
			trees_spawned += 1

	var ores_spawned := 0
	for pos in ore_positions:
		if not _data.is_ore_harvested(pos):
			_entity_orchestrator.spawn_entity("iron_ore", pos)
			ores_spawned += 1

	_enemy_spawner.spawn_animals()

	var quest_h: float = 0.0
	if is_instance_valid(_terrain_generator):
		quest_h = _terrain_generator.get_height_at(8.0, -5.0)
	_entity_orchestrator.spawn_entity("quest_npc", Vector3(8.0, quest_h, -5.0))

	_enemy_spawner.spawn_enemies()
	_pet_restorer.restore(world_root)
	_water_placer.place_all(world_root)

	# Player via EntityOrchestrator spawnen — erhält on_spawn(config, ctx) wie alle Entities.
	# spawn_position via config damit Player.on_spawn() die korrekte Startposition kennt.
	var player_y: float = 3.0
	if is_instance_valid(_terrain_generator):
		player_y = _terrain_generator.get_height_at(0.0, 0.0) + 2.0
	var player_spawn := Vector3(0.0, player_y, 0.0)
	_entity_orchestrator.spawn_entity("player", player_spawn, {spawn_position = player_spawn})

	Logger.log_end("WorldSpawner.spawn_all()", t, LOG_CAT)
	Logger.log_info(
		"Spawning: %d Bäume, %d Erze. Aktiv: %d." % [
			trees_spawned, ores_spawned, _entity_orchestrator.get_entity_count()
		], LOG_CAT
	)


func _generate_positions() -> void:
	if is_instance_valid(_world_gen):
		Logger.log_info("Kein Save — generiere via WorldGenerationService.", LOG_CAT)
		var seed_val := int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
		var height_cb := Callable()
		if is_instance_valid(_terrain_generator):
			height_cb = _terrain_generator.get_height_at
		_world_gen.generate_world(seed_val, _data, height_cb)
	else:
		Logger.log_warn("WorldGenerationService fehlt — nutze Hardcode-Defaults.", LOG_CAT)
		var defaults: Array[Vector3] = [Vector3(5,0,5), Vector3(-6,0,4), Vector3(8,0,-3)]
		_data.tree_positions = defaults
		_data.ore_positions  = [Vector3(-4,0,6)]
