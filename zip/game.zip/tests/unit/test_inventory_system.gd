# res://tests/unit/test_inventory_system.gd
extends GutTest

## Unit-Tests für InventorySystem (E-02).
##
## Strategie: InventorySystem direkt instanziieren mit einer
## Minimal-Mock-Item-Registry. configure() erhält nur einen minimalen DataService-Stub.
## Kein SaveSystem, kein NetworkBridge — Tier-1-Pfad (direkte Mutations).
##
## Abgedeckt:
##   - on_item_add_confirmed(): einfaches Hinzufügen, Stapeln, Stack-Cap
##   - remove_item(): korrekte Reduktion, Fehler bei zu wenig
##   - has_item(): korrekte Prüfung
##   - request_add_item(): Slot-Limit, Gewichtslimit, unbekanntes Item
##   - Gewichtstracking nach Add / Remove
##   - Multi-Tenanz: zwei player_ids unabhängig
##   - get_save_key() / get_save_data() Serialisierungs-Snapshot
##   - Save-Round-Trip: save_data → _restore_from_save → gleicher State

# ─────────────────────────────────────────────────────────────────────────────
# Minimal-Mock: ItemDefinition-ähnliches Objekt
# ─────────────────────────────────────────────────────────────────────────────

class MockItemDef extends ItemDefinition:
	var weight: float = 1.0

	func _init(p_name: String, p_max_stack: int = 99, p_weight: float = 1.0) -> void:
		display_name = p_name
		max_stack    = p_max_stack
		weight       = p_weight

# ─────────────────────────────────────────────────────────────────────────────
# Minimal-Mock: DataService-Stub
# ─────────────────────────────────────────────────────────────────────────────

class MockDataService extends DataService:
	var _items: Dictionary = {}

	func get_all_items() -> Dictionary:
		return _items

	func get_player_data() -> Variant:
		return null

# ─────────────────────────────────────────────────────────────────────────────
# Test-Setup
# ─────────────────────────────────────────────────────────────────────────────

var _svc:   InventorySystem
var _ds:    MockDataService
var _bus:   MockEventBus
var _item_a: MockItemDef
var _item_b: MockItemDef

const ITEM_A := "iron_ore"
const ITEM_B := "log_oak"

func before_each() -> void:
	_item_a = MockItemDef.new("Iron Ore", 50, 2.0)
	_item_b = MockItemDef.new("Oak Log",  20, 3.0)
	_ds     = MockDataService.new()
	_ds._items[ITEM_A] = _item_a
	_ds._items[ITEM_B] = _item_b
	_bus = MockEventBus.new()

	_svc = InventorySystem.new()
	# configure() ohne SaveSystem → kein Restore, kein Provider-Register
	_svc.configure(ServiceDeps.from_dict({
		ServiceKeys.DATA:      _ds,
		ServiceKeys.EVENT_BUS: _bus,
	}))

func after_each() -> void:
	_svc.on_cleanup()
	_svc = null

# ─────────────────────────────────────────────────────────────────────────────
# on_item_add_confirmed — Basisfälle
# ─────────────────────────────────────────────────────────────────────────────

func test_add_item_increases_quantity() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 5)
	assert_true(_svc.has_item(ITEM_A, 5), "5x iron_ore müssen vorhanden sein")

func test_add_item_twice_stacks() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 3)
	_svc.on_item_add_confirmed(ITEM_A, 4)
	assert_true(_svc.has_item(ITEM_A, 7), "Gestapelt: 7x erwartet")

func test_add_item_caps_at_max_stack() -> void:
	# max_stack = 50
	_svc.on_item_add_confirmed(ITEM_A, 48)
	_svc.on_item_add_confirmed(ITEM_A, 10)  # würde auf 58 gehen → cap bei 50
	var all := _svc.get_all_items()
	var found := false
	for entry in all:
		if entry["id"] == ITEM_A:
			assert_lte(entry["quantity"], 50, "Stack darf max_stack (50) nicht überschreiten")
			found = true
	assert_true(found, "iron_ore muss in get_all_items() erscheinen")

func test_add_unknown_item_is_silent() -> void:
	_svc.on_item_add_confirmed("nonexistent_item", 1)
	assert_false(_svc.has_item("nonexistent_item"), "Unbekanntes Item darf nicht anlegen")

# ─────────────────────────────────────────────────────────────────────────────
# remove_item
# ─────────────────────────────────────────────────────────────────────────────

func test_remove_item_decreases_quantity() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 10)
	var ok := _svc.remove_item(ITEM_A, 4)
	assert_true(ok, "remove_item() muss true zurückgeben")
	assert_true(_svc.has_item(ITEM_A, 6), "6 übrig nach remove 4 von 10")

func test_remove_all_clears_item() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 5)
	_svc.remove_item(ITEM_A, 5)
	assert_false(_svc.has_item(ITEM_A), "Item muss nach vollständigem Remove fehlen")

func test_remove_more_than_owned_returns_false() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 2)
	var ok := _svc.remove_item(ITEM_A, 5)
	assert_false(ok, "remove_item() muss false zurückgeben wenn zu wenig")
	assert_true(_svc.has_item(ITEM_A, 2), "State darf sich nicht geändert haben")

func test_remove_from_empty_returns_false() -> void:
	var ok := _svc.remove_item(ITEM_A, 1)
	assert_false(ok, "remove_item() auf leerem Slot → false")

# ─────────────────────────────────────────────────────────────────────────────
# request_add_item — Slot-Limit, Gewichtslimit
# ─────────────────────────────────────────────────────────────────────────────

func test_request_add_known_item_succeeds() -> void:
	var ok := _svc.request_add_item(ITEM_A, 1)
	assert_true(ok, "request_add_item() muss true für bekanntes Item zurückgeben")
	assert_true(_svc.has_item(ITEM_A, 1), "Item muss danach vorhanden sein")

func test_request_add_unknown_item_returns_false() -> void:
	var ok := _svc.request_add_item("ghost_item", 1)
	assert_false(ok, "Unbekanntes Item → false")

func test_weight_tracked_after_add() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 5)  # 5 × 2.0 kg = 10.0 kg
	var ws := _svc.get_weight_status()
	assert_almost_eq(ws["current"], 10.0, 0.01, "Gewicht muss 10.0 kg sein")

func test_weight_tracked_after_remove() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 5)
	_svc.remove_item(ITEM_A, 2)  # 3 × 2.0 = 6.0 kg
	var ws := _svc.get_weight_status()
	assert_almost_eq(ws["current"], 6.0, 0.01, "Gewicht nach Remove: 6.0 kg")

func test_weight_limit_blocks_add() -> void:
	# Standardlimit: 50 kg. iron_ore = 2.0 kg. 25 Stück = 50.0 kg (Limit)
	_svc.on_item_add_confirmed(ITEM_A, 25)  # 50 kg — exakt am Limit
	# log_oak = 3.0 kg — würde über Limit gehen
	var ok := _svc.request_add_item(ITEM_B, 1)
	assert_false(ok, "Gewichtslimit muss weiteres Hinzufügen verhindern")

# ─────────────────────────────────────────────────────────────────────────────
# get_free_slots
# ─────────────────────────────────────────────────────────────────────────────

func test_free_slots_decreases_on_new_item_type() -> void:
	var before := _svc.get_free_slots()
	_svc.on_item_add_confirmed(ITEM_A, 1)
	var after := _svc.get_free_slots()
	assert_eq(after, before - 1, "Neues Item-Typ belegt einen Slot")

func test_free_slots_unchanged_on_stack_add() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 1)
	var before := _svc.get_free_slots()
	_svc.on_item_add_confirmed(ITEM_A, 5)  # Stacking, kein neuer Slot
	var after := _svc.get_free_slots()
	assert_eq(after, before, "Stacking belegt keinen neuen Slot")

# ─────────────────────────────────────────────────────────────────────────────
# Multi-Tenanz (MIGRATION-010)
# ─────────────────────────────────────────────────────────────────────────────

func test_two_players_have_independent_state() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 10, 1)
	_svc.on_item_add_confirmed(ITEM_A, 3,  2)
	assert_true( _svc.has_item(ITEM_A, 10, 1), "Spieler 1: 10x iron_ore")
	assert_false(_svc.has_item(ITEM_A, 10, 2), "Spieler 2 hat keine 10x iron_ore")
	assert_true( _svc.has_item(ITEM_A, 3,  2), "Spieler 2: 3x iron_ore")

func test_remove_from_player1_does_not_affect_player2() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 5, 1)
	_svc.on_item_add_confirmed(ITEM_A, 5, 2)
	_svc.remove_item(ITEM_A, 5, 1)
	assert_false(_svc.has_item(ITEM_A, 1, 1), "Spieler 1 hat kein iron_ore mehr")
	assert_true( _svc.has_item(ITEM_A, 5, 2), "Spieler 2 unberührt")

# ─────────────────────────────────────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────────────────────────────────────

func test_save_key_is_inventory() -> void:
	assert_eq(_svc.get_save_key(), "inventory", "SAVE_KEY muss 'inventory' sein")

func test_save_data_reflects_current_state() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 7)
	var sd := _svc.get_save_data()
	assert_true(sd.has("1"), "Save-Daten müssen Player-1-Bucket enthalten")
	var bucket := sd["1"] as Dictionary
	assert_true(bucket.has(ITEM_A), "iron_ore muss im Snapshot sein")
	assert_eq(int(bucket[ITEM_A]), 7, "Menge muss 7 sein")

func test_save_data_empty_when_no_items() -> void:
	var sd := _svc.get_save_data()
	# Frische Instanz: Player-1-Bucket existiert durch configure(_ensure_player nicht aufgerufen),
	# aber kein Artikel → entweder leerer bucket oder kein key
	var has_items := false
	for pid_str in sd:
		var b := sd[pid_str] as Dictionary
		if not b.is_empty():
			has_items = true
	assert_false(has_items, "Leeres Inventar → keine Items im Snapshot")

# ─────────────────────────────────────────────────────────────────────────────
# Save-Round-Trip (A-04 / E-02)
# ─────────────────────────────────────────────────────────────────────────────

func test_round_trip_restores_items() -> void:
	# Phase 1: State aufbauen
	_svc.on_item_add_confirmed(ITEM_A, 12)
	_svc.on_item_add_confirmed(ITEM_B, 3)
	var snapshot := _svc.get_save_data()

	# Phase 2: neue Instanz + Restore
	var svc2 := InventorySystem.new()
	svc2.configure(ServiceDeps.from_dict({ServiceKeys.DATA: _ds, ServiceKeys.EVENT_BUS: _bus}))
	svc2._restore_from_save(snapshot)

	assert_true(svc2.has_item(ITEM_A, 12), "Round-Trip: 12x iron_ore muss wiederhergestellt sein")
	assert_true(svc2.has_item(ITEM_B, 3),  "Round-Trip: 3x log_oak muss wiederhergestellt sein")

	svc2.on_cleanup()

func test_round_trip_empty_save_produces_empty_inventory() -> void:
	var svc2 := InventorySystem.new()
	svc2.configure(ServiceDeps.from_dict({ServiceKeys.DATA: _ds, ServiceKeys.EVENT_BUS: _bus}))
	svc2._restore_from_save({})

	assert_false(svc2.has_item(ITEM_A), "Nach leerem Restore: kein iron_ore")
	svc2.on_cleanup()

func test_round_trip_multi_tenant() -> void:
	_svc.on_item_add_confirmed(ITEM_A, 5, 1)
	_svc.on_item_add_confirmed(ITEM_A, 9, 2)
	var snapshot := _svc.get_save_data()

	var svc2 := InventorySystem.new()
	svc2.configure(ServiceDeps.from_dict({ServiceKeys.DATA: _ds, ServiceKeys.EVENT_BUS: _bus}))
	svc2._restore_from_save(snapshot)

	assert_true(svc2.has_item(ITEM_A, 5, 1), "Spieler 1: 5x nach Round-Trip")
	assert_true(svc2.has_item(ITEM_A, 9, 2), "Spieler 2: 9x nach Round-Trip")
	svc2.on_cleanup()
