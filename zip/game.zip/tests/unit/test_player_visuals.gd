# res://tests/unit/test_player_visuals.gd
extends GutTest

## Test für PlayerVisuals.apply_appearance() (Round 105, ADR-048).
## Restlicher PlayerVisuals-Funktionsumfang (Skeleton/Bone-Attachments) ist
## bereits über WeaponVisual3D-nahe Tests indirekt abgedeckt — hier nur die
## in dieser Runde neue Methode.

var _visuals: PlayerVisuals

func before_each() -> void:
	_visuals = autofree(PlayerVisuals.new())

func test_apply_appearance_sets_albedo_color_on_mesh_material() -> void:
	_visuals.apply_appearance(Color(0.25, 0.55, 0.25))

	var mat := _visuals.mesh.material_override as StandardMaterial3D
	assert_true(is_instance_valid(mat))
	assert_eq(mat.albedo_color, Color(0.25, 0.55, 0.25))

func test_apply_appearance_can_be_called_multiple_times_reusing_the_material() -> void:
	_visuals.apply_appearance(Color(0.25, 0.55, 0.25))
	var mat_first := _visuals.mesh.material_override

	_visuals.apply_appearance(Color(0.95, 0.75, 0.25))
	var mat_second := _visuals.mesh.material_override

	assert_eq(mat_first, mat_second, "apply_appearance() soll das bestehende Material wiederverwenden statt bei jedem Aufruf ein neues zu erzeugen.")
	assert_eq((mat_second as StandardMaterial3D).albedo_color, Color(0.95, 0.75, 0.25))
