# res://tests/unit/test_terrain_field.gd
extends GutTest

## Tests für den Terrain-Stack: TerrainSeed, TerrainConfig, Layer und TerrainField.
## Schwerpunkt: die ARCHITEKTUR-GARANTIEN, auf die sich der Rest des Spiels verlässt —
## Determinismus, Seed-Stabilität über Engine-Versionen, Weltkoordinaten, Spawn-Plateau,
## Wasser als Eigenschaft der Höhe.

## Höhenfeld mit fester/beliebiger Funktion — für Wasser-/Steigungs-Tests.
class FuncField extends TerrainField:
	var fn: Callable
	func get_height_at(x: float, z: float) -> float:
		return float(fn.call(x, z))

const SEEDS: Array[int] = [1337, 42, 987654321]

# ── TerrainSeed ─────────────────────────────────

func test_seed_golden_values_never_change() -> void:
	# FESTE Werte: ändert sich einer, sieht JEDE bestehende Welt anders aus. Diese Tests sind
	# der Grund, warum FNV-1a statt String.hash() benutzt wird (nicht versionsstabil).
	assert_eq(TerrainSeed.derive(1337, "terrain.continent"), 343236760)
	assert_eq(TerrainSeed.derive(1337, "terrain.detail"), 2030383245)
	assert_eq(TerrainSeed.derive(0, ""), 1441645609)
	assert_eq(TerrainSeed.derive(42, "climate.temp"), 38122628)
	assert_eq(TerrainSeed.derive(-5, "x"), 2144768907)

func test_seed_is_non_negative_31_bit() -> void:
	for s in [0, 1, -1, 123456789, -987654321, 9223372036854775807]:
		var d := TerrainSeed.derive(s, "terrain.continent")
		assert_true(d >= 0 and d <= 0x7FFFFFFF, "Seed %d → %d außerhalb 31 Bit" % [s, d])

func test_seed_different_salts_and_seeds_differ() -> void:
	assert_ne(TerrainSeed.derive(1, "a"), TerrainSeed.derive(1, "b"))
	assert_ne(TerrainSeed.derive(1, "a"), TerrainSeed.derive(2, "a"))

func test_seed_is_deterministic() -> void:
	assert_eq(TerrainSeed.derive(77, "terrain.river"), TerrainSeed.derive(77, "terrain.river"))

# ── TerrainConfig ───────────────────────────────

func test_config_resolution_follows_edit_lattice() -> void:
	# Chunk-Vertices MÜSSEN auf den Punkten der Edit-Schicht liegen — sonst passt Umgraben nicht.
	var cfg := TerrainConfig.new()
	assert_eq(cfg.get_vertex_spacing(), TerrainEditLayer.SPACING)
	assert_eq(cfg.get_resolution(), 32)

func test_config_defaults_are_sane() -> void:
	var cfg := TerrainConfig.new()
	assert_gt(cfg.spawn_blend_radius, cfg.spawn_flat_radius)
	assert_gt(cfg.basin_end, cfg.basin_start)
	assert_gt(cfg.hill_end, cfg.hill_start)
	assert_gt(cfg.spawn_height, cfg.water_level + 1.0, "Spawn muss klar über dem Wasser liegen.")

# ── TerrainField: Determinismus ─────────────────

func test_same_seed_gives_same_world() -> void:
	var a := TerrainField.new(null, 4711)
	var b := TerrainField.new(null, 4711)
	for i in 50:
		var x := float(i * 137 - 3000)
		var z := float(i * 211 - 4000)
		assert_eq(a.get_height_at(x, z), b.get_height_at(x, z))
		assert_eq(a.get_biome_id_at(x, z), b.get_biome_id_at(x, z))

func test_different_seeds_give_different_worlds() -> void:
	var a := TerrainField.new(null, 1)
	var b := TerrainField.new(null, 2)
	var differs := false
	for i in 50:
		if not is_equal_approx(a.get_height_at(i * 97.0 + 200.0, i * 53.0 + 200.0), b.get_height_at(i * 97.0 + 200.0, i * 53.0 + 200.0)):
			differs = true
			break
	assert_true(differs, "Der world_seed muss im Terrain ankommen (war früher wirkungslos!).")

func test_seed_zero_falls_back_to_default() -> void:
	assert_eq(TerrainField.new(null, 0).get_seed(), TerrainConfig.DEFAULT_SEED)
	assert_eq(TerrainField.new(null, 55).get_seed(), 55)

func test_heights_are_finite_and_in_plausible_range() -> void:
	for s in SEEDS:
		var f := TerrainField.new(null, s)
		for iz in 30:
			for ix in 30:
				var h := f.get_height_at(float(ix) * 173.0 - 2500.0, float(iz) * 191.0 - 2800.0)
				assert_false(is_nan(h) or is_inf(h))
				assert_true(h > -8.0 and h < 20.0, "Höhe %.2f außerhalb des plausiblen Bereichs (seed %d)" % [h, s])

# ── Spawn-Plateau ───────────────────────────────

func test_spawn_area_is_flat_and_dry_for_every_seed() -> void:
	# DAS ist die Garantie für Dorf/NPCs/Ackerbeete: egal welcher Seed, um den Ursprung ist es
	# eben und trocken. (Vorher hing es vom Zufall ab, ob dort See, Hang oder Fluss war.)
	var cfg := TerrainConfig.new()
	for s in [1, 2, 3, 99, 1337, 123456, 987654321, 55555]:
		var f := TerrainField.new(cfg, s)
		for i in 24:
			var ang := float(i) * TAU / 24.0
			for r in [0.0, 10.0, 25.0, cfg.spawn_flat_radius - 1.0]:
				var x: float = cos(ang) * r
				var z: float = sin(ang) * r
				assert_almost_eq(f.get_height_at(x, z), cfg.spawn_height, 0.001, "seed %d @ r=%.0f" % [s, r])
				assert_false(f.is_water_at(x, z))

func test_spawn_plateau_blends_smoothly() -> void:
	var cfg := TerrainConfig.new()
	var f := TerrainField.new(cfg, 1337)
	var prev := f.get_height_at(cfg.spawn_flat_radius, 0.0)
	var r := cfg.spawn_flat_radius
	while r < cfg.spawn_blend_radius:
		r += 1.0
		var h := f.get_height_at(r, 0.0)
		assert_lt(absf(h - prev), 2.5, "Sprung im Übergangsbereich bei r=%.0f" % r)
		prev = h

func test_terrain_far_from_spawn_is_untouched_by_plateau() -> void:
	var cfg := TerrainConfig.new()
	var layer := TerrainSpawnPlateauLayer.new(cfg)
	assert_eq(layer.apply(cfg.spawn_blend_radius + 5.0, 0.0, 7.3), 7.3)
	assert_eq(layer.apply(0.0, 0.0, 7.3), cfg.spawn_height)

# ── Layer ───────────────────────────────────────

func test_river_only_lowers_never_raises() -> void:
	var layer := TerrainRiverLayer.new(TerrainConfig.new(), 1337)
	for i in 400:
		var x := float(i % 20) * 41.0 - 400.0
		var z := float(i / 20) * 37.0 - 400.0
		assert_true(layer.apply(x, z, 2.0) <= 2.0 + 0.0001)

func test_river_exists_and_is_sparse() -> void:
	var layer := TerrainRiverLayer.new(TerrainConfig.new(), 1337)
	var carved := 0
	var total := 0
	for iz in 160:
		for ix in 160:
			total += 1
			if layer.apply(float(ix) * 25.0, float(iz) * 25.0, 2.0) < 1.99:
				carved += 1
	var frac := float(carved) / float(total)
	assert_gt(frac, 0.003, "Es muss Flüsse geben.")
	assert_lt(frac, 0.25, "Flüsse dürfen nicht die halbe Welt fluten.")

func test_river_does_not_cut_into_hills() -> void:
	var cfg := TerrainConfig.new()
	var layer := TerrainRiverLayer.new(cfg, 1337)
	var h_high: float = cfg.river_max_height + cfg.river_fade_range + 1.0
	for i in 400:
		var x := float(i % 20) * 41.0 - 400.0
		var z := float(i / 20) * 37.0 - 400.0
		assert_eq(layer.apply(x, z, h_high), h_high, "Hügel bleiben unberührt (Fluss läuft aus).")

func test_river_bed_reaches_river_depth_below_local_ground() -> void:
	# BUGFIX (2026-09-20, "Wasser/Flüsse & Seen sind alle auf einer Ebene"): das Bett liegt
	# jetzt RELATIV zum lokalen Gelände (h - river_depth), nicht mehr auf einer festen
	# absoluten Höhe (water_level - river_depth). Ein Fluss durch h=2.4 schneidet also bis
	# ~1.2 (2.4 - river_depth), nicht bis unter den globalen Meeresspiegel.
	var cfg := TerrainConfig.new()
	var layer := TerrainRiverLayer.new(cfg, 1337)
	var h: float = 2.4
	var lowest := 100.0
	for iz in 200:
		for ix in 200:
			lowest = minf(lowest, layer.apply(float(ix) * 20.0, float(iz) * 20.0, h))
	assert_almost_eq(lowest, h - cfg.river_depth, 0.01, "Volle Flussbett-Tiefe muss erreicht werden.")

func test_river_follows_local_terrain_instead_of_one_global_level() -> void:
	# Kern des BUGFIX: ein Fluss durch höheres Gelände muss auch höher liegen als einer im
	# Tiefland — vorher landeten beide auf exakt derselben absoluten Höhe.
	var cfg := TerrainConfig.new()
	var layer := TerrainRiverLayer.new(cfg, 1337)
	var lowland: float = layer.apply(500.0, 500.0, 0.5)
	var upland: float = layer.apply(500.0, 500.0, 3.5)
	assert_almost_eq(lowland, 0.5 - cfg.river_depth, 0.01)
	assert_almost_eq(upland, 3.5 - cfg.river_depth, 0.01)
	assert_gt(upland, lowland, "Fluss im höheren Gelände muss höher liegen als im Tiefland.")

func test_river_water_target_matches_bank_height_only_inside_the_river() -> void:
	var cfg := TerrainConfig.new()
	var layer := TerrainRiverLayer.new(cfg, 1337)
	# Irgendwo weit weg von jedem Fluss (river_search_band-Vorfilter greift sofort): NAN.
	assert_true(is_nan(layer.get_water_target_at(999999.0, 999999.0, 2.0)))
	# Direkt am Fluss (dieselbe Stelle, an der apply() auch tatsächlich einschneidet):
	# das Ziel muss die uneingeschnittene Höhe sein, nicht der globale Wasserspiegel.
	for iz in 200:
		for ix in 200:
			var x := float(ix) * 20.0
			var z := float(iz) * 20.0
			var h: float = 2.4
			if layer.apply(x, z, h) < h - 0.01:
				assert_almost_eq(layer.get_water_target_at(x, z, h), h, 0.0001)
				return
	fail_test("Kein Flusspunkt im Suchraster gefunden — Testdaten prüfen.")

# ── Statistik der Gesamtwelt (großzügige Grenzen, gegen grobe Fehlabstimmung) ──

func test_world_has_water_hills_and_mostly_land_for_multiple_seeds() -> void:
	for s in SEEDS:
		var f := TerrainField.new(null, s)
		var water := 0
		var hills := 0
		var total := 0
		for iz in 60:
			for ix in 60:
				total += 1
				var h := f.get_height_at(float(ix) * 160.0 - 4800.0, float(iz) * 160.0 - 4800.0)
				if h < 0.0:
					water += 1
				if h > 5.0:
					hills += 1
		var water_frac := float(water) / float(total)
		var hill_frac := float(hills) / float(total)
		assert_gt(water_frac, 0.02, "seed %d: kaum Wasser (%.1f%%)" % [s, water_frac * 100.0])
		assert_lt(water_frac, 0.40, "seed %d: zu viel Wasser (%.1f%%)" % [s, water_frac * 100.0])
		assert_gt(hill_frac, 0.03, "seed %d: kaum Hügel (%.1f%%)" % [s, hill_frac * 100.0])
		assert_lt(hill_frac, 0.50, "seed %d: zu viel Hügel (%.1f%%)" % [s, hill_frac * 100.0])

func test_terrain_has_no_cliffs() -> void:
	# Kein (fast) senkrechter Höhensprung auf 1 m Distanz — auch nicht an Flussufern und im
	# Übergang zum Spawn-Plateau. (Der alte Fluss/See hatte pro Chunk harte Kanten.)
	for s in SEEDS:
		var f := TerrainField.new(null, s)
		for i in 400:
			var x := float(i % 20) * 233.0 - 2300.0
			var z := float(i / 20) * 197.0 - 2000.0
			assert_lt(absf(f.get_height_at(x + 1.0, z) - f.get_height_at(x, z)), 2.5)
			assert_lt(absf(f.get_height_at(x, z + 1.0) - f.get_height_at(x, z)), 2.5)

# ── Edit-Schicht ────────────────────────────────

func test_edit_layer_changes_height_but_not_base() -> void:
	var f := TerrainField.new(null, 1337)
	var layer := TerrainEditLayer.new()
	layer.set_delta(Vector2i(50, 50), -1.5)   # Weltposition (100, 100)
	var before := f.get_height_at(100.0, 100.0)
	f.set_edit_layer(layer)
	assert_almost_eq(f.get_height_at(100.0, 100.0), before - 1.5, 0.0001)
	assert_almost_eq(f.get_base_height_at(100.0, 100.0), before, 0.0001)

func test_field_without_edit_layer_equals_base() -> void:
	var f := TerrainField.new(null, 1337)
	assert_eq(f.get_height_at(321.0, -123.0), f.get_base_height_at(321.0, -123.0))

func test_edit_layer_can_be_replaced_and_removed() -> void:
	var f := TerrainField.new(null, 1337)
	var layer := TerrainEditLayer.new()
	layer.set_delta(Vector2i(50, 50), 2.0)
	f.set_edit_layer(layer)
	assert_same(f.get_edit_layer(), layer)
	f.set_edit_layer(null)
	assert_eq(f.get_height_at(100.0, 100.0), f.get_base_height_at(100.0, 100.0))

# ── Wasser ──────────────────────────────────────

func _field_with(fn: Callable) -> FuncField:
	var f := FuncField.new()
	f.fn = fn
	return f

func test_water_is_where_terrain_is_below_water_level() -> void:
	var low := _field_with(func(_x: float, _z: float) -> float: return -1.0)
	var high := _field_with(func(_x: float, _z: float) -> float: return 3.0)
	assert_true(low.is_water_at(0, 0))
	assert_false(high.is_water_at(0, 0))

func test_water_depth() -> void:
	var f := _field_with(func(_x: float, _z: float) -> float: return -1.5)
	assert_almost_eq(f.get_water_depth_at(0, 0), 1.5, 0.0001)
	var dry := _field_with(func(_x: float, _z: float) -> float: return 2.0)
	assert_eq(dry.get_water_depth_at(0, 0), 0.0)

func test_water_level_comes_from_config() -> void:
	var cfg := TerrainConfig.new()
	cfg.water_level = 3.0
	var f := TerrainField.new(cfg, 1)
	assert_eq(f.get_water_level(), 3.0)

func test_water_level_at_matches_global_level_away_from_rivers() -> void:
	# Weitab von jedem Fluss (river_search_band-Vorfilter) muss der lokale Spiegel exakt dem
	# globalen entsprechen — das "beim Buddeln irgendwann auf Wasser stoßen" bleibt gleich.
	var f := TerrainField.new(null, 1337)
	assert_eq(f.get_water_level_at(999999.0, 999999.0), f.get_water_level())

func test_water_level_at_follows_river_terrain_not_one_flat_plane() -> void:
	# BUGFIX (2026-09-20, "Wasser/Flüsse & Seen sind alle auf einer Ebene"): innerhalb eines
	# echten Flusslaufs muss der Spiegel dem umgebenden (uneingeschnittenen) Gelände folgen —
	# nicht überall exakt derselbe globale Wert sein.
	var f := TerrainField.new(null, 1337)
	var differs := false
	for iz in 300:
		for ix in 300:
			var x := float(ix) * 15.0 - 2250.0
			var z := float(iz) * 15.0 - 2250.0
			if not is_equal_approx(f.get_water_level_at(x, z), f.get_water_level()):
				differs = true
				break
		if differs:
			break
	assert_true(differs, "Es muss Flussstellen geben, an denen der Spiegel vom globalen abweicht.")

func test_digging_away_from_rivers_still_floods_at_the_global_level() -> void:
	# Der Kern-Punkt aus dem BUGFIX-Kommentar: das gegrabene Loch abseits von Flüssen wird
	# NICHT sein eigener kleiner See auf der ursprünglichen Geländehöhe — es flutet weiterhin
	# beim globalen Spiegel, wie vorher.
	var f := TerrainField.new(null, 1337)
	var layer := TerrainEditLayer.new()
	f.set_edit_layer(layer)
	# Eine Stelle weit weg von jedem Fluss suchen, dort ein tiefes Loch graben.
	var x := 999999.0
	var z := 999999.0
	var natural_h: float = f.get_base_height_at(x, z)
	layer.set_delta(TerrainEditLayer.world_to_lattice(Vector2(x, z)), f.get_water_level() - 1.0 - natural_h)
	assert_true(f.is_water_at(x, z), "Tief genug gegraben → muss geflutet sein.")
	assert_almost_eq(f.get_water_level_at(x, z), f.get_water_level(), 0.0001,
		"Spiegel darf sich nicht auf die (ungegrabene) natürliche Höhe dieser Stelle verschieben.")

# ── Steigung ────────────────────────────────────

func test_slope_flat_and_tilted() -> void:
	var flat := _field_with(func(_x: float, _z: float) -> float: return 4.0)
	assert_almost_eq(flat.get_slope_at(10, 10), 0.0, 0.001)
	var ramp := _field_with(func(x: float, _z: float) -> float: return x)   # 1 m Anstieg pro m → 45°
	assert_almost_eq(ramp.get_slope_at(10, 10), 45.0, 0.01)

# ── Klima / Biome ───────────────────────────────

func test_climate_is_bounded_and_resolves_to_a_biome() -> void:
	var f := TerrainField.new(null, 1337)
	for i in 100:
		var c := f.get_climate_at(float(i) * 311.0 - 15000.0, float(i) * 173.0 - 9000.0)
		assert_true(c.x >= -1.0 and c.x <= 1.0 and c.y >= -1.0 and c.y <= 1.0)
		assert_not_null(f.get_biome_at(float(i) * 311.0, float(i) * 173.0))
		assert_false(f.get_biome_id_at(float(i) * 311.0, float(i) * 173.0).is_empty())

func test_climate_differs_between_seeds() -> void:
	var a := TerrainField.new(null, 1)
	var b := TerrainField.new(null, 2)
	var differs := false
	for i in 30:
		if a.get_climate_at(i * 500.0, i * 300.0) != b.get_climate_at(i * 500.0, i * 300.0):
			differs = true
			break
	assert_true(differs)

func test_all_biomes_occur_somewhere_in_the_world() -> void:
	# Regressionsschutz für "ich habe noch nie eine Wüste / Eislandschaft gesehen":
	# in einer 20-km-Weltscheibe müssen Wüste UND Winter vorkommen.
	var f := TerrainField.new(null, 1337)
	var seen: Dictionary = {}
	for iz in 80:
		for ix in 80:
			seen[f.get_biome_id_at(float(ix) * 250.0 - 10000.0, float(iz) * 250.0 - 10000.0)] = true
	assert_true(seen.has("desert"), "Keine Wüste in 20 km × 20 km")
	assert_true(seen.has("winter"), "Kein Eis in 20 km × 20 km")
