# res://tests/unit/test_animal_visual_builder.gd
extends GutTest

## Unit-Tests für AnimalVisualBuilder.build() (stateless, statische Geometrie-Fabrik).
##
## Seit der Umstellung auf AnimalVisualProfile (Wunsch "Tiere sollen besser aussehen,
## gemeinsame Basis statt alles neu erfinden") ist die Geometrie deutlich reicher als
## vorher (Augen/Schnauze/Ohren/Schwanz statt nur Kapsel+Kugel+4 Beine) — die Tests unten
## prüfen weiterhin alles, was von Hand exakt nachrechenbar ist (Beine, Rumpf, Schädel —
## reine Multiplikationen von body_size-Komponenten, siehe AnimalVisualBuilder-Konstanten),
## und für die restlichen Gesichts-/Schwanzmerkmale (über ProcGenShapes.spike() platziert,
## keine einfachen Multiplikationen mehr) nur noch STRUKTURELLE Invarianten (Kind mit
## erwartetem Namen/Mesh-Typ/Material existiert) statt exakter Positionswerte.

const COLOR := Color(0.4, 0.5, 0.6, 1.0)
const BODY_SIZE := Vector3(2.0, 3.0, 1.0)  # radius=1.0, Höhe=3.0, Tiefe=1.0

var _root: Node3D
var _profile: AnimalVisualProfile


func before_each() -> void:
	# Default-Profil == AnimalBase-Defaults (ROUND/STUB/SHORT/NONE), siehe dortige Felder.
	_profile = AnimalVisualProfile.new(COLOR, BODY_SIZE)
	_root = AnimalVisualBuilder.build(_profile)
	add_child_autofree(_root)


func after_each() -> void:
	_root = null
	_profile = null


func _find(node_name: String) -> Node:
	return _root.find_child(node_name, true, false)


func test_root_is_named_visuals() -> void:
	assert_eq(_root.name, "Visuals")


# ─────────────────────────────────────────────
# Beine — reine Multiplikation von body_size, exakt nachrechenbar
# ─────────────────────────────────────────────

func test_all_four_legs_are_cylinders_with_correct_dimensions() -> void:
	for leg_name in ["LegFL", "LegFR", "LegBL", "LegBR"]:
		var lmi: MeshInstance3D = _find(leg_name)
		assert_not_null(lmi, "Bein '%s' fehlt" % leg_name)
		assert_true(lmi.mesh is CylinderMesh, leg_name)
		var cyl: CylinderMesh = lmi.mesh
		assert_almost_eq(cyl.top_radius, 0.17, 0.0001, "body_size.x*0.085, %s" % leg_name)
		assert_almost_eq(cyl.bottom_radius, 0.13, 0.0001, "body_size.x*0.065, %s" % leg_name)
		assert_almost_eq(cyl.height, 1.65, 0.0001, "body_size.y*0.55, %s" % leg_name)

func test_all_four_legs_use_darkened_body_color() -> void:
	for leg_name in ["LegFL", "LegFR", "LegBL", "LegBR"]:
		var lmi: MeshInstance3D = _find(leg_name)
		var mat: StandardMaterial3D = lmi.material_override
		assert_eq(mat.albedo_color, COLOR.darkened(0.2), leg_name)

func test_leg_positions_are_at_four_corners() -> void:
	# offset = (±body_size.x*0.3=±0.6, body_size.y*0.27=0.81, ±body_size.z*0.22=±0.22)
	var expected := {
		"LegFL": Vector3(-0.6, 0.81, -0.22),
		"LegFR": Vector3(0.6, 0.81, -0.22),
		"LegBL": Vector3(-0.6, 0.81, 0.22),
		"LegBR": Vector3(0.6, 0.81, 0.22),
	}
	for leg_name: String in expected:
		var lmi: MeshInstance3D = _find(leg_name)
		assert_eq(lmi.position, expected[leg_name], leg_name)


# ─────────────────────────────────────────────
# Rumpf — liegende Kapsel (90°-Drehung), exakt nachrechenbar
# ─────────────────────────────────────────────

func test_body_is_capsule_with_correct_dimensions() -> void:
	var bmi: MeshInstance3D = _find("Body")
	assert_not_null(bmi)
	assert_true(bmi.mesh is CapsuleMesh)
	var cm: CapsuleMesh = bmi.mesh
	assert_almost_eq(cm.radius, 0.84, 0.0001, "body_size.x*0.42")
	assert_almost_eq(cm.height, 2.2, 0.0001, "max(body_size.z*2.2, radius*2+0.1)")

func test_body_lies_horizontally_and_is_vertically_squashed() -> void:
	var bmi: MeshInstance3D = _find("Body")
	assert_almost_eq(bmi.rotation.x, PI * 0.5, 0.0001, "Rumpf liegt (Länge entlang Z statt Y)")
	assert_almost_eq(bmi.scale.z, 0.82, 0.0001, "BODY_VERTICAL_SQUASH")

func test_body_position_and_color() -> void:
	var bmi: MeshInstance3D = _find("Body")
	# leg_top=3.0*0.545=1.635; +radius(0.84)*0.82*0.85=0.58548 -> 2.22048
	assert_almost_eq(bmi.position.y, 2.22048, 0.001, "body_center_y")
	var mat: StandardMaterial3D = bmi.material_override
	assert_eq(mat.albedo_color, COLOR)


# ─────────────────────────────────────────────
# Kopf — Kugel, exakt nachrechenbar; Gesichtsmerkmale nur strukturell geprüft
# ─────────────────────────────────────────────

func test_head_group_exists_at_expected_position() -> void:
	var head: Node3D = _find("Head")
	assert_not_null(head)
	# body_center_y(2.22048) + head_r(0.8)*0.35 = 2.50048; body_length(2.2)*0.5 - head_r*0.2 = 0.94
	assert_almost_eq(head.position.y, 2.50048, 0.001, "head_y")
	assert_almost_eq(head.position.z, 0.94, 0.0001, "head_z")

func test_skull_is_sphere_with_correct_radius_and_lightened_color() -> void:
	var head: Node3D = _find("Head")
	var skull: MeshInstance3D = head.get_node("Skull")
	assert_true(skull.mesh is SphereMesh)
	var sm: SphereMesh = skull.mesh
	assert_almost_eq(sm.radius, 0.8, 0.0001, "body_size.x*0.40")
	var mat: StandardMaterial3D = skull.material_override
	assert_eq(mat.albedo_color, COLOR.lightened(0.1))

func test_eyes_exist_as_dark_spheres() -> void:
	for eye_name in ["EyeR", "EyeL"]:
		var eye: MeshInstance3D = _find(eye_name)
		assert_not_null(eye, eye_name)
		assert_true(eye.mesh is SphereMesh, eye_name)

func test_default_profile_has_round_ears() -> void:
	for ear_name in ["EarR", "EarL"]:
		var ear: MeshInstance3D = _find(ear_name)
		assert_not_null(ear, ear_name)
		assert_true(ear.mesh is SphereMesh, "EarStyle.ROUND -> Kugel, %s" % ear_name)

func test_default_profile_has_short_snout_nose() -> void:
	var nose: MeshInstance3D = _find("Nose")
	assert_not_null(nose)
	assert_true(nose.mesh is SphereMesh)

func test_default_profile_has_no_headgear() -> void:
	assert_null(_find("AntlerR"), "HeadgearStyle.NONE -> kein Geweih")
	assert_null(_find("TuskR"), "HeadgearStyle.NONE -> keine Hauer")


# ─────────────────────────────────────────────
# Schwanz — abhängig vom TailStyle
# ─────────────────────────────────────────────

func test_default_profile_has_stub_tail() -> void:
	var tail: MeshInstance3D = _find("Tail")
	assert_not_null(tail)
	assert_true(tail.mesh is CapsuleMesh, "TailStyle.STUB -> Kapsel")

func test_tail_style_none_produces_no_tail_node() -> void:
	var profile := AnimalVisualProfile.new(COLOR, BODY_SIZE)
	profile.tail_style = AnimalVisualProfile.TailStyle.NONE
	var root := AnimalVisualBuilder.build(profile)
	add_child_autofree(root)
	assert_null(root.find_child("Tail", true, false))

func test_fluffy_tail_is_a_sphere_ignoring_body_color() -> void:
	var profile := AnimalVisualProfile.new(COLOR, BODY_SIZE)
	profile.tail_style = AnimalVisualProfile.TailStyle.FLUFFY
	var root := AnimalVisualBuilder.build(profile)
	add_child_autofree(root)
	var tail: MeshInstance3D = root.find_child("Tail", true, false)
	assert_true(tail.mesh is SphereMesh)
	var mat: StandardMaterial3D = tail.material_override
	assert_ne(mat.albedo_color, COLOR, "Puschelschwanz ist absichtlich naturfarben, nicht fellfarbig")


# ─────────────────────────────────────────────
# Kopfschmuck — abhängig vom HeadgearStyle
# ─────────────────────────────────────────────

func test_antlers_produce_four_pieces_per_side_group() -> void:
	var profile := AnimalVisualProfile.new(COLOR, BODY_SIZE)
	profile.headgear_style = AnimalVisualProfile.HeadgearStyle.ANTLERS
	var root := AnimalVisualBuilder.build(profile)
	add_child_autofree(root)
	for n in ["AntlerR", "AntlerL", "AntlerRTine", "AntlerLTine"]:
		assert_not_null(root.find_child(n, true, false), n)

func test_tusks_produce_two_cream_colored_cones() -> void:
	var profile := AnimalVisualProfile.new(COLOR, BODY_SIZE)
	profile.headgear_style = AnimalVisualProfile.HeadgearStyle.TUSKS
	var root := AnimalVisualBuilder.build(profile)
	add_child_autofree(root)
	for n in ["TuskR", "TuskL"]:
		var tusk: MeshInstance3D = root.find_child(n, true, false)
		assert_not_null(tusk, n)
		assert_true(tusk.mesh is CylinderMesh, "Kegel = CylinderMesh mit top_radius 0")
		var mat: StandardMaterial3D = tusk.material_override
		assert_ne(mat.albedo_color, COLOR, "Hauer sind absichtlich elfenbeinfarben, nicht fellfarbig")


# ─────────────────────────────────────────────
# Statelessness
# ─────────────────────────────────────────────

func test_repeated_build_calls_are_independent() -> void:
	var root2 := AnimalVisualBuilder.build(AnimalVisualProfile.new(COLOR, BODY_SIZE))
	add_child_autofree(root2)
	assert_ne(_root, root2)
	assert_not_null(root2.find_child("Body", true, false))
