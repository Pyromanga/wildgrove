# res://tests/unit/test_animal_visual_builder.gd
extends GutTest

## Unit-Tests für AnimalVisualBuilder.build() (stateless, statische
## Geometrie-Fabrik — Kapsel-Körper + Kugelkopf + 4 Zylinder-Beine).
##
## Für color.lightened()/color.darkened() wird NICHT die Ziel-Farbe von Hand
## nachgerechnet (Risiko einer falschen Formel-Annahme) — stattdessen ruft
## der Test dieselbe Godot-eigene Methode mit demselben Parameter auf und
## vergleicht. Das prüft exakt das, was der Quellcode behauptet (welcher
## Amount-Wert verwendet wird), ohne die Farbmathematik selbst zu duplizieren.
## Alle Positions-/Radius-/Höhen-Werte sind reine Multiplikationen von
## body_size-Komponenten -> von Hand exakt nachrechenbar, in Python
## gegengeprüft (siehe Kommentare bei den einzelnen Tests).

const COLOR := Color(0.4, 0.5, 0.6, 1.0)
const BODY_SIZE := Vector3(2.0, 3.0, 1.0)  # radius=1.0, Höhe=3.0, Tiefe=1.0

var _root: Node3D


func before_each() -> void:
	_root = AnimalVisualBuilder.build(COLOR, BODY_SIZE)
	add_child_autofree(_root)


func after_each() -> void:
	_root = null


func test_root_is_named_visuals() -> void:
	assert_eq(_root.name, "Visuals")

func test_root_has_six_children() -> void:
	# 1 Körper + 1 Kopf + 4 Beine
	assert_eq(_root.get_child_count(), 6)


# ─────────────────────────────────────────────
# Körper (Kind 0)
# ─────────────────────────────────────────────

func test_body_mesh_is_capsule_with_correct_dimensions() -> void:
	var bmi: MeshInstance3D = _root.get_child(0)
	assert_true(bmi.mesh is CapsuleMesh)
	var cm: CapsuleMesh = bmi.mesh
	assert_almost_eq(cm.radius, 1.0, 0.0001, "body_size.x*0.5 = 2.0*0.5")
	assert_almost_eq(cm.height, 3.0, 0.0001, "body_size.y")

func test_body_position_and_color() -> void:
	var bmi: MeshInstance3D = _root.get_child(0)
	assert_almost_eq(bmi.position.y, 1.5, 0.0001, "body_size.y*0.5")
	var mat: StandardMaterial3D = bmi.material_override
	assert_eq(mat.albedo_color, COLOR)


# ─────────────────────────────────────────────
# Kopf (Kind 1)
# ─────────────────────────────────────────────

func test_head_mesh_is_sphere_with_correct_dimensions() -> void:
	var hmi: MeshInstance3D = _root.get_child(1)
	assert_true(hmi.mesh is SphereMesh)
	var sm: SphereMesh = hmi.mesh
	assert_almost_eq(sm.radius, 0.7, 0.0001, "body_size.x*0.35 = 2.0*0.35")
	assert_almost_eq(sm.height, 1.4, 0.0001, "body_size.x*0.7 = 2.0*0.7")

func test_head_position() -> void:
	var hmi: MeshInstance3D = _root.get_child(1)
	# Vector3(0, body_size.y*1.05=3.15, body_size.x*0.25=0.5)
	assert_eq(hmi.position, Vector3(0.0, 3.15, 0.5))

func test_head_color_is_lightened_body_color() -> void:
	var hmi: MeshInstance3D = _root.get_child(1)
	var mat: StandardMaterial3D = hmi.material_override
	assert_eq(mat.albedo_color, COLOR.lightened(0.1))


# ─────────────────────────────────────────────
# Beine (Kinder 2..5)
# ─────────────────────────────────────────────

func test_all_four_legs_are_cylinders_with_correct_dimensions() -> void:
	for i in range(2, 6):
		var lmi: MeshInstance3D = _root.get_child(i)
		assert_true(lmi.mesh is CylinderMesh, "Kind %d" % i)
		var cyl: CylinderMesh = lmi.mesh
		assert_almost_eq(cyl.top_radius, 0.16, 0.0001, "body_size.x*0.08 = 2.0*0.08, Kind %d" % i)
		assert_almost_eq(cyl.bottom_radius, 0.16, 0.0001, "Kind %d" % i)
		assert_almost_eq(cyl.height, 1.65, 0.0001, "body_size.y*0.55 = 3.0*0.55, Kind %d" % i)

func test_all_four_legs_use_darkened_body_color() -> void:
	for i in range(2, 6):
		var lmi: MeshInstance3D = _root.get_child(i)
		var mat: StandardMaterial3D = lmi.material_override
		assert_eq(mat.albedo_color, COLOR.darkened(0.2), "Kind %d" % i)

func test_leg_positions_are_at_four_corners() -> void:
	# offset = (±body_size.x*0.3=±0.6, 0, ±body_size.z*0.2=±0.2) + (0, body_size.y*0.27=0.81, 0)
	var expected := [
		Vector3(-0.6, 0.81, -0.2),
		Vector3(0.6, 0.81, -0.2),
		Vector3(-0.6, 0.81, 0.2),
		Vector3(0.6, 0.81, 0.2),
	]
	for i in range(4):
		var lmi: MeshInstance3D = _root.get_child(2 + i)
		assert_eq(lmi.position, expected[i], "Bein #%d" % i)


# ─────────────────────────────────────────────
# Statelessness
# ─────────────────────────────────────────────

func test_repeated_build_calls_are_independent() -> void:
	var root2 := AnimalVisualBuilder.build(COLOR, BODY_SIZE)
	add_child_autofree(root2)
	assert_ne(_root, root2)
	assert_eq(root2.get_child_count(), 6)
