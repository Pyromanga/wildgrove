# res://tests/unit/test_world_save_handler.gd
extends GutTest

## Unit-Tests für WorldSaveHandler (E-02 — WorldService save/load).
##
## Strategie: WorldSaveHandler ist eine RefCounted-Hilfsklasse ohne SceneTree-Abhängigkeit.
## WorldData und WorldTimeService direkt instanziiert — beide sind RefCounted.
## Kein Node, kein Logger-Problem, kein EventBus.
##
## Abgedeckt:
##   - get_save_data(): Struktur der serialisierten Keys
##   - get_save_data(): Baum-Positionen serialisiert
##   - get_save_data(): Erz-Positionen serialisiert
##   - get_save_data(): Spieler-Position
##   - get_save_data(): Tageszeit und Tagzähler
##   - restore_world(): Bäume wiederhergestellt
##   - restore_world(): Erze wiederhergestellt
##   - restore_world(): Spieler-Position wiederhergestellt
##   - restore_world(): Tageszeit und Tagzähler wiederhergestellt
##   - restore_world(): Harvested-Objects wiederhergestellt
##   - Save-Round-Trip: get_save_data → restore_world → gleicher State

var _data:    WorldData
var _time:    WorldTimeService
var _handler: WorldSaveHandler

const POS_TREE_1 := Vector3(10, 0, 20)
const POS_TREE_2 := Vector3(30, 0, 40)
const POS_ORE_1  := Vector3(-5, 0, 15)
const POS_PLAYER := Vector3(7, 0, 3)

func before_each() -> void:
	_data    = WorldData.new()
	_time    = WorldTimeService.new()
	_handler = WorldSaveHandler.new(_data, _time)

func after_each() -> void:
	_handler = null
	_time    = null
	_data    = null

# ─────────────────────────────────────────────────────────────────────────────
# get_save_data — Struktur
# ─────────────────────────────────────────────────────────────────────────────

func test_save_data_has_required_keys() -> void:
	var sd := _handler.get_save_data()
	assert_true(sd.has("day_time"),       "day_time muss im Snapshot sein")
	assert_true(sd.has("day_count"),      "day_count muss im Snapshot sein")
	assert_true(sd.has("tree_positions"), "tree_positions muss im Snapshot sein")
	assert_true(sd.has("ore_positions"),  "ore_positions muss im Snapshot sein")
	assert_true(sd.has("player_pos"),     "player_pos muss im Snapshot sein")
	assert_true(sd.has("harvested"),      "harvested muss im Snapshot sein")

func test_save_data_serializes_trees() -> void:
	_data.add_tree(POS_TREE_1)
	_data.add_tree(POS_TREE_2)
	var sd := _handler.get_save_data()
	var trees := sd["tree_positions"] as Array
	assert_eq(trees.size(), 2, "Zwei Bäume müssen serialisiert sein")

func test_save_data_serializes_player_position() -> void:
	_data.player_position = POS_PLAYER
	var sd := _handler.get_save_data()
	var restored := str_to_var(sd["player_pos"] as String)
	assert_true(restored is Vector3, "player_pos muss als Vector3 deserialisierbar sein")
	assert_almost_eq((restored as Vector3).x, POS_PLAYER.x, 0.01, "X-Koordinate muss übereinstimmen")

func test_save_data_includes_day_time() -> void:
	_time.day_time  = 14.5
	_time.day_count = 3
	var sd := _handler.get_save_data()
	assert_almost_eq(sd["day_time"]  as float, 14.5, 0.01, "day_time muss 14.5 sein")
	assert_eq(        sd["day_count"] as int,   3,          "day_count muss 3 sein")

# ─────────────────────────────────────────────────────────────────────────────
# restore_world
# ─────────────────────────────────────────────────────────────────────────────

func test_restore_trees() -> void:
	_data.add_tree(POS_TREE_1)
	_data.add_tree(POS_TREE_2)
	var snapshot := _handler.get_save_data()

	# Neue Instanzen
	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	assert_eq(data2.tree_positions.size(), 2, "Zwei Bäume müssen wiederhergestellt sein")

func test_restore_ores() -> void:
	_data.add_ore(POS_ORE_1)
	var snapshot := _handler.get_save_data()

	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	assert_eq(data2.ore_positions.size(), 1, "Ein Erz muss wiederhergestellt sein")

func test_restore_player_position() -> void:
	_data.player_position = POS_PLAYER
	var snapshot := _handler.get_save_data()

	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	assert_almost_eq(data2.player_position.x, POS_PLAYER.x, 0.01, "X-Koordinate muss passen")
	assert_almost_eq(data2.player_position.z, POS_PLAYER.z, 0.01, "Z-Koordinate muss passen")

func test_restore_day_time() -> void:
	_time.day_time  = 18.0
	_time.day_count = 7
	var snapshot := _handler.get_save_data()

	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	assert_almost_eq(time2.day_time,  18.0, 0.01, "Tageszeit muss 18.0 sein")
	assert_eq(        time2.day_count, 7,          "Tagzähler muss 7 sein")

# ─────────────────────────────────────────────────────────────────────────────
# Save-Round-Trip (A-04)
# ─────────────────────────────────────────────────────────────────────────────

## Save-Round-Trip mit neuem Key-Pfad (P0-Fix):
## mark_harvested via WorldData.make_key() — der Pfad den HarvestableEntity.on_despawn() geht.
## Stellt sicher dass der neue API-Pfad bei Save/Load korrekt round-trippt.
func test_round_trip_new_key_path_oak_tree() -> void:
	_data.add_tree(POS_TREE_1)
	# Neuer Pfad: WorldService.mark_harvested() → WorldData.mark_harvested(make_key(...))
	_data.mark_harvested(WorldData.make_key("oak_tree", POS_TREE_1))

	var snapshot := _handler.get_save_data()

	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	# Nach Restore: is_harvested_by_type() muss den Key finden (nicht is_tree_harvested,
	# das wäre trivial — wir testen is_harvested_by_type direkt).
	assert_true(
		data2.is_harvested_by_type("oak_tree", POS_TREE_1),
		"P0: is_harvested_by_type('oak_tree') muss nach Round-Trip via make_key() True sein"
	)

func test_round_trip_new_key_path_copper_ore() -> void:
	## Neuer Typ (copper_ore) der vorher gar nicht getestet wurde.
	var pos := Vector3(-2, 0, 8)
	_data.add_ore(pos)
	_data.mark_harvested(WorldData.make_key("copper_ore", pos))

	var snapshot := _handler.get_save_data()

	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	assert_true(
		data2.is_harvested_by_type("copper_ore", pos),
		"P0: copper_ore-Key muss nach Round-Trip via make_key() in is_harvested_by_type() gefunden werden"
	)

func test_round_trip_make_key_and_legacy_dont_alias() -> void:
	## Stellt sicher dass make_key("oak_tree", pos) und der alte "tree_x_y_z"-Key
	## nicht dieselbe Entry sind — sonst wäre das ein stiller false-positive.
	var data2 := WorldData.new()
	var pos   := Vector3(5, 0, 5)
	data2.mark_harvested(WorldData.make_key("oak_tree", pos))
	# Der alte Key war "tree_5_0_5" — der neue ist "oak_tree_5_0_5"
	assert_false(
		data2.harvested_objects.has("tree_5_0_5"),
		"Neues Key-Schema darf den alten 'tree_x_y_z'-Schlüssel nicht setzen (kein Alias)"
	)
	assert_true(
		data2.harvested_objects.has("oak_tree_5_0_5"),
		"Neues Key-Schema muss 'oak_tree_5_0_5' schreiben"
	)

func test_round_trip_full_state_after_restore() -> void:
	# Phase 1: State befüllen
	_data.add_tree(POS_TREE_1)
	_data.add_tree(POS_TREE_2)
	_data.add_ore(POS_ORE_1)
	_data.player_position = POS_PLAYER
	_data.mark_tree_harvested(POS_TREE_1)
	_time.day_time  = 12.0
	_time.day_count = 5

	var snapshot := _handler.get_save_data()

	# Phase 2: neue Instanzen + Restore
	var data2 := WorldData.new()
	var time2 := WorldTimeService.new()
	var h2    := WorldSaveHandler.new(data2, time2)
	h2.restore_world(snapshot)

	assert_eq(data2.tree_positions.size(), 2,    "2 Bäume nach Round-Trip")
	assert_eq(data2.ore_positions.size(),  1,    "1 Erz nach Round-Trip")
	assert_almost_eq(time2.day_time,       12.0, 0.01, "Tageszeit 12.0 nach Round-Trip")
	assert_eq(time2.day_count,             5,    "Tagzähler 5 nach Round-Trip")
	assert_true(data2.is_tree_harvested(POS_TREE_1), "Geernteter Baum muss nach Round-Trip markiert sein")
