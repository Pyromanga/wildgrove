# res://tests/unit/test_terrain_chunk_builder.gd
extends GutTest

## Tests für TerrainChunkBuilder + TerrainWaterBuilder: aus dem TerrainField werden die Nodes
## eines Chunks. Schwerpunkt: Nahtlosigkeit (gleiche Weltkoordinate → gleiche Höhe), Wasser
## nur wo nötig, Neubau ohne Duplikate.

## Höhenfeld mit beliebiger Funktion.
class FuncField extends TerrainField:
	var fn: Callable
	func get_height_at(x: float, z: float) -> float:
		return float(fn.call(x, z))

var _builder: TerrainChunkBuilder
var _field: TerrainField

func before_each() -> void:
	_field = TerrainField.new(null, 1337)
	_builder = TerrainChunkBuilder.new(_field)

func _flat_field(h: float) -> FuncField:
	var f := FuncField.new()
	f.fn = func(_x: float, _z: float) -> float: return h
	return f

func _make_chunk(coord: Vector2i) -> Node3D:
	var n := Node3D.new()
	var c := _builder.get_chunk_center(coord)
	n.position = Vector3(c.x, 0.0, c.y)
	autofree(n)
	return n

# ── Koordinaten ─────────────────────────────────

func test_chunk_center_is_coord_times_size() -> void:
	var size := _field.get_config().chunk_size
	assert_eq(_builder.get_chunk_center(Vector2i(2, -3)), Vector2(2.0 * size, -3.0 * size))

func test_chunk_at_roundtrip_and_negative() -> void:
	for coord in [Vector2i(0, 0), Vector2i(3, -2), Vector2i(-5, 7)]:
		var c := _builder.get_chunk_center(coord)
		assert_eq(_builder.get_chunk_at(c.x, c.y), coord)
	assert_eq(_builder.get_chunk_at(-70.0, 5.0), Vector2i(-1, 0))

# ── Höhen ───────────────────────────────────────

func test_sample_heights_has_full_grid() -> void:
	var res := _field.get_config().get_resolution()
	assert_eq(_builder.sample_heights(Vector2.ZERO).size(), (res + 1) * (res + 1))

func test_heights_equal_field_at_vertices() -> void:
	var cfg := _field.get_config()
	var center := _builder.get_chunk_center(Vector2i(2, 1))
	var heights := _builder.sample_heights(center)
	var n := cfg.get_resolution() + 1
	var step := cfg.get_vertex_spacing()
	for z_i in [0, 5, 16, 32]:
		for x_i in [0, 7, 20, 32]:
			var wx := center.x - cfg.chunk_size * 0.5 + float(x_i) * step
			var wz := center.y - cfg.chunk_size * 0.5 + float(z_i) * step
			assert_almost_eq(heights[z_i * n + x_i], _field.get_height_at(wx, wz), 0.0001)

func test_neighbor_chunks_share_border_vertices_exactly() -> void:
	# DER Nahtgarantie: rechte Spalte von Chunk (0,0) == linke Spalte von Chunk (1,0),
	# untere Zeile von (0,0) == obere Zeile von (0,1). Bit-genau, nicht nur ungefähr.
	var n := _field.get_config().get_resolution() + 1
	var a := _builder.sample_heights(_builder.get_chunk_center(Vector2i(0, 0)))
	var right := _builder.sample_heights(_builder.get_chunk_center(Vector2i(1, 0)))
	var below := _builder.sample_heights(_builder.get_chunk_center(Vector2i(0, 1)))
	for i in n:
		assert_eq(a[i * n + (n - 1)], right[i * n + 0], "Naht in x bei Zeile %d" % i)
		assert_eq(a[(n - 1) * n + i], below[0 * n + i], "Naht in z bei Spalte %d" % i)

func test_chunk_heights_include_player_edits() -> void:
	var layer := TerrainEditLayer.new()
	var center := _builder.get_chunk_center(Vector2i(0, 0))
	var before := _builder.sample_heights(center)
	layer.set_delta(Vector2i(0, 0), -1.5)   # Weltposition (0, 0) = Chunk-Zentrum
	_field.set_edit_layer(layer)
	var after := _builder.sample_heights(center)
	var n := _field.get_config().get_resolution() + 1
	var mid := (n / 2) * n + (n / 2)
	assert_almost_eq(after[mid], before[mid] - 1.5, 0.0001)
	assert_almost_eq(after[0], before[0], 0.0001, "Weit entfernte Vertices bleiben unberührt.")

# ── build() ─────────────────────────────────────

func test_build_adds_terrain_and_physics() -> void:
	var node := _make_chunk(Vector2i(0, 0))
	_builder.build(Vector2i(0, 0), node)
	assert_not_null(node.get_node_or_null(TerrainChunkBuilder.NODE_TERRAIN))
	assert_not_null(node.get_node_or_null(TerrainChunkBuilder.NODE_PHYSICS))

func test_physics_shape_matches_sampled_heights() -> void:
	var node := _make_chunk(Vector2i(1, 1))
	_builder.build(Vector2i(1, 1), node)
	var body := node.get_node(TerrainChunkBuilder.NODE_PHYSICS) as StaticBody3D
	var shape := (body.get_child(0) as CollisionShape3D).shape as HeightMapShape3D
	var expected := _builder.sample_heights(_builder.get_chunk_center(Vector2i(1, 1)))
	assert_eq(shape.map_data.size(), expected.size())
	assert_eq(shape.map_data[100], expected[100], "Kollision und Mesh nutzen dieselben Höhen.")

func test_dry_chunk_gets_no_water_surface() -> void:
	var field := _flat_field(5.0)
	var b := TerrainChunkBuilder.new(field)
	var node := Node3D.new()
	autofree(node)
	b.build(Vector2i(0, 0), node)
	assert_null(node.get_node_or_null(TerrainChunkBuilder.NODE_WATER))

func test_flooded_chunk_gets_water_surface_at_water_level() -> void:
	var field := _flat_field(-2.0)
	var b := TerrainChunkBuilder.new(field)
	var node := Node3D.new()
	autofree(node)
	b.build(Vector2i(0, 0), node)
	var water := node.get_node_or_null(TerrainChunkBuilder.NODE_WATER) as MeshInstance3D
	assert_not_null(water)
	assert_eq(water.position.y, field.get_water_level())

func test_water_surface_has_no_collision() -> void:
	# Regression zum alten Verhalten: Wasser waren begehbare Rechtecke mit Kollision.
	var field := _flat_field(-2.0)
	var b := TerrainChunkBuilder.new(field)
	var node := Node3D.new()
	autofree(node)
	b.build(Vector2i(0, 0), node)
	var water := node.get_node(TerrainChunkBuilder.NODE_WATER)
	for child in water.get_children():
		assert_false(child is CollisionObject3D or child is CollisionShape3D, "Wasser darf keine Kollision haben.")
	assert_true(water is MeshInstance3D)

# ── rebuild() ───────────────────────────────────

func test_rebuild_replaces_without_duplicates() -> void:
	var node := _make_chunk(Vector2i(0, 0))
	_builder.build(Vector2i(0, 0), node)
	var first_terrain := node.get_node(TerrainChunkBuilder.NODE_TERRAIN)
	_builder.rebuild(Vector2i(0, 0), node)
	var terrain_count := 0
	for c in node.get_children():
		if c.name == TerrainChunkBuilder.NODE_TERRAIN:
			terrain_count += 1
	assert_eq(terrain_count, 1)
	assert_ne(node.get_node(TerrainChunkBuilder.NODE_TERRAIN), first_terrain, "Neue Instanz.")
	assert_eq(node.get_node(TerrainChunkBuilder.NODE_TERRAIN).name, TerrainChunkBuilder.NODE_TERRAIN, "Kein Umbenennen ('Terrain2').")

func test_rebuild_keeps_foreign_children() -> void:
	var node := _make_chunk(Vector2i(0, 0))
	var marker := Node3D.new()
	marker.name = "Marker"
	node.add_child(marker)
	_builder.build(Vector2i(0, 0), node)
	_builder.rebuild(Vector2i(0, 0), node)
	assert_not_null(node.get_node_or_null("Marker"), "Fremde Kinder (z.B. Entities) bleiben beim Neubau erhalten.")

func test_rebuild_removes_stale_water_when_ground_rises() -> void:
	var field := FuncField.new()
	field.fn = func(_x: float, _z: float) -> float: return -2.0
	var b := TerrainChunkBuilder.new(field)
	var node := Node3D.new()
	autofree(node)
	b.build(Vector2i(0, 0), node)
	assert_not_null(node.get_node_or_null(TerrainChunkBuilder.NODE_WATER))
	field.fn = func(_x: float, _z: float) -> float: return 4.0
	b.rebuild(Vector2i(0, 0), node)
	assert_null(node.get_node_or_null(TerrainChunkBuilder.NODE_WATER), "Aufgeschüttetes Gelände → kein Wasser mehr.")

# ── TerrainWaterBuilder ─────────────────────────

func test_water_builder_needs_surface_only_below_level() -> void:
	var wb := TerrainWaterBuilder.new()
	assert_false(wb.needs_surface(PackedFloat32Array([1.0, 2.0, 3.0]), 0.0))
	assert_true(wb.needs_surface(PackedFloat32Array([1.0, -0.5, 3.0]), 0.0))

func test_water_builder_ignores_grazing_contact() -> void:
	var wb := TerrainWaterBuilder.new()
	assert_false(wb.needs_surface(PackedFloat32Array([1.0, -0.01]), 0.0), "Kaum unter dem Spiegel → keine Ebene (Z-Fighting).")

func test_water_surface_covers_chunk() -> void:
	var wb := TerrainWaterBuilder.new()
	var mi := wb.build_surface(64.0, 0.5)
	autofree(mi)
	assert_eq(mi.position, Vector3(0.0, 0.5, 0.0))
	assert_eq((mi.mesh as PlaneMesh).size, Vector2(64.0, 64.0))
