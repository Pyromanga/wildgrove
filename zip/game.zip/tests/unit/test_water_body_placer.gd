# res://tests/unit/test_water_body_placer.gd
extends GutTest

## Unit-Tests für WaterBodyPlacer.place_all() (Haupt-Welt-Gegenstück zu
## ChunkWaterPlacer, siehe test_chunk_water_placer.gd — hier aber ein
## deutlich komplexerer, NICHT-transitiver Greedy-Cluster-Algorithmus statt
## einer einzelnen Bounding-Box).
##
## WICHTIG zur Cluster-Logik (im Code selbst leicht überraschend): Gruppe i
## sammelt nur Punkte, die innerhalb von sample_step*1.8 zum ANKER-Punkt
## (water_centers[i]) liegen — NICHT transitiv über die wachsende Bounding-
## Box. Zwei Punkte, die beide nah an einem dritten, aber nicht nah
## zueinander sind, landen NICHT zwangsläufig in derselben Gruppe. Um hier
## keine falsche Erwartung von Hand zu unterstellen, wurde der komplette
## Cluster-Durchlauf für das Test-Setup unten VORHER 1:1 in Python
## nachsimuliert (exaktes Abbild des GDScript-Codes) und nur die daraus
## errechneten Werte hier als Erwartung übernommen — keine Schätzung.
##
## Test-Setup: gen.size=16.0 -> sample_step=2.0. 3x3-Gitter aus Tiefpunkten
## bei lx,lz ∈ {-2,0,2}. Simuliertes Ergebnis: GENAU EIN WaterBody bei
## (-1.0, 2.1, -1.0), Größe (4,4,4) — die anderen zwei Gruppen, die dabei
## entstehen, sind beide in genau einer Dimension zu schmal (2.0 < 4.0) und
## werden verworfen.
##
## Abgedeckt:
##   - Ungültiger TerrainGenerator (im Konstruktor null) -> No-Op
##   - Keine Tiefpunkte -> No-Op
##   - Einzelner isolierter Tiefpunkt -> Gruppe zu schmal -> No-Op
##   - 3x3-Gitter -> exakt 1 WaterBody, mit den simulierten Werten

class StubTerrainGenerator extends TerrainGenerator:
	var low_points_set: Dictionary = {}  ## Vector2(x,z) -> true
	func get_height_at(x: float, z: float) -> float:
		if low_points_set.has(Vector2(x, z)):
			return -1.0
		return 2.0


var _world_root: Node3D


func before_each() -> void:
	_world_root = Node3D.new()
	add_child_autofree(_world_root)


func after_each() -> void:
	_world_root = null


func _water_bodies() -> Array:
	var result: Array = []
	for child in _world_root.get_children():
		if child is WaterBody:
			result.append(child)
	return result


func _make_3x3_grid_gen() -> StubTerrainGenerator:
	var gen := StubTerrainGenerator.new()
	gen.size = 16.0  # sample_step = 2.0
	for xi in [-2.0, 0.0, 2.0]:
		for zi in [-2.0, 0.0, 2.0]:
			gen.low_points_set[Vector2(xi, zi)] = true
	return gen


# ─────────────────────────────────────────────
# No-Op-Fälle
# ─────────────────────────────────────────────

func test_invalid_terrain_generator_is_noop() -> void:
	var placer := WaterBodyPlacer.new(null)
	placer.place_all(_world_root)
	assert_eq(_water_bodies().size(), 0)

func test_no_low_points_is_noop() -> void:
	var gen := StubTerrainGenerator.new()
	gen.size = 16.0
	var placer := WaterBodyPlacer.new(gen)
	placer.place_all(_world_root)
	assert_eq(_water_bodies().size(), 0)

func test_single_isolated_low_point_is_too_narrow() -> void:
	var gen := StubTerrainGenerator.new()
	gen.size = 16.0
	gen.low_points_set[Vector2(0.0, 0.0)] = true
	var placer := WaterBodyPlacer.new(gen)
	placer.place_all(_world_root)
	assert_eq(_water_bodies().size(), 0)


# ─────────────────────────────────────────────
# 3x3-Gitter — Werte aus der Python-Simulation (siehe Klassenkommentar oben)
# ─────────────────────────────────────────────

func test_3x3_grid_places_exactly_one_water_body() -> void:
	var placer := WaterBodyPlacer.new(_make_3x3_grid_gen())
	placer.place_all(_world_root)
	assert_eq(_water_bodies().size(), 1,
		"Zwei der drei Kandidaten-Gruppen sind in genau einer Dimension zu schmal (siehe Simulation).")

func test_3x3_grid_water_body_has_simulated_position_and_size() -> void:
	var placer := WaterBodyPlacer.new(_make_3x3_grid_gen())
	placer.place_all(_world_root)
	var wb: WaterBody = _water_bodies()[0]
	assert_almost_eq(wb.position.x, -1.0, 0.0001)
	assert_almost_eq(wb.position.z, -1.0, 0.0001)
	assert_almost_eq(wb.position.y, 2.1, 0.0001, "get_height_at(-1,-1) trifft KEINEN Gitterpunkt -> Stub-Default 2.0 + 0.1.")
	assert_almost_eq(wb.water_size.x, 4.0, 0.0001)
	assert_almost_eq(wb.water_size.y, 4.0, 0.0001)
	assert_almost_eq(wb.water_size.z, 4.0, 0.0001)
