# res://tests/unit/test_animal_species_db.gd
extends GutTest

## Unit-Tests für AnimalSpeciesDB (reine Daten, AUTO-GENERIERT — siehe dortigen
## Kopfkommentar). Prüft die Invarianten, auf die sich GenericAnimal.gd und
## ChunkEntitySpawner verlassen, OHNE jeden der 39+ Einträge einzeln aufzuzählen (das wäre
## exakt die Art manueller Pflege, die AnimalSpeciesDB vermeiden soll).

## Dieselben zehn IDs wie ChunkEntitySpawner.CURATED_LAND_ANIMAL_TYPES/CURATED_FISH_TYPES —
## AnimalSpeciesDB darf keine davon doppelt vergeben (siehe WorldEntityRegistry-Kommentar).
const CURATED_IDS: Array[String] = ["deer", "rabbit", "boar", "fox", "squirrel", "sheep", "bee", "spider", "snake", "bear", "fish"]

const REQUIRED_KEYS: Array[String] = [
	"display_name", "inspect_text", "color", "body_size", "speed", "flee_radius",
	"idle_time", "wander_range", "ear_style", "tail_style", "snout_style",
	"headgear_style", "tail_scale", "body_plan", "wing_style", "back_style",
	"body_shape", "leg_style", "pattern_style", "pattern_color", "aquatic",
]

func test_species_db_is_not_empty() -> void:
	assert_gt(AnimalSpeciesDB.SPECIES.size(), 0)

func test_no_species_id_contains_underscore() -> void:
	# Siehe GenericAnimal.gd-Klassenkommentar: species_id wird aus dem ersten Wort VOR dem
	# ersten "_" des Node-Namens abgeleitet — eine ID mit "_" würde nie korrekt gefunden.
	for id: String in AnimalSpeciesDB.SPECIES:
		assert_eq(id.find("_"), -1, "species_id '%s' darf kein '_' enthalten" % id)

func test_no_species_id_collides_with_curated_animals() -> void:
	for id: String in AnimalSpeciesDB.SPECIES:
		assert_false(id in CURATED_IDS, "species_id '%s' kollidiert mit einer handgeschriebenen Tierart" % id)

func test_every_entry_has_all_required_keys() -> void:
	for id: String in AnimalSpeciesDB.SPECIES:
		var def: Dictionary = AnimalSpeciesDB.SPECIES[id]
		for key in REQUIRED_KEYS:
			assert_true(def.has(key), "'%s' fehlt Feld '%s'" % [id, key])

func test_every_entry_has_sane_value_types_and_ranges() -> void:
	for id: String in AnimalSpeciesDB.SPECIES:
		var def: Dictionary = AnimalSpeciesDB.SPECIES[id]
		assert_true(def["color"] is Color, id)
		assert_true(def["body_size"] is Vector3, id)
		assert_gt(float(def["speed"]), 0.0, id)
		assert_gt(float(def["flee_radius"]), 0.0, id)
		var bs: Vector3 = def["body_size"]
		assert_gt(bs.x, 0.0, id)
		assert_gt(bs.y, 0.0, id)
		assert_gt(bs.z, 0.0, id)
		assert_true(def["aquatic"] is bool, id)
		assert_true(def["pattern_color"] is Color, id)

func test_patterned_entries_use_quadruped_body_plan() -> void:
	# pattern_style wirkt nur auf QUADRUPED (siehe AnimalVisualBuilder._build_body_material()-
	# Kommentar) — ein Eintrag mit Muster auf einem anderen Bauplan wäre kein Crash, aber
	# totes Daten-Feld ohne jede sichtbare Wirkung.
	for id: String in AnimalSpeciesDB.SPECIES:
		var def: Dictionary = AnimalSpeciesDB.SPECIES[id]
		if int(def["pattern_style"]) != AnimalVisualProfile.PatternStyle.NONE:
			assert_eq(int(def["body_plan"]), AnimalVisualProfile.BodyPlan.QUADRUPED, "%s hat ein Muster, aber keinen QUADRUPED-Bauplan" % id)

func test_aquatic_entries_use_fish_body_plan() -> void:
	for id: String in AnimalSpeciesDB.SPECIES:
		var def: Dictionary = AnimalSpeciesDB.SPECIES[id]
		if def["aquatic"]:
			assert_eq(int(def["body_plan"]), AnimalVisualProfile.BodyPlan.FISH, "%s ist aquatic, aber kein FISH-Bauplan" % id)

func test_land_and_aquatic_species_ids_partition_all_species() -> void:
	var land: Array[String] = AnimalSpeciesDB.land_species_ids()
	var aquatic: Array[String] = AnimalSpeciesDB.aquatic_species_ids()
	assert_eq(land.size() + aquatic.size(), AnimalSpeciesDB.SPECIES.size())
	for id in land:
		assert_false(id in aquatic, id)

func test_has_and_get_definition() -> void:
	var any_id: String = AnimalSpeciesDB.SPECIES.keys()[0]
	assert_true(AnimalSpeciesDB.has(any_id))
	assert_false(AnimalSpeciesDB.get_definition(any_id).is_empty())
	assert_false(AnimalSpeciesDB.has("definitiv_keine_echte_art"))
	assert_true(AnimalSpeciesDB.get_definition("definitiv_keine_echte_art").is_empty())
