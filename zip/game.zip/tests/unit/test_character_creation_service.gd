# res://tests/unit/test_character_creation_service.gd
extends GutTest

## Unit-Tests für CharacterCreationService (ADR-048).
##
## Strategie: CharacterCreationService extends Service (RefCounted) — kein
## add_child nötig für den Tier-1-Pfad, identisches Setup-Muster wie
## test_achievement_service.gd/test_stats_service.gd.
##
## Round 106: request_submit_answers()/request_skip_creation() sind jetzt
## die öffentlichen Einstiegspunkte (ohne echten Peer/Tier 1 laufen sie
## direkt in on_submit_answers_confirmed()/on_skip_creation_confirmed(),
## identisches Verhalten wie die alten submit_answers()/skip_creation()
## zuvor) — die bestehenden Tests unten wurden entsprechend umbenannt, ohne
## ihre Assertions zu ändern. Eigener Abschnitt unten für den RPC-Pfad
## selbst (SpyNetworkBridge, analog test_report_service.gd) und für
## character_creation_confirmed.

const P1 := "player-1"
const P2 := "player-2"

var _svc: CharacterCreationService
var _save: SaveSystem

func before_each() -> void:
	_save = SaveSystem.new()
	_save.configure(ServiceDeps.from_dict({ServiceKeys.EVENT_BUS: MockEventBus.new()}))
	_svc = CharacterCreationService.new()
	_svc.configure(ServiceDeps.from_dict({ServiceKeys.SAVE_SYSTEM: _save}))

func test_has_seen_creation_false_by_default() -> void:
	assert_false(_svc.has_seen_creation(P1))

func test_get_questions_returns_four_questions_each_with_four_options() -> void:
	var questions := _svc.get_questions()
	assert_eq(questions.size(), 4)
	for q in questions:
		assert_eq((q["options"] as Array).size(), 4)

func test_get_questions_returns_a_copy_not_the_internal_const() -> void:
	var questions := _svc.get_questions()
	questions.clear()
	assert_eq(_svc.get_questions().size(), 4, "get_questions() muss eine Kopie liefern, sonst mutiert der Aufrufer die Konstante.")

func test_submit_answers_marks_seen_and_completed() -> void:
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "a", "company": "a", "value": "a"})

	assert_true(_svc.has_seen_creation(P1))
	assert_true(_svc.is_completed(P1))

func test_submit_answers_derives_majority_preset() -> void:
	# Alle vier Antworten "wald" (Option "a" bei free_day, "c" bei challenge,
	# "c" bei company, "b" bei value — siehe QUESTIONS-Konstante).
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	assert_eq(_svc.get_appearance_preset_id(P1), "wald")
	assert_eq(_svc.get_appearance_color(P1), Color(0.25, 0.55, 0.25))

func test_submit_answers_collects_unique_traits() -> void:
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	var traits := _svc.get_traits(P1)
	assert_eq(traits, ["naturverbunden"], "Alle vier Antworten zeigen auf denselben Archetyp -> genau ein Trait, nicht viermal derselbe.")

func test_submit_answers_with_mixed_answers_ties_broken_by_archetype_order() -> void:
	# free_day="a" (wald), challenge="a" (sonnig), company="a" (sonnig),
	# value="a" (flut) -> sonnig hat 2 Stimmen, gewinnt eindeutig.
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "a", "company": "a", "value": "a"})

	assert_eq(_svc.get_appearance_preset_id(P1), "sonnig")

func test_submit_answers_emits_character_created() -> void:
	var seen: Array = []
	_svc.character_created.connect(func(pid: String, preset_id: String, traits: Array) -> void:
		seen.append([pid, preset_id, traits])
	)

	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	assert_eq(seen.size(), 1)
	assert_eq(seen[0][0], P1)
	assert_eq(seen[0][1], "wald")

func test_submit_answers_ignores_unknown_question_ids() -> void:
	_svc.request_submit_answers(P1, {"nonexistent_question": "a"})

	assert_true(_svc.has_seen_creation(P1))
	assert_eq(_svc.get_appearance_preset_id(P1), CharacterCreationService.DEFAULT_APPEARANCE_ID)

func test_submit_answers_with_empty_player_id_is_ignored() -> void:
	_svc.request_submit_answers("", {"free_day": "a"})

	assert_false(_svc.has_seen_creation(""))

func test_skip_creation_marks_seen_but_not_completed() -> void:
	_svc.request_skip_creation(P1)

	assert_true(_svc.has_seen_creation(P1))
	assert_false(_svc.is_completed(P1))

func test_skip_creation_uses_default_appearance() -> void:
	_svc.request_skip_creation(P1)

	assert_eq(_svc.get_appearance_preset_id(P1), CharacterCreationService.DEFAULT_APPEARANCE_ID)
	assert_eq(_svc.get_appearance_color(P1), CharacterCreationService.DEFAULT_APPEARANCE_COLOR)
	assert_eq(_svc.get_traits(P1), [])

func test_skip_creation_emits_character_creation_skipped() -> void:
	var seen: Array = []
	_svc.character_creation_skipped.connect(func(pid: String) -> void: seen.append(pid))

	_svc.request_skip_creation(P1)

	assert_eq(seen, [P1])

func test_other_player_is_unaffected() -> void:
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	assert_false(_svc.has_seen_creation(P2))
	assert_eq(_svc.get_appearance_preset_id(P2), CharacterCreationService.DEFAULT_APPEARANCE_ID)

func test_get_appearance_color_for_unknown_player_returns_default() -> void:
	assert_eq(_svc.get_appearance_color("nobody"), CharacterCreationService.DEFAULT_APPEARANCE_COLOR)

func test_save_round_trip() -> void:
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})
	_svc.request_skip_creation(P2)

	var saved := _svc.get_save_data()

	var restored := CharacterCreationService.new()
	restored.configure(ServiceDeps.from_dict({ServiceKeys.SAVE_SYSTEM: _save}))
	restored._restore_from_save(saved)

	assert_true(restored.has_seen_creation(P1))
	assert_eq(restored.get_appearance_preset_id(P1), "wald")
	assert_eq(restored.get_traits(P1), ["naturverbunden"])
	assert_true(restored.has_seen_creation(P2))
	assert_false(restored.is_completed(P2))

func test_save_data_empty_by_default() -> void:
	var saved := _svc.get_save_data()
	assert_true((saved["seen"] as Dictionary).is_empty())
	assert_true((saved["completed"] as Dictionary).is_empty())
	assert_true((saved["appearance"] as Dictionary).is_empty())
	assert_true((saved["traits"] as Dictionary).is_empty())

# ─────────────────────────────────────────────────────────────────────────────
# Netzwerk-Pfad (Round 106, ADR-048) — analog test_report_service.gd
# ─────────────────────────────────────────────────────────────────────────────

class SpyNetworkBridge extends NetworkBridge:
	var submit_calls: Array[Dictionary] = []
	var skip_calls: Array[String] = []
	func send_character_creation_submit_answers(player_id: String, answers: Dictionary) -> void:
		submit_calls.append({"player_id": player_id, "answers": answers})
	func send_character_creation_skip(player_id: String) -> void:
		skip_calls.append(player_id)

func test_request_submit_answers_calls_network_when_not_authority() -> void:
	# Kein echter Peer im Test -> has_peer() ist false -> geht direkt lokal.
	# Dokumentiert den Tier-1-Fallback-Pfad: ohne echten Peer läuft
	# request_submit_answers() immer direkt in on_submit_answers_confirmed(),
	# NIE über send_character_creation_submit_answers() — exakt das
	# ReportService-Guard-Muster.
	var net := SpyNetworkBridge.new()
	add_child_autofree(net)
	_svc.inject_network_bridge(net)

	var created: Array = []
	_svc.character_created.connect(func(pid, _preset, _traits): created.append(pid))
	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	assert_eq(net.submit_calls.size(), 0, "Ohne echten Peer (Tier 1) darf kein RPC versucht werden.")
	assert_eq(created.size(), 1, "Stattdessen muss der direkte Autoritäts-Pfad laufen.")

func test_request_skip_creation_calls_network_when_not_authority() -> void:
	var net := SpyNetworkBridge.new()
	add_child_autofree(net)
	_svc.inject_network_bridge(net)

	var skipped: Array = []
	_svc.character_creation_skipped.connect(func(pid): skipped.append(pid))
	_svc.request_skip_creation(P1)

	assert_eq(net.skip_calls.size(), 0, "Ohne echten Peer (Tier 1) darf kein RPC versucht werden.")
	assert_eq(skipped.size(), 1, "Stattdessen muss der direkte Autoritäts-Pfad laufen.")

func test_on_submit_answers_confirmed_rejects_non_authority() -> void:
	# _require_authority() greift nur mit einem echten Peer, der nicht Server
	# ist — hier direkt über eine Fake-Bridge simuliert, analog anderer
	# _require_authority()-Tests im Projekt (test_report_service.gd hat
	# keinen äquivalenten Test, weil on_submit_report_confirmed() denselben
	# Guard nutzt; hier zusätzlich abgedeckt, weil der Guard jetzt zwei
	# separate Einstiegspunkte schützen muss).
	var net := FakeNonAuthorityBridge.new()
	add_child_autofree(net)
	_svc.inject_network_bridge(net)

	_svc.on_submit_answers_confirmed(P1, {"free_day": "a"})

	assert_false(_svc.has_seen_creation(P1), "Auf einer Nicht-Autorität darf on_submit_answers_confirmed() nichts mutieren.")

class FakeNonAuthorityBridge extends NetworkBridge:
	func has_peer() -> bool: return true
	func is_server() -> bool: return false

func test_on_submit_answers_confirmed_sends_completed_result_to_owning_peer() -> void:
	# Simuliert die Autoritätsseite: ein RPC von einem entfernten Client kam
	# an, on_submit_answers_confirmed() muss das Ergebnis gezielt an genau
	# diesen Spieler zurückschicken (send_character_creation_completed_for_
	# player()) — ohne diesen Rückkanal bekäme ein Nicht-Host-Client sein
	# eigenes Aussehen nie zurück (siehe Klassenkommentar "AUTORITÄT").
	var net := SpyCompletedBridge.new()
	add_child_autofree(net)
	_svc.inject_network_bridge(net)

	_svc.on_submit_answers_confirmed(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	assert_eq(net.completed_calls.size(), 1)
	assert_eq(String(net.completed_calls[0]["player_id"]), P1)
	assert_eq(String((net.completed_calls[0]["payload"] as Dictionary).get("appearance_preset_id", "")), "wald")

class SpyCompletedBridge extends NetworkBridge:
	var completed_calls: Array[Dictionary] = []
	func send_character_creation_completed_for_player(player_id: String, payload: Dictionary) -> void:
		completed_calls.append({"player_id": player_id, "payload": payload})

func test_on_skip_creation_confirmed_sends_skipped_result_to_owning_peer() -> void:
	var net := SpySkippedBridge.new()
	add_child_autofree(net)
	_svc.inject_network_bridge(net)

	_svc.on_skip_creation_confirmed(P1)

	assert_eq(net.skipped_calls, [P1])

class SpySkippedBridge extends NetworkBridge:
	var skipped_calls: Array[String] = []
	func send_character_creation_skipped_for_player(player_id: String, _payload: Dictionary) -> void:
		skipped_calls.append(player_id)

# ─────────────────────────────────────────────────────────────────────────────
# character_creation_confirmed (Round 106) — Signal für den UI-Controller
# ─────────────────────────────────────────────────────────────────────────────

func test_character_creation_confirmed_emitted_on_submit() -> void:
	var confirmed: Array = []
	_svc.character_creation_confirmed.connect(func(pid): confirmed.append(pid))

	_svc.request_submit_answers(P1, {"free_day": "a", "challenge": "c", "company": "c", "value": "b"})

	assert_eq(confirmed, [P1])

func test_character_creation_confirmed_emitted_on_skip() -> void:
	var confirmed: Array = []
	_svc.character_creation_confirmed.connect(func(pid): confirmed.append(pid))

	_svc.request_skip_creation(P1)

	assert_eq(confirmed, [P1])

func test_remote_creation_completed_received_updates_local_state_and_confirms() -> void:
	# Simuliert die Client-Seite: die Autorität hat bereits entschieden
	# (Payload kommt fertig an), CharacterCreationService übernimmt das
	# Ergebnis nur noch — analog AchievementService._on_remote_unlock_received.
	var net: NetworkBridge = autofree(NetworkBridge.new())
	var session: StubSessionManager = autofree(StubSessionManager.new())
	var svc := CharacterCreationService.new()
	svc.configure(ServiceDeps.from_dict({
		ServiceKeys.SAVE_SYSTEM: _save,
		ServiceKeys.NETWORK_BRIDGE: net,
		ServiceKeys.SESSION_MANAGER: session,
	}))

	var confirmed: Array = []
	svc.character_creation_confirmed.connect(func(pid): confirmed.append(pid))

	net.character_creation_completed_received.emit({"appearance_preset_id": "flut", "traits": ["besonnen"]})

	assert_true(svc.has_seen_creation(P1))
	assert_true(svc.is_completed(P1))
	assert_eq(svc.get_appearance_preset_id(P1), "flut")
	assert_eq(svc.get_traits(P1), ["besonnen"])
	assert_eq(confirmed, [P1])
	svc.on_cleanup()

func test_remote_creation_skipped_received_updates_local_state_and_confirms() -> void:
	var net: NetworkBridge = autofree(NetworkBridge.new())
	var session: StubSessionManager = autofree(StubSessionManager.new())
	var svc := CharacterCreationService.new()
	svc.configure(ServiceDeps.from_dict({
		ServiceKeys.SAVE_SYSTEM: _save,
		ServiceKeys.NETWORK_BRIDGE: net,
		ServiceKeys.SESSION_MANAGER: session,
	}))

	var confirmed: Array = []
	svc.character_creation_confirmed.connect(func(pid): confirmed.append(pid))

	net.character_creation_skipped_received.emit({})

	assert_true(svc.has_seen_creation(P1))
	assert_false(svc.is_completed(P1))
	assert_eq(svc.get_appearance_preset_id(P1), CharacterCreationService.DEFAULT_APPEARANCE_ID)
	assert_eq(confirmed, [P1])
	svc.on_cleanup()

class StubSessionManager extends SessionManager:
	var player_id: String = P1
	func get_local_player_id() -> String:
		return player_id
