# res://tests/unit/test_pet_panel_controller.gd
extends GutTest

## Tests für PetPanelController — Pet-Menü (Wunsch "Pets auf Ressourcen sammeln
## usw. verteilen", bisher gab es dafür kein Interface).
##
## StubWorldService liefert Fake-Pets ohne echten SceneTree-Scan (siehe
## WorldService.get_pets_for_peer() — normalerweise get_tree().get_nodes_in_group("pets")).
## StubPet ist ein echtes PetComponent (muss `is PetComponent` bestehen, siehe
## PetPanelController._on_ability_toggled()), aber nie in einen SceneTree
## eingehängt — _ready()/on_spawn() laufen dadurch nie, nur die hier
## überschriebenen Lese-/Schreib-Methoden zählen.

class StubPet extends PetComponent:
	var _stub_name: String
	var _stub_abilities: Array[String]

	func _init(pet_name: String, abilities: Array[String]) -> void:
		_stub_name = pet_name
		_stub_abilities = abilities

	func get_pet_name() -> String:
		return _stub_name

	func get_abilities() -> Array[String]:
		return _stub_abilities.duplicate()

	func set_abilities(new_abilities: Array[String]) -> void:
		_stub_abilities = PetAbilities.sanitize(new_abilities)

	func get_owner_peer_id() -> int:
		return 1

class StubWorldService extends WorldService:
	var pets: Array[PetComponent] = []
	func get_pets_for_peer(_peer_id: int) -> Array[PetComponent]:
		return pets

var _ctrl: PetPanelController
var _ctx: UIContext
var _canvas: CanvasLayer
var _visuals: PetPanelVisuals
var _world: StubWorldService
var _pet: StubPet

func before_each() -> void:
	_canvas = autofree(CanvasLayer.new())
	_visuals = PetPanelVisuals.new(_canvas)

	_pet = autofree(StubPet.new("Fluffy", [PetAbilities.GATHERING]))
	_world = StubWorldService.new()
	_world.pets = [_pet]

	_ctx = UIContext.for_test()
	_ctx._world = _world
	_ctx._local_peer_id = 1

	_ctrl = add_child_autofree(PetPanelController.new())
	_ctrl.setup(_visuals, _ctx)  # setup() ruft bereits refresh() auf

func test_setup_lists_owned_pet() -> void:
	assert_eq(_visuals._rows.get_child_count(), 1, "Ein Pet in world.pets → eine Zeile im Panel")

func test_empty_label_hidden_when_pets_exist() -> void:
	assert_false(_visuals._empty_label.visible)

func test_no_pets_shows_empty_label() -> void:
	_world.pets = []
	_ctrl.refresh()
	assert_true(_visuals._empty_label.visible)
	assert_eq(_visuals._rows.get_child_count(), 0)

func test_toggling_ability_on_adds_it_without_losing_existing() -> void:
	_ctrl._on_ability_toggled(_pet.get_instance_id(), PetAbilities.COMBAT, true)
	var abilities := _pet.get_abilities()
	assert_true(abilities.has(PetAbilities.COMBAT), "Neue Fähigkeit muss hinzugefügt werden")
	assert_true(abilities.has(PetAbilities.GATHERING), "Bestehende Fähigkeit darf nicht verloren gehen")

func test_toggling_ability_off_removes_it() -> void:
	_ctrl._on_ability_toggled(_pet.get_instance_id(), PetAbilities.GATHERING, false)
	assert_eq(_pet.get_abilities(), [])

func test_toggle_on_unknown_pet_instance_is_ignored_without_crash() -> void:
	_ctrl._on_ability_toggled(999999999, PetAbilities.COMBAT, true)
	# Kein Crash + das echte Pet bleibt unangetastet.
	assert_eq(_pet.get_abilities(), [PetAbilities.GATHERING])

func test_reopening_panel_refreshes_pet_list() -> void:
	_visuals.panel.visible = true
	assert_eq(_visuals._rows.get_child_count(), 1)

	var second := autofree(StubPet.new("Rex", [PetAbilities.COMBAT]))
	_world.pets = [_pet, second]

	_visuals.panel.visible = false
	_visuals.panel.visible = true  # visibility_changed → _on_visibility_changed() → refresh()

	assert_eq(_visuals._rows.get_child_count(), 2, "Neu gezähmtes Pet muss beim erneuten Öffnen auftauchen")
