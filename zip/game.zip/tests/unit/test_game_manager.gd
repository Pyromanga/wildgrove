# res://tests/unit/test_game_manager.gd
extends GutTest

## Unit-Tests für GameManager (E-02).
##
## Strategie: GameManager extends ServiceNode (Node) — braucht add_child_autofree().
## configure() ohne SceneManager (null) → kein Szenenwechsel, nur State-Tracking.
## StateValidator wird mit echter GameConfig instanziiert.
##
## Abgedeckt:
##   - get_state() Grundzustand: BOOT
##   - change_state() erlaubte Übergänge
##   - change_state() blockierte Übergänge (via StateValidator + GameConfig)
##   - change_state() same-state wird ignoriert
##   - start_game() setzt MAIN_MENU
##   - is_playing() korrekt

var _gm:     GameManager
var _config: GameConfig
var _bus:    MockEventBus

func before_each() -> void:
	_bus    = MockEventBus.new()
	_gm     = add_child_autofree(GameManager.new())
	_config = GameConfig.new()
	# Kein SceneManager → change_state() macht nur State-Tracking, kein Szenenwechsel.
	_gm.configure(ServiceDeps.from_dict({
		"scenemanager": null,
		"gameconfig": _config,
		ServiceKeys.EVENT_BUS: _bus,
	}))

# ─────────────────────────────────────────────────────────────────────────────
# Grundzustand
# ─────────────────────────────────────────────────────────────────────────────

func test_initial_state_is_boot() -> void:
	assert_eq(_gm.get_state(), GameEnums.State.BOOT, "Startzustand muss BOOT sein")

func test_is_playing_false_at_boot() -> void:
	assert_false(_gm.is_playing(), "is_playing() muss false bei BOOT sein")

# ─────────────────────────────────────────────────────────────────────────────
# start_game()
# ─────────────────────────────────────────────────────────────────────────────

func test_start_game_sets_main_menu() -> void:
	_gm.start_game()
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU,
		"start_game() muss State auf MAIN_MENU setzen")

# ─────────────────────────────────────────────────────────────────────────────
# change_state — erlaubte Übergänge (laut GameConfig.valid_transitions)
# ─────────────────────────────────────────────────────────────────────────────

func test_boot_to_main_menu_allowed() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU)

func test_main_menu_to_playing_allowed() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	assert_eq(_gm.get_state(), GameEnums.State.PLAYING)

func test_playing_to_paused_allowed() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	_gm.change_state(GameEnums.State.PAUSED)
	assert_eq(_gm.get_state(), GameEnums.State.PAUSED)

func test_playing_to_main_menu_allowed() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	_gm.change_state(GameEnums.State.MAIN_MENU)
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU)

# ─────────────────────────────────────────────────────────────────────────────
# change_state — blockierte Übergänge
# ─────────────────────────────────────────────────────────────────────────────

func test_boot_to_playing_blocked() -> void:
	# BOOT → PLAYING ist nicht in valid_transitions
	_gm.change_state(GameEnums.State.PLAYING)
	assert_eq(_gm.get_state(), GameEnums.State.BOOT, "BOOT→PLAYING muss blockiert sein")

func test_main_menu_to_paused_blocked() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PAUSED)
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU, "MAIN_MENU→PAUSED muss blockiert sein")

func test_credits_to_playing_blocked() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.CREDITS)
	_gm.change_state(GameEnums.State.PLAYING)
	assert_eq(_gm.get_state(), GameEnums.State.CREDITS, "CREDITS→PLAYING muss blockiert sein")

# ─────────────────────────────────────────────────────────────────────────────
# Same-state ignorieren
# ─────────────────────────────────────────────────────────────────────────────

func test_same_state_transition_ignored() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	# Zweiter Aufruf mit gleichem State: darf keinen Fehler werfen
	_gm.change_state(GameEnums.State.MAIN_MENU)
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU, "State muss gleich bleiben")

# ─────────────────────────────────────────────────────────────────────────────
# is_playing()
# ─────────────────────────────────────────────────────────────────────────────

func test_is_playing_true_when_playing() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	assert_true(_gm.is_playing(), "is_playing() muss true sein in PLAYING")

func test_is_playing_false_when_paused() -> void:
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	_gm.change_state(GameEnums.State.PAUSED)
	assert_false(_gm.is_playing(), "is_playing() muss false sein in PAUSED")

# ─────────────────────────────────────────────────────────────────────────────
# ADR-028: network_peer_disconnected → geordnete Rückkehr zu MAIN_MENU
# ─────────────────────────────────────────────────────────────────────────────

func test_network_peer_disconnected_returns_to_main_menu_from_playing() -> void:
	_gm.on_ready()
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	_bus.networking().emit_network_peer_disconnected()
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU,
		"Autoritätsverlust in PLAYING muss zu MAIN_MENU führen (ADR-028).")

func test_network_peer_disconnected_returns_to_main_menu_from_loading() -> void:
	_gm.on_ready()
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.LOADING)
	_bus.networking().emit_network_peer_disconnected()
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU,
		"Autoritätsverlust in LOADING muss zu MAIN_MENU führen (ADR-028).")

func test_network_peer_disconnected_returns_to_main_menu_from_paused() -> void:
	_gm.on_ready()
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	_gm.change_state(GameEnums.State.PAUSED)
	_bus.networking().emit_network_peer_disconnected()
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU,
		"Autoritätsverlust in PAUSED muss zu MAIN_MENU führen (ADR-028).")

func test_network_peer_disconnected_while_already_in_main_menu_is_noop() -> void:
	_gm.on_ready()
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_bus.networking().emit_network_peer_disconnected()
	assert_eq(_gm.get_state(), GameEnums.State.MAIN_MENU,
		"Bereits im Hauptmenü — darf keinen Fehler werfen, State bleibt MAIN_MENU.")

func test_without_on_ready_network_peer_disconnected_has_no_effect() -> void:
	## Kontrollfall: ohne on_ready() ist die Signal-Verdrahtung nie hergestellt worden —
	## belegt, dass der Effekt oben tatsächlich von on_ready()s connect() kommt.
	_gm.change_state(GameEnums.State.MAIN_MENU)
	_gm.change_state(GameEnums.State.PLAYING)
	_bus.networking().emit_network_peer_disconnected()
	assert_eq(_gm.get_state(), GameEnums.State.PLAYING,
		"Ohne on_ready() darf sich am State nichts ändern — Kontrollfall für die Tests oben.")
