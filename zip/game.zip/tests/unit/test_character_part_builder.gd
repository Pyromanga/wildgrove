# res://tests/unit/test_character_part_builder.gd
extends GutTest

## Tests für CharacterPartBuilder — prüft die vom Rest des Spiels beobachtbare
## Struktur (welche Kind-Nodes existieren, welche Materialfarben landen wo),
## nicht exakte Geometrie-Zahlen (die sind Gestaltungsfreiheit, keine Contracts).

func test_build_returns_all_documented_keys() -> void:
	var parts := CharacterPartBuilder.build(CharacterLook.default_look())
	for key in ["root", "torso", "shirt_mat", "head", "face", "hair", "arm_r", "arm_l", "leg_r", "leg_l"]:
		assert_true(parts.has(key), "build() Ergebnis fehlt Schlüssel '%s'." % key)
	autofree(parts["root"])

func test_torso_material_color_matches_shirt_catalog_entry() -> void:
	var look := CharacterLook.sanitize({"shirt": "wald"})
	var parts := CharacterPartBuilder.build(look)
	autofree(parts["root"])

	var mat := (parts["torso"] as MeshInstance3D).material_override as StandardMaterial3D
	assert_eq(mat.albedo_color, CharacterLook.color_of("shirt", "wald"))

func test_torso_material_is_the_same_instance_as_shirt_mat() -> void:
	var parts := CharacterPartBuilder.build(CharacterLook.default_look())
	autofree(parts["root"])

	var mat := (parts["torso"] as MeshInstance3D).material_override
	assert_eq(mat, parts["shirt_mat"], "Rumpf und zurückgegebenes shirt_mat müssen dasselbe Material teilen (für Ärmel-Konsistenz).")

func test_head_contains_face_and_hair_children() -> void:
	var parts := CharacterPartBuilder.build(CharacterLook.default_look())
	autofree(parts["root"])

	var head := parts["head"] as Node3D
	assert_true(head.has_node("Face"))
	assert_true(head.has_node("Hair"))
	assert_eq(head.get_node("Face"), parts["face"])
	assert_eq(head.get_node("Hair"), parts["hair"])

func test_bald_hair_style_produces_no_hair_children() -> void:
	var look := CharacterLook.sanitize({"hair_style": "bald"})
	var parts := CharacterPartBuilder.build(look)
	autofree(parts["root"])

	var hair := parts["hair"] as Node3D
	assert_eq(hair.get_child_count(), 0)

func test_every_non_bald_hair_style_produces_at_least_one_mesh() -> void:
	for style_id in CharacterLook.option_ids("hair_style"):
		if style_id == "bald":
			continue
		var look := CharacterLook.sanitize({"hair_style": style_id})
		var parts := CharacterPartBuilder.build(look)
		autofree(parts["root"])
		var hair := parts["hair"] as Node3D
		assert_true(hair.get_child_count() > 0, "hair_style '%s' erzeugt keine Kind-Nodes." % style_id)

func test_no_nose_option_produces_no_nose_child() -> void:
	var look := CharacterLook.sanitize({"nose": "none"})
	var parts := CharacterPartBuilder.build(look)
	autofree(parts["root"])

	var face := parts["face"] as Node3D
	assert_false(face.has_node("Nose"))

func test_no_brows_option_produces_no_brow_children() -> void:
	var look := CharacterLook.sanitize({"brows": "none"})
	var parts := CharacterPartBuilder.build(look)
	autofree(parts["root"])

	var face := parts["face"] as Node3D
	assert_false(face.has_node("BrowR"))
	assert_false(face.has_node("BrowL"))

func test_arm_and_leg_pivots_are_symmetric_around_x_axis() -> void:
	var parts := CharacterPartBuilder.build(CharacterLook.default_look())
	autofree(parts["root"])

	var arm_r := parts["arm_r"] as Node3D
	var arm_l := parts["arm_l"] as Node3D
	assert_almost_eq(arm_r.position.x, -arm_l.position.x, 0.0001)
	assert_almost_eq(arm_r.position.y, arm_l.position.y, 0.0001)

	var leg_r := parts["leg_r"] as Node3D
	var leg_l := parts["leg_l"] as Node3D
	assert_almost_eq(leg_r.position.x, -leg_l.position.x, 0.0001)

func test_broad_build_widens_shoulder_x_versus_slim() -> void:
	var slim := CharacterPartBuilder.shoulder_x(CharacterLook.sanitize({"build": "slim"}))
	var broad := CharacterPartBuilder.shoulder_x(CharacterLook.sanitize({"build": "broad"}))
	assert_true(broad > slim, "Kräftige Statur muss eine breitere Schulterposition ergeben als schlanke.")

func test_hand_position_mirrors_across_sides() -> void:
	var look := CharacterLook.default_look()
	var right := CharacterPartBuilder.hand_position(look, 1.0)
	var left := CharacterPartBuilder.hand_position(look, -1.0)
	assert_almost_eq(right.x, -left.x, 0.0001)
	assert_almost_eq(right.y, left.y, 0.0001)

func test_build_is_deterministic_for_same_look() -> void:
	var look := CharacterLook.sanitize({"build": "broad", "height": "tall"})
	var a := CharacterPartBuilder.build(look)
	var b := CharacterPartBuilder.build(look)
	autofree(a["root"])
	autofree(b["root"])

	assert_eq((a["arm_r"] as Node3D).position, (b["arm_r"] as Node3D).position)
