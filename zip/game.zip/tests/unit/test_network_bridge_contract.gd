# res://tests/unit/test_network_bridge_contract.gd
extends GutTest

## Contract-Tests für das on_*_confirmed()-Muster (ADR-004 / I-01-Fix).
##
## Kontext: Nach I-01-Fix sind die Authority-Mutations-Handler vollständig public und
## direkt typed — kein Dictionary-Payload, kein receive_*_from_network()-Wrapper mehr.
## NetworkBridge._rpc_*() und send_*() rufen on_*_confirmed() direkt auf.
##
## Diese Tests sichern:
##   1. on_*_confirmed() ist öffentlich erreichbar (kein Underscore-Präfix).
##   2. on_*_confirmed() mutiert denselben State wie der request_*()-Pfad.
##   3. player_id-Routing ist korrekt: peer-Daten landen beim richtigen Spieler.
##   4. Authority Guard in on_*_confirmed() verweigert auf Nicht-Autorität.
##   5. NetworkBridge.send_*() und _rpc_*() rufen on_*_confirmed() korrekt auf.
##
## Abdeckung:
##   - QuestService.on_quest_start_confirmed()
##   - QuestService.on_quest_complete_confirmed()
##   - SkillSystem.on_xp_add_confirmed()
##   - NetworkBridge.send_*() Tier-1-Routing → on_*_confirmed()

var _bridge:    NetworkBridge
var _quest:     QuestService
var _skill:     SkillSystem
var _inventory: InventorySystem
var _bus:       MockEventBus

func before_each() -> void:
	_bus = MockEventBus.new()

	_bridge = NetworkBridge.new()
	_bridge.configure(ServiceDeps.from_dict({}))
	add_child_autofree(_bridge)

	_quest = QuestService.new()
	_quest.configure(ServiceDeps.from_dict({"network_bridge": _bridge, "event_bus": _bus}))

	_skill = SkillSystem.new()
	_skill.configure(ServiceDeps.from_dict({"network_bridge": _bridge, "event_bus": _bus}))

	_inventory = InventorySystem.new()
	_inventory.configure(ServiceDeps.from_dict({"network_bridge": _bridge, "event_bus": _bus}))

	# NetworkBridge mit allen Services konfigurieren
	_bridge.configure(ServiceDeps.from_dict({
		"quest":        _quest,
		"skill_system": _skill,
		"inventory":    _inventory,
	}))

func after_each() -> void:
	_bridge.on_cleanup()
	_quest.on_cleanup()
	_skill.on_cleanup()
	_inventory.on_cleanup()
	_bridge    = null
	_quest     = null
	_skill     = null
	_inventory = null

# ─────────────────────────────────────────────────────────────────────────────
# QuestService — on_quest_start_confirmed()
# ─────────────────────────────────────────────────────────────────────────────

func test_quest_on_start_confirmed_is_public() -> void:
	# ADR-004: Handler muss public sein — direkt via RPC aufrufbar
	assert_true(_quest.has_method("on_quest_start_confirmed"),
		"QuestService.on_quest_start_confirmed() muss öffentlich existieren (ADR-004).")

func test_quest_on_complete_confirmed_is_public() -> void:
	assert_true(_quest.has_method("on_quest_complete_confirmed"),
		"QuestService.on_quest_complete_confirmed() muss öffentlich existieren (ADR-004).")

func test_quest_on_start_confirmed_does_not_crash_for_unknown_quest() -> void:
	# Unbekannte quest_id → graceful handling, kein Crash
	_quest.on_quest_start_confirmed("nonexistent_quest_id", 1)
	assert_true(true, "Unbekannte Quest-ID darf keinen Crash auslösen.")

func test_quest_on_start_confirmed_same_state_as_request() -> void:
	# on_quest_start_confirmed() muss denselben State hinterlassen wie request_start_quest().
	# Ohne DataService bleibt is_quest_active() false — aber beide Pfade müssen konsistent sein.
	var svc_via_request := QuestService.new()
	svc_via_request.configure(ServiceDeps.from_dict({"network_bridge": _bridge}))
	svc_via_request.request_start_quest("quest_woodcutter_intro", 1)
	var active_via_request := svc_via_request.is_quest_active("quest_woodcutter_intro", 1)
	svc_via_request.on_cleanup()

	_quest.on_quest_start_confirmed("quest_woodcutter_intro", 1)
	var active_via_confirmed := _quest.is_quest_active("quest_woodcutter_intro", 1)

	assert_eq(active_via_request, active_via_confirmed,
		"on_quest_start_confirmed() und request_start_quest() müssen denselben State liefern.")

func test_quest_on_start_confirmed_player_id_routing() -> void:
	# player_id=2 darf nicht in player_id=1 landen
	_quest.on_quest_start_confirmed("quest_woodcutter_intro", 2)
	assert_false(_quest.is_quest_active("quest_woodcutter_intro", 1),
		"Quest für player_id=2 darf nicht in player_id=1 landen.")

func test_quest_on_complete_confirmed_does_not_crash_without_active_quest() -> void:
	# Quest abschließen die nie gestartet wurde → kein Crash
	_quest.on_quest_complete_confirmed("quest_woodcutter_intro", 1)
	assert_true(true, "Abschließen einer nicht gestarteten Quest darf nicht crashen.")

func test_quest_old_receive_wrappers_are_removed() -> void:
	# I-01-Fix: receive_*_from_network()-Wrapper sind entfernt — on_*_confirmed() ist der Kontrakt
	assert_false(_quest.has_method("receive_start_quest_from_network"),
		"receive_start_quest_from_network() ist entfernt — on_quest_start_confirmed() ist der Kontrakt.")
	assert_false(_quest.has_method("receive_complete_quest_from_network"),
		"receive_complete_quest_from_network() ist entfernt — on_quest_complete_confirmed() ist der Kontrakt.")

# ─────────────────────────────────────────────────────────────────────────────
# SkillSystem — on_xp_add_confirmed()
# ─────────────────────────────────────────────────────────────────────────────

func test_skill_on_xp_add_confirmed_is_public() -> void:
	assert_true(_skill.has_method("on_xp_add_confirmed"),
		"SkillSystem.on_xp_add_confirmed() muss öffentlich existieren (ADR-004).")

func test_skill_on_xp_add_confirmed_mutates_state() -> void:
	_skill.on_xp_add_confirmed("woodcutting", 100, 1)
	assert_eq(_skill.get_xp("woodcutting", 1), 100,
		"on_xp_add_confirmed() muss XP-State mutieren.")

func test_skill_on_xp_add_confirmed_player_id_routing() -> void:
	_skill.on_xp_add_confirmed("woodcutting", 50, 2)
	assert_eq(_skill.get_xp("woodcutting", 1), 0,
		"XP für player_id=2 darf nicht in player_id=1 landen.")
	assert_eq(_skill.get_xp("woodcutting", 2), 50,
		"XP muss bei player_id=2 ankommen.")

func test_skill_on_xp_add_confirmed_same_result_as_request() -> void:
	# on_xp_add_confirmed() und request_add_xp() müssen äquivalent sein (Tier 1)
	_skill.on_xp_add_confirmed("mining", 75, 1)
	var xp_via_confirmed := _skill.get_xp("mining", 1)

	var svc2 := SkillSystem.new()
	svc2.configure(ServiceDeps.from_dict({"network_bridge": _bridge}))
	svc2.request_add_xp("mining", 75, 1)
	var xp_via_request := svc2.get_xp("mining", 1)
	svc2.on_cleanup()

	assert_eq(xp_via_confirmed, xp_via_request,
		"on_xp_add_confirmed() und request_add_xp() müssen denselben Endstate liefern.")

func test_skill_on_xp_add_confirmed_unknown_skill_no_crash() -> void:
	_skill.on_xp_add_confirmed("nonexistent_skill", 50, 1)
	assert_true(true, "Unbekannter Skill in on_xp_add_confirmed darf nicht crashen.")

func test_skill_on_xp_add_confirmed_accumulates() -> void:
	_skill.on_xp_add_confirmed("woodcutting", 30, 1)
	_skill.on_xp_add_confirmed("woodcutting", 20, 1)
	assert_eq(_skill.get_xp("woodcutting", 1), 50,
		"Mehrere on_xp_add_confirmed()-Aufrufe müssen akkumulieren.")

func test_skill_old_receive_wrapper_is_removed() -> void:
	# I-01-Fix: receive_add_xp_from_network() ist entfernt
	assert_false(_skill.has_method("receive_add_xp_from_network"),
		"receive_add_xp_from_network() ist entfernt — on_xp_add_confirmed() ist der Kontrakt.")

# ─────────────────────────────────────────────────────────────────────────────
# NetworkBridge Tier-1-Routing → on_*_confirmed()
# ─────────────────────────────────────────────────────────────────────────────

func test_bridge_send_add_xp_reaches_skill_via_on_confirmed() -> void:
	# Tier 1 (kein Peer): send_add_xp() → on_xp_add_confirmed() direkt
	_bridge.configure(ServiceDeps.from_dict({"skill_system": _skill}))
	_bridge.send_add_xp("farming", 40)
	assert_eq(_skill.get_xp("farming"), 40,
		"Bridge.send_add_xp() muss XP via on_xp_add_confirmed() weiterleiten.")

func test_bridge_send_start_quest_reaches_quest_via_on_confirmed() -> void:
	_bridge.configure(ServiceDeps.from_dict({"quest": _quest}))
	# Ohne DataService bleibt is_quest_active() false — aber kein Crash
	_bridge.send_start_quest("quest_woodcutter_intro")
	assert_true(true, "Bridge.send_start_quest() darf nicht crashen.")

func test_bridge_send_add_xp_without_skill_system_does_not_crash() -> void:
	var bridge2 := NetworkBridge.new()
	bridge2.configure(ServiceDeps.from_dict({}))
	add_child_autofree(bridge2)
	bridge2.send_add_xp("woodcutting", 10)
	assert_true(true, "send_add_xp() ohne SkillSystem darf nicht crashen.")
	bridge2.on_cleanup()

# ─────────────────────────────────────────────
# IV-02: Tier-1 → Tier-2 Übergang (NetworkBridge)
# ─────────────────────────────────────────────
##
## Kernvertrag des gesamten Multiplayer-Designs:
##   Tier 1 (kein Peer): request_*() ruft on_*_confirmed() direkt auf
##   Tier 2 (mit Peer, Client): request_*() delegiert via RPC an Autorität —
##       on_*_confirmed() wird NICHT lokal aufgerufen.
##
## MockNetworkBridge simuliert "Peer ist gesetzt, ich bin Client (nicht Server)"
## ohne echten SceneTree-Multiplayer-Peer.

class MockNetworkBridgeAsPeer extends NetworkBridge:
	## Überschreibt die drei kritischen Checks, die alle Tier-2-Pfade steuern.
	## has_peer() → true: simuliert gesetzten Multiplayer-Peer (Tier 2/3)
	## is_server() → false: simuliert Client-Rolle (nur Autorität → on_*_confirmed)
	## get_local_peer_id() → 2: Nicht-Autorität-Peer-ID
	var _rpc_calls: Array[String] = []

	func has_peer() -> bool:
		return true

	func is_server() -> bool:
		return false

	func get_local_peer_id() -> int:
		return 2

	## Override rpc_id() um Aufrufe zu verfolgen ohne echtes Netzwerk.
	## GDScript erlaubt kein rpc_id()-Override auf Node direkt;
	## wir tracken den Aufrufpfad stattdessen über send_add_xp().
	func send_add_xp(skill_name: String, amount: int) -> void:
		# Als Client: delegiere zum Server (RPC-Pfad) — mutiere NICHT lokal
		_rpc_calls.append("rpc_add_xp(%s,%d)" % [skill_name, amount])
		# kein on_xp_add_confirmed() Aufruf — das ist Tier-2-Semantik

func test_tier1_request_add_xp_calls_on_confirmed_locally() -> void:
	# Tier 1: kein Peer → on_xp_add_confirmed() wird sofort lokal aufgerufen
	var bridge := NetworkBridge.new()
	bridge.configure(ServiceDeps.from_dict({"skill_system": _skill}))
	add_child_autofree(bridge)
	assert_false(bridge.has_peer(), "Tier-1-Bridge darf keinen Peer haben")
	bridge.send_add_xp("farming", 30)
	assert_eq(_skill.get_xp("farming"), 30,
		"Tier 1: send_add_xp() muss XP lokal via on_xp_add_confirmed() schreiben")
	bridge.on_cleanup()

func test_tier2_request_add_xp_does_not_call_on_confirmed_locally() -> void:
	# Tier 2: mit Peer (Client-Rolle) → on_xp_add_confirmed() wird NICHT lokal aufgerufen
	var mock_bridge := MockNetworkBridgeAsPeer.new()
	mock_bridge.configure(ServiceDeps.from_dict({"skill_system": _skill}))
	add_child_autofree(mock_bridge)
	assert_true(mock_bridge.has_peer(), "MockNetworkBridgeAsPeer muss Peer simulieren")
	assert_false(mock_bridge.is_server(), "MockNetworkBridgeAsPeer muss Client-Rolle simulieren")

	mock_bridge.send_add_xp("farming", 30)

	assert_eq(_skill.get_xp("farming"), 0,
		"Tier 2: send_add_xp() als Client darf NICHT lokal on_xp_add_confirmed() aufrufen")
	assert_eq(mock_bridge._rpc_calls.size(), 1,
		"Tier 2: send_add_xp() muss einen RPC-Aufruf vermerken")
	assert_true(
		mock_bridge._rpc_calls[0].begins_with("rpc_add_xp(farming"),
		"Tier 2: RPC-Call muss farming-Skill-Namen enthalten"
	)
	mock_bridge.on_cleanup()

func test_tier2_skill_request_add_xp_routes_via_rpc_not_local() -> void:
	# SkillSystem.request_add_xp() selbst wählt Tier anhand _network.has_peer() + is_server()
	# Mit MockBridge-Peer → request_add_xp() ruft rpc_id() → kein lokaler State
	var mock_bridge := MockNetworkBridgeAsPeer.new()
	mock_bridge.configure(ServiceDeps.from_dict({}))
	add_child_autofree(mock_bridge)
	_skill.set_network(mock_bridge)   # inject mock als _network-Dep

	_skill.request_add_xp("farming", 50, 1)
	assert_eq(_skill.get_xp("farming"), 0,
		"Tier 2: request_add_xp() als Client darf XP nicht lokal schreiben — muss via RPC gehen")
	mock_bridge.on_cleanup()

