# res://tests/unit/test_chunk_water_placer.gd
extends GutTest

## Unit-Tests für ChunkWaterPlacer (Terrain-Senken-Sampling + Becken-Berechnung).
##
## Strategie: StubTerrainGenerator liefert -1.0 (< -0.5, "Tiefpunkt") NUR für
## exakt kontrollierte (x,z)-Gitterpunkte, sonst 2.0. Das Sample-Raster ist
## vollständig deterministisch (lx=xi*sample_step für xi in -3..3, kein
## Zufall im Spiel) — dadurch sind ALLE erwarteten Werte hier exakt von Hand
## nachrechenbar, kein Trig-Risiko wie bei MathHelper/EnemyAI.
##
## WaterBody.place() ist eine konkrete statische Methode (nicht injizierbar)
## — Nachweis über echte Kind-Suche im chunk_node nach dem Aufruf, analog zum
## bereits etablierten InteractableComponent-Muster (test_enemy_attack.gd).
##
## Abgedeckt:
##   - Ungültiger TerrainGenerator (null) -> No-Op, keine Kinder
##   - Keine Tiefpunkte gefunden -> No-Op
##   - Ein einzelner Tiefpunkt -> Becken ist genau 1 sample_step breit/lang
##     -> unter der 4m-Mindestgröße -> No-Op
##   - Mehrere Tiefpunkte, breit genug -> WaterBody wird platziert, mit exakt
##     nachgerechneter Position und Größe

var _placer: ChunkWaterPlacer
var _chunk_node: Node3D


class StubTerrainGenerator extends TerrainGenerator:
	var low_points_set: Dictionary = {}  ## Vector2(x,z) -> true
	func get_height_at(x: float, z: float) -> float:
		if low_points_set.has(Vector2(x, z)):
			return -1.0
		return 2.0


func before_each() -> void:
	_placer = ChunkWaterPlacer.new()
	_chunk_node = Node3D.new()
	add_child_autofree(_chunk_node)


func after_each() -> void:
	_placer = null
	_chunk_node = null


func _find_water_body() -> WaterBody:
	for child in _chunk_node.get_children():
		if child is WaterBody:
			return child
	return null


# ─────────────────────────────────────────────
# No-Op-Fälle
# ─────────────────────────────────────────────

func test_invalid_generator_is_noop() -> void:
	_placer.place_water(_chunk_node, Vector2.ZERO, null)
	assert_null(_find_water_body())

func test_no_low_points_is_noop() -> void:
	var gen := StubTerrainGenerator.new()
	gen.size = 12.0  # sample_step = 2.0
	# low_points_set bleibt leer -> get_height_at() liefert überall 2.0
	_placer.place_water(_chunk_node, Vector2.ZERO, gen)
	assert_null(_find_water_body())

func test_single_low_point_basin_too_narrow_is_noop() -> void:
	var gen := StubTerrainGenerator.new()
	gen.size = 12.0  # sample_step = 2.0
	gen.low_points_set[Vector2(0.0, 0.0)] = true
	# Becken aus einem einzelnen Punkt: w = max(0-0+2.0, 2.0) = 2.0 < 4.0
	_placer.place_water(_chunk_node, Vector2.ZERO, gen)
	assert_null(_find_water_body())


# ─────────────────────────────────────────────
# Erfolgsfall — exakt nachgerechnete Werte
# ─────────────────────────────────────────────

func test_wide_basin_places_water_body_with_exact_position_and_size() -> void:
	var gen := StubTerrainGenerator.new()
	gen.size = 12.0  # sample_step = 2.0
	# 3x3-Gitter von Tiefpunkten bei x,z in {-2, 0, 2} -> min=-2, max=2 überall.
	for xi in [-2.0, 0.0, 2.0]:
		for zi in [-2.0, 0.0, 2.0]:
			gen.low_points_set[Vector2(xi, zi)] = true

	var center := Vector2(100.0, 200.0)
	_placer.place_water(_chunk_node, center, gen)

	var wb := _find_water_body()
	assert_not_null(wb, "Becken ist 4x4 breit (>= 4.0) -> WaterBody sollte platziert sein.")

	# w = max(2-(-2)+2.0, 2.0) = 6.0, l analog = 6.0
	assert_almost_eq(wb.water_size.x, 6.0, 0.0001)
	assert_almost_eq(wb.water_size.z, 6.0, 0.0001)
	assert_almost_eq(wb.water_size.y, 4.0, 0.0001, "Tiefe ist im Code hart codiert (4.0), unabhängig vom Becken.")

	# wx = center.x + (min_x+max_x)*0.5 = 100 + 0 = 100; wz analog = 200
	assert_almost_eq(wb.position.x, 100.0, 0.0001)
	assert_almost_eq(wb.position.z, 200.0, 0.0001)
	# basin_h = get_height_at(0,0) + 0.1 = -1.0 + 0.1 = -0.9
	assert_almost_eq(wb.position.y, -0.9, 0.0001)

func test_wide_basin_places_exactly_one_water_body() -> void:
	var gen := StubTerrainGenerator.new()
	gen.size = 12.0
	for xi in [-2.0, 0.0, 2.0]:
		for zi in [-2.0, 0.0, 2.0]:
			gen.low_points_set[Vector2(xi, zi)] = true
	_placer.place_water(_chunk_node, Vector2.ZERO, gen)

	var count := 0
	for child in _chunk_node.get_children():
		if child is WaterBody:
			count += 1
	assert_eq(count, 1)

func test_asymmetric_basin_x_too_narrow_is_noop_even_if_z_is_wide() -> void:
	# Becken 6m breit in Z, aber nur 1 Gitterpunkt in X (2.0m, < 4.0) ->
	# Code verlangt BEIDE Dimensionen >= 4.0 ("w < 4.0 or l < 4.0").
	var gen := StubTerrainGenerator.new()
	gen.size = 12.0
	for zi in [-2.0, 0.0, 2.0]:
		gen.low_points_set[Vector2(0.0, zi)] = true  # x immer 0.0
	_placer.place_water(_chunk_node, Vector2.ZERO, gen)
	assert_null(_find_water_body())
