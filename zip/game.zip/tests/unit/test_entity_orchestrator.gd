# res://tests/unit/test_entity_orchestrator.gd
extends GutTest

## Unit-Tests für EntityOrchestrator.resolve_for_player() (ADR-023).
##
## Deckt ab:
##   - unbekannte UUID → null
##   - kein Player-Node mit passendem peer_id → null
##   - Player existiert, aber Entity außerhalb max_range → null
##   - Player existiert, Entity innerhalb max_range → Entity wird zurückgegeben
##   - peer_id-Auflösung nutzt "owner_peer_id"-Meta, nicht Node-Reihenfolge

var _orchestrator: EntityOrchestrator
var _world_root: Node3D

func before_each() -> void:
	_world_root = add_child_autofree(Node3D.new())
	_orchestrator = add_child_autofree(EntityOrchestrator.new())
	_orchestrator.set_event_bus(MockEventBus.new())
	_orchestrator.initialize(_world_root)
	_orchestrator.register_definition("oak_tree", "res://tests/mocks/MockHarvestable.gd", "")

func _spawn_player(peer_id: int, position: Vector3) -> Node3D:
	var player := Node3D.new()
	player.position = position
	player.add_to_group("player")
	player.set_meta("owner_peer_id", peer_id)
	add_child_autofree(player)
	return player

func test_resolve_for_player_returns_null_for_unknown_uuid() -> void:
	_spawn_player(1, Vector3.ZERO)
	var result := _orchestrator.resolve_for_player("does-not-exist", 1, 10.0)
	assert_null(result, "Unbekannte UUID muss null liefern.")

func test_resolve_for_player_returns_null_without_matching_player() -> void:
	var entity := _orchestrator.spawn_entity("oak_tree", Vector3.ZERO)
	var uuid: String = entity.get_meta("entity_uuid")
	# Kein Player mit peer_id=1 in der Gruppe "player" gespawnt.
	var result := _orchestrator.resolve_for_player(uuid, 1, 100.0)
	assert_null(result, "Fehlender Player-Node muss null liefern.")

func test_resolve_for_player_returns_null_outside_range() -> void:
	_spawn_player(1, Vector3(500, 0, 0))
	var entity := _orchestrator.spawn_entity("oak_tree", Vector3.ZERO)
	var uuid: String = entity.get_meta("entity_uuid")
	var result := _orchestrator.resolve_for_player(uuid, 1, 5.0)
	assert_null(result, "Entity außerhalb max_range muss null liefern.")

func test_resolve_for_player_returns_entity_within_range() -> void:
	_spawn_player(1, Vector3(1, 0, 0))
	var entity := _orchestrator.spawn_entity("oak_tree", Vector3.ZERO)
	var uuid: String = entity.get_meta("entity_uuid")
	var result := _orchestrator.resolve_for_player(uuid, 1, 5.0)
	assert_eq(result, entity, "Entity innerhalb max_range muss zurückgegeben werden.")

func test_resolve_for_player_matches_by_owner_peer_id_not_node_order() -> void:
	# Spieler 2 zuerst in der Gruppe, Spieler 1 danach — Auflösung darf sich
	# nicht auf Einfüge-/Iterationsreihenfolge verlassen, sondern muss über
	# das "owner_peer_id"-Meta matchen.
	_spawn_player(2, Vector3(500, 0, 0))
	_spawn_player(1, Vector3(1, 0, 0))
	var entity := _orchestrator.spawn_entity("oak_tree", Vector3.ZERO)
	var uuid: String = entity.get_meta("entity_uuid")
	var result := _orchestrator.resolve_for_player(uuid, 1, 5.0)
	assert_eq(result, entity, "Muss über peer_id=1 (nah) auflösen, nicht über peer_id=2 (fern).")
