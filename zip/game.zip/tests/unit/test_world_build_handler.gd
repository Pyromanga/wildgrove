# res://tests/unit/test_world_build_handler.gd
extends GutTest

## Tests für WorldBuildHandler + WorldTerrainEditor — komplett ohne SceneTree/Inventar:
## alles Externe (Definitionen, Boden, Spawnen, Inventar) wird per Callable gefaket.

const FLOOR := BuildPieceDefinition.Kind.FLOOR
const WALL  := BuildPieceDefinition.Kind.WALL
const PLAYER := "p1"
const NEAR := Vector3(1.0, 0.0, 8.0)      # Spielerposition, weit genug von Wänden bei z=4
const CHUNK := 64.0

var _registry: BuildRegistry
var _layer: TerrainEditLayer
var _editor: WorldTerrainEditor
var _handler: WorldBuildHandler

var _defs: Dictionary = {}
var _wallet: Dictionary = {}
var _spawned: Array = []
var _despawned: Array = []
var _refreshed: Array = []

func before_each() -> void:
	_defs = {}
	_wallet = {"log_normal": 20, "stone": 20}
	_spawned = []
	_despawned = []
	_refreshed = []

	var floor_def := BuildPieceDefinition.new()
	floor_def.id = "wood_floor"; floor_def.kind = FLOOR; floor_def.cost = {"log_normal": 4}
	var wall_def := BuildPieceDefinition.new()
	wall_def.id = "wood_wall"; wall_def.kind = WALL; wall_def.cost = {"log_normal": 5, "stone": 3}
	wall_def.refund_ratio = 0.5
	_defs["wood_floor"] = floor_def
	_defs["wood_wall"] = wall_def

	_registry = BuildRegistry.new()
	_layer = TerrainEditLayer.new()
	_editor = WorldTerrainEditor.new(_layer, _registry, _fake_refresh)
	_handler = WorldBuildHandler.new(
		_registry, _editor, _fake_def, _fake_ground, _fake_spawn, _fake_despawn, CHUNK
	)
	_handler.set_inventory_ops(_fake_can_afford, _fake_pay, _fake_refund)

# ── Fakes (als Methoden statt mehrzeiliger Lambdas: robuster zu parsen) ──

func _fake_refresh(points: Array) -> void:
	_refreshed.append_array(points)

func _fake_def(piece_id: String) -> Variant:
	return _defs.get(piece_id)

func _fake_ground(_x: float, _z: float) -> float:
	return 1.0

func _fake_spawn(type_id: String, pos: Vector3, cfg: Dictionary) -> Node3D:
	var n := Node3D.new()
	autofree(n)
	_spawned.append({"type": type_id, "pos": pos, "cfg": cfg})
	return n

func _fake_despawn(node: Node3D) -> void:
	_despawned.append(node)

func _fake_can_afford(_pid: String, cost: Dictionary) -> bool:
	for id: String in cost.keys():
		if int(_wallet.get(id, 0)) < int(cost[id]):
			return false
	return true

func _fake_pay(_pid: String, cost: Dictionary) -> bool:
	for id: String in cost.keys():
		_wallet[id] = int(_wallet.get(id, 0)) - int(cost[id])
	return true

func _fake_refund(_pid: String, items: Dictionary) -> void:
	for id: String in items.keys():
		_wallet[id] = int(_wallet.get(id, 0)) + int(items[id])

# ── Platzieren ──────────────────────────────────

func test_place_floor_succeeds_spawns_and_charges() -> void:
	var res := _handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	assert_true(res["ok"], str(res))
	assert_eq(_registry.count(), 1)
	assert_eq(_spawned.size(), 1)
	assert_eq(_spawned[0]["type"], "build_piece")
	assert_eq(_spawned[0]["cfg"]["piece_id"], "wood_floor")
	assert_eq(_wallet["log_normal"], 16)

func test_place_floor_levels_terrain_and_refreshes_chunks() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	assert_false(_layer.is_empty(), "Boden ebnet das Gelände darunter ein.")
	assert_false(_refreshed.is_empty(), "Betroffene Chunks werden neu gebaut.")

func test_place_record_has_expected_position() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	var rec := _registry.get_record("F_0_0")
	assert_eq(rec["x"], 1.0)
	assert_eq(rec["z"], 1.0)
	assert_eq(rec["y"], 1.0)
	assert_eq(rec["owner"], PLAYER)

func test_place_wall_on_ground() -> void:
	var res := _handler.place(PLAYER, "wood_wall", Vector3(1, 0, 4), 0, NEAR)
	assert_true(res["ok"], str(res))
	assert_eq(_wallet["stone"], 17)
	assert_true(_layer.is_empty(), "Wände verändern das Gelände nicht.")

func test_place_unknown_piece_fails() -> void:
	var res := _handler.place(PLAYER, "gibt_es_nicht", Vector3(1, 0, 1), 0, NEAR)
	assert_false(res["ok"])
	assert_eq(res["reason"], "unknown_piece")

func test_place_without_materials_changes_nothing() -> void:
	_wallet["log_normal"] = 1
	var res := _handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	assert_false(res["ok"])
	assert_eq(res["reason"], "no_materials")
	assert_eq(_registry.count(), 0)
	assert_eq(_wallet["log_normal"], 1, "Nichts abgezogen.")
	assert_true(_layer.is_empty(), "Kein Einebnen ohne Bau.")
	assert_eq(_spawned.size(), 0)

func test_place_on_occupied_cell_fails_without_charging() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	var before: int = _wallet["log_normal"]
	var res := _handler.place(PLAYER, "wood_floor", Vector3(1.5, 0, 0.5), 0, NEAR)
	assert_false(res["ok"])
	assert_eq(res["reason"], "occupied")
	assert_eq(_wallet["log_normal"], before)

func test_place_too_far_fails() -> void:
	var res := _handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, Vector3(100, 0, 100))
	assert_false(res["ok"])
	assert_eq(res["reason"], "too_far")

func test_place_wall_on_player_fails() -> void:
	var res := _handler.place(PLAYER, "wood_wall", Vector3(1, 0, 4), 0, Vector3(1.0, 0.0, 4.1))
	assert_false(res["ok"])
	assert_eq(res["reason"], "player_in_way")

func test_place_wall_on_floor_takes_floor_height() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 3), 0, NEAR)   # Zelle (0,1), y=1.0
	var res := _handler.place(PLAYER, "wood_wall", Vector3(1, 0, 4), 0, NEAR)
	assert_true(res["ok"], str(res))
	assert_eq(_registry.get_record(res["key"])["y"], 1.0)

func test_place_without_inventory_ops_is_free() -> void:
	_handler.set_inventory_ops(Callable(), Callable(), Callable())
	var res := _handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	assert_true(res["ok"])

# ── Vorschau ────────────────────────────────────

func test_preview_does_not_mutate() -> void:
	var pv := _handler.preview(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	assert_true(pv["ok"])
	assert_eq(_registry.count(), 0)
	assert_eq(_spawned.size(), 0)
	assert_eq(_wallet["log_normal"], 20)
	assert_true(_layer.is_empty())

func test_preview_reports_snap_and_affordability() -> void:
	# Achse 1: x=1.2 → nächste Kante x=2 (Index 1); z=4 → Zelle 2.
	var pv := _handler.preview(PLAYER, "wood_wall", Vector3(1.2, 0, 4), 1, NEAR)
	assert_eq(pv["key"], "W1_1_2")
	assert_almost_eq(pv["yaw"], PI * 0.5, 0.0001)
	assert_true(pv["affordable"])
	_wallet["stone"] = 0
	assert_false(_handler.preview(PLAYER, "wood_wall", Vector3(1.2, 0, 4), 1, NEAR)["affordable"])

func test_preview_matches_place_outcome() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	var pv := _handler.preview(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	assert_false(pv["ok"])
	assert_eq(pv["reason"], "occupied")

func test_preview_marks_too_far() -> void:
	var pv := _handler.preview(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, Vector3(100, 0, 100))
	assert_false(pv["ok"])
	assert_eq(pv["reason"], "too_far")

func test_preview_unknown_piece() -> void:
	assert_eq(_handler.preview(PLAYER, "x", Vector3.ZERO, 0, NEAR)["reason"], "unknown_piece")

# ── Entfernen ───────────────────────────────────

func test_remove_refunds_and_despawns() -> void:
	var placed := _handler.place(PLAYER, "wood_wall", Vector3(1, 0, 4), 0, NEAR)
	assert_eq(_wallet["log_normal"], 15)
	var res := _handler.remove(PLAYER, placed["key"], NEAR)
	assert_true(res["ok"])
	assert_eq(_registry.count(), 0)
	assert_eq(_despawned.size(), 1)
	assert_eq(_wallet["log_normal"], 17, "5 investiert, 50 % zurück = 2.")
	assert_eq(_wallet["stone"], 18, "3 investiert, 50 % zurück = 1.")

func test_remove_unknown_key_fails() -> void:
	var res := _handler.remove(PLAYER, "F_9_9", NEAR)
	assert_false(res["ok"])

func test_remove_too_far_fails_and_keeps_piece() -> void:
	var placed := _handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	var res := _handler.remove(PLAYER, placed["key"], Vector3(200, 0, 200))
	assert_false(res["ok"])
	assert_eq(res["reason"], "too_far")
	assert_eq(_registry.count(), 1)

func test_place_then_remove_frees_the_cell() -> void:
	var placed := _handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	_handler.remove(PLAYER, placed["key"], NEAR)
	assert_true(_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)["ok"])

# ── Chunk-Ansichten ─────────────────────────────

func test_chunk_unload_despawns_views_but_keeps_data() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	_handler.on_chunk_unloaded(Vector2i(0, 0))
	assert_eq(_despawned.size(), 1)
	assert_eq(_registry.count(), 1, "Daten bleiben — nur die Ansicht verschwindet.")
	assert_eq(_handler.get_view_count(), 0)

func test_chunk_load_respawns_views_from_data() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	_handler.on_chunk_unloaded(Vector2i(0, 0))
	_handler.on_chunk_loaded(Vector2i(0, 0))
	assert_eq(_spawned.size(), 2, "Einmal beim Bauen, einmal beim erneuten Laden.")
	assert_eq(_handler.get_view_count(), 1)

func test_chunk_load_does_not_duplicate_existing_view() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	_handler.on_chunk_loaded(Vector2i(0, 0))
	assert_eq(_spawned.size(), 1)

func test_chunk_events_only_touch_their_own_pieces() -> void:
	_registry.add({"key": "F_far", "piece_id": "wood_floor", "kind": FLOOR, "x": 200.0, "y": 0.0, "z": 0.0, "yaw": 0.0})
	_handler.on_chunk_loaded(Vector2i(0, 0))
	assert_eq(_spawned.size(), 0)
	_handler.on_chunk_loaded(Vector2i(3, 0))   # x=200 → Chunk 3
	assert_eq(_spawned.size(), 1)

# ── WorldTerrainEditor ──────────────────────────

func test_dig_lowers_terrain_and_refreshes() -> void:
	var res := _editor.edit(WorldTerrainEditor.MODE_DIG, Vector3(20, 0, 20))
	assert_true(res["ok"])
	assert_lt(_layer.get_delta_at(20.0, 20.0), 0.0)
	assert_false(_refreshed.is_empty())

func test_fill_raises_terrain() -> void:
	var res := _editor.edit(WorldTerrainEditor.MODE_FILL, Vector3(20, 0, 20))
	assert_true(res["ok"])
	assert_gt(_layer.get_delta_at(20.0, 20.0), 0.0)

func test_dig_blocked_near_building() -> void:
	_handler.place(PLAYER, "wood_floor", Vector3(1, 0, 1), 0, NEAR)
	_refreshed = []
	var res := _editor.edit(WorldTerrainEditor.MODE_DIG, Vector3(3, 0, 1))
	assert_false(res["ok"])
	assert_eq(res["reason"], "building_nearby")
	assert_true(_refreshed.is_empty())

func test_dig_reports_limit_when_nothing_changes() -> void:
	# Diagonalpunkte bekommen nur 0.05 m pro Schlag → 80 Schläge bis zum Limit von 4 m.
	for i in 100:
		_editor.edit(WorldTerrainEditor.MODE_DIG, Vector3(20, 0, 20))
	var res := _editor.edit(WorldTerrainEditor.MODE_DIG, Vector3(20, 0, 20))
	assert_false(res["ok"])
	assert_eq(res["reason"], "limit")

func test_edit_rejects_bad_mode() -> void:
	assert_eq(_editor.edit("explodieren", Vector3.ZERO)["reason"], "bad_mode")

func test_editor_reason_texts_are_specific() -> void:
	for code in ["building_nearby", "limit", "too_far", "no_dirt", "inventory_full", "coop_unsupported"]:
		assert_ne(WorldTerrainEditor.reason_text(code), "Das geht hier nicht.")
