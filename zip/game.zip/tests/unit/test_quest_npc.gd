# res://tests/unit/test_quest_npc.gd
extends GutTest

## Unit-Tests für QuestNPC — Fokus auf IEventBus-Injection (Runde 4 Migration).
##
## QuestNPC braucht NPCVisualBuilder.build() in _ready() (3D-Label/Mesh) —
## läuft im Headless-Testmodus, da reine Node3D/Label3D-Erzeugung ohne
## Rendering-Pflicht. Voller Lifecycle (_ready + on_spawn) ist daher testbar.
##
## Abgedeckt:
##   - on_spawn() ohne IEventBus: kein Crash, _dialog bleibt null
##   - on_spawn() mit IEventBus: _bus korrekt gesetzt, _dialog erstellt
##   - on_spawn() verbindet quest_completed/quest_objective_updated/quest_start_failed
##   - _on_interacted() vor on_spawn(): kein Crash (Null-Guard)
##   - _on_interacted() nach on_spawn(): delegiert an _dialog.on_interact()
##   - on_despawn(): disconnected alle Signale

var _bus: MockEventBus

func before_each() -> void:
	_bus = MockEventBus.new()

func _make_npc() -> QuestNPC:
	var npc := QuestNPC.new()
	npc.quest_id         = "quest_woodcutter_intro"
	npc.quest_obj_id     = "obj_chop_trees"
	npc.npc_display_name = "Test-NPC"
	add_child_autofree(npc)
	return npc

class BareContext extends IEntityContext:
	func get_service(_k: String) -> Variant: return null

## ADR-021 (R-5): spy statt echtem NetworkBridge — vermeidet SceneTree/
## multiplayer-Abhängigkeit, prüft nur DASS und mit WELCHEN Argumenten
## report_domain_event() aufgerufen wird.
class MockNetworkBridge extends NetworkBridge:
	var reported_events: Array[Dictionary] = []
	func report_domain_event(event_name: String, payload: Dictionary, peer_id: int = 1) -> void:
		reported_events.append({"event_name": event_name, "payload": payload, "peer_id": peer_id})

# ─────────────────────────────────────────────────────────────────────────────
# on_spawn() — IEventBus Pflicht-Dep
# ─────────────────────────────────────────────────────────────────────────────

func test_on_spawn_without_bus_no_crash() -> void:
	var npc := _make_npc()
	npc.on_spawn({}, BareContext.new())
	assert_true(true, "on_spawn() ohne IEventBus darf nicht crashen")

func test_on_spawn_without_bus_dialog_stays_null() -> void:
	var npc := _make_npc()
	npc.on_spawn({}, BareContext.new())
	assert_null(npc._dialog, "Ohne gültigen Bus darf _dialog nicht erstellt werden")

func test_on_spawn_with_bus_sets_field() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	assert_eq(npc._bus, _bus, "_bus muss aus ctx.get_event_bus() übernommen werden")

func test_on_spawn_with_bus_creates_dialog() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	assert_not_null(npc._dialog, "Mit gültigem Bus muss _dialog erstellt werden")

func test_on_spawn_dialog_starts_in_has_quest_state() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	assert_eq(npc._dialog.state, QuestNPCDialogController.NPCState.HAS_QUEST)

# ─────────────────────────────────────────────────────────────────────────────
# on_spawn() — Signal-Connects auf injizierten Bus
# ─────────────────────────────────────────────────────────────────────────────

func test_on_spawn_connects_quest_completed() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	assert_true(
		_bus.quest().quest_completed.is_connected(npc._on_quest_completed),
		"on_spawn() muss quest_completed auf injiziertem Bus connecten"
	)

func test_on_spawn_connects_quest_objective_updated() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	assert_true(
		_bus.quest().quest_objective_updated.is_connected(npc._on_objective_updated),
		"on_spawn() muss quest_objective_updated auf injiziertem Bus connecten"
	)

func test_on_spawn_connects_quest_start_failed() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	assert_true(
		_bus.quest().quest_start_failed.is_connected(npc._on_quest_start_failed),
		"on_spawn() muss quest_start_failed auf injiziertem Bus connecten"
	)

func test_quest_completed_signal_updates_dialog_state() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	_bus.quest().quest_completed.emit("quest_woodcutter_intro", null)
	assert_eq(npc._dialog.state, QuestNPCDialogController.NPCState.QUEST_DONE,
		"quest_completed Signal muss Dialog-State auf QUEST_DONE setzen")

# ─────────────────────────────────────────────────────────────────────────────
# _on_interacted()
# ─────────────────────────────────────────────────────────────────────────────

func test_on_interacted_before_on_spawn_no_crash() -> void:
	var npc := _make_npc()
	# kein on_spawn() aufgerufen — _dialog ist null
	npc._on_interacted("talk_quest_npc", 1)
	assert_true(true, "_on_interacted() vor on_spawn() darf nicht crashen")

func test_on_interacted_wrong_action_id_ignored() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	npc._on_interacted("some_other_action", 1)
	assert_eq(npc._dialog.state, QuestNPCDialogController.NPCState.HAS_QUEST,
		"Falsche action_id darf den Dialog-State nicht ändern")

func test_on_interacted_correct_action_id_triggers_dialog() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	npc._on_interacted("talk_quest_npc", 1)
	assert_eq(npc._dialog.state, QuestNPCDialogController.NPCState.QUEST_ACTIVE,
		"talk_quest_npc Interaktion muss Dialog.on_interact() auslösen")

func test_on_interacted_reports_npc_talked_to_domain_event_with_real_peer_id() -> void:
	# ADR-021 (R-5): _peer_id war vorher ungenutzt — muss jetzt an
	# report_domain_event() durchgereicht werden, sonst kann ein Nicht-Host-
	# Spieler dieses TALK-Objective serverseitig nie erfüllen.
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	var mock_network := MockNetworkBridge.new()
	ctx._network = mock_network
	npc.on_spawn({}, ctx)
	npc._on_interacted("talk_quest_npc", 4)
	assert_eq(mock_network.reported_events.size(), 1,
		"_on_interacted() muss genau ein Domain-Event melden")
	assert_eq(mock_network.reported_events[0]["event_name"], "npc_talked_to")
	assert_eq(mock_network.reported_events[0]["payload"]["npc_id"], npc.npc_id)
	assert_eq(mock_network.reported_events[0]["peer_id"], 4,
		"Muss den echten peer_id melden, nicht Default 1")

func test_on_interacted_on_non_authority_still_updates_dialog_but_skips_reporting() -> void:
	## BUG-26 (Round 45→46): set_multiplayer_authority(2) bei unique_id=1
	## (kein Peer im Test) → is_multiplayer_authority() = false, simuliert den
	## lokalen Feedback-Aufruf auf einem Nicht-Host-Client (siehe
	## InteractableComponent._handle_completion(), ADR-020). Lokales Feedback
	## (Dialog) muss weiterhin laufen — nur das Domain-Event-Reporting darf
	## hier NICHT feuern, sonst zählt der Server (der denselben Hook über
	## resolve_and_dispatch_interaction() ein zweites Mal aufruft) doppelt.
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	var mock_network := MockNetworkBridge.new()
	ctx._network = mock_network
	npc.on_spawn({}, ctx)
	npc.set_multiplayer_authority(2)
	assert_false(npc.is_multiplayer_authority(), "Testvoraussetzung: NPC darf hier nicht die Autorität sein")

	npc._on_interacted("talk_quest_npc", 4)

	assert_eq(npc._dialog.state, QuestNPCDialogController.NPCState.QUEST_ACTIVE,
		"Lokales Dialog-Feedback muss auf Nicht-Autorität weiterhin laufen")
	assert_eq(mock_network.reported_events.size(), 0,
		"Auf Nicht-Autorität darf kein Domain-Event gemeldet werden (BUG-26)")

func test_on_interacted_authority_and_non_authority_together_report_exactly_once() -> void:
	## BUG-26 Regression: simuliert den vollen Round-Trip einer Nicht-Host-
	## Interaktion — einmal der lokale, wirkungslose Aufruf auf dem Client
	## (nicht Autorität), einmal der reale Aufruf auf der Autorität (z.B. über
	## resolve_and_dispatch_interaction()). Zusammen darf genau EIN Domain-Event
	## gemeldet werden, nicht zwei.
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	var mock_network := MockNetworkBridge.new()
	ctx._network = mock_network
	npc.on_spawn({}, ctx)

	npc.set_multiplayer_authority(2)
	npc._on_interacted("talk_quest_npc", 4)  # lokal auf Nicht-Host-Client — darf nicht zählen

	npc.set_multiplayer_authority(1)
	npc._on_interacted("talk_quest_npc", 4)  # erneut auf der Autorität — zählt genau einmal

	assert_eq(mock_network.reported_events.size(), 1,
		"Gesamter Round-Trip darf genau ein Domain-Event melden, kein Doppel-Count")

func test_on_interacted_without_network_bridge_does_not_crash() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	npc._on_interacted("talk_quest_npc", 1)
	assert_true(true, "_on_interacted() ohne NetworkBridge darf nicht crashen.")

# ─────────────────────────────────────────────────────────────────────────────
# on_despawn()
# ─────────────────────────────────────────────────────────────────────────────

func test_on_despawn_disconnects_quest_completed() -> void:
	var npc := _make_npc()
	var ctx := EntityContext.for_test()
	ctx._bus = _bus
	npc.on_spawn({}, ctx)
	npc.on_despawn()
	assert_false(
		_bus.quest().quest_completed.is_connected(npc._on_quest_completed),
		"on_despawn() muss quest_completed disconnecten"
	)

func test_on_despawn_without_prior_spawn_no_crash() -> void:
	var npc := _make_npc()
	npc.on_despawn()
	assert_true(true, "on_despawn() ohne vorheriges on_spawn() darf nicht crashen (_bus == null Guard)")
