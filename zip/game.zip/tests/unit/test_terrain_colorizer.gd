# res://tests/unit/test_terrain_colorizer.gd
extends GutTest

## Unit-Tests für TerrainColorizer.height_to_color() (stateless, reine Funktion).
##
## Test-Setup: max_height=98.0, sea_level=20.0 -> min_h=-2.0 (Konstante im
## Code) -> ratio = (h+2)/100, sl_ratio = 22/100 = 0.22. Damit ergeben sich
## sehr saubere Grenzwerte für jedes der sieben Bänder.
##
## Strategie GEGEN Lerp-Rundungsrisiko: für jede Bandgrenze wird exakt der
## Wert gewählt, bei dem der jeweilige lerp()-Faktor t=0 ist — an der Stelle
## liefert lerp() immer exakt die Startfarbe zurück, ganz ohne
## Fließkomma-Unschärfe. Nur EIN Test prüft einen echten Interior-Punkt
## (t=0.5), dessen erwarteter Wert vorher in Python nachgerechnet wurde
## (siehe Kommentar dort).
##
## Abgedeckt: alle sieben Farbbänder (inkl. beider Clamping-Enden), ein
## Lerp-Interior-Punkt, Konsistenz bei wiederholtem Aufruf (stateless).

const MAX_HEIGHT := 98.0
const SEA_LEVEL := 20.0
const GRASS := Color(0.3, 0.6, 0.25)  # beliebige Biom-Grasfarbe, ungleich dem Fallback-COL_GRASS

var _colorizer: TerrainColorizer


func before_each() -> void:
	_colorizer = TerrainColorizer.new()


func after_each() -> void:
	_colorizer = null


func _color(h: float) -> Color:
	return _colorizer.height_to_color(h, GRASS, MAX_HEIGHT, SEA_LEVEL)


# ─────────────────────────────────────────────
# Sieben Bänder, jeweils an einer t=0-Grenze (exakt, kein Lerp-Risiko)
# ─────────────────────────────────────────────

func test_deep_water_interior() -> void:
	assert_eq(_color(3.0), TerrainColorizer.COL_DEEP_WATER)  # ratio=0.05 < 0.11

func test_shallow_at_band_start() -> void:
	assert_eq(_color(9.0), TerrainColorizer.COL_SHALLOW)  # ratio=0.11, t=0 im shallow->sand-Lerp

func test_sand_at_band_start() -> void:
	assert_eq(_color(20.0), TerrainColorizer.COL_SAND)  # ratio=0.22=sl_ratio, t=0 im sand->grass-Lerp

func test_grass_at_band_start() -> void:
	assert_eq(_color(24.0), GRASS)  # ratio=0.26=sl_ratio+0.04, direkt grass_color (kein Lerp mehr)

func test_grass_interior() -> void:
	assert_eq(_color(38.0), GRASS)  # ratio=0.40, mitten im reinen Grass-Band

func test_hill_at_band_start() -> void:
	assert_eq(_color(53.0), GRASS)  # ratio=0.55, t=0 im grass->hill-Lerp -> exakt grass_color

func test_rock_at_band_start() -> void:
	assert_eq(_color(70.0), TerrainColorizer.COL_HILL)  # ratio=0.72, t=0 im hill->rock-Lerp

func test_snow_lerp_at_band_start() -> void:
	assert_eq(_color(86.0), TerrainColorizer.COL_ROCK)  # ratio=0.88, t=0 im rock->snow-Lerp

func test_full_snow_at_max_height() -> void:
	assert_eq(_color(98.0), TerrainColorizer.COL_SNOW)  # ratio=1.0, t=1 im rock->snow-Lerp


# ─────────────────────────────────────────────
# Clamping an beiden Enden
# ─────────────────────────────────────────────

func test_height_far_above_max_clamps_to_snow() -> void:
	assert_eq(_color(10000.0), TerrainColorizer.COL_SNOW)

func test_height_far_below_min_clamps_to_deep_water() -> void:
	assert_eq(_color(-10000.0), TerrainColorizer.COL_DEEP_WATER)


# ─────────────────────────────────────────────
# Ein echter Lerp-Interior-Punkt (Wert vorab in Python nachgerechnet)
# ─────────────────────────────────────────────

func test_shallow_to_sand_lerp_interior_point() -> void:
	# ratio=0.165 -> t=(0.165-0.11)/0.11=0.5 im shallow->sand-Band.
	var c := _color(14.5)
	assert_almost_eq(c.r, 0.47, 0.0005)
	assert_almost_eq(c.g, 0.595, 0.0005)
	assert_almost_eq(c.b, 0.6, 0.0005)


# ─────────────────────────────────────────────
# Stateless — wiederholter Aufruf liefert dasselbe Ergebnis
# ─────────────────────────────────────────────

func test_repeated_calls_are_consistent() -> void:
	var first := _color(38.0)
	var second := _color(38.0)
	assert_eq(first, second)
