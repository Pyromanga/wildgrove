## tests/unit/test_inventory_ui_signal.gd
## Regression-Tests für inventory_changed Signal-Signatur.
##
## Regression: InventoryUIController verband _on_inventory_changed(items) direkt —
## Signal hat Signatur (player_id: int, items: Array[Dictionary]),
## deshalb kam bei player_id != erwartet nie etwas an.

extends GutTest

var _inventory: InventorySystem

func before_each() -> void:
	_inventory = InventorySystem.new()
	_inventory.configure(ServiceDeps.from_dict({}))

func after_each() -> void:
	_inventory.on_cleanup()
	_inventory = null

func test_inventory_changed_signal_has_two_params() -> void:
	# Prüft dass das Signal player_id UND items liefert (nicht nur items).
	var received_player_id := [-1]
	var received_items: Array = [[]]

	_inventory.inventory_changed.connect(
		func(player_id: int, items: Array[Dictionary]) -> void:
			received_player_id[0] = player_id
			received_items[0]     = items
	)

	# Direkt den State setzen und Signal manuell auslösen
	_inventory.inventory_changed.emit(1, [{"id": "iron_ore", "name": "Eisenerz", "quantity": 3}])

	assert_eq(received_player_id[0], 1,
		"Signal muss player_id=1 liefern.")
	assert_eq((received_items[0] as Array).size(), 1,
		"Signal muss Items-Array liefern.")

func test_inventory_changed_player_id_filter() -> void:
	# Stellt sicher dass der Controller nur player_id==1 weiterverarbeitet.
	var player1_count := [0]
	var player2_count := [0]

	_inventory.inventory_changed.connect(
		func(player_id: int, _items: Array[Dictionary]) -> void:
			if player_id == 1:
				player1_count[0] += 1
			elif player_id == 2:
				player2_count[0] += 1
	)

	_inventory.inventory_changed.emit(1, [])
	_inventory.inventory_changed.emit(2, [])
	_inventory.inventory_changed.emit(1, [])

	assert_eq(player1_count[0], 2, "player_id==1 muss 2x empfangen werden.")
	assert_eq(player2_count[0], 1, "player_id==2 muss 1x empfangen werden.")

func test_inventory_changed_items_structure() -> void:
	# Prüft dass die Items-Dictionaries die erwarteten Keys haben.
	var received: Array = [[]]
	_inventory.inventory_changed.connect(
		func(_pid: int, items: Array[Dictionary]) -> void:
			received[0] = items
	)

	var test_items: Array[Dictionary] = [
		{"id": "log_normal", "name": "Holz", "quantity": 5},
		{"id": "iron_ore",   "name": "Eisenerz", "quantity": 2},
	]
	_inventory.inventory_changed.emit(1, test_items)

	var received_arr: Array = received[0]
	assert_eq(received_arr.size(), 2, "2 Items erwartet.")
	assert_true(received_arr[0].has("id"),       "Item muss 'id' haben.")
	assert_true(received_arr[0].has("quantity"), "Item muss 'quantity' haben.")
