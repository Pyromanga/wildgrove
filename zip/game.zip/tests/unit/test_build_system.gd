# res://tests/unit/test_build_system.gd
extends GutTest

## Tests für die reine Bau-Logik: BuildGrid, BuildRegistry, BuildPlacementRules,
## BuildPieceDefinition. (Engine-freie Klassen — kein SceneTree nötig.)

const FLOOR   := BuildPieceDefinition.Kind.FLOOR
const WALL    := BuildPieceDefinition.Kind.WALL
const ROOF    := BuildPieceDefinition.Kind.ROOF
const DOOR    := BuildPieceDefinition.Kind.DOOR
const WINDOW  := BuildPieceDefinition.Kind.WINDOW
const STAIRS  := BuildPieceDefinition.Kind.STAIRS

var _registry: BuildRegistry
var _floor_def: BuildPieceDefinition
var _wall_def: BuildPieceDefinition
var _roof_def: BuildPieceDefinition
var _door_def: BuildPieceDefinition
var _window_def: BuildPieceDefinition
var _stairs_def: BuildPieceDefinition

func before_each() -> void:
	_registry = BuildRegistry.new()
	_floor_def = BuildPieceDefinition.new()
	_floor_def.id = "wood_floor"
	_floor_def.kind = FLOOR
	_floor_def.cost = {"log_normal": 4}
	_wall_def = BuildPieceDefinition.new()
	_wall_def.id = "wood_wall"
	_wall_def.kind = WALL
	_wall_def.cost = {"log_normal": 5, "stone": 3}
	_wall_def.refund_ratio = 0.5
	_roof_def = BuildPieceDefinition.new()
	_roof_def.id = "wood_roof"
	_roof_def.kind = ROOF
	_roof_def.height = 1.4
	_roof_def.cost = {"log_normal": 4}
	_door_def = BuildPieceDefinition.new()
	_door_def.id = "wood_door"
	_door_def.kind = DOOR
	_door_def.height = 2.5
	_door_def.thickness = 0.2
	_door_def.skirt = 0.8
	_door_def.cost = {"log_normal": 3}
	_window_def = BuildPieceDefinition.new()
	_window_def.id = "wood_window"
	_window_def.kind = WINDOW
	_window_def.height = 2.5
	_window_def.thickness = 0.18
	_window_def.skirt = 0.8
	_window_def.cost = {"log_normal": 2}
	_stairs_def = BuildPieceDefinition.new()
	_stairs_def.id = "wood_stairs"
	_stairs_def.kind = STAIRS
	_stairs_def.height = BuildGrid.LEVEL_HEIGHT
	_stairs_def.cost = {"log_normal": 5}

func _flat(h: float) -> Callable:
	return func(_x: float, _z: float) -> float: return h

func _add_floor(cell: Vector2i, y: float) -> void:
	_registry.add({"key": BuildGrid.floor_key(cell), "piece_id": "wood_floor",
		"kind": FLOOR, "x": 0.0, "y": y, "z": 0.0, "yaw": 0.0, "owner": ""})

# ── BuildGrid ───────────────────────────────────

func test_floor_snaps_to_cell_center() -> void:
	var s := BuildGrid.snap(FLOOR, Vector3(2.9, 0, 5.1), 0)
	assert_eq(s["cell"], Vector2i(1, 2))
	assert_eq(s["center"], Vector2(3.0, 5.0))
	assert_eq(s["key"], "F_1_2")

func test_floor_snap_handles_negative_coordinates() -> void:
	var s := BuildGrid.snap(FLOOR, Vector3(-0.5, 0, -0.5), 0)
	assert_eq(s["cell"], Vector2i(-1, -1))
	assert_eq(s["center"], Vector2(-1.0, -1.0))

func test_floor_ignores_rotation() -> void:
	var a := BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0)
	var b := BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 3)
	assert_eq(a["key"], b["key"])

func test_wall_even_rotation_uses_x_axis_edge() -> void:
	var s := BuildGrid.snap(WALL, Vector3(2.9, 0, 3.1), 0)
	assert_eq(s["axis"], 0)
	# z=3.1 → nächste Kante z=4 (roundi(1.55)=2 → 2*2=4); x=2.9 → Zelle 1 → Mitte x=3.
	assert_eq(s["center"], Vector2(3.0, 4.0))
	assert_eq(s["yaw"], 0.0)

func test_wall_odd_rotation_uses_z_axis_edge() -> void:
	var s := BuildGrid.snap(WALL, Vector3(2.9, 0, 3.1), 1)
	assert_eq(s["axis"], 1)
	# x=2.9 → nächste Kante x=2 (roundi(1.45)=1 → 2); z=3.1 → Zelle 1 → Mitte z=3.
	assert_eq(s["center"], Vector2(2.0, 3.0))
	assert_almost_eq(s["yaw"], PI * 0.5, 0.0001)

func test_wall_negative_rotation_steps_are_valid() -> void:
	assert_eq(BuildGrid.snap(WALL, Vector3(1, 0, 1), -1)["axis"], 1)
	assert_eq(BuildGrid.snap(WALL, Vector3(1, 0, 1), -2)["axis"], 0)

func test_floor_corners_are_four_terrain_lattice_points() -> void:
	var corners := BuildGrid.floor_corner_lattice(Vector2i(3, -1))
	assert_eq(corners.size(), 4)
	assert_true(corners.has(Vector2i(3, -1)))
	assert_true(corners.has(Vector2i(4, 0)))

func test_wall_endpoints_match_axis() -> void:
	var e0 := BuildGrid.wall_endpoints(0, 1, 2)
	assert_eq(e0[0], Vector2(2, 4))
	assert_eq(e0[1], Vector2(4, 4))
	var e1 := BuildGrid.wall_endpoints(1, 1, 2)
	assert_eq(e1[1], Vector2(2, 6))

func test_wall_adjacent_cells() -> void:
	var a0 := BuildGrid.cells_adjacent_to_wall(0, 1, 2)
	assert_true(a0.has(Vector2i(1, 2)) and a0.has(Vector2i(1, 1)))
	var a1 := BuildGrid.cells_adjacent_to_wall(1, 1, 2)
	assert_true(a1.has(Vector2i(1, 2)) and a1.has(Vector2i(0, 2)))

func test_distance_to_wall_segment() -> void:
	# Wand entlang X von (2,4) bis (4,4).
	assert_almost_eq(BuildGrid.distance_to_wall(Vector2(3, 5), 0, 1, 2), 1.0, 0.0001)
	assert_almost_eq(BuildGrid.distance_to_wall(Vector2(6, 4), 0, 1, 2), 2.0, 0.0001)  # jenseits des Endes

func test_quantize_y_rounds_to_step() -> void:
	assert_eq(BuildGrid.quantize_y(1.13), 1.25)
	assert_eq(BuildGrid.quantize_y(1.10), 1.0)

# ── BuildRegistry ───────────────────────────────

func test_registry_add_and_get() -> void:
	assert_true(_registry.add({"key": "F_0_0", "piece_id": "wood_floor", "x": 1.0, "y": 0.0, "z": 1.0}))
	assert_true(_registry.has_key("F_0_0"))
	assert_eq(_registry.get_record("F_0_0")["piece_id"], "wood_floor")
	assert_eq(_registry.count(), 1)

func test_registry_rejects_duplicate_and_empty_key() -> void:
	_registry.add({"key": "F_0_0", "piece_id": "a", "x": 0, "y": 0, "z": 0})
	assert_false(_registry.add({"key": "F_0_0", "piece_id": "b", "x": 0, "y": 0, "z": 0}))
	assert_false(_registry.add({"piece_id": "b"}))
	assert_eq(_registry.count(), 1)

func test_registry_get_record_returns_copy() -> void:
	_registry.add({"key": "F_0_0", "piece_id": "a", "x": 0, "y": 0, "z": 0})
	var rec := _registry.get_record("F_0_0")
	rec["piece_id"] = "manipuliert"
	assert_eq(_registry.get_record("F_0_0")["piece_id"], "a", "Änderungen an der Kopie dürfen die Registry nicht verändern.")

func test_registry_remove_returns_record() -> void:
	_registry.add({"key": "F_0_0", "piece_id": "a", "x": 0, "y": 0, "z": 0})
	assert_eq(_registry.remove("F_0_0")["piece_id"], "a")
	assert_false(_registry.has_key("F_0_0"))
	assert_true(_registry.remove("F_0_0").is_empty())

func test_registry_finds_adjacent_floors_for_wall() -> void:
	_add_floor(Vector2i(1, 1), 2.0)
	# Wand Achse 0 bei (1, 2) grenzt an Zellen (1,2) und (1,1) → findet (1,1).
	assert_eq(_registry.floors_adjacent_to_wall(0, 1, 2).size(), 1)
	assert_eq(_registry.floors_adjacent_to_wall(0, 5, 5).size(), 0)

func test_registry_area_occupied() -> void:
	_registry.add({"key": "F_0_0", "piece_id": "a", "x": 10.0, "y": 0, "z": 10.0})
	assert_true(_registry.is_area_occupied(10.0, 10.0, 1.0))
	assert_true(_registry.is_area_occupied(12.0, 10.0, 1.0), "Toleranz: eine Zelle Puffer.")
	assert_false(_registry.is_area_occupied(40.0, 40.0, 3.5))

func test_registry_records_in_chunk() -> void:
	_registry.add({"key": "a", "piece_id": "x", "x": 5.0, "y": 0, "z": 5.0})      # Chunk (0,0)
	_registry.add({"key": "b", "piece_id": "x", "x": 70.0, "y": 0, "z": 0.0})     # Chunk (1,0)
	var in_zero := _registry.records_in_chunk(Vector2i(0, 0), 64.0)
	assert_eq(in_zero.size(), 1)
	assert_eq(in_zero[0]["key"], "a")

func test_chunk_of_matches_chunk_manager_convention() -> void:
	# ChunkManager: Vector2i(round(x/64), round(z/64)). 31.9 → 0, 32.1 → 1.
	assert_eq(BuildRegistry.chunk_of(31.9, 0.0, 64.0), Vector2i(0, 0))
	assert_eq(BuildRegistry.chunk_of(32.1, 0.0, 64.0), Vector2i(1, 0))
	assert_eq(BuildRegistry.chunk_of(-40.0, 0.0, 64.0), Vector2i(-1, 0))

func test_registry_save_roundtrip_via_var_to_str() -> void:
	_registry.add({"key": "F_1_2", "piece_id": "wood_floor", "kind": FLOOR,
		"x": 3.0, "y": 1.25, "z": 5.0, "yaw": 0.0, "owner": "p1"})
	var restored := BuildRegistry.new()
	restored.load_save(str_to_var(var_to_str(_registry.to_save())))
	assert_eq(restored.count(), 1)
	assert_eq(restored.get_record("F_1_2")["y"], 1.25)

func test_registry_load_skips_invalid_entries() -> void:
	_registry.load_save([
		{"key": "ok", "piece_id": "a", "x": 0, "y": 0, "z": 0},
		{"key": "", "piece_id": "a", "x": 0, "y": 0, "z": 0},
		{"key": "nopiece", "x": 0, "y": 0, "z": 0},
		{"key": "nopos", "piece_id": "a"},
		"müll", 42,
	])
	assert_eq(_registry.count(), 1)
	_registry.load_save("kein array")
	assert_eq(_registry.count(), 0)

# ── BuildPieceDefinition ────────────────────────

func test_refund_rounds_down_and_never_exceeds_cost() -> void:
	assert_eq(_wall_def.refund_for("log_normal"), 2)   # 5 * 0.5 = 2.5 → 2
	assert_eq(_wall_def.refund_for("stone"), 1)        # 3 * 0.5 = 1.5 → 1
	assert_eq(_wall_def.refund_for("gold"), 0)
	_wall_def.refund_ratio = 1.0
	assert_eq(_wall_def.refund_for("log_normal"), 5)

# ── BuildPlacementRules: Boden ──────────────────

func test_floor_on_flat_ground_is_valid_and_levels_terrain() -> void:
	var layer := TerrainEditLayer.new()
	var snap := BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0)
	var res := BuildPlacementRules.check(_floor_def, snap, _registry, _flat(1.0), layer)
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0)
	assert_true(res["level"]["ok"])
	assert_eq((res["level"]["changes"] as Dictionary).size(), 4)
	assert_almost_eq(res["level"]["target_y"], 1.0 - BuildPlacementRules.FLOOR_LIFT, 0.0001)

func test_floor_lift_survives_terrain_quantization() -> void:
	# Auf ebenem Gelände muss das Einebnen ein ECHTES Delta erzeugen (Terrain knapp unter dem
	# Boden), sonst wären Bodenoberkante und Gelände koplanar → Flackern (Z-Fighting).
	var layer := TerrainEditLayer.new()
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, _flat(1.0), layer)
	var changed := layer.apply_changes(res["level"]["changes"])
	assert_eq(changed.size(), 4)
	assert_lt(layer.get_delta_lattice(0, 0), 0.0)

func test_floor_height_is_quantized_mean_of_corners() -> void:
	var ground := func(x: float, _z: float) -> float: return 1.0 if x < 1.0 else 2.0
	# Zelle (0,0): Ecken x=0 (2 Stück, h=1) und x=2 (2 Stück, h=2) → Mittel 1.5.
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, ground, null)
	assert_true(res["ok"])
	assert_eq(res["y"], 1.5)

func test_floor_without_layer_skips_leveling() -> void:
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, _flat(0.0), null)
	assert_true(res["ok"])
	assert_true((res["level"] as Dictionary).is_empty())

func test_floor_rejected_when_occupied() -> void:
	_add_floor(Vector2i(0, 0), 0.0)
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, _flat(0.0), null)
	assert_false(res["ok"])
	assert_eq(res["reason"], "occupied")

func test_floor_rejected_without_ground() -> void:
	var no_ground := func(_x: float, _z: float) -> float: return NAN
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, no_ground, null)
	assert_false(res["ok"])
	assert_eq(res["reason"], "no_ground")

func test_floor_rejected_when_terrain_too_steep_to_level() -> void:
	# Ecken sehr unterschiedlich hoch → Mittelwert liegt >4 m von einer Ecke entfernt.
	var ground := func(x: float, _z: float) -> float: return 0.0 if x < 1.0 else 12.0
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, ground, TerrainEditLayer.new())
	assert_false(res["ok"])
	assert_eq(res["reason"], "too_steep")

# ── BuildPlacementRules: Wand ───────────────────

func test_freestanding_wall_on_flat_ground_is_valid() -> void:
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0), _registry, _flat(1.1))
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0)   # 1.1 → Raster 0.25 → 1.0

func test_wall_on_floor_uses_floor_top() -> void:
	_add_floor(Vector2i(0, 1), 3.0)
	# Wand Achse 0 bei (0, 2)? Grenzt an Zellen (0,2) und (0,1) → Boden (0,1) trägt sie.
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0), _registry, _flat(0.0))
	assert_true(res["ok"])
	assert_eq(res["y"], 3.0)

func test_wall_on_two_floors_uses_higher_one() -> void:
	_add_floor(Vector2i(0, 1), 3.0)
	_add_floor(Vector2i(0, 2), 3.5)
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0), _registry, _flat(0.0))
	assert_eq(res["y"], 3.5)

func test_wall_rejected_when_occupied() -> void:
	var snap := BuildGrid.snap(WALL, Vector3(1, 0, 4), 0)
	_registry.add({"key": snap["key"], "piece_id": "wood_wall", "x": 0, "y": 0, "z": 0})
	var res := BuildPlacementRules.check(_wall_def, snap, _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "occupied")

func test_freestanding_wall_rejected_on_steep_slope() -> void:
	var ground := func(x: float, _z: float) -> float: return x * 2.0   # 4 m Unterschied über 2 m
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0), _registry, ground)
	assert_false(res["ok"])
	assert_eq(res["reason"], "too_steep")

func test_wall_takes_highest_ground_point_as_base() -> void:
	# Wand liegt zwischen x=0 und x=2: linkes Ende/Mitte auf 0, rechtes Ende auf 1.
	var ground := func(x: float, _z: float) -> float: return 0.0 if x < 1.5 else 1.0
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0), _registry, ground)
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0)

func test_wall_rejected_when_player_stands_in_it() -> void:
	var snap := BuildGrid.snap(WALL, Vector3(1, 0, 4), 0)   # Wand von (0,4) bis (2,4)
	var res := BuildPlacementRules.check(_wall_def, snap, _registry, _flat(0.0), null, Vector3(1.0, 0.0, 4.2))
	assert_false(res["ok"])
	assert_eq(res["reason"], "player_in_way")

func test_wall_ok_when_player_is_clear() -> void:
	var snap := BuildGrid.snap(WALL, Vector3(1, 0, 4), 0)
	var res := BuildPlacementRules.check(_wall_def, snap, _registry, _flat(0.0), null, Vector3(1.0, 0.0, 6.0))
	assert_true(res["ok"])

func test_reason_text_exists_for_all_codes() -> void:
	for code in ["occupied", "no_ground", "too_steep", "unsupported", "player_in_way", "in_water", "too_far", "no_materials", "unknown_piece", "coop_unsupported"]:
		assert_ne(BuildPlacementRules.reason_text(code), "Bauen nicht möglich.", "Code '%s' braucht einen eigenen Text." % code)

# ── Wasser ──────────────────────────────────────

func test_floor_rejected_in_water() -> void:
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry,
		_flat(-1.0), null, Vector3(NAN, NAN, NAN), _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "in_water")

func test_floor_at_shoreline_is_still_too_wet() -> void:
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry,
		_flat(0.1), null, Vector3(NAN, NAN, NAN), _flat(0.0))
	assert_eq(res["reason"], "in_water", "Knapp über dem Spiegel zählt noch als Ufer (MIN_DRY_CLEARANCE).")

func test_floor_on_dry_land_is_fine_with_water_level() -> void:
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry,
		_flat(2.0), null, Vector3(NAN, NAN, NAN), _flat(0.0))
	assert_true(res["ok"])

func test_freestanding_wall_rejected_in_water() -> void:
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0), _registry,
		_flat(-0.5), null, Vector3(NAN, NAN, NAN), _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "in_water")

func test_default_water_level_disables_the_check() -> void:
	# Ohne water_level_fn (Default: ungültiges Callable) verhalten sich alle bisherigen
	# Aufrufe wie vorher — keine Wasserprüfung.
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry, _flat(-5.0), null)
	assert_true(res["ok"])

func test_river_water_level_blocks_building_above_global_sea_level() -> void:
	# Fluss liegt (BUGFIX 2026-09-20) lokal höher als der globale Meeresspiegel — Bauen muss
	# trotzdem blockieren, wenn die Bauhöhe unter DIESEM lokalen Spiegel liegt.
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0), _registry,
		_flat(3.0), null, Vector3(NAN, NAN, NAN), _flat(3.5))
	assert_false(res["ok"])
	assert_eq(res["reason"], "in_water")

# ── Geometrie (gemeinsam für Bauteil und Geist) ──

func test_floor_box_top_is_at_origin() -> void:
	_floor_def.height = 0.3
	_floor_def.skirt = 0.6
	var size := _floor_def.get_box_size(BuildGrid.CELL)
	var center := _floor_def.get_box_center()
	assert_eq(size, Vector3(BuildGrid.CELL, 0.9, BuildGrid.CELL))
	assert_almost_eq(center.y + size.y * 0.5, 0.0, 0.0001, "Oberkante des Bodens liegt bei y=0 (Bauhöhe).")

func test_wall_box_spans_skirt_to_height() -> void:
	_wall_def.height = 2.5
	_wall_def.skirt = 0.8
	_wall_def.thickness = 0.25
	var size := _wall_def.get_box_size(BuildGrid.CELL)
	var center := _wall_def.get_box_center()
	assert_eq(size, Vector3(BuildGrid.CELL, 3.3, 0.25))
	assert_almost_eq(center.y - size.y * 0.5, -0.8, 0.0001, "Unterkante = -skirt")
	assert_almost_eq(center.y + size.y * 0.5, 2.5, 0.0001, "Oberkante = +height")

# ── Ebenen (storey) ─────────────────────────────

func _add_wall(axis: int, cx: int, cz: int, y: float, storey: int = 0) -> void:
	_registry.add({"key": BuildGrid.wall_key(axis, cx, cz, storey), "piece_id": "wood_wall",
		"kind": WALL, "x": 0.0, "y": y, "z": 0.0, "yaw": 0.0, "owner": "", "storey": storey})

func _add_floor_at(cell: Vector2i, y: float, storey: int) -> void:
	_registry.add({"key": BuildGrid.floor_key(cell, storey), "piece_id": "wood_floor",
		"kind": FLOOR, "x": 0.0, "y": y, "z": 0.0, "yaw": 0.0, "owner": "", "storey": storey})

func test_storey_zero_keys_are_unchanged() -> void:
	assert_eq(BuildGrid.floor_key(Vector2i(2, 3)), "F_2_3")
	assert_eq(BuildGrid.wall_key(1, -1, 4), "W1_-1_4")
	assert_eq(BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0)["key"], "F_0_0")

func test_upper_storey_keys_get_suffix() -> void:
	assert_eq(BuildGrid.floor_key(Vector2i(2, 3), 1), "F_2_3_L1")
	assert_eq(BuildGrid.wall_key(0, -1, 4, 2), "W0_-1_4_L2")
	assert_eq(BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1)["key"], "W0_0_2_L1")

func test_snap_clamps_storey() -> void:
	assert_eq(BuildGrid.snap(FLOOR, Vector3.ZERO, 0, 99)["storey"], BuildGrid.MAX_STOREY)
	assert_eq(BuildGrid.snap(FLOOR, Vector3.ZERO, 0, -3)["storey"], 0)

func test_parse_key_roundtrip() -> void:
	var f := BuildGrid.parse_key(BuildGrid.floor_key(Vector2i(-2, 5), 2))
	assert_eq(f["kind"], FLOOR)
	assert_eq(f["x"], -2)
	assert_eq(f["z"], 5)
	assert_eq(f["storey"], 2)
	var w := BuildGrid.parse_key(BuildGrid.wall_key(1, 3, -4))
	assert_eq(w["kind"], WALL)
	assert_eq(w["axis"], 1)
	assert_eq(w["storey"], 0)
	assert_true(BuildGrid.parse_key("Quatsch").is_empty())

func test_upper_floor_needs_wall_below() -> void:
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0, 1), _registry, _flat(0.0), null)
	assert_false(res["ok"])
	assert_eq(res["reason"], "unsupported")

func test_upper_floor_rests_on_wall_top() -> void:
	_add_wall(0, 0, 0, 1.0)   # Wand auf Kante z=0 der Zelle (0,0)
	var res := BuildPlacementRules.check(_floor_def, BuildGrid.snap(FLOOR, Vector3(1, 0, 1), 0, 1), _registry, _flat(0.0), null)
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0 + BuildGrid.LEVEL_HEIGHT)

func test_upper_wall_needs_support() -> void:
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1), _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "unsupported")

func test_upper_wall_stacks_on_wall_below() -> void:
	_add_wall(0, 0, 2, 0.0)
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1), _registry, _flat(0.0))
	assert_true(res["ok"])
	assert_eq(res["y"], BuildGrid.LEVEL_HEIGHT)

func test_upper_wall_stands_on_upper_floor() -> void:
	_add_floor_at(Vector2i(0, 1), 2.5, 1)
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1), _registry, _flat(0.0))
	assert_true(res["ok"])
	assert_eq(res["y"], 2.5)

func test_upper_wall_ignores_player_standing_below() -> void:
	_add_wall(0, 0, 2, 0.0)
	# Spieler steht am Boden direkt unter der oberen Wand → darf sie nicht blockieren.
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1), _registry,
		_flat(0.0), null, Vector3(1.0, -3.0, 4.1))
	assert_true(res["ok"])

func test_upper_wall_blocked_by_player_at_same_height() -> void:
	_add_floor_at(Vector2i(0, 1), 2.5, 1)
	var res := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1), _registry,
		_flat(0.0), null, Vector3(1.0, 2.5, 4.1))
	assert_false(res["ok"])
	assert_eq(res["reason"], "player_in_way")

func test_upper_pieces_key_is_separate_from_ground() -> void:
	_add_wall(0, 0, 2, 0.0)
	var upper := BuildPlacementRules.check(_wall_def, BuildGrid.snap(WALL, Vector3(1, 0, 4), 0, 1), _registry, _flat(0.0))
	assert_true(upper["ok"], "Ebene 1 darf trotz belegter Ebene 0 frei sein.")

func test_has_dependents_for_wall_with_wall_above() -> void:
	_add_wall(0, 0, 2, 0.0)
	assert_false(_registry.has_dependents(BuildGrid.wall_key(0, 0, 2)))
	_add_wall(0, 0, 2, 2.5, 1)
	assert_true(_registry.has_dependents(BuildGrid.wall_key(0, 0, 2)))

func test_has_dependents_for_wall_with_floor_above() -> void:
	_add_wall(0, 0, 2, 0.0)
	_add_floor_at(Vector2i(0, 2), 2.5, 1)
	assert_true(_registry.has_dependents(BuildGrid.wall_key(0, 0, 2)))

func test_has_dependents_for_upper_floor_with_walls() -> void:
	_add_floor_at(Vector2i(0, 0), 2.5, 1)
	assert_false(_registry.has_dependents(BuildGrid.floor_key(Vector2i(0, 0), 1)))
	_add_wall(0, 0, 0, 2.5, 1)
	assert_true(_registry.has_dependents(BuildGrid.floor_key(Vector2i(0, 0), 1)))

func test_ground_floor_never_has_dependents() -> void:
	_add_floor(Vector2i(0, 0), 1.0)
	_add_wall(0, 0, 0, 1.0)
	assert_false(_registry.has_dependents(BuildGrid.floor_key(Vector2i(0, 0))))

func test_supports_others_has_reason_text() -> void:
	assert_ne(BuildPlacementRules.reason_text("supports_others"), "Bauen nicht möglich.")

# ── Dach (ROOF) ──────────────────────────────────

func test_roof_key_matches_floor_style() -> void:
	assert_eq(BuildGrid.roof_key(Vector2i(2, 3)), "R_2_3")
	assert_eq(BuildGrid.roof_key(Vector2i(2, 3), 1), "R_2_3_L1")

func test_roof_snap_axis_follows_rotation_like_walls() -> void:
	var even := BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0)
	assert_eq(even["axis"], 0)
	assert_eq(even["yaw"], 0.0)
	assert_eq(even["key"], "R_0_0")
	var odd := BuildGrid.snap(ROOF, Vector3(1, 0, 1), 1)
	assert_eq(odd["axis"], 1)
	assert_almost_eq(float(odd["yaw"]), PI * 0.5, 0.0001)
	# Achse ändert nichts am Schlüssel — pro Zelle/Ebene passt ohnehin nur ein Dach.
	assert_eq(odd["key"], "R_0_0")

func test_roof_snap_respects_storey() -> void:
	assert_eq(BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0, 1)["key"], "R_0_0_L1")

func test_roof_parse_key_roundtrip() -> void:
	var r := BuildGrid.parse_key(BuildGrid.roof_key(Vector2i(-2, 5), 1))
	assert_eq(r["kind"], ROOF)
	assert_eq(r["axis"], -1)
	assert_eq(r["x"], -2)
	assert_eq(r["z"], 5)
	assert_eq(r["storey"], 1)

func test_roof_is_roof_flag() -> void:
	assert_true(_roof_def.is_roof())
	assert_false(_roof_def.is_wall())
	assert_false(_roof_def.is_floor())

func test_roof_box_center_is_half_height() -> void:
	_roof_def.height = 1.4
	var size := _roof_def.get_box_size(BuildGrid.CELL)
	var center := _roof_def.get_box_center()
	assert_eq(size, Vector3(BuildGrid.CELL, 1.4, BuildGrid.CELL))
	assert_almost_eq(center.y, 0.7, 0.0001)

func test_roof_mesh_has_one_surface() -> void:
	var mesh := BuildPieceDefinition.build_roof_mesh(BuildGrid.CELL, 1.4)
	assert_eq(mesh.get_surface_count(), 1)
	# 3 Quads (2 Dachflächen + Unterseite, je 2 Dreiecke = 6 Punkte) + 2 Giebel-Dreiecke
	# (3 Punkte) = 3*6 + 2*3 = 24 Vertices (nicht indiziert, SurfaceTool.commit() ohne
	# index_array).
	assert_eq(mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX].size(), 24)

func test_roof_rejected_without_walls() -> void:
	var res := BuildPlacementRules.check(_roof_def, BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0), _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "unsupported")

func test_roof_rests_on_wall_top_of_same_storey() -> void:
	_add_wall(0, 0, 0, 0.0)   # Wand auf Kante z=0 der Zelle (0,0), Ebene 0
	var res := BuildPlacementRules.check(_roof_def, BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0), _registry, _flat(0.0))
	assert_true(res["ok"])
	assert_eq(res["y"], BuildGrid.LEVEL_HEIGHT)

func test_roof_uses_highest_surrounding_wall() -> void:
	_add_wall(0, 0, 0, 0.0)
	_add_wall(1, 0, 0, 0.5)   # höhere Wand auf Kante x=0
	var res := BuildPlacementRules.check(_roof_def, BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0), _registry, _flat(0.0))
	assert_true(res["ok"])
	assert_eq(res["y"], 0.5 + BuildGrid.LEVEL_HEIGHT)

func test_roof_needs_wall_of_same_storey_not_below() -> void:
	_add_wall(0, 0, 0, 0.0, 0)   # Wand auf Ebene 0
	var res := BuildPlacementRules.check(_roof_def, BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0, 1), _registry, _flat(0.0))
	assert_false(res["ok"], "Dach auf Ebene 1 braucht eine Wand AUF Ebene 1, nicht Ebene 0.")
	assert_eq(res["reason"], "unsupported")

func test_roof_rejected_when_occupied() -> void:
	_registry.add({"key": "R_0_0", "piece_id": "wood_roof", "kind": ROOF, "x": 0.0, "y": 0.0, "z": 0.0, "owner": ""})
	var res := BuildPlacementRules.check(_roof_def, BuildGrid.snap(ROOF, Vector3(1, 0, 1), 0), _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "occupied")

func test_roof_never_has_dependents() -> void:
	_add_wall(0, 0, 0, 0.0)
	_registry.add({"key": "R_0_0", "piece_id": "wood_roof", "kind": ROOF, "x": 0.0, "y": BuildGrid.LEVEL_HEIGHT, "z": 0.0, "owner": ""})
	assert_false(_registry.has_dependents("R_0_0"))
	assert_false(_registry.has_dependents(BuildGrid.roof_key(Vector2i(0, 0), 2)), "Auch auf oberen Ebenen: unbekannter Schlüssel → false, kein Absturz.")

# ── Tür/Fenster (DOOR/WINDOW) — wandartig, teilen sich den Schlüsselraum mit WALL ──

func test_door_and_window_snap_like_a_wall() -> void:
	var w := BuildGrid.snap(WALL, Vector3(2.9, 0, 3.1), 0)
	var d := BuildGrid.snap(DOOR, Vector3(2.9, 0, 3.1), 0)
	var n := BuildGrid.snap(WINDOW, Vector3(2.9, 0, 3.1), 0)
	assert_eq(d["key"], w["key"])
	assert_eq(n["key"], w["key"])
	assert_eq(d["kind"], DOOR)
	assert_eq(n["kind"], WINDOW)
	assert_eq(d["center"], w["center"])
	assert_eq(d["yaw"], w["yaw"])

func test_door_is_wall_like_but_not_wall() -> void:
	assert_true(_door_def.is_wall_like())
	assert_true(_window_def.is_wall_like())
	assert_false(_door_def.is_wall())
	assert_false(_window_def.is_wall())

func test_door_is_door_flag() -> void:
	assert_true(_door_def.is_door())
	assert_true(_window_def.is_window())
	assert_false(_door_def.is_stairs())
	assert_false(_window_def.is_door())

func test_door_and_wall_on_same_edge_are_mutually_exclusive() -> void:
	var snap := BuildGrid.snap(WALL, Vector3(1, 0, 4), 0)
	_registry.add({"key": snap["key"], "piece_id": "wood_wall", "x": 0, "y": 0, "z": 0})
	var res := BuildPlacementRules.check(_door_def, BuildGrid.snap(DOOR, Vector3(1, 0, 4), 0), _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "occupied")

func test_freestanding_door_uses_wall_placement_rules() -> void:
	var res := BuildPlacementRules.check(_door_def, BuildGrid.snap(DOOR, Vector3(1, 0, 4), 0), _registry, _flat(1.1))
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0)

func test_door_supports_floor_above_like_a_wall() -> void:
	# has_dependents() liest den Kind aus dem SCHLÜSSEL (parse_key), nicht aus piece_id —
	# eine Tür an einer Kante trägt strukturell genauso wie eine Wand.
	var key := BuildGrid.wall_key(0, 0, 2)
	_registry.add({"key": key, "piece_id": "wood_door", "kind": DOOR, "x": 0.0, "y": 0.0, "z": 0.0, "yaw": 0.0, "owner": ""})
	_add_floor_at(Vector2i(0, 2), 2.5, 1)
	assert_true(_registry.has_dependents(key))

func test_door_boxes_leave_a_walkable_gap_at_the_base() -> void:
	var boxes := _door_def.get_door_boxes(BuildGrid.CELL)
	assert_eq(boxes.size(), 3, "2 Pfosten + Sturz (Tür niedriger als Wand).")
	for b: Dictionary in boxes:
		var size: Vector3 = b["size"]
		var center: Vector3 = b["center"]
		var half_x: float = size.x * 0.5
		# Keine Box darf die Mittelachse (x=0) am Boden (y nahe 0) überdecken — dort ist die
		# Öffnung, durch die man gehen können muss.
		if absf(center.y) < 0.5:
			assert_true(center.x - half_x > -0.01 or center.x + half_x < 0.01,
				"Box '%s' reicht in die Türöffnung hinein." % [b])

func test_window_boxes_have_sill_jambs_and_lintel() -> void:
	var boxes := _window_def.get_window_boxes(BuildGrid.CELL)
	assert_eq(boxes.size(), 4, "2 Pfosten + Brüstung + Sturz.")

func test_framed_mesh_combines_all_boxes() -> void:
	var boxes := _door_def.get_door_boxes(BuildGrid.CELL)
	var mesh := BuildPieceDefinition.build_framed_mesh(boxes)
	assert_eq(mesh.get_surface_count(), 1)
	# Jede Box = 6 Quads × 6 Punkte (2 Dreiecke, nicht indiziert) = 36 Vertices.
	assert_eq(mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX].size(), boxes.size() * 36)

# ── Treppe (STAIRS) ─────────────────────────────

func test_stairs_key_matches_floor_style() -> void:
	assert_eq(BuildGrid.stairs_key(Vector2i(2, 3)), "T_2_3")
	assert_eq(BuildGrid.stairs_key(Vector2i(2, 3), 1), "T_2_3_L1")

func test_stairs_snap_uses_full_rotation_for_facing() -> void:
	var s0 := BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0)
	var s1 := BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 1)
	var s2 := BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 2)
	var s3 := BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 3)
	assert_eq(s0["axis"], 0)
	assert_eq(s1["axis"], 1)
	assert_eq(s2["axis"], 2)
	assert_eq(s3["axis"], 3)
	assert_almost_eq(float(s1["yaw"]), PI * 0.5, 0.0001)
	assert_almost_eq(float(s2["yaw"]), PI, 0.0001)
	# Achse ändert nichts am Schlüssel — pro Zelle/Ebene passt ohnehin nur eine Treppe.
	assert_eq(s0["key"], "T_0_0")
	assert_eq(s3["key"], "T_0_0")

func test_stairs_snap_respects_storey() -> void:
	assert_eq(BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0, 1)["key"], "T_0_0_L1")

func test_stairs_parse_key_roundtrip() -> void:
	var t := BuildGrid.parse_key(BuildGrid.stairs_key(Vector2i(-2, 5), 1))
	assert_eq(t["kind"], STAIRS)
	assert_eq(t["axis"], -1)
	assert_eq(t["x"], -2)
	assert_eq(t["z"], 5)
	assert_eq(t["storey"], 1)

func test_stairs_is_stairs_flag() -> void:
	assert_true(_stairs_def.is_stairs())
	assert_false(_stairs_def.is_wall_like())
	assert_false(_stairs_def.is_floor())

func test_stairs_box_center_is_half_height() -> void:
	_stairs_def.height = BuildGrid.LEVEL_HEIGHT
	var size := _stairs_def.get_box_size(BuildGrid.CELL)
	var center := _stairs_def.get_box_center()
	assert_eq(size, Vector3(BuildGrid.CELL, BuildGrid.LEVEL_HEIGHT, BuildGrid.CELL))
	assert_almost_eq(center.y, BuildGrid.LEVEL_HEIGHT * 0.5, 0.0001)

func test_stairs_mesh_has_one_surface_per_step() -> void:
	var mesh := BuildPieceDefinition.build_stairs_mesh(BuildGrid.CELL, BuildGrid.LEVEL_HEIGHT)
	assert_eq(mesh.get_surface_count(), 1)
	var expected: int = BuildPieceDefinition.STAIR_STEPS * 36   # 6 Quads × 6 Punkte je Stufenbox
	assert_eq(mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX].size(), expected)

func test_stairs_rejected_without_ground() -> void:
	var no_ground := func(_x: float, _z: float) -> float: return NAN
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0), _registry, no_ground)
	assert_false(res["ok"])
	assert_eq(res["reason"], "no_ground")

func test_stairs_on_flat_ground_bases_at_lowest_corner() -> void:
	var ground := func(x: float, _z: float) -> float: return 1.0 if x < 1.0 else 1.3
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0), _registry, ground)
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0)

func test_stairs_rejected_when_terrain_too_steep() -> void:
	var ground := func(x: float, _z: float) -> float: return 0.0 if x < 1.0 else 12.0
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0), _registry, ground)
	assert_false(res["ok"])
	assert_eq(res["reason"], "too_steep")

func test_stairs_rejected_in_water() -> void:
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0), _registry,
		_flat(-1.0), null, Vector3(NAN, NAN, NAN), _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "in_water")

func test_stairs_rejected_when_occupied() -> void:
	_registry.add({"key": "T_0_0", "piece_id": "wood_stairs", "kind": STAIRS, "x": 0.0, "y": 0.0, "z": 0.0, "owner": ""})
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0), _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "occupied")

func test_upper_stairs_need_wall_below() -> void:
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0, 1), _registry, _flat(0.0))
	assert_false(res["ok"])
	assert_eq(res["reason"], "unsupported")

func test_upper_stairs_rest_on_wall_top() -> void:
	_add_wall(0, 0, 0, 1.0)
	var res := BuildPlacementRules.check(_stairs_def, BuildGrid.snap(STAIRS, Vector3(1, 0, 1), 0, 1), _registry, _flat(0.0))
	assert_true(res["ok"])
	assert_eq(res["y"], 1.0 + BuildGrid.LEVEL_HEIGHT)

func test_stairs_never_have_dependents() -> void:
	_registry.add({"key": "T_0_0", "piece_id": "wood_stairs", "kind": STAIRS, "x": 0.0, "y": 0.0, "z": 0.0, "owner": ""})
	assert_false(_registry.has_dependents("T_0_0"))
