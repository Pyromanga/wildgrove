class_name TerrainGenerator
extends RefCounted

## TerrainGenerator — Prozedurales Terrain mit Hügeln, Biomen, Flüssen und Seen.
##
## Erzeugt MeshInstance3D (Terrain) + MeshInstance3D (lokalisiertes Wasser)
## + StaticBody3D (Physik) und gibt diese als Kinder von `world` zurück.
##
## ── WASSER (NEU) ─────────────────────────────────────────────────────────
## Wasser ist KEINE riesige flache Plane mehr (die überdeckte vorher alles).
## Stattdessen: das Wasser-Mesh nutzt das GLEICHE Vertex-Grid wie das Terrain,
## aber enthält NUR Dreiecke deren 4 Eck-Vertices alle eine Höhe < water_level
## haben. Ergebnis: Wasser erscheint NUR in echten Senken (Seen/Flüsse),
## der Rest des Terrains bleibt komplett wasserfrei.
##
## ── BIOME (NEU) ──────────────────────────────────────────────────────────
## Zweite Noise-Schicht (_biome_noise) mit FESTEM globalen Seed und sehr
## niedriger Frequenz, gesampled in WELT-Koordinaten (world_offset + lokal).
## → Biome-Übergänge sind über Chunk-Grenzen hinweg KONTINUIERLICH, auch wenn
##   jeder Chunk sein eigenes Detail-Noise mit eigenem Seed hat.
## Biome-Wert 0..1 moduliert die maximale Hügel-Höhe (height_mult):
##   0.0 → Ebene (flach, height_mult≈0.2)
##   1.0 → Gebirge (hoch, height_mult=1.0)
##
## ── CHUNK-ALIGNMENT ──────────────────────────────────────────────────────
## world_offset: Vector2 — Weltposition des Chunk-Zentrums. Wird vom Aufrufer
## (ChunkManager) VOR create() gesetzt. get_height_at(x,z) erwartet x,z als
## LOKALE Koordinaten relativ zu world_offset (genau wie die Mesh-Vertices).

const LOG_CAT := "TerrainGen"

# ── Konfiguration ──────────────────────────────────────────
var size: float        = 64.0
var resolution: int    = 64
var max_height: float  = 12.0
## sea_level: feste Y-Höhe der Wasser-Plane (Skyrim/Minecraft-Ansatz).
## Terrain kann darunter sinken. Depth-Buffer löst die Sichtbarkeit automatisch:
## Terrain-Fragmente über sea_level gewinnen gegen Wasser-Fragmente darunter.
var sea_level: float   = 0.0
var noise_seed: int    = 0

## Weltposition des Chunk-Zentrums — für kontinuierliche Biome über Chunk-Grenzen.
var world_offset: Vector2 = Vector2.ZERO

# Farben — Wasser-Bänder werden kaum sichtbar (Wasser-Mesh liegt darüber),
# aber als Fallback für Bereiche knapp über water_level relevant.
const COL_DEEP_WATER := Color(0.08, 0.25, 0.55)
const COL_SHALLOW    := Color(0.18, 0.48, 0.70)
const COL_SAND       := Color(0.76, 0.71, 0.50)
const COL_GRASS      := Color(0.24, 0.54, 0.20)
const COL_GRASS_DRY  := Color(0.55, 0.58, 0.22)  # Ebenen-Biome: trockenere Wiese
const COL_HILL       := Color(0.36, 0.30, 0.20)
const COL_ROCK       := Color(0.50, 0.46, 0.42)
const COL_SNOW       := Color(0.93, 0.94, 0.96)

const BIOME_SEED: int = 424242   # FEST über alle Chunks — kontinuierliche Biome-Karte
const BIOME_FREQ: float = 0.0035

var _noise: FastNoiseLite        # Detail-Noise — pro Chunk eigener Seed
var _biome_noise: FastNoiseLite  # Biome-Noise — globaler fester Seed
var _rng: RandomNumberGenerator


func _init() -> void:
	_rng = RandomNumberGenerator.new()
	_rng.seed = noise_seed if noise_seed != 0 else int(Time.get_unix_time_from_system())

	_noise = FastNoiseLite.new()
	_noise.seed = _rng.randi()
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_noise.fractal_octaves = 6
	_noise.fractal_lacunarity = 2.1
	_noise.fractal_gain = 0.55
	_noise.frequency = 0.012

	_biome_noise = FastNoiseLite.new()
	_biome_noise.seed = BIOME_SEED
	_biome_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_biome_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_biome_noise.fractal_octaves = 2
	_biome_noise.frequency = BIOME_FREQ


## Erzeugt Terrain + lokalisiertes Wasser + Physik als Kinder von `world`.
func create(world: Node3D) -> void:
	var t := Logger.log_begin("TerrainGenerator.create()", LOG_CAT)

	var heights := _generate_heightmap()

	var terrain := _build_terrain_mesh(heights)
	terrain.name = "Terrain"
	world.add_child(terrain)

	# Wasser: einfache Plane auf sea_level=0.02 — Depth-Buffer übernimmt Sichtbarkeit.
	var water := _build_water_plane()
	water.name = "Water"
	world.add_child(water)

	var physics := _build_physics_body(heights)
	physics.name = "TerrainPhysics"
	world.add_child(physics)

	Logger.log_end("TerrainGenerator.create()", t, LOG_CAT)
	Logger.log_info(
		"Terrain: %dx%d, %.0fm×%.0fm @ %s" % [
			resolution, resolution, size, size, str(world_offset)
		],
		LOG_CAT
	)


## Gibt die Terrain-Höhe an LOKALER Position (x, z) zurück — relativ zu world_offset,
## genau wie die Mesh-Vertices (Bereich ca. [-size/2, size/2]).
func get_height_at(x: float, z: float) -> float:
	var nx: float = x / size
	var nz: float = z / size
	var world_x: float = world_offset.x + x
	var world_z: float = world_offset.y + z
	return _sample_height(nx, nz, world_x, world_z)


# ─────────────────────────────────────────────
# Heightmap
# ─────────────────────────────────────────────


func _generate_heightmap() -> PackedFloat32Array:
	var n := resolution + 1
	var map := PackedFloat32Array()
	map.resize(n * n)

	var river_x_offset: float = _rng.randf_range(-0.1, 0.1)
	var river_amplitude: float = _rng.randf_range(0.06, 0.12)

	for z_i in range(n):
		for x_i in range(n):
			var nx: float = float(x_i) / float(resolution) - 0.5
			var nz: float = float(z_i) / float(resolution) - 0.5
			var local_x: float = nx * size
			var local_z: float = nz * size
			var world_x: float = world_offset.x + local_x
			var world_z: float = world_offset.y + local_z

			var h: float = _sample_height(nx, nz, world_x, world_z)

			# Fluss — zieht Terrain unter sea_level → Wasser-Plane füllt ihn
			var river_x: float = sin(nz * PI * 2.0) * river_amplitude + river_x_offset
			var river_dist: float = abs(nx - river_x)
			var river_width: float = 0.035
			if river_dist < river_width:
				var t_r: float = 1.0 - river_dist / river_width
				h = lerp(h, -1.5, pow(t_r, 2.5))

			# Seen — Mulden unter sea_level
			h = _apply_lake(h, nx, nz, 0.18, -0.22, 0.10)
			h = _apply_lake(h, nx, nz, -0.20, 0.15, 0.08)

			map[z_i * n + x_i] = h

	return map


## Liefert den Biome-Faktor (0..1) an WELT-Koordinaten — global, chunk-übergreifend stetig.
func _get_biome_factor(world_x: float, world_z: float) -> float:
	return (_biome_noise.get_noise_2d(world_x, world_z) + 1.0) * 0.5


## h = detail_noise * max_height * biome_height_mult, mindestens 1.0.
## biome 0.0 → Ebene (height_mult≈0.2, flach)
## biome 1.0 → Gebirge (height_mult=1.0, volle Höhe)
func _sample_height(nx: float, nz: float, world_x: float, world_z: float) -> float:
	var detail: float = (_noise.get_noise_2d(nx, nz) + 1.0) * 0.5  # 0..1
	var biome: float  = _get_biome_factor(world_x, world_z)         # 0..1
	var height_mult: float = lerp(0.15, 1.0, biome)
	# Terrain reicht von ca. -2.0 (tiefe Seen) bis max_height (Berggipfel).
	# sea_level = 0.0 ist die Trennlinie zwischen Wasser und Land.
	# noise 0..1 → h = (noise - 0.35) * max_height * mult
	# Damit liegt ~35% der Fläche unter sea_level (Wasser) und ~65% darüber (Land).
	return (detail - 0.35) * max_height * height_mult


func _apply_lake(h: float, nx: float, nz: float, cx: float, cz: float, radius: float) -> float:
	var dist: float = Vector2(nx - cx, nz - cz).length()
	if dist < radius:
		var t: float = 1.0 - dist / radius
		return lerp(h, -2.0, pow(t, 3.0))
	return h


# ─────────────────────────────────────────────
# Terrain-Mesh
# ─────────────────────────────────────────────


func _build_terrain_mesh(heights: PackedFloat32Array) -> MeshInstance3D:
	var n := resolution + 1
	var step: float = size / float(resolution)
	var half: float = size * 0.5

	var verts: PackedVector3Array = PackedVector3Array()
	var normals: PackedVector3Array = PackedVector3Array()
	var colors: PackedColorArray = PackedColorArray()
	var indices: PackedInt32Array = PackedInt32Array()

	for z_i in range(n):
		for x_i in range(n):
			var h: float = heights[z_i * n + x_i]
			var vx: float = x_i * step - half
			var vz: float = z_i * step - half
			verts.append(Vector3(vx, h, vz))
			# Biome-Faktor für Farbgebung an dieser Stelle (Welt-Koordinaten)
			var world_x: float = world_offset.x + vx
			var world_z: float = world_offset.y + vz
			var biome: float = _get_biome_factor(world_x, world_z)
			colors.append(_height_to_color(h, biome))
			normals.append(Vector3.UP)

	for z_i in range(resolution):
		for x_i in range(resolution):
			var i00: int = z_i * n + x_i
			var i10: int = i00 + 1
			var i01: int = (z_i + 1) * n + x_i
			var i11: int = i01 + 1
			indices.append(i00)
			indices.append(i01)
			indices.append(i10)
			indices.append(i10)
			indices.append(i01)
			indices.append(i11)

	# Normalen per Vertex (Durchschnitt der anliegenden Dreiecksnormalen)
	var tri_normals: Array[Vector3] = []
	for _i in range(verts.size()):
		tri_normals.append(Vector3.ZERO)

	for tri_i in range(0, indices.size(), 3):
		var a: int = indices[tri_i]
		var b: int = indices[tri_i + 1]
		var c: int = indices[tri_i + 2]
		var n_vec: Vector3 = (verts[b] - verts[a]).cross(verts[c] - verts[a]).normalized()
		tri_normals[a] += n_vec
		tri_normals[b] += n_vec
		tri_normals[c] += n_vec

	for i in range(verts.size()):
		normals[i] = tri_normals[i].normalized()

	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	arr[Mesh.ARRAY_COLOR]  = colors
	arr[Mesh.ARRAY_INDEX]  = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.9
	mat.metallic = 0.0
	# Kein render_priority — Standard (0) ist korrekt für opake Meshes.
	# render_priority=-1 verursacht Transparenz-Artefakte in Godot 4 Forward+.

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position.y = 0.0
	return mi


func _height_to_color(h: float, biome: float) -> Color:
	# h liegt in [-2, max_height]. Normalisieren auf [0,1]:
	# 0.0 = tiefster Seeboden (-2), 1.0 = höchster Berg.
	var min_h: float = -2.0
	var ratio: float = (h - min_h) / (max_height - min_h)
	ratio = clampf(ratio, 0.0, 1.0)
	# sea_level=0 liegt bei ratio = (0 - (-2)) / (12 - (-2)) = 2/14 ≈ 0.143
	var sl_ratio: float = (sea_level - min_h) / (max_height - min_h)

	if ratio < sl_ratio * 0.5:
		return COL_DEEP_WATER
	elif ratio < sl_ratio:
		return COL_SHALLOW.lerp(COL_SAND, (ratio - sl_ratio * 0.5) / (sl_ratio * 0.5))
	elif ratio < sl_ratio + 0.04:
		var grass: Color = COL_GRASS_DRY.lerp(COL_GRASS, biome)
		return COL_SAND.lerp(grass, (ratio - sl_ratio) / 0.04)
	elif ratio < 0.55:
		return COL_GRASS_DRY.lerp(COL_GRASS, biome)
	elif ratio < 0.72:
		return COL_GRASS.lerp(COL_HILL, (ratio - 0.55) / 0.17)
	elif ratio < 0.88:
		return COL_HILL.lerp(COL_ROCK, (ratio - 0.72) / 0.16)
	else:
		return COL_ROCK.lerp(COL_SNOW, (ratio - 0.88) / 0.12)


# ─────────────────────────────────────────────
# Wasser — lokalisiertes Mesh (gleiche Grid-Topologie wie Terrain)
# ─────────────────────────────────────────────


## Wasser: einfache flache Plane auf sea_level — deckt den gesamten Chunk ab.
## Der Depth-Buffer übernimmt die Sichtbarkeit: Terrain-Fragmente über sea_level
## haben kleinere Tiefe → gewinnen automatisch gegen Wasser-Fragmente darunter.
## Das ist der Standard-Ansatz (Skyrim, Minecraft, Unity Terrain etc.).
## Gibt immer eine Plane zurück (nie null) — jeder Chunk hat eine Wasser-Plane.
func _build_water_plane() -> MeshInstance3D:
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(size, size)
	# Höhere Subdivision → feinerer Depth-Test, weniger Z-Fighting an Ufern
	mesh.subdivide_width  = 16
	mesh.subdivide_depth  = 16

	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.10, 0.35, 0.72, 1.0)
	mat.roughness    = 0.05
	mat.metallic     = 0.25
	# Cull disabled: auch von unten sichtbar (Unterwasser-Perspektive)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	# sea_level + kleiner Offset vermeidet exaktes Z-Fighting an Terrain-Vertices
	# die genau auf sea_level=0.0 liegen (theoretisch möglich bei h=0.0).
	mi.position.y = sea_level + 0.02
	return mi


# ─────────────────────────────────────────────
# Physik
# ─────────────────────────────────────────────


func _build_physics_body(heights: PackedFloat32Array) -> StaticBody3D:
	var body := StaticBody3D.new()
	var col := CollisionShape3D.new()
	var shape := HeightMapShape3D.new()

	shape.map_width = resolution + 1
	shape.map_depth = resolution + 1
	shape.map_data  = heights

	col.shape = shape
	body.add_child(col)

	# HeightMapShape3D: 1 Unit pro Vertex in lokalen Shape-Koordinaten.
	# Skalierung auf Weltgröße via StaticBody3D.scale (NICHT CollisionShape3D.scale).
	# HeightMapShape3D ist bereits zentriert bei (0,0,0) des Body.
	var scale_xz: float = size / float(resolution)
	body.scale = Vector3(scale_xz, 1.0, scale_xz)

	return body
