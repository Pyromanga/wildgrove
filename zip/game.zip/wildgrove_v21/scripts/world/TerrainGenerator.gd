class_name TerrainGenerator
extends RefCounted

## TerrainGenerator — Prozedurales Terrain mit Hügeln, Biomen, Flüssen und Seen.
##
## Erzeugt MeshInstance3D (Terrain) + MeshInstance3D(s) (lokalisiertes Wasser)
## + StaticBody3D (Physik) und gibt diese als Kinder von `world` zurück.
##
## ── WASSER (v2 — Rework) ─────────────────────────────────────────────────
## KEINE globale flache Plane mehr — stattdessen EXPLIZITE WASSERKÖRPER:
##
##   Problem alt: Eine riesige PlaneMesh (64×64m) liegt bei y=0.02 über dem
##   gesamten Chunk. Der Depth-Buffer soll Land "durchschneiden", aber bei
##   flachem Terrain schlägt das fehl → Land wirkt transparent, Z-Fighting
##   an Ufern, keine Höhenkontrolle möglich.
##
##   Lösung neu: Jeder Wasserkörper (WaterBodyDef) hat:
##     • einen eigenen Typ: "lake" | "river"
##     • eine eigene Höhe (water_level) → Bergseen über sea_level möglich
##     • ein eigenes Mesh, das NUR dort trianguliert wo Terrain < water_level
##   → Kein Wasser über Land → kein "transparentes Land" mehr
##   → Wasser nur in echten Senken → korrekte Seitensicht
##   → Bergseen: water_level > sea_level
##   → Flüsse mit Gefälle: water_level ≠ water_level_end
##   → Trockene Höhlen: einfach keinen Wasserkörper dort definieren
##
## ── KONFIGURATION VOR create() ────────────────────────────────────────────
## water_bodies kann VOR create() von außen befüllt werden:
##   var body := TerrainGenerator.WaterBodyDef.new()
##   body.type = "lake"
##   body.water_level = 5.0          # Bergsee bei y=5
##   body.center = Vector2(0.1, -0.1)
##   body.radius = 0.12
##   gen.water_bodies.append(body)
##   gen.create(world)
## Falls water_bodies leer ist, füllt _populate_default_water_bodies()
## mit Fluss + 2 Seen auf sea_level.
##
## ── BIOME (unverändert) ───────────────────────────────────────────────────
## Zweite Noise-Schicht (_biome_noise) mit FESTEM globalen Seed und sehr
## niedriger Frequenz, gesampled in WELT-Koordinaten (world_offset + lokal).
## → Biome-Übergänge kontinuierlich über Chunk-Grenzen.
##
## ── CHUNK-ALIGNMENT (unverändert) ────────────────────────────────────────
## world_offset: Vector2 — Weltposition des Chunk-Zentrums.

const LOG_CAT := "TerrainGen"

# ── Konfiguration ──────────────────────────────────────────
var size: float        = 64.0
var resolution: int    = 64
var max_height: float  = 12.0
## sea_level: Standard-Y für auto-generierte Wasserkörper (Default-Fallback).
## Für individuelle Höhen: WaterBodyDef.water_level direkt setzen.
var sea_level: float   = 0.0
var noise_seed: int    = 0

## Weltposition des Chunk-Zentrums — für kontinuierliche Biome über Chunk-Grenzen.
var world_offset: Vector2 = Vector2.ZERO

# Terrain-Farben
const COL_DEEP_WATER := Color(0.08, 0.25, 0.55)
const COL_SHALLOW    := Color(0.18, 0.48, 0.70)
const COL_SAND       := Color(0.76, 0.71, 0.50)
const COL_GRASS      := Color(0.24, 0.54, 0.20)
const COL_GRASS_DRY  := Color(0.55, 0.58, 0.22)
const COL_HILL       := Color(0.36, 0.30, 0.20)
const COL_ROCK       := Color(0.50, 0.46, 0.42)
const COL_SNOW       := Color(0.93, 0.94, 0.96)

## Wasser-Farbe (RGBA — Alpha steuert Transparenz; 0.82 = leicht durchsichtig)
const WATER_COLOR := Color(0.10, 0.38, 0.75, 0.82)

const BIOME_SEED: int  = 424242
const BIOME_FREQ: float = 0.0035

var _noise: FastNoiseLite
var _biome_noise: FastNoiseLite
var _rng: RandomNumberGenerator

## water_bodies: Alle Wasserkörper dieses Chunks.
## Kann VOR create() von außen befüllt werden (externe Konfiguration).
## Bleibt leer bis create() → wird dann mit prozeduralen Defaults gefüllt.
## Nach create(): enthält alle erzeugten Wasserkörper (auch extern definierte).
var water_bodies: Array = []


## ── WaterBodyDef ─────────────────────────────────────────────────────────
## Datenbeschreibung eines Wasserkörpers (See oder Fluss-Segment).
## Koordinaten: normalisierte Chunk-Koordinaten [-0.5 .. +0.5].
## Höhen (water_level, water_level_end): Welt-Y in Metern.
class WaterBodyDef:
	## "lake" = kreisförmiger See | "river" = geschwungener Fluss
	var type: String = "lake"

	## Y der Wasseroberfläche in Weltkoordinaten.
	##   sea_level (0.0) → Küstensee / Flusstal
	##   > 0.0           → Bergsee / Hochplateau-See
	##   < 0.0           → Meeresbucht / tiefer Fjord
	var water_level: float = 0.0

	# ── See ────────────────────────────────────────────────────────────────
	## Mitte des Sees (normalisiert, Chunk-relativ)
	var center: Vector2 = Vector2.ZERO
	## Radius (normalisiert; 0.10 ≈ 6.4m bei size=64, 0.20 ≈ 12.8m)
	var radius: float = 0.10

	# ── Fluss ──────────────────────────────────────────────────────────────
	## Sinusförmige Flusskrümmung: x-Position = sin(nz * PI * 2) * amplitude + x_offset
	var river_amplitude: float = 0.08
	## Lateraler Offset der Flussmitte (normalisiert)
	var river_x_offset: float  = 0.0
	## Halbe Flussbreite (normalisiert; 0.035 ≈ 2.2m bei size=64)
	var river_width: float     = 0.035
	## Y am Fluss-Ende (Süd-Rand des Chunks).
	## water_level_end < water_level → Gefälle (Fluss fließt bergab).
	## water_level_end = water_level → flacher Fluss (kein Gefälle).
	var water_level_end: float = 0.0


func _init() -> void:
	_rng = RandomNumberGenerator.new()
	_rng.seed = noise_seed if noise_seed != 0 else int(Time.get_unix_time_from_system())

	_noise = FastNoiseLite.new()
	_noise.seed = _rng.randi()
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_noise.fractal_octaves = 6
	_noise.fractal_lacunarity = 2.1
	_noise.fractal_gain = 0.55
	_noise.frequency = 0.012

	_biome_noise = FastNoiseLite.new()
	_biome_noise.seed = BIOME_SEED
	_biome_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_biome_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_biome_noise.fractal_octaves = 2
	_biome_noise.frequency = BIOME_FREQ


## Erzeugt Terrain + Wasserkörper-Meshes + Physik als Kinder von `world`.
func create(world: Node3D) -> void:
	var t := Logger.log_begin("TerrainGenerator.create()", LOG_CAT)

	var heights := _generate_heightmap()

	var terrain := _build_terrain_mesh(heights)
	terrain.name = "Terrain"
	world.add_child(terrain)

	# Wasser: ein Mesh pro Wasserkörper (keine globale Plane mehr)
	var water_meshes := _build_all_water_meshes(heights)
	for i in range(water_meshes.size()):
		water_meshes[i].name = "Water_%d" % i
		world.add_child(water_meshes[i])

	var physics := _build_physics_body(heights)
	physics.name = "TerrainPhysics"
	world.add_child(physics)

	Logger.log_end("TerrainGenerator.create()", t, LOG_CAT)
	Logger.log_info(
		"Terrain: %dx%d, %.0fm×%.0fm @ %s — %d Wasserkörper" % [
			resolution, resolution, size, size,
			str(world_offset), water_bodies.size()
		],
		LOG_CAT
	)


## Gibt die Terrain-Höhe an LOKALER Position (x, z) zurück — relativ zu world_offset,
## genau wie die Mesh-Vertices (Bereich ca. [-size/2, size/2]).
func get_height_at(x: float, z: float) -> float:
	var nx: float = x / size
	var nz: float = z / size
	var world_x: float = world_offset.x + x
	var world_z: float = world_offset.y + z
	return _sample_height(nx, nz, world_x, world_z)


# ─────────────────────────────────────────────
# Heightmap
# ─────────────────────────────────────────────


func _generate_heightmap() -> PackedFloat32Array:
	var n := resolution + 1
	var map := PackedFloat32Array()
	map.resize(n * n)

	# Wasserkörper aufbauen falls nicht von außen vorkonfiguriert
	if water_bodies.is_empty():
		_populate_default_water_bodies()

	for z_i in range(n):
		for x_i in range(n):
			var nx: float = float(x_i) / float(resolution) - 0.5
			var nz: float = float(z_i) / float(resolution) - 0.5
			var local_x: float = nx * size
			var local_z: float = nz * size
			var world_x: float = world_offset.x + local_x
			var world_z: float = world_offset.y + local_z

			var h: float = _sample_height(nx, nz, world_x, world_z)

			# Terrain für alle Wasserkörper aushöhlen
			for body in water_bodies:
				h = _carve_water_body(h, nx, nz, body)

			map[z_i * n + x_i] = h

	return map


## Befüllt water_bodies mit prozeduralen Defaults (1 Fluss + 2 Seen).
## Wird nur aufgerufen wenn water_bodies vor create() leer war.
func _populate_default_water_bodies() -> void:
	var river := WaterBodyDef.new()
	river.type             = "river"
	river.water_level      = sea_level
	river.water_level_end  = sea_level  # kein Gefälle per Default
	river.river_amplitude  = _rng.randf_range(0.06, 0.12)
	river.river_x_offset   = _rng.randf_range(-0.1, 0.1)
	river.river_width      = 0.035
	water_bodies.append(river)

	var lake1 := WaterBodyDef.new()
	lake1.type        = "lake"
	lake1.center      = Vector2(0.18, -0.22)
	lake1.radius      = 0.10
	lake1.water_level = sea_level
	water_bodies.append(lake1)

	var lake2 := WaterBodyDef.new()
	lake2.type        = "lake"
	lake2.center      = Vector2(-0.20, 0.15)
	lake2.radius      = 0.08
	lake2.water_level = sea_level
	water_bodies.append(lake2)


## Höhlt das Terrain für einen einzelnen Wasserkörper aus.
func _carve_water_body(h: float, nx: float, nz: float, body: WaterBodyDef) -> float:
	match body.type:
		"lake":  return _carve_lake(h, nx, nz, body)
		"river": return _carve_river(h, nx, nz, body)
	return h


func _carve_lake(h: float, nx: float, nz: float, body: WaterBodyDef) -> float:
	var dist: float = Vector2(nx - body.center.x, nz - body.center.y).length()
	if dist < body.radius:
		var t: float = 1.0 - dist / body.radius
		# See-Boden: 2m unter water_level (sanfte Schüssel-Form)
		return lerp(h, body.water_level - 2.0, pow(t, 3.0))
	return h


func _carve_river(h: float, nx: float, nz: float, body: WaterBodyDef) -> float:
	var river_x: float = sin(nz * PI * 2.0) * body.river_amplitude + body.river_x_offset
	var river_dist: float = abs(nx - river_x)
	if river_dist < body.river_width:
		var t_r: float = 1.0 - river_dist / body.river_width
		# Gefälle interpolieren: nz -0.5..+0.5 → t_nz 0..1
		var t_nz: float = nz + 0.5
		var local_wl: float = lerp(body.water_level, body.water_level_end, t_nz)
		# Fluss-Boden: 1.5m unter dem lokalen Wasserstand
		return lerp(h, local_wl - 1.5, pow(t_r, 2.5))
	return h


## Liefert den Biome-Faktor (0..1) an WELT-Koordinaten.
func _get_biome_factor(world_x: float, world_z: float) -> float:
	return (_biome_noise.get_noise_2d(world_x, world_z) + 1.0) * 0.5


func _sample_height(nx: float, nz: float, world_x: float, world_z: float) -> float:
	var detail: float = (_noise.get_noise_2d(nx, nz) + 1.0) * 0.5
	var biome: float  = _get_biome_factor(world_x, world_z)
	var height_mult: float = lerp(0.15, 1.0, biome)
	return (detail - 0.35) * max_height * height_mult


# ─────────────────────────────────────────────
# Terrain-Mesh (unverändert)
# ─────────────────────────────────────────────


func _build_terrain_mesh(heights: PackedFloat32Array) -> MeshInstance3D:
	var n := resolution + 1
	var step: float = size / float(resolution)
	var half: float = size * 0.5

	var verts: PackedVector3Array = PackedVector3Array()
	var normals: PackedVector3Array = PackedVector3Array()
	var colors: PackedColorArray = PackedColorArray()
	var indices: PackedInt32Array = PackedInt32Array()

	for z_i in range(n):
		for x_i in range(n):
			var h: float = heights[z_i * n + x_i]
			var vx: float = x_i * step - half
			var vz: float = z_i * step - half
			verts.append(Vector3(vx, h, vz))
			var world_x: float = world_offset.x + vx
			var world_z: float = world_offset.y + vz
			var biome: float = _get_biome_factor(world_x, world_z)
			colors.append(_height_to_color(h, biome))
			normals.append(Vector3.UP)

	for z_i in range(resolution):
		for x_i in range(resolution):
			var i00: int = z_i * n + x_i
			var i10: int = i00 + 1
			var i01: int = (z_i + 1) * n + x_i
			var i11: int = i01 + 1
			indices.append(i00)
			indices.append(i01)
			indices.append(i10)
			indices.append(i10)
			indices.append(i01)
			indices.append(i11)

	var tri_normals: Array[Vector3] = []
	for _i in range(verts.size()):
		tri_normals.append(Vector3.ZERO)

	for tri_i in range(0, indices.size(), 3):
		var a: int = indices[tri_i]
		var b: int = indices[tri_i + 1]
		var c: int = indices[tri_i + 2]
		var n_vec: Vector3 = (verts[b] - verts[a]).cross(verts[c] - verts[a]).normalized()
		tri_normals[a] += n_vec
		tri_normals[b] += n_vec
		tri_normals[c] += n_vec

	for i in range(verts.size()):
		normals[i] = tri_normals[i].normalized()

	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	arr[Mesh.ARRAY_COLOR]  = colors
	arr[Mesh.ARRAY_INDEX]  = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.9
	mat.metallic = 0.0

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position.y = 0.0
	return mi


func _height_to_color(h: float, biome: float) -> Color:
	var min_h: float = -2.0
	var ratio: float = (h - min_h) / (max_height - min_h)
	ratio = clampf(ratio, 0.0, 1.0)
	var sl_ratio: float = (sea_level - min_h) / (max_height - min_h)

	if ratio < sl_ratio * 0.5:
		return COL_DEEP_WATER
	elif ratio < sl_ratio:
		return COL_SHALLOW.lerp(COL_SAND, (ratio - sl_ratio * 0.5) / (sl_ratio * 0.5))
	elif ratio < sl_ratio + 0.04:
		var grass: Color = COL_GRASS_DRY.lerp(COL_GRASS, biome)
		return COL_SAND.lerp(grass, (ratio - sl_ratio) / 0.04)
	elif ratio < 0.55:
		return COL_GRASS_DRY.lerp(COL_GRASS, biome)
	elif ratio < 0.72:
		return COL_GRASS.lerp(COL_HILL, (ratio - 0.55) / 0.17)
	elif ratio < 0.88:
		return COL_HILL.lerp(COL_ROCK, (ratio - 0.72) / 0.16)
	else:
		return COL_ROCK.lerp(COL_SNOW, (ratio - 0.88) / 0.12)


# ─────────────────────────────────────────────
# Wasser — lokalisierte Meshes pro Wasserkörper
# ─────────────────────────────────────────────


## Erzeugt alle Wasser-Meshes (einen pro Wasserkörper in water_bodies).
func _build_all_water_meshes(heights: PackedFloat32Array) -> Array:
	var result: Array = []
	for body in water_bodies:
		var mi: MeshInstance3D = null
		match body.type:
			"lake":  mi = _build_lake_water_mesh(body, heights)
			"river": mi = _build_river_water_mesh(body, heights)
		if mi != null:
			result.append(mi)
	return result


## See-Wasser-Mesh: Quads im kreisförmigen Bereich, nur wo Terrain < water_level.
## Alle Vertices liegen auf einer FLACHEN Ebene bei body.water_level + 0.01.
func _build_lake_water_mesh(body: WaterBodyDef, heights: PackedFloat32Array) -> MeshInstance3D:
	var n := resolution + 1
	var step: float = size / float(resolution)
	var half: float = size * 0.5
	# +0.01: minimaler Offset über Terrain-Vertices am Ufer → kein Z-Fighting
	var wl: float = body.water_level + 0.01

	var verts   := PackedVector3Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	# Deduplizierter Vertex-Pool: grid-Index → verts-Index
	var vert_map: Dictionary = {}

	for z_i in range(resolution):
		for x_i in range(resolution):
			var corners := [
				Vector2i(x_i,     z_i),
				Vector2i(x_i + 1, z_i),
				Vector2i(x_i,     z_i + 1),
				Vector2i(x_i + 1, z_i + 1),
			]

			# Mindestens 1 Ecke im See-Radius (leicht erweitert für sauberen Rand)
			var in_lake := false
			for c in corners:
				var cnx := float(c.x) / float(resolution) - 0.5
				var cnz := float(c.y) / float(resolution) - 0.5
				if Vector2(cnx - body.center.x, cnz - body.center.y).length() < body.radius * 1.05:
					in_lake = true
					break
			if not in_lake:
				continue

			# Mindestens 1 Ecke unter water_level (echte Senke — kein Wasser auf Bergen)
			var any_wet := false
			for c in corners:
				if heights[c.y * n + c.x] < body.water_level:
					any_wet = true
					break
			if not any_wet:
				continue

			# Vertices hinzufügen (dedupliziert)
			var qi := PackedInt32Array()
			for c in corners:
				var key: int = c.y * n + c.x
				if not vert_map.has(key):
					verts.append(Vector3(c.x * step - half, wl, c.y * step - half))
					normals.append(Vector3.UP)
					vert_map[key] = verts.size() - 1
				qi.append(vert_map[key])

			# 2 Dreiecke pro Quad (gleiche Wicklung wie Terrain)
			indices.append(qi[0]); indices.append(qi[2]); indices.append(qi[1])
			indices.append(qi[1]); indices.append(qi[2]); indices.append(qi[3])

	if verts.is_empty():
		return null
	return _assemble_water_mesh_instance(verts, normals, indices)


## Fluss-Wasser-Mesh: Quads entlang des Fluss-Pfads, mit Gefälle-Unterstützung.
## Y der Vertices variiert entlang der Z-Achse (lerp water_level → water_level_end).
func _build_river_water_mesh(body: WaterBodyDef, heights: PackedFloat32Array) -> MeshInstance3D:
	var n := resolution + 1
	var step: float = size / float(resolution)
	var half: float = size * 0.5

	var verts   := PackedVector3Array()
	var normals := PackedVector3Array()
	var indices := PackedInt32Array()
	var vert_map: Dictionary = {}

	for z_i in range(resolution):
		for x_i in range(resolution):
			var corners := [
				Vector2i(x_i,     z_i),
				Vector2i(x_i + 1, z_i),
				Vector2i(x_i,     z_i + 1),
				Vector2i(x_i + 1, z_i + 1),
			]

			# Mindestens 1 Ecke im Flussbereich (1.5× Breite für weicheren Rand)
			var in_river := false
			for c in corners:
				var cnx := float(c.x) / float(resolution) - 0.5
				var cnz := float(c.y) / float(resolution) - 0.5
				var rx: float = sin(cnz * PI * 2.0) * body.river_amplitude + body.river_x_offset
				if abs(cnx - rx) < body.river_width * 1.5:
					in_river = true
					break
			if not in_river:
				continue

			# Mindestens 1 Ecke unter dem lokalen Wasserstand (Gefälle berücksichtigt)
			var any_wet := false
			for c in corners:
				var cnz := float(c.y) / float(resolution) - 0.5
				var local_wl := lerp(body.water_level, body.water_level_end, cnz + 0.5)
				if heights[c.y * n + c.x] < local_wl:
					any_wet = true
					break
			if not any_wet:
				continue

			var qi := PackedInt32Array()
			for c in corners:
				var key: int = c.y * n + c.x
				if not vert_map.has(key):
					var cnz := float(c.y) / float(resolution) - 0.5
					# Gefälle: Wasserstand nimmt von water_level (Nord) auf water_level_end (Süd) ab
					var local_wl := lerp(body.water_level, body.water_level_end, cnz + 0.5) + 0.01
					verts.append(Vector3(c.x * step - half, local_wl, c.y * step - half))
					normals.append(Vector3.UP)
					vert_map[key] = verts.size() - 1
				qi.append(vert_map[key])

			indices.append(qi[0]); indices.append(qi[2]); indices.append(qi[1])
			indices.append(qi[1]); indices.append(qi[2]); indices.append(qi[3])

	if verts.is_empty():
		return null
	return _assemble_water_mesh_instance(verts, normals, indices)


## Gemeinsame Mesh + Material Assemblierung für alle Wasserkörper-Typen.
##
## Material-Entscheidungen:
##   TRANSPARENCY_ALPHA: Alpha < 1 → Seeboden sichtbar (gewünscht)
##   DEPTH_DRAW_DISABLED: Wasser schreibt nicht in Depth-Buffer → andere
##     transparente Objekte (Partikel, Unterwasser-Effekte) korrekt hinter Wasser
##   render_priority = 1: Wasser rendert NACH opakem Terrain → kein Z-Fight
##   CULL_DISABLED: Von unten sichtbar (Unterwasser-Perspektive / Höhlen)
func _assemble_water_mesh_instance(
	verts:   PackedVector3Array,
	normals: PackedVector3Array,
	indices: PackedInt32Array
) -> MeshInstance3D:
	var arr: Array = []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	arr[Mesh.ARRAY_INDEX]  = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

	var mat := StandardMaterial3D.new()
	mat.albedo_color    = WATER_COLOR
	mat.roughness       = 0.08
	mat.metallic        = 0.20
	mat.transparency    = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.depth_draw_mode = BaseMaterial3D.DEPTH_DRAW_DISABLED
	mat.render_priority = 1
	mat.cull_mode       = BaseMaterial3D.CULL_DISABLED

	var mi := MeshInstance3D.new()
	mi.mesh              = mesh
	mi.material_override = mat
	return mi


# ─────────────────────────────────────────────
# Physik (unverändert)
# ─────────────────────────────────────────────


func _build_physics_body(heights: PackedFloat32Array) -> StaticBody3D:
	var body := StaticBody3D.new()
	var col := CollisionShape3D.new()
	var shape := HeightMapShape3D.new()

	shape.map_width = resolution + 1
	shape.map_depth = resolution + 1
	shape.map_data  = heights

	col.shape = shape
	body.add_child(col)

	var scale_xz: float = size / float(resolution)
	body.scale = Vector3(scale_xz, 1.0, scale_xz)

	return body
