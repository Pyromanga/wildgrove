extends CharacterBody3D
class_name AnimalBase

## AnimalBase — Basisklasse für alle Tiere.
##
## State Machine: IDLE → WANDER → FLEE (Spieler zu nah)
## Visuals: programmatisch (Körper + Kopf + 4 Beine)
## Unterklassen setzen _color, _body_size, _speed, _flee_radius, etc.

const LOG_CAT := "Animal"
const GRAVITY  := 9.8

enum State { IDLE, WANDER, FLEE }

var _color:        Color   = Color(0.7, 0.5, 0.3)
var _body_size:    Vector3 = Vector3(0.4, 0.6, 0.4)
var _speed:        float   = 3.0
var _flee_radius:  float   = 5.0
var _idle_time:    float   = 2.0
var _wander_range: float   = 8.0
var _home_radius:  float   = 15.0

var _state:         State   = State.IDLE
var _state_timer:   float   = 0.0
var _wander_target: Vector3 = Vector3.ZERO
var _spawn_origin:  Vector3 = Vector3.ZERO


func _ready() -> void:
	_spawn_origin = global_position
	_build_visuals()
	_build_collision()
	add_to_group("animals")
	_on_ready_extended()
	Logger.log_debug("Tier '%s' @ %s" % [name, str(global_position)], LOG_CAT)


func _on_ready_extended() -> void:
	pass   # Hook für Unterklassen


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0

	_state_timer -= delta

	match _state:
		State.IDLE:
			velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)
			if _state_timer <= 0.0:
				_enter_wander()

		State.WANDER:
			_move_toward(_wander_target, _speed, delta)
			if global_position.distance_to(_wander_target) < 0.6 or _state_timer <= 0.0:
				_enter_idle()

		State.FLEE:
			_move_toward(_wander_target, _speed * 2.2, delta)
			if _state_timer <= 0.0:
				_enter_idle()

	# Heimkehr
	var home_flat := Vector2(global_position.x - _spawn_origin.x,
							 global_position.z - _spawn_origin.z)
	if home_flat.length() > _home_radius and _state != State.FLEE:
		_wander_target = _spawn_origin
		_state         = State.WANDER
		_state_timer   = 4.0

	move_and_slide()
	_check_player_proximity()


func _check_player_proximity() -> void:
	var players := get_tree().get_nodes_in_group("player")
	if players.is_empty():
		return
	var player: Node3D = players[0]
	if not is_instance_valid(player):
		return
	if global_position.distance_to(player.global_position) < _flee_radius \
	   and _state != State.FLEE:
		var flee_dir: Vector3 = (global_position - player.global_position).normalized()
		_wander_target = global_position + flee_dir * _wander_range
		_state         = State.FLEE
		_state_timer   = 3.5


func _move_toward(target: Vector3, spd: float, delta: float) -> void:
	var dir := (target - global_position)
	dir.y = 0.0
	if dir.length_squared() > 0.01:
		dir = dir.normalized()
		velocity.x = move_toward(velocity.x, dir.x * spd, 12.0 * delta)
		velocity.z = move_toward(velocity.z, dir.z * spd, 12.0 * delta)
		look_at(global_position + dir, Vector3.UP)


func _enter_idle() -> void:
	_state       = State.IDLE
	_state_timer = _idle_time + randf_range(-0.5, 1.5)


func _enter_wander() -> void:
	_state       = State.WANDER
	_state_timer = 3.0 + randf_range(0.0, 2.0)
	_wander_target = _spawn_origin + Vector3(
		randf_range(-_wander_range, _wander_range), 0.0,
		randf_range(-_wander_range, _wander_range)
	)


# ─────────────────────────────────────────────
# Visuals
# ─────────────────────────────────────────────

func _build_visuals() -> void:
	var root := Node3D.new(); root.name = "Visuals"
	var bm := CapsuleMesh.new()
	bm.radius = _body_size.x * 0.5
	bm.height = _body_size.y
	var bmat := StandardMaterial3D.new(); bmat.albedo_color = _color
	var bmi  := MeshInstance3D.new(); bmi.mesh = bm; bmi.material_override = bmat
	bmi.position.y = _body_size.y * 0.5
	root.add_child(bmi)

	var hm := SphereMesh.new()
	hm.radius = _body_size.x * 0.35; hm.height = _body_size.x * 0.7
	var hmat := StandardMaterial3D.new(); hmat.albedo_color = _color.lightened(0.1)
	var hmi  := MeshInstance3D.new(); hmi.mesh = hm; hmi.material_override = hmat
	hmi.position = Vector3(0, _body_size.y * 1.05, _body_size.x * 0.25)
	root.add_child(hmi)
	_add_legs(root)
	add_child(root)


func _add_legs(parent: Node3D) -> void:
	var lmat := StandardMaterial3D.new(); lmat.albedo_color = _color.darkened(0.2)
	for lp: Vector3 in [
		Vector3(-_body_size.x*.3, 0, -_body_size.z*.2),
		Vector3( _body_size.x*.3, 0, -_body_size.z*.2),
		Vector3(-_body_size.x*.3, 0,  _body_size.z*.2),
		Vector3( _body_size.x*.3, 0,  _body_size.z*.2),
	]:
		var lm := CylinderMesh.new()
		lm.top_radius = lm.bottom_radius = _body_size.x * 0.08
		lm.height = _body_size.y * 0.55
		var lmi := MeshInstance3D.new(); lmi.mesh = lm; lmi.material_override = lmat
		lmi.position = lp + Vector3(0, _body_size.y * 0.27, 0)
		parent.add_child(lmi)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = _body_size.x * 0.45; sh.height = _body_size.y
	col.shape = sh; col.position.y = _body_size.y * 0.5
	add_child(col)


func on_spawn(_cfg: Dictionary) -> void:
	_spawn_origin = global_position; _enter_idle()

func on_despawn() -> void:
	pass

func get_inspect_text() -> String:
	return "Ein Tier."
