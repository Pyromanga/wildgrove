extends ServiceNode
class_name WorldGenerationService

## WorldGenerationService — Prozedurale Welt-Generierung.
##
## Verantwortung:
##   - Positionen für Entities (Bäume, Erze) generieren
##   - Seed-basiert und damit reproduzierbar (selber Seed = selbe Welt)
##   - Verhindert Überlappungen durch Mindestabstand-Prüfung
##
## Integration:
##   WorldService ruft generate_world(seed_value, data) in _spawn_world_entities() auf
##   wenn kein Savegame vorhanden ist.
##
## Abhängigkeiten (deps): [] — reine Logik, kein Service nötig

const LOG_CAT := "WorldGen"

@export var world_half_size: float      = 30.0
@export var min_tree_distance: float    = 4.0
@export var min_ore_distance: float     = 5.0
@export var min_spawn_clearance: float  = 6.0
@export var tree_count: int             = 12
@export var ore_count: int              = 5


## Callback für Terrain-Höhe: Callable(x: float, z: float) -> float
## Wird von WorldService.on_world_scene_ready() injiziert nachdem das Terrain gebaut wurde.
## Ohne Callback: y = 0.0 (flacher Fallback).
var _height_cb: Callable = Callable()


func configure(_deps: Dictionary) -> void:
	Logger.log_debug("WorldGenerationService konfiguriert.", LOG_CAT)


func on_ready() -> void:
	Logger.log_info("WorldGenerationService bereit.", LOG_CAT)


## Injiziert den Terrain-Höhen-Callback.
## cb: Callable(x: float, z: float) -> float
func set_height_callback(cb: Callable) -> void:
	_height_cb = cb
	Logger.log_debug("Terrain-Höhen-Callback injiziert.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Generiert eine komplette Welt mit dem gegebenen Seed.
## Gibt eine befüllte WorldData zurück (KEINE neue Instanz — schreibt in die übergebene).
## Wenn data == null wird eine neue WorldData erstellt.
func generate_world(seed_value: int, data: WorldData = null) -> WorldData:
	if data == null:
		data = WorldData.new()

	var t := Logger.log_begin("WorldGenerationService.generate_world(seed=%d)" % seed_value, LOG_CAT)

	var rng := RandomNumberGenerator.new()
	rng.seed = seed_value

	# Bäume generieren
	data.tree_positions = _generate_positions(
		rng, tree_count, min_tree_distance, min_spawn_clearance, []
	)
	Logger.log_debug(
		"%d Baum-Positionen generiert." % data.tree_positions.size(), LOG_CAT
	)

	# Erze generieren — mit Abstand zu Bäumen
	data.ore_positions = _generate_positions(
		rng, ore_count, min_ore_distance, min_spawn_clearance, data.tree_positions
	)
	Logger.log_debug(
		"%d Erz-Positionen generiert." % data.ore_positions.size(), LOG_CAT
	)

	Logger.log_end("WorldGenerationService.generate_world()", t, LOG_CAT)
	Logger.log_info(
		"Welt generiert (Seed %d): %d Bäume, %d Erze." % [
			seed_value,
			data.tree_positions.size(),
			data.ore_positions.size()
		],
		LOG_CAT
	)
	return data


## Generiert einen deterministischen Seed aus einem String (z.B. Spieler-Name).
static func seed_from_string(s: String) -> int:
	var hash_val := 0
	for i in range(s.length()):
		hash_val = (hash_val * 31 + s.unicode_at(i)) & 0x7FFFFFFF
	return hash_val


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _generate_positions(
	rng:             RandomNumberGenerator,
	count:           int,
	min_dist:        float,
	spawn_clearance: float,
	avoid_positions: Array[Vector3]
) -> Array[Vector3]:
	## Platziert `count` Positionen innerhalb der Weltgrenzen.
	## Garantiert Mindestabstand zueinander und zu avoid_positions.
	## Bricht nach max_attempts ab um Endlosschleifen zu vermeiden.

	var placed: Array[Vector3] = []
	var max_attempts := count * 30  # 30 Versuche pro gewünschter Position
	var attempts     := 0

	while placed.size() < count and attempts < max_attempts:
		attempts += 1

		var x := rng.randf_range(-world_half_size, world_half_size)
		var z := rng.randf_range(-world_half_size, world_half_size)
		var candidate := Vector3(x, 0.0, z)

		# Spawn-Clearance prüfen (Abstand vom Ursprung)
		if candidate.length() < spawn_clearance:
			continue

		# Nicht ins Wasser spawnen — Terrain-Höhe prüfen
		if _height_cb.is_valid():
			var h: float = _height_cb.call(x, z)
			# water_level ≈ 0.8 — Entities sollen nur auf Land spawnen
			if h < 1.2:
				continue
			candidate.y = h
		
		# Abstand zu bereits platzierten Positionen
		if not _is_far_enough(candidate, placed, min_dist):
			continue

		# Abstand zu avoid_positions (z.B. Bäume wenn Erze platziert werden)
		if not _is_far_enough(candidate, avoid_positions, min_dist):
			continue

		placed.append(candidate)

	if placed.size() < count:
		Logger.log_warn(
			"Nur %d/%d Positionen platziert (max_attempts=%d erreicht)." % [
				placed.size(), count, max_attempts
			],
			LOG_CAT
		)

	return placed


static func _is_far_enough(candidate: Vector3, others: Array[Vector3], min_dist: float) -> bool:
	for other in others:
		if candidate.distance_to(other) < min_dist:
			return false
	return true
