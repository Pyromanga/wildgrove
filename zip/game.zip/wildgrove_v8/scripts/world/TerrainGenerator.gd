class_name TerrainGenerator
extends RefCounted

## TerrainGenerator — Prozedurales Terrain mit Hügeln, Tälern, Flüssen und Seen.
##
## Erzeugt ein MeshInstance3D + StaticBody3D mit echter Höhenkarte.
## Wird von WorldFactory._add_ground() verwendet statt des flachen BoxMesh.
##
## Technik:
##   - Heightmap per Noise (FastNoiseLite mit mehreren Oktaven)
##   - ArrayMesh mit berechneten Normalen für korrekte Beleuchtung
##   - Wasser-Plane auf water_level für Seen/Flüsse
##   - Fluss-Kanal: entlang einer Bezier-Kurve abgesenkte Höhen
##   - StaticBody3D mit HeightMapShape3D für Physik-Kollision

const LOG_CAT := "TerrainGen"

# ── Konfiguration ──────────────────────────────────────────
## Größe der Kachel in Welt-Einheiten
var size: float             = 120.0
## Auflösung: Vertices pro Seite (höher = feiner, aber langsamer)
var resolution: int         = 64
## Maximale Terrain-Höhe über Basislevel
var max_height: float       = 8.0
## Wasser-Level: alles darunter = See/Fluss
var water_level: float      = 0.8
## Steigung der Ufer (wie schnell das Terrain abfällt)
var shore_steepness: float  = 2.5
## Seed für Reproduzierbarkeit (0 = zufällig)
var noise_seed: int         = 0

# Farben
const COL_DEEP_WATER := Color(0.08, 0.25, 0.55)
const COL_SHALLOW    := Color(0.18, 0.48, 0.70)
const COL_SAND       := Color(0.75, 0.70, 0.50)
const COL_GRASS      := Color(0.22, 0.52, 0.18)
const COL_HILL       := Color(0.35, 0.30, 0.22)
const COL_ROCK       := Color(0.50, 0.45, 0.40)
const COL_SNOW       := Color(0.92, 0.93, 0.95)

var _noise: FastNoiseLite
var _rng: RandomNumberGenerator


func _init() -> void:
	_rng = RandomNumberGenerator.new()
	_rng.seed = noise_seed if noise_seed != 0 else int(Time.get_unix_time_from_system())

	_noise = FastNoiseLite.new()
	_noise.seed = _rng.randi()
	_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_noise.fractal_octaves = 5
	_noise.fractal_lacunarity = 2.0
	_noise.fractal_gain = 0.5
	_noise.frequency = 0.018


## Erzeugt das komplette Terrain als Node3D mit Mesh + Physik + Wasser.
## Gibt einen Container zurück den WorldFactory in world_root einhängt.
func create(world: Node3D) -> void:
	var t := Logger.log_begin("TerrainGenerator.create()", LOG_CAT)

	var heights := _generate_heightmap()
	var terrain := _build_terrain_mesh(heights)
	terrain.name = "Terrain"
	world.add_child(terrain)

	var water := _build_water_plane()
	water.name = "Water"
	world.add_child(water)

	var physics := _build_physics_body(heights)
	physics.name = "TerrainPhysics"
	world.add_child(physics)

	Logger.log_end("TerrainGenerator.create()", t, LOG_CAT)
	Logger.log_info(
		"Terrain: %dx%d, %.0fm×%.0fm, Wasser bei y=%.1f" % [
			resolution, resolution, size, size, water_level
		],
		LOG_CAT
	)


## Gibt die Terrain-Höhe an Weltposition (x, z) zurück.
## Kann von WorldGenerationService genutzt werden um Entities korrekt zu platzieren.
func get_height_at(x: float, z: float) -> float:
	var nx: float = x / size
	var nz: float = z / size
	return _sample_height(nx, nz)


# ─────────────────────────────────────────────
# Heightmap
# ─────────────────────────────────────────────


func _generate_heightmap() -> PackedFloat32Array:
	var n := resolution + 1
	var map := PackedFloat32Array()
	map.resize(n * n)

	# Fluss-Pfad: Sinuslinie von Nord nach Süd (parametrisch, deterministisch)
	var river_x_offset: float = _rng.randf_range(-0.15, 0.15)
	var river_amplitude: float = _rng.randf_range(0.08, 0.18)

	for z_i in range(n):
		for x_i in range(n):
			var nx: float = float(x_i) / float(resolution) - 0.5  # -0.5..0.5
			var nz: float = float(z_i) / float(resolution) - 0.5

			var h: float = _sample_height(nx, nz)

			# Fluss-Kanal: entlang einer Sinuslinie einschneiden
			var river_x: float = sin(nz * PI * 2.2) * river_amplitude + river_x_offset
			var river_dist: float = abs(nx - river_x)
			var river_width: float = 0.055
			if river_dist < river_width:
				var t_r: float = 1.0 - river_dist / river_width
				var channel_depth: float = water_level * 0.6
				h = lerp(h, channel_depth * 0.3, pow(t_r, 1.8))

			# Seen: zwei abgesenkte Mulden
			h = _apply_lake(h, nx, nz, 0.18, -0.22, 0.13)
			h = _apply_lake(h, nx, nz, -0.20, 0.15, 0.10)

			map[z_i * n + x_i] = h

	return map


func _sample_height(nx: float, nz: float) -> float:
	## Basis-Rauschen (0..1) → skaliert auf max_height.
	## Rand-Absenkung: verhindert schwebende Kanten (Terrain läuft am Rand ins Wasser).
	var raw: float = (_noise.get_noise_2d(nx, nz) + 1.0) * 0.5  # 0..1
	# Rand-Maske: cosinus-förmig, fällt an den Rändern ab
	var edge_x: float = cos(nx * PI) * 0.5 + 0.5
	var edge_z: float = cos(nz * PI) * 0.5 + 0.5
	var edge: float = pow(edge_x * edge_z, 0.6)
	return raw * edge * max_height


func _apply_lake(h: float, nx: float, nz: float, cx: float, cz: float, radius: float) -> float:
	var dist: float = Vector2(nx - cx, nz - cz).length()
	if dist < radius:
		var t: float = 1.0 - dist / radius
		return lerp(h, water_level * 0.35, pow(t, 2.2))
	return h


# ─────────────────────────────────────────────
# Mesh-Bau
# ─────────────────────────────────────────────


func _build_terrain_mesh(heights: PackedFloat32Array) -> MeshInstance3D:
	var n := resolution + 1
	var step: float = size / float(resolution)
	var half: float = size * 0.5

	var verts   := PackedVector3Array()
	var normals := PackedVector3Array()
	var colors  := PackedColorArray()
	var indices := PackedInt32Array()

	# Vertices
	for z_i in range(n):
		for x_i in range(n):
			var h: float = heights[z_i * n + x_i]
			var vx: float = x_i * step - half
			var vz: float = z_i * step - half
			verts.append(Vector3(vx, h, vz))
			colors.append(_height_to_color(h))
			normals.append(Vector3.UP)  # Placeholder — wird unten berechnet

	# Indices (Quads → Dreiecke)
	for z_i in range(resolution):
		for x_i in range(resolution):
			var i00: int = z_i * n + x_i
			var i10: int = i00 + 1
			var i01: int = (z_i + 1) * n + x_i
			var i11: int = i01 + 1
			# Dreieck 1
			indices.append(i00)
			indices.append(i01)
			indices.append(i10)
			# Dreieck 2
			indices.append(i10)
			indices.append(i01)
			indices.append(i11)

	# Normalen per Vertex berechnen (Durchschnitt der anliegenden Dreiecksnormalen)
	var tri_normals: Array = []
	for _i in range(verts.size()):
		tri_normals.append(Vector3.ZERO)

	for tri_i in range(0, indices.size(), 3):
		var a: int = indices[tri_i]
		var b: int = indices[tri_i + 1]
		var c: int = indices[tri_i + 2]
		var n_vec: Vector3 = (verts[b] - verts[a]).cross(verts[c] - verts[a]).normalized()
		tri_normals[a] += n_vec
		tri_normals[b] += n_vec
		tri_normals[c] += n_vec

	for i in range(verts.size()):
		normals[i] = (tri_normals[i] as Vector3).normalized()

	# ArrayMesh zusammensetzen
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX]  = verts
	arr[Mesh.ARRAY_NORMAL]  = normals
	arr[Mesh.ARRAY_COLOR]   = colors
	arr[Mesh.ARRAY_INDEX]   = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 0.9
	mat.metallic = 0.0

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position.y = 0.0
	return mi


func _height_to_color(h: float) -> Color:
	var ratio: float = h / max_height
	var wl_ratio: float = water_level / max_height

	if ratio < wl_ratio * 0.5:
		return COL_DEEP_WATER
	elif ratio < wl_ratio:
		return COL_SHALLOW.lerp(COL_SAND, (ratio - wl_ratio * 0.5) / (wl_ratio * 0.5))
	elif ratio < wl_ratio + 0.05:
		return COL_SAND.lerp(COL_GRASS, (ratio - wl_ratio) / 0.05)
	elif ratio < 0.55:
		return COL_GRASS
	elif ratio < 0.72:
		return COL_GRASS.lerp(COL_HILL, (ratio - 0.55) / 0.17)
	elif ratio < 0.88:
		return COL_HILL.lerp(COL_ROCK, (ratio - 0.72) / 0.16)
	else:
		return COL_ROCK.lerp(COL_SNOW, (ratio - 0.88) / 0.12)


# ─────────────────────────────────────────────
# Wasser-Plane
# ─────────────────────────────────────────────


func _build_water_plane() -> MeshInstance3D:
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(size, size)
	mesh.subdivide_width  = 4
	mesh.subdivide_depth  = 4

	var mat := StandardMaterial3D.new()
	mat.albedo_color   = Color(0.12, 0.38, 0.72, 0.72)
	mat.transparency   = StandardMaterial3D.TRANSPARENCY_ALPHA
	mat.roughness      = 0.05
	mat.metallic       = 0.3
	mat.shading_mode   = StandardMaterial3D.SHADING_MODE_PER_PIXEL

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position.y = water_level
	return mi


# ─────────────────────────────────────────────
# Physik
# ─────────────────────────────────────────────


func _build_physics_body(heights: PackedFloat32Array) -> StaticBody3D:
	var body := StaticBody3D.new()
	var col  := CollisionShape3D.new()
	var shape := HeightMapShape3D.new()

	shape.map_width  = resolution + 1
	shape.map_depth  = resolution + 1
	shape.map_data   = heights

	col.shape = shape

	# HeightMapShape3D skaliert mit der tatsächlichen Größe
	var scale_xz: float = size / float(resolution)
	col.scale = Vector3(scale_xz, 1.0, scale_xz)
	# Offset damit (0,0,0) in der Mitte liegt
	col.position = Vector3(-size * 0.5, 0.0, -size * 0.5)

	body.add_child(col)
	return body
