# res://scripts/core/EntityContext.gd
class_name EntityContext extends IEntityContext

## EntityContext — Produktions-Implementierung von IEntityContext.
##
## Wird von EntityOrchestrator erstellt und in on_spawn() injiziert.
## Hält keine Services selbst — delegiert an die übergeben Instanzen.
##
## WARUM KEIN "extends Node":
##   RefCounted reicht — kein SceneTree-Entry nötig, kein _ready().
##   Entities bekommen die Referenz via on_spawn(config, ctx) übergeben.
##
## TESTBARKEIT:
##   In Tests: MockEntityContext erstellen, nur die benötigten Felder setzen.
##   Kein ServiceOrchestrator, keine AutoLoads nötig.

var _skill_system: SkillSystem   = null
var _inventory:    InventorySystem = null
var _factory:      Factory3D      = null
var _respawn:      RespawnService  = null


## Erstellt einen EntityContext aus dem laufenden Services-Container.
## Wird von EntityOrchestrator.spawn_entity() aufgerufen.
static func from_services() -> EntityContext:
	var ctx := EntityContext.new()
	ctx._skill_system = Services.skill_system
	ctx._inventory    = Services.inventory
	ctx._factory      = Services.factory3d
	ctx._respawn      = Services.respawn
	return ctx


## Erstellt einen minimalen Kontext für Unit-Tests.
## Felder können danach direkt gesetzt werden:
##   var ctx = EntityContext.for_test()
##   ctx._skill_system = MockSkillSystem.new()
static func for_test() -> EntityContext:
	return EntityContext.new()


# ─────────────────────────────────────────────
# IEntityContext Overrides
# ─────────────────────────────────────────────

func get_skill_system() -> SkillSystem:
	return _skill_system

func get_inventory() -> InventorySystem:
	return _inventory

func get_factory() -> Factory3D:
	return _factory

func get_respawn() -> RespawnService:
	return _respawn
