# res://scripts/core/ServiceInstaller.gd
class_name ServiceInstaller extends RefCounted

## ServiceInstaller — Phase 6 der Boot-Pipeline.
##
## Prüft ob alle kritischen Services registriert sind.
## Bei fehlenden kritischen Services: Boot-Warning (kein Abbruch, da
## das Spiel eventuell auch ohne bestimmte Services lauffähig ist —
## das entscheidet GameManager.start_game()).
##
## uninstall() wird vom TeardownManager aufgerufen.

const LOG_CAT := "ServiceInstaller"

## Services die MÜSSEN vorhanden sein damit das Spiel korrekt läuft.
const CRITICAL := ["ticker", "savesystem", "gamemanager", "world", "hud"]

## Services die SOLLTEN vorhanden sein (Warnung wenn fehlt, kein Abbruch).
const RECOMMENDED := ["inventory", "skill_system", "quest", "respawn", "world_gen", "reward_dispatcher"]


func install(registry: ServiceRegistry) -> ServiceRegistry:
	var t := Logger.log_begin("ServiceInstaller.install()", LOG_CAT)
	var ok := true

	# Kritische Services prüfen
	for name in CRITICAL:
		if registry.has_service(name):
			Logger.log_debug("✓ kritisch: '%s'" % name, LOG_CAT)
		else:
			Logger.log_error("✗ KRITISCH FEHLT: '%s' — Spiel möglicherweise nicht lauffähig!" % name, LOG_CAT)
			ok = false

	# Empfohlene Services prüfen
	for name in RECOMMENDED:
		if registry.has_service(name):
			Logger.log_debug("✓ empfohlen: '%s'" % name, LOG_CAT)
		else:
			Logger.log_warn("⚠ empfohlen fehlt: '%s'" % name, LOG_CAT)

	var total := registry.get_all_names().size()
	Logger.log_end("ServiceInstaller.install()", t, LOG_CAT)
	Logger.log_info(
		"%d Services installiert. Kritische OK: %s" % [total, "ja" if ok else "NEIN"],
		LOG_CAT
	)
	return registry
