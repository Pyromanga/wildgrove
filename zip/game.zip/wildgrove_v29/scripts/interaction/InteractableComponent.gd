extends Node3D
class_name InteractableComponent

## InteractableComponent — Koppelt ein World-Objekt an das Interaktions-System.
##
## Verantwortung:
##   - Gruppe "interactable" + Meta "interactable_component" auf Parent setzen
##   - Label3D + 3D-Fortschrittsbar verwalten
##   - Interaktion via InteractionExecutor ausführen
##   - Completion-Ergebnisse nur via EventBus weitergeben
##
## Delegiert Nähe-Erkennung → ProximityDetector (eigenes Signal-basiertes Node)
##
## ARCHITEKTUR-REGEL: Emittiert NUR via EventBus — keine direkten Service-Calls.

@export var data: InteractableData
@export var detection_radius: float = 3.0

## Emitted when an interaction completes. The parent entity connects to this
## in _ready() — the component never calls get_parent() directly.
signal interacted(action_id: String)

const LOG_CAT := "Interactable"

var _bar_3d:  Factory3D.Bar3D = null
var _label:   Label3D         = null


# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────


func _ready() -> void:
	assert(data != null, "InteractableComponent braucht InteractableData! (data == null)")

	get_parent().add_to_group("interactable")
	get_parent().set_meta("interactable_component", self)

	_setup_label()
	_setup_bar()
	_setup_proximity()
	_connect_world_events()

	Logger.log_info(
		"Bereit: '%s' | Parent: '%s' | Radius: %.1fm"
		% [data.label, get_parent().name, detection_radius],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Gibt alle verfügbaren Aktionen zurück. Aufgerufen von Player.get_context_actions().
func get_actions() -> Array[InteractableAction]:
	var actions: Array[InteractableAction] = []

	var action := InteractableAction.new(data.id, data.label)
	action.duration     = data.duration
	action.xp_type      = data.xp_type
	action.xp_amount    = data.xp_amount
	action.drops        = data.drops
	action.inspect_text = data.inspect_text
	action.on_complete  = _handle_completion
	actions.append(action)

	var inspect_text := data.inspect_text if not data.inspect_text.is_empty() \
		else "%s — nichts Besonderes fällt auf." % data.label
	var inspect := InteractableAction.new(data.id + "_inspect", "Untersuchen")
	inspect.duration    = 0.0
	inspect.xp_type     = "none"
	inspect.xp_amount   = 0
	inspect.inspect_text = inspect_text
	inspect.on_complete  = func(): EventBus.world.emit_interaction_reward_text(inspect_text)
	actions.append(inspect)

	Logger.log_debug(
		"get_actions(): '%s' — %d Aktionen." % [data.label, actions.size()], LOG_CAT
	)
	return actions


func start_default_interaction() -> void:
	if not is_instance_valid(Services.interaction_executor):
		Logger.log_error("InteractionExecutor-Service fehlt!", LOG_CAT)
		return
	var actions := get_actions()
	if actions.is_empty():
		return
	Services.interaction_executor.execute_action(actions[0])


# ─────────────────────────────────────────────
# Setup
# ─────────────────────────────────────────────


func _setup_label() -> void:
	_label           = Label3D.new()
	_label.text      = data.label
	_label.position  = Vector3(0.0, 2.5, 0.0)
	_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_label.visible   = false
	add_child(_label)


func _setup_bar() -> void:
	if is_instance_valid(Services.factory3d):
		_bar_3d = Services.factory3d.create_3d_bar(self)
	else:
		Logger.log_warn("Factory3D nicht verfügbar — 3D-Fortschrittsbar fehlt.", LOG_CAT)


func _setup_proximity() -> void:
	var detector := ProximityDetector.new(detection_radius)
	add_child(detector)
	detector.player_entered.connect(_on_player_entered)
	detector.player_exited.connect(_on_player_exited)
	Logger.log_debug("ProximityDetector erstellt (Radius: %.1fm)." % detection_radius, LOG_CAT)


func _connect_world_events() -> void:
	EventBus.world.interaction_started.connect(_on_interaction_started)
	EventBus.world.interaction_finished.connect(_on_interaction_ended)
	EventBus.world.interaction_cancelled.connect(_on_interaction_ended)


# ─────────────────────────────────────────────
# Proximity
# ─────────────────────────────────────────────


func _on_player_entered() -> void:
	if is_instance_valid(_label):
		_label.visible = true
	Logger.log_info(
		"Spieler in Reichweite: '%s' (%.1fm)." % [data.label, detection_radius], LOG_CAT
	)


func _on_player_exited() -> void:
	if is_instance_valid(_label):
		_label.visible = false
	Logger.log_info("Spieler außer Reichweite: '%s'." % data.label, LOG_CAT)


# ─────────────────────────────────────────────
# Completion
# ─────────────────────────────────────────────


func _handle_completion() -> void:
	Logger.log_info("Interaktion abgeschlossen: '%s'." % data.label, LOG_CAT)

	var resolved_drops: Dictionary = {}
	if data.loot_table:
		resolved_drops = data.loot_table.roll()
	elif not data.drops.is_empty():
		resolved_drops = data.drops

	for item_id in resolved_drops:
		var qty: int = resolved_drops[item_id]
		EventBus.world.emit_loot_collected(item_id, qty)

	if data.xp_type != "none" and data.xp_amount > 0:
		EventBus.player.emit_xp(data.xp_type, data.xp_amount)

	if not data.inspect_text.is_empty():
		EventBus.world.emit_interaction_reward_text(data.inspect_text)

	if get_parent().has_method("_on_interacted"):
		interacted.emit(data.id)  # Parent connects to this signal in _ready() — no direct call


# ─────────────────────────────────────────────
# 3D-Bar (World-Events)
# ─────────────────────────────────────────────


func _on_interaction_started(action_id: String, _label: String, duration: float) -> void:
	if action_id != data.id or not is_instance_valid(_bar_3d):
		return
	if not _is_player_target():
		return
	_bar_3d.visible = true
	var t := create_tween()
	t.tween_method(func(v: float): _bar_3d.update(v), 0.0, 1.0, duration)


func _on_interaction_ended(action_id: String, _label: String) -> void:
	if action_id == data.id and is_instance_valid(_bar_3d):
		_bar_3d.visible = false


func _is_player_target() -> bool:
	# Ask the Player directly via its public API — no SceneTree group scan.
	var player_node := get_tree().get_first_node_in_group("player")
	if not is_instance_valid(player_node):
		return true  # No player present — safe default
	if not player_node.has_method("get_closest_interactable"):
		return true
	var target: Node3D = player_node.get_closest_interactable()
	if not is_instance_valid(target):
		return false
	var parent: Node = get_parent()
	return parent == target or target.is_ancestor_of(self)
