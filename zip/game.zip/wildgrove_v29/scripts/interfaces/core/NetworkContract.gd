# res://scripts/interfaces/core/NetworkContract.gd
class_name NetworkContract extends RefCounted

## NetworkContract — Definiert die Authority-Grenze vor dem Network-Layer.
##
## Löst TODO #9: Dokumentiert welche Systeme client-autoritativ und welche
## server-autoritativ sein werden. Verhindert neue direkte State-Mutationen
## in server-autoritativen Systemen.
##
## VERWENDUNG:
##   Kein Runtime-Code — diese Klasse ist ein lebendiges Architektur-Dokument
##   und Linting-Hilfe (static assertions, Helper-Methoden).
##
## KONVENTION:
##   request_*()  — Methoden die in Zukunft zum Server gehen.
##                  Derzeit: synchron und lokal.
##   on_*_confirmed() — Mutieren State nur nach Server-Bestätigung.
##                  Derzeit: direkt aufgerufen.
##
## ─────────────────────────────────────────────
## SERVER-AUTORITATIV (request_/confirmed_-Pattern PFLICHT):
## ─────────────────────────────────────────────
##   InventorySystem    — add_item, remove_item, trade
##   QuestService       — start_quest, complete_quest, update_objective
##   EntityOrchestrator — spawn_entity, despawn_entity
##   PlayerStateService — health, position (authoritative reconciliation)
##   SkillSystem        — xp_gain, level_up
##
## ─────────────────────────────────────────────
## CLIENT-AUTORITATIV (darf State direkt mutieren):
## ─────────────────────────────────────────────
##   TouchInput, PlayerCamera — Input, Kamera-Rotation, Look-Smoothing
##   HUDManager, LayoutManager — UI-State, Animation
##   Settings — lokale Display/Audio-Präferenzen
##   Logger — Logging ist lokal
##
## ─────────────────────────────────────────────
## SHARED / READ-ONLY REPLICA (Client hat Kopie, Server ist Truth):
## ─────────────────────────────────────────────
##   WorldData — Client hat eine lokale Kopie für Rendering,
##               Server ist die einzige Schreibquelle.
##   DataService — Item/Quest/Skill-Definitionen sind statisch → kein Sync nötig.

## Gibt true zurück wenn der übergebene Methodenname der request_-Konvention folgt.
## Nützlich für Runtime-Checks in Tests.
static func is_valid_request_method(method_name: String) -> bool:
	return method_name.begins_with("request_") or method_name.begins_with("on_") and "_confirmed" in method_name


## Gibt die erwartete confirm-Methode für eine request-Methode zurück.
## Beispiel: "request_add_item" → "on_item_add_confirmed"
## Konvention: request_<noun>_<verb> → on_<noun>_<verb>_confirmed
static func get_confirm_method_for(request_method: String) -> String:
	if not request_method.begins_with("request_"):
		return ""
	var stripped := request_method.substr(8)  # Remove "request_"
	return "on_%s_confirmed" % stripped


## Assertions für Tests — wirft einen Fehler wenn eine server-autoritative
## Klasse direkt State mutiert ohne request_/confirmed_-Pattern.
## Wird in IntegrationTest.gd aufgerufen.
static func assert_server_authoritative_uses_request_pattern(obj: Object, method: String) -> void:
	assert(
		is_valid_request_method(method),
		"[NetworkContract] Server-autoritative Methode '%s' in '%s' verletzt request_-Konvention."
		% [method, obj.get_class()]
	)
