# res://scripts/interfaces/core/IEntityContext.gd
class_name IEntityContext extends RefCounted

## IEntityContext — Schmale Service-Fassade für Entities.
##
## Löst TODO #1: Entities rufen keine globalen Services.xyz mehr auf.
## Stattdessen bekommen sie via on_spawn(config, context) nur die Services,
## die sie wirklich brauchen — testbar, server/client-dual-context-fähig.
##
## VERWENDUNG:
##   EntityOrchestrator erstellt einen EntityContext und injiziert ihn in on_spawn():
##     entity.on_spawn(config, context)
##
##   In einem Server-Kontext: ServerEntityContext mit anderen Implementierungen.
##   In einem Client-Kontext: ClientEntityContext mit Prediction-Services.
##   In Tests:               MockEntityContext mit Mock-Implementations.
##
## WICHTIG: Entities speichern den Context als _ctx: IEntityContext.
##   Kein Services.xyz, kein get_node("/root/Services").

# ─────────────────────────────────────────────
# Gameplay-Services
# ─────────────────────────────────────────────

## Skill-System für Schadens-Berechnung, XP-Queries.
## Gibt null zurück wenn der Kontext diesen Service nicht bereitstellt
## (z.B. rein visueller Client-Kontext).
func get_skill_system() -> SkillSystem:
	return null


## InventorySystem für Item-Checks (z.B. Tool-Requirement).
func get_inventory() -> InventorySystem:
	return null


## EventBus-Zugriff — immer vorhanden, da er ein AutoLoad ist.
## Hier als expliziter Accessor für Testbarkeit (Mock-EventBus möglich).
func get_event_bus() -> Node:
	return EventBus


# ─────────────────────────────────────────────
# Welt-Services
# ─────────────────────────────────────────────

## Factory3D für prozedurales Spawning von Sub-Entities.
func get_factory() -> Factory3D:
	return null


## RespawnService — für Entities die ihren eigenen Respawn triggern müssen.
func get_respawn() -> RespawnService:
	return null
