extends Node

## Logger — Enterprise-Grade Logger für WildGrove.
##
## AutoLoad #1 — keine Abhängigkeiten, existiert für die gesamte Laufzeit.
##
## Features (TODO #10 upgrades markiert):
##   - 4 Log-Levels: DEBUG, INFO, WARN, ERROR
##   - Automatischer Stacktrace bei ERROR
##   - Ring-Puffer (500 Einträge) für Terminal-Replay
##   - TODO #10: Hintergrund-Thread für File-I/O — Main-Thread nie blockiert
##   - TODO #10: NDJSON-Dateiformat — direkt ingestierbar von Loki/Datadog/ELK
##   - TODO #10: DEBUG-Sampling in Production (1 in N) — verhindert Log-Flood
##   - Kategorie-basiertes Muting
##   - Performance-Counter: log_count pro Level

signal on_log(formatted: String, category: String, level: int)

enum LogLevel { DEBUG, INFO, WARN, ERROR }

const MAX_BUFFER := 500  # Erhöht für lange Sessions ohne Godot-Editor
const LOG_FILE_PATH := "user://wildgrove.log"

var enabled_levels: Dictionary = {
	LogLevel.DEBUG: true,
	LogLevel.INFO: true,
	LogLevel.WARN: true,
	LogLevel.ERROR: true,
}

var _muted_categories: Array[String] = []
var _log_buffer: Array[Dictionary] = []
var _file_logging_enabled: bool = false
var _log_file: FileAccess = null

## TODO #10: Hintergrund-Thread für File-I/O
## Main-Thread enqueued Entries — Worker-Thread schreibt sie auf Disk.
var _write_thread:   Thread    = null
var _write_queue:    Array     = []        ## Main-Thread-Seite (enqueue only)
var _thread_running: bool      = false

## TODO #10: DEBUG-Sampling in Production.
## Nur 1 in debug_sample_rate DEBUG-Einträge werden emittiert.
## INFO, WARN, ERROR sind immer aktiv.
var debug_sample_rate: int  = 1     ## 1 = alle (Debug-Build), 10 = 1/10 (Production)
var _debug_sample_counter: int = 0

## TODO #10: NDJSON statt Free-Text — ein JSON-Objekt pro Zeile.
## Kompatibel mit Loki, Datadog, ELK ohne Custom-Parser.
var use_ndjson_format: bool = false  ## Aktiviert via enable_ndjson_logging()

## Performance-Counter — nützlich für Health-Checks
var log_counts: Dictionary = {
	LogLevel.DEBUG: 0,
	LogLevel.INFO: 0,
	LogLevel.WARN: 0,
	LogLevel.ERROR: 0,
}


func _ready() -> void:
	# TODO #10: In Production: DEBUG-Sampling aktivieren (1 in 10)
	if not OS.is_debug_build():
		debug_sample_rate = 10
		use_ndjson_format = true

	# File-Logging standardmäßig aktiv im Debug-Build
	if OS.is_debug_build():
		enable_file_logging()

	# TODO #10: Background-Thread für File-I/O starten
	_thread_running = true
	_write_thread = Thread.new()
	_write_thread.start(_file_writer_loop)


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_CRASH:
		# TODO #10: Sicherstellen dass alle gepufferten Log-Einträge vor dem Exit
		# geschrieben werden (Crash-Handler Integration).
		_thread_running = false
		if is_instance_valid(_write_thread) and _write_thread.is_started():
			_write_thread.wait_to_finish()
		_close_log_file()


# ─────────────────────────────────────────────
# Öffentliche Log-API
# ─────────────────────────────────────────────


func log_debug(msg: String, cat: String = "General") -> void:
	_print_log(msg, cat, LogLevel.DEBUG)


func log_info(msg: String, cat: String = "General") -> void:
	_print_log(msg, cat, LogLevel.INFO)


func log_warn(msg: String, cat: String = "General") -> void:
	_print_log(msg, cat, LogLevel.WARN)


func log_error(msg: String, cat: String = "General") -> void:
	_print_log(msg, cat, LogLevel.ERROR)
	push_error("[%s] %s" % [cat, msg])


## Setzt den minimalen Log-Level (alles darunter wird ignoriert).
## set_min_level(LogLevel.INFO) → kein DEBUG-Spam mehr.
## set_min_level(LogLevel.WARN) → nur Warnungen und Fehler.
func set_min_level(level: LogLevel) -> void:
	enabled_levels[LogLevel.DEBUG] = level <= LogLevel.DEBUG
	enabled_levels[LogLevel.INFO]  = level <= LogLevel.INFO
	enabled_levels[LogLevel.WARN]  = level <= LogLevel.WARN
	enabled_levels[LogLevel.ERROR] = true  # ERROR nie unterdrücken
	log_info("Log-Level gesetzt: %s+" % LogLevel.keys()[level], "Logger")


## Druckt eine kompakte Zusammenfassung der Session in den Log.
## Nützlich für den SimpleTerminal 'status'-Befehl.
func log_summary() -> String:
	var errs:  int = log_counts.get(LogLevel.ERROR, 0)
	var warns: int = log_counts.get(LogLevel.WARN,  0)
	var infos: int = log_counts.get(LogLevel.INFO,  0)
	var dbgs:  int = log_counts.get(LogLevel.DEBUG, 0)
	return "Log-Stats: %d ERR | %d WARN | %d INFO | %d DEBUG" % [errs, warns, infos, dbgs]


## Strukturiertes Log mit zusätzlichem Daten-Dictionary.
## Format: [Zeit] [DEBUG] [Kategorie] Nachricht | DATA: {"key": "val"}
func log_trace(msg: String, data: Dictionary = {}, cat: String = "General") -> void:
	_print_log(msg, cat, LogLevel.DEBUG, data)


## Loggt den Start einer wichtigen Operation mit Timer.
## Gibt einen Timestamp zurück — übergib ihn an log_end() für die Elapsed-Zeit.
func log_begin(operation: String, cat: String = "General") -> int:
	var t := Time.get_ticks_msec()
	_print_log("▶ BEGIN: %s" % operation, cat, LogLevel.DEBUG)
	return t


## Loggt das Ende einer Operation mit Elapsed-Zeit.
func log_end(operation: String, started_at: int, cat: String = "General") -> void:
	var elapsed := Time.get_ticks_msec() - started_at
	_print_log("■ END:   %s (%d ms)" % [operation, elapsed], cat, LogLevel.DEBUG)


# ─────────────────────────────────────────────
# File-Logging
# ─────────────────────────────────────────────


func enable_file_logging() -> void:
	if _file_logging_enabled:
		return
	_log_file = FileAccess.open(LOG_FILE_PATH, FileAccess.WRITE)
	if _log_file:
		_file_logging_enabled = true
		var header := "=== WildGrove Session: %s ===" % Time.get_datetime_string_from_system()
		_log_file.store_line(header)
		print("[Logger] File-Logging aktiv: %s" % LOG_FILE_PATH)
	else:
		push_warning("[Logger] Konnte Log-Datei nicht öffnen: %s" % LOG_FILE_PATH)


func disable_file_logging() -> void:
	_close_log_file()
	_file_logging_enabled = false


# ─────────────────────────────────────────────
# Kategorie-Kontrolle
# ─────────────────────────────────────────────


func mute_category(cat: String) -> void:
	var lower := cat.to_lower()
	if lower not in _muted_categories:
		_muted_categories.append(lower)
		print("[Logger] Kategorie stummgeschaltet: '%s'" % cat)


func unmute_category(cat: String) -> void:
	_muted_categories.erase(cat.to_lower())


func get_muted_categories() -> Array[String]:
	return _muted_categories.duplicate()


# ─────────────────────────────────────────────
# Puffer-Zugriff
# ─────────────────────────────────────────────


## Gibt den Puffer zurück UND leert ihn. Für SimpleTerminal-Replay.
func flush_log_buffer() -> Array[Dictionary]:
	var copy := _log_buffer.duplicate()
	_log_buffer.clear()
	return copy


## Gibt den Puffer zurück OHNE ihn zu leeren. Für Debug-Inspektion.
func peek_log_buffer() -> Array[Dictionary]:
	return _log_buffer.duplicate()


## Gibt die Anzahl der Logs pro Level zurück.
func get_log_stats() -> Dictionary:
	return log_counts.duplicate()


## Gibt alle ERROR-Logs aus dem Puffer zurück.
func get_errors() -> Array[Dictionary]:
	var errors: Array[Dictionary] = []
	for entry in _log_buffer:
		if entry.get("level") == LogLevel.ERROR:
			errors.append(entry)
	return errors


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _print_log(msg: String, cat: String, level: int, data: Dictionary = {}) -> void:
	if not enabled_levels.get(level, true):
		return
	if cat.to_lower() in _muted_categories:
		return

	var time: String = Time.get_datetime_string_from_system(false, true)
	var level_keys: Array = LogLevel.keys()
	var lvl_str: String = (
		level_keys[level] if level >= 0 and level < level_keys.size() else "UNKNOWN"
	)

	# Automatischer Stacktrace bei ERROR
	var final_msg := msg
	if level == LogLevel.ERROR:
		var stack := _format_stacktrace(get_stack())
		if not stack.is_empty():
			final_msg += "\n" + stack

	var data_str: String = ""
	if not data.is_empty():
		data_str = " | DATA: " + JSON.stringify(data)

	var formatted: String = "[%s] [%s] [%s] %s%s" % [time, lvl_str, cat, final_msg, data_str]

	# Ring-Puffer
	var entry := {"formatted": formatted, "category": cat, "level": level, "msg": msg, "data": data}
	_log_buffer.append(entry)
	if _log_buffer.size() > MAX_BUFFER:
		_log_buffer.pop_front()

	# Counter
	if log_counts.has(level):
		log_counts[level] += 1

	print(formatted)

	# TODO #10: DEBUG-Sampling in Production — nie für WARN/ERROR
	if level == LogLevel.DEBUG and debug_sample_rate > 1:
		_debug_sample_counter += 1
		if _debug_sample_counter % debug_sample_rate != 0:
			on_log.emit(formatted, cat, level)
			return

	# TODO #10: File-I/O via Background-Thread — kein main-thread blocking
	if _file_logging_enabled:
		_write_queue.append({"formatted": formatted, "entry": entry, "ndjson": use_ndjson_format})

	on_log.emit(formatted, cat, level)


func _format_stacktrace(stack: Array) -> String:
	if stack.is_empty():
		return ""
	var lines: PackedStringArray = PackedStringArray(["Stacktrace:"])
	for frame in stack:
		var source: String = str(frame.get("source", ""))
		var function: String = str(frame.get("function", "?"))
		var line: int = int(frame.get("line", 0))
		# Logger-interne Frames überspringen
		if source.ends_with("Logger.gd") or function in ["_print_log", "log_error"]:
			continue
		lines.append("  %s:%d in %s()" % [source, line, function])
	return "\n".join(lines)


func _close_log_file() -> void:
	if is_instance_valid(_log_file):
		_log_file.flush()
		_log_file.close()
		_log_file = null


# ─────────────────────────────────────────────
# TODO #10: Background-Thread File-Writer
# ─────────────────────────────────────────────


## Worker-Schleife — läuft auf dem Background-Thread.
## Schreibt log entries aus _write_queue auf Disk ohne Main-Thread zu blockieren.
func _file_writer_loop() -> void:
	while _thread_running or not _write_queue.is_empty():
		# Batch verarbeiten — alle aktuell in der Queue stehenden Einträge
		var batch: Array = _write_queue.duplicate()
		_write_queue.clear()

		if not batch.is_empty() and _file_logging_enabled and is_instance_valid(_log_file):
			for item in batch:
				if item.get("ndjson", false):
					_log_file.store_line(_to_ndjson(item["entry"]))
				else:
					_log_file.store_line(item["formatted"])
			_log_file.flush()  # Expliziter Flush pro Batch

		# 16ms Sleep — vermeidet Busy-Wait, bleibt reaktiv genug
		if _thread_running:
			OS.delay_msec(16)

	print("[Logger] File-Writer-Thread beendet.")


## Konvertiert einen Log-Entry in NDJSON-Format.
## Ein JSON-Objekt pro Zeile — direkt ingestierbar von Loki/Datadog/ELK.
func _to_ndjson(entry: Dictionary) -> String:
	var level_keys: Array = LogLevel.keys()
	var level_int: int    = entry.get("level", 0)
	var level_str: String = level_keys[level_int] if level_int < level_keys.size() else "UNKNOWN"

	var ndjson_obj := {
		"ts":      Time.get_unix_time_from_system(),
		"level":   level_str,
		"cat":     entry.get("category", ""),
		"msg":     entry.get("msg", ""),
	}
	if not entry.get("data", {}).is_empty():
		ndjson_obj["data"] = entry["data"]
	return JSON.stringify(ndjson_obj)


## Aktiviert NDJSON-Format für externe Log-Aggregatoren (Loki, Datadog, ELK).
## Überschreibt das bestehende Log-File mit NDJSON-Header-Kommentar.
func enable_ndjson_logging() -> void:
	use_ndjson_format = true
	print("[Logger] NDJSON-Format aktiviert.")
