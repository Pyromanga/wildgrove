# WildGrove — Enterprise Architecture TODOs
## Status nach v29-Implementierung

Alle 10 TODOs implementiert. Details unten.

---

## ✅ Critical

### 1. `IEntityContext` Interface — DONE
- `scripts/interfaces/core/IEntityContext.gd` — schmale Service-Fassade
- `scripts/core/EntityContext.gd` — Produktions-Implementierung + `for_test()` Factory
- `EntityOrchestrator.spawn_entity()` injiziert jetzt `EntityContext.from_services()` in `on_spawn(config, ctx)`
- `EnemyNPC.on_spawn(cfg, ctx)` speichert den Context, verwendet `_ctx.get_skill_system()` statt `Services.skill_system`

### 2. Save-Versioning + Migration — DONE
- `scripts/services/SaveMigrationService.gd` — versionierte Migrations-Kette (v0→v1→v2)
- `SaveSystem.configure()` ruft `SaveMigrationService.migrate(raw)` vor jedem Restore auf
- `schema_version` Key in jedem Save-Block
- Neue Migration hinzufügen: `CURRENT_VERSION` erhöhen + `_migrate_vN_to_vN1()` implementieren

---

## ✅ High Priority

### 3. `QuestProgressRecord` — DONE
- `scripts/quest/QuestProgressRecord.gd` — typisierter Container mit Validierung
- `from_save()` validiert gegen aktuelle `QuestDefinition`: unbekannte IDs → verworfen, fehlende → 0
- `update_progress()` clamps delta auf ≥0 und Progress auf [0, required]
- `QuestService._restore_from_save()` + `get_save_data()` verwenden den Record

### 4. `EnemyNPC._player_ref` gecacht — DONE
- `_player_ref: Node3D = null` in EnemyNPC
- `_ready()` cached den Player einmalig
- `_get_player()` retry-once Fallback (identisches Pattern wie AnimalBase v29)
- Bei 500 Enemies: 30.000 SceneTree-Scans/s → 0

### 5. `RespawnService` Min-Heap — DONE
- `_queue` bleibt Array, aber sortiert nach `spawn_at` aufsteigend (Sorted-Insert via Binary-Search)
- `on_tick()` prüft nur `_queue[0]` — O(1) statt O(n)
- `_heap_push()` O(log n) via Binary-Search Insert
- Bei 300 Entries: 18.000 No-Op-Vergleiche/s → 1

---

## ✅ Medium Priority

### 6. `InventorySystem` Slots + Weight + request_/confirm_ — DONE
- `max_slots: int = 28`, `current_weight: float`, `max_weight: float = 50.0`
- `request_add_item()` — Slot-Check + Gewichts-Check vor Mutation
- `on_item_add_confirmed()` — einzige Methode die `_items` mutiert
- `add_item()` bleibt als Kompatibilitäts-Alias (EventBus-Listener)
- `get_weight_status()`, `get_free_slots()` für UI

### 7. `WorldGenerationService` Thread — DONE
- `generate_world_async(seed_value)` startet Hintergrund-Thread
- Signal `generation_complete(data: WorldData)` + `generation_failed(reason)`
- `_thread_generate()` ruft synchrones `generate_world()` auf
- `call_deferred("_on_thread_done", result)` → zurück auf Main-Thread für Signal-Emission
- `on_cleanup()` joined Thread sauber

### 8. UUID v4 — DONE
- `EntityOrchestrator._generate_uuid()` verwendet 4x `randi()` (128 Bit Zufall)
- RFC 4122 Version-4-Bit-Masken korrekt gesetzt
- Kein `get_ticks_usec()` mehr — kein Kollisionsrisiko bei simultanen Clients

---

## ✅ Long-term / Architectural

### 9. Network Interface Layer — DONE (Konvention + Dokumentation)
- `scripts/interfaces/core/NetworkContract.gd` — Authority-Grenz-Dokument
- Definiert welche Systeme server-autoritativ vs. client-autoritativ sind
- `request_` / `on_*_confirmed` Konvention implementiert in InventorySystem
- `NetworkContract.assert_server_authoritative_uses_request_pattern()` für Tests

### 10. Logger Background-Thread + NDJSON + Sampling — DONE
- `_write_thread` startet in `_ready()`, schreibt File-I/O im Hintergrund
- `_to_ndjson()` — ein JSON-Objekt pro Zeile für Loki/Datadog/ELK
- `debug_sample_rate` — Production: 1/10 DEBUG-Einträge; INFO/WARN/ERROR immer
- `_notification(CRASH)` joined Thread vor Exit → kein Log-Verlust bei Crash
- `enable_ndjson_logging()` für externe Aggregatoren
