# WildGrove — Architektur & Naming-Konventionen

> Stand: v28 — Refactor-Session 3: WorldService, WorldSpawner, QuestNPC aufgeteilt

---

## 1. Was die Naming-Suffixe bedeuten

| Suffix | Erbt von | Zweck | Beispiel |
|--------|----------|-------|---------|
| `Service` | `ServiceNode` (→ `Node`) | Autoload-ähnliche Singleton-Klasse im ServiceOrchestrator. Hat configure/on_ready/on_cleanup Lifecycle. Lebt für die gesamte Spielsession. | `QuestService`, `InventorySystem`, `RespawnService` |
| `System` | `ServiceNode` | Wie Service — wird für gameplay-nahe Systeme (Skills, Inventory) verwendet. Kein semantischer Unterschied zu Service, nur Benennung. | `SkillSystem`, `InventorySystem` |
| `Manager` | `Node` | Lebt **im SceneTree** (nicht als Service), verwaltet einen lokalen Teilbereich. Wird von einem Service instanziiert und in die Szene gehängt. | `ChunkManager`, `HUDManager` |
| `Orchestrator` | `Node` | Koordiniert mehrere Sub-Systeme ohne eigene Fachlogik. Delegiert fast alles. | `EntityOrchestrator`, `ServiceOrchestrator` |
| `Handler` | `RefCounted` | Verarbeitet einen spezifischen Event-Typ oder eine Eingabe-Kategorie. Stateless oder fast stateless. | `QuestObjectiveHandler`, `WorldSaveHandler` |
| `Builder` | `RefCounted` | Erzeugt ein Objekt (Node, Mesh, Dictionary) und gibt es zurück. Kein eigener State nach dem Build. | `TerrainMeshBuilder`, `AnimalVisualBuilder`, `NPCVisualBuilder`, `HUDBuilder` |
| `Factory` | `RefCounted` oder `Node` | Wie Builder, aber breiter: erzeugt mehrere verschiedene Objekt-Typen. | `WorldFactory`, `Factory3D`, `ServiceFactory` |
| `Controller` | `Node` (meist UI-Node) | Verbindet UI-Signale mit dem EventBus oder Services. Keine Render-Logik. | `QuestPanelController`, `QuestNPCDialogController`, `PauseMenuController` |
| `Visuals` | `Node` oder `RefCounted` | Nur Render-/Layout-Logik. Kein Gameplay, kein EventBus-Emit. | `QuestPanelVisuals`, `EnemyVisuals`, `TerrainColorizer` |
| `Component` | `Node3D` oder `Node` | Fügt einer Entity eine einzelne Fähigkeit hinzu (Composition over Inheritance). | `InteractableComponent`, `HealthComponent`, `PetComponent` |
| `Detector` | `Node3D` | Physik-basierte Sensor-Node. Emittiert Signale, reagiert nicht selbst. | `ProximityDetector` |
| `Executor` | `Node` | Führt eine Operation aus (mit Dauer, Callbacks). Kein State außer "läuft/läuft nicht". | `InteractionExecutor` |
| `Sensor` | `Node` | Beobachtet etwas im SceneTree (z.B. nächste interagierbare Entity). | `InteractionSensor` |
| `Spawner` | `RefCounted` | Instanziiert und platziert Entities. Kein Lifecycle-Management danach. | `WorldSpawner`, `ChunkEntitySpawner`, `EnemySpawner` |
| `Placer` | `RefCounted` | Wie Spawner, aber für nicht-Entity-Objekte (Wasser, Deko). | `ChunkWaterPlacer`, `WaterBodyPlacer` |
| `Dispatcher` | `Node` oder `RefCounted` | Verteilt etwas (Rewards, Events) an mehrere Empfänger. | `RewardDispatcher` |
| `Registry` | `RefCounted` | Hält eine Sammlung von Definitionen / Typen. Kein Gameplay. | `EntityRegistry`, `ServiceRegistry`, `WorldEntityRegistry` |
| `Pool` | `RefCounted` | Object-Pool: acquire / release. | `EntityPool` |
| `Resolver` | `RefCounted` | Löst Abhängigkeiten oder Konflikte auf. | `ServiceDependencyResolver` |
| `Validator` | `RefCounted` oder `Node` | Prüft Zustand / Invarianten, wirft Errors/Warnings. Verändert nichts. | `ServiceValidator`, `StateValidator` |
| `Initializer` | `Node` oder `RefCounted` | Einmalige Setup-Logik beim Start. | `ServiceInitializer` |
| `Installer` | `RefCounted` | Registriert Services im Orchestrator. | `ServiceInstaller` |
| `Generator` | `RefCounted` | Erstellt Daten prozedural (Terrain, Welt-Layout). | `TerrainGenerator`, `WorldGenerationService` |
| `Ticker` | `Node` | Ruft `on_tick(delta)` auf allen registrierten Services auf. | `ServiceTicker` |
| `NPC` | `Node3D` / `StaticBody3D` | Nicht-spielbare Figur mit eigenem Verhalten. | `QuestNPC`, `EnemyNPC` |
| `AI` | `RefCounted` | State-Machine-Logik für einen NPC. Kein Node. Gibt Bewegungsvektor + Actions zurück. | `EnemyAI` |
| `Base` | `CharacterBody3D` / `Node3D` | Abstrakte Basisklasse die vererbt wird. | `AnimalBase` |
| `Data` | `Resource` oder `RefCounted` | Reines Daten-Objekt. Kein Verhalten. | `WorldData`, `PlayerData`, `InteractableData` |
| `Definition` | `Resource` | Unveränderliche Beschreibung eines Typs (aus .tres). | `QuestDefinition`, `SkillDefinition`, `ItemDefinition` |
| `Config` | `Resource` oder `RefCounted` | Konfiguration für ein System (Cooldowns, Limits). | `RespawnConfig`, `GameConfig` |
| `Helper` | `RefCounted` (statisch) | Statische Utility-Methoden ohne State. | `MathHelper` |
| `Utils` | `RefCounted` (statisch) | Breiter als Helper — mehrere unverbundene Utilities. | `UIUtils` |

---

## 2. Wann welches Suffix wählen — Entscheidungsbaum

```
Braucht es den SceneTree (_ready, _process, Signale an Nodes)?
├── Nein → RefCounted
│   ├── Erzeugt Objekte?         → Builder / Factory / Spawner / Placer
│   ├── Hält Definitionen?       → Registry
│   ├── Verarbeitet Events?      → Handler (statisch: static func)
│   ├── Prüft nur / verändert nicht? → Validator / Helper
│   └── Sonst                    → (kein Suffix, beschreibender Name)
└── Ja → Node
    ├── Lebt als Service?        → Service / System (extends ServiceNode)
    ├── Verwaltet einen Bereich? → Manager
    ├── Koordiniert Sub-Systeme? → Orchestrator
    ├── Ist UI?
    │   ├── Nur Render-Logik?    → Visuals
    │   └── Verbindet UI↔Bus?   → Controller
    ├── Fügt Fähigkeit hinzu?    → Component
    ├── Ist Physik-Sensor?       → Detector / Sensor
    ├── Führt Operation aus?     → Executor
    └── NPC-KI?                  → AI (RefCounted), NPC (Node3D)
```

---

## 3. Nächste Aufteiltungskandidaten

> In v28 wurden WorldService, WorldSpawner und QuestNPC bereits aufgeteilt (→ je ≤ 109 Z.).
> Folgende Dateien liegen noch über 150 Zeilen:

| Datei | Zeilen | Priorität | Vorschlag |
|-------|--------|-----------|-----------|
| `Logger.gd` | ~261 | Niedrig (Autoload, Ausnahme) | `LogFileWriter`, `LogBuffer`, `LogFormatter` |
| `SimpleTerminal.gd` | ~248 | Niedrig (Debug-Only) | `TerminalCommandRegistry`, `TerminalServiceCommands` |
| `SkillSystem.gd` | ~162 | Niedrig | `SkillLevelCalculator` (statisch) |
| `RespawnService.gd` | ~205 | Niedrig (gut strukturiert) | Erst aufteilen wenn Queue-Logik wächst |

---

## 4. Ordnerstruktur (Soll-Zustand)

```
scripts/
├── core/
│   ├── entity/
│   │   ├── EntityOrchestrator.gd   # Koordination
│   │   ├── EntityPool.gd           # Pooling
│   │   └── EntityRegistry.gd       # Definitionen + Instanziierung
│   ├── helpers/
│   │   ├── MathHelper.gd
│   │   └── StateValidator.gd
│   └── [Service-Infrastruktur: GameManager, ServiceOrchestrator, ...]
├── events/
│   └── [EventBus, WorldEvents, QuestEvents, ...]
├── interaction/
│   ├── InteractableComponent.gd    # Coordinator
│   ├── ProximityDetector.gd        # Sensor
│   ├── InteractionExecutor.gd      # Executor
│   └── InteractionSensor.gd        # Sensor
├── services/
│   ├── QuestService.gd             # Service
│   ├── QuestObjectiveHandler.gd    # Handler (statisch)
│   ├── SkillSystem.gd              # System
│   ├── InventorySystem.gd          # System
│   └── [DataService, SaveSystem, RewardDispatcher, ...]
├── world/
│   ├── WorldService.gd             # Service (194 Z.)
│   ├── WorldSaveHandler.gd         # Handler
│   ├── WorldEntityRegistry.gd      # Registry
│   ├── WorldSpawner.gd             # Spawner (94 Z.)
│   ├── WorldGenerationService.gd   # Service
│   ├── WorldData.gd                # Data
│   ├── WorldFactory.gd             # Factory
│   ├── WorldTimeService.gd         # Service
│   ├── RespawnService.gd           # Service
│   ├── terrain/
│   │   ├── TerrainGenerator.gd     # Generator
│   │   ├── TerrainMeshBuilder.gd   # Builder
│   │   └── TerrainColorizer.gd     # Visuals (statisch)
│   ├── chunks/
│   │   ├── ChunkManager.gd         # Manager
│   │   ├── ChunkEntitySpawner.gd   # Spawner
│   │   └── ChunkWaterPlacer.gd     # Placer
│   ├── animals/
│   │   ├── AnimalBase.gd           # Base
│   │   ├── AnimalVisualBuilder.gd  # Builder
│   │   └── Deer.gd / Rabbit.gd / Boar.gd
│   ├── combat/
│   │   ├── EnemyNPC.gd             # NPC
│   │   ├── EnemyAI.gd              # AI
│   │   ├── EnemyVisuals.gd         # Visuals
│   │   ├── EnemyAttack.gd          # Handler
│   │   ├── EnemySpawner.gd         # Spawner
│   │   └── HealthComponent.gd      # Component
│   ├── npc/
│   │   ├── QuestNPC.gd             # NPC (109 Z.)
│   │   ├── NPCVisualBuilder.gd     # Builder
│   │   └── QuestNPCDialogController.gd  # Controller
│   ├── objects/
│   │   └── OakTree.gd / IronOre.gd
│   ├── pets/
│   │   ├── PetComponent.gd         # Component
│   │   ├── AnimalCatcher.gd
│   │   └── PetRestorer.gd          # RefCounted
│   └── water/
│       ├── WaterBody.gd
│       └── WaterBodyPlacer.gd      # Placer
├── player/
│   ├── Player.gd                   # Koordination
│   ├── PlayerMover.gd
│   ├── PlayerCamera.gd
│   ├── PlayerVisuals.gd            # Visuals
│   └── PlayerSetup.gd              # Initializer
├── ui/
│   ├── controllers/                # Controller: UI↔EventBus
│   └── visuals/                    # Visuals: nur Render
└── [quest/, resources/, logger/, debug/, interfaces/]
```

---

## 5. Faustregeln

- **≤ 150 Zeilen**: Datei ist OK.
- **150–200 Zeilen**: Prüfen ob Verantwortungen gemischt sind.
- **> 200 Zeilen**: Fast immer aufteilen. Ausnahme: Logger (Autoload), SimpleTerminal (Debug-Only).
- **Jede Klasse hat genau eine Antwort auf "Was macht diese Datei?"**
- **RefCounted > Node** wenn kein SceneTree nötig.
- **Signale nur aufwärts, Services nur abwärts**: Entity → EventBus → Service. Nie Service → Entity direkt.
- **Stubs anlegen** wenn eine Verantwortung noch nicht implementiert ist — leere Klasse mit Kommentar ist besser als gemischte Klasse.
- **Koordinatoren benennen**: Wenn eine Klasse nur delegiert, im Docstring explizit "Koordinator" schreiben — das verhindert, dass die Klasse wieder wächst.
