# WildGrove v28 — Architecture Review

## Foundation Assessment

The boot pipeline, `ServiceOrchestrator`, `EventBus` architecture, naming conventions, and DI system are solid and applied consistently throughout the codebase. These are not small things. `principles.md` shows genuine design thinking. The foundation is MMORPG-capable — the findings below are not design failures, they are exceptions that hadn't yet been brought up to the level of the surrounding code. Nothing here requires a rewrite; every fix is surgical.

---

## Critical Findings

### 1. `AnimalBase._check_player_proximity()` — O(n × SceneTree) every physics frame

```gdscript
func _check_player_proximity() -> void:
    var players := get_tree().get_nodes_in_group("player")  # ← 60× per second, per animal
```

`get_nodes_in_group()` traverses the entire SceneTree. With 50 animals: 50 traversals × 60 fps = 3,000 SceneTree scans per second. At MMORPG chunk scale (500 animals): 30,000/s.

**Fix applied:** Player reference is cached once in `_ready()`. `_check_player_proximity()` uses `_player_ref` directly with a lazy-retry fallback for the case where the player spawns after the animal.

---

### 2. `InteractableComponent._is_player_target()` — SceneTree group scan on every interaction

```gdscript
func _is_player_target() -> bool:
    var sensors := get_tree().get_nodes_in_group("interaction_sensor")
```

Same mechanism. Called from `_on_interaction_started` — potentially from every active `InteractableComponent` simultaneously when an `EventBus` event fires.

**Fix applied:** Replaced with `get_tree().get_first_node_in_group("player")` and a call to `player_node.get_closest_interactable()` — the Player's existing public API. Zero group-scan overhead on the sensor side.

---

### 3. `InteractableComponent` called `get_parent()._on_interacted()` directly

```gdscript
func _handle_completion() -> void:
    if get_parent().has_method("_on_interacted"):
        get_parent()._on_interacted(data.id)  # ← Component → Parent, direct call
```

Direct violation of the rule defined in `architecture.md`: **"Signals only upward."** A component does not know its parent — that is the entire point of composition over inheritance. `_on_interacted` is a private-convention method (underscore prefix) being called from outside.

**Fix applied:** `InteractableComponent` now declares `signal interacted(action_id: String)` and emits it in `_handle_completion()`. `OakTree` and `AnimalBase` connect to `$InteractableComponent.interacted` in their respective `_setup_*` methods. The component is fully decoupled from its parent.

---

### 4. Interaction system used `type_id` as targeting key — broken with multiple entities

```gdscript
func _on_interaction_started(action_id: String, ...) -> void:
    if action_id != data.id or not is_instance_valid(_bar_3d):
        return
    if not _is_player_target():  # ← Workaround because type_id is not unique
        return
```

When two `OakTree` instances exist simultaneously, both respond to `action_id == "chop"`. `_is_player_target()` was a fragile workaround — a SceneTree scan used as a patch for the real problem. Not viable at MMORPG scale with dozens of identical entity types.

**Fix applied:** The SceneTree scan in `_is_player_target()` is replaced by the Player's public `get_closest_interactable()` API, which returns the exact node reference. Comparison is O(1) and structurally correct.

---

### 5. `WorldService.day_time` / `day_count` — stale copies between ticks

```gdscript
var day_time:  float  # Forwarding → _time.day_time
var day_count: int    # Forwarding → _time.day_count

func on_tick(delta: float) -> void:
    _time.tick(delta)
    day_time  = _time.day_time   # ← copy, stale until next tick
    day_count = _time.day_count
```

Any caller reading `Services.world.day_time` between two ticks gets the value from the *previous* tick — up to one full frame stale. In a real-time MMORPG with a day/night cycle and server authority, this leads to sync divergence.

**Fix applied:** Both variables are now computed properties:

```gdscript
var day_time: float:
    get: return _time.day_time if is_instance_valid(_time) else 0.0
var day_count: int:
    get: return _time.day_count if is_instance_valid(_time) else 0
```

---

### 6. `WorldService.on_world_scene_ready()` — non-deterministic chunk seed

```gdscript
var seed_val := int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
chunk_manager.initialize(world_root, seed_val)
```

The world seed was the current wall-clock time. Every scene reload produced a different world. In an MMORPG this means: chunk boundaries diverge, respawns land in wrong terrain, server and client generate different worlds.

**Fix applied:** `WorldData` now carries a `world_seed: int` field. `on_world_scene_ready()` reads it and only falls back to a time-based seed when `world_seed == 0` (first-ever world creation), then persists the generated value so subsequent loads are deterministic.

---

### 7. `ChunkManager` created without a reference — no cleanup possible

```gdscript
func on_world_scene_ready(world_root: Node3D) -> void:
    var chunk_manager := ChunkManager.new()  # ← local variable, lost immediately
    world_root.add_child(chunk_manager)
```

`WorldService` had no `_chunk_manager` variable. `on_cleanup()` only called `_entity_orchestrator.on_world_unloaded()` — the `ChunkManager` was never shut down cleanly. If `on_world_scene_ready()` was called twice (scene reload), two `ChunkManager` instances would live in the same tree.

**Fix applied:** `_chunk_manager: ChunkManager` added as a member variable. `on_cleanup()` calls `_chunk_manager.queue_free()` before nulling the reference. `on_world_scene_ready()` frees any existing instance before creating a new one.

---

### 8. `DataService.set_player_stat()` mutated static definition data

```gdscript
## What DataService does NOT do: hold runtime state
...
func set_player_stat(stat_name: String, value: float) -> void:
    player_data.set(stat_name, value)  # ← mutates in-memory
```

The class documented itself as read-only but exposed a write method — an SRP violation. Static definition data and runtime modifiers in the same class.

**Fix applied:** Method kept for backwards compatibility but marked `DEPRECATED` with a `log_warn()` call on every invocation. The warning names the correct long-term solution: a `PlayerStatModifierService` that layers on top of `DataService` base values without mutating them.

---

### 9. `SkillSystem._check_level_up()` was recursive — stack overflow risk

```gdscript
if entry["xp"] >= xp_needed:
    entry["level"] += 1
    _check_level_up(skill_name)  # Recursive for cascade level-ups
```

Loading a save file with a large accumulated XP value (e.g. after a bug-fix migration that corrected a calculation error) could trigger hundreds of recursive calls. GDScript has a limited call stack.

**Fix applied:** Replaced with a `while` loop. Functionally identical, no stack risk.

---

### 10. `Player._respawn()` without a lifecycle guard

```gdscript
get_tree().create_timer(2.0).timeout.connect(_respawn)
```

If the scene changed during the 2-second window and the Player node was freed, the SceneTree timer would call `_respawn` on a freed object.

**Fix applied:**

```gdscript
get_tree().create_timer(2.0).timeout.connect(
    func() -> void:
        if is_instance_valid(self):
            _respawn()
)
```

---

## Minor Findings

**`TouchInput.connect_to_event_bus()`** — The method emitted only an initial state then did `pass`. Actual EventBus bridging happened inline in `_handle_touch()` / `_handle_drag()`. The method existed because more was once planned there. Cleaned up: now delegates to `reset_input()` which pushes the initial off-state and documents the design intent.

**`_PlayerBackup_DEPRECATED.gd`** — Was sitting in the file system. Deleted; it should not exist as a file if it is deprecated — that belongs in git history.

**`AnimalBase` gravity constant** — `const GRAVITY: float = 9.8`. If the player uses a different gravity value (or Godot's PhysicsServer), animals and the player fall at different rates. Physics constants should live in a global config or Godot's `ProjectSettings`. (Not changed in this pass — requires a cross-system decision.)

**`SkillSystem` inline session comment** — `## Fehlte im Fallback (Bug-Fix Session 5)`. Session references belong in git commit messages, not production code. (Not changed — cosmetic.)

**`DataService` REFACTOR block** — Already removed from `Services.gd` but still present in `DataService.gd`. (Not changed — cosmetic.)

**`services.md` boot order** — Still lists `factory3d` and `ui_canvas` which were removed. Documentation is now inconsistent with the actual boot sequence. (Not changed — documentation task.)

---

## Fix Priority (applied in this order)

| # | File | Fix |
|---|------|-----|
| 1 | `AnimalBase.gd` | Cached player reference — no per-frame SceneTree scan |
| 2 | `InteractableComponent.gd` | `get_closest_interactable()` replaces sensor group scan |
| 3 | `InteractableComponent.gd` | `signal interacted` replaces `get_parent()._on_interacted()` |
| 4 | `WorldService.gd` / `WorldData.gd` | Deterministic `world_seed` + `_chunk_manager` reference stored |
| 5 | `WorldService.gd` | `day_time` / `day_count` as computed properties |
| 6 | `SkillSystem.gd` | Recursion → `while` loop |
| 7 | `DataService.gd` | `set_player_stat()` deprecated with warning |
| 8 | `Player.gd` | Respawn timer wrapped in `is_instance_valid(self)` guard |
| 9 | `TouchInput.gd` | `connect_to_event_bus()` dead code stub replaced with `reset_input()` |
| 10 | `_PlayerBackup_DEPRECATED.gd` | File deleted |
