class_name ChunkEntitySpawner
extends RefCounted

## ChunkEntitySpawner — Spawnt Bäume und Tiere für einen Chunk.
##
## Extrahiert aus ChunkManager._spawn_chunk_entities().
## Deterministisch über (chunk_seed ^ coord): gleicher Seed → gleiche Entities.
##
## Verwendet Services.world.spawn_entity() — muss nach Service-Init aufgerufen werden.

const LOG_CAT      := "ChunkEntitySpawner"
const ENTITY_MARGIN := 6.0  # Abstand zum Chunk-Rand

var _chunk_size: float
var _base_seed:  int


func _init(chunk_size: float, base_seed: int) -> void:
	_chunk_size = chunk_size
	_base_seed  = base_seed


## Spawnt Bäume/Tiere für coord.
## center: Chunk-Zentrum in Weltkoordinaten (Vector2).
## gen: TerrainGenerator für Höhen-Lookup.
func spawn_for_chunk(coord: Vector2i, center: Vector2, gen: TerrainGenerator) -> void:
	if not is_instance_valid(Services.world):
		return

	var half: float = _chunk_size * 0.5 - ENTITY_MARGIN
	var rng := RandomNumberGenerator.new()
	rng.seed = _base_seed ^ (coord.x * 1234567) ^ (coord.y * 7654321)

	_spawn_trees(coord, center, gen, rng, half)
	_spawn_animal(coord, center, gen, rng, half)


func _spawn_trees(
	_coord: Vector2i, center: Vector2, gen: TerrainGenerator,
	rng: RandomNumberGenerator, half: float
) -> void:
	var count := rng.randi_range(1, 4)
	for _i in range(count):
		var lx: float = rng.randf_range(-half, half)
		var lz: float = rng.randf_range(-half, half)
		var h:  float = gen.get_height_at(lx, lz)
		if h > 0.3:
			Services.world.spawn_entity("oak_tree", Vector3(center.x + lx, h, center.y + lz))


func _spawn_animal(
	coord: Vector2i, center: Vector2, gen: TerrainGenerator,
	rng: RandomNumberGenerator, half: float
) -> void:
	# Jeder dritte Chunk bekommt ein Tier (deterministisch)
	if (abs(coord.x) + abs(coord.y)) % 3 != 0:
		return

	var types: Array[String] = ["deer", "rabbit", "boar"]
	var animal_type: String  = types[rng.randi_range(0, 2)]
	var lx: float = rng.randf_range(-half, half)
	var lz: float = rng.randf_range(-half, half)
	var h:  float = gen.get_height_at(lx, lz)
	if h > 0.3:
		Services.world.spawn_entity(animal_type, Vector3(center.x + lx, h, center.y + lz))
