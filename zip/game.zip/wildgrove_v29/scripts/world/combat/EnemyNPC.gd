extends CharacterBody3D
class_name EnemyNPC

## EnemyNPC — Koordiniert KI, Gesundheit, Visuals und Interaktion.
##
## Delegiert:
##   KI-State-Machine    → EnemyAI
##   Visuals + Health-Bar → EnemyVisuals
##   Interaktions-Setup + Schaden-Berechnung → EnemyAttack
##
## on_interacted(action_id) wird von InteractableComponent nach Abschluss aufgerufen.

const LOG_CAT := "EnemyNPC"
const GRAVITY: float = 9.8

## Konfigurierbar via on_spawn(config)
var _color:        Color  = Color(0.7, 0.15, 0.15)
var _max_health:   int    = 30
var _damage:       int    = 5
var _speed:        float  = 2.5
var _detect_range: float  = 8.0
var _attack_range: float  = 1.5
var _attack_cd:    float  = 1.5
var _xp_reward:    int    = 20
var _xp_skill:     String = "combat"
var _drops:        Dictionary = {}
var _label:        String = "Goblin"

var _ai:     EnemyAI
var _health: HealthComponent
var _visuals: EnemyVisuals

var _ctx:        IEntityContext = null   ## Injected via on_spawn() — kein Services.xyz
var _player_ref: Node3D = null           ## TODO #4: Cached once — no per-frame SceneTree scan


func _ready() -> void:
	add_to_group("enemies")
	# TODO #4: Cache player reference once — avoids SceneTree scan every physics frame
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty():
		_player_ref = players[0] as Node3D
	if name == get_class() or name.begins_with("@"):
		name = "%s_%d" % [_label, get_instance_id() % 9999]

	_ai      = EnemyAI.new(_detect_range, _attack_range, _attack_cd, _speed)
	_visuals = EnemyVisuals.new()
	_visuals.build(self, _color, _max_health, _label)
	_build_collision()
	_setup_health()
	EnemyAttack.setup_interactable(self)
	Logger.log_debug("EnemyNPC '%s' bereit." % name, LOG_CAT)


func _physics_process(delta: float) -> void:
	if _ai.state == EnemyAI.State.DEAD:
		return
	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	else:
		velocity.y = 0.0

	var player := _get_player()
	if not is_instance_valid(player):
		_ai.state = EnemyAI.State.IDLE
		move_and_slide()
		return

	var result := _ai.update(self, player, delta, velocity)
	velocity = result["velocity"]
	if result["do_melee"]:
		_do_melee(player)

	_visuals.update_health_bar(_health.current_health, _health.max_health)
	move_and_slide()


# ─────────────────────────────────────────────
# Interaktions-Callback
# ─────────────────────────────────────────────


func _on_interacted(action_id: String) -> void:
	if action_id != "attack_enemy" or _ai.state == EnemyAI.State.DEAD:
		return
	var dmg := EnemyAttack.calculate_player_damage(
			_ctx.get_skill_system() if is_instance_valid(_ctx) else Services.skill_system
		)
	if is_instance_valid(_health):
		_health.take_damage(dmg)
		Logger.log_debug(
			"Spieler trifft '%s': %d Dmg → %d/%d HP"
			% [name, dmg, _health.current_health, _health.max_health],
			LOG_CAT
		)


# ─────────────────────────────────────────────
# Kampf
# ─────────────────────────────────────────────


func _do_melee(player: Node3D) -> void:
	Logger.log_debug("%s greift an: %d Dmg." % [_label, _damage], LOG_CAT)
	var hc := player.get_node_or_null("HealthComponent") as HealthComponent
	if is_instance_valid(hc):
		hc.take_damage(_damage)


func _die() -> void:
	_ai.set_dead()
	remove_from_group("interactable")
	EventBus.player.emit_xp(_xp_skill, _xp_reward)
	for item_id in _drops:
		EventBus.world.emit_loot_collected(item_id, _drops[item_id])
	var ic := get_node_or_null("AttackInteractable")
	if is_instance_valid(ic):
		ic.queue_free()
	get_tree().create_timer(1.5).timeout.connect(
		func() -> void:
			if is_instance_valid(self):
				queue_free()
	)
	Logger.log_info("%s besiegt. +%d %s XP." % [_label, _xp_reward, _xp_skill], LOG_CAT)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _setup_health() -> void:
	_health            = HealthComponent.new()
	_health.name       = "HealthComponent"
	_health.max_health = _max_health
	add_child(_health)
	_health.died.connect(_die)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.32
	sh.height = 1.0
	col.shape  = sh
	col.position.y = 0.7
	add_child(col)


func _get_player() -> Node3D:
	# TODO #4: Use cached reference — no per-frame SceneTree scan.
	# Retry once if the player spawned after this enemy (e.g. late join).
	if not is_instance_valid(_player_ref):
		var players := get_tree().get_nodes_in_group("player")
		if players.is_empty():
			return null
		_player_ref = players[0] as Node3D
	return _player_ref


# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────


func on_spawn(cfg: Dictionary = {}, ctx: IEntityContext = null) -> void:
	# TODO #1: Store injected context — used instead of Services.xyz
	_ctx = ctx
	if cfg.has("label"):       _label       = cfg["label"]
	if cfg.has("color"):       _color       = cfg["color"]
	if cfg.has("max_health"):  _max_health  = cfg["max_health"]
	if cfg.has("damage"):      _damage      = cfg["damage"]
	if cfg.has("xp_reward"):   _xp_reward   = cfg["xp_reward"]
	if cfg.has("drops"):       _drops       = cfg["drops"]
	if is_instance_valid(_health):
		_health.max_health = _max_health
		_health.reset()
	_ai.state = EnemyAI.State.IDLE
	add_to_group("interactable")


func on_despawn() -> void:
	_ai.set_dead()
