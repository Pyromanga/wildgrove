class_name EnemyAttack
extends RefCounted

## EnemyAttack — Interaktions-Setup und Schaden-Berechnung für EnemyNPC.
##
## BUG-FIX (Session 5):
##   VORHER: setup_interactable() connected auf EventBus.world.interaction_finished global.
##           Bei 3 Goblins → 3 Lambdas auf demselben Signal → jede Interaktion triggerte
##           alle drei, nur einer war das echte Ziel (Sensor-Check schlug bei 2/3 fehl).
##   NACHHER: EnemyNPC implementiert on_interacted(action_id) — InteractableComponent
##           ruft es direkt am Parent auf (wie OakTree, IronOre). Kein globales Signal-Abgreifen.
##
## VERANTWORTUNG:
##   setup_interactable() → baut InteractableData + InteractableComponent
##   calculate_player_damage() → skaliert Schaden mit combat-Level (static, testbar)

const LOG_CAT := "EnemyAttack"


static func setup_interactable(parent: Node3D) -> void:
	var d := InteractableData.new()
	d.id           = "attack_enemy"
	d.label        = "Angreifen"
	d.duration     = 0.7
	d.xp_type      = "combat"
	d.xp_amount    = 5
	d.drops        = {}
	d.inspect_text = "Ein Goblin. Feindselig und gefährlich."
	var comp := InteractableComponent.new()
	comp.name = "AttackInteractable"
	comp.data = d
	parent.add_child(comp)
	# KEIN globales Signal-Connect hier — parent.on_interacted() wird von
	# InteractableComponent via _handle_completion() → get_parent()._on_interacted() aufgerufen.


## Berechnet den Spieler-Schaden skaliert mit dem combat-Level.
## Static damit es ohne Instanz testbar ist.
static func calculate_player_damage(skill_system: SkillSystem) -> int:
	var base_dmg := 10
	if is_instance_valid(skill_system):
		base_dmg += skill_system.get_level("combat") * 2
	return base_dmg
