extends StaticBody3D
class_name QuestNPC

## QuestNPC — Stationärer Quest-Geber. Koordinator-Klasse.
##
## Delegiert seit v28 an:
##   NPCVisualBuilder          → 3D-Visuals aufbauen
##   QuestNPCDialogController  → Dialog-State-Machine
##
## Diese Klasse hält nur die Node-Lifecycle-Logik und verdrahtet
## EventBus-Signale mit dem Controller.

const LOG_CAT := "QuestNPC"

@export var quest_id:         String = "quest_woodcutter_intro"
@export var quest_obj_id:     String = "obj_chop_trees"
@export var npc_display_name: String = "Waldläufer Erik"

var _dialog: QuestNPCDialogController


func _ready() -> void:
	name = "QuestNPC_" + npc_display_name.replace(" ", "_")
	add_to_group("npcs")

	var dialog_label := NPCVisualBuilder.build(self, npc_display_name)
	_dialog = QuestNPCDialogController.new(quest_id, dialog_label, get_tree())

	_build_collision()
	_setup_interactable()

	EventBus.quest.quest_completed.connect(_on_quest_completed)
	EventBus.quest.quest_objective_updated.connect(_on_objective_updated)
	EventBus.quest.quest_start_failed.connect(_on_quest_start_failed)

	Logger.log_info("QuestNPC '%s' bereit." % npc_display_name, LOG_CAT)


# ─────────────────────────────────────────────
# EventBus-Handler
# ─────────────────────────────────────────────

func _on_objective_updated(q_id: String, obj_id: String, current: int, _required: int) -> void:
	if q_id == quest_id and obj_id == quest_obj_id:
		_dialog.on_objective_updated(q_id, current)


func _on_quest_start_failed(q_id: String, reason: String) -> void:
	if q_id == quest_id:
		_dialog.on_quest_start_failed(reason)
		Logger.log_warn("Quest-Start fehlgeschlagen '%s': %s" % [q_id, reason], LOG_CAT)


func _on_quest_completed(q_id: String, _reward: QuestReward) -> void:
	_dialog.on_quest_completed(q_id)
	if q_id == quest_id:
		Logger.log_info("Quest '%s' abgeschlossen — NPC-Status aktualisiert." % q_id, LOG_CAT)


# ─────────────────────────────────────────────
# Interaktion
# ─────────────────────────────────────────────

func _setup_interactable() -> void:
	var d := InteractableData.new()
	d.id          = "talk_quest_npc"
	d.label       = "Mit %s sprechen" % npc_display_name
	d.duration    = 0.3
	d.xp_type     = "none"
	d.xp_amount   = 0
	d.drops       = {}
	d.inspect_text = "%s. Er sieht aus als hätte er eine Aufgabe für dich." % npc_display_name
	var comp := InteractableComponent.new()
	comp.data = d
	add_child(comp)


## Aufgerufen von InteractableComponent nach Abschluss der Rede-Interaktion.
func _on_interacted(action_id: String) -> void:
	if action_id != "talk_quest_npc":
		return
	_dialog.on_interact()
	Logger.log_info("NPC interagiert, State: %s" % _dialog.state, LOG_CAT)


# ─────────────────────────────────────────────
# Collision
# ─────────────────────────────────────────────

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.35
	sh.height = 1.5
	col.shape = sh
	col.position.y = 0.75
	add_child(col)


# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────

func on_spawn(_cfg: Dictionary) -> void:
	pass


func on_despawn() -> void:
	pass
