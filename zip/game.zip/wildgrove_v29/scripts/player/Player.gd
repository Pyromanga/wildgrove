extends CharacterBody3D
class_name Player

## Player.gd — Gameplay-Loop, State-Machine, Death/Respawn.
## Setup-Logik (Subsystem-Bau) → PlayerSetup.gd
## Interaktions-Abfragen → unverändert hier (eng mit sensor/camera gekoppelt)

const LOG_CAT       := "Player"
const JUMP_VELOCITY := 6.0

var _mover:  PlayerMover
var visuals: PlayerVisuals
var camera:  PlayerCamera
var input:   TouchInput
var sensor:  InteractionSensor
var health:  HealthComponent

var _jump_requested: bool    = false
var _spawn_position: Vector3 = Vector3.ZERO
var _is_dead:        bool    = false


func _ready() -> void:
	add_to_group("player")
	set_physics_process(false)
	EventBus.player.movement_interrupted.connect(_on_action_interrupted)
	Logger.log_debug("Player bereit. Warte auf Services...", LOG_CAT)

	if is_instance_valid(Services.game_manager):
		_on_core_ready()
	else:
		EventBus.system.services_initialized.connect(_on_core_ready, CONNECT_ONE_SHOT)


func _on_core_ready() -> void:
	Logger.log_info("Initialisiere Player-System.", LOG_CAT)
	var subs := PlayerSetup.build(self)
	_mover  = subs["mover"]
	visuals = subs["visuals"]
	camera  = subs["camera"]
	input   = subs["input"]
	sensor  = subs["sensor"]
	health  = subs["health"]
	health.died.connect(_on_player_died)

	PlayerSetup.apply_stats(_mover)
	_spawn_position = global_position
	set_physics_process(true)
	Logger.log_info("Player-System online.", LOG_CAT)


# ─────────────────────────────────────────────
# Physics-Loop
# ─────────────────────────────────────────────

func _physics_process(delta: float) -> void:
	if not is_instance_valid(Services.player_states):
		return
	match Services.player_states.get_state():
		PlayerStateService.State.FREE:
			_loop_free(delta)
		PlayerStateService.State.BUSY:
			_loop_busy(delta)
		_:
			velocity = Vector3.ZERO
			move_and_slide()


func _loop_free(delta: float) -> void:
	var move_dir := MathHelper.calculate_move_direction(camera, input.js_vec)
	velocity = _mover.calculate_velocity(velocity, move_dir, delta, is_on_floor())
	if _jump_requested:
		_jump_requested = false
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
	move_and_slide()
	visuals.handle_rotation(move_dir, delta)
	camera.handle_input(input, delta)


func _loop_busy(delta: float) -> void:
	if input.js_vec.length() > 0.5:
		EventBus.player.emit_movement_interrupted()
	velocity = velocity.move_toward(Vector3.ZERO, 15.0 * delta)
	move_and_slide()
	camera.handle_input(input, delta)


# ─────────────────────────────────────────────
# Jump / Death / Respawn
# ─────────────────────────────────────────────

func request_jump() -> void:
	_jump_requested = true


func _on_player_died() -> void:
	if _is_dead:
		return
	_is_dead = true
	Logger.log_info("Spieler gestorben — Respawn in 2s.", LOG_CAT)
	EventBus.player.emit_player_died()
	# Guard against the node being freed during the 2-second window (e.g. scene change).
	get_tree().create_timer(2.0).timeout.connect(
		func() -> void:
			if is_instance_valid(self):
				_respawn()
	)


func _respawn() -> void:
	global_position = _spawn_position
	if is_instance_valid(health):
		health.reset()
	velocity        = Vector3.ZERO
	_is_dead        = false
	_jump_requested = false
	EventBus.player.emit_player_respawned()
	Logger.log_info("Spieler respawnt.", LOG_CAT)


func _on_action_interrupted() -> void:
	visuals.play_effect("interrupted")


# ─────────────────────────────────────────────
# Öffentliche API — Interaktion
# ─────────────────────────────────────────────

func get_closest_interactable() -> Node3D:
	return sensor.get_closest() if is_instance_valid(sensor) else null


func get_context_actions() -> Array:
	var target := get_closest_interactable()
	if not is_instance_valid(target):
		return []

	Logger.log_debug("Kontext für '%s'." % target.name, LOG_CAT)

	if target.has_meta("interactable_component"):
		var comp: InteractableComponent = target.get_meta("interactable_component")
		if is_instance_valid(comp):
			var actions := comp.get_actions()
			Logger.log_info("%d Aktion(en) für '%s'." % [actions.size(), target.name], LOG_CAT)
			return actions

	# Fallback: Child-Traversal
	for child in target.get_children():
		if child is InteractableComponent:
			return (child as InteractableComponent).get_actions()

	if target.has_method("start_default_interaction"):
		var fallback := InteractableAction.new("interact", "Interagieren")
		fallback.duration   = 1.5
		fallback.on_complete = func(): target.start_default_interaction()
		return [fallback]

	return []
