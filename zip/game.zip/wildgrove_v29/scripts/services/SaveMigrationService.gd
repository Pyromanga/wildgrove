# res://scripts/services/SaveMigrationService.gd
class_name SaveMigrationService extends RefCounted

## SaveMigrationService — Versionierte, verkettete Save-Migrationen.
##
## Löst TODO #2: Jeder Save-Block trägt eine Schema-Versionsnummer.
## Beim Laden wird geprüft, ob Migrationen nötig sind, und diese
## der Reihe nach ausgeführt: v1 → v2 → v3 → ... → CURRENT_VERSION.
##
## VERWENDUNG (in SaveSystem._read_from_disk()):
##   var migrated := SaveMigrationService.migrate(raw_dict)
##
## MIGRATION HINZUFÜGEN:
##   1. CURRENT_VERSION um 1 erhöhen.
##   2. Neue Methode _migrate_vN_to_vN1(data) implementieren.
##   3. In _migration_steps[] registrieren.
##
## DESIGN:
##   - Jede Migration bekommt das gesamte Save-Dictionary
##     (nicht nur einen Sub-Block), da Migrationen auch Keys
##     umbenennen oder zwischen Blöcken verschieben können.
##   - Migrationen sind rein funktional: Input rein, Output raus, kein State.
##   - Ein fehlgeschlagener Parse-Wert wird mit Fallback behandelt — niemals crash.

const CURRENT_VERSION := 2
const LOG_CAT := "SaveMigration"

## Einstiegspunkt — gibt ein migriertes Dictionary zurück.
## Ist data bereits auf CURRENT_VERSION, wird es unverändert zurückgegeben.
static func migrate(data: Dictionary) -> Dictionary:
	var version: int = data.get("schema_version", 0)

	if version == CURRENT_VERSION:
		return data

	if version > CURRENT_VERSION:
		Logger.log_warn(
			"Save-Version %d > Software-Version %d — möglicherweise Downgrade." \
			% [version, CURRENT_VERSION],
			LOG_CAT
		)
		return data

	Logger.log_info(
		"Migriere Save von v%d → v%d." % [version, CURRENT_VERSION],
		LOG_CAT
	)

	var migrated := data.duplicate(true)

	# Migrations-Kette: jede Stufe genau einmal ausführen
	if version < 1:
		migrated = _migrate_v0_to_v1(migrated)
		version = 1

	if version < 2:
		migrated = _migrate_v1_to_v2(migrated)
		version = 2

	migrated["schema_version"] = CURRENT_VERSION
	Logger.log_info("Migration abgeschlossen. Schema ist jetzt v%d." % CURRENT_VERSION, LOG_CAT)
	return migrated


# ─────────────────────────────────────────────
# Migrations-Implementierungen
# ─────────────────────────────────────────────


## v0 → v1: Ursprüngliches Format hatte kein schema_version-Feld.
## Kein Inhalt ändert sich — nur das Version-Tag wird gesetzt.
## Alle bestehenden Keys bleiben unberührt.
static func _migrate_v0_to_v1(data: Dictionary) -> Dictionary:
	Logger.log_debug("Migration v0→v1: schema_version hinzugefügt.", LOG_CAT)
	data["schema_version"] = 1
	# Quest-Format: active_quests war ein flaches Dictionary ohne typed records.
	# Wird in v2 validiert — hier nur tagging.
	return data


## v1 → v2: QuestService bekommt typed QuestProgressRecord-Format.
## Alte Struktur: { "quest_id": { "status": "started", "objectives": { "obj_id": int } } }
## Neue Struktur: { "quest_id": { "status": "started", "level": 1, "objectives": { "obj_id": int }, "started_at": 0 } }
static func _migrate_v1_to_v2(data: Dictionary) -> Dictionary:
	Logger.log_debug("Migration v1→v2: QuestProgressRecord-Felder normalisiert.", LOG_CAT)

	var quest_block: Variant = data.get("quest_progress")
	if not quest_block is Dictionary:
		return data

	var qb := quest_block as Dictionary
	var active: Variant = qb.get("active")
	if not active is Dictionary:
		return data

	var active_dict := active as Dictionary
	for quest_id in active_dict.keys():
		var entry: Variant = active_dict[quest_id]
		if not entry is Dictionary:
			active_dict[quest_id] = {"status": "started", "level": 1, "objectives": {}, "started_at": 0}
			continue
		var e := entry as Dictionary
		# Fehlende Felder mit Defaults auffüllen
		if not e.has("level"):       e["level"]      = 1
		if not e.has("started_at"):  e["started_at"] = 0
		if not e.has("status"):      e["status"]     = "started"
		if not e.has("objectives"):  e["objectives"] = {}

	return data
