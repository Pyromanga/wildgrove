extends ServiceNode
class_name InventorySystem

## InventorySystem — Verwaltet das Spieler-Inventar.
## Abhängigkeiten (deps): ["data", "savesystem"]
##
## REFACTOR (Session 4):
##   _load_item_database() entfernt — InventorySystem öffnet kein DirAccess mehr.
##   Item-Registry kommt jetzt von DataService.get_all_items() (zentrales Repository).

signal inventory_changed(items: Array)

const LOG_CAT := "Inventory"
const SAVE_KEY := "inventory"

var _items: Dictionary = {}           # { "item_id": quantity }
var _item_registry: Dictionary = {}   # { "item_id": ItemDefinition } — von DataService

var _save_system: SaveSystem

# ─────────────────────────────────────────────
# TODO #6: Slot-basiertes Inventar + Weight
# ─────────────────────────────────────────────

## Maximale Anzahl unterschiedlicher Item-Slots (unique Item-IDs).
## Gesetzt von configure() via PlayerData.max_inventory_slots oder Default.
var max_slots: int = 28

## Aktuelles Gewicht (Summe aller item.weight * quantity).
var current_weight: float = 0.0

## Maximales Gewicht. 0.0 = kein Limit (bis max_slots aktiviert ist).
var max_weight: float = 50.0


# ─────────────────────────────────────────────
# Phase 4: Configure (DI)
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	var t := Logger.log_begin("InventorySystem.configure()", LOG_CAT)

	# Item-Registry aus DataService — kein eigenes DirAccess mehr
	var data_service := deps.get("data") as DataService
	if is_instance_valid(data_service):
		_item_registry = data_service.get_all_items()
		Logger.log_debug("Item-Registry von DataService: %d Items." % _item_registry.size(), LOG_CAT)
	else:
		Logger.log_error("DataService fehlt — Item-Registry leer!" , LOG_CAT)

	_save_system = deps.get("savesystem") as SaveSystem
	if _save_system:
		_save_system.register_save_provider(self)
		var saved: Variant = _save_system.get_state_for(SAVE_KEY)
		if saved is Dictionary and not (saved as Dictionary).is_empty():
			_restore_from_save(saved)
	else:
		Logger.log_error("Abhängigkeit 'savesystem' fehlt!", LOG_CAT)

	# TODO #6: Slot/Gewichts-Limits aus PlayerData laden (wenn vorhanden)
	var player_data: PlayerData = data_service.get_player_data() if is_instance_valid(data_service) and data_service.has_method("get_player_data") else null
	if is_instance_valid(player_data):
		if player_data.get("max_inventory_slots") != null:
			max_slots  = player_data.max_inventory_slots
		if player_data.get("max_carry_weight") != null:
			max_weight = player_data.max_carry_weight
		Logger.log_debug("Slots: %d, Max-Gewicht: %.1f kg." % [max_slots, max_weight], LOG_CAT)

	Logger.log_end("InventorySystem.configure()", t, LOG_CAT)
	Logger.log_info(
		"Initialisiert. %d Items in DB, %d im Rucksack. Slots: %d/%d." % [_item_registry.size(), _items.size(), _items.size(), max_slots],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────


func on_ready() -> void:
	# Initialen Zustand publizieren
	inventory_changed.emit(get_all_items())
	# Loot-Events von InteractableComponent abhören — statt direkter Service-Kopplung.
	# InteractableComponent ruft kein Services.inventory.add_item() mehr auf,
	# sondern emittiert EventBus.world.loot_collected. Wir horchen hier darauf.
	EventBus.world.loot_collected.connect(add_item)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────


func get_save_key() -> String:
	return SAVE_KEY


func get_save_data() -> Dictionary:
	# Duplicate verhindert, dass das SaveSystem Referenzen manipuliert
	return _items.duplicate()


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## TODO #6: request_/confirm_ Namenskonvention — dokumentiert den zukünftigen
## Server-Authority-Kontrakt, ohne die Implementierung zu brechen.
## Wenn der Network-Layer ankommt: request_add_item() schickt die Anfrage ans Server,
## on_item_add_confirmed() mutiiert dann den lokalen State.
## Derzeit: synchron und lokal — die Naming Convention ist der Kontrakt.
func request_add_item(item_id: String, quantity: int = 1) -> bool:
	## Gibt true zurück wenn das Item hinzugefügt werden konnte, false bei Fehler.
	## Fehlergründe: unbekannte ID, Slot-Limit, Gewichts-Limit, Stack-Limit.
	var def := get_item_info(item_id)
	if not def:
		Logger.log_error("Item-ID '%s' unbekannt." % item_id, LOG_CAT)
		return false

	# Slot-Check: Neues Item nur wenn freie Slots vorhanden
	if not _items.has(item_id) and _items.size() >= max_slots:
		Logger.log_warn(
			"Inventar voll (%d/%d Slots) — '%s' abgelehnt." % [_items.size(), max_slots, item_id],
			LOG_CAT
		)
		return false

	# Gewichts-Check
	if max_weight > 0.0:
		var item_weight: float = def.get("weight") if def.get("weight") != null else 0.0
		var added_weight: float = item_weight * quantity
		if current_weight + added_weight > max_weight:
			Logger.log_warn(
				"Gewichtslimit (%.1f/%.1f kg) — '%s' abgelehnt." % [current_weight, max_weight, item_id],
				LOG_CAT
			)
			return false

	# Delegation an confirm — derzeit synchron, beim Network-Layer async
	on_item_add_confirmed(item_id, quantity)
	return true


## Kompatibilitäts-Alias — bestehende Aufrufe (EventBus-Listener) weiterhin bedienen.
## Deprecated: Neuer Code soll request_add_item() verwenden.
func add_item(item_id: String, quantity: int = 1) -> void:
	request_add_item(item_id, quantity)


## Server-Bestätigung (derzeit lokal synchron, zukünftig: via RPC vom Server).
## ONLY this method mutates _items — nie direkt aus request_add_item().
func on_item_add_confirmed(item_id: String, quantity: int) -> void:
	var def := get_item_info(item_id)
	if not def:
		return

	var current: int = _items.get(item_id, 0)
	var new_qty: int = min(current + quantity, def.max_stack)
	var actual_added: int = new_qty - current

	_items[item_id] = new_qty

	# Gewicht nachführen
	var item_weight: float = def.get("weight") if def.get("weight") != null else 0.0
	current_weight += item_weight * actual_added

	inventory_changed.emit(get_all_items())
	Logger.log_debug(
		"Item hinzugefügt: '%s' x%d. Gewicht: %.1f/%.1f kg, Slots: %d/%d." 		% [item_id, actual_added, current_weight, max_weight, _items.size(), max_slots],
		LOG_CAT
	)


func remove_item(item_id: String, quantity: int = 1) -> bool:
	var current: int = _items.get(item_id, 0)
	if current < quantity:
		Logger.log_warn("Zu wenig '%s' (Besitz: %d)." % [item_id, current], LOG_CAT)
		return false

	_items[item_id] = current - quantity
	if _items[item_id] <= 0:
		_items.erase(item_id)

	inventory_changed.emit(get_all_items())
	return true


func has_item(item_id: String, quantity: int = 1) -> bool:
	return _items.get(item_id, 0) >= quantity


func get_all_items() -> Array:
	var result: Array = []
	for item_id in _items:
		var def: ItemDefinition = _item_registry.get(item_id)
		result.append(
			{
				"id":       item_id,
				"name":     def.display_name if def else item_id,
				"quantity": _items[item_id],
				"icon":     def.icon if def else null,
				"weight":   def.get("weight") if def and def.get("weight") != null else 0.0,
			}
		)
	return result


## TODO #6: Gewichts-Status für UI
func get_weight_status() -> Dictionary:
	return {"current": current_weight, "max": max_weight}


## TODO #6: Freie Slots für UI
func get_free_slots() -> int:
	return max(0, max_slots - _items.size())


func get_item_info(item_id: String) -> ItemDefinition:
	return _item_registry.get(item_id)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _restore_from_save(saved: Dictionary) -> void:
	for item_id in saved:
		if _item_registry.has(item_id):
			_items[item_id] = int(saved[item_id])
