extends ServiceNode
class_name QuestService

## QuestService — Verwaltet den Fortschritt aller Quests.
##
## Abhängigkeiten (deps): ["data", "savesystem", "skill_system", "reward_dispatcher"]
##
## Delegiert Event→Objective-Auflösung → QuestObjectiveHandler (statische Helfer-Klasse)
##
## ARCHITEKTUR:
##   - Keine Referenz auf InventorySystem
##   - skill_system per DI für Level-Checks in SKILL-Objectives
##   - Reward-Auszahlung über RewardDispatcher
##   - Quest-Unlock via EventBus.quest.quest_unlock_requested

const LOG_CAT  := "Quest"
const SAVE_KEY := "quest_progress"

var _data_service:      DataService
var _save_system:       SaveSystem
var _skill_system:      SkillSystem
var _reward_dispatcher: RewardDispatcher

var _definitions: Dictionary = {}   # { quest_id: QuestDefinition }

## TODO #3: Werte sind jetzt QuestProgressRecord-Instanzen, nicht rohe Dicts.
var active_quests:    Dictionary     = {}  # { quest_id: QuestProgressRecord }
var completed_quests: Array[String]  = []
var available_quests: Array[String]  = []


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	var t := Logger.log_begin("QuestService.configure()", LOG_CAT)

	_data_service      = deps.get("data")              as DataService
	_save_system       = deps.get("savesystem")        as SaveSystem
	_skill_system      = deps.get("skill_system")      as SkillSystem
	_reward_dispatcher = deps.get("reward_dispatcher") as RewardDispatcher

	if is_instance_valid(_data_service):
		_definitions = _data_service.get_all_quests()
		Logger.log_debug("Quest-Definitionen geladen: %d" % _definitions.size(), LOG_CAT)
	else:
		Logger.log_warn("DataService fehlt — Quest-Definitionen nicht geladen.", LOG_CAT)

	if is_instance_valid(_save_system):
		_save_system.register_save_provider(self)
		var saved: Dictionary = _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_restore_from_save(saved)
	else:
		Logger.log_warn("SaveSystem fehlt — Quest-Fortschritt nicht gespeichert.", LOG_CAT)

	Logger.log_end("QuestService.configure()", t, LOG_CAT)
	Logger.log_info(
		"Konfiguriert. Definitionen: %d, Aktiv: %d, Abgeschlossen: %d."
		% [_definitions.size(), active_quests.size(), completed_quests.size()],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────


func on_ready() -> void:
	EventBus.world.loot_collected.connect(_on_loot_collected)
	EventBus.player.xp_gained.connect(_on_xp_gained)
	EventBus.world.interaction_finished.connect(_on_interaction_finished)
	EventBus.quest.quest_unlock_requested.connect(unlock_quest)
	EventBus.quest.quest_start_requested.connect(start_quest)

	if is_instance_valid(_data_service):
		for quest_id in _data_service.get_auto_start_quests():
			if not completed_quests.has(quest_id) and not active_quests.has(quest_id):
				start_quest(quest_id)

	Logger.log_info("QuestService aktiv.", LOG_CAT)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────


func get_save_key() -> String: return SAVE_KEY

func get_save_data() -> Dictionary:
	return {
		"active":    active_quests.duplicate(true),
		"completed": completed_quests.duplicate(),
		"available": available_quests.duplicate(),
	}


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


func start_quest(quest_id: String) -> bool:
	if quest_id.is_empty():
		Logger.log_error("start_quest(): quest_id ist leer!", LOG_CAT)
		return false
	if completed_quests.has(quest_id):
		EventBus.quest.emit_quest_start_failed(quest_id, "already_completed")
		return false
	if active_quests.has(quest_id):
		EventBus.quest.emit_quest_start_failed(quest_id, "already_active")
		return false

	var def: QuestDefinition = _definitions.get(quest_id)
	if def:
		for prereq in def.prerequisites:
			if not completed_quests.has(prereq):
				EventBus.quest.emit_quest_start_failed(quest_id, "prereq_missing:%s" % prereq)
				return false

	var objectives: Dictionary = {}
	if def:
		for obj in def.objectives:
			objectives[obj.id] = 0

	active_quests[quest_id] = {"status": "started", "objectives": objectives}
	available_quests.erase(quest_id)
	EventBus.quest.emit_quest_started(quest_id)
	Logger.log_info("Quest gestartet: '%s'." % quest_id, LOG_CAT)
	return true


func complete_quest(quest_id: String) -> void:
	if not active_quests.has(quest_id):
		return
	active_quests.erase(quest_id)
	completed_quests.append(quest_id)

	var def: QuestDefinition = _definitions.get(quest_id)
	var reward: QuestReward  = def.reward if (def and def.reward) else null

	if reward and is_instance_valid(_reward_dispatcher):
		_reward_dispatcher.dispatch(reward)
	elif reward:
		Logger.log_warn("RewardDispatcher fehlt — Reward für '%s' nicht ausgezahlt!" % quest_id, LOG_CAT)

	EventBus.quest.emit_quest_completed(quest_id, reward)
	Logger.log_info("Quest abgeschlossen: '%s'." % quest_id, LOG_CAT)
	_unlock_followup_quests(quest_id)


func fail_quest(quest_id: String) -> void:
	if not active_quests.has(quest_id):
		return
	active_quests.erase(quest_id)
	EventBus.quest.emit_quest_failed(quest_id)


func unlock_quest(quest_id: String) -> void:
	if completed_quests.has(quest_id) or active_quests.has(quest_id):
		return
	if not available_quests.has(quest_id):
		available_quests.append(quest_id)
		EventBus.quest.emit_quest_unlocked(quest_id)
		Logger.log_info("Quest freigeschaltet: '%s'." % quest_id, LOG_CAT)


func update_objective(quest_id: String, objective_id: String, delta: int) -> void:
	# TODO #3: Verwendet QuestProgressRecord — kein ungetyptes Dict, kein blindes current+delta.
	if not active_quests.has(quest_id):
		return

	var record: QuestProgressRecord = active_quests[quest_id]
	var def: QuestDefinition        = _definitions.get(quest_id)
	if def == null:
		return

	var required := 1
	for obj in def.objectives:
		if obj.id == objective_id:
			required = obj.required
			break

	# update_progress clamps delta≥0 und Progress auf [0, required]
	var new_val := record.update_progress(objective_id, delta, required)

	Logger.log_debug(
		"Objective '%s/%s': %d (+%d) / %d." % [quest_id, objective_id, new_val, delta, required],
		LOG_CAT
	)
	EventBus.quest.emit_objective_updated(quest_id, objective_id, new_val, required)
		if QuestObjectiveHandler.is_completable(quest_id, objectives, def):
			complete_quest(quest_id)


func is_quest_active(quest_id: String)    -> bool: return active_quests.has(quest_id)
func is_quest_completed(quest_id: String) -> bool: return completed_quests.has(quest_id)

func get_objective_progress(quest_id: String, objective_id: String) -> int:
	if not active_quests.has(quest_id):
		return 0
	return active_quests[quest_id]["objectives"].get(objective_id, 0)


# ─────────────────────────────────────────────
# Event-Handler → delegiert an QuestObjectiveHandler
# ─────────────────────────────────────────────


func _on_loot_collected(item_id: String, quantity: int) -> void:
	for upd in QuestObjectiveHandler.resolve_loot(item_id, quantity, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])


func _on_xp_gained(skill_name: String, _amount: int) -> void:
	for upd in QuestObjectiveHandler.resolve_xp(skill_name, active_quests, _definitions, _skill_system):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])


func _on_interaction_finished(action_id: String, _label: String) -> void:
	for upd in QuestObjectiveHandler.resolve_interaction(action_id, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _unlock_followup_quests(completed_id: String) -> void:
	for quest_id in _definitions:
		var def: QuestDefinition = _definitions[quest_id]
		if completed_quests.has(quest_id) or active_quests.has(quest_id):
			continue
		if not def.prerequisites.has(completed_id):
			continue
		var all_met := true
		for prereq in def.prerequisites:
			if not completed_quests.has(prereq):
				all_met = false
				break
		if all_met:
			unlock_quest(quest_id)
			if def.auto_start:
				start_quest(quest_id)


func _restore_from_save(saved_data: Dictionary) -> void:
	# TODO #3: Validierung gegen aktuelle Definitionen — niemals blindes Dict-Assign.
	# Unbekannte Objective-IDs werden verworfen, fehlende mit 0 initialisiert.
	# Negative/Over-Progress-Werte werden auf [0, required] geclampt.
	var saved_active: Variant = saved_data.get("active", {})
	if saved_active is Dictionary:
		for quest_id in (saved_active as Dictionary).keys():
			var def: QuestDefinition = _definitions.get(quest_id)
			if def == null:
				Logger.log_warn("Quest '%s' nicht in Definitionen — Save-Eintrag verworfen." % quest_id, LOG_CAT)
				continue
			var raw_entry: Variant = (saved_active as Dictionary)[quest_id]
			var entry_dict := raw_entry as Dictionary if raw_entry is Dictionary else {}
			active_quests[quest_id] = QuestProgressRecord.from_save(quest_id, entry_dict, def)

	var saved_completed: Variant = saved_data.get("completed", [])
	completed_quests = saved_completed if saved_completed is Array else []

	var saved_available: Variant = saved_data.get("available", [])
	available_quests = saved_available if saved_available is Array else []

	Logger.log_info(
		"Quest-State geladen: aktiv=%d, abgeschlossen=%d, verfügbar=%d."
		% [active_quests.size(), completed_quests.size(), available_quests.size()],
		LOG_CAT
	)
