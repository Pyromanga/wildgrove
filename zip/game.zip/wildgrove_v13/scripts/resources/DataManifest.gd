class_name DataManifest

## DataManifest — Explizite Liste aller statischen Ressourcen-Pfade.
##
## WARUM: DirAccess.open("res://...") funktioniert auf Android nicht —
## Godot-PCK-Archive erlauben keine Verzeichnisauflistung zur Laufzeit.
## Außerdem erkennt der Godot-Exporter mit export_filter="all_resources"
## nur Ressourcen die im SceneTree oder via preload() referenziert sind.
## Ressourcen die nur per DirAccess-Scan geladen werden, landen NICHT im APK.
##
## LÖSUNG: Alle Pfade hier als Konstanten auflisten.
##   - Der Exporter sieht die String-Literals und packt die Dateien ein.
##   - DataService nutzt diese Listen statt DirAccess.
##   - Neue Items/Quests: Pfad hier ergänzen → automatisch exportiert.

const ITEMS: Array[String] = [
	"res://data/items/LogNormal.tres",
	"res://data/items/LogOak.tres",
	"res://data/items/LogMaple.tres",
	"res://data/items/LogWillow.tres",
	"res://data/items/IronOre.tres",
	"res://data/items/CopperOre.tres",
]

const QUESTS: Array[String] = [
	"res://data/quests/quest_woodcutter_intro.tres",
]

const SKILLS: Array[String] = [
	"res://data/skills/woodcutting.tres",
	"res://data/skills/mining.tres",
	"res://data/skills/farming.tres",
]
