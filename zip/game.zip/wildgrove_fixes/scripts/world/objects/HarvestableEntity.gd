extends Node3D
class_name HarvestableEntity

## HarvestableEntity — Basisklasse für alle abbau-/fällbaren Welt-Objekte.
##
## Subklassen implementieren:
##   _get_entity_type_id() -> String   — EntityRegistry-Key ("oak_tree", "iron_ore", ...)
##   _build_interactable_data() -> InteractableData — Typ-spezifische Interaktion
##   _build_visuals()                  — Typ-spezifische 3D-Darstellung
##
## Die Basisklasse übernimmt:
##   - Lifecycle (on_spawn / on_despawn / _ready)
##   - InteractableComponent aufbauen und verdrahten
##   - Context in InteractableComponent propagieren
##   - Despawn via EntityOrchestrator (UUID-Lookup) oder Fallback queue_free()
##   - Harvest-State via WorldService.mark_harvested(type_id, pos)
##
## Neue Ressource-Typen (WillowTree, CopperOre, ...): nur Subklasse anlegen,
## 3 Methoden implementieren, in WorldEntityRegistry.register_all() eintragen.
## Kein Lifecycle-Code mehr kopieren.

var _interactable_comp: InteractableComponent = null
var _ctx:               IEntityContext        = null

# ─────────────────────────────────────────────
# Abstrakt — Subklassen müssen überschreiben
# ─────────────────────────────────────────────

## EntityRegistry-Key dieser Entität. Wird für Harvest-State-Key genutzt.
## Beispiele: "oak_tree", "iron_ore", "copper_ore", "willow_tree"
func _get_entity_type_id() -> String:
	push_error("HarvestableEntity: _get_entity_type_id() nicht implementiert in '%s'." % get_class())
	return "unknown"

## Erstellt und gibt die Typ-spezifischen InteractableData zurück.
## Wird einmalig in _ready() aufgerufen.
func _build_interactable_data() -> InteractableData:
	push_error("HarvestableEntity: _build_interactable_data() nicht implementiert in '%s'." % get_class())
	return InteractableData.new()

## Erstellt die 3D-Darstellung dieser Entität.
## Wird in on_spawn() aufgerufen wenn ctx.get_factory3d() verfügbar ist.
## Für Factory3D-Calls: ctx ist zu diesem Zeitpunkt gesetzt.
func _build_visuals() -> void:
	push_error("HarvestableEntity: _build_visuals() nicht implementiert in '%s'." % get_class())

# ─────────────────────────────────────────────
# Lifecycle — geerbt, nicht überschreiben
# ─────────────────────────────────────────────

func _ready() -> void:
	var type_id := _get_entity_type_id()
	if name == get_class() or name.begins_with("@"):
		name = "%s_%d" % [type_id, get_instance_id() % 9999]
	set_multiplayer_authority(1)
	_setup_interactable()
	AppLogger.log_info(
		"%s bereit bei %s. Label: '%s'." % [
			type_id,
			str(position),
			_interactable_comp.data.label if _interactable_comp else "?"
		],
		type_id
	)

## Aufgerufen von EntityOrchestrator NACH add_child() und NACH _ready().
func on_spawn(config: Dictionary = {}, ctx: IEntityContext = null) -> void:
	_ctx = ctx
	AppLogger.log_debug("%s.on_spawn() config: %s" % [_get_entity_type_id(), str(config)], _get_entity_type_id())
	if is_instance_valid(_interactable_comp):
		_interactable_comp.inject_context(_ctx)
	# Pool-Reuse-Guard: Visuals vor dem Aufbau bereinigen damit sich bei jedem
	# Spawn-Zyklus keine MeshInstance3D-Kinder akkumulieren.
	_clear_visuals()
	_build_visuals()
	_on_spawn_extended(config)

## Hook für Subklassen die on_spawn zusätzliche Logik brauchen (optional).
func _on_spawn_extended(_config: Dictionary) -> void:
	pass

## Bereinigt alle visuellen Kinder dieser Entity.
## Wird am Anfang von on_spawn() aufgerufen — verhindert Visual-Akkumulation
## bei Pool-Reuse (EntityPool gibt Entity zurück ohne Kinder zu entfernen).
## Subklassen können überschreiben wenn gezielte Bereinigung nötig ist.
## Wichtig: _interactable_comp wird NICHT entfernt (ist kein visueller Child).
func _clear_visuals() -> void:
	for child in get_children():
		if child == _interactable_comp:
			continue  # InteractableComponent erhalten
		# Sofortiges free() statt queue_free(): queue_free() ist deferred (wirkt erst
		# am Frame-Ende) — bei zwei synchronen on_spawn()-Aufrufen im selben Frame
		# (Pool-Reuse!) wäre das alte Mesh beim Neuaufbau noch nicht entfernt und
		# würde sich akkumulieren. Reine Visual-Kinder haben keine hängenden
		# Cross-Frame-Verbindungen, sofortiges free() ist hier sicher.
		remove_child(child)
		child.free()

## Aufgerufen von EntityOrchestrator beim Despawn.
func on_despawn() -> void:
	var type_id := _get_entity_type_id()
	AppLogger.log_debug("%s.on_despawn() bei %s." % [type_id, str(global_position)], type_id)
	if is_instance_valid(_interactable_comp):
		_interactable_comp.disconnect_world_events()
	var world: WorldService = _ctx.get_world() if is_instance_valid(_ctx) else null
	if is_instance_valid(world):
		world.mark_harvested(type_id, global_position)
		AppLogger.log_info("Harvest-Marker gesetzt: '%s' @ %s." % [type_id, str(global_position)], type_id)
	else:
		AppLogger.log_warn("WorldService nicht verfügbar — Harvest-State nicht persistiert.", type_id)

# ─────────────────────────────────────────────
# Shared Helpers — Subklassen nutzen diese statt eigener Duplikate
# ─────────────────────────────────────────────

## Gemeinsamer Placeholder-Zylinder für Bäume — ersetzt die dreifache Duplikation
## in OakTree, WillowTree, MapleTree.
## radius: Zylinderradius (oben = unten), height: Zylinderhöhe, color: Stammfarbe.
func _add_placeholder_cylinder(radius: float, height: float, color: Color) -> void:
	var mesh_inst := MeshInstance3D.new()
	var cyl       := CylinderMesh.new()
	cyl.top_radius    = radius
	cyl.bottom_radius = radius
	cyl.height        = height
	mesh_inst.mesh    = cyl
	var mat := StandardMaterial3D.new()
	mat.albedo_color          = color
	mesh_inst.material_override = mat
	mesh_inst.position.y      = height * 0.5
	add_child(mesh_inst)

## Gemeinsamer Placeholder-Quader für Erze — ersetzt direktes add_child()
## in IronOre/CopperOre.
func _add_placeholder_box(size: Vector3, color: Color) -> void:
	var m   := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = size
	m.mesh   = box
	var mat := StandardMaterial3D.new()
	mat.albedo_color    = color
	m.material_override = mat
	add_child(m)

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _setup_interactable() -> void:
	var d := _build_interactable_data()
	_interactable_comp = InteractableComponent.new()
	_interactable_comp.data = d
	add_child(_interactable_comp)
	_interactable_comp.interacted.connect(_on_interacted)
	AppLogger.log_debug(
		"InteractableComponent '%s' erstellt (XP: %d %s)." % [d.label, d.xp_amount, d.xp_type],
		_get_entity_type_id()
	)

## peer_id: kommt aus resolve_and_dispatch_interaction()/dem lokalen
## interacted-Emit — echte Identität des erntenden Spielers (ADR-015/ADR-020).
##
## ADR-020 / R-1 (Round 43): Loot-Roll + XP-Bemessung laufen jetzt HIER, nicht
## mehr in InteractionExecutor._on_tween_finished(). Dieser Hook läuft dank des
## Autoritäts-Guards unten UND des Round-42-Transports garantiert nur auf der
## echten Autorität — exakt die Voraussetzung, die InteractionResolver.resolve()
## selbst nicht mehr prüft (das ist bewusst nicht seine Verantwortung, siehe
## dortige Doku). _interactable_comp.data ist die servereigene Kopie der
## InteractableData (aus der Szene/Resource geladen, nie vom Client übertragen) —
## es gibt keinen Pfad, über den ein Client hier eine andere loot_table oder
## einen anderen xp_amount einschleusen könnte.
##
## ADR-020 / R-3 + R-6: Guard analog zu EnemyNPC._on_interacted(). Vorher lief
## dieser Hook auf JEDEM Peer, der seinen lokalen Tween zuerst beendet hat —
## auf einem Nicht-Host-Client despawnte das Objekt dadurch nur lokal (der
## despawn-Request lief über den lokalen, pro-Peer-EventBus, siehe R-6), der
## Server hatte nie davon erfahren und hielt das Objekt weiterhin für
## interagierbar. Jetzt läuft die eigentliche Wirkung ausschließlich auf der
## Autorität — erreicht über InteractableComponent._handle_completion()'s
## RPC-Weiterleitung (WorldService.request_entity_interaction()), nicht mehr
## über den rein lokalen Tween-Abschluss eines beliebigen Peers.
func _on_interacted(action_id: String, peer_id: int) -> void:
	if not is_multiplayer_authority():
		return
	var type_id := _get_entity_type_id()
	var bus: IEventBus = _ctx.get_event_bus() if is_instance_valid(_ctx) else null
	if is_instance_valid(_interactable_comp):
		var stat_mods: StatModifierService = _ctx.get_stat_modifiers() if is_instance_valid(_ctx) else null
		# Round 69: InteractionResolver.resolve() braucht jetzt zusätzlich zur
		# peer_id auch die stabile player_id (für den StatModifierService-Aufruf
		# darin) — Auflösung passiert HIER, am Aufrufer, nicht in
		# InteractionResolver selbst (siehe dessen Klassenkommentar + geklärte
		# Design-Frage in TODO-offene-probleme.md). Leerer NetworkBridge/
		# unauflösbare peer_id → leerer String, resolve() behandelt das als
		# "kein Stat-Bonus", kein Crash.
		var network: NetworkBridge = _ctx.get_network_bridge() if is_instance_valid(_ctx) else null
		var player_id := network.get_player_id_for_peer(peer_id) if is_instance_valid(network) else ""
		InteractionResolver.resolve(_interactable_comp.data, peer_id, player_id, bus, stat_mods)
	AppLogger.log_info("Interaktion '%s' abgeschlossen — %s despawnt." % [action_id, type_id], type_id)
	var uuid: String = get_meta("entity_uuid", "")
	if not uuid.is_empty():
		if bus != null:
			bus.world().emit_entity_despawn_requested(uuid)
		else:
			AppLogger.log_warn("Kein IEventBus im Context — direkte queue_free() statt Despawn-Request.", type_id)
			on_despawn()
			queue_free()
	else:
		AppLogger.log_warn("Keine UUID — direkte queue_free().", type_id)
		on_despawn()
		queue_free()
