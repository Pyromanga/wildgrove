class_name AnimalCatcher
extends RefCounted

## AnimalCatcher — Utility zum Umwandeln eines gefangenen Tieres in ein Pet.
## Wird von der Fangen-Aktion in AnimalBase aufgerufen.
##
## Spawnt das Pet über EntityOrchestrator.spawn_entity("pet", ...) statt per
## direktem PetComponent.new() + add_child() — sonst ist das Pet für andere
## Peers unsichtbar (MultiplayerSpawner kennt nur registrierte EntityRegistry-
## Typen) und bekommt keinen owner_peer_id für die Folge-Logik.
##
## owner_peer_id = peer_id, Pflichtparameter vom Aufrufer (AnimalBase._on_interacted()).
## ADR-015 Phase 5: das war zuvor animal.get_multiplayer().get_unique_id() —
## eine Näherung, weil das Interaktionssystem (InteractableComponent.interacted-
## Signal) keine Spieler-Identität trug. Seit Phase 4 trägt es sie echt, also
## wird hier nicht mehr geraten, sondern der reale Wert entgegengenommen.

const LOG_CAT := "AnimalCatcher"

static func catch_animal(animal: AnimalBase, peer_id: int) -> PetComponent:
	if not is_instance_valid(animal):
		return null

	# BUG-FIX: 'animal' kann durch einen zeitgleichen Despawn/Respawn-Zyklus
	# (RespawnService) exakt im Moment des Fangens kurzzeitig aus dem
	# SceneTree entfernt sein. global_position (-> get_global_transform())
	# crasht dann mit "!is_inside_tree()" und liefert eine korrupte
	# Transform3D()-Position für das neue Pet. Sauber abbrechen statt mit
	# falscher Position weiterzumachen.
	if not animal.is_inside_tree():
		AppLogger.log_warn(
			"catch_animal(): '%s' war beim Fangen nicht im SceneTree (Despawn-Race) — abgebrochen." % animal.name,
			LOG_CAT
		)
		return null

	var ctx: IEntityContext = animal.get_context()
	var world: WorldService = ctx.get_world() if is_instance_valid(ctx) else null
	if not is_instance_valid(world):
		AppLogger.log_error(
			"catch_animal(): kein WorldService im EntityContext — Fangen abgebrochen (kein AutoLoad-Fallback).",
			LOG_CAT
		)
		return null

	# Alles vor queue_free() einsammeln — 'animal' ist danach zur Freigabe vorgemerkt.
	var owner_peer_id := peer_id
	var pet_name := "Zahmes " + animal.name
	var config := {
		"name":          pet_name,
		"color":         animal._color,
		"body_size":     animal._body_size,
		"speed":         animal._speed * 0.85,
		"owner_peer_id": owner_peer_id,
	}
	var pos := animal.global_position
	var bus: IEventBus = ctx.get_event_bus()

	animal.queue_free()

	var pet := world.spawn_entity("pet", pos, config, owner_peer_id) as PetComponent
	if not is_instance_valid(pet):
		AppLogger.log_error("catch_animal(): spawn_entity('pet') fehlgeschlagen.", LOG_CAT)
		return null

	AppLogger.log_info(
		"Tier gefangen → Pet '%s' erstellt (Besitzer: peer %d)." % [pet_name, owner_peer_id], LOG_CAT
	)
	if is_instance_valid(bus):
		bus.world().emit_interaction_reward_text("Du hast ein %s gefangen!" % pet_name)
	return pet
