class_name HUDBuilder

## HUDBuilder — Instanziiert und verbindet alle HUD-Komponenten.


static func build_all(hud: HUD, context: Dictionary) -> Dictionary:
	var registry: Dictionary = {}
	var ui_events: UIEvents = EventBus.ui

	# 1. Interaktions-Fortschrittsbalken
	registry["interaction"] = InteractionComponent.new().build(hud, EventBus.world)

	# 2. Interaktions-Button
	registry["interaction_button"] = InteractionButtonComponent.new().build(hud)

	# 3. Inventar
	# BUG-FIX: Services.inventory könnte null sein wenn HUD sehr früh gebaut wird.
	# Wir prüfen explizit und loggen einen Fehler statt silently zu crashen.
	var inv_svc := Services.inventory
	if is_instance_valid(inv_svc):
		var inv_ctrl := InventoryComponent.new().build(hud, inv_svc)
		registry["inventory"] = inv_ctrl
		# BUG-FIX: InventorySystem.on_ready() feuert inventory_changed BEVOR der
		# Controller connected ist → initiales Inventar wird nie angezeigt.
		# Lösung: nach dem Build den aktuellen Stand manuell pushen.
		if inv_ctrl is InventoryUIController:
			inv_ctrl.refresh()
	else:
		Logger.log_error("HUDBuilder: Services.inventory ist null — Inventar-UI fehlt!", "HUD")

	# 4. Floating Text (XP-Gains, Level-Ups)
	registry["floating_text"] = FloatingTextComponent.new().build(hud, EventBus.player)

	# 5. Benachrichtigungen (Reward-Texte nach Interaktionen)
	registry["notification"] = NotificationComponent.new().build(hud)

	# 6. Joystick-Visual
	registry["joystick"] = JoystickComponent.new().build(hud)

	# 7. Kontext-Button und Menü
	registry["context_button"] = ContextButtonComponent.new().build(hud, ui_events)
	registry["context_menu"]   = ContextMenuComponent.new().build(hud, ui_events)

	# 8. Pause-/Optionsmenü
	registry["pause_menu"] = PauseMenuComponent.new().build(hud)

	# 9. Skill-Panel (⚔-Button oben links)
	registry["skill_panel"] = SkillPanelComponent.new().build(hud)

	# 10. Quest-Panel (📜-Button oben links)
	registry["quest_panel"] = QuestPanelComponent.new().build(hud)

	return registry
