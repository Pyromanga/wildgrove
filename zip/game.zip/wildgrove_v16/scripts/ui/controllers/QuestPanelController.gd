class_name QuestPanelController
extends Node

var _visuals: QuestPanelVisuals


func setup(visuals: QuestPanelVisuals) -> void:
	_visuals = visuals
	EventBus.quest.quest_started.connect(_on_quest_started)
	EventBus.quest.quest_completed.connect(_on_quest_completed)
	EventBus.quest.quest_objective_updated.connect(_on_objective_updated)
	_refresh_active_quests()


func _refresh_active_quests() -> void:
	if not is_instance_valid(Services.quest):
		return
	for quest_id in Services.quest.active_quests:
		_show_quest(quest_id)


func _show_quest(quest_id: String) -> void:
	if not is_instance_valid(Services.quest):
		return
	var qs := Services.quest
	if not qs.active_quests.has(quest_id):
		return
	var def: QuestDefinition = qs._definitions.get(quest_id)
	var title := def.title if def else quest_id
	var objectives := _build_obj_data(quest_id, def)
	_visuals.show_quest(quest_id, title, objectives)


func _build_obj_data(quest_id: String, def: QuestDefinition) -> Array:
	var result := []
	if not def:
		return result
	for obj in def.objectives:
		result.append({
			"label":    obj.label,
			"current":  Services.quest.get_objective_progress(quest_id, obj.id),
			"required": obj.required,
		})
	return result


func _on_quest_started(quest_id: String) -> void:
	_show_quest(quest_id)


func _on_quest_completed(quest_id: String, _reward: QuestReward) -> void:
	_visuals.remove_quest(quest_id)


func _on_objective_updated(quest_id: String, _obj_id: String, _cur: int, _req: int) -> void:
	_show_quest(quest_id)
