class_name FloatingTextController

## FloatingTextController — zeigt XP-Gains, Level-Ups und Loot-Drops als schwebenden Text.
## Lauscht auf PlayerEvents (XP/Level) und UIEvents (Loot-Floating-Text).

var _visuals: FloatingTextVisuals
var _ctx: IUIContext

func setup(visuals: FloatingTextVisuals, ctx: IUIContext) -> void:
	assert(ctx != null, "FloatingTextController.setup: ctx ist null!")
	_visuals = visuals
	_ctx = ctx
	_ctx.bus().player().xp_gained.connect(_on_xp_gained)
	_ctx.bus().player().level_up.connect(_on_level_up)
	# Loot-Drop-Text über UIEvents
	_ctx.bus().ui().floating_loot_text_requested.connect(_on_floating_loot)

func _on_xp_gained(skill: String, amount: int, peer_id: int) -> void:
	# BUGFIX (2026-09-13): xp_gained liefert 3 Argumente (skill, amount,
	# peer_id) — ohne peer_id-Parameter schlug JEDER Aufruf mit einem
	# 'Method expected 2 argument(s), but called with 3' Engine-Fehler fehl,
	# XP-Floating-Text wurde nie angezeigt. Zusätzlich: nur für den lokalen
	# Spieler anzeigen, nicht für fremde peer_ids (Coop).
	if peer_id != _ctx.get_local_peer_id():
		return
	_visuals.spawn_text("+%d %s" % [amount, skill], Color(1.0, 0.9, 0.2), 24, 2.0)

func _on_level_up(skill: String, new_level: int, peer_id: int) -> void:
	if peer_id != _ctx.get_local_peer_id():
		return
	_visuals.spawn_text("LEVEL UP!\n%s → %d" % [skill, new_level], Color(0.2, 0.8, 1.0), 32, 3.0)

func _on_floating_loot(text: String, _world_pos: Vector3) -> void:
	# Loot-Text grün mit leichtem Versatz damit er sich von XP abhebt
	_visuals.spawn_text(text, Color(0.3, 1.0, 0.4), 22, 2.5)
