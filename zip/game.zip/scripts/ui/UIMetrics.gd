class_name UIMetrics
extends RefCounted

## UIMetrics — gemeinsame Maße und Platzierungs-Helfer für alle HUD-Elemente.
##
## WARUM ES DAS GIBT: Vorher hat jedes Panel seine Position und Button-Größe selbst
## festgelegt (mal Bruchteil-Anchors wie 0.02, mal Pixel-Offsets, mal fest 32/36 px
## hohe Buttons). Ergebnis: Toggle-Buttons lagen übereinander, alle Panels öffneten
## an fast derselben Stelle, Tap-Ziele waren winzig. Jetzt kommen Maße und
## Platzierung von hier — Änderungen an einer Stelle wirken auf das ganze HUD.
##
## Referenzauflösung: 1920×1080 (project.godot: stretch canvas_items / expand).
## Auf einem Handy sind 1080 px Höhe grob 65–70 mm → 64 px ≈ 4 mm, 88 px ≈ 5,5 mm.

const MARGIN: int = 16

## Toolbar (PanelDock) oben links.
const TOOLBAR_BUTTON: int = 88
const TOOLBAR_GAP: int = 10
const TOOLBAR_PADDING: int = 8

## Sheets (Seitenfenster: Inventar, Skills, Quests, ...) beginnen unterhalb der Toolbar.
const SHEET_LEFT: int = 16
const SHEET_TOP: int = MARGIN + TOOLBAR_BUTTON + 2 * TOOLBAR_PADDING + 12

## Mindestgrößen für Touch-Ziele innerhalb von Panels.
const TAP_MIN: int = 64
const FIELD_MIN: int = 56

## Schriftgröße für Listenzeilen (vorher 13 — auf dem Handy kaum lesbar).
const FONT_ROW: int = 18

## Stellt sicher, dass ein Control mindestens TAP_MIN hoch (und optional min_width breit) ist.
static func tap(ctrl: Control, min_width: float = 0.0) -> void:
	var s: Vector2 = ctrl.custom_minimum_size
	ctrl.custom_minimum_size = Vector2(maxf(s.x, min_width), maxf(s.y, float(TAP_MIN)))

## Sheet: links oben unter der Toolbar. Höhe = Inhalt (wächst nach unten).
static func place_sheet(panel: Control, width: float) -> void:
	panel.anchor_left   = 0.0
	panel.anchor_right  = 0.0
	panel.anchor_top    = 0.0
	panel.anchor_bottom = 0.0
	panel.offset_left   = SHEET_LEFT
	panel.offset_right  = SHEET_LEFT + width
	panel.offset_top    = SHEET_TOP
	panel.offset_bottom = SHEET_TOP
	panel.grow_horizontal = Control.GROW_DIRECTION_END
	panel.grow_vertical   = Control.GROW_DIRECTION_END
	panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN

## Modal: zentriert, Höhe = Inhalt. GROW_DIRECTION_BOTH hält das Fenster auch dann
## mittig, wenn der Inhalt (größere Buttons!) höher wird als früher fest verdrahtet.
static func place_modal(panel: Control, width: float) -> void:
	panel.anchor_left   = 0.5
	panel.anchor_right  = 0.5
	panel.anchor_top    = 0.5
	panel.anchor_bottom = 0.5
	panel.offset_left   = -width * 0.5
	panel.offset_right  = width * 0.5
	panel.offset_top    = 0.0
	panel.offset_bottom = 0.0
	panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	panel.grow_vertical   = Control.GROW_DIRECTION_BOTH
