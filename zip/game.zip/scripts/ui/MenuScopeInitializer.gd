class_name MenuScopeInitializer extends Node

## MenuScopeInitializer — Sitzt in MainMenu.tscn als Child-Node.
##
## Einzige Verantwortung: signalisiert wenn der MainMenu-Root bereit ist.
## Kein AutoLoad-Zugriff. Kein EventBus. Kein Pull.
##
## ServiceOrchestrator lauscht dauerhaft auf 'menu_ready' (siehe
## _watch_for_menu_initializer()) — anders als beim World-Pendant, das nur
## einmal pro Session gebootet wird, wird MainMenu.tscn bei jedem
## 'main_menu_requested' (Rückkehr ins Hauptmenü) komplett neu geladen, also
## erzeugt jeder Ladevorgang eine neue MenuScopeInitializer-Instanz.
##
## Push-Pattern: dieser Node pushed Existenz nach oben, niemand pollt ihn.
## Schließt BUG-21: MainMenuController.inject_save_system() existierte als
## DI-Punkt, hatte aber nie einen Aufrufer.

## Emittiert einmalig wenn dieser Node im SceneTree bereit ist.
## get_parent() ist zu diesem Zeitpunkt der MainMenu-Root (Control).
signal menu_ready(menu_root: Control)

func _ready() -> void:
	var root := get_parent()
	if not root is Control:
		push_error(
			"MenuScopeInitializer: Parent ist kein Control — in MainMenu.tscn direkt unter Root einsetzen."
		)
		return
	menu_ready.emit(root as Control)
	## Nach emit ist dieser Node fertig. Er bleibt im SceneTree für die Lebensdauer
	## des MainMenu-Screens, hat aber keine weitere aktive Rolle.
