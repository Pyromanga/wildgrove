class_name CharacterPartBuilder
extends RefCounted

## CharacterPartBuilder — baut aus einem CharacterLook den sichtbaren Körper
## (Rumpf, Becken, Hals, Kopf mit Gesicht + Haaren, Arme, Beine) aus
## Godot-Primitiven. Kein Asset, keine Textur — alles prozedural, damit sich
## jedes Teil per Code ändern lässt.
##
## Rein statisch, kein Zustand. PlayerVisuals ruft `build()` bei jeder
## Look-Änderung auf und hängt das Ergebnis unter das Skeleton.
##
## KOORDINATEN (Skeleton-/Körperraum, Einheit = Meter, Füße bei y = 0):
##   +Y oben, +Z = Blickrichtung des Charakters (PlayerVisuals.handle_rotation
##   dreht die +Z-Achse in Laufrichtung).
##   +X-Seite = "_r"-Seite: das ist die Legacy-Konvention der Bones (hand_r
##   sitzt bei +X, dort hängt die Waffe). Anatomisch ist das bei +Z-Blick die
##   linke Körperseite — bewusst NICHT geändert, sonst wandern alle
##   Waffen-Attachments auf die andere Hand.
##
## PROPORTIONEN (Normal-Statur, Höhe "medium"): Gesamthöhe ~1,85 m mit Frisur,
## Kopf leicht überproportional. Die Kollisionskapsel (PlayerSetup) ist
## 1,8 m hoch.

const HEAD_R: float = 0.19
const HEAD_CENTER_Y: float = 1.65
const TORSO_R: float = 0.19
const TORSO_H: float = 0.64
const TORSO_CENTER_Y: float = 1.10
## Rumpf ist eine in X gedehnte, in Z abgeflachte Kapsel.
const TORSO_X_BASE: float = 1.25
const TORSO_Z: float = 0.85
const SHOULDER_Y: float = 1.34
const HIP_Y: float = 0.80
## Schulter -> Handmitte.
const ARM_LEN: float = 0.56
const HAND_R: float = 0.062
const LEG_X_BASE: float = 0.115

# ─────────────────────────────────────────────
# Öffentliche Geometrie-Abfragen (für PlayerVisuals: Hand-Bones, Slots)
# ─────────────────────────────────────────────

## X-Abstand des Schultergelenks (und damit der Hand) von der Körpermitte.
static func shoulder_x(look: Dictionary) -> float:
	var tw := CharacterLook.torso_width(String(look.get("build", "normal")))
	return TORSO_R * TORSO_X_BASE * tw + 0.045

## Handmitte im Körperraum für die Seite (+1 = "_r"/+X, -1 = "_l"/-X).
static func hand_position(look: Dictionary, side: float) -> Vector3:
	return Vector3(side * shoulder_x(look), SHOULDER_Y - ARM_LEN, 0.0)

## Schulterpunkt (Drehpunkt des Arms) im Körperraum.
static func shoulder_position(look: Dictionary, side: float) -> Vector3:
	return Vector3(side * shoulder_x(look), SHOULDER_Y, 0.0)

# ─────────────────────────────────────────────
# Aufbau
# ─────────────────────────────────────────────

## Baut den gesamten Körper. Rückgabe (alles Referenzen in den neuen Baum):
##   root      Node3D   — Wurzel "Parts", vom Aufrufer einzuhängen
##   torso     MeshInstance3D — Rumpf (trägt das Hemd-Material)
##   shirt_mat StandardMaterial3D — geteilt von Rumpf + Ärmeln
##   head      Node3D   — Kopf-Gruppe (Skull, Ohren, Face, Hair)
##   face      Node3D
##   hair      Node3D
##   arm_r / arm_l / leg_r / leg_l  Node3D — Drehpunkte (Schulter/Hüfte),
##             rotation.x schwingt die Gliedmaße
static func build(look: Dictionary) -> Dictionary:
	var l := CharacterLook.sanitize(look)
	var skin_col := CharacterLook.color_of("skin", l["skin"])
	var hair_col := CharacterLook.color_of("hair_color", l["hair_color"])
	var tw := CharacterLook.torso_width(l["build"])
	var limb := CharacterLook.limb_scale(l["build"])

	var skin_mat := _mat(skin_col, 0.9)
	var shirt_mat := _mat(CharacterLook.color_of("shirt", l["shirt"]))
	var pants_mat := _mat(CharacterLook.color_of("pants", l["pants"]))
	var shoe_mat := _mat(Color(0.24, 0.17, 0.12), 0.9)
	var hair_mat := _mat(hair_col, 0.7)

	var root := Node3D.new()
	root.name = "Parts"

	# Rumpf
	var torso := _mi(_capsule(TORSO_R, TORSO_H), shirt_mat, Vector3(0.0, TORSO_CENTER_Y, 0.0), "Torso")
	torso.scale = Vector3(TORSO_X_BASE * tw, 1.0, TORSO_Z)
	root.add_child(torso)

	# Becken (Hosenfarbe) — schließt die Lücke zwischen Rumpf und Beinen.
	var pelvis := _mi(_capsule(0.115, 0.44 * tw + 0.06), pants_mat, Vector3(0.0, HIP_Y + 0.02, 0.0), "Pelvis")
	pelvis.rotation.z = PI * 0.5
	root.add_child(pelvis)

	# Hals
	root.add_child(_mi(_cylinder(0.055, 0.055, 0.12), skin_mat, Vector3(0.0, 1.47, 0.0), "Neck"))

	# Kopf
	var head := _build_head(l, skin_mat, hair_mat, skin_col, hair_col)
	root.add_child(head)

	# Arme / Beine (Drehpunkte, damit sie später animiert werden können)
	var arm_r := _build_arm(l, 1.0, limb, skin_mat, shirt_mat, "ArmR")
	var arm_l := _build_arm(l, -1.0, limb, skin_mat, shirt_mat, "ArmL")
	var leg_r := _build_leg(1.0, tw, limb, pants_mat, shoe_mat, "LegR")
	var leg_l := _build_leg(-1.0, tw, limb, pants_mat, shoe_mat, "LegL")
	root.add_child(arm_r)
	root.add_child(arm_l)
	root.add_child(leg_r)
	root.add_child(leg_l)

	return {
		"root": root,
		"torso": torso,
		"shirt_mat": shirt_mat,
		"head": head,
		"face": head.get_node("Face"),
		"hair": head.get_node("Hair"),
		"arm_r": arm_r,
		"arm_l": arm_l,
		"leg_r": leg_r,
		"leg_l": leg_l,
	}

# ─────────────────────────────────────────────
# Kopf / Gesicht / Haare
# ─────────────────────────────────────────────

static func _build_head(l: Dictionary, skin_mat: StandardMaterial3D, hair_mat: StandardMaterial3D, skin_col: Color, hair_col: Color) -> Node3D:
	var head := Node3D.new()
	head.name = "Head"
	head.position = Vector3(0.0, HEAD_CENTER_Y, 0.0)

	head.add_child(_mi(_sphere(HEAD_R, false, 24, 12), skin_mat, Vector3.ZERO, "Skull"))
	for side in [1.0, -1.0]:
		var ear := _mi(_sphere(0.035), skin_mat, Vector3(side * (HEAD_R - 0.002), -0.005, 0.0), "EarR" if side > 0.0 else "EarL")
		ear.scale = Vector3(0.55, 1.0, 0.8)
		head.add_child(ear)

	var face := Node3D.new()
	face.name = "Face"
	head.add_child(face)
	_build_face(face, l, skin_col, hair_col)

	var hair := Node3D.new()
	hair.name = "Hair"
	head.add_child(hair)
	_build_hair(hair, String(l["hair_style"]), hair_mat)

	return head

static func _build_face(face: Node3D, l: Dictionary, skin_col: Color, hair_col: Color) -> void:
	var iris_col := CharacterLook.color_of("eye_color", l["eye_color"])

	# Augen
	for side in [1.0, -1.0]:
		var eye := _build_eye(String(l["eyes"]), iris_col)
		var y_scale := 0.55 if String(l["eyes"]) == "narrow" else 1.0
		_place(eye, side * 0.07, 0.0, 0.0, Vector3(1.0, y_scale, 1.0))
		eye.name = "EyeR" if side > 0.0 else "EyeL"
		face.add_child(eye)

	# Brauen (Hinweis Roll-Vorzeichen: +roll hebt bei x>0 das äußere Ende an,
	# der innere Rand sinkt = strenger Blick; siehe Klassen-Doku Koordinaten.)
	var brow_style := String(l["brows"])
	if brow_style != "none":
		var brow_mat := _mat(hair_col.darkened(0.15), 0.8)
		var size := Vector3(0.075, 0.014, 0.012)
		var roll := 0.0
		match brow_style:
			"soft":
				roll = -0.12
			"angled":
				roll = 0.30
			"thick":
				size = Vector3(0.085, 0.026, 0.014)
				roll = 0.08
		for side in [1.0, -1.0]:
			var brow := _mi(_box(size), brow_mat, Vector3.ZERO, "BrowR" if side > 0.0 else "BrowL")
			_place(brow, side * 0.07, 0.057, 0.004, Vector3.ONE, side * roll)
			face.add_child(brow)

	# Nase
	var nose_style := String(l["nose"])
	if nose_style != "none":
		var nose_r := 0.022 if nose_style == "small" else 0.032
		var nose := _mi(_sphere(nose_r), _mat(skin_col.darkened(0.06), 0.9), Vector3.ZERO, "Nose")
		_place(nose, 0.0, -0.04, 0.008)
		face.add_child(nose)

	# Mund
	_build_mouth(face, String(l["mouth"]))

static func _build_eye(style: String, iris_col: Color) -> Node3D:
	var eye := Node3D.new()
	var dark := _mat(Color(0.05, 0.05, 0.07), 0.3)
	if style == "dot":
		var bead := _mi(_sphere(0.024), dark, Vector3.ZERO, "Bead")
		bead.scale = Vector3(1.0, 1.15, 0.5)
		eye.add_child(bead)
		return eye

	var big := style == "big"
	var sclera_r := 0.044 if big else 0.034
	var iris_r := 0.028 if big else 0.021
	var pupil_r := 0.014 if big else 0.011
	var depth := 0.45  # Abflachung in Z (Anteil des Radius)

	var sclera := _mi(_sphere(sclera_r), _mat(Color(0.97, 0.97, 0.95), 0.4), Vector3.ZERO, "Sclera")
	sclera.scale = Vector3(1.0, 1.0, depth)
	eye.add_child(sclera)

	var iris := _mi(_sphere(iris_r), _mat(iris_col, 0.3), Vector3(0.0, 0.0, sclera_r * depth * 0.45), "Iris")
	iris.scale = Vector3(1.0, 1.0, depth)
	eye.add_child(iris)

	var pupil := _mi(_sphere(pupil_r), dark, Vector3(0.0, 0.0, sclera_r * depth * 1.0), "Pupil")
	pupil.scale = Vector3(1.0, 1.0, depth)
	eye.add_child(pupil)
	return eye

static func _build_mouth(face: Node3D, style: String) -> void:
	var lip_mat := _mat(Color(0.62, 0.28, 0.28), 0.6)
	var y := -0.085
	match style:
		"neutral":
			var m := _mi(_box(Vector3(0.06, 0.010, 0.010)), lip_mat, Vector3.ZERO, "Mouth")
			_place(m, 0.0, y, 0.003)
			face.add_child(m)
		"open":
			var m := _mi(_sphere(0.022), _mat(Color(0.30, 0.08, 0.10), 0.5), Vector3.ZERO, "Mouth")
			_place(m, 0.0, y - 0.004, 0.002, Vector3(1.3, 0.9, 0.4))
			face.add_child(m)
		"smirk":
			var m := _mi(_box(Vector3(0.05, 0.010, 0.010)), lip_mat, Vector3.ZERO, "Mouth")
			_place(m, 0.012, y, 0.003, Vector3.ONE, 0.22)
			face.add_child(m)
		_:
			# "smile": zwei Segmente, äußere Enden angehoben (Roll-Vorzeichen
			# wie bei den Brauen: +roll hebt bei x>0 das äußere Ende).
			for side in [1.0, -1.0]:
				var seg := _mi(_box(Vector3(0.036, 0.010, 0.010)), lip_mat, Vector3.ZERO, "MouthR" if side > 0.0 else "MouthL")
				_place(seg, side * 0.021, y + 0.004, 0.003, Vector3.ONE, side * 0.38)
				face.add_child(seg)

static func _build_hair(hair: Node3D, style: String, mat: StandardMaterial3D) -> void:
	match style:
		"bald":
			pass
		"buzz":
			hair.add_child(_cap(0.198, mat))
		"bob":
			hair.add_child(_cap(0.212, mat))
			hair.add_child(_mi(_box(Vector3(0.40, 0.24, 0.11)), mat, Vector3(0.0, -0.06, -0.115), "BobBack"))
			for side in [1.0, -1.0]:
				hair.add_child(_mi(_box(Vector3(0.055, 0.22, 0.20)), mat, Vector3(side * 0.185, -0.05, -0.03), "BobSideR" if side > 0.0 else "BobSideL"))
		"long":
			hair.add_child(_cap(0.212, mat))
			hair.add_child(_mi(_sphere(0.17), mat, Vector3(0.0, 0.0, -0.05), "Volume"))
			hair.add_child(_mi(_box(Vector3(0.40, 0.55, 0.08)), mat, Vector3(0.0, -0.21, -0.14), "LongBack"))
			for side in [1.0, -1.0]:
				hair.add_child(_mi(_box(Vector3(0.05, 0.36, 0.09)), mat, Vector3(side * 0.19, -0.13, -0.03), "LockR" if side > 0.0 else "LockL"))
		"ponytail":
			hair.add_child(_cap(0.208, mat))
			hair.add_child(_mi(_sphere(0.17), mat, Vector3(0.0, 0.0, -0.05), "Volume"))
			var tail := _mi(_capsule(0.045, 0.34), mat, Vector3(0.0, -0.09, -0.235), "Tail")
			tail.rotation.x = 0.35
			hair.add_child(tail)
			hair.add_child(_mi(_sphere(0.05), _mat(Color(0.75, 0.20, 0.20), 0.7), Vector3(0.0, 0.02, -0.20), "Tie"))
		"bun":
			hair.add_child(_cap(0.208, mat))
			hair.add_child(_mi(_sphere(0.17), mat, Vector3(0.0, 0.0, -0.05), "Volume"))
			hair.add_child(_mi(_sphere(0.085), mat, Vector3(0.0, 0.215, -0.07), "Bun"))
		"spiky":
			hair.add_child(_cap(0.200, mat))
			hair.add_child(_spike(mat, Vector3(0.0, 0.17, -0.02), Vector3(0.0, 1.0, -0.15), "SpikeTop"))
			var count := 5
			for i in count:
				var a := TAU * float(i) / float(count) + 0.3
				var dir := Vector3(sin(a) * 0.55, 1.0, cos(a) * 0.55 - 0.1)
				var base := Vector3(sin(a) * 0.115, 0.13, cos(a) * 0.115 - 0.02)
				hair.add_child(_spike(mat, base, dir, "Spike%d" % i))
		_:
			# "short" + unbekannte Werte (sanitize() lässt hier nur bekannte durch)
			hair.add_child(_cap(0.208, mat))
			hair.add_child(_mi(_sphere(0.17), mat, Vector3(0.0, 0.0, -0.05), "Volume"))

## Haarkappe: nach hinten gekippte Halbkugel — vorn hoher Haaransatz (Stirn
## frei), hinten tief. Halbkugel-Mesh: Kuppel nach +Y, flache Basis bei y=0.
static func _cap(radius: float, mat: StandardMaterial3D, back_tilt: float = -0.4) -> MeshInstance3D:
	var cap := _mi(_sphere(radius, true, 20, 8), mat, Vector3(0.0, 0.02, -0.01), "Cap")
	cap.rotation.x = back_tilt
	return cap

## Kegel-Stachel: Spitze zeigt entlang `dir`.
static func _spike(mat: StandardMaterial3D, base: Vector3, dir: Vector3, node_name: String) -> MeshInstance3D:
	var d := dir.normalized()
	var spike := _mi(_cylinder(0.0, 0.05, 0.15), mat, base + d * 0.06, node_name)
	spike.basis = Basis(Quaternion(Vector3.UP, d))
	return spike

# ─────────────────────────────────────────────
# Arme / Beine
# ─────────────────────────────────────────────

static func _build_arm(l: Dictionary, side: float, limb: float, skin_mat: StandardMaterial3D, shirt_mat: StandardMaterial3D, node_name: String) -> Node3D:
	var pivot := Node3D.new()
	pivot.name = node_name
	pivot.position = shoulder_position(l, side)
	pivot.add_child(_mi(_capsule(0.072 * limb, 0.32), shirt_mat, Vector3(0.0, -0.14, 0.0), "Sleeve"))
	pivot.add_child(_mi(_capsule(0.058 * limb, 0.34), skin_mat, Vector3(0.0, -0.40, 0.0), "Forearm"))
	pivot.add_child(_mi(_sphere(HAND_R * limb), skin_mat, Vector3(0.0, -ARM_LEN, 0.0), "Hand"))
	return pivot

static func _build_leg(side: float, tw: float, limb: float, pants_mat: StandardMaterial3D, shoe_mat: StandardMaterial3D, node_name: String) -> Node3D:
	var pivot := Node3D.new()
	pivot.name = node_name
	pivot.position = Vector3(side * LEG_X_BASE * tw, HIP_Y, 0.0)
	pivot.add_child(_mi(_capsule(0.10 * limb, HIP_Y), pants_mat, Vector3(0.0, -HIP_Y * 0.5, 0.0), "Leg"))
	pivot.add_child(_mi(_box(Vector3(0.16 * limb, 0.09, 0.28)), shoe_mat, Vector3(0.0, -HIP_Y + 0.045, 0.05), "Shoe"))
	return pivot

# ─────────────────────────────────────────────
# Primitive-Helfer
# ─────────────────────────────────────────────

## Primitive-Erzeugung/-Platzierung ist nach ProcGenShapes ausgelagert (gemeinsame Basis mit
## AnimalVisualBuilder/NPCVisualBuilder — siehe dortigen Klassenkommentar). Diese Wrapper
## bleiben als kurze, an dieser Datei gewohnte Namen erhalten, damit die ~80 Aufrufstellen
## unten unverändert bleiben; die eigentliche Geometrie-Erzeugung lebt nur noch an einer Stelle.
static func _mat(color: Color, roughness: float = 0.85) -> StandardMaterial3D:
	return ProcGenShapes.mat(color, roughness)

static func _mi(mesh: Mesh, mat: Material, pos: Vector3, node_name: String) -> MeshInstance3D:
	return ProcGenShapes.mi(mesh, mat, pos, node_name)

static func _sphere(radius: float, hemisphere: bool = false, segments: int = 16, rings: int = 8) -> SphereMesh:
	return ProcGenShapes.sphere(radius, hemisphere, segments, rings)

static func _capsule(radius: float, height: float) -> CapsuleMesh:
	return ProcGenShapes.capsule(radius, height)

static func _box(size: Vector3) -> BoxMesh:
	return ProcGenShapes.box(size)

static func _cylinder(top_r: float, bottom_r: float, height: float) -> CylinderMesh:
	return ProcGenShapes.cylinder(top_r, bottom_r, height)

## Setzt `node` auf die Kopfoberfläche (Kopfmitte = Ursprung der Gesichts-
## Gruppe): (x, y) = Position auf der Stirn-/Wangenebene, die Tiefe (z) ergibt
## sich aus der Kugelform. `lift` schiebt entlang der Oberflächennormale nach
## außen; +Z des Nodes zeigt aus dem Kopf heraus. `roll` dreht in der
## Tangentialebene, `node_scale` skaliert in lokalen Achsen.
static func _place(node: Node3D, x: float, y: float, lift: float, node_scale: Vector3 = Vector3.ONE, roll: float = 0.0) -> void:
	ProcGenShapes.place_on_sphere(node, HEAD_R, x, y, lift, node_scale, roll)
