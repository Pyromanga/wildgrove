class_name CharacterLook
extends RefCounted

## CharacterLook — Datenmodell + Katalog für das Aussehen eines Spielers.
##
## Ein "Look" ist ein flaches Dictionary  { feld: option_id }  — ausschließlich
## Strings. Das ist Absicht:
##   - speicherbar (SaveSystem) und über RPC sendbar ohne Sonderbehandlung,
##   - stabil gegen Katalog-Umbau: gespeichert wird die ID, nicht der Index.
##     Eine Option darf umsortiert oder eingefügt werden, ohne alte Spielstände
##     zu verändern.
##   - nie vertrauenswürdig: alles, was von außen kommt (Save, Netzwerk), läuft
##     durch `sanitize()`. Unbekannte Felder/IDs fallen auf Defaults zurück, es
##     gibt keinen Weg, rohe Farben oder Zahlen ins Rendering zu schmuggeln.
##
## Neue Option = ein Eintrag in CATALOG (+ ggf. Bauanleitung in
## CharacterPartBuilder). Neues Feld = Eintrag in FIELDS + CATALOG + DEFAULTS.
## Der Editor (AppearancePanelVisuals) liest FIELDS/CATALOG und zeigt neue
## Felder automatisch an.
##
## Reine Daten + statische Helfer — kein Node, kein Zustand.

## Reihenfolge = Reihenfolge im Editor. `group` ist nur Überschrift.
const FIELDS: Array = [
	{"key": "skin",       "label": "Hautton",     "group": "Körper"},
	{"key": "build",      "label": "Statur",      "group": "Körper"},
	{"key": "height",     "label": "Größe",       "group": "Körper"},
	{"key": "hair_style", "label": "Frisur",      "group": "Haare"},
	{"key": "hair_color", "label": "Haarfarbe",   "group": "Haare"},
	{"key": "eyes",       "label": "Augen",       "group": "Gesicht"},
	{"key": "eye_color",  "label": "Augenfarbe",  "group": "Gesicht"},
	{"key": "brows",      "label": "Brauen",      "group": "Gesicht"},
	{"key": "nose",       "label": "Nase",        "group": "Gesicht"},
	{"key": "mouth",      "label": "Mund",        "group": "Gesicht"},
	{"key": "shirt",      "label": "Oberteil",    "group": "Kleidung"},
	{"key": "pants",      "label": "Hose",        "group": "Kleidung"},
]

const DEFAULTS: Dictionary = {
	"skin":       "sand",
	"build":      "normal",
	"height":     "medium",
	"hair_style": "short",
	"hair_color": "brown",
	"eyes":       "round",
	"eye_color":  "brown",
	"brows":      "soft",
	"nose":       "small",
	"mouth":      "smile",
	"shirt":      "unbestimmt",
	"pants":      "navy",
}

## feld -> Array von { id, label, ... }. Die erste Option eines Feldes ist NICHT
## automatisch der Default — der steht in DEFAULTS.
## Hinweis zu den Shirt-IDs: "sonnig"/"wald"/"flut"/"asche"/"unbestimmt" sind
## bewusst identisch mit den Archetyp-IDs aus CharacterCreationService (dessen
## Farben müssen mit diesen Einträgen übereinstimmen — ein Test prüft das).
const CATALOG: Dictionary = {
	"skin": [
		{"id": "porcelain", "label": "Porzellan", "color": Color(0.96, 0.83, 0.72)},
		{"id": "light",     "label": "Hell",      "color": Color(0.92, 0.76, 0.62)},
		{"id": "sand",      "label": "Sand",      "color": Color(0.86, 0.68, 0.52)},
		{"id": "gold",      "label": "Gold",      "color": Color(0.78, 0.58, 0.40)},
		{"id": "bronze",    "label": "Bronze",    "color": Color(0.65, 0.46, 0.32)},
		{"id": "copper",    "label": "Kupfer",    "color": Color(0.55, 0.37, 0.26)},
		{"id": "brown",     "label": "Braun",     "color": Color(0.42, 0.28, 0.20)},
		{"id": "dark",      "label": "Dunkel",    "color": Color(0.28, 0.19, 0.15)},
	],
	## torso_w: Breitenfaktor Rumpf/Schultern, limb: Dickenfaktor Arme/Beine.
	"build": [
		{"id": "slim",   "label": "Schlank", "torso_w": 0.88, "limb": 0.90},
		{"id": "normal", "label": "Normal",  "torso_w": 1.00, "limb": 1.00},
		{"id": "broad",  "label": "Kräftig", "torso_w": 1.14, "limb": 1.15},
	],
	## scale: gleichmäßiger Faktor auf den gesamten Körper.
	"height": [
		{"id": "short",  "label": "Klein", "scale": 0.93},
		{"id": "medium", "label": "Mittel", "scale": 1.00},
		{"id": "tall",   "label": "Groß",  "scale": 1.07},
	],
	"hair_style": [
		{"id": "bald",     "label": "Glatze"},
		{"id": "buzz",     "label": "Kurzgeschoren"},
		{"id": "short",    "label": "Kurz"},
		{"id": "bob",      "label": "Bob"},
		{"id": "long",     "label": "Lang"},
		{"id": "ponytail", "label": "Zopf"},
		{"id": "bun",      "label": "Dutt"},
		{"id": "spiky",    "label": "Stachelig"},
	],
	"hair_color": [
		{"id": "black",      "label": "Schwarz",      "color": Color(0.08, 0.07, 0.07)},
		{"id": "darkbrown",  "label": "Dunkelbraun",  "color": Color(0.22, 0.14, 0.09)},
		{"id": "brown",      "label": "Braun",        "color": Color(0.38, 0.24, 0.13)},
		{"id": "chestnut",   "label": "Kastanie",     "color": Color(0.50, 0.27, 0.15)},
		{"id": "blond",      "label": "Blond",        "color": Color(0.85, 0.70, 0.38)},
		{"id": "lightblond", "label": "Hellblond",    "color": Color(0.93, 0.84, 0.60)},
		{"id": "red",        "label": "Rot",          "color": Color(0.66, 0.22, 0.12)},
		{"id": "gray",       "label": "Grau",         "color": Color(0.60, 0.60, 0.62)},
		{"id": "white",      "label": "Weiß",         "color": Color(0.92, 0.92, 0.93)},
		{"id": "blue",       "label": "Blau",         "color": Color(0.25, 0.40, 0.80)},
	],
	"eyes": [
		{"id": "round",  "label": "Rund"},
		{"id": "dot",    "label": "Punkte"},
		{"id": "narrow", "label": "Schmal"},
		{"id": "big",    "label": "Groß"},
	],
	"eye_color": [
		{"id": "brown",  "label": "Braun",    "color": Color(0.35, 0.22, 0.12)},
		{"id": "hazel",  "label": "Haselnuss", "color": Color(0.55, 0.40, 0.18)},
		{"id": "green",  "label": "Grün",     "color": Color(0.25, 0.55, 0.30)},
		{"id": "blue",   "label": "Blau",     "color": Color(0.25, 0.50, 0.85)},
		{"id": "gray",   "label": "Grau",     "color": Color(0.55, 0.60, 0.65)},
		{"id": "violet", "label": "Violett",  "color": Color(0.55, 0.35, 0.75)},
	],
	"brows": [
		{"id": "none",   "label": "Keine"},
		{"id": "soft",   "label": "Sanft"},
		{"id": "angled", "label": "Streng"},
		{"id": "thick",  "label": "Buschig"},
	],
	"nose": [
		{"id": "none",  "label": "Keine"},
		{"id": "small", "label": "Klein"},
		{"id": "round", "label": "Rund"},
	],
	"mouth": [
		{"id": "smile",   "label": "Lächeln"},
		{"id": "neutral", "label": "Neutral"},
		{"id": "open",    "label": "Offen"},
		{"id": "smirk",   "label": "Schmunzeln"},
	],
	"shirt": [
		{"id": "sonnig",     "label": "Sonnengelb",  "color": Color(0.95, 0.75, 0.25)},
		{"id": "wald",       "label": "Waldgrün",    "color": Color(0.25, 0.55, 0.25)},
		{"id": "flut",       "label": "Flutblau",    "color": Color(0.25, 0.45, 0.75)},
		{"id": "asche",      "label": "Aschviolett", "color": Color(0.55, 0.45, 0.60)},
		{"id": "unbestimmt", "label": "Grau",        "color": Color(0.60, 0.60, 0.60)},
		{"id": "red",        "label": "Rot",         "color": Color(0.75, 0.25, 0.22)},
		{"id": "white",      "label": "Weiß",        "color": Color(0.90, 0.90, 0.88)},
		{"id": "black",      "label": "Schwarz",     "color": Color(0.15, 0.15, 0.17)},
		{"id": "brown",      "label": "Braun",       "color": Color(0.45, 0.30, 0.18)},
		{"id": "teal",       "label": "Türkis",      "color": Color(0.20, 0.60, 0.60)},
	],
	"pants": [
		{"id": "navy",  "label": "Dunkelblau", "color": Color(0.18, 0.22, 0.38)},
		{"id": "brown", "label": "Braun",      "color": Color(0.36, 0.26, 0.16)},
		{"id": "black", "label": "Schwarz",    "color": Color(0.13, 0.13, 0.15)},
		{"id": "gray",  "label": "Grau",       "color": Color(0.42, 0.42, 0.45)},
		{"id": "olive", "label": "Oliv",       "color": Color(0.32, 0.36, 0.20)},
		{"id": "sand",  "label": "Sand",       "color": Color(0.72, 0.62, 0.44)},
	],
}

## Archetyp-ID (CharacterCreationService.APPEARANCE_ARCHETYPES) -> Überschreibungen
## auf den Default-Look. Hauttyp bleibt bewusst unangetastet — der ist eine
## persönliche Wahl, keine Charaktereigenschaft.
const ARCHETYPE_LOOKS: Dictionary = {
	"sonnig": {"shirt": "sonnig", "hair_style": "short",    "hair_color": "blond",     "eye_color": "blue",   "mouth": "smile",   "pants": "brown"},
	"wald":   {"shirt": "wald",   "hair_style": "ponytail", "hair_color": "chestnut",  "eye_color": "green",  "mouth": "smile",   "pants": "olive"},
	"flut":   {"shirt": "flut",   "hair_style": "bob",      "hair_color": "darkbrown", "eye_color": "blue",   "mouth": "neutral", "pants": "navy"},
	"asche":  {"shirt": "asche",  "hair_style": "spiky",    "hair_color": "gray",      "eye_color": "violet", "mouth": "smirk",   "brows": "angled", "pants": "black"},
}

# ─────────────────────────────────────────────
# Erzeugen / Validieren
# ─────────────────────────────────────────────

static func default_look() -> Dictionary:
	return DEFAULTS.duplicate()

## Look für einen Archetyp (oder Default bei unbekannter/"unbestimmt"-ID).
static func from_archetype(preset_id: String) -> Dictionary:
	var look := default_look()
	var overrides: Variant = ARCHETYPE_LOOKS.get(preset_id, null)
	if overrides is Dictionary:
		for key in (overrides as Dictionary).keys():
			look[key] = (overrides as Dictionary)[key]
	return look

## Macht aus BELIEBIGEM Input einen vollständigen, gültigen Look.
## Pro Feld: gültiger String aus `raw` -> sonst Wert aus `base` (falls gültig)
## -> sonst Default. Unbekannte Schlüssel in `raw` werden verworfen. `raw` darf
## alles sein (auch null / kein Dictionary) — das ist der Eingangsfilter für
## Save-Daten und RPC-Payloads.
static func sanitize(raw: Variant, base: Dictionary = {}) -> Dictionary:
	var out: Dictionary = {}
	var source: Dictionary = raw as Dictionary if raw is Dictionary else {}
	for field in FIELDS:
		var key: String = String((field as Dictionary)["key"])
		var chosen: String = _valid_id(key, source.get(key, null))
		if chosen.is_empty():
			chosen = _valid_id(key, base.get(key, null))
		if chosen.is_empty():
			chosen = String(DEFAULTS[key])
		out[key] = chosen
	return out

## Zykliert `field` um `delta` Schritte (±1) und liefert einen NEUEN Look.
static func step(look: Dictionary, field: String, delta: int) -> Dictionary:
	var clean := sanitize(look)
	var ids := option_ids(field)
	if ids.is_empty():
		return clean
	var idx: int = ids.find(clean[field])
	if idx < 0:
		idx = 0
	clean[field] = ids[posmod(idx + delta, ids.size())]
	return clean

# ─────────────────────────────────────────────
# Katalog-Abfragen
# ─────────────────────────────────────────────

static func option_ids(field: String) -> Array:
	var ids: Array = []
	for entry in (CATALOG.get(field, []) as Array):
		ids.append((entry as Dictionary)["id"])
	return ids

## Vollständiger Katalogeintrag ({} wenn Feld/ID unbekannt).
static func get_entry(field: String, id: String) -> Dictionary:
	for entry in (CATALOG.get(field, []) as Array):
		if (entry as Dictionary)["id"] == id:
			return (entry as Dictionary).duplicate()
	return {}

static func label_of(field: String, id: String) -> String:
	return String(get_entry(field, id).get("label", id))

static func field_label(field: String) -> String:
	for f in FIELDS:
		if (f as Dictionary)["key"] == field:
			return String((f as Dictionary)["label"])
	return field

## Farbe eines Farb-Feldes (skin/hair_color/eye_color/shirt/pants). Unbekannte
## ID -> Farbe der Default-Option, nie ein Fehler.
static func color_of(field: String, id: String) -> Color:
	var entry := get_entry(field, id)
	if entry.has("color"):
		return entry["color"] as Color
	var fallback := get_entry(field, String(DEFAULTS.get(field, "")))
	return fallback.get("color", Color.MAGENTA) as Color

static func height_scale(id: String) -> float:
	return float(get_entry("height", id).get("scale", 1.0))

static func torso_width(id: String) -> float:
	return float(get_entry("build", id).get("torso_w", 1.0))

static func limb_scale(id: String) -> float:
	return float(get_entry("build", id).get("limb", 1.0))

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

## Gibt `value` als String zurück, wenn es eine gültige Option von `field` ist,
## sonst "". Akzeptiert nur String/StringName (kein implizites Casting von
## Zahlen o. ä. aus Netzwerk-Payloads).
static func _valid_id(field: String, value: Variant) -> String:
	if not (value is String or value is StringName):
		return ""
	var s := String(value)
	for entry in (CATALOG.get(field, []) as Array):
		if (entry as Dictionary)["id"] == s:
			return s
	return ""
