extends SpringArm3D
class_name PlayerCamera

## PlayerCamera — Schulter-Kamera an einem SpringArm3D.
##
## FIX (2026-09-21, "Mauern/Decken übereinander schwer zu bauen"): vorher war
## der Pitch auf [-75°, 0°] geklemmt — der Spieler konnte nie nach OBEN sehen
## (0° war bereits die Obergrenze, waagerecht). Für Decken/hohe Wände musste
## man "blind" bauen. Jetzt bis MAX_PITCH_UP (positiv = Kamera schwenkt unter
## den Spieler und blickt hinauf) erweitert.
##
## FEATURE (First-Person-Zoom): Zoom-Untergrenze von 3.0 auf MIN_ZOOM_FIRST_PERSON
## gesenkt — nah genug heran, dass die Kamera praktisch an der Kopf-Position
## (position.y == 1.6, siehe _init()) sitzt. Damit lässt sich exakt anvisieren,
## wohin man baut (übereinanderliegende Wände/Decken), statt nur aus der
## Schulteransicht zu schätzen. Unterhalb von FIRST_PERSON_THRESHOLD wird das
## Player-Mesh ausgeblendet (first_person_changed-Signal) — sonst stünde das
## eigene Modell zwischen Kamera und Blickrichtung.

const LOG_CAT := "Camera"

@export var touch_sensitivity: float = 0.006
@export var zoom_speed: float = 5.0
@export var rotation_speed: float = 10.0

const MIN_ZOOM_FIRST_PERSON: float = 0.4
const MAX_ZOOM: float = 15.0
const FIRST_PERSON_THRESHOLD: float = 1.2

const MIN_PITCH_DEG: float = -75.0
const MAX_PITCH_UP_DEG: float = 65.0

var _target_zoom: float = 8.0
var _target_yaw: float = 0.0
var _target_pitch: float = deg_to_rad(-35.0)

## true während spring_length unter FIRST_PERSON_THRESHOLD liegt. Player.gd
## abonniert first_person_changed und blendet darüber das eigene Mesh aus/ein
## (siehe Klassenkommentar).
var _is_first_person: bool = false

## Wird gefeuert, sobald spring_length die FIRST_PERSON_THRESHOLD über- bzw.
## unterschreitet. Player.gd hält die Camera-Referenz bereits (siehe
## Player.on_spawn()) — kein EventBus nötig, rein lokale Subsystem-Kopplung
## wie touch_sensitivity/rotation_speed oben.
signal first_person_changed(active: bool)

var camera: Camera3D

func _init() -> void:
	position = Vector3(0, 1.6, 0)
	spring_length = _target_zoom
	collision_mask = 1
	_build_camera()

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.current = true
	add_child(camera)

func handle_input(inp: TouchInput, delta: float) -> void:
	_process_rotation(inp, delta)
	_process_zoom(inp, delta)

func _process_rotation(inp: TouchInput, delta: float) -> void:
	var c_delta := inp.cam_delta
	inp.cam_delta = Vector2.ZERO
	if c_delta != Vector2.ZERO:
		_target_yaw -= c_delta.x * touch_sensitivity
		_target_pitch = clamp(
			_target_pitch - c_delta.y * touch_sensitivity,
			deg_to_rad(MIN_PITCH_DEG), deg_to_rad(MAX_PITCH_UP_DEG)
		)
	rotation.y = lerp_angle(rotation.y, _target_yaw, rotation_speed * delta)
	rotation.x = lerp(rotation.x, _target_pitch, rotation_speed * delta)

func _process_zoom(inp: TouchInput, delta: float) -> void:
	var z_delta := inp.zoom_delta
	inp.zoom_delta = 0.0
	if z_delta != 0.0:
		_target_zoom = clamp(_target_zoom + z_delta, MIN_ZOOM_FIRST_PERSON, MAX_ZOOM)
	spring_length = lerp(spring_length, _target_zoom, zoom_speed * delta)

	var now_first_person := spring_length < FIRST_PERSON_THRESHOLD
	if now_first_person != _is_first_person:
		_is_first_person = now_first_person
		first_person_changed.emit(_is_first_person)

## Für PlayerSetup/Tests: aktuell First-Person aktiv?
func is_first_person() -> bool:
	return _is_first_person
