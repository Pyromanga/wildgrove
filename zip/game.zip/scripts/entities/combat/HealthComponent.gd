class_name HealthComponent
extends Node

## HealthComponent — HP-Verwaltung für Spieler und feindliche NPCs.
## take_damage(amount) → einfacher Pfad ohne Attributions-Info, emittiert
##   health_changed und ggf. died(null).
## take_damage_record(record) → wendet record.final_amount an und emittiert
##   bei Tod died(record) — der todesursächliche Record trägt die Angreifer-
##   Identität (DamageRecord.attacker_peer_id, ADR-019) mit.

signal health_changed(current: int, maximum: int)
## record: der todesursächliche DamageRecord, oder null wenn der Tod durch
## einen direkten take_damage(amount)-Aufruf ausgelöst wurde (z.B. Tests,
## siehe HealthComponent-Kommentar). Consumer MÜSSEN den null-Fall behandeln.
signal died(record: DamageRecord)

@export var max_health: int = 50:
	set(v):
		max_health = v
		current_health = v   ## Sync current mit max beim ersten Setzen
var current_health: int = 50
var is_dead: bool = false

func _ready() -> void:
	## Sicherheitsnetz: current_health auf max_health setzen falls max_health
	## NACH add_child() (also nach _ready()) noch geändert wird.
	current_health = max_health

## Einfacher Schadenspfad ohne Attributions-Info — für direkte Aufrufer, die
## keinen DamageRecord haben (Tests, Umweltschaden ohne CombatSystem-Pfad).
## Bei tödlichem Schaden wird died(null) emittiert.
func take_damage(amount: int) -> void:
	_apply_damage(amount, null)

## Bevorzugter Schadenspfad: wendet record.final_amount an und gibt den Record
## bei Tod an died() weiter, damit Consumer (z.B. EnemyNPC._die()) die echte
## Angreifer-Identität kennen (ADR-019 Option B).
func take_damage_record(record: DamageRecord) -> void:
	_apply_damage(int(record.final_amount), record)

func _apply_damage(amount: int, record: DamageRecord) -> void:
	if is_dead:
		return
	current_health = max(0, current_health - amount)
	health_changed.emit(current_health, max_health)
	if current_health <= 0:
		is_dead = true
		died.emit(record)

func heal(amount: int) -> void:
	if is_dead:
		return
	current_health = min(max_health, current_health + amount)
	health_changed.emit(current_health, max_health)

func reset() -> void:
	current_health = max_health
	is_dead = false
	health_changed.emit(current_health, max_health)
