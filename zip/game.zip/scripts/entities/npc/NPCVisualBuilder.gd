class_name NPCVisualBuilder
extends RefCounted

## NPCVisualBuilder — Erstellt die 3D-Visuals für einen NPC.
##
## Ausgelagert aus QuestNPC._build_visuals() (v28).
## Analog zu AnimalVisualBuilder — statisch, kein State.
##
## SEIT DER FIGUREN-ÜBERARBEITUNG baut jeder NPC denselben Körper wie ein Spieler
## (CharacterPartBuilder: Beine, Arme, Gesicht, Haare, Kleidung, Zubehör) statt
## "schwebender Kapsel + Kugel + Hut". Das Aussehen kommt aus NPCLook (Preset pro
## Story-NPC, sonst deterministisch aus dem Namen). Zusätzlich bekommt jeder NPC eine
## CharacterGaze: Augen/Kopf folgen dem nächsten Spieler in Reichweite, sonst schaut er
## sich im Idle um, blinzelt und atmet; ist der Spieler weit seitlich/hinter ihm, dreht
## er sich langsam mit.
##
## Zusätzlich (NPCProps): Handrequisiten (Axt, Spitzhacke, Speer, Korb, ...), Kopfbedeckungen
## (Schutzhelm mit Lampe, Helm, Zylinder), Schal, Rucksack, Umhang und der Geister-Look.
## Die Signatur ist rückwärtskompatibel: `build(parent, name)` und
## `build(parent, name, body_color)` funktionieren wie vorher (body_color wird zur
## Hemdfarbe). Neu ist nur der optionale vierte Parameter `look`.
##
## Erzeugt: "Visual" (Körper + Blicksteuerung), Name-Label3D, Dialog-Label3D
## (returned als Referenz).

## body_color: optionale Einfärbung des Oberteils, damit unterschiedliche
## NPC-Subklassen (Miner, Herbalist, ...) sich optisch unterscheiden lassen.
## look: optionale Feld-Überschreibungen (CharacterLook-IDs) für diesen NPC.
static func build(parent: Node3D, display_name: String, body_color: Color = NPCLook.DEFAULT_BODY_COLOR, look: Dictionary = {}) -> Label3D:
	var spec := NPCLook.resolve(display_name, body_color, look)

	# Körper + Blick unter einem eigenen Knoten — der Eltern-Knoten (StaticBody3D) bleibt
	# unverändert, nur die Optik dreht sich beim Umsehen.
	var visual := Node3D.new()
	visual.name = "Visual"
	var scale_f: float = spec["scale"]
	visual.scale = Vector3.ONE * scale_f
	parent.add_child(visual)

	var parts := CharacterPartBuilder.build(spec["look"], spec["overrides"])
	visual.add_child(parts["root"] as Node3D)
	NPCProps.apply(parts, spec["look"], spec)
	# Geister u. Ä. schweben leicht über dem Boden.
	visual.position.y = float(spec["hover"])

	var gaze := CharacterGaze.new()
	gaze.name = "Gaze"
	gaze.owner_exclude = parent
	gaze.interest_groups = PackedStringArray(["player"])
	gaze.interest_range = 6.0
	gaze.turn_body = visual
	visual.add_child(gaze)
	gaze.bind(parts)

	# Labels über Kopf/Hut (mit Körpergröße mitwachsend).
	var name_y := maxf(2.4, 1.95 * scale_f + 0.45) + float(spec["hover"])

	# Name-Label
	var name_lbl := Label3D.new()
	name_lbl.text      = display_name
	name_lbl.font_size = 48
	name_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_lbl.modulate  = Color(1.0, 0.9, 0.3)
	name_lbl.position.y = name_y
	parent.add_child(name_lbl)

	# Dialog-Label (Referenz zurückgeben, da QuestNPC damit arbeitet)
	var dialog_lbl := Label3D.new()
	dialog_lbl.text      = ""
	dialog_lbl.font_size = 36
	dialog_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	dialog_lbl.modulate  = Color(1.0, 1.0, 1.0, 0.9)
	dialog_lbl.position.y = name_y + 0.5
	dialog_lbl.visible    = false
	parent.add_child(dialog_lbl)

	return dialog_lbl
