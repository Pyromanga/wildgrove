class_name NPCVisualBuilder
extends RefCounted

## NPCVisualBuilder — Erstellt die 3D-Visuals für einen Quest-NPC.
##
## Ausgelagert aus QuestNPC._build_visuals() (v28).
## Analog zu AnimalVisualBuilder — statisch, kein State.
## Primitive-Erzeugung kommt aus ProcGenShapes (gemeinsame Basis mit
## AnimalVisualBuilder/CharacterPartBuilder — siehe dortigen Klassenkommentar), damit hier
## keine eigene Kopie von "Mesh + Material + MeshInstance3D" mehr nötig ist.
##
## Erzeugt: Körper-Kapsel, Kopf-Kugel, Hut-Zylinder, Name-Label3D,
##           Dialog-Label3D (returned als Referenz).

## body_color: optionale Einfärbung der Körper-Kapsel, damit unterschiedliche
## QuestNPC-Subklassen (Miner, Herbalist, ...) sich optisch unterscheiden lassen.
## Default entspricht 1:1 der bisherigen, fest verdrahteten Erik-Farbe —
## rückwärtskompatibel für alle bestehenden Aufrufer.
static func build(parent: Node3D, display_name: String, body_color: Color = Color(0.25, 0.40, 0.65)) -> Label3D:
	# Körper
	var body_mesh := ProcGenShapes.capsule(0.28, 1.1)
	parent.add_child(ProcGenShapes.mi(body_mesh, ProcGenShapes.mat(body_color), Vector3(0.0, 0.95, 0.0), "Body"))

	# Kopf
	var head_mesh := ProcGenShapes.sphere(0.22)
	parent.add_child(ProcGenShapes.mi(head_mesh, ProcGenShapes.mat(Color(0.88, 0.72, 0.58)), Vector3(0.0, 1.72, 0.0), "Head"))

	# Hut
	var hat_mesh := ProcGenShapes.cylinder(0.20, 0.28, 0.25)
	parent.add_child(ProcGenShapes.mi(hat_mesh, ProcGenShapes.mat(Color(0.25, 0.18, 0.08)), Vector3(0.0, 1.98, 0.0), "Hat"))

	# Name-Label
	var name_lbl := Label3D.new()
	name_lbl.text      = display_name
	name_lbl.font_size = 48
	name_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	name_lbl.modulate  = Color(1.0, 0.9, 0.3)
	name_lbl.position.y = 2.4
	parent.add_child(name_lbl)

	# Dialog-Label (Referenz zurückgeben, da QuestNPC damit arbeitet)
	var dialog_lbl := Label3D.new()
	dialog_lbl.text      = ""
	dialog_lbl.font_size = 36
	dialog_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	dialog_lbl.modulate  = Color(1.0, 1.0, 1.0, 0.9)
	dialog_lbl.position.y = 2.9
	dialog_lbl.visible    = false
	parent.add_child(dialog_lbl)

	return dialog_lbl
