extends StaticBody3D
class_name VillagerNPC

## VillagerNPC — Stationärer, beklaubarer Dorfbewohner (Wunsch "es fehlt ein
## NPC den ich beklauen kann").
##
## Bewusst nach ShopNPC.gd-Muster gebaut (StaticBody3D, kein CharacterBody3D/
## keine KI wie EnemyNPC) — ein Villager kämpft nicht und bewegt sich nicht,
## er steht nur herum und lässt sich bestehlen. Drei feste Aktionen
## ("pickpocket_weak/normal/strong"), exakt wie PlayerPickpocket.gd es für
## Spieler-Ziele macht (gleiche Kristall-Tiers, gleiche Konstanten in
## PickpocketService) — nur das Ziel ist hier ein NPC statt ein anderer
## Spieler-Node.
##
## AUTORITÄTS-ROUTING: anders als PlayerPickpocket/Player._on_pickpocket_
## requested() (das über NetworkBridge.send_pickpocket_attempt() explizit
## zur Autorität routen muss, weil ein Spieler-Node nicht zwingend
## Server-Autorität hat) braucht es hier KEINEN eigenen Netzwerk-Zweig:
## VillagerNPC ist wie EnemyNPC/HarvestableEntity ein normales Welt-Entity
## mit set_multiplayer_authority(1) — InteractableComponent._handle_
## completion() routet Klicks von Nicht-Autorität-Peers bereits generisch
## zur Autorität (siehe HarvestableEntity._on_interacted()-Kommentar
## "ADR-020 / R-1"). _on_interacted() unten läuft deshalb, exakt wie
## EnemyNPC._on_interacted(), direkt gegen PickpocketService.
##
## Siehe PickpocketService.on_pickpocket_npc_confirmed() für die eigentliche
## Diebstahl-Mechanik (Formel/Cooldown identisch zur Spieler-Variante, nur
## der stehlbare Pool ist ein fester Gold-Bereich statt echtem Inventar).

const LOG_CAT := "VillagerNPC"

## Konfigurierbar via on_spawn(config) — analog EnemyNPC.
@export var npc_display_name: String = "Dorfbewohner"
var _gold_min: int = 5
var _gold_max: int = 40
## Fiktiver "Verteidigungs-Level" gegen den die Diebstahl-Chance läuft
## (ersetzt SkillSystem.get_level() eines echten Opfers, siehe
## PickpocketService.on_pickpocket_npc_confirmed()). Niedrig gehalten —
## Villager sind ein leichtes Einstiegsziel, kein Endgame-Opfer.
var _defense_level: int = 5

var _dialog_label: Label3D
var _ctx: IEntityContext = null

const _CRYSTAL_BY_ACTION := {
	"pickpocket_weak":   "theft_crystal_weak",
	"pickpocket_normal": "theft_crystal_normal",
	"pickpocket_strong": "theft_crystal_strong",
}
const _TIER_CONFIG := [
	{"action_id": "pickpocket_weak",   "label": "Taschendiebstahl (schwach)", "comp_name": "PickpocketWeakInteractable"},
	{"action_id": "pickpocket_normal", "label": "Taschendiebstahl",           "comp_name": "PickpocketNormalInteractable"},
	{"action_id": "pickpocket_strong", "label": "Taschendiebstahl (stark)",   "comp_name": "PickpocketStrongInteractable"},
]

func _ready() -> void:
	name = "VillagerNPC_" + npc_display_name.replace(" ", "_")
	add_to_group("npcs")
	set_multiplayer_authority(1)
	_dialog_label = NPCVisualBuilder.build(self, npc_display_name)
	_build_collision()
	_setup_interactable()
	AppLogger.log_info("VillagerNPC '%s' bereit." % npc_display_name, LOG_CAT)

# ─────────────────────────────────────────────
# Interaktion
# ─────────────────────────────────────────────

func _setup_interactable() -> void:
	for tier_config in _TIER_CONFIG:
		var d := InteractableData.new()
		d.id           = tier_config["action_id"]
		d.label        = "%s (%s)" % [tier_config["label"], npc_display_name]
		d.duration     = 0.5
		# Kein xp_type/xp_amount — die Diebstahl-XP vergibt PickpocketService
		# selbst (Erfolg/Fehlschlag unterschiedlich), passt nicht ins feste
		# InteractionResolver-Schema. Identisches Muster wie PlayerPickpocket.gd.
		d.inspect_text = "%s. Wirkt beschäftigt und unaufmerksam." % npc_display_name
		var comp := InteractableComponent.new()
		comp.name = tier_config["comp_name"]
		comp.data = d
		add_child(comp)
		comp.interacted.connect(_on_interacted)

## Siehe Klassenkommentar "AUTORITÄTS-ROUTING" — kein Netzwerk-Zweig nötig,
## direkter Aufruf gegen PickpocketService, exakt wie EnemyNPC._on_interacted()
## gegen CombatSystem.
func _on_interacted(action_id: String, peer_id: int) -> void:
	if not action_id.begins_with("pickpocket_"):
		return
	if not is_multiplayer_authority():
		return
	if not is_instance_valid(_ctx):
		AppLogger.log_error("_on_interacted(): kein EntityContext gespeichert — Diebstahl verweigert.", LOG_CAT)
		return

	var pickpocket: PickpocketService = _ctx.get_pickpocket()
	if not is_instance_valid(pickpocket):
		AppLogger.log_error("_on_interacted(): kein PickpocketService im Context — Diebstahl verweigert.", LOG_CAT)
		return

	var crystal_item_id: String = _CRYSTAL_BY_ACTION.get(action_id, "")
	if crystal_item_id.is_empty():
		AppLogger.log_error("_on_interacted(): unbekannte action_id '%s'." % action_id, LOG_CAT)
		return

	var network: NetworkBridge = _ctx.get_network_bridge()
	var thief_id := network.get_player_id_for_peer(peer_id) if is_instance_valid(network) else ""
	if thief_id.is_empty():
		AppLogger.log_warn("_on_interacted(): player_id-Übersetzung fehlgeschlagen — Diebstahl verweigert.", LOG_CAT)
		return

	pickpocket.on_pickpocket_npc_confirmed(thief_id, name, crystal_item_id, _gold_min, _gold_max, _defense_level)

# ─────────────────────────────────────────────
# Collision
# ─────────────────────────────────────────────

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.35
	sh.height = 1.5
	col.shape = sh
	col.position.y = 0.75
	add_child(col)

# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────

## npc_display_name wird bewusst NICHT hier aus cfg übernommen (anders als
## z.B. EnemyNPC._label): _ready() (und damit NPCVisualBuilder.build() mit
## dem Namens-Label) läuft laut EntityOrchestrator-Kontrakt VOR on_spawn() —
## ein Override hier käme fürs Label immer zu spät. Wer einen anderen Namen
## braucht, setzt das @export-Feld an der Szene/Definition, nicht über cfg.
func on_spawn(cfg: Dictionary = {}, ctx: IEntityContext = null) -> void:
	_ctx = ctx
	if cfg.has("gold_min"):       _gold_min        = cfg["gold_min"]
	if cfg.has("gold_max"):       _gold_max        = cfg["gold_max"]
	if cfg.has("defense_level"):  _defense_level   = cfg["defense_level"]

func on_despawn() -> void:
	pass
