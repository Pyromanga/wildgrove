class_name AnimalVisualProfile
extends RefCounted

## AnimalVisualProfile — datengetriebene Beschreibung, wie EIN Tier aussieht.
##
## VORHER: AnimalVisualBuilder.build(color, body_size) baute für jede Tierart exakt
## dieselbe Silhouette (stehende Kapsel + Kugelkopf + 4 identische Beine, nur skaliert/
## eingefärbt) — Reh, Wildschwein und Hase unterschieden sich nur durch Größe und Farbe,
## nicht durch Form. Dieses Profil macht Kopf-/Schwanzmerkmale je Unterklasse
## konfigurierbar, OHNE dass jede Tierart ihre eigene Kopie der Geometrie-Erzeugung
## braucht — analog zu BuildPieceDefinition.PropShape (EIN Bauteil-Kind, viele
## Erscheinungsformen über ein Formfeld statt über Subklassen mit eigenem Zeichencode).
##
## AnimalBase-Unterklassen setzen in _on_ready_extended() weiterhin nur `_color` und
## `_body_size` (Kollisionsform bleibt unverändert!) und zusätzlich die Stil-Felder unten
## (`_ear_style` etc.) — AnimalBase baut daraus dieses Profil und reicht es an
## AnimalVisualBuilder.build() durch.

enum EarStyle { NONE, ROUND, POINTY, LONG, FLOPPY }
enum TailStyle { NONE, STUB, BUSHY, FLUFFY }
enum SnoutStyle { NONE, SHORT, LONG }
enum HeadgearStyle { NONE, ANTLERS, TUSKS }

var color: Color = Color(0.7, 0.5, 0.3)
## x = Körperbreite (Durchmesser), y = Höhe, z = Tiefe — dieselbe Konvention wie bisher
## AnimalBase._body_size (bleibt zusätzlich alleinige Quelle für die Kollisionskapsel,
## siehe AnimalBase._build_collision() — rein kosmetische Merkmale unten beeinflussen die
## Kollision bewusst nicht).
var body_size: Vector3 = Vector3(0.4, 0.6, 0.4)

var ear_style: int = EarStyle.ROUND
var tail_style: int = TailStyle.STUB
var snout_style: int = SnoutStyle.SHORT
var headgear_style: int = HeadgearStyle.NONE

## Zusätzlicher Größenfaktor nur für den Schwanz (z.B. Eichhörnchen: ikonischer,
## überproportional großer Schwanz) — ohne eigenes TailStyle-Enum-Mitglied pro Spezies.
var tail_scale: float = 1.0

func _init(p_color: Color = Color(0.7, 0.5, 0.3), p_body_size: Vector3 = Vector3(0.4, 0.6, 0.4)) -> void:
	color = p_color
	body_size = p_body_size
