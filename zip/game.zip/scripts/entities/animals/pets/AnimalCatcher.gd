class_name AnimalCatcher
extends RefCounted

## AnimalCatcher — Utility zum Umwandeln eines gefangenen Tieres in ein Pet.
## Wird von der Fangen-Aktion in AnimalBase aufgerufen.
##
## Spawnt das Pet über EntityOrchestrator.spawn_entity("pet", ...) statt per
## direktem PetComponent.new() + add_child() — sonst ist das Pet für andere
## Peers unsichtbar (MultiplayerSpawner kennt nur registrierte EntityRegistry-
## Typen) und bekommt keinen owner_peer_id für die Folge-Logik.
##
## owner_peer_id = peer_id, Pflichtparameter vom Aufrufer (AnimalBase._on_interacted()).
## ADR-015 Phase 5: das war zuvor animal.get_multiplayer().get_unique_id() —
## eine Näherung, weil das Interaktionssystem (InteractableComponent.interacted-
## Signal) keine Spieler-Identität trug. Seit Phase 4 trägt es sie echt, also
## wird hier nicht mehr geraten, sondern der reale Wert entgegengenommen.

const LOG_CAT := "AnimalCatcher"

static func catch_animal(animal: AnimalBase, peer_id: int) -> PetComponent:
	if not is_instance_valid(animal):
		return null

	# BUG-FIX: 'animal' kann durch einen zeitgleichen Despawn/Respawn-Zyklus
	# (RespawnService) exakt im Moment des Fangens kurzzeitig aus dem
	# SceneTree entfernt sein. global_position (-> get_global_transform())
	# crasht dann mit "!is_inside_tree()" und liefert eine korrupte
	# Transform3D()-Position für das neue Pet. Sauber abbrechen statt mit
	# falscher Position weiterzumachen.
	if not animal.is_inside_tree():
		AppLogger.log_warn(
			"catch_animal(): '%s' war beim Fangen nicht im SceneTree (Despawn-Race) — abgebrochen." % animal.name,
			LOG_CAT
		)
		return null

	var ctx: IEntityContext = animal.get_context()
	var world: WorldService = ctx.get_world() if is_instance_valid(ctx) else null
	if not is_instance_valid(world):
		AppLogger.log_error(
			"catch_animal(): kein WorldService im EntityContext — Fangen abgebrochen (kein AutoLoad-Fallback).",
			LOG_CAT
		)
		return null

	# Alles vor queue_free() einsammeln — 'animal' ist danach zur Freigabe vorgemerkt.
	var owner_peer_id := peer_id
	var pet_name := "Zahmes " + animal.name
	var pos := animal.global_position
	var bus: IEventBus = ctx.get_event_bus()
	var animal_name := animal.name

	# BUGFIX (2026-09-17, "Dinge werden nicht gesynct"): dieselbe Lücke wie bei
	# EnemyNPC._die()/HarvestableEntity._on_interacted()/Gravestone._request_despawn()
	# — animal.queue_free() unten läuft nur lokal auf der Autorität, kein
	# anderer Peer erfuhr je davon (dessen eigene, lokal gespawnte Kopie des
	# Tieres blieb als Leiche stehen). network kommt bewusst vom Animal selbst
	# (get_context()), nicht vom neu gespawnten Pet — das Pet existiert zu
	# diesem Zeitpunkt noch gar nicht.
	var network: NetworkBridge = ctx.get_network_bridge() if is_instance_valid(ctx) else null
	if is_instance_valid(network):
		network.broadcast_to_all_peers("entity_despawned", {"name": animal_name})
	else:
		AppLogger.log_warn(
			"catch_animal(): kein NetworkBridge verfügbar — Despawn von '%s' wird anderen Peers nicht gemeldet." % animal_name,
			LOG_CAT
		)

	# FEATURE (2026-09-17, "Pets cross-peer sichtbar"): owner_player_id (statt
	# nur owner_peer_id) für EntityOrchestrator.spawn_entity()'s deterministische
	# Namensvergabe — siehe dortiger Kommentar. Leerer String (kein
	# NetworkBridge, z.B. Solo/Tests) → Fallback auf peer_id dort, unverändertes
	# Verhalten.
	var owner_player_id := network.get_player_id_for_peer(owner_peer_id) if is_instance_valid(network) else ""
	var config := {
		"name":            pet_name,
		"color":           animal._color,
		"body_size":       animal._body_size,
		"speed":           animal._speed * 0.85,
		# BUGFIX ("Nach dem Fangen ist das ursprüngliche Modell weg"): bisher gingen die
		# kosmetischen Silhouette-Felder (Ohren/Schwanz/Schnauze/Kopfschmuck) beim Fangen
		# verloren — PetComponent baute nur eine schlichte Kapsel mit der übernommenen
		# Farbe/Größe. Jetzt reicht catch_animal() dieselben Felder durch, aus denen das
		# Tier selbst gebaut wurde (siehe AnimalVisualProfile/AnimalVisualBuilder), damit
		# das Pet wie das ursprüngliche Tier aussieht.
		"ear_style":       animal._ear_style,
		"tail_style":      animal._tail_style,
		"snout_style":     animal._snout_style,
		"headgear_style":  animal._headgear_style,
		"tail_scale":      animal._tail_scale,
		"owner_peer_id":   owner_peer_id,
		"owner_player_id": owner_player_id,
	}

	animal.queue_free()

	var pet := world.spawn_entity("pet", pos, config, owner_peer_id) as PetComponent
	if not is_instance_valid(pet):
		AppLogger.log_error("catch_animal(): spawn_entity('pet') fehlgeschlagen.", LOG_CAT)
		return null

	AppLogger.log_info(
		"Tier gefangen → Pet '%s' erstellt (Besitzer: peer %d)." % [pet_name, owner_peer_id], LOG_CAT
	)
	if is_instance_valid(bus):
		bus.world().emit_interaction_reward_text("Du hast ein %s gefangen!" % pet_name)
	return pet
