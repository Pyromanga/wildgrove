class_name PetPanelController
extends Node

## PetPanelController — verbindet PetPanelVisuals mit WorldService.get_pets_for_peer()
## (Lesen) und PetComponent.set_abilities() (Schreiben, siehe dortiger Kommentar
## zum Autoritäts-Guard). Kein eigener Zustand über eine Frame-Refresh-Runde
## hinaus — die "Wahrheit" bleibt immer bei den PetComponent-Instanzen selbst.
##
## REFRESH-STRATEGIE: kein Event wie SkillSystem.skill_changed existiert für
## "ein Pet wurde gezähmt/despawnt" (siehe TODO-offene-probleme.md — bewusst
## kein neues Event nur dafür eingeführt, um die Änderung klein zu halten).
## Stattdessen: Refresh bei jedem Öffnen des Panels (visibility_changed) — für
## ein Menü, das der Spieler aktiv aufruft, reicht das; ein frisch gefangenes
## Pet taucht beim nächsten Öffnen auf, nicht in Echtzeit während es bereits
## offen ist.

var _visuals: PetPanelVisuals
var _ctx: IUIContext

func setup(visuals: PetPanelVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx     = ctx
	_visuals.ability_toggled.connect(_on_ability_toggled)
	_visuals.panel.visibility_changed.connect(_on_visibility_changed)
	refresh()

func _on_visibility_changed() -> void:
	if _visuals.panel.visible:
		refresh()

## Öffentlich (wie InventoryUIController.refresh()) — HUDBuilder ruft das einmal
## direkt nach dem Bauen auf, damit das Panel auch ohne vorheriges Öffnen/
## Schließen einen korrekten Erststand hätte, falls es je initial sichtbar wäre.
func refresh() -> void:
	if not is_instance_valid(_visuals):
		return
	_visuals.set_pets(_collect_pet_rows())

func _collect_pet_rows() -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	var world: WorldService = _ctx.get_world() if is_instance_valid(_ctx) else null
	if not is_instance_valid(world):
		return rows
	var peer_id := _ctx.get_local_peer_id()
	for pet in world.get_pets_for_peer(peer_id):
		rows.append({
			"id":        pet.get_instance_id(),
			"name":      pet.get_pet_name(),
			"abilities": pet.get_abilities(),
		})
	return rows

func _on_ability_toggled(pet_instance_id: int, ability_id: String, enabled: bool) -> void:
	var pet := instance_from_id(pet_instance_id)
	if not is_instance_valid(pet) or not (pet is PetComponent):
		# Pet wurde zwischen Panel-Öffnen und Tap despawnt (gestorben/entfernt) —
		# kein Fehlerfall, nur zu spät. Nächster refresh() (nächstes Öffnen)
		# räumt die Zeile automatisch weg.
		AppLogger.log_warn(
			"Pet-Menü: Toggle auf nicht mehr existentes Pet (instance_id %d) ignoriert." % pet_instance_id,
			"PetPanel"
		)
		return
	var current := (pet as PetComponent).get_abilities()
	if enabled and not current.has(ability_id):
		current.append(ability_id)
	elif not enabled:
		current.erase(ability_id)
	(pet as PetComponent).set_abilities(current)
