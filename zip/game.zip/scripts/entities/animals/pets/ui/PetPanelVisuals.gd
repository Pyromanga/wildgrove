class_name PetPanelVisuals

## PetPanelVisuals — "Pets"-Sheet (Pet-Menü): listet alle eigenen Pets und
## erlaubt pro Pet, welche Fähigkeiten (Sammeln/Bergbau/Fällen/Kampf/Graben,
## siehe PetAbilities) gerade aktiv sind zuzuweisen — Wunsch "Pets auf
## Ressourcen sammeln usw. verteilen"; bisher gab es dafür kein Interface,
## nur die Arten-Defaults aus AnimalCatcher.catch_animal().
##
## ÜBERARBEITUNG (Wunsch "alles ist relativ klein" / "Scrollen ... im Pet-Menü
## brutal" / "UI generell ansprechender machen"):
##   - Einheitlicher Look über UIMetrics.panel_style()/row_style() statt
##     eigener StyleBoxFlat-Werte.
##   - Kopfzeile mit ✕-Schließen-Button (UIMetrics.build_header()) statt
##     "Panel nur über den Toolbar-Button wieder zu bekommen".
##   - Größere Schrift/Touch-Ziele über UIMetrics (FONT_TITLE/FONT_ROW/FONT_SUB,
##     TAP_MIN) statt hartcodierter 16/150.
##   - ECHTES Scrollen: das Grid aus Fähigkeits-Buttons pro Pet-Zeile bedeckt
##     praktisch die ganze Zeilenfläche — ohne UIMetrics.allow_scroll_through()
##     startet fast jede Wisch-Geste auf einem Button (der sie standardmäßig
##     verschluckt, siehe dortiger Kommentar) und der ScrollContainer bekommt
##     sie nie zu sehen. set_pets() ruft das deshalb NACH jedem Rebuild erneut
##     auf (Zeilen werden bei jedem Öffnen komplett neu gebaut).
##
## Bewusst zustandslos bzgl. Spiellogik: set_pets() baut die Zeilen bei JEDEM
## Aufruf komplett neu auf (kein Row-Diffing) — Pet-Listen sind klein (wenige
## Tiere) und ändern sich selten (fangen/despawnen), ein voller Rebuild ist
## hier einfacher und robuster als Zeilen einzeln zu synchronisieren. Toggle-
## Klicks werden nur über `ability_toggled` nach außen gemeldet — ob/wie
## PetComponent.set_abilities() das tatsächlich übernimmt, entscheidet
## PetPanelController, nicht diese Klasse (siehe dortiger Kommentar).

signal ability_toggled(pet_instance_id: int, ability_id: String, enabled: bool)

## Anzeige-Reihenfolge + Label je Fähigkeit (siehe PetAbilities.ALL).
const ABILITY_ORDER: Array[String] = [
	PetAbilities.GATHERING, PetAbilities.MINING, PetAbilities.WOODCUTTING,
	PetAbilities.COMBAT, PetAbilities.DIGGING,
]
const ABILITY_LABELS: Dictionary = {
	PetAbilities.GATHERING:   "🌿 Sammeln",
	PetAbilities.MINING:      "⛏ Bergbau",
	PetAbilities.WOODCUTTING: "🪓 Fällen",
	PetAbilities.COMBAT:      "⚔ Kampf",
	PetAbilities.DIGGING:     "🕳 Graben",
}

## Etwas breiter als der Sheet-Standard (UIMetrics.SHEET_WIDTH) — das
## 2-spaltige Fähigkeiten-Grid + größere Schrift brauchen mehr Platz, sonst
## brechen die Button-Texte um.
const PANEL_WIDTH := 440.0

var panel: PanelContainer
var toggle_button: Button
var _rows: VBoxContainer
var _empty_label: Label

func _init(parent: CanvasLayer) -> void:
	toggle_button = Button.new()
	toggle_button.name = "PetToggleButton"
	toggle_button.text = "🐾"
	toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	toggle_button.pressed.connect(toggle)

	panel = PanelContainer.new()
	panel.name = "PetPanel"
	panel.visible = false
	panel.add_theme_stylebox_override("panel", UIMetrics.panel_style())

	UIMetrics.place_sheet(panel, PANEL_WIDTH)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 10)
	panel.add_child(vbox)

	vbox.add_child(UIMetrics.build_header("🐾 Pets", panel))

	var subtitle := Label.new()
	subtitle.text = "Fähigkeiten pro Pet zuweisen"
	subtitle.add_theme_font_size_override("font_size", UIMetrics.FONT_SUB)
	subtitle.modulate = Color(1, 1, 1, 0.6)
	vbox.add_child(subtitle)

	_empty_label = Label.new()
	_empty_label.text = "Noch kein Pet gezähmt."
	_empty_label.add_theme_font_size_override("font_size", UIMetrics.FONT_ROW)
	_empty_label.modulate = Color(1, 1, 1, 0.6)
	_empty_label.visible = false
	vbox.add_child(_empty_label)

	_rows = VBoxContainer.new()
	_rows.name = "PetRows"
	_rows.add_theme_constant_override("separation", 14)
	vbox.add_child(UIMetrics.make_scrollable(_rows))

	parent.add_child(panel)
	PanelDock.register_in(parent, &"pets", panel, PanelDock.Kind.SHEET, toggle_button)

## pets: Array[Dictionary] mit { "id": int (instance_id), "name": String,
## "abilities": Array[String] } — siehe PetPanelController._collect_pet_rows().
func set_pets(pets: Array[Dictionary]) -> void:
	for child in _rows.get_children():
		_rows.remove_child(child)
		child.queue_free()

	_empty_label.visible = pets.is_empty()

	for pet_data in pets:
		_rows.add_child(_build_pet_row(pet_data))

	# MUSS nach jedem Rebuild erneut laufen — die eben neu erzeugten Buttons
	# haben wieder das Standard-STOP (siehe Klassenkommentar oben).
	UIMetrics.allow_scroll_through(_rows)

func _build_pet_row(pet_data: Dictionary) -> Control:
	var pet_id: int = pet_data.get("id", 0)
	var abilities: Array = pet_data.get("abilities", [])

	var container := PanelContainer.new()
	container.add_theme_stylebox_override("panel", UIMetrics.row_style())

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 8)
	container.add_child(col)

	var name_lbl := Label.new()
	name_lbl.text = String(pet_data.get("name", "Pet"))
	name_lbl.add_theme_font_size_override("font_size", UIMetrics.FONT_ROW)
	col.add_child(name_lbl)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	col.add_child(grid)

	for ability_id in ABILITY_ORDER:
		var btn := Button.new()
		btn.text = String(ABILITY_LABELS.get(ability_id, ability_id))
		btn.toggle_mode = true
		btn.button_pressed = abilities.has(ability_id)
		btn.add_theme_font_size_override("font_size", UIMetrics.FONT_SUB)
		UIMetrics.tap(btn, 170)
		btn.toggled.connect(func(enabled: bool) -> void:
			ability_toggled.emit(pet_id, ability_id, enabled)
		)
		grid.add_child(btn)

	return container

func toggle() -> void:
	panel.visible = !panel.visible
