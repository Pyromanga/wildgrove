class_name PetPanelVisuals

## PetPanelVisuals — "Pets"-Sheet (Pet-Menü): listet alle eigenen Pets und
## erlaubt pro Pet, welche Fähigkeiten (Sammeln/Bergbau/Fällen/Kampf/Graben,
## siehe PetAbilities) gerade aktiv sind zuzuweisen — Wunsch "Pets auf
## Ressourcen sammeln usw. verteilen"; bisher gab es dafür kein Interface,
## nur die Arten-Defaults aus AnimalCatcher.catch_animal().
##
## Gleicher Aufbau wie SkillPanelVisuals (PanelDock-Sheet, ScrollContainer mit
## fester Maximalhöhe statt unbegrenzt mitwachsend, siehe dortiger Kommentar
## "wie BuildPanelVisuals" zur Begründung).
##
## Bewusst zustandslos bzgl. Spiellogik: set_pets() baut die Zeilen bei JEDEM
## Aufruf komplett neu auf (kein Row-Diffing) — Pet-Listen sind klein (wenige
## Tiere) und ändern sich selten (fangen/despawnen), ein voller Rebuild ist
## hier einfacher und robuster als Zeilen einzeln zu synchronisieren. Toggle-
## Klicks werden nur über `ability_toggled` nach außen gemeldet — ob/wie
## PetComponent.set_abilities() das tatsächlich übernimmt, entscheidet
## PetPanelController, nicht diese Klasse (siehe dortiger Kommentar).

signal ability_toggled(pet_instance_id: int, ability_id: String, enabled: bool)

## Anzeige-Reihenfolge + Label je Fähigkeit (siehe PetAbilities.ALL).
const ABILITY_ORDER: Array[String] = [
	PetAbilities.GATHERING, PetAbilities.MINING, PetAbilities.WOODCUTTING,
	PetAbilities.COMBAT, PetAbilities.DIGGING,
]
const ABILITY_LABELS: Dictionary = {
	PetAbilities.GATHERING:   "🌿 Sammeln",
	PetAbilities.MINING:      "⛏ Bergbau",
	PetAbilities.WOODCUTTING: "🪓 Fällen",
	PetAbilities.COMBAT:      "⚔ Kampf",
	PetAbilities.DIGGING:     "🕳 Graben",
}

var panel: PanelContainer
var toggle_button: Button
var _rows: VBoxContainer
var _empty_label: Label

func _init(parent: CanvasLayer) -> void:
	toggle_button = Button.new()
	toggle_button.name = "PetToggleButton"
	toggle_button.text = "🐾"
	toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	toggle_button.pressed.connect(toggle)

	panel = PanelContainer.new()
	panel.name = "PetPanel"
	panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.07, 0.10, 0.94)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)

	UIMetrics.place_sheet(panel, 360)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	panel.add_child(vbox)

	var title := Label.new()
	title.text = "Pets"
	title.add_theme_font_size_override("font_size", 20)
	vbox.add_child(title)

	_empty_label = Label.new()
	_empty_label.text = "Noch kein Pet gezähmt."
	_empty_label.modulate = Color(1, 1, 1, 0.6)
	_empty_label.visible = false
	vbox.add_child(_empty_label)

	_rows = VBoxContainer.new()
	_rows.name = "PetRows"
	_rows.add_theme_constant_override("separation", 12)
	var scroll := ScrollContainer.new()
	scroll.name = "PetRowsScroll"
	scroll.custom_minimum_size = Vector2(0, 420)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroll.add_child(_rows)
	vbox.add_child(scroll)

	parent.add_child(panel)
	PanelDock.register_in(parent, &"pets", panel, PanelDock.Kind.SHEET, toggle_button)

## pets: Array[Dictionary] mit { "id": int (instance_id), "name": String,
## "abilities": Array[String] } — siehe PetPanelController._collect_pet_rows().
func set_pets(pets: Array[Dictionary]) -> void:
	for child in _rows.get_children():
		_rows.remove_child(child)
		child.queue_free()

	_empty_label.visible = pets.is_empty()

	for pet_data in pets:
		_rows.add_child(_build_pet_row(pet_data))

func _build_pet_row(pet_data: Dictionary) -> Control:
	var pet_id: int = pet_data.get("id", 0)
	var abilities: Array = pet_data.get("abilities", [])

	var container := PanelContainer.new()
	var row_sb := StyleBoxFlat.new()
	row_sb.bg_color = Color(1, 1, 1, 0.05)
	row_sb.set_corner_radius_all(8)
	row_sb.set_content_margin_all(10)
	container.add_theme_stylebox_override("panel", row_sb)

	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 6)
	container.add_child(col)

	var name_lbl := Label.new()
	name_lbl.text = String(pet_data.get("name", "Pet"))
	name_lbl.add_theme_font_size_override("font_size", 16)
	col.add_child(name_lbl)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 6)
	grid.add_theme_constant_override("v_separation", 6)
	col.add_child(grid)

	for ability_id in ABILITY_ORDER:
		var btn := Button.new()
		btn.text = String(ABILITY_LABELS.get(ability_id, ability_id))
		btn.toggle_mode = true
		btn.button_pressed = abilities.has(ability_id)
		UIMetrics.tap(btn, 150)
		btn.toggled.connect(func(enabled: bool) -> void:
			ability_toggled.emit(pet_id, ability_id, enabled)
		)
		grid.add_child(btn)

	return container

func toggle() -> void:
	panel.visible = !panel.visible
