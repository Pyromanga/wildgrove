class_name PetAbilityComponent
extends Node

## PetAbilityComponent — führt EINE Pet-Fähigkeit autonom aus (siehe PetAbilities
## für die IDs). PetComponent erzeugt pro Fähigkeit in config["abilities"] eine
## eigene Instanz und hängt sie als Kind an (siehe PetComponent._build_abilities()).
##
## ARCHITEKTUR-ENTSCHEIDUNG: Fähigkeiten laufen NICHT über den normalen
## Spieler-Interaktionspfad (InteractionExecutor — der ist pro PEER-ID
## BUSY/FREE-gated, siehe dortiger Klassenkommentar; ein Pet über die peer_id
## seines Besitzers laufen zu lassen würde jede eigene Aktion des Besitzers
## blockieren, sobald das Pet gerade sammelt/kämpft, und umgekehrt). Stattdessen
## führt diese Komponente ihre eigene, lokale Wartezeit (siehe _state-Automat
## unten) und ruft danach denselben autoritäts-geguardeten Einstiegspunkt auf,
## den auch InteractableComponent._handle_completion() für einen Spieler nutzt:
## WorldService.request_entity_interaction(uuid, action_id, owner_peer_id) für
## Ernte-/Kampf-Ziele, bzw. EventBus.world().terrain_edit_requested() für Graben
## (derselbe Weg wie GroundToolController._start()). Loot/XP/Autoritäts-Prüfung
## laufen dadurch unverändert über die bestehende, servereigene Pipeline — ein
## Pet kann strukturell nichts anderes auslösen als ein Spieler an gleicher
## Stelle auch könnte.
##
## BEKANNTE EINSCHRÄNKUNG (dokumentiert statt stillschweigend in Kauf genommen,
## gleiche Konvention wie TODO-offene-probleme.md): Die serverseitige
## Reichweitenprüfung (EntityOrchestrator.resolve_for_player() bzw.
## WorldService._edit_gate()) misst die Distanz vom BESITZER-Spieler zum Ziel,
## nicht vom Pet selbst — es gibt (noch) keinen positions-basierten
## Gegenpart dieser Prüfung. Läuft der Besitzer weit weg während das Pet einem
## Fähigkeits-Ziel nachläuft, kann die Aktion serverseitig fehlschlagen (nur
## ein Log-Warn, kein Crash) — SEARCH_RADIUS unten ist deshalb bewusst klein
## gehalten, damit das Pet in normalem Spiel nahe genug am Besitzer bleibt.

const LOG_CAT := "PetAbility"

## Von PetComponent._build_abilities() gesetzt, siehe PetAbilities-Konstanten.
var ability_id: String = ""

var _pet:   PetComponent    = null
var _ctx:   IEntityContext  = null
var _bus:   IEventBus       = null
var _owner_peer_id:   int    = 1
var _owner_player_id: String = ""

# ─────────────────────────────────────────────
# Gemeinsame Tuning-Werte
# ─────────────────────────────────────────────
const SEARCH_RADIUS   := 7.0   ## Wie weit ein Pet nach einem Ziel sucht (siehe Klassenkommentar oben).
const SCAN_INTERVAL   := 1.5   ## Sekunden zwischen zwei Ziel-Suchen im IDLE-Zustand.

# Ernte-Fähigkeiten (gathering/woodcutting/mining)
const HARVEST_ARRIVE_RADIUS := 1.4

# Kampf
const ATTACK_RANGE      := 1.7
const ATTACK_CHASE_SLACK := 1.3  ## Toleranz bevor erneut auf das Ziel zubewegt wird (verhindert Zittern).
const ATTACK_COOLDOWN   := 1.3

# Graben
const DIG_RADIUS    := 2.5
const DIG_ARRIVE     := 0.6
const DIG_DURATION   := 2.0
const DIG_COOLDOWN   := 5.0

enum State { IDLE, SEEKING, ACTING }

var _state: State = State.IDLE
var _target: Node3D = null
var _act_time_left: float = 0.0
var _scan_cooldown: float = 0.0
var _attack_cooldown: float = 0.0

var _dig_point: Vector3 = Vector3.ZERO
var _rng := RandomNumberGenerator.new()

## Aufgerufen von PetComponent unmittelbar nach add_child(). Pflicht-Setup —
## ohne gültigen ctx/bus bleibt die Komponente untätig (siehe _physics_process()-
## Guard), loggt aber nicht bei jedem Frame, nur einmalig hier.
func setup(pet: PetComponent, ctx: IEntityContext, bus: IEventBus, owner_peer_id: int, owner_player_id: String) -> void:
	_pet = pet
	_ctx = ctx
	_bus = bus
	_owner_peer_id = owner_peer_id
	_owner_player_id = owner_player_id
	_rng.randomize()
	if not is_instance_valid(_ctx) or not is_instance_valid(_ctx.get_world()):
		AppLogger.log_warn(
			"setup('%s'): kein WorldService im Context — Fähigkeit bleibt untätig." % ability_id, LOG_CAT
		)

func _physics_process(delta: float) -> void:
	if not is_instance_valid(_pet) or not is_instance_valid(_ctx):
		return
	# Nur die Netzwerk-Autorität des Pets entscheidet — Pets sind
	# client-autoritativ (siehe PetComponent.on_spawn()), genau wie deren
	# eigene Bewegungslogik in PetComponent._physics_process().
	if not _pet.is_multiplayer_authority():
		return
	match ability_id:
		PetAbilities.COMBAT:
			_process_combat(delta)
		PetAbilities.DIGGING:
			_process_digging(delta)
		_:
			if PetAbilities.is_harvest_ability(ability_id):
				_process_harvest(delta)

func _exit_tree() -> void:
	_unclaim_target()

# ─────────────────────────────────────────────
# Sammeln / Abbauen / Fällen (gathering, mining, woodcutting)
# ─────────────────────────────────────────────

func _process_harvest(delta: float) -> void:
	match _state:
		State.IDLE:
			_scan_cooldown -= delta
			if _scan_cooldown > 0.0:
				return
			_scan_cooldown = SCAN_INTERVAL
			_target = _find_harvest_target()
			if is_instance_valid(_target):
				_claim_target(_target)
				_state = State.SEEKING

		State.SEEKING:
			if not _target_still_valid():
				_reset_idle()
				return
			if not _pet.request_movement(self, _target.global_position, HARVEST_ARRIVE_RADIUS):
				return  # eine andere Fähigkeit dieses Pets steuert gerade — warten
			if _pet.has_arrived_at_movement_target():
				_act_time_left = _resolve_duration(_target)
				_state = State.ACTING

		State.ACTING:
			if not _target_still_valid():
				_reset_idle()
				return
			# Steuerung explizit auf das (unbewegliche) Ziel halten, damit das Pet
			# nicht während der Wartezeit wieder Richtung Besitzer abdriftet.
			_pet.request_movement(self, _target.global_position, HARVEST_ARRIVE_RADIUS)
			_act_time_left -= delta
			if _act_time_left <= 0.0:
				_complete_harvest()

func _find_harvest_target() -> Node3D:
	var allowed := PetAbilities.harvest_type_ids_for(ability_id)
	if allowed.is_empty():
		return null
	return _find_nearest_in_group("interactable", func(node: Node) -> bool:
		if not node.has_method("_get_entity_type_id"):
			return false
		if not (String(node.call("_get_entity_type_id")) in allowed):
			return false
		return not bool(node.get_meta("pet_claimed", false))
	, SEARCH_RADIUS)

## Liest die Interaktions-Dauer aus der InteractableComponent des Ziels (Meta
## "interactable_components", siehe WorldService._max_interaction_range_for()
## für dasselbe Muster) — Fallback 2.0s falls das Meta fehlt (sollte bei jeder
## HarvestableEntity-Instanz gesetzt sein, siehe InteractableComponent._ready()).
func _resolve_duration(node: Node) -> float:
	var comps: Array = node.get_meta("interactable_components", [])
	for comp in comps:
		if is_instance_valid(comp) and comp is InteractableComponent:
			return maxf(0.2, (comp as InteractableComponent).data.duration)
	return 2.0

func _resolve_action_id(node: Node) -> String:
	var comps: Array = node.get_meta("interactable_components", [])
	for comp in comps:
		if is_instance_valid(comp) and comp is InteractableComponent:
			return (comp as InteractableComponent).data.id
	return ""

func _complete_harvest() -> void:
	var target := _target
	var action_id := _resolve_action_id(target) if is_instance_valid(target) else ""
	if is_instance_valid(target) and not action_id.is_empty():
		var world: WorldService = _ctx.get_world()
		var uuid := world.resolve_entity_uuid(target)
		if not uuid.is_empty():
			world.request_entity_interaction(uuid, action_id, _owner_peer_id)
		else:
			AppLogger.log_warn(
				"_complete_harvest('%s'): keine entity_uuid für Ziel — Aktion nicht ausgelöst." % ability_id,
				LOG_CAT
			)
	_reset_idle()

# ─────────────────────────────────────────────
# Kampf
# ─────────────────────────────────────────────

func _process_combat(delta: float) -> void:
	match _state:
		State.IDLE:
			_scan_cooldown -= delta
			if _scan_cooldown > 0.0:
				return
			_scan_cooldown = SCAN_INTERVAL
			_target = _find_combat_target()
			if is_instance_valid(_target):
				_claim_target(_target)
				_attack_cooldown = 0.0
				_state = State.SEEKING

		State.SEEKING:
			if not _combat_target_alive():
				_reset_idle()
				return
			if not _pet.request_movement(self, _target.global_position, ATTACK_RANGE * 0.7):
				return
			if _pet.has_arrived_at_movement_target():
				_state = State.ACTING

		State.ACTING:
			if not _combat_target_alive():
				_reset_idle()
				return
			var dist := _pet.global_position.distance_to(_target.global_position)
			if dist > ATTACK_RANGE * ATTACK_CHASE_SLACK:
				_state = State.SEEKING
				return
			# Nah dran halten (Ziel kann sich bewegen — EnemyAI verfolgt den Besitzer).
			_pet.request_movement(self, _target.global_position, ATTACK_RANGE * 0.7)
			_attack_cooldown -= delta
			if _attack_cooldown <= 0.0:
				_do_attack()
				_attack_cooldown = ATTACK_COOLDOWN

func _find_combat_target() -> Node3D:
	# "enemies" + gleichzeitig noch "interactable" = lebt noch (EnemyNPC._die()
	# entfernt die Gruppe "interactable" beim Tod, siehe dortiger Kommentar) —
	# ohne eigenen Zugriff auf EnemyAI.State (privater Zustand der Entity).
	return _find_nearest_in_group("enemies", func(node: Node) -> bool:
		if not node.is_in_group("interactable"):
			return false
		return not bool(node.get_meta("pet_claimed", false))
	, SEARCH_RADIUS)

func _combat_target_alive() -> bool:
	return _target_still_valid() and _target.is_in_group("interactable")

func _do_attack() -> void:
	if not is_instance_valid(_target):
		return
	var world: WorldService = _ctx.get_world()
	var uuid := world.resolve_entity_uuid(_target)
	if uuid.is_empty():
		AppLogger.log_warn("_do_attack(): keine entity_uuid für Kampfziel.", LOG_CAT)
		return
	world.request_entity_interaction(uuid, "attack_enemy", _owner_peer_id)

# ─────────────────────────────────────────────
# Graben
# ─────────────────────────────────────────────

var _dig_state: State = State.IDLE

func _process_digging(delta: float) -> void:
	match _dig_state:
		State.IDLE:
			_scan_cooldown -= delta
			if _scan_cooldown > 0.0:
				return
			_scan_cooldown = DIG_COOLDOWN
			_dig_point = _pick_dig_point()
			_dig_state = State.SEEKING

		State.SEEKING:
			if not _pet.request_movement(self, _dig_point, DIG_ARRIVE):
				return
			if _pet.has_arrived_at_movement_target():
				_act_time_left = DIG_DURATION
				_dig_state = State.ACTING

		State.ACTING:
			_pet.request_movement(self, _dig_point, DIG_ARRIVE)
			_act_time_left -= delta
			if _act_time_left <= 0.0:
				_do_dig()
				_pet.release_movement(self)
				_dig_state = State.IDLE

func _pick_dig_point() -> Vector3:
	var angle := _rng.randf_range(0.0, TAU)
	var radius := _rng.randf_range(0.5, DIG_RADIUS)
	var offset := Vector3(cos(angle) * radius, 0.0, sin(angle) * radius)
	return _pet.global_position + offset

## Gleicher Weg wie GroundToolController._start()/build_action() —
## EventBus.world().terrain_edit_requested() → WorldService.request_terrain_edit().
## Nur Solo unterstützt (siehe WorldService._edit_gate(): "coop_unsupported" in
## Mehrspieler-Sitzungen) — dort schlägt der Aufruf mit einem Log-Warn fehl,
## kein Crash, kein Sonderfall hier nötig.
func _do_dig() -> void:
	if not is_instance_valid(_bus):
		return
	if _owner_player_id.is_empty():
		AppLogger.log_warn("_do_dig(): keine owner_player_id — Graben nicht ausgelöst.", LOG_CAT)
		return
	_bus.world().emit_terrain_edit_requested(_owner_player_id, WorldTerrainEditor.MODE_DIG, _dig_point)

# ─────────────────────────────────────────────
# Gemeinsame Helfer
# ─────────────────────────────────────────────

func _find_nearest_in_group(group: String, filter: Callable, radius: float) -> Node3D:
	if not _pet.is_inside_tree():
		return null
	var best: Node3D = null
	var best_dist_sq := radius * radius
	for node in _pet.get_tree().get_nodes_in_group(group):
		if not (node is Node3D) or not is_instance_valid(node):
			continue
		if node == _pet:
			continue
		if filter.is_valid() and not bool(filter.call(node)):
			continue
		var d := _pet.global_position.distance_squared_to((node as Node3D).global_position)
		if d <= best_dist_sq:
			best_dist_sq = d
			best = node as Node3D
	return best

func _target_still_valid() -> bool:
	return is_instance_valid(_target) and _target.is_inside_tree()

## Markiert ein Ziel als "von diesem Pet belegt" — verhindert, dass ein zweites
## Pet DESSELBEN Besitzers (auf demselben Peer) im selben Frame dasselbe Ziel
## anläuft. Wirkt nur lokal (Meta auf der lokalen Node-Kopie) — auf einem
## Nicht-Autoritäts-Peer sähe ein fremdes Pet dieses Meta nicht, siehe
## Klassenkommentar zur bekannten Reichweiten-Einschränkung für denselben
## strukturellen Grund (kein geteilter, replizierter "Claim"-Zustand).
func _claim_target(node: Node) -> void:
	if is_instance_valid(node):
		node.set_meta("pet_claimed", true)

func _unclaim_target() -> void:
	if is_instance_valid(_target):
		_target.remove_meta("pet_claimed")
	_target = null

func _reset_idle() -> void:
	_unclaim_target()
	_pet.release_movement(self)
	_state = State.IDLE
	_scan_cooldown = SCAN_INTERVAL
