class_name PetRestorer
extends RefCounted

## PetRestorer — Stellt gespeicherte Pets beim Laden der Welt wieder her.
##
## Ausgelagert aus WorldSpawner._restore_pets() (v28).
## Liest Pet-Daten aus WorldData.get_meta("saved_pets") und spawnt sie über
## EntityOrchestrator.spawn_entity("pet", ...) — nicht per direktem
## PetComponent.new() + add_child() (siehe AnimalCatcher für dieselbe
## Begründung: Replikation an andere Peers braucht die EntityRegistry-Definition).

const LOG_CAT := "PetRestorer"

var _data: WorldData
var _orchestrator: EntityOrchestrator

func _init(data: WorldData, orchestrator: EntityOrchestrator) -> void:
	_data = data
	_orchestrator = orchestrator

func restore(_world_root: Node3D) -> void:
	if not is_instance_valid(_data) or not _data.has_meta("saved_pets"):
		return
	var pet_data: Variant = _data.get_meta("saved_pets")
	if not pet_data is Array:
		return

	var restored := 0
	for entry in pet_data:
		if not entry is Dictionary:
			continue
		var pos: Variant = str_to_var(entry.get("pos", "Vector3(0,1,0)"))
		if not pos is Vector3:
			continue
		var col: Variant = str_to_var(entry.get("color", "Color(0.7,0.5,0.3,1)"))
		var config := {
			"name":          entry.get("name", "Pet"),
			"color":         col if col is Color else Color(0.7, 0.5, 0.3),
			# owner_peer_id fehlt in Saves von vor diesem Fix — Default 1 (Solo/Host),
			# kein Absturz, keine Fehl-Zuordnung an einen falschen Spieler.
			"owner_peer_id": entry.get("owner_peer_id", 1),
		}
		var pet := _orchestrator.spawn_entity("pet", pos, config, config["owner_peer_id"])
		if is_instance_valid(pet):
			restored += 1
		else:
			AppLogger.log_warn("Pet-Wiederherstellung fehlgeschlagen für Eintrag: %s" % str(entry), LOG_CAT)

	AppLogger.log_info("Pets wiederhergestellt: %d." % restored, LOG_CAT)
