class_name PetComponent
extends CharacterBody3D

## PetComponent — Ein Pet das seinem Besitzer folgt.
##
## Wird über EntityOrchestrator.spawn_entity("pet", pos, config, owner_peer_id)
## erzeugt — entweder beim Fangen eines Tieres (AnimalCatcher) oder beim
## Wiederherstellen eines Saves (PetRestorer). KEIN direktes PetComponent.new()
## + add_child() mehr (siehe AnimalCatcher/PetRestorer) — sonst fehlt die
## EntityRegistry-Registrierung, die der MultiplayerSpawner für Replikation an
## andere Peers braucht, und es gibt kein ctx für den EventBus.
##
## NICHT gepoolt (EntityOrchestrator._ready(): set_max_size_for("pet", 0)) —
## jedes Pet hat eine individuelle Identität (Name/Farbe/Besitzer), Pooling
## würde diese beim Wiederverwenden vermischen.

const LOG_CAT := "Pet"
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)

var _color:     Color   = Color(0.7, 0.5, 0.3)
var _body_size: Vector3 = Vector3(0.3, 0.4, 0.3)
var _name:      String  = "Pet"

var _follow_distance: float = 2.5
var _speed:           float = 4.0
var _idle_radius:     float = 1.5

## Kosmetische Silhouette, übernommen vom gefangenen Tier (siehe AnimalCatcher.catch_animal()) —
## BUGFIX ("Nach dem Fangen ist das ursprüngliche Modell weg"): ohne diese Felder baute
## _build_visuals() nur eine schlichte, kopf-/ohrenlose Kapsel. Defaults entsprechen
## AnimalVisualProfile's eigenen Defaults (generisches "Standardtier"), falls ein Pet ohne
## diese Config-Felder gespawnt wird (z.B. sehr alte Saves vor diesem Fix).
var _ear_style:      int   = AnimalVisualProfile.EarStyle.ROUND
var _tail_style:     int   = AnimalVisualProfile.TailStyle.STUB
var _snout_style:    int   = AnimalVisualProfile.SnoutStyle.SHORT
var _headgear_style: int   = AnimalVisualProfile.HeadgearStyle.NONE
var _tail_scale:     float = 1.0

## Peer-ID des Besitzers — das Pet folgt NUR diesem Spieler, nicht "irgendeinem"
## (relevant sobald mehrere Spieler eigene Pets haben). Default 1 (Solo/Host)
## für Saves ohne owner_peer_id (Alt-Feld, siehe get_save_state()).
var _owner_peer_id: int = 1

## Stabile player_id des Besitzers (SessionManager-UUID, NICHT die peer_id) —
## gebraucht von PetAbilityComponent für Aktionen, die eine player_id statt
## einer peer_id erwarten (aktuell nur Graben, siehe dortiges
## emit_terrain_edit_requested()). AnimalCatcher.catch_animal() liefert sie
## bereits im Spawn-Config mit ("owner_player_id", bisher nur für die
## deterministische Namensvergabe genutzt) — hier zusätzlich gespeichert statt
## bei jedem Grab-Versuch neu über NetworkBridge aufzulösen. Leerer String
## (alte Saves, Solo ohne NetworkBridge) wird in on_spawn() best-effort
## nachaufgelöst, siehe dort.
var _owner_player_id: String = ""

## Fähigkeiten dieses Pets (siehe PetAbilities-Konstanten) — bestimmt, welche
## PetAbilityComponent-Kinder _build_abilities() in on_spawn() erzeugt.
var _abilities: Array[String] = []

var _bus: IEventBus      = null
## Vollständiger Context (nicht nur der Bus) — PetAbilityComponent braucht
## get_world()/get_network_bridge() für die eigentlichen Fähigkeits-Aktionen.
var _ctx: IEntityContext = null

## Cache — wird über IEventBus.player() (player_died/player_respawned) aktuell
## gehalten, kein Polling im Physik-Frame.
var _player_ref: Node3D = null

# ─────────────────────────────────────────────
# Bewegungs-Arbitrierung für Fähigkeiten (siehe PetAbilityComponent)
# ─────────────────────────────────────────────
## null = normales Besitzer-Folgeverhalten. Sonst: die PetAbilityComponent,
## die gerade "das Steuer hält" — max. eine gleichzeitig, damit nicht zwei
## Fähigkeiten (z.B. Kampf + Graben auf demselben Eber) widersprüchliche
## velocity-Ziele in denselben Physik-Frame schreiben.
var _movement_owner:        Node    = null
var _movement_target:       Vector3 = Vector3.ZERO
var _movement_arrive_radius: float  = 1.0

## Fordert die Bewegungssteuerung für requester an. Gibt true zurück wenn
## requester ab jetzt (oder weiterhin) steuert, false wenn eine ANDERE
## Fähigkeit gerade hält (der Aufrufer muss dann warten/es später erneut
## versuchen). Ein erneuter Aufruf desselben requesters aktualisiert nur das
## Ziel (z.B. wenn ein Kampfziel sich bewegt).
func request_movement(requester: Node, target_pos: Vector3, arrive_radius: float) -> bool:
	if is_instance_valid(_movement_owner) and _movement_owner != requester:
		return false
	_movement_owner = requester
	_movement_target = target_pos
	_movement_arrive_radius = max(0.1, arrive_radius)
	return true

## Gibt die Steuerung frei, NUR wenn requester sie aktuell hält (kein
## Fremdeingriff möglich).
func release_movement(requester: Node) -> void:
	if _movement_owner == requester:
		_movement_owner = null

func is_movement_claimed_by(requester: Node) -> bool:
	return _movement_owner == requester

func has_arrived_at_movement_target() -> bool:
	return global_position.distance_to(_movement_target) <= _movement_arrive_radius

func has_ability(ability_id: String) -> bool:
	return _abilities.has(ability_id)

func _ready() -> void:
	add_to_group("pets")
	# FEATURE (2026-09-17, "Pets cross-peer sichtbar"): fehlte komplett — ohne
	# das hätten andere Peers zwar jetzt eine Kopie des Pets (siehe
	# NetworkBridge._rpc_spawn_remote_pet()), aber die würde nie ihre Position
	# aktualisieren, exakt dasselbe Muster wie bei AnimalBase (siehe dortiger
	# Kommentar für die volle Begründung). Pets sind CLIENT-autoritativ
	# (set_multiplayer_authority(_owner_peer_id) unten in on_spawn(), nicht
	# immer 1) — funktioniert mit MultiplayerSynchronizer genauso, die
	# Autorität ist einfach nicht immer der Server.
	_setup_multiplayer_sync()

func _setup_multiplayer_sync() -> void:
	var sync := MultiplayerSynchronizer.new()
	sync.name = "MultiplayerSync"
	sync.replication_interval = 0.1   # 10 Hz — wie AnimalBase/EnemyNPC
	add_child(sync)
	var config := SceneReplicationConfig.new()
	config.add_property(NodePath(".:position"))
	config.add_property(NodePath(".:rotation"))
	sync.replication_config = config
	AppLogger.log_debug("MultiplayerSynchronizer erstellt (position, rotation, 10Hz).", LOG_CAT)

## Aufgerufen von EntityOrchestrator NACH add_child() und NACH _ready().
## config: { "name": String, "color": Color, "body_size": Vector3,
##           "speed": float, "owner_peer_id": int }
func on_spawn(config: Dictionary = {}, ctx: IEntityContext = null) -> void:
	_name          = config.get("name", _name)
	_color         = config.get("color", _color)
	_body_size     = config.get("body_size", _body_size)
	_speed         = config.get("speed", _speed)
	_ear_style      = config.get("ear_style", _ear_style)
	_tail_style     = config.get("tail_style", _tail_style)
	_snout_style    = config.get("snout_style", _snout_style)
	_headgear_style = config.get("headgear_style", _headgear_style)
	_tail_scale     = config.get("tail_scale", _tail_scale)
	_owner_peer_id = config.get("owner_peer_id", 1)
	_owner_player_id = String(config.get("owner_player_id", _owner_player_id))
	# PetAbilities.sanitize() statt der rohen config-Liste: verwirft unbekannte
	# IDs (Tippfehler/altes Save nach Feature-Rollback) statt sie als Fähigkeit
	# zu akzeptieren, für die keine PetAbilityComponent je etwas tut.
	_abilities = PetAbilities.sanitize(config.get("abilities", []))

	set_multiplayer_authority(_owner_peer_id)

	_build_visuals()
	_build_collision()

	_ctx = ctx
	if is_instance_valid(ctx):
		_bus = ctx.get_event_bus()
	if is_instance_valid(_bus):
		_bus.player().player_died.connect(_on_player_died)
		_bus.player().player_respawned.connect(_on_player_respawned)
	else:
		AppLogger.log_warn(
			"Pet '%s': kein IEventBus im Context — reagiert nicht auf Tod/Respawn des Besitzers." % _name,
			LOG_CAT
		)

	# Best-effort Nachauflösung falls owner_player_id (noch) nicht mitgegeben
	# wurde (z.B. alte Saves von vor diesem Feld) — nötig für die
	# "digging"-Fähigkeit, siehe PetAbilityComponent._do_dig().
	if _owner_player_id.is_empty() and is_instance_valid(ctx):
		var network: NetworkBridge = ctx.get_network_bridge()
		if is_instance_valid(network):
			_owner_player_id = network.get_player_id_for_peer(_owner_peer_id)

	_build_abilities()

	_player_ref = _find_owner()
	AppLogger.log_debug(
		"Pet '%s' bereit (Besitzer: peer %d, Fähigkeiten: %s)." % [_name, _owner_peer_id, str(_abilities)],
		LOG_CAT
	)

## Erzeugt für jede Fähigkeit in _abilities eine eigene PetAbilityComponent
## (siehe dortiger Klassenkommentar zur Begründung: eine Komponente pro
## Fähigkeit statt einer einzigen Multi-Fähigkeit-Klasse, damit z.B. ein Eber
## Bergbau + Graben unabhängig voneinander verfolgen kann — Bewegungssteuerung
## wird trotzdem über request_movement()/release_movement() oben serialisiert).
## Pool-Reuse-Guard: alte Fähigkeits-Kinder zuerst entfernen (Pets sind zwar
## laut Klassenkommentar NICHT gepoolt, aber on_spawn() kann bei einem
## Hot-Reload-Pfad theoretisch erneut laufen — kein Risiko, doppelte Kinder
## zu akkumulieren einzugehen).
func _build_abilities() -> void:
	for child in get_children():
		if child is PetAbilityComponent:
			remove_child(child)
			child.queue_free()
	for ability_id in _abilities:
		var comp := PetAbilityComponent.new()
		comp.name = "Ability_%s" % ability_id
		comp.ability_id = ability_id
		add_child(comp)
		comp.setup(self, _ctx, _bus, _owner_peer_id, _owner_player_id)

func on_despawn() -> void:
	if is_instance_valid(_bus):
		if _bus.player().player_died.is_connected(_on_player_died):
			_bus.player().player_died.disconnect(_on_player_died)
		if _bus.player().player_respawned.is_connected(_on_player_respawned):
			_bus.player().player_respawned.disconnect(_on_player_respawned)

func _on_player_died() -> void:
	_player_ref = null

func _on_player_respawned() -> void:
	_player_ref = _find_owner()

## Sucht den Spieler-Node mit owner_peer_id-Meta == _owner_peer_id — NICHT
## einfach "den ersten Spieler in der Gruppe". Damit läuft in Multiplayer mit
## mehreren Pets jedes seinem eigenen Besitzer hinterher statt alle demselben
## (meist zufällig zuerst gefundenen) Spieler.
##
## Meta statt get_multiplayer_authority(): "wem gehört das Player-Node" und
## "wer ist Netzwerk-Autorität darüber" sind zwei verschiedene Fragen, die
## bisher nur zufällig übereinstimmten. Seit ADR-025 (Autorität = Server für
## Player-Nodes) gilt das nicht mehr, siehe TODO "BLOCKER für
## ADR-025/026-Umsetzung". Pets selbst sind von ADR-025 nicht betroffen —
## nur die Suche nach ihrem Besitzer-Player war über denselben Umweg gebaut.
func _find_owner() -> Node3D:
	for p in get_tree().get_nodes_in_group("player"):
		if p is Node3D and p.get_meta("owner_peer_id", 1) == _owner_peer_id:
			return p as Node3D
	# Fallback für Solo/Host: bei genau einem Spieler in der Gruppe ist die
	# Authority-Prüfung ohnehin eindeutig — greift nur falls sie aus irgendeinem
	# Grund nicht matcht (z.B. Timing beim Session-Start).
	return get_tree().get_first_node_in_group("player") as Node3D

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0

	# Solange eine PetAbilityComponent die Steuerung hält (Sammeln/Kämpfen/
	# Graben — siehe request_movement()), läuft das Pet dorthin statt dem
	# Besitzer hinterher. Gibt die Komponente frei (release_movement()),
	# übernimmt ab dem nächsten Frame automatisch wieder das Folgeverhalten.
	if is_instance_valid(_movement_owner):
		_steer_toward(_movement_target, delta, _movement_arrive_radius)
	else:
		var player := _player_ref
		if is_instance_valid(player):
			_steer_toward(player.global_position, delta, _follow_distance)

	move_and_slide()

## Gemeinsame Bewegungs-/Ausrichtungslogik für Besitzer-Folgeverhalten UND
## Fähigkeits-Steuerung (siehe _physics_process() oben) — vorher direkt im
## Besitzer-Folge-Zweig dupliziert, jetzt einmalig mit variablem stop_distance
## (== _follow_distance beim Folgen, == PetAbilityComponent.arrive_radius bei
## einer aktiven Fähigkeit).
func _steer_toward(target_pos: Vector3, delta: float, stop_distance: float) -> void:
	var dist := global_position.distance_to(target_pos)
	if dist > stop_distance:
		var dir: Vector3 = target_pos - global_position
		dir.y = 0.0
		if dir.length_squared() > 0.01:
			dir = dir.normalized()
			var t: float = min(1.0, (dist - stop_distance) / 3.0)
			var spd: float = _speed * t
			velocity.x = move_toward(velocity.x, dir.x * spd, 12.0 * delta)
			velocity.z = move_toward(velocity.z, dir.z * spd, 12.0 * delta)
			# BUGFIX ("Tiere/Pets laufen mit dem Schwanz voraus"): siehe identischer
			# Fix + Begründung in AnimalBase._move_toward(). Pet-Körper ist zwar nur
			# eine einfache Kapsel ohne sichtbaren Kopf, übernimmt aber dieselbe
			# +Z-vorne-Konvention — betrifft z.B. das Label3D mit dem Pet-Namen.
			look_at(global_position - dir, Vector3.UP)
	else:
		velocity.x = move_toward(velocity.x, 0.0, 6.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, 6.0 * delta)

func get_save_state() -> Dictionary:
	return {
		"pos":           var_to_str(global_position),
		"color":         var_to_str(_color),
		# BUGFIX ("Pets verlieren nach Save/Load ihr Modell", schrumpfen zu kleinen
		# Kugeln): body_size/speed fehlten hier komplett — on_spawn() bekam beim
		# Wiederherstellen dadurch nie die tatsächliche Größe des gefangenen Tieres
		# (siehe AnimalCatcher.catch_animal()'s config), sondern immer nur den
		# winzigen PetComponent-Klassen-Default Vector3(0.3, 0.4, 0.3).
		"body_size":     var_to_str(_body_size),
		"speed":         _speed,
		# BUGFIX ("Nach dem Fangen ist das ursprüngliche Modell weg" / Save-Reload):
		# ohne diese Felder verlor ein Pet seine Silhouette auch bei jedem Neuladen wieder,
		# selbst nachdem sie beim Fangen selbst schon korrekt übernommen wurde.
		"ear_style":      _ear_style,
		"tail_style":     _tail_style,
		"snout_style":    _snout_style,
		"headgear_style": _headgear_style,
		"tail_scale":     _tail_scale,
		"name":          _name,
		"owner_peer_id": _owner_peer_id,
		"owner_player_id": _owner_player_id,
		# FEATURE (Pet-Fähigkeiten): ohne dieses Feld würde ein Pet beim
		# nächsten Laden auf PetRestorer.gd's Default zurückfallen (siehe
		# dort) statt die tatsächlich zugewiesenen Fähigkeiten zu behalten —
		# relevant sobald Fähigkeiten künftig mal umverteilbar werden.
		"abilities":     _abilities,
	}

## BUGFIX ("Nach dem Fangen ist das ursprüngliche Modell weg"): baute bisher nur eine
## schlichte, kopf-/ohren-/schwanzlose Kapsel aus _color/_body_size — das gefangene Tier sah
## als Pet komplett anders aus. Jetzt: dieselbe AnimalVisualBuilder-Geometrie wie AnimalBase,
## mit dem vom Tier übernommenen Silhouette-Profil (siehe _ear_style/_tail_style/etc. und
## AnimalCatcher.catch_animal()). _build_collision() bleibt unverändert auf _body_size
## basiert — Kollisionsform ist bewusst von der Kosmetik getrennt, siehe AnimalBase-Vorbild.
func _build_visuals() -> void:
	var profile := AnimalVisualProfile.new(_color, _body_size)
	profile.ear_style      = _ear_style
	profile.tail_style     = _tail_style
	profile.snout_style    = _snout_style
	profile.headgear_style = _headgear_style
	profile.tail_scale     = _tail_scale
	add_child(AnimalVisualBuilder.build(profile))

	var lbl := Label3D.new()
	lbl.text = _name
	lbl.font_size = 36
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(0.6, 1.0, 0.6)
	# Etwas höher als vorher (war auf die alte, kopflose Kapsel abgestimmt) — muss jetzt
	# über dem Kopf schweben, nicht nur über dem Rumpf.
	lbl.position.y = _body_size.y * 1.6
	add_child(lbl)

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh := CapsuleShape3D.new()
	sh.radius = _body_size.x * 0.4
	sh.height = _body_size.y
	col.shape = sh
	col.position.y = _body_size.y * 0.5
	add_child(col)
