class_name PetComponent
extends CharacterBody3D

## PetComponent — Ein Pet das seinem Besitzer folgt.
##
## Wird über EntityOrchestrator.spawn_entity("pet", pos, config, owner_peer_id)
## erzeugt — entweder beim Fangen eines Tieres (AnimalCatcher) oder beim
## Wiederherstellen eines Saves (PetRestorer). KEIN direktes PetComponent.new()
## + add_child() mehr (siehe AnimalCatcher/PetRestorer) — sonst fehlt die
## EntityRegistry-Registrierung, die der MultiplayerSpawner für Replikation an
## andere Peers braucht, und es gibt kein ctx für den EventBus.
##
## NICHT gepoolt (EntityOrchestrator._ready(): set_max_size_for("pet", 0)) —
## jedes Pet hat eine individuelle Identität (Name/Farbe/Besitzer), Pooling
## würde diese beim Wiederverwenden vermischen.

const LOG_CAT := "Pet"
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)

var _color:     Color   = Color(0.7, 0.5, 0.3)
var _body_size: Vector3 = Vector3(0.3, 0.4, 0.3)
var _name:      String  = "Pet"

var _follow_distance: float = 2.5
var _speed:           float = 4.0
var _idle_radius:     float = 1.5

## Peer-ID des Besitzers — das Pet folgt NUR diesem Spieler, nicht "irgendeinem"
## (relevant sobald mehrere Spieler eigene Pets haben). Default 1 (Solo/Host)
## für Saves ohne owner_peer_id (Alt-Feld, siehe get_save_state()).
var _owner_peer_id: int = 1

var _bus: IEventBus = null

## Cache — wird über IEventBus.player() (player_died/player_respawned) aktuell
## gehalten, kein Polling im Physik-Frame.
var _player_ref: Node3D = null

func _ready() -> void:
	add_to_group("pets")
	# FEATURE (2026-09-17, "Pets cross-peer sichtbar"): fehlte komplett — ohne
	# das hätten andere Peers zwar jetzt eine Kopie des Pets (siehe
	# NetworkBridge._rpc_spawn_remote_pet()), aber die würde nie ihre Position
	# aktualisieren, exakt dasselbe Muster wie bei AnimalBase (siehe dortiger
	# Kommentar für die volle Begründung). Pets sind CLIENT-autoritativ
	# (set_multiplayer_authority(_owner_peer_id) unten in on_spawn(), nicht
	# immer 1) — funktioniert mit MultiplayerSynchronizer genauso, die
	# Autorität ist einfach nicht immer der Server.
	_setup_multiplayer_sync()

func _setup_multiplayer_sync() -> void:
	var sync := MultiplayerSynchronizer.new()
	sync.name = "MultiplayerSync"
	sync.replication_interval = 0.1   # 10 Hz — wie AnimalBase/EnemyNPC
	add_child(sync)
	var config := SceneReplicationConfig.new()
	config.add_property(NodePath(".:position"))
	config.add_property(NodePath(".:rotation"))
	sync.replication_config = config
	AppLogger.log_debug("MultiplayerSynchronizer erstellt (position, rotation, 10Hz).", LOG_CAT)

## Aufgerufen von EntityOrchestrator NACH add_child() und NACH _ready().
## config: { "name": String, "color": Color, "body_size": Vector3,
##           "speed": float, "owner_peer_id": int }
func on_spawn(config: Dictionary = {}, ctx: IEntityContext = null) -> void:
	_name          = config.get("name", _name)
	_color         = config.get("color", _color)
	_body_size     = config.get("body_size", _body_size)
	_speed         = config.get("speed", _speed)
	_owner_peer_id = config.get("owner_peer_id", 1)

	set_multiplayer_authority(_owner_peer_id)

	_build_visuals()
	_build_collision()

	if is_instance_valid(ctx):
		_bus = ctx.get_event_bus()
	if is_instance_valid(_bus):
		_bus.player().player_died.connect(_on_player_died)
		_bus.player().player_respawned.connect(_on_player_respawned)
	else:
		AppLogger.log_warn(
			"Pet '%s': kein IEventBus im Context — reagiert nicht auf Tod/Respawn des Besitzers." % _name,
			LOG_CAT
		)

	_player_ref = _find_owner()
	AppLogger.log_debug("Pet '%s' bereit (Besitzer: peer %d)." % [_name, _owner_peer_id], LOG_CAT)

func on_despawn() -> void:
	if is_instance_valid(_bus):
		if _bus.player().player_died.is_connected(_on_player_died):
			_bus.player().player_died.disconnect(_on_player_died)
		if _bus.player().player_respawned.is_connected(_on_player_respawned):
			_bus.player().player_respawned.disconnect(_on_player_respawned)

func _on_player_died() -> void:
	_player_ref = null

func _on_player_respawned() -> void:
	_player_ref = _find_owner()

## Sucht den Spieler-Node mit owner_peer_id-Meta == _owner_peer_id — NICHT
## einfach "den ersten Spieler in der Gruppe". Damit läuft in Multiplayer mit
## mehreren Pets jedes seinem eigenen Besitzer hinterher statt alle demselben
## (meist zufällig zuerst gefundenen) Spieler.
##
## Meta statt get_multiplayer_authority(): "wem gehört das Player-Node" und
## "wer ist Netzwerk-Autorität darüber" sind zwei verschiedene Fragen, die
## bisher nur zufällig übereinstimmten. Seit ADR-025 (Autorität = Server für
## Player-Nodes) gilt das nicht mehr, siehe TODO "BLOCKER für
## ADR-025/026-Umsetzung". Pets selbst sind von ADR-025 nicht betroffen —
## nur die Suche nach ihrem Besitzer-Player war über denselben Umweg gebaut.
func _find_owner() -> Node3D:
	for p in get_tree().get_nodes_in_group("player"):
		if p is Node3D and p.get_meta("owner_peer_id", 1) == _owner_peer_id:
			return p as Node3D
	# Fallback für Solo/Host: bei genau einem Spieler in der Gruppe ist die
	# Authority-Prüfung ohnehin eindeutig — greift nur falls sie aus irgendeinem
	# Grund nicht matcht (z.B. Timing beim Session-Start).
	return get_tree().get_first_node_in_group("player") as Node3D

func _physics_process(delta: float) -> void:
	if not is_multiplayer_authority():
		return
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0

	var player := _player_ref
	if is_instance_valid(player):
		var dist := global_position.distance_to(player.global_position)
		if dist > _follow_distance:
			var dir: Vector3 = player.global_position - global_position
			dir.y = 0.0
			if dir.length_squared() > 0.01:
				dir = dir.normalized()
				var t: float = min(1.0, (dist - _follow_distance) / 3.0)
				var spd: float = _speed * t
				velocity.x = move_toward(velocity.x, dir.x * spd, 12.0 * delta)
				velocity.z = move_toward(velocity.z, dir.z * spd, 12.0 * delta)
				look_at(global_position + dir, Vector3.UP)
		else:
			velocity.x = move_toward(velocity.x, 0.0, 6.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 6.0 * delta)

	move_and_slide()

func get_save_state() -> Dictionary:
	return {
		"pos":           var_to_str(global_position),
		"color":         var_to_str(_color),
		"name":          _name,
		"owner_peer_id": _owner_peer_id,
	}

func _build_visuals() -> void:
	var bm := ProcGenShapes.capsule(_body_size.x * 0.5, _body_size.y)
	add_child(ProcGenShapes.mi(bm, ProcGenShapes.mat(_color), Vector3(0.0, _body_size.y * 0.5, 0.0), "Body"))

	var lbl := Label3D.new()
	lbl.text = _name
	lbl.font_size = 36
	lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	lbl.modulate = Color(0.6, 1.0, 0.6)
	lbl.position.y = _body_size.y * 1.3
	add_child(lbl)

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh := CapsuleShape3D.new()
	sh.radius = _body_size.x * 0.4
	sh.height = _body_size.y
	col.shape = sh
	col.position.y = _body_size.y * 0.5
	add_child(col)
