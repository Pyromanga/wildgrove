class_name AnimalVisualBuilder
extends RefCounted

## AnimalVisualBuilder — Baut die prozedurale Tier-Geometrie.
##
## Erweitert aus dem ursprünglichen "Kapsel-Körper + Kugelkopf + 4 Zylinder-Beine" für
## ALLE Tierarten identisch (siehe AnimalVisualProfile-Klassenkommentar für die Motivation).
## Stateless — keine Member-Variablen.
##
## Primitive-Erzeugung (Mesh/Material/MeshInstance3D) kommt aus ProcGenShapes — gemeinsame
## Basis mit CharacterPartBuilder/NPCVisualBuilder, damit hier keine eigene Kopie von
## "Kugel/Kapsel/Box/Zylinder + Material" mehr nötig ist (Wunsch "gemeinsame Basis finden,
## damit nicht alles neu erfunden werden muss"). Das Bausystem (BuildPieceDefinition) bleibt
## bewusst eine eigene, andere Technik (SurfaceTool-Dreiecksnetze für Wände/Dächer) — dafür
## taugen Godots Primitive-Meshes nicht, siehe ProcGenShapes-Klassenkommentar.
##
## KOORDINATEN: root-lokal, Füße bei y=0, +Z = "vorne" (Kopf/Schnauze-Richtung; AnimalBase
## dreht via look_at() in die tatsächliche Laufrichtung). Rumpf liegt entlang Z (liegende
## Kapsel), nicht wie ursprünglich stehend — siehe build()-Kommentar bei body_node.

## Anteil von body_size.y, an dem die Bein-MITTE sitzt bzw. an dem die Beinoberkante liegt
## (Bein-Zylinderhöhe = body_size.y * LEG_HEIGHT_RATIO, siehe _add_legs()) — beide Werte
## teilen sich dieselben Konstanten, damit Beinoberkante und Rumpfunterkante ohne Lücke
## aneinander anschließen.
const LEG_OFFSET_Y_RATIO: float = 0.27
const LEG_HEIGHT_RATIO: float = 0.55
const LEG_TOP_RATIO: float = LEG_OFFSET_Y_RATIO + LEG_HEIGHT_RATIO * 0.5

const BODY_RADIUS_RATIO: float = 0.42
## Staucht die Rumpfhöhe (vertikal) gegenüber der Breite/Tiefe — ein reiner Kreisquerschnitt
## (unskaliert) wirkt zu wurstförmig/aufgeblasen, siehe build().
const BODY_VERTICAL_SQUASH: float = 0.82
const HEAD_RADIUS_RATIO: float = 0.40

## Baut Rumpf + Kopf (mit Augen/Schnauze/Ohren/Kopfschmuck je Profil) + 4 Beine + optionalem
## Schwanz. Gibt einen Node3D ("Visuals") zurück, der direkt per add_child() an das Tier
## gehängt werden kann.
static func build(profile: AnimalVisualProfile) -> Node3D:
	var root := Node3D.new()
	root.name = "Visuals"

	var bs: Vector3 = profile.body_size
	var color: Color = profile.color
	var body_mat := ProcGenShapes.mat(color)
	var head_mat := ProcGenShapes.mat(color.lightened(0.1))
	var leg_mat := ProcGenShapes.mat(color.darkened(0.2))
	# Für Nase/Nasenspitze/Hufansatz — ein deutlich dunklerer Akzent, unabhängig von der
	# eigentlichen Fellfarbe des Tieres (reale Tiere haben fast immer eine dunkle Nase,
	# unabhängig vom Fellton).
	var accent_mat := ProcGenShapes.mat(color.darkened(0.55), 0.7)

	_add_legs(root, leg_mat, bs)

	var leg_top: float = bs.y * LEG_TOP_RATIO
	var body_radius: float = bs.x * BODY_RADIUS_RATIO
	# Körperlänge (Nase-Schwanz-Richtung): body_size.z war bisher nur der Bein-Z-Versatz,
	# nie eine echte Rumpflänge (der alte Rumpf war eine STEHENDE Kapsel ohne Länge). Hier
	# wird z zusätzlich als Längenfaktor benutzt, ohne dass Unterklassen ihre body_size
	# ändern müssen — ein Vielfaches von z ergibt einen plausibel länglichen statt runden
	# Rumpf, größere Tiere (großes z) werden automatisch proportional länger.
	var body_length: float = maxf(bs.z * 2.2, body_radius * 2.0 + 0.1)
	var body_center_y: float = leg_top + body_radius * BODY_VERTICAL_SQUASH * 0.85

	var body_node := ProcGenShapes.mi(
		ProcGenShapes.capsule(body_radius, body_length), body_mat, Vector3(0.0, body_center_y, 0.0), "Body"
	)
	# CapsuleMesh liegt standardmäßig AUFRECHT (Länge entlang lokal Y) — das war exakt das
	# Problem des alten Modells ("stehende Pille" statt Tierkörper). 90°-Drehung um X legt
	# die Länge auf die Z-Achse (vorne/hinten); scale.z (= die ehemalige Mesh-Y-Achse vor der
	# Drehung, landet nach der Drehung auf der vertikalen Weltachse) staucht danach die
	# Rumpfhöhe leicht — siehe BODY_VERTICAL_SQUASH.
	body_node.rotation.x = PI * 0.5
	body_node.scale = Vector3(1.0, 1.0, BODY_VERTICAL_SQUASH)
	root.add_child(body_node)

	var head_r: float = bs.x * HEAD_RADIUS_RATIO
	var head := Node3D.new()
	head.name = "Head"
	head.position = Vector3(0.0, body_center_y + head_r * 0.35, body_length * 0.5 - head_r * 0.2)
	root.add_child(head)
	head.add_child(ProcGenShapes.mi(ProcGenShapes.sphere(head_r), head_mat, Vector3.ZERO, "Skull"))

	_add_eyes(head, head_r)
	_add_snout(head, profile, head_r, head_mat, accent_mat)
	_add_ears(head, profile, head_r, head_mat)
	_add_headgear(head, profile, head_r)
	_add_tail(root, profile, leg_mat, body_center_y, body_length, body_radius)

	return root

# ─────────────────────────────────────────────
# Beine
# ─────────────────────────────────────────────

static func _add_legs(root: Node3D, leg_mat: Material, bs: Vector3) -> void:
	# Eine Mesh-Resource für alle vier Beine geteilt (identische Geometrie) — die vier
	# MeshInstance3D-Knoten unterscheiden sich nur in Position/Name, nicht in der Form.
	var mesh := ProcGenShapes.cylinder(bs.x * 0.085, bs.x * 0.065, bs.y * LEG_HEIGHT_RATIO)
	var offsets: Array[Vector3] = [
		Vector3(-bs.x * 0.3, 0.0, -bs.z * 0.22),
		Vector3( bs.x * 0.3, 0.0, -bs.z * 0.22),
		Vector3(-bs.x * 0.3, 0.0,  bs.z * 0.22),
		Vector3( bs.x * 0.3, 0.0,  bs.z * 0.22),
	]
	var names: Array[String] = ["LegFL", "LegFR", "LegBL", "LegBR"]
	for i in offsets.size():
		var pos: Vector3 = offsets[i] + Vector3(0.0, bs.y * LEG_OFFSET_Y_RATIO, 0.0)
		root.add_child(ProcGenShapes.mi(mesh, leg_mat, pos, names[i]))

# ─────────────────────────────────────────────
# Gesicht (Kind der "Head"-Gruppe, lokal relativ zu deren Ursprung = Kopfmitte)
# ─────────────────────────────────────────────

static func _add_eyes(head: Node3D, head_r: float) -> void:
	var eye_mat := ProcGenShapes.mat(Color(0.05, 0.05, 0.06), 0.25)
	var eye_mesh := ProcGenShapes.sphere(head_r * 0.13)
	for side in [1.0, -1.0]:
		var eye := ProcGenShapes.mi(eye_mesh, eye_mat, Vector3.ZERO, "EyeR" if side > 0.0 else "EyeL")
		ProcGenShapes.place_on_sphere(eye, head_r, side * head_r * 0.62, head_r * 0.10, head_r * 0.06, Vector3(1.0, 1.0, 0.6))
		head.add_child(eye)

static func _add_snout(head: Node3D, profile: AnimalVisualProfile, head_r: float, head_mat: Material, accent_mat: Material) -> void:
	match profile.snout_style:
		AnimalVisualProfile.SnoutStyle.SHORT:
			var nose := ProcGenShapes.mi(ProcGenShapes.sphere(head_r * 0.22), accent_mat, Vector3.ZERO, "Nose")
			ProcGenShapes.place_on_sphere(nose, head_r, 0.0, -head_r * 0.15, head_r * 0.30, Vector3(1.0, 0.8, 0.7))
			head.add_child(nose)
		AnimalVisualProfile.SnoutStyle.LONG:
			# Schnauze setzt bewusst weit INNERHALB der Schädelkugel an (anchor nahe am
			# Zentrum statt exakt auf der Oberfläche) — sonst entstünde eine sichtbare
			# Nahtlücke zwischen Kugel und Kapsel, da ProcGenShapes.spike() vom Ansatzpunkt
			# aus gerade nach `dir` weiterbaut statt sich der Kugelkrümmung anzuschmiegen.
			var muzzle_dir := Vector3(0.0, -0.12, 1.0).normalized()
			var muzzle_len := head_r * 0.85
			var anchor := Vector3(0.0, -head_r * 0.08, head_r * 0.35)
			head.add_child(ProcGenShapes.spike(
				ProcGenShapes.capsule(head_r * 0.26, muzzle_len), head_mat, anchor, muzzle_dir, muzzle_len, "Muzzle"
			))
			var nose := ProcGenShapes.mi(ProcGenShapes.sphere(head_r * 0.16), accent_mat, anchor + muzzle_dir * muzzle_len, "Nose")
			head.add_child(nose)
		_:
			pass

static func _add_ears(head: Node3D, profile: AnimalVisualProfile, head_r: float, head_mat: Material) -> void:
	match profile.ear_style:
		AnimalVisualProfile.EarStyle.ROUND:
			var mesh := ProcGenShapes.sphere(head_r * 0.30)
			for side in [1.0, -1.0]:
				var ear := ProcGenShapes.mi(mesh, head_mat, Vector3.ZERO, "EarR" if side > 0.0 else "EarL")
				ProcGenShapes.place_on_sphere(ear, head_r, side * head_r * 0.62, head_r * 0.58, head_r * 0.05, Vector3(0.65, 1.0, 0.5))
				head.add_child(ear)
		AnimalVisualProfile.EarStyle.POINTY:
			var mesh := ProcGenShapes.cone(head_r * 0.20, head_r * 0.6)
			for side in [1.0, -1.0]:
				var anchor := Vector3(side * head_r * 0.42, head_r * 0.45, -head_r * 0.05)
				var dir := Vector3(side * 0.45, 1.0, -0.15).normalized()
				head.add_child(ProcGenShapes.spike(mesh, head_mat, anchor, dir, head_r * 0.6, "EarR" if side > 0.0 else "EarL"))
		AnimalVisualProfile.EarStyle.LONG:
			var mesh := ProcGenShapes.capsule(head_r * 0.14, head_r * 1.7)
			for side in [1.0, -1.0]:
				var anchor := Vector3(side * head_r * 0.30, head_r * 0.45, -head_r * 0.05)
				var dir := Vector3(side * 0.16, 1.0, -0.05).normalized()
				head.add_child(ProcGenShapes.spike(mesh, head_mat, anchor, dir, head_r * 1.7, "EarR" if side > 0.0 else "EarL"))
		AnimalVisualProfile.EarStyle.FLOPPY:
			var mesh := ProcGenShapes.capsule(head_r * 0.17, head_r * 0.95)
			for side in [1.0, -1.0]:
				var anchor := Vector3(side * head_r * 0.68, head_r * 0.15, 0.0)
				var dir := Vector3(side * 0.35, -1.0, 0.1).normalized()
				head.add_child(ProcGenShapes.spike(mesh, head_mat, anchor, dir, head_r * 0.95, "EarR" if side > 0.0 else "EarL"))
		_:
			pass

## Geweih (Reh) bzw. Hauer (Wildschwein) — bewusst NICHT von der Fellfarbe abgeleitet
## (Knochen-/Elfenbeinfarbe ist unabhängig vom Fell), siehe jeweilige Konstante unten.
static func _add_headgear(head: Node3D, profile: AnimalVisualProfile, head_r: float) -> void:
	match profile.headgear_style:
		AnimalVisualProfile.HeadgearStyle.ANTLERS:
			var antler_mat := ProcGenShapes.mat(Color(0.55, 0.45, 0.33), 0.9)
			var beam_mesh := ProcGenShapes.cylinder(head_r * 0.045, head_r * 0.09, head_r * 1.3)
			var tine_mesh := ProcGenShapes.cone(head_r * 0.05, head_r * 0.45)
			for side in [1.0, -1.0]:
				var anchor := Vector3(side * head_r * 0.32, head_r * 0.5, -head_r * 0.1)
				var beam_dir := Vector3(side * 0.25, 1.0, -0.3).normalized()
				var beam_name := "AntlerR" if side > 0.0 else "AntlerL"
				head.add_child(ProcGenShapes.spike(beam_mesh, antler_mat, anchor, beam_dir, head_r * 1.3, beam_name))
				var tine_anchor: Vector3 = anchor + beam_dir * (head_r * 1.3 * 0.55)
				var tine_dir := (beam_dir + Vector3(side * 0.7, 0.25, -0.15)).normalized()
				head.add_child(ProcGenShapes.spike(tine_mesh, antler_mat, tine_anchor, tine_dir, head_r * 0.45, beam_name + "Tine"))
		AnimalVisualProfile.HeadgearStyle.TUSKS:
			var tusk_mat := ProcGenShapes.mat(Color(0.92, 0.90, 0.82), 0.4)
			var mesh := ProcGenShapes.cone(head_r * 0.09, head_r * 0.35)
			for side in [1.0, -1.0]:
				var anchor := Vector3(side * head_r * 0.30, -head_r * 0.25, head_r * 0.65)
				var dir := Vector3(side * 0.5, 0.7, 0.3).normalized()
				head.add_child(ProcGenShapes.spike(mesh, tusk_mat, anchor, dir, head_r * 0.35, "TuskR" if side > 0.0 else "TuskL"))
		_:
			pass

# ─────────────────────────────────────────────
# Schwanz (Kind von root, am Rumpf-Heck)
# ─────────────────────────────────────────────

static func _add_tail(
	root: Node3D, profile: AnimalVisualProfile, leg_mat: Material,
	body_center_y: float, body_length: float, body_radius: float
) -> void:
	var scale: float = profile.tail_scale
	# Ansatzpunkt liegt absichtlich etwas INNERHALB der hinteren Rumpfkuppe (0.7 statt 1.0),
	# damit Schwanz und Rumpf ohne sichtbare Naht ineinander übergehen — gleiches Prinzip
	# wie beim Schnauzenansatz in _add_snout().
	var anchor := Vector3(0.0, body_center_y, -body_length * 0.5 * 0.7)
	match profile.tail_style:
		AnimalVisualProfile.TailStyle.STUB:
			var length: float = body_radius * 0.6 * scale
			var mesh := ProcGenShapes.capsule(body_radius * 0.22 * scale, length)
			var dir := Vector3(0.0, 0.35, -1.0).normalized()
			root.add_child(ProcGenShapes.spike(mesh, leg_mat, anchor, dir, length, "Tail"))
		AnimalVisualProfile.TailStyle.BUSHY:
			var length: float = body_radius * 1.3 * scale
			var mesh := ProcGenShapes.cone(body_radius * 0.34 * scale, length)
			var dir := Vector3(0.0, 0.55, -1.0).normalized()
			root.add_child(ProcGenShapes.spike(mesh, leg_mat, anchor, dir, length, "Tail"))
		AnimalVisualProfile.TailStyle.FLUFFY:
			# Kein spike() nötig (Kugel ist richtungslos symmetrisch) — reine
			# "Puschelschwanz"-Optik, bewusst naturfarben statt fellfarbig (siehe
			# Klassenkommentar von _add_headgear() für dasselbe Prinzip bei Hörnern).
			var puff_mat := ProcGenShapes.mat(Color(0.95, 0.95, 0.92), 0.7)
			var pos: Vector3 = anchor + Vector3(0.0, body_radius * 0.15, -body_radius * 0.35) * scale
			root.add_child(ProcGenShapes.mi(ProcGenShapes.sphere(body_radius * 0.30 * scale), puff_mat, pos, "Tail"))
		_:
			pass
