# res://scripts/economy/inventory/ItemDefinition.gd
class_name ItemDefinition extends Resource

@export var id: String = ""
@export var display_name: String = ""
@export var icon: Texture2D
@export var max_stack: int = 99
## Verkaufspreis beim Shop-NPC (Gold pro Stück). 0 = ShopService fällt auf
## DEFAULT_SELL_PRICE zurück (siehe dort) statt das Item unverkäuflich zu machen.
@export var sell_price: int = 0

## ADR-038: "" = normales Item (Standardfall). Für Schutz-Scrolls einer der
## ItemProtectionService.TYPE_*-Werte ("pve"/"theft"/"pvp") — bestimmt, WELCHEN
## Schutz das Scroll gewährt, wenn es über request_apply_protection() auf ein
## Ziel-Item angewendet wird. Bewusst auf dem Item selbst (nicht am Aufrufer)
## definiert: ItemProtectionService liest DIESES Feld serverseitig vom
## scroll_item_id aus der ItemDefinition, statt dem Client zu vertrauen, WELCHEN
## protection_type ein Scroll gewährt — ein Client könnte sonst ein billiges
## Scroll mit einem selbstgewählten protection_type="pvp" einreichen.
@export var grants_protection_type: String = ""

## ADR-039: "" = normales Item (Standardfall). Für Diebstahl-Kristalle einer
## der PickpocketService.TIER_*-Werte ("weak"/"normal"/"strong") — bestimmt
## Cooldown UND Erfolgschance-Bonus, wenn dieses Item bei einem
## Pickpocket-Versuch verbraucht wird. Serverseitig aus der ItemDefinition
## gelesen (nicht vom Client übermittelt) — exakt dieselbe
## Fälschungs-Vermeidung wie bei ItemDefinition.grants_protection_type
## (ADR-038): ein Client könnte sonst einen billigen Kristall mit
## selbstgewähltem Tier="strong" einreichen.
@export var pickpocket_crystal_tier: String = ""
