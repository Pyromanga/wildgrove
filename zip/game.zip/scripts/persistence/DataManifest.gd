class_name DataManifest

## DataManifest — Explizite Liste aller statischen Ressourcen-Pfade.
##
## WARUM: DirAccess.open("res://...") funktioniert auf Android nicht —
## Godot-PCK-Archive erlauben keine Verzeichnisauflistung zur Laufzeit.
## Außerdem erkennt der Godot-Exporter mit export_filter="all_resources"
## nur Ressourcen die im SceneTree oder via preload() referenziert sind.
## Ressourcen die nur per DirAccess-Scan geladen werden, landen NICHT im APK.
##
## LÖSUNG: Alle Pfade hier als Konstanten auflisten.
##   - Der Exporter sieht die String-Literals und packt die Dateien ein.
##   - DataService nutzt diese Listen statt DirAccess.
##   - Neue Items/Quests: Pfad hier ergänzen → automatisch exportiert.

const ITEMS: Array[String] = [
	"res://data/items/LogNormal.tres",
	"res://data/items/LogOak.tres",
	"res://data/items/LogMaple.tres",
	"res://data/items/LogWillow.tres",
	"res://data/items/IronOre.tres",
	"res://data/items/CopperOre.tres",
	# Goblin-Drop Items
	"res://data/items/GoblinEar.tres",
	"res://data/items/weapons/PoisonDagger.tres",
	# Skeleton-Drop Items
	"res://data/items/BoneFragment.tres",
	# Cactus-Drop Items (Round 76)
	"res://data/items/CactusFiber.tres",
	# PineTree-/IceCrystal-Drop Items (Round 77)
	"res://data/items/LogPine.tres",
	"res://data/items/IceCrystalShard.tres",
	# RockBoulder-Drop Item (Round 78)
	"res://data/items/Stone.tres",
	# MushroomCluster-Drop Item (Round 79) — FallenTree nutzt log_normal (bereits oben registriert)
	"res://data/items/WildMushroom.tres",
	# Fern-Drop Item (Fern-Rollout)
	"res://data/items/FernFiber.tres",
	# Gathering-Werkzeuge (Shop-Kauf, Round 88): +50% Abbaugeschwindigkeit
	"res://data/items/tools/WoodAxe.tres",
	"res://data/items/tools/Pickaxe.tres",
	# ADR-038: Item-Schutz-Dreiklang — drei Schutz-Scrolls
	"res://data/items/ScrollPveProtection.tres",
	"res://data/items/ScrollTheftProtection.tres",
	"res://data/items/ScrollPvpProtection.tres",
	# ADR-039: Pickpocketing — drei Diebstahl-Kristall-Stufen
	"res://data/items/TheftCrystalWeak.tres",
	"res://data/items/TheftCrystalNormal.tres",
	"res://data/items/TheftCrystalStrong.tres",
]

const LOOT_TABLES: Array[String] = [
	"res://data/loot_tables/goblin_loot.tres",
	"res://data/loot_tables/skeleton_loot.tres",
]

const QUESTS: Array[String] = [
	"res://data/quests/quest_woodcutter_intro.tres",
]

const SKILLS: Array[String] = [
	"res://data/skills/woodcutting.tres",
	"res://data/skills/mining.tres",
	"res://data/skills/farming.tres",
	"res://data/skills/combat.tres",
	"res://data/skills/foraging.tres",
	# ADR-039: uncapped (max_level=-1), lineare XP-Kurve (xp_scaling_factor=1.0)
	# — rein datengetrieben, kein SkillSystem-Code-Umbau nötig (siehe ADR
	# "Lineare statt exponentieller XP-Kurve").
	"res://data/skills/pickpocketing.tres",
]

const COMBAT_PROFILES: Array[String] = [
	"res://data/combat_profiles/goblin.tres",
	"res://data/combat_profiles/player.tres",
	"res://data/combat_profiles/skeleton.tres",
]

## Round 103 (ADR-046 "Umsetzungsstand (Round 103)"): datengetriebene
## Achievement-Definitionen, ergänzen/überschreiben
## AchievementService.DEFAULT_DEFINITIONS (der eingebaute Fallback bleibt
## bestehen, siehe dortiger Klassenkommentar).
const ACHIEVEMENTS: Array[String] = [
	"res://data/achievements/first_blood.tres",
	"res://data/achievements/pvp_veteran.tres",
	"res://data/achievements/first_sale.tres",
	"res://data/achievements/auctioneer.tres",
	"res://data/achievements/community_watch.tres",
	"res://data/achievements/wanderer.tres",
	"res://data/achievements/high_jumper.tres",
	"res://data/achievements/gravity_defier.tres",
	"res://data/achievements/monster_hunter.tres",
]
