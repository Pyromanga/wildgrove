class_name DataManifest

## DataManifest — Explizite Liste aller statischen Ressourcen-Pfade.
##
## WARUM: DirAccess.open("res://...") funktioniert auf Android nicht —
## Godot-PCK-Archive erlauben keine Verzeichnisauflistung zur Laufzeit.
## Außerdem erkennt der Godot-Exporter mit export_filter="all_resources"
## nur Ressourcen die im SceneTree oder via preload() referenziert sind.
## Ressourcen die nur per DirAccess-Scan geladen werden, landen NICHT im APK.
##
## LÖSUNG: Alle Pfade hier als Konstanten auflisten.
##   - Der Exporter sieht die String-Literals und packt die Dateien ein.
##   - DataService nutzt diese Listen statt DirAccess.
##   - Neue Items/Quests: Pfad hier ergänzen → automatisch exportiert.

const ITEMS: Array[String] = [
	"res://data/items/LogNormal.tres",
	"res://data/items/LogOak.tres",
	"res://data/items/LogMaple.tres",
	"res://data/items/LogWillow.tres",
	"res://data/items/IronOre.tres",
	"res://data/items/CopperOre.tres",
	# Goblin-Drop Items
	"res://data/items/GoblinEar.tres",
	"res://data/items/weapons/PoisonDagger.tres",
	# Skeleton-Drop Items
	"res://data/items/BoneFragment.tres",
	# Cactus-Drop Items (Round 76)
	"res://data/items/CactusFiber.tres",
	# PineTree-/IceCrystal-Drop Items (Round 77)
	"res://data/items/LogPine.tres",
	"res://data/items/IceCrystalShard.tres",
	# RockBoulder-Drop Item (Round 78)
	"res://data/items/Stone.tres",
	# MushroomCluster-Drop Item (Round 79) — FallenTree nutzt log_normal (bereits oben registriert)
	"res://data/items/WildMushroom.tres",
	# Fern-Drop Item (Fern-Rollout)
	"res://data/items/FernFiber.tres",
	# Gathering-Werkzeuge (Shop-Kauf, Round 88): +50% Abbaugeschwindigkeit
	"res://data/items/tools/WoodAxe.tres",
	"res://data/items/tools/Pickaxe.tres",
	# Graben/Aufschütten (Gelände-Umbau): Schaufel + das Material, das dabei entsteht/verbraucht wird
	"res://data/items/tools/Shovel.tres",
	"res://data/items/Dirt.tres",
	# ADR-038: Item-Schutz-Dreiklang — drei Schutz-Scrolls
	"res://data/items/ScrollPveProtection.tres",
	"res://data/items/ScrollTheftProtection.tres",
	"res://data/items/ScrollPvpProtection.tres",
	# ADR-039: Pickpocketing — drei Diebstahl-Kristall-Stufen
	"res://data/items/TheftCrystalWeak.tres",
	"res://data/items/TheftCrystalNormal.tres",
	"res://data/items/TheftCrystalStrong.tres",
	# Farming — Samen + Ernte-Item (Wunsch "Samen pflanzen + ernten")
	"res://data/items/CarrotSeed.tres",
	"res://data/items/Carrot.tres",
	# Hain-Skills (Sturmkunde/Imkerei/Sternkunde/Alchemie/Köhlerei): je ein Sammel-Item.
	"res://data/items/LightningGlass.tres",
	"res://data/items/Honeycomb.tres",
	"res://data/items/MeteoriteIron.tres",
	"res://data/items/Sulfur.tres",
	"res://data/items/Charcoal.tres",
]

const LOOT_TABLES: Array[String] = [
	"res://data/loot_tables/goblin_loot.tres",
	"res://data/loot_tables/skeleton_loot.tres",
	"res://data/loot_tables/loot_carrot.tres",
]

## Farming (Wunsch "Samen pflanzen + ernten") — siehe FarmCropDefinition.gd/
## FarmPlot.gd. Neue Feldfrucht: neue .tres hier + passende Samen-/Ernte-
## Items oben in ITEMS + eigene LootTable — kein Code-Änderung an FarmPlot
## nötig (siehe dortiger Klassenkommentar).
const CROPS: Array[String] = [
	"res://data/crops/carrot.tres",
]

## Bauteile (Bausystem): neues Bauteil = neue .tres hier — solange es ein bekannter Kind ist
## (BuildPieceDefinition.Kind), ist kein Code nötig. Kosten verweisen auf Item-IDs aus ITEMS.
const BUILD_PIECES: Array[String] = [
	"res://data/building/WoodFloor.tres",
	"res://data/building/WoodWall.tres",
	"res://data/building/StoneWall.tres",
]

const QUESTS: Array[String] = [
	"res://data/quests/quest_woodcutter_intro.tres",
	# BUG-FIX: die folgenden drei .tres existierten bereits, fehlten aber hier —
	# DataService._load_quests() liest ausschließlich aus dieser Liste (kein
	# DirAccess-Scan, siehe Klassenkommentar oben), sie wurden also nie
	# geladen und waren im Spiel faktisch nicht vorhanden.
	"res://data/quests/quest_erik_friendship.tres",
	"res://data/quests/quest_miner_defense.tres",
	"res://data/quests/quest_woodcutter_master.tres",
	"res://data/quests/quest_miner_gratitude.tres",
	"res://data/quests/quest_herbalist_request.tres",
	"res://data/quests/quest_herbalist_secret.tres",
]

const SKILLS: Array[String] = [
	"res://data/skills/woodcutting.tres",
	"res://data/skills/mining.tres",
	"res://data/skills/farming.tres",
	"res://data/skills/combat.tres",
	"res://data/skills/foraging.tres",
	# FIX: digging.tres existierte, fehlte aber hier — WorldService vergibt DIG_XP über
	# request_add_xp("digging", …), SkillSystem verwarf die XP als "Unbekannter Skill".
	"res://data/skills/digging.tres",
	# ADR-039: uncapped (max_level=-1), lineare XP-Kurve (xp_scaling_factor=1.0)
	# — rein datengetrieben, kein SkillSystem-Code-Umbau nötig (siehe ADR
	# "Lineare statt exponentieller XP-Kurve").
	"res://data/skills/pickpocketing.tres",
	# Hain-Skills: XP kommen aus den Weltobjekten Fulgurite/WildBeehive/Meteorite/SulfurCrust/CharcoalKiln
	# (InteractableData.xp_type == Skill-ID).
	"res://data/skills/stormlore.tres",
	"res://data/skills/beekeeping.tres",
	"res://data/skills/stargazing.tres",
	"res://data/skills/alchemy.tres",
	"res://data/skills/charcoal_burning.tres",
]

const COMBAT_PROFILES: Array[String] = [
	"res://data/combat_profiles/goblin.tres",
	"res://data/combat_profiles/player.tres",
	"res://data/combat_profiles/skeleton.tres",
]

## Round 103 (ADR-046 "Umsetzungsstand (Round 103)"): datengetriebene
## Achievement-Definitionen, ergänzen/überschreiben
## AchievementService.DEFAULT_DEFINITIONS (der eingebaute Fallback bleibt
## bestehen, siehe dortiger Klassenkommentar).
const ACHIEVEMENTS: Array[String] = [
	"res://data/achievements/first_blood.tres",
	"res://data/achievements/pvp_veteran.tres",
	"res://data/achievements/first_sale.tres",
	"res://data/achievements/auctioneer.tres",
	"res://data/achievements/community_watch.tres",
	"res://data/achievements/wanderer.tres",
	"res://data/achievements/high_jumper.tres",
	"res://data/achievements/gravity_defier.tres",
	"res://data/achievements/monster_hunter.tres",
]
