class_name DataManifest

## DataManifest — Explizite Liste aller statischen Ressourcen-Pfade.
##
## WARUM: DirAccess.open("res://...") funktioniert auf Android nicht —
## Godot-PCK-Archive erlauben keine Verzeichnisauflistung zur Laufzeit.
## Außerdem erkennt der Godot-Exporter mit export_filter="all_resources"
## nur Ressourcen die im SceneTree oder via preload() referenziert sind.
## Ressourcen die nur per DirAccess-Scan geladen werden, landen NICHT im APK.
##
## LÖSUNG: Alle Pfade hier als Konstanten auflisten.
##   - Der Exporter sieht die String-Literals und packt die Dateien ein.
##   - DataService nutzt diese Listen statt DirAccess.
##   - Neue Items/Quests: Pfad hier ergänzen → automatisch exportiert.

const ITEMS: Array[String] = [
	"res://data/items/LogNormal.tres",
	"res://data/items/LogOak.tres",
	"res://data/items/LogMaple.tres",
	"res://data/items/LogWillow.tres",
	"res://data/items/IronOre.tres",
	"res://data/items/CopperOre.tres",
	# Goblin-Drop Items
	"res://data/items/GoblinEar.tres",
	"res://data/items/weapons/PoisonDagger.tres",
	# Skeleton-Drop Items
	"res://data/items/BoneFragment.tres",
	# Cactus-Drop Items (Round 76)
	"res://data/items/CactusFiber.tres",
	# PineTree-/IceCrystal-Drop Items (Round 77)
	"res://data/items/LogPine.tres",
	"res://data/items/IceCrystalShard.tres",
	# RockBoulder-Drop Item (Round 78)
	"res://data/items/Stone.tres",
	# MushroomCluster-Drop Item (Round 79) — FallenTree nutzt log_normal (bereits oben registriert)
	"res://data/items/WildMushroom.tres",
	# Fern-Drop Item (Fern-Rollout)
	"res://data/items/FernFiber.tres",
	# Gathering-Werkzeuge (Shop-Kauf, Round 88): +50% Abbaugeschwindigkeit
	"res://data/items/tools/WoodAxe.tres",
	"res://data/items/tools/Pickaxe.tres",
	# Graben/Aufschütten (Gelände-Umbau): Schaufel + das Material, das dabei entsteht/verbraucht wird
	"res://data/items/tools/Shovel.tres",
	"res://data/items/Dirt.tres",
	# Boden-Material-System (2026-09-26, "natürlich Erde/Sand je nach Biom + Kiesschicht"):
	# analog zu Dirt.tres, siehe BiomeDefinition.surface_material/TerrainField.get_material_at().
	"res://data/items/Sand.tres",
	"res://data/items/Gravel.tres",
	# Graben in die Tiefe: Leiter + Funde (Erze/Edelsteine, siehe DigFindTable)
	"res://data/items/Ladder.tres",
	"res://data/items/SilverOre.tres",
	"res://data/items/GoldOre.tres",
	"res://data/items/GemAmethyst.tres",
	"res://data/items/GemEmerald.tres",
	"res://data/items/GemSapphire.tres",
	"res://data/items/GemRuby.tres",
	"res://data/items/GemDiamond.tres",
	# ADR-038: Item-Schutz-Dreiklang — drei Schutz-Scrolls
	"res://data/items/ScrollPveProtection.tres",
	"res://data/items/ScrollTheftProtection.tres",
	"res://data/items/ScrollPvpProtection.tres",
	# ADR-039: Pickpocketing — drei Diebstahl-Kristall-Stufen
	"res://data/items/TheftCrystalWeak.tres",
	"res://data/items/TheftCrystalNormal.tres",
	"res://data/items/TheftCrystalStrong.tres",
	# Farming — Samen + Ernte-Item (Wunsch "Samen pflanzen + ernten")
	"res://data/items/CarrotSeed.tres",
	"res://data/items/Carrot.tres",
	# Försterei — Setzling (Wunsch "Försterei-Skill: Setzlinge kaufen + pflanzen").
	# log_oak selbst ist schon länger als Bau-Material registriert (OakWall,
	# TowerWoodSquare, …), hatte aber bisher keine Erntequelle im Spiel — die
	# Försterei ist jetzt genau das. Ausgebaut auf alle vier Wild-Baumarten
	# (Wunsch "für alle Baumarten ausbauen") — je ein Setzling-Item pro
	# HarvestableEntity-Baum (OakTree/MapleTree/PineTree/WillowTree).
	"res://data/items/OakSapling.tres",
	"res://data/items/MapleSapling.tres",
	"res://data/items/PineSapling.tres",
	"res://data/items/WillowSapling.tres",
	# Hain-Skills (Sturmkunde/Imkerei/Sternkunde/Alchemie/Köhlerei): je ein Sammel-Item.
	"res://data/items/LightningGlass.tres",
	"res://data/items/Honeycomb.tres",
	"res://data/items/MeteoriteIron.tres",
	"res://data/items/Sulfur.tres",
	"res://data/items/Charcoal.tres",
	"res://data/items/FoxTailTalisman.tres",
]

const LOOT_TABLES: Array[String] = [
	"res://data/loot_tables/goblin_loot.tres",
	"res://data/loot_tables/skeleton_loot.tres",
	"res://data/loot_tables/loot_carrot.tres",
]

## Farming (Wunsch "Samen pflanzen + ernten") — siehe FarmCropDefinition.gd/
## FarmPlot.gd. Neue Feldfrucht: neue .tres hier + passende Samen-/Ernte-
## Items oben in ITEMS + eigene LootTable — kein Code-Änderung an FarmPlot
## nötig (siehe dortiger Klassenkommentar).
## FarmPlot trägt inzwischen auch Baum-Setzlinge (skill_id="forestry" statt
## "farming", siehe FarmCropDefinition.gd) — "CROPS" ist historisch benannt,
## bedeutet hier "alles, was ein FarmPlot bepflanzen kann".
const CROPS: Array[String] = [
	"res://data/crops/carrot.tres",
	"res://data/crops/oak_sapling.tres",
	"res://data/crops/maple_sapling.tres",
	"res://data/crops/pine_sapling.tres",
	"res://data/crops/willow_sapling.tres",
]

## Bauteile (Bausystem): neues Bauteil = neue .tres hier — solange es ein bekannter Kind ist
## (BuildPieceDefinition.Kind), ist kein Code nötig. Kosten verweisen auf Item-IDs aus ITEMS.
const BUILD_PIECES: Array[String] = [
	"res://data/building/WoodFloor.tres",
	"res://data/building/WoodWall.tres",
	"res://data/building/StoneWall.tres",
	"res://data/building/WoodDoor.tres",
	"res://data/building/WoodWindow.tres",
	"res://data/building/WoodRoof.tres",
	"res://data/building/WoodStairs.tres",
	# Mehr Auswahl fürs Bauen (Wunsch "damit man wirklich gut bauen kann"): Stein-Set
	# komplettiert (bisher nur Wand — jetzt auch Boden/Dach/Treppe, ein reines Steinhaus
	# ist damit möglich), plus Eichenwand (stabilere Holz-Stufe, log_oak bisher ungenutzt),
	# verstärkte Tür und niedrige Mauern/Zäune (WALL mit geringerer height — Balkone/
	# Gärten/Sichtschutz ohne gleich ein ganzes Zimmer abzuschließen).
	"res://data/building/StoneFloor.tres",
	"res://data/building/StoneRoof.tres",
	"res://data/building/StoneStairs.tres",
	"res://data/building/OakWall.tres",
	"res://data/building/IronDoor.tres",
	"res://data/building/WoodFence.tres",
	"res://data/building/StoneFence.tres",
	# Bogenschießstand (Wunsch "mehr shapes und Strukturen"): neuer Kind TARGET (freistehende
	# Requisiten, siehe BuildPieceDefinition.Kind) für die Zielscheibe, plus Strohballen als
	# niedrige, breite WALL-Variante (Pfeilfang/Absperrung — kein neuer Code nötig, nur Daten).
	"res://data/building/ArcheryTarget.tres",
	"res://data/building/HayBale.tres",
	# Brunnen (Wunsch "als nächstes ein Brunnen"): zweite Requisite auf Kind TARGET, über den
	# neuen Schalter BuildPieceDefinition.PropShape (kein neuer Kind/Platzierungscode nötig,
	# nur ein neuer build_..._mesh() — siehe BuildPieceDefinition.Kind-Klassenkommentar).
	"res://data/building/Well.tres",
	# Türme rund/eckig (Wunsch "Türme rund und eckig"): zwei weitere PropShape-Werte auf
	# demselben Kind TARGET wie Zielscheibe/Brunnen — kein neuer Kind/Platzierungscode nötig.
	"res://data/building/TowerStoneRound.tres",
	"res://data/building/TowerWoodSquare.tres",
	# Mehr Dachformen, First adjustierbar (Wunsch "Dächer in mehr Formen ... adjustierend"):
	# neuer Schalter BuildPieceDefinition.RoofShape auf demselben Kind ROOF — Satteldach
	# (bisheriges Verhalten, WoodRoof/StoneRoof bleiben unverändert GABLE) bekommt zwei
	# Geschwister (Walmdach/Zeltdach, beide dieselbe First-Einzug-Formel wie GABLE, nur mit
	# roof_ridge > 0 — siehe RoofShape-Kommentar) sowie ein Flachdach ohne First.
	"res://data/building/HipRoof.tres",
	"res://data/building/PyramidRoof.tres",
	"res://data/building/FlatRoof.tres",
	# Wendeltreppen (Wunsch "Wendeltreppen, sollen in Große Häuser & Türme passen"): neuer
	# Schalter BuildPieceDefinition.StairsShape auf demselben Kind STAIRS wie WoodStairs/
	# StoneStairs — kein neuer Kind/Platzierungscode nötig, nur ein neuer build_..._mesh() +
	# eigene Kollisionsform. Grundfläche bleibt EINE Zelle (wie bei der geraden Treppe), passt
	# also in Turmschäfte (TOWER_ROUND/TOWER_SQUARE) und mehrstöckige Häuser, wo eine gerade
	# Treppe zu viel Platz braucht.
	"res://data/building/WoodSpiralStairs.tres",
	"res://data/building/StoneSpiralStairs.tres",
	# Kirche & Friedhof (Wunsch "Kirche & Friedhof"): Kreuz und Grabsteine als drei weitere
	# PropShape-Werte auf Kind TARGET (wie Zielscheibe/Brunnen/Türme — kein neuer Kind/
	# Platzierungscode nötig). CemeteryGate ist Kind DOOR (dieselbe Öffnungs-Mechanik wie
	# WoodDoor/IronDoor, nur dunklere Optik/andere Kosten) — die niedrige Friedhofsmauer
	# braucht kein neues Bauteil, StoneFence (oben) deckt das schon ab.
	"res://data/building/WaysideCross.tres",
	"res://data/building/GraveCross.tres",
	"res://data/building/GravestoneStele.tres",
	"res://data/building/GravestoneSlab.tres",
	"res://data/building/CemeteryGate.tres",
	# Kapelle, Wegweiser, Straßenlaternen (Wunsch "als nächstes Kapelle, Wegweiser und Straßen-
	# laternen"): drei weitere PropShape-Werte auf Kind TARGET (CHAPEL/SIGNPOST/LAMP_POST) — kein neuer
	# Kind/Platzierungscode. Neu gegenüber den älteren Requisiten: mehrere Mesh-Flächen mit
	# Zweitfarbe (accent_color) und Leuchtfläche, begehbare Kapelle (get_prop_collision_boxes()) und
	# optionales Licht (light_range) — siehe BuildPieceDefinition.PropShape/PropSurface. Je zwei
	# Materialvarianten für Kapelle und Laterne, nur Daten.
	"res://data/building/ChapelStone.tres",
	"res://data/building/ChapelWood.tres",
	"res://data/building/WoodSignpost.tres",
	"res://data/building/StreetLampIron.tres",
	"res://data/building/StreetLampWood.tres",
	# Windmühle & Sonnenuhr (Wunsch "Strukturen und shapes ... kleine gimmicks und große
	# Struktur"): zwei weitere PropShape-Werte auf demselben Kind TARGET wie Zielscheibe/Brunnen/
	# Turm/Laterne — kein neuer Kind/Platzierungscode nötig, nur zwei neue build_..._mesh().
	"res://data/building/Windmill.tres",
	"res://data/building/Sundial.tres",
	# Torturm & Katapult (Wunsch "Richtung Burg"): wie oben zwei weitere PropShape-Werte auf
	# Kind TARGET — kein neuer Kind/Platzierungscode nötig, nur zwei neue build_..._mesh().
	"res://data/building/Gatehouse.tres",
	"res://data/building/Catapult.tres",
]

## Komplette Häuser (HouseTemplateDefinition): mehrere BUILD_PIECES-Einträge als eine Vorlage,
## siehe HouseTemplateDefinition-Klassenkommentar. Neues Haus = neue .tres hier — solange sie
## nur vorhandene BUILD_PIECES referenziert, ist kein Code nötig.
const HOUSE_TEMPLATES: Array[String] = [
	"res://data/building/houses/SimpleCabin.tres",
	"res://data/building/houses/StarterHut.tres",
	"res://data/building/houses/ForestLodge.tres",
	"res://data/building/houses/ArcheryRange.tres",
	# Kirche & Friedhof (Wunsch "Kirche & Friedhof"): kein neuer Code nötig — nur vorhandene
	# BUILD_PIECES referenziert (Stein-Set, Turm, Wegkreuz), siehe HouseTemplateDefinition-
	# Klassenkommentar.
	"res://data/building/houses/VillageChurch.tres",
	"res://data/building/houses/VillageCemetery.tres",
	# Müllerhäuschen (Wunsch "Strukturen und shapes ... große Struktur"): kein neuer Code nötig —
	# nur vorhandene BUILD_PIECES referenziert (Stein-Set der Steinhütte) plus die neue Windmühle/
	# Sonnenuhr von oben.
	"res://data/building/houses/WindmillCottage.tres",
	# Kleine Burg (Wunsch "Richtung Burg"): kein neuer Code nötig — nur vorhandene BUILD_PIECES
	# referenziert (Steinmauer, Rundturm, Brunnen) plus Torturm/Katapult von oben.
	"res://data/building/houses/SmallCastle.tres",
]

const QUESTS: Array[String] = [
	"res://data/quests/quest_woodcutter_intro.tres",
	# BUG-FIX: die folgenden drei .tres existierten bereits, fehlten aber hier —
	# DataService._load_quests() liest ausschließlich aus dieser Liste (kein
	# DirAccess-Scan, siehe Klassenkommentar oben), sie wurden also nie
	# geladen und waren im Spiel faktisch nicht vorhanden.
	"res://data/quests/quest_erik_friendship.tres",
	"res://data/quests/quest_miner_defense.tres",
	"res://data/quests/quest_woodcutter_master.tres",
	"res://data/quests/quest_miner_gratitude.tres",
	"res://data/quests/quest_herbalist_request.tres",
	"res://data/quests/quest_herbalist_secret.tres",
	"res://data/quests/quest_wei_patience.tres",
	"res://data/quests/quest_babatunde_tale.tres",
	"res://data/quests/quest_wei_mastery.tres",
	"res://data/quests/quest_babatunde_legacy.tres",
	"res://data/quests/quest_talia_investigation.tres",
	"res://data/quests/quest_talia_verdict.tres",
]

const SKILLS: Array[String] = [
	"res://data/skills/woodcutting.tres",
	"res://data/skills/mining.tres",
	"res://data/skills/farming.tres",
	"res://data/skills/combat.tres",
	"res://data/skills/foraging.tres",
	# FIX: digging.tres existierte, fehlte aber hier — WorldService vergibt DIG_XP über
	# request_add_xp("digging", …), SkillSystem verwarf die XP als "Unbekannter Skill".
	"res://data/skills/digging.tres",
	# ADR-039: uncapped (max_level=-1), lineare XP-Kurve (xp_scaling_factor=1.0)
	# — rein datengetrieben, kein SkillSystem-Code-Umbau nötig (siehe ADR
	# "Lineare statt exponentieller XP-Kurve").
	"res://data/skills/pickpocketing.tres",
	# Hain-Skills: XP kommen aus den Weltobjekten Fulgurite/WildBeehive/Meteorite/SulfurCrust/CharcoalKiln
	# (InteractableData.xp_type == Skill-ID).
	"res://data/skills/stormlore.tres",
	"res://data/skills/beekeeping.tres",
	"res://data/skills/stargazing.tres",
	"res://data/skills/alchemy.tres",
	"res://data/skills/charcoal_burning.tres",
	# Försterei (Wunsch "Försterei-Skill: Setzlinge kaufen + pflanzen") — XP kommt
	# aus FarmPlot._refresh_interactable_data() über FarmCropDefinition.skill_id
	# (siehe data/crops/oak_sapling.tres), analog zu farming.tres oben.
	"res://data/skills/forestry.tres",
]

const COMBAT_PROFILES: Array[String] = [
	"res://data/combat_profiles/goblin.tres",
	"res://data/combat_profiles/player.tres",
	"res://data/combat_profiles/skeleton.tres",
]

## Round 103 (ADR-046 "Umsetzungsstand (Round 103)"): datengetriebene
## Achievement-Definitionen, ergänzen/überschreiben
## AchievementService.DEFAULT_DEFINITIONS (der eingebaute Fallback bleibt
## bestehen, siehe dortiger Klassenkommentar).
const ACHIEVEMENTS: Array[String] = [
	"res://data/achievements/first_blood.tres",
	"res://data/achievements/pvp_veteran.tres",
	"res://data/achievements/first_sale.tres",
	"res://data/achievements/auctioneer.tres",
	"res://data/achievements/community_watch.tres",
	"res://data/achievements/wanderer.tres",
	"res://data/achievements/high_jumper.tres",
	"res://data/achievements/gravity_defier.tres",
	"res://data/achievements/monster_hunter.tres",
]
