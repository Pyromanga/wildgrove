extends Node
class_name InteractionTargetPicker

## InteractionTargetPicker — Tap/Klick-Zielauswahl per Raycast (RuneScape-/
## Minecraft-Stil): antippen wählt EXPLIZIT das gemeinte Objekt aus (statt nur
## "das nächste in Reichweite", was bei mehreren Bäumen nebeneinander mehrdeutig
## ist) und zeigt es umrandet an (InteractionOutline) — zur Bestätigung, bevor
## irgendetwas passiert.
##
## Gilt generisch für ALLES in der Gruppe "interactable" — kein Sonderfall pro
## Entity-Typ. Kein neuer Interaktions-Pfad: die Auswahl wird nur an
## InteractionSensor.set_manual_target() gereicht, das bestehende UI/Executor-
## System (ContextButtonController → Kontextmenü → InteractionExecutor) läuft
## unverändert weiter, sobald der Spieler nah genug ist. Ohne Reichweite bleibt
## es bei der optischen Bestätigung (Umrandung) — der Spieler muss noch
## hinlaufen; kein Click-to-move/Auto-Pathing (bewusst außerhalb des Scopes).
##
## Kein Service — direktes Child des Player-Nodes, analog InteractionSensor/
## TouchInput. Empfängt world_tap_requested (siehe TouchInput/WorldEvents) über
## den injizierten IEventBus.

const LOG_CAT := "TargetPicker"
const MAX_RAY_DISTANCE: float = 60.0

var _bus: IEventBus = null
var _camera: PlayerCamera = null
var _sensor: InteractionSensor = null
var _owner_node: Node3D = null

var _outline: InteractionOutline = null

## Wird von PlayerSetup.build() unmittelbar nach add_child() aufgerufen.
func setup(camera: PlayerCamera, sensor: InteractionSensor, owner_node: Node3D) -> void:
	_camera = camera
	_sensor = sensor
	_owner_node = owner_node

## Wird von Player.on_spawn() aufgerufen — analog InteractionSensor.inject_bus()/
## TouchInput.inject_bus().
func inject_bus(bus: IEventBus) -> void:
	_bus = bus
	_bus.world().world_tap_requested.connect(_on_world_tap)

func _exit_tree() -> void:
	_clear_outline()

## Highlight nur solange gültig, wie das Ziel noch existiert (z.B. Baum wurde
## in der Zwischenzeit abgeerntet/despawnt). Billiger Check statt eigenem
## Listener auf jedes mögliche Despawn-Signal.
func _process(_delta: float) -> void:
	if is_instance_valid(_outline) and not _outline.is_target_valid():
		_clear_outline()
		if is_instance_valid(_sensor):
			_sensor.clear_manual_target()

func _on_world_tap(screen_pos: Vector2) -> void:
	if not is_instance_valid(_camera) or not is_instance_valid(_camera.camera):
		return

	var hit := _raycast(screen_pos)
	if hit == null:
		_deselect()
		return

	if is_instance_valid(_outline) and _outline.get_target() == hit:
		# Erneutes Antippen desselben Ziels → abwählen (Tap als Toggle, wie in
		# RuneScape/Minecraft: nochmal drauf tippen nimmt die Markierung weg).
		_deselect()
		return

	_select(hit)

func _raycast(screen_pos: Vector2) -> Node3D:
	var space_state := _camera.camera.get_world_3d().direct_space_state
	var origin := _camera.camera.project_ray_origin(screen_pos)
	var dir := _camera.camera.project_ray_normal(screen_pos)

	var params := PhysicsRayQueryParameters3D.create(origin, origin + dir * MAX_RAY_DISTANCE)
	params.collide_with_areas = true
	params.collide_with_bodies = true
	if is_instance_valid(_owner_node) and _owner_node is CollisionObject3D:
		params.exclude = [(_owner_node as CollisionObject3D).get_rid()]

	var result := space_state.intersect_ray(params)
	if result.is_empty():
		return null

	var collider: Object = result.get("collider")
	if collider == null or not (collider is Node):
		return null

	return InteractionGroupUtil.resolve_interactable(collider as Node, _owner_node)

func _select(target: Node3D) -> void:
	_clear_outline()
	_outline = InteractionOutline.new(target)
	if is_instance_valid(_sensor):
		_sensor.set_manual_target(target)
	AppLogger.log_info("Ziel angetippt: '%s'." % target.name, LOG_CAT)

func _deselect() -> void:
	if not is_instance_valid(_outline):
		return
	_clear_outline()
	if is_instance_valid(_sensor):
		_sensor.clear_manual_target()

func _clear_outline() -> void:
	if is_instance_valid(_outline):
		_outline.destroy()
	_outline = null
