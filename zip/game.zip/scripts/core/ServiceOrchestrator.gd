extends Node

## ServiceOrchestrator — Dünne Lifecycle-Shell. Nichts mehr.
##
## Verwaltet nur noch:
##   - App-Boot in _ready()
##   - Character-Boot/Teardown auf Session-Request
##   - World-Boot wenn WorldScopeInitializer signalisiert
##   - Shutdown-Handling
##
## Alle Boot-Logik lebt in BootPipeline.
## Alle Scope-Daten leben in AppScope / CharacterScope / WorldScope.
## Keine _inject_*-Methoden. Keine Cross-Registry-Handshakes. Kein God Object.

const LOG_CAT := "Orchestrator"

var _pipeline: BootPipeline = BootPipeline.new()
var _app_scope: AppScope    = null

## BUG-23 Root-Cause-Fix: true sobald boot_app() erfolgreich durchgelaufen ist.
## Solange false, werden eingehende session_requested-Signale gepuffert statt
## verarbeitet — vorher gingen sie komplett verloren, wenn der Request
## (z.B. "Neues Spiel"-Klick) ankam bevor boot_app() fertig war, weil der
## Connect für session_requested erst NACH boot_app() passierte.
var _boot_complete: bool = false
var _pending_session_request: String = ""

func _ready() -> void:
	# BUG-23 Diagnose: erste Zeile in _ready(), damit ein künftiger Log-Capture
	# sofort zeigt ob/wann dieser Autoload überhaupt zu laufen beginnt, relativ
	# zum MainMenu-Boot.
	AppLogger.log_info("_ready() gestartet.", LOG_CAT)
	_app_scope = AppScope.new(ServiceRegistry.new())

	# Beide Listener JETZT verdrahten — VOR boot_app(). Das ist der eigentliche
	# BUG-23-Fix: egal wie lange boot_app() braucht oder wie früh die Main-Szene
	# (MainMenu.tscn) nachzieht, ein 'Neues Spiel'-Klick oder ein
	# MenuScopeInitializer-Node kann jetzt nie mehr verloren gehen, weil der
	# Connect zu spät kam. session_requested wird gepuffert (s.u.), bis
	# boot_app() durch ist.
	EventBus.system.session_requested.connect(_on_session_requested)
	_watch_for_menu_initializer()

	var result := _pipeline.boot_app(_app_scope, self)
	if not result.ok:
		# Vorher verpuffte dieser Fehler unsichtbar: der einzige Listener auf
		# boot_failed saß in Main.tscn, das nie geladen wird (run/main_scene
		# ist MainMenu.tscn). Jetzt zusätzlich laut geloggt, damit ein
		# Boot-Fehler nie wieder wie ein stilles Hängenbleiben aussieht.
		AppLogger.log_error(
			"App-Boot fehlgeschlagen — Phase '%s': %s" % [result.failed_phase, result.reason],
			LOG_CAT
		)
		EventBus.system.boot_failed.emit(result.failed_phase, result.reason)
		return

	_boot_complete = true
	EventBus.system.state_changed.connect(_on_state_changed)
	_connect_session_manager()

	if not _pending_session_request.is_empty():
		var pending_id := _pending_session_request
		_pending_session_request = ""
		AppLogger.log_info("Gepufferten Session-Request nachgeholt: '%s'." % pending_id, LOG_CAT)
		_on_session_requested(pending_id)

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_CRASH:
		_pipeline.teardown_all(_app_scope)

# ─────────────────────────────────────────────
# Character-Scope
# ─────────────────────────────────────────────

func _on_session_requested(player_id: String) -> void:
	if not _boot_complete:
		# App-Boot noch nicht fertig (z.B. Request kam extrem früh rein) —
		# puffern statt verlieren. Wird in _ready() nachgeholt sobald
		# boot_app() erfolgreich durchgelaufen ist.
		AppLogger.log_warn(
			"Session-Request '%s' vor Boot-Abschluss — wird gepuffert." % player_id, LOG_CAT
		)
		_pending_session_request = player_id
		return
	var char_scope := _app_scope.create_character_scope(player_id, self)
	var result     := _pipeline.boot_character(char_scope, self)
	if not result.ok:
		EventBus.system.boot_failed.emit(result.failed_phase, result.reason)
		return
	# WorldScope wird getriggert sobald WorldScopeInitializer in World.tscn bereit ist.
	# CharacterScope.world_scope_ready → _on_world_scope_ready
	char_scope.world_scope_ready.connect(_on_world_scope_ready)
	_watch_for_world_initializer()
	_wire_hud(char_scope)
	EventBus.system.emit_session_ready()

func _on_state_changed(new_state: int) -> void:
	if new_state == GameEnums.State.MAIN_MENU and _app_scope.has_character_scope():
		_app_scope.destroy_character_scope()
		EventBus.system.emit_session_unloaded()

# ─────────────────────────────────────────────
# World-Scope — getriggert durch WorldScopeInitializer (Push, kein Pull)
# ─────────────────────────────────────────────

func _on_world_initializer_ready(world_root: Node3D) -> void:
	var char_scope := _app_scope.get_character_scope()
	if char_scope == null:
		AppLogger.log_warn("WorldScopeInitializer signalisierte aber kein CharacterScope aktiv.", LOG_CAT)
		return
	var world_scope := char_scope.create_world_scope(world_root, self)
	var result      := _pipeline.boot_world(world_scope, self)
	if not result.ok:
		EventBus.system.boot_failed.emit(result.failed_phase, result.reason)

func _on_world_scope_ready(_world_scope: WorldScope) -> void:
	pass  # Erweiterungspunkt für post-world-boot Wiring

# ─────────────────────────────────────────────
# HUD-Wiring (war: _inject_save_system_into_main_menu + HUDManager.boot)
# HUDScopeInitializer würde das analog übernehmen (offen). MainMenu-Seite ist seit
# BUG-21 (Round 24) über MenuScopeInitializer gelöst, siehe unten.
# Für HUD: bleibt hier als expliziter Aufruf bis der Initializer-Node gebaut ist.
# ─────────────────────────────────────────────

func _wire_hud(char_scope: CharacterScope) -> void:
	var reg     := char_scope.registry
	var factory := func() -> IUIContext: return UIContext.from_registry(reg)
	if get_tree():
		HUDManager.boot(get_tree(), factory)

# ─────────────────────────────────────────────
# MainMenu-Wiring — Push-Pattern via MenuScopeInitializer (BUG-21)
# App-Scope-DI: existiert vor jedem Session-Boot, kein IUIContext-Injektionspunkt
# (siehe ADR-012). MainMenu.tscn wird bei jedem 'main_menu_requested' neu geladen,
# daher bleibt der node_added-Listener dauerhaft verbunden statt one-shot.
# ─────────────────────────────────────────────

func _watch_for_menu_initializer() -> void:
	get_tree().node_added.connect(_on_node_added_check_menu)

func _on_node_added_check_menu(node: Node) -> void:
	if node is MenuScopeInitializer:
		node.menu_ready.connect(_on_menu_initializer_ready, CONNECT_ONE_SHOT)

func _on_menu_initializer_ready(menu_root: Control) -> void:
	if not menu_root is MainMenuController:
		return
	var save_system := _app_scope.get_service(ServiceKeys.SAVE_SYSTEM) as SaveSystem
	if is_instance_valid(save_system):
		(menu_root as MainMenuController).inject_save_system(save_system)
	else:
		AppLogger.log_error("SaveSystem nicht in App-Scope verfügbar — MainMenu-Injektion übersprungen.", LOG_CAT)

# ─────────────────────────────────────────────
# SessionManager — Client-Auto-Join
# ─────────────────────────────────────────────

func _connect_session_manager() -> void:
	var sm := _app_scope.get_service(ServiceKeys.SESSION_MANAGER) as SessionManager
	if is_instance_valid(sm):
		sm.client_connected_to_server.connect(_on_client_connected)

func _on_client_connected() -> void:
	var sm         := _app_scope.get_service(ServiceKeys.SESSION_MANAGER) as SessionManager
	var local_peer := sm.get_local_peer_id() if is_instance_valid(sm) else 1
	_on_session_requested("client_%d" % local_peer)

# ─────────────────────────────────────────────
# Debug API
# ─────────────────────────────────────────────

func get_service(service_name: String) -> Object:
	var svc := _app_scope.get_service(service_name)
	if svc == null and _app_scope.has_character_scope():
		svc = _app_scope.get_character_scope().get_service(service_name)
	return svc

## Alle aktuell registrierten Service-Namen (global + aktive Character-Session).
## Wird von SimpleTerminal ('services', 'status') genutzt.
func get_registered_names() -> Array[String]:
	var names := _app_scope.registry.get_all_names()
	if _app_scope.has_character_scope():
		names.append_array(_app_scope.get_character_scope().registry.get_all_names())
	return names

## Kurzinfo zu einem einzelnen Service. Wird von SimpleTerminal ('service', 'status') genutzt.
func get_service_info(service_name: String) -> Dictionary:
	var svc := get_service(service_name)
	if svc == null:
		return {"valid": false}
	return {"valid": is_instance_valid(svc), "class": svc.get_class()}

func is_session_active() -> bool:
	return _app_scope.has_character_scope()

## Lauscht einmalig auf WorldScopeInitializer im SceneTree.
## Wird direkt nach boot_character() aufgerufen — bevor World.tscn geladen ist.
## Sobald WorldScopeInitializer bereit ist, wird world_ready connected und
## node_added sofort disconnected. Kein dauerhaftes Polling.
func _watch_for_world_initializer() -> void:
	get_tree().node_added.connect(_on_node_added_check_world, CONNECT_ONE_SHOT)

func _on_node_added_check_world(node: Node) -> void:
	if node is WorldScopeInitializer:
		node.world_ready.connect(_on_world_initializer_ready, CONNECT_ONE_SHOT)
	else:
		# Noch nicht der richtige Node — weiterwarten
		get_tree().node_added.connect(_on_node_added_check_world, CONNECT_ONE_SHOT)
