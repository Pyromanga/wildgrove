extends Service
class_name QuestService
## implements ISaveProvider

## QuestService — Verwaltet den Fortschritt aller Quests.
##
## Abhängigkeiten (deps): ["data", "savesystem", "skill_system", "reward_dispatcher", "network_bridge"]
##
## sind jetzt per peer_id verschachtelt. Methoden bekommen player_id: int = 1 —
## bestehende Aufrufer ohne player_id verhalten sich identisch.
##
## Delegiert Event→Objective-Auflösung → QuestObjectiveHandler (statische Helfer-Klasse)
##
## ARCHITEKTUR:
##   - Keine Referenz auf InventorySystem
##   - skill_system per DI für Level-Checks in SKILL-Objectives
##   - Reward-Auszahlung über RewardDispatcher
##   - Quest-Unlock via EventBus.quest.quest_unlock_requested

const LOG_CAT  := "Quest"
const SAVE_KEY := "quest_progress"

var _data_service:      DataService
var _save_system:       SaveSystem
var _skill_system:      SkillSystem
var _reward_dispatcher: RewardDispatcher
var _network:           NetworkBridge = null
var _bus:               IEventBus

var _definitions: Dictionary = {}   # { quest_id: QuestDefinition }

## Multi-Tenant State: { peer_id: { "active": {}, "completed": [], "available": [] } }
var _players: Dictionary = {}

# ─────────────────────────────────────────────
# Intern: Player-Bucket
# ─────────────────────────────────────────────

func _ensure_player(player_id: int) -> Dictionary:
	if not _players.has(player_id):
		var completed_arr: Array[String] = []
		var available_arr: Array[String] = []
		_players[player_id] = {
			"active":    {},
			"completed": completed_arr,
			"available": available_arr,
		}
	return _players[player_id]

## Convenience-Accessors für Tier 1 (player_id=1) — behalten die bekannten Variablennamen
var active_quests:    Dictionary    : get = _get_active_quests
var completed_quests: Array[String] : get = _get_completed_quests
var available_quests: Array[String] : get = _get_available_quests

func _get_active_quests()    -> Dictionary:    return (_ensure_player(1)["active"]    as Dictionary)
func _get_completed_quests() -> Array[String]: return (_ensure_player(1)["completed"] as Array[String])
func _get_available_quests() -> Array[String]: return (_ensure_player(1)["available"] as Array[String])

# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	var t := Logger.log_begin("QuestService.configure()", LOG_CAT)

	_data_service      = deps.get_optional(ServiceKeys.DATA)              as DataService
	_save_system       = deps.require(ServiceKeys.SAVE_SYSTEM)            as SaveSystem
	_skill_system      = deps.get_optional(ServiceKeys.SKILL_SYSTEM)      as SkillSystem
	_reward_dispatcher = deps.get_optional(ServiceKeys.REWARD_DISPATCHER) as RewardDispatcher
	_network           = deps.get_optional(ServiceKeys.NETWORK_BRIDGE)    as NetworkBridge
	_bus               = deps.require(ServiceKeys.EVENT_BUS)              as IEventBus

	if is_instance_valid(_data_service):
		_definitions = _data_service.get_all_quests()
		Logger.log_debug("Quest-Definitionen geladen: %d" % _definitions.size(), LOG_CAT)
	else:
		Logger.log_warn("DataService fehlt — Quest-Definitionen nicht geladen.", LOG_CAT)

	# Lokalen Spieler initialisieren
	_ensure_player(1)

	if is_instance_valid(_save_system):
		_save_system.register_save_provider(self)
		var saved: Dictionary = _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_restore_from_save(saved)
	else:
		Logger.log_warn("SaveSystem fehlt — Quest-Fortschritt nicht gespeichert.", LOG_CAT)

	Logger.log_end("QuestService.configure()", t, LOG_CAT)
	Logger.log_info(
		"Konfiguriert. Definitionen: %d, Aktiv: %d, Abgeschlossen: %d."
		% [_definitions.size(), (_players.get(1, {"active": {}}) as Dictionary).get("active", {}).size(),
		   (_players.get(1, {"completed": []}) as Dictionary).get("completed", []).size()],
		LOG_CAT
	)

# ─────────────────────────────────────────────
# Phase 5: Activate
# ─────────────────────────────────────────────

## Phase S8.6 Late-Inject — NetworkBridge wird nach vollem Session-Boot injiziert.
func inject_network_bridge(network: NetworkBridge) -> void:
	_network = network

func on_ready() -> void:
	_bus.world().loot_collected.connect(_on_loot_collected)
	_bus.player().xp_gained.connect(_on_xp_gained)
	_bus.world().interaction_finished.connect(_on_interaction_finished)
	_bus.world().enemy_killed.connect(_on_enemy_killed)
	_bus.quest().npc_talked_to.connect(_on_npc_talked_to)
	_bus.quest().custom_objective_triggered.connect(_on_custom_objective_triggered)
	_bus.quest().quest_unlock_requested.connect(unlock_quest)
	_bus.quest().quest_start_requested.connect(request_start_quest)

	if is_instance_valid(_data_service):
		for quest_id in _data_service.get_auto_start_quests():
			if not completed_quests.has(quest_id) and not active_quests.has(quest_id):
				request_start_quest(quest_id)

	Logger.log_info("QuestService aktiv.", LOG_CAT)

func on_cleanup() -> void:
	if _bus.world().loot_collected.is_connected(_on_loot_collected):
		_bus.world().loot_collected.disconnect(_on_loot_collected)
	if _bus.player().xp_gained.is_connected(_on_xp_gained):
		_bus.player().xp_gained.disconnect(_on_xp_gained)
	if _bus.world().interaction_finished.is_connected(_on_interaction_finished):
		_bus.world().interaction_finished.disconnect(_on_interaction_finished)
	if _bus.world().enemy_killed.is_connected(_on_enemy_killed):
		_bus.world().enemy_killed.disconnect(_on_enemy_killed)
	if _bus.quest().npc_talked_to.is_connected(_on_npc_talked_to):
		_bus.quest().npc_talked_to.disconnect(_on_npc_talked_to)
	if _bus.quest().custom_objective_triggered.is_connected(_on_custom_objective_triggered):
		_bus.quest().custom_objective_triggered.disconnect(_on_custom_objective_triggered)
	if _bus.quest().quest_unlock_requested.is_connected(unlock_quest):
		_bus.quest().quest_unlock_requested.disconnect(unlock_quest)
	if _bus.quest().quest_start_requested.is_connected(request_start_quest):
		_bus.quest().quest_start_requested.disconnect(request_start_quest)
	Logger.log_info("QuestService cleanup.", LOG_CAT)

# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func get_save_key() -> String: return SAVE_KEY

func get_save_data() -> Dictionary:
	# Format: { "1": { active: {...}, completed: [...], available: [...] }, "2": {...} }
	var out: Dictionary = {}
	for pid in _players:
		var bucket: Dictionary = _players[pid]
		out[str(pid)] = {
			"active":    (bucket["active"] as Dictionary).duplicate(true),
			"completed": (bucket["completed"] as Array).duplicate(),
			"available": (bucket["available"] as Array).duplicate(),
		}
	return out

# ─────────────────────────────────────────────
# Öffentliche API — request_/on_*_confirmed Pattern (ADR-004)
# ─────────────────────────────────────────────

## Client-seitige Anfrage: Quest starten. Default player_id=1 → Tier 1 unverändert.
func request_start_quest(quest_id: String, player_id: int = 1) -> bool:
	if quest_id.is_empty():
		Logger.log_error("request_start_quest(): quest_id ist leer!", LOG_CAT)
		return false
	var bucket := _ensure_player(player_id)
	var c_quests: Array[String] = bucket["completed"] as Array[String]
	var a_quests: Dictionary = bucket["active"]
	if c_quests.has(quest_id):
		_bus.quest().emit_quest_start_failed(quest_id, "already_completed")
		return false
	if a_quests.has(quest_id):
		_bus.quest().emit_quest_start_failed(quest_id, "already_active")
		return false

	var def: QuestDefinition = _definitions.get(quest_id)
	if def:
		for prereq in def.prerequisites:
			if not c_quests.has(prereq):
				_bus.quest().emit_quest_start_failed(quest_id, "prereq_missing:%s" % prereq)
				return false

	# Tier 1: direkter Aufruf. Tier 2/3: via NetworkBridge an die Autorität senden.
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		_network.rpc_id(1, "_rpc_start_quest", quest_id)
	else:
		on_quest_start_confirmed(quest_id, player_id)
	return true

## Authority-Mutation: schreibt Quest-State für player_id. Public (ADR-004) — direkt via RPC aufrufbar.
## C-02: Authority Guard — verweigert auf Nicht-Autorität wenn Peer gesetzt.
func on_quest_start_confirmed(quest_id: String, player_id: int = 1) -> void:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		Logger.log_error(
			"on_quest_start_confirmed: Aufruf auf Nicht-Autorität — verweigert.", LOG_CAT
		)
		return
	if quest_id.is_empty():
		Logger.log_error("on_quest_start_confirmed: quest_id ist leer!", LOG_CAT)
		return

	var bucket := _ensure_player(player_id)
	var def: QuestDefinition = _definitions.get(quest_id)
	if def:
		bucket["active"][quest_id] = QuestProgressRecord.create_new(def)
	else:
		var empty_rec := QuestProgressRecord.new()
		empty_rec.quest_id = quest_id
		bucket["active"][quest_id] = empty_rec
	(bucket["available"] as Array).erase(quest_id)
	_bus.quest().emit_quest_started(quest_id)
	Logger.log_info("Quest gestartet: '%s' (Spieler %d)." % [quest_id, player_id], LOG_CAT)

func request_complete_quest(quest_id: String, player_id: int = 1) -> void:
	var bucket := _ensure_player(player_id)
	if not (bucket["active"] as Dictionary).has(quest_id):
		return
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		_network.rpc_id(1, "_rpc_complete_quest", quest_id)
	else:
		on_quest_complete_confirmed(quest_id, player_id)

## Authority-Mutation: schreibt Quest-Complete-State für player_id. Public (ADR-004) — direkt via RPC aufrufbar.
## C-02: Authority Guard — verweigert auf Nicht-Autorität wenn Peer gesetzt.
func on_quest_complete_confirmed(quest_id: String, player_id: int = 1) -> void:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		Logger.log_error(
			"on_quest_complete_confirmed: Aufruf auf Nicht-Autorität — verweigert.", LOG_CAT
		)
		return
	if quest_id.is_empty():
		Logger.log_error("on_quest_complete_confirmed: quest_id ist leer!", LOG_CAT)
		return

	var bucket := _ensure_player(player_id)
	var active: Dictionary = bucket["active"]
	if not active.has(quest_id):
		return

	active.erase(quest_id)
	(bucket["completed"] as Array).append(quest_id)

	var def: QuestDefinition = _definitions.get(quest_id)
	var reward: QuestReward  = def.reward if (def and def.reward) else null

	if reward and is_instance_valid(_reward_dispatcher):
		_reward_dispatcher.dispatch(reward)
	elif reward:
		Logger.log_warn("RewardDispatcher fehlt — Reward für '%s' nicht ausgezahlt!" % quest_id, LOG_CAT)

	_bus.quest().emit_quest_completed(quest_id, reward)
	Logger.log_info("Quest abgeschlossen: '%s' (Spieler %d)." % [quest_id, player_id], LOG_CAT)
	_unlock_followup_quests(quest_id, player_id)

func fail_quest(quest_id: String, player_id: int = 1) -> void:
	var bucket := _ensure_player(player_id)
	if not (bucket["active"] as Dictionary).has(quest_id):
		return
	(bucket["active"] as Dictionary).erase(quest_id)
	_bus.quest().emit_quest_failed(quest_id)

func unlock_quest(quest_id: String, player_id: int = 1) -> void:
	var bucket := _ensure_player(player_id)
	var completed: Array[String] = bucket["completed"] as Array[String]
	var active: Dictionary = bucket["active"]
	var available: Array[String]   = bucket["available"] as Array[String]
	if completed.has(quest_id) or active.has(quest_id):
		return
	if not available.has(quest_id):
		available.append(quest_id)
		_bus.quest().emit_quest_unlocked(quest_id)
		Logger.log_info("Quest freigeschaltet: '%s' (Spieler %d)." % [quest_id, player_id], LOG_CAT)

func update_objective(quest_id: String, objective_id: String, delta: int, player_id: int = 1) -> void:
	var bucket := _ensure_player(player_id)
	var active: Dictionary = bucket["active"]
	if not active.has(quest_id):
		return

	var record: QuestProgressRecord = active[quest_id]
	var def: QuestDefinition        = _definitions.get(quest_id)
	if def == null:
		return

	var required := 1
	for obj in def.objectives:
		if obj.id == objective_id:
			required = obj.required
			break

	var new_val := record.update_progress(objective_id, delta, required)

	Logger.log_debug(
		"Objective '%s/%s': %d (+%d) / %d (Spieler %d)." % [quest_id, objective_id, new_val, delta, required, player_id],
		LOG_CAT
	)
	_bus.quest().emit_objective_updated(quest_id, objective_id, new_val, required)

	var record2: QuestProgressRecord = active.get(quest_id)
	var def2: QuestDefinition = _definitions.get(quest_id)
	if record2 != null and def2 != null and record2.is_complete(def2):
		request_complete_quest(quest_id, player_id)

func is_quest_active(quest_id: String, player_id: int = 1)    -> bool:
	return (_players.get(player_id, {"active": {}}) as Dictionary).get("active", {}).has(quest_id)

func is_quest_completed(quest_id: String, player_id: int = 1) -> bool:
	return ((_players.get(player_id, {"completed": []}) as Dictionary).get("completed", []) as Array).has(quest_id)

func get_quest_definition(quest_id: String) -> QuestDefinition:
	return _definitions.get(quest_id)

func get_objective_progress(quest_id: String, objective_id: String, player_id: int = 1) -> int:
	var bucket: Dictionary = _players.get(player_id, {})
	var active: Dictionary = bucket.get("active", {})
	if not active.has(quest_id):
		return 0
	var rec: QuestProgressRecord = active[quest_id]
	return rec.objectives.get(objective_id, 0)

# ─────────────────────────────────────────────
# Event-Handler → delegiert an QuestObjectiveHandler
# ─────────────────────────────────────────────

func _on_loot_collected(item_id: String, quantity: int) -> void:
	# Tier 1: alle Quest-Updates für Spieler 1
	for upd in QuestObjectiveHandler.resolve_loot(item_id, quantity, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])

func _on_xp_gained(skill_name: String, _amount: int) -> void:
	for upd in QuestObjectiveHandler.resolve_xp(skill_name, active_quests, _definitions, _skill_system):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])

func _on_interaction_finished(action_id: String, _label: String) -> void:
	for upd in QuestObjectiveHandler.resolve_interaction(action_id, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])

func _on_enemy_killed(enemy_type_id: String, _position: Vector3) -> void:
	# Tier 1: KILL-Objectives für Spieler 1.
	# Tier 2/3: Multi-Tenant erfordert dass enemy_killed ein player_id-Argument trägt.
	# Dieses Signal kommt von EnemyNPC._die() das bislang keinen Spieler-Kontext hat —
	# das ist ein bekannter Tech Debt für die Multiplayer-Phase.
	for upd in QuestObjectiveHandler.resolve_kill(enemy_type_id, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])

func _on_npc_talked_to(npc_id: String) -> void:
	# Tier 1: TALK-Objectives für Spieler 1 (gleicher bekannter Tech Debt wie KILL —
	# npc_talked_to trägt noch keinen player_id-Kontext).
	for upd in QuestObjectiveHandler.resolve_talk(npc_id, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])

func _on_custom_objective_triggered(signal_key: String) -> void:
	for upd in QuestObjectiveHandler.resolve_custom(signal_key, active_quests, _definitions):
		update_objective(upd["quest_id"], upd["obj_id"], upd["delta"])

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _unlock_followup_quests(completed_id: String, player_id: int = 1) -> void:
	var bucket := _ensure_player(player_id)
	var completed: Array[String]    = bucket["completed"] as Array[String]
	var active: Dictionary  = bucket["active"]
	for quest_id in _definitions:
		var def: QuestDefinition = _definitions[quest_id]
		if completed.has(quest_id) or active.has(quest_id):
			continue
		if not def.prerequisites.has(completed_id):
			continue
		var all_met := true
		for prereq in def.prerequisites:
			if not completed.has(prereq):
				all_met = false
				break
		if all_met:
			unlock_quest(quest_id, player_id)
			if def.auto_start:
				request_start_quest(quest_id, player_id)

func _restore_from_save(saved_data: Dictionary) -> void:
	# Format: { "1": { active: {...}, completed: [...], available: [...] }, ... }
	for pid_str in saved_data:
		var pid: int = int(pid_str)
		var raw: Dictionary = saved_data[pid_str] as Dictionary if saved_data[pid_str] is Dictionary else {}
		var bucket := _ensure_player(pid)

		var saved_active: Variant = raw.get("active", {})
		if saved_active is Dictionary:
			for quest_id in (saved_active as Dictionary).keys():
				var def: QuestDefinition = _definitions.get(quest_id)
				if def == null:
					Logger.log_warn("Quest '%s' nicht in Definitionen — Save-Eintrag verworfen." % quest_id, LOG_CAT)
					continue
				var raw_entry: Variant = (saved_active as Dictionary)[quest_id]
				var entry_dict := raw_entry as Dictionary if raw_entry is Dictionary else {}
				bucket["active"][quest_id] = QuestProgressRecord.from_save(quest_id, entry_dict, def)

		var saved_completed: Variant = raw.get("completed", [])
		var completed_arr: Array[String] = []
		if saved_completed is Array:
			for v in (saved_completed as Array):
				completed_arr.append(str(v))
		bucket["completed"] = completed_arr

		var saved_available: Variant = raw.get("available", [])
		var available_arr: Array[String] = []
		if saved_available is Array:
			for v in (saved_available as Array):
				available_arr.append(str(v))
		bucket["available"] = available_arr

	Logger.log_info(
		"Quest-State geladen: aktiv=%d, abgeschlossen=%d, verfügbar=%d."
		% [active_quests.size(), completed_quests.size(), available_quests.size()],
		LOG_CAT
	)
