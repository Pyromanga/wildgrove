extends Service
class_name CharacterCreationService

## ADR-048: Charaktererstellung / Onboarding-Fragenreihe.
##
## Vorgabe: eine kurze Fragenreihe (ähnlich Animal Crossing) bestimmt beim
## ersten Login sowohl das Aussehen als auch "Charakterzüge" des Spielers.
## Der Spieler wählt Antworten, NICHT direkt ein Aussehen — das Aussehen wird
## aus den Antworten ABGELEITET (Mehrheitsentscheid über die vier
## `APPEARANCE_ARCHETYPES`, siehe `_derive_appearance()`). Presets sind für
## diese Runde bewusst grob (vier feste Farbtöne) — Feintuning (Slider) ist
## explizit NICHT Teil dieser Runde, siehe unten.
##
## KOSMETISCH-ONLY (bewusste Entscheidung, 2026-08 — noch nicht final):
## Charakterzüge haben in dieser Runde AUSSCHLIESSLICH kosmetische Wirkung
## (Aussehen). Kein Effekt auf Stats/Dialoge. Zwei Ausbaustufen sind als
## Spike vorgemerkt (siehe `TODO-offene-probleme.md`): (a) reine
## Flavor-Wirkung (NPC-Dialoge reagieren auf `get_traits()`), (b) echte
## Stat-Boni über `StatModifierService`. Beides bewusst NICHT in dieser
## Runde entschieden — `get_traits()` existiert bereits jetzt, damit ein
## künftiger Spike ohne Datenmodell-Umbau andocken kann.
##
## AUTORITÄT (Round 106 nachgezogen — vorher exakt der Round-102-Kompromiss
## von `AchievementService`, siehe ADR-048 "Autorität"):
## `on_submit_answers_confirmed()`/`on_skip_creation_confirmed()` laufen nur
## auf der Autorität (`_require_authority()`). `request_submit_answers()`/
## `request_skip_creation()` sind die neuen Client-Einstiegspunkte —
## identisches Verzweigungsmuster wie `ReportService.request_submit_report()`:
## ohne echten Peer oder auf dem Host läuft das direkt in
## `on_*_confirmed()`, ein Nicht-Host-Client schickt stattdessen ein RPC
## (`NetworkBridge.send_character_creation_submit_answers()`/
## `send_character_creation_skip()`).
##
## RÜCKKANAL: anders als bei `ReportService` (reine Einbahnstraße, Meldungen
## sind nie für den Melder selbst relevant) braucht der anfragende Client
## hier das Ergebnis zurück — sein eigenes Aussehen. Die Autorität schickt
## nach `on_*_confirmed()` gezielt an den betroffenen Spieler zurück
## (`send_character_creation_completed_for_player()`/
## `send_character_creation_skipped_for_player()`, überspringt den lokalen
## Peer — identisches Guard-/Skip-Local-Muster wie
## `send_achievement_unlocked_for_player()`). `_on_remote_creation_completed_
## received()`/`_on_remote_creation_skipped_received()` übernehmen das
## Ergebnis clientseitig direkt in `_seen`/`_completed`/`_appearance`/
## `_traits` (ohne `_require_authority()` — hier wird nichts neu
## entschieden, nur gespiegelt, exakt `AchievementService._on_remote_unlock_
## received()`s Kommentar). Beide Pfade emittieren dasselbe neue
## `character_creation_confirmed`-Signal — bewusst NICHT `character_created`/
## `character_creation_skipped` wiederverwendet, weil die laut
## `AchievementService`-Klassenkommentar ("TRIGGER-QUELLEN") nachweislich
## AUSSCHLIESSLICH auf der Autorität feuern dürfen; ein Re-Emit auf dem
## Client würde dort ungewollt `grant_progress()` anstoßen (hinter
## `_require_authority()` zwar folgenlos, aber unnötiger Log-Lärm) und die
## dokumentierte Invariante brechen.
##
## PERSISTENZ: `SAVE_KEY = "character_creation"`, Save-Interface analog
## `StatsService`/`AchievementService`.
##
## TRIGGER-QUELLE für `AchievementService` (Round 105, siehe dort):
## `character_created`/`character_creation_skipped` — fünfte/sechste
## Trigger-Quelle neben PvP-Kill/Auktion/Meldung/Statistiken.
##
## BEWUSST NICHT TEIL DIESER RUNDE:
##   - Kein Feintuning-Editor (Farbwähler/Slider) — nur die vier
##     Archetyp-Presets, automatisch aus den Antworten abgeleitet.
##   - Kein Hook von hier in Richtung Tutorial-Guide-NPC — Teil 2 der
##     ursprünglichen Vorgabe ("...danach Spawn + erklärender NPC") ist
##     seit Round 106 als eigenständiger, unabhängig platzierter NPC
##     umgesetzt (`TutorialGuideNPC`, `scripts/onboarding/`), NICHT als
##     Fortsetzung des Charaktererstellungs-Flows — der NPC steht einfach
##     nahe dem Spawnpunkt, kein direkter Übergang vom Willkommens-Toast
##     zum Guide-Dialog.
##   - Keine Gameplay-Wirkung der Charakterzüge — siehe "KOSMETISCH-ONLY".
##   - Kein Broadcast des Aussehens an ANDERE Spieler (der RPC-Rückkanal
##     aus Round 106 informiert ausschließlich den betroffenen Spieler
##     selbst über sein eigenes Ergebnis) — andere Peers sähen die farbige
##     Anwendung auf einem entfernten Player-Mesh in dieser Runde noch
##     nicht. Analog zum PlayerVisuals-Gap aus Round 105 (siehe UI-
##     Controller-Kommentar), aber eine eigene, noch offene Lücke.

const LOG_CAT := "CharacterCreationService"
const SAVE_KEY := "character_creation"

## preset_id -> { label, color }. Vier bewusst grobe Archetypen —
## Mehrheitsentscheid über die Antworten wählt einen davon.
const APPEARANCE_ARCHETYPES: Dictionary = {
	"sonnig": {"label": "Sonnig",   "trait_id": "lebhaft",        "color": Color(0.95, 0.75, 0.25)},
	"wald":   {"label": "Waldig",   "trait_id": "naturverbunden", "color": Color(0.25, 0.55, 0.25)},
	"flut":   {"label": "Flutig",   "trait_id": "besonnen",       "color": Color(0.25, 0.45, 0.75)},
	"asche":  {"label": "Aschig",   "trait_id": "eigenwillig",    "color": Color(0.55, 0.45, 0.60)},
}

## Default-Aussehen für übersprungene Charaktererstellung — bewusst ein
## neutraler fünfter Farbton statt eines der vier Archetypen, damit
## übersprungene Charaktere sichtbar (aber nicht abwertend) anders aussehen.
const DEFAULT_APPEARANCE_ID := "unbestimmt"
const DEFAULT_APPEARANCE_COLOR := Color(0.6, 0.6, 0.6)

## Vier Fragen, jede mit denselben vier Archetyp-Optionen (Reihenfolge pro
## Frage variiert bewusst, damit es sich nicht wie derselbe Klick viermal
## anfühlt) — hält das Datenmodell trivial: Mehrheit über `preset_id` der
## gegebenen Antworten entscheidet, siehe `_derive_appearance()`.
const QUESTIONS: Array = [
	{
		"id": "free_day",
		"text": "Was tust du lieber an einem freien Tag?",
		"options": [
			{"id": "a", "preset_id": "wald",   "label": "Durch den Wald streifen"},
			{"id": "b", "preset_id": "flut",   "label": "Am Wasser sitzen und nachdenken"},
			{"id": "c", "preset_id": "sonnig", "label": "Mit anderen ein Lagerfeuer machen"},
			{"id": "d", "preset_id": "asche",  "label": "Allein etwas Neues ausprobieren"},
		],
	},
	{
		"id": "challenge",
		"text": "Wie reagierst du auf eine Herausforderung?",
		"options": [
			{"id": "a", "preset_id": "sonnig", "label": "Kopf durch, sofort anpacken"},
			{"id": "b", "preset_id": "flut",   "label": "Erst beobachten, dann handeln"},
			{"id": "c", "preset_id": "wald",   "label": "Geduldig einen eigenen Weg finden"},
			{"id": "d", "preset_id": "asche",  "label": "Eigene Regeln aufstellen"},
		],
	},
	{
		"id": "company",
		"text": "In Gesellschaft bist du eher…",
		"options": [
			{"id": "a", "preset_id": "sonnig", "label": "Der/die Wortführer/in"},
			{"id": "b", "preset_id": "asche",  "label": "Der/die Eigenbrötler/in"},
			{"id": "c", "preset_id": "wald",   "label": "Der/die Zuhörer/in"},
			{"id": "d", "preset_id": "flut",   "label": "Der/die Vermittler/in"},
		],
	},
	{
		"id": "value",
		"text": "Was ist dir am wichtigsten?",
		"options": [
			{"id": "a", "preset_id": "flut",   "label": "Ruhe und Klarheit"},
			{"id": "b", "preset_id": "wald",   "label": "Verbindung zur Natur"},
			{"id": "c", "preset_id": "sonnig", "label": "Gemeinschaft"},
			{"id": "d", "preset_id": "asche",  "label": "Unabhängigkeit"},
		],
	},
]

## Emittiert nach erfolgreichem submit_answers() — die Trigger-Quelle für
## AchievementService (character_creator_complete).
signal character_created(player_id: String, appearance_preset_id: String, traits: Array)

## Emittiert nach skip_creation() — die Trigger-Quelle für AchievementService
## (character_creator_skipped).
signal character_creation_skipped(player_id: String)

## Round 106: emittiert IMMER auf dem anfragenden Peer, sobald das Ergebnis
## von request_submit_answers()/request_skip_creation() feststeht — direkt
## am Ende von on_submit_answers_confirmed()/on_skip_creation_confirmed()
## auf Tier 1/Host, oder nach Empfang des RPC-Rückkanals auf einem
## Nicht-Host-Client. Der UI-Controller hört darauf statt synchron
## anzunehmen, dass request_*() sofort fertig ist (siehe Klassenkommentar
## "AUTORITÄT"). BEWUSST NICHT character_created/character_creation_skipped
## wiederverwendet — siehe Klassenkommentar.
signal character_creation_confirmed(player_id: String)

var _save_system: SaveSystem = null
var _network: NetworkBridge = null
## Round 106: nur für _local_player_id() auf dem Client — bestimmt, für wen
## ankommende character_creation_completed_received/_skipped_received-RPCs
## lokal übernommen werden. Identisches Muster wie
## AchievementService._session_manager (Round 104).
var _session_manager: SessionManager = null

## player_id -> true, sobald submit_answers() ODER skip_creation() lief.
## Bestimmt, ob die Fragenreihe beim nächsten Login erneut gezeigt wird.
var _seen: Dictionary = {}

## player_id -> true nur bei tatsächlich abgeschlossener Fragenreihe
## (submit_answers()), false/fehlend bei übersprungen.
var _completed: Dictionary = {}

## player_id -> preset_id (Schlüssel in APPEARANCE_ARCHETYPES, oder
## DEFAULT_APPEARANCE_ID bei übersprungener Erstellung).
var _appearance: Dictionary = {}

## player_id -> Array[String] gewählter trait_ids (leer bei übersprungen).
var _traits: Dictionary = {}

func configure(deps: ServiceDeps) -> void:
	_save_system     = deps.get_optional(ServiceKeys.SAVE_SYSTEM)     as SaveSystem
	_network         = deps.get_optional(ServiceKeys.NETWORK_BRIDGE)  as NetworkBridge
	_session_manager = deps.get_optional(ServiceKeys.SESSION_MANAGER) as SessionManager
	_connect_network_receive()

	if _save_system:
		_save_system.register_save_provider(self)
		var saved: Variant = _save_system.get_state_for(SAVE_KEY)
		if saved is Dictionary and not (saved as Dictionary).is_empty():
			_restore_from_save(saved)
	else:
		AppLogger.log_error("Abhängigkeit 'savesystem' fehlt!", LOG_CAT)

	AppLogger.log_info("CharacterCreationService initialisiert.", LOG_CAT)

func inject_network_bridge(network: NetworkBridge) -> void:
	_network = network
	_connect_network_receive()

func on_cleanup() -> void:
	if is_instance_valid(_network):
		if _network.character_creation_completed_received.is_connected(_on_remote_creation_completed_received):
			_network.character_creation_completed_received.disconnect(_on_remote_creation_completed_received)
		if _network.character_creation_skipped_received.is_connected(_on_remote_creation_skipped_received):
			_network.character_creation_skipped_received.disconnect(_on_remote_creation_skipped_received)

## Round 106: Gegenstück zu on_submit_answers_confirmed()/
## on_skip_creation_confirmed() (beide über _require_authority() für
## Nicht-Autorität gesperrt) — übernimmt Server-Antworten auf dem Client
## OHNE den Authority-Guard, weil hier keine eigene Mutation stattfindet,
## nur Übernahme eines bereits autoritativ entschiedenen Zustands. Exakt
## das Verdrahtungsmuster von AchievementService._connect_network_receive().
func _connect_network_receive() -> void:
	if not is_instance_valid(_network):
		return
	if not _network.character_creation_completed_received.is_connected(_on_remote_creation_completed_received):
		_network.character_creation_completed_received.connect(_on_remote_creation_completed_received)
	if not _network.character_creation_skipped_received.is_connected(_on_remote_creation_skipped_received):
		_network.character_creation_skipped_received.connect(_on_remote_creation_skipped_received)

# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## true, wenn player_id die Fragenreihe schon gesehen hat (abgeschlossen
## ODER übersprungen) — UI zeigt sie dann nicht erneut.
func has_seen_creation(player_id: String) -> bool:
	return bool(_seen.get(player_id, false))

func get_questions() -> Array:
	return QUESTIONS.duplicate(true)

func get_appearance_archetypes() -> Dictionary:
	return APPEARANCE_ARCHETYPES.duplicate(true)

## Round 106: Client-seitiger Einstiegspunkt — analog
## ReportService.request_submit_report(). Ohne echten Peer (Tier 1) oder auf
## dem Host läuft das direkt in on_submit_answers_confirmed(); ein
## Nicht-Host-Client schickt stattdessen ein RPC an die Autorität.
func request_submit_answers(player_id: String, answers: Dictionary) -> void:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		_network.send_character_creation_submit_answers(player_id, answers)
	else:
		on_submit_answers_confirmed(player_id, answers)

## answers: Dictionary(question_id -> option_id). Fehlende/unbekannte
## Fragen werden ignoriert (kein harter Fehler — Antwortreihe muss nicht
## vollständig sein, Mehrheitsentscheid funktioniert auch mit weniger
## Antworten, solange mindestens eine gültig ist).
func on_submit_answers_confirmed(player_id: String, answers: Dictionary) -> void:
	if not _require_authority("on_submit_answers_confirmed"):
		return
	if player_id.is_empty():
		AppLogger.log_warn("on_submit_answers_confirmed(): leere player_id — ignoriert.", LOG_CAT)
		return

	var traits: Array = []
	var preset_counts: Dictionary = {}
	for question in QUESTIONS:
		var q: Dictionary = question
		var question_id: String = q["id"]
		if not answers.has(question_id):
			continue
		var chosen_option_id: String = String(answers[question_id])
		for option in (q["options"] as Array):
			var opt: Dictionary = option
			if opt["id"] != chosen_option_id:
				continue
			var preset_id: String = opt["preset_id"]
			preset_counts[preset_id] = int(preset_counts.get(preset_id, 0)) + 1
			var trait_id: String = String((APPEARANCE_ARCHETYPES.get(preset_id, {}) as Dictionary).get("trait_id", ""))
			if not trait_id.is_empty() and trait_id not in traits:
				traits.append(trait_id)
			break

	var appearance_id := _pick_majority_preset(preset_counts)

	_seen[player_id] = true
	_completed[player_id] = true
	_appearance[player_id] = appearance_id
	_traits[player_id] = traits

	AppLogger.log_info(
		"on_submit_answers_confirmed('%s'): Aussehen='%s', Charakterzüge=%s." % [player_id, appearance_id, str(traits)],
		LOG_CAT
	)
	character_created.emit(player_id, appearance_id, traits)
	character_creation_confirmed.emit(player_id)
	if is_instance_valid(_network):
		_network.send_character_creation_completed_for_player(player_id, {
			"appearance_preset_id": appearance_id,
			"traits": traits,
		})

## Round 106: Client-seitiger Einstiegspunkt — analog
## request_submit_answers().
func request_skip_creation(player_id: String) -> void:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		_network.send_character_creation_skip(player_id)
	else:
		on_skip_creation_confirmed(player_id)

## Bricht ohne Fragenreihe ab — Aussehen fällt auf DEFAULT_APPEARANCE_ID
## zurück, keine Charakterzüge gesetzt.
func on_skip_creation_confirmed(player_id: String) -> void:
	if not _require_authority("on_skip_creation_confirmed"):
		return
	if player_id.is_empty():
		AppLogger.log_warn("on_skip_creation_confirmed(): leere player_id — ignoriert.", LOG_CAT)
		return

	_seen[player_id] = true
	_completed[player_id] = false
	_appearance[player_id] = DEFAULT_APPEARANCE_ID
	_traits[player_id] = []

	AppLogger.log_info("on_skip_creation_confirmed('%s'): Charaktererstellung übersprungen." % player_id, LOG_CAT)
	character_creation_skipped.emit(player_id)
	character_creation_confirmed.emit(player_id)
	if is_instance_valid(_network):
		_network.send_character_creation_skipped_for_player(player_id, {})

func get_appearance_preset_id(player_id: String) -> String:
	return String(_appearance.get(player_id, DEFAULT_APPEARANCE_ID))

## Gibt die Godot-Farbe für den aktuellen Preset von player_id zurück —
## direkt konsumierbar von PlayerVisuals.apply_appearance().
func get_appearance_color(player_id: String) -> Color:
	var preset_id := get_appearance_preset_id(player_id)
	if APPEARANCE_ARCHETYPES.has(preset_id):
		return (APPEARANCE_ARCHETYPES[preset_id] as Dictionary)["color"]
	return DEFAULT_APPEARANCE_COLOR

func get_traits(player_id: String) -> Array:
	return (_traits.get(player_id, []) as Array).duplicate()

func is_completed(player_id: String) -> bool:
	return bool(_completed.get(player_id, false))

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

## Höchste Stimmenzahl gewinnt; bei Gleichstand entscheidet die
## Iterationsreihenfolge von APPEARANCE_ARCHETYPES (stabil, weil GDScript-
## Dictionaries Einfüge-Reihenfolge erhalten) — deterministisch statt
## zufällig, damit dasselbe Antwortmuster immer dasselbe Aussehen ergibt.
func _pick_majority_preset(preset_counts: Dictionary) -> String:
	if preset_counts.is_empty():
		return DEFAULT_APPEARANCE_ID
	var best_id := DEFAULT_APPEARANCE_ID
	var best_count := -1
	for preset_id in APPEARANCE_ARCHETYPES.keys():
		var count: int = int(preset_counts.get(preset_id, 0))
		if count > best_count:
			best_count = count
			best_id = preset_id
	return best_id

func _require_authority(caller: String) -> bool:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		AppLogger.log_error("%s: Aufruf auf Nicht-Autorität — verweigert." % caller, LOG_CAT)
		return false
	return true

# ─────────────────────────────────────────────
# Client-Empfang (Round 106) — Gegenstück zu on_submit_answers_confirmed()/
# on_skip_creation_confirmed() auf einem Nicht-Autoritäts-Peer. Übernimmt
# Server-Payloads direkt in _seen/_completed/_appearance/_traits statt über
# on_*_confirmed() zu laufen (die beide _require_authority() erzwingen) —
# hier wird nichts neu entschieden, nur ein bereits von der Autorität
# getroffenes Ergebnis gespiegelt. Exakt AchievementService._on_remote_
# unlock_received().
# ─────────────────────────────────────────────

func _local_player_id() -> String:
	return _session_manager.get_local_player_id() if is_instance_valid(_session_manager) else ""

## Payload enthält keine player_id (siehe NetworkBridge.
## send_character_creation_completed_for_player() — Adressierung läuft
## bereits über rpc_id an den Ziel-Peer) — der Empfänger IST der betroffene
## Spieler.
func _on_remote_creation_completed_received(payload: Dictionary) -> void:
	var player_id := _local_player_id()
	if player_id.is_empty():
		AppLogger.log_error("_on_remote_creation_completed_received: lokale player_id unbekannt (SessionManager fehlt?).", LOG_CAT)
		return
	_seen[player_id] = true
	_completed[player_id] = true
	_appearance[player_id] = String(payload.get("appearance_preset_id", DEFAULT_APPEARANCE_ID))
	_traits[player_id] = (payload.get("traits", []) as Array).duplicate()
	character_creation_confirmed.emit(player_id)

func _on_remote_creation_skipped_received(_payload: Dictionary) -> void:
	var player_id := _local_player_id()
	if player_id.is_empty():
		AppLogger.log_error("_on_remote_creation_skipped_received: lokale player_id unbekannt (SessionManager fehlt?).", LOG_CAT)
		return
	_seen[player_id] = true
	_completed[player_id] = false
	_appearance[player_id] = DEFAULT_APPEARANCE_ID
	_traits[player_id] = []
	character_creation_confirmed.emit(player_id)

# ─────────────────────────────────────────────
# Save-Interface (analog StatsService/AchievementService)
# ─────────────────────────────────────────────

func get_save_key() -> String:
	return SAVE_KEY

func get_save_data() -> Dictionary:
	return {
		"seen": _seen,
		"completed": _completed,
		"appearance": _appearance,
		"traits": _traits,
	}

func _restore_from_save(saved: Dictionary) -> void:
	if saved.get("seen") is Dictionary:
		_seen = saved["seen"]
	if saved.get("completed") is Dictionary:
		_completed = saved["completed"]
	if saved.get("appearance") is Dictionary:
		_appearance = saved["appearance"]
	if saved.get("traits") is Dictionary:
		_traits = saved["traits"]
