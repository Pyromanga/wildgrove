class_name ChunkEntitySpawner
extends RefCounted

## ChunkEntitySpawner — Spawnt Props/Tiere/Gegner für einen Chunk.
##
## Extrahiert aus ChunkManager._spawn_chunk_entities().
## Deterministisch über (chunk_seed ^ coord): gleicher Seed → gleiche Entities.
##
## Spawn-Callable wird per DI injiziert (_init-Parameter) — kein direkter
## Service-Zugriff. Konsistent mit dem übrigen DI-Modell des Projekts.
##
## Round 75: Props/Gegner werden jetzt tatsächlich über BiomeDefinition.
## prop_chances/enemy_chances des Chunks gewählt (vorher: hartcodiert
## "oak_tree"). Biom wird EINMAL pro Chunk am Chunk-Zentrum gesampelt (nicht
## pro Prop) — bei der aktuellen Biom-Noise-Wellenlänge (~285m, BIOME_FREQ
## 0.0035) liegt ein 64m-Chunk nur selten auf einer Biom-Grenze; exaktere
## Pro-Prop-Sampling wäre möglich, aber 3-4× mehr Noise-Aufrufe pro Chunk für
## einen in der Praxis seltenen Randfall — bewusst nicht gemacht, siehe
## TODO-offene-probleme.md falls das mal zum echten Problem wird (sichtbare
## "Biom-Kante mitten im Chunk" mit falscher Vegetation).

const LOG_CAT      := "ChunkEntitySpawner"
const ENTITY_MARGIN := 6.0  # Abstand zum Chunk-Rand
## Mindesthöhe ÜBER dem Wasserspiegel, ab der etwas spawnt (Uferstreifen bleibt frei —
## keine Bäume im Wasser, keine Tiere am Beckenrand).
const SHORE_MARGIN := 0.3

var _chunk_size:   float
var _base_seed:    int
var _spawn_entity: Callable
## Optional: func(type_id: String, pos: Vector3) -> bool — bereits abgeerntete Objekte (Bäume,
## Erze) entstehen beim erneuten Laden des Chunks nicht wieder (WorldData.harvested_objects).
var _is_harvested: Callable

## { Vector2i: Array[Node3D] } — was dieser Spawner pro Chunk erzeugt hat. Ohne diese Buchführung
## blieben Bäume/Tiere eines entladenen Chunks für immer in der Welt (schwebend) und würden beim
## Zurückkehren doppelt entstehen.
var _spawned: Dictionary = {}
var _bucket: Array[Node3D] = []

func _init(
	chunk_size: float, base_seed: int, spawn_entity_cb: Callable,
	is_harvested_cb: Callable = Callable()
) -> void:
	_chunk_size   = chunk_size
	_base_seed    = base_seed
	_spawn_entity = spawn_entity_cb
	_is_harvested = is_harvested_cb

## Entfernt alle Entities, die spawn_for_chunk(coord) erzeugt hat. unload_cb: func(node: Node3D) -> void
## (WorldService: EntityOrchestrator.unload_entity — NICHT despawn_entity, siehe dort).
## Schon anderweitig freigegebene Entities (gefällter Baum, getötetes Tier) werden übersprungen.
func despawn_for_chunk(coord: Vector2i, unload_cb: Callable) -> void:
	var nodes: Array = _spawned.get(coord, [])
	_spawned.erase(coord)
	if not unload_cb.is_valid():
		return
	for node in nodes:
		if is_instance_valid(node):
			unload_cb.call(node)

func get_spawned_count(coord: Vector2i) -> int:
	var n: int = 0
	for node in _spawned.get(coord, []):
		if is_instance_valid(node):
			n += 1
	return n

## Spawnt EINE Entity, merkt sie sich für den Chunk und überspringt bereits Abgeerntetes.
func _spawn(type_id: String, pos: Vector3) -> void:
	if _is_harvested.is_valid() and bool(_is_harvested.call(type_id, pos)):
		return
	var node: Variant = _spawn_entity.call(type_id, pos)
	if is_instance_valid(node) and node is Node3D:
		_bucket.append(node as Node3D)

## Spawnt Props/Tiere/Gegner für coord.
## center: Chunk-Zentrum in Weltkoordinaten (Vector2).
## gen: TerrainField für Höhen-/Biom-/Wasser-Lookup (alles in Weltkoordinaten).
func spawn_for_chunk(coord: Vector2i, center: Vector2, gen: TerrainField) -> void:
	if not _spawn_entity.is_valid():
		return

	# Doppelt laden (ohne Entladen dazwischen) darf nichts verdoppeln.
	if _spawned.has(coord):
		return
	_bucket = []

	var half: float = _chunk_size * 0.5 - ENTITY_MARGIN
	var rng := RandomNumberGenerator.new()
	rng.seed = _base_seed ^ (coord.x * 1234567) ^ (coord.y * 7654321)

	# Round 75: EINMAL pro Chunk gesampelt (siehe Klassenkommentar), am Chunk-Zentrum.
	var biome: BiomeDefinition = gen.get_biome_at(center.x, center.y)

	_spawn_props(biome, center, gen, rng, half)
	_spawn_animal(coord, center, gen, rng, half)
	_spawn_enemy(coord, biome, center, gen, rng, half)

	_spawned[coord] = _bucket
	_bucket = []

func _spawn_props(
	biome: BiomeDefinition, center: Vector2, gen: TerrainField,
	rng: RandomNumberGenerator, half: float
) -> void:
	if not is_instance_valid(biome) or biome.prop_chances.is_empty():
		return
	# TUNING (2026-09-20, Wunsch "Spawnrate von Bäumen usw deutlich erhöhen"):
	# vorher 1-4 Props/Chunk — spürbar leere Landschaft. Hochgesetzt auf 4-10.
	var count := rng.randi_range(4, 10)
	for _i in range(count):
		var lx: float = rng.randf_range(-half, half)
		var lz: float = rng.randf_range(-half, half)
		var h:  float = gen.get_height_at(center.x + lx, center.y + lz)
		if h <= gen.get_water_level_at(center.x + lx, center.y + lz) + SHORE_MARGIN:
			continue
		var type_id: String = _roll_weighted_type(
			biome.prop_chances, WorldEntityRegistry.KNOWN_PROP_TYPES, rng
		)
		if not type_id.is_empty():
			_spawn(type_id, Vector3(center.x + lx, h, center.y + lz))

func _spawn_animal(
	coord: Vector2i, center: Vector2, gen: TerrainField,
	rng: RandomNumberGenerator, half: float
) -> void:
	# Jeder dritte Chunk bekommt ein Tier (deterministisch)
	# Unverändert (Round 75): Anfrage betraf nur Props/Gegner (Kaktus/Skelett),
	# Tiere absichtlich nicht angefasst — kein biomspezifisches Verhalten
	# gewünscht/gefordert, kleinere Diff.
	if (abs(coord.x) + abs(coord.y)) % 3 != 0:
		return

	var types: Array[String] = ["deer", "rabbit", "boar"]
	var animal_type: String  = types[rng.randi_range(0, 2)]
	var lx: float = rng.randf_range(-half, half)
	var lz: float = rng.randf_range(-half, half)
	var h:  float = gen.get_height_at(center.x + lx, center.y + lz)
	if h > gen.get_water_level_at(center.x + lx, center.y + lz) + SHORE_MARGIN:
		_spawn(animal_type, Vector3(center.x + lx, h, center.y + lz))

## Round 75 (Anfrage "vermehrt Skelette [im Wüsten-Biom]"). Ein Versuch pro
## Chunk, analog zur bisherigen _spawn_animal()-Kadenz — kein "jeder dritte
## Chunk"-Gate wie bei Tieren, die Wahrscheinlichkeit steckt schon in
## BiomeDefinition.enemy_chances selbst (z.B. desert: 0.06 pro Chunk).
func _spawn_enemy(
	_coord: Vector2i, biome: BiomeDefinition, center: Vector2, gen: TerrainField,
	rng: RandomNumberGenerator, half: float
) -> void:
	if not is_instance_valid(biome) or biome.enemy_chances.is_empty():
		return
	var type_id: String = _roll_weighted_type(
		biome.enemy_chances, WorldEntityRegistry.KNOWN_ENEMY_TYPES, rng
	)
	if type_id.is_empty():
		return
	var lx: float = rng.randf_range(-half, half)
	var lz: float = rng.randf_range(-half, half)
	var h:  float = gen.get_height_at(center.x + lx, center.y + lz)
	if h > gen.get_water_level_at(center.x + lx, center.y + lz) + SHORE_MARGIN:
		_spawn(type_id, Vector3(center.x + lx, h, center.y + lz))

## Rollt EINEN Typ aus `chances` ({type_id: chance_0_to_1}), nur unter den in
## `known` gelisteten (tatsächlich registrierten) Typen — alles andere wird
## stillschweigend übersprungen (siehe WorldEntityRegistry.KNOWN_PROP_TYPES-
## Kommentar). Reihenfolge folgt Dictionary.keys() (Godot: Insertions-
## reihenfolge) — bei mehreren Treffern gewinnt der zuerst deklarierte Typ,
## kein echtes Gewichtungs-Sampling über alle Kandidaten. Für die aktuelle
## Datenlage (max. 2 gültige Typen pro Biom) ausreichend; bei Bedarf später
## durch echtes gewichtetes Sampling ersetzbar.
func _roll_weighted_type(
	chances: Dictionary, known: Array[String], rng: RandomNumberGenerator
) -> String:
	for type_id: String in chances.keys():
		if not (type_id in known):
			continue
		if rng.randf() < float(chances[type_id]):
			return type_id
	return ""
