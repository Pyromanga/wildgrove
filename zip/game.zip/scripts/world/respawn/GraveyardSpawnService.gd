extends ServiceNode
# justified: ServiceTicker-Registrierung (add_child) und on_tick() brauchen Node-Lifecycle.
class_name GraveyardSpawnService

## GraveyardSpawnService — Ambientes Nachspawnen von Skeletten rund um
## Spawner-Gräber: natürliche Friedhöfe (Gravestone.gd, per Welt-Chunk-
## Generierung, siehe ChunkEntitySpawner._spawn_graveyard()) UND von
## Spielern gebaute Spawner-Grabsteine (BuildPiece.gd, freigeschaltet über
## Quest — siehe BuildPieceDefinition.requires_quest_id).
##
## ABGRENZUNG ZU RespawnService (bewusst ZWEI Dienste statt einer):
## RespawnService respawnt GENAU DAS abgeerntete/getötete Objekt an SEINER
## EIGENEN Position, ausgelöst durch das entity_despawned-Signal (Baum
## fällt → derselbe Baum wächst später an derselben Stelle nach). Hier geht
## es um etwas grundsätzlich anderes: ein UNVERÄNDERLICH stehendes Objekt
## (Grabstein) soll LAUFEND einen ANDEREN Entity-Typ (Skelett) in seiner
## NÄHE erzeugen, unabhängig davon ob/wann das Grab selbst je despawnt.
## Eine Erweiterung von RespawnService (dessen _configs rein typ-basiert
## sind, kein Konzept von "an einem Punkt X spawnt Typ Y") hätte dessen
## einfaches Modell verwässert — analog zur bestehenden Trennung
## ChunkEntitySpawner (Erstbesiedlung) vs. RespawnService (Nachwuchs nach
## Ernte): zwei verschiedene Probleme, zwei verschiedene Dienste.
##
## SPAWN-CALLBACK statt direkter EntityOrchestrator-Referenz: identisches
## Muster zu RespawnService (siehe dortiger Klassenkommentar
## "Abhängigkeitsproblem gelöst") — WorldService.on_ready() injiziert seine
## eigene spawn_entity()-Methode als Closure, kein zirkulärer DI-Graph.
##
## POPULATION-CAP PRO PUNKT (nicht global): verhindert, dass ein einzelnes
## Grab bei langer Serverlaufzeit eine Skelett-Armee anhäuft, ohne die
## übrigen Gräber der Karte zu drosseln. Zählt bewusst ALLE Gegner der
## Gruppe "enemies" in der Nähe (nicht nur Skelette) — ein Grab neben einem
## bereits von Goblins überlaufenen Fleck soll nicht zusätzlich draufsatteln.

const LOG_CAT := "GraveyardSpawnService"
const DEFAULT_RADIUS: float        = 10.0
const DEFAULT_MAX_ALIVE: int       = 2
const DEFAULT_INTERVAL_SECS: float = 75.0
## Verhindert, dass bei vielen registrierten Gräbern alle im selben Tick fällig
## werden (z.B. wenn ein Chunk mit mehreren Friedhof-Punkten gleichzeitig lädt).
const CHECK_JITTER_SECS: float = 20.0

class _Point:
	var position: Vector3
	var radius: float
	var max_alive: int
	var interval_secs: float
	var next_check_at: float  ## Time.get_unix_time_from_system()

## key → _Point. key ist die entity_uuid des Grabsteins (NICHT die Position —
## zwei Spawner-Gräber könnten durch Spieler-Bau sehr nah beieinander stehen,
## eine Positions-Rundung wie bei WorldData.make_key() würde sie dann fälschlich
## zusammenlegen).
var _points: Dictionary = {}
## Callable(type_id: String, position: Vector3) -> Node3D — von WorldService.
## on_ready() injiziert, identisches Muster zu RespawnService._spawn_cb.
var _spawn_cb: Callable = Callable()
var _ticker: ServiceTicker = null
var _rng := RandomNumberGenerator.new()

# ─────────────────────────────────────────────
# Phase 4/5/7
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	_ticker = deps.get_optional(ServiceKeys.TICKER) as ServiceTicker
	_rng.randomize()
	AppLogger.log_debug("GraveyardSpawnService konfiguriert (wartet auf Callback-Injection).", LOG_CAT)

func on_ready() -> void:
	if is_instance_valid(_ticker):
		_ticker.register_service(self)
	AppLogger.log_info("GraveyardSpawnService bereit.", LOG_CAT)

func on_cleanup() -> void:
	_points.clear()
	_spawn_cb = Callable()
	AppLogger.log_debug("GraveyardSpawnService bereinigt.", LOG_CAT)

# ─────────────────────────────────────────────
# Callback-Injection (von WorldService.on_ready())
# ─────────────────────────────────────────────

## cb: Callable(type_id: String, position: Vector3) -> Node3D
func set_spawn_callback(cb: Callable) -> void:
	assert(cb.is_valid(), "GraveyardSpawnService.set_spawn_callback: Callable ist ungültig!")
	_spawn_cb = cb
	AppLogger.log_debug("Spawn-Callback injiziert.", LOG_CAT)

# ─────────────────────────────────────────────
# Öffentliche API — von Gravestone.gd / BuildPiece.gd aufgerufen
# ─────────────────────────────────────────────

## Meldet einen Spawn-Punkt an. Aufgerufen aus on_spawn() (Autorität-Guard
## liegt beim Aufrufer, analog zu allen anderen request_*()-losen, rein
## additiven Registrierungs-Aufrufen in diesem Codebase, z.B.
## RespawnService.register_config()).
func register_point(
	key: String, position: Vector3, radius: float = DEFAULT_RADIUS,
	max_alive: int = DEFAULT_MAX_ALIVE, interval_secs: float = DEFAULT_INTERVAL_SECS
) -> void:
	if key.is_empty():
		AppLogger.log_warn("register_point() ohne key ignoriert.", LOG_CAT)
		return
	var p := _Point.new()
	p.position      = position
	p.radius        = radius
	p.max_alive     = max_alive
	p.interval_secs = interval_secs
	# Jitter auf den ERSTEN Check (nicht erst ab dem zweiten) — sonst würden
	# alle Punkte eines gleichzeitig geladenen Chunks exakt interval_secs nach
	# dem Laden im selben Tick fällig.
	p.next_check_at = Time.get_unix_time_from_system() + _rng.randf_range(0.0, CHECK_JITTER_SECS)
	_points[key] = p
	AppLogger.log_debug("Spawn-Punkt registriert: '%s' @ %s." % [key, str(position)], LOG_CAT)

## Meldet einen Spawn-Punkt ab (Grab despawnt/abgerissen). No-op wenn key
## unbekannt (z.B. doppeltes on_despawn() — siehe EntityPool-Reuse-Pattern).
func unregister_point(key: String) -> void:
	if _points.erase(key):
		AppLogger.log_debug("Spawn-Punkt entfernt: '%s'." % key, LOG_CAT)

func get_point_count() -> int:
	return _points.size()

# ─────────────────────────────────────────────
# Tick — fällige Punkte prüfen und ggf. spawnen
# ─────────────────────────────────────────────

func on_tick(_delta: float) -> void:
	if _points.is_empty() or not _spawn_cb.is_valid():
		return
	var now := Time.get_unix_time_from_system()
	# Tick-Budget: max. 1 Spawn pro Frame über ALLE Punkte hinweg. Enger als
	# RespawnService's Budget von 3 — jeder Spawn hier erzeugt einen
	# zusätzlichen, aktiv kämpfenden Gegner statt eines passiven Harvestables.
	var budget := 1
	for key in _points.keys():
		if budget <= 0:
			break
		var p: _Point = _points[key]
		if now < p.next_check_at:
			continue
		p.next_check_at = now + p.interval_secs + _rng.randf_range(-CHECK_JITTER_SECS * 0.3, CHECK_JITTER_SECS * 0.3)
		if _count_nearby_enemies(p.position, p.radius) >= p.max_alive:
			continue
		var offset := Vector3(_rng.randf_range(-p.radius, p.radius), 0.0, _rng.randf_range(-p.radius, p.radius))
		var spawn_pos: Vector3 = p.position + offset
		var entity = _spawn_cb.call("skeleton", spawn_pos)
		if is_instance_valid(entity):
			budget -= 1
			AppLogger.log_info(
				"Friedhof-Skelett gespawnt @ %s (Punkt '%s')." % [str(spawn_pos), key], LOG_CAT
			)

func _count_nearby_enemies(position: Vector3, radius: float) -> int:
	var tree := Engine.get_main_loop() as SceneTree
	if tree == null:
		return 0
	var n := 0
	for node in tree.get_nodes_in_group("enemies"):
		if node is Node3D and (node as Node3D).global_position.distance_to(position) <= radius:
			n += 1
	return n
