extends HarvestableEntity
class_name OakTree

## OakTree — Fällbarer Baum (Woodcutting-Interaktion).
## Lifecycle, Despawn und Harvest-State kommen von HarvestableEntity.
## Hier: nur Typ-ID, InteractableData und Visuals.

func _get_entity_type_id() -> String:
	return "oak_tree"

func _build_interactable_data() -> InteractableData:
	var d := InteractableData.new()
	d.id           = "chop"
	d.label        = "Eiche fällen"
	d.duration     = 3.0
	d.xp_type      = "woodcutting"
	d.xp_amount    = 25
	d.loot_table   = preload("res://data/loot_tables/loot_oak_tree.tres")
	d.yield_stat_id = "gathering_yield_wood"
	d.speed_stat_id = "gathering_speed_wood"
	d.inspect_text = "Eine mächtige Eiche. Der Stamm ist mindestens 50 Jahre alt — das Holz riecht nach Harz und feuchter Erde."
	return d

func _build_visuals() -> void:
	var factory: Factory3D = _ctx.get_factory3d() if is_instance_valid(_ctx) else null
	if is_instance_valid(factory):
		factory.create_simple_tree(self)
	else:
		AppLogger.log_warn("Factory3D nicht verfügbar — OakTree Placeholder-Visual.", "oak_tree")
		_add_placeholder_cylinder(0.15, 2.0, Color(0.4, 0.25, 0.1))
