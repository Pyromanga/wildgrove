class_name TreeGrowthStage
extends RefCounted

## TreeGrowthStage — wählt deterministisch (aus der Weltposition, NICHT per Zufall — jeder Peer
## muss an derselben Chunk-Position denselben Baum in derselben Größe sehen, ohne RPC/Sync) das
## Wachstumsstadium eines Baums (siehe MeshCache.TreeStage). Wunsch "Bäume in verschiedenen
## Stadien darstellen": ein natürlicher Wald besteht nicht nur aus ausgewachsenen Bäumen — eine
## Minderheit Sapling/Jungbaum sorgt für Abwechslung, ohne dass irgendein Baum je "wächst" (kein
## Zeit-/Speicherzustand nötig — der Wert ist bei jedem Neuladen exakt derselbe).
##
## Verteilung bewusst zugunsten von MATURE (der Wald soll nicht wie eine Baumschule aussehen):
## ~12% SAPLING, ~23% YOUNG, ~65% MATURE.

const SAPLING_THRESHOLD: float = 0.12
const YOUNG_THRESHOLD: float = 0.35  ## SAPLING_THRESHOLD + Anteil YOUNG

## Liefert MeshCache.TreeStage (0=SAPLING, 1=YOUNG, 2=MATURE) für eine Weltposition. `salt`
## erlaubt mehreren Baumarten an derselben Position unterschiedliche (aber weiterhin
## deterministische) Werte zu bekommen, falls sie je dieselbe Zellmitte teilen sollten.
static func for_position(pos: Vector3, salt: int = 0) -> int:
	var h: float = _hash(pos, salt)
	if h < SAPLING_THRESHOLD:
		return 0  # MeshCache.TreeStage.SAPLING
	if h < YOUNG_THRESHOLD:
		return 1  # MeshCache.TreeStage.YOUNG
	return 2      # MeshCache.TreeStage.MATURE

## Wie for_position(), liefert aber direkt das Schlüssel-Suffix, das Factory3D.create_simple_tree()
## bzw. PineTree für den passenden MeshCache-Szenenschlüssel braucht ("" für MATURE — der
## unveränderte, rückwärtskompatible Schlüssel, "_young", "_sapling") statt des rohen Enum-Werts.
static func suffix_for_position(pos: Vector3, salt: int = 0) -> String:
	match for_position(pos, salt):
		0: return "_sapling"
		1: return "_young"
		_: return ""

## Einfacher, deterministischer Positions-Hash → [0, 1). Dieselbe sin()-basierte
## Pseudo-Rauschen-Technik wie in ProceduralTextureFactory, nur auf Vector3 statt auf
## Pixel-Koordinaten — kein Random-Objekt, kein Seed-Zustand, exakt reproduzierbar.
static func _hash(pos: Vector3, salt: int) -> float:
	var v: float = pos.x * 12.9898 + pos.z * 78.233 + float(salt) * 37.719
	var s: float = sin(v) * 43758.5453
	return s - floor(s)
