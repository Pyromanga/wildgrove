extends HarvestableEntity
class_name CharcoalKiln

## CharcoalKiln — Rauchender Kohlenmeiler (Skill "charcoal_burning" / Köhlerei).
## Lifecycle, Despawn und Harvest-State kommen von HarvestableEntity.
## Hier: nur Typ-ID, InteractableData und Visuals.
##
## Echte Welt: Im Meiler verschwelt Holz unter sehr wenig Luft über Tage zu
## Holzkohle (Pyrolyse); sie brennt heißer als Holz und war der Brennstoff der
## Schmiede. Spawnt in Wäldern (BiomeRegistry). Respawn: siehe
## WorldService.configure().
##
## Der Bildungstext lebt in data/skills/charcoal_burning.tres.

func _get_entity_type_id() -> String:
	return "charcoal_kiln"

func _build_interactable_data() -> InteractableData:
	var d := InteractableData.new()
	d.id           = "harvest_charcoal_kiln"
	d.label        = "Holzkohle bergen"
	d.duration     = 3.0
	d.xp_type      = "charcoal_burning"
	d.xp_amount    = 20
	d.loot_table   = preload("res://data/loot_tables/loot_charcoal_kiln.tres")
	d.inspect_text = "Ein rauchender Erdhügel: der Kohlenmeiler. Wusstest du? Darin brennt Holz tagelang mit sehr wenig Luft zu Holzkohle, die heißer brennt als Holz."
	return d

func _build_visuals() -> void:
	_add_placeholder_cylinder(0.8, 0.9, Color(0.20, 0.14, 0.10))
	AppLogger.log_debug("CharcoalKiln Placeholder-Zylinder erstellt.", "charcoal_kiln")
