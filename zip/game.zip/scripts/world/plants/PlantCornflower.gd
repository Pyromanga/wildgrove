class_name PlantCornflower
extends WildPlant

## Kornblume (Centaurea cyanus) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "cornflower"
