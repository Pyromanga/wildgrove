class_name PlantChamomile
extends WildPlant

## Kamille (Matricaria chamomilla) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "chamomile"
