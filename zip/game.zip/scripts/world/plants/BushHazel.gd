class_name BushHazel
extends WildBush

## Haselnussstrauch (Corylus avellana) — Pflücken + Roden, alles Weitere: BushCatalog + WildBush.

func _bush_id() -> String:
	return "hazel"
