class_name PlantDandelion
extends WildPlant

## Löwenzahn (Taraxacum officinale) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "dandelion"
