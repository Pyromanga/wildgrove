class_name PlantNettle
extends WildPlant

## Brennnessel (Urtica dioica) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "nettle"
