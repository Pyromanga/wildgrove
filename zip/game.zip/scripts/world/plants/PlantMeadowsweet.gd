class_name PlantMeadowsweet
extends WildPlant

## Mädesüß (Filipendula ulmaria) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "meadowsweet"
