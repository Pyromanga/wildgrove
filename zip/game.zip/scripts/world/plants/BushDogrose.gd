class_name BushDogrose
extends WildBush

## Heckenrose (Rosa canina) — Pflücken + Roden, alles Weitere: BushCatalog + WildBush.

func _bush_id() -> String:
	return "dogrose"
