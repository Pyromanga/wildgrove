class_name BushElder
extends WildBush

## Holunderstrauch (Sambucus nigra) — Pflücken + Roden, alles Weitere: BushCatalog + WildBush.

func _bush_id() -> String:
	return "elder"
