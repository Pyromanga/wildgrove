class_name PlantThyme
extends WildPlant

## Thymian (Thymus vulgaris) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "thyme"
