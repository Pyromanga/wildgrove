class_name BushBlackberry
extends WildBush

## Brombeerstrauch (Rubus fruticosus agg.) — Pflücken + Roden, alles Weitere: BushCatalog + WildBush.

func _bush_id() -> String:
	return "blackberry"
