class_name PlantPoppy
extends WildPlant

## Klatschmohn (Papaver rhoeas) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "poppy"
