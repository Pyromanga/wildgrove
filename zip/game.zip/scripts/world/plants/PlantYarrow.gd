class_name PlantYarrow
extends WildPlant

## Schafgarbe (Achillea millefolium) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "yarrow"
