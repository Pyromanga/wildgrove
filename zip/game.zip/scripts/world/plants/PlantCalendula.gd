class_name PlantCalendula
extends WildPlant

## Ringelblume (Calendula officinalis) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "calendula"
