class_name PlantLavender
extends WildPlant

## Lavendel (Lavandula angustifolia) — wildes Weltobjekt, alles Weitere: PlantCatalog + WildPlant.

func _plant_id() -> String:
	return "lavender"
