class_name ProceduralTextureFactory
extends RefCounted

## ProceduralTextureFactory — "Natur besteht auch nur aus Mathematik": kleine,
## nahtlos kachelbare Texturen, komplett aus Value-Noise/fbm berechnet statt
## aus Bilddateien geladen. Ergänzt MeshCache (das schon alle Meshes einmalig
## prozedural baut) um dieselbe Idee für Oberflächen-Detail.
##
## Kategorien: grass, stone, wood, sand, gravel, dirt (tileable Grain-Texturen
## für StandardMaterial3D.albedo_texture, siehe MeshCache.get_textured_material())
## sowie leaf_card, raindrop_streak, snowflake (Sprite-Texturen mit Alpha für
## Partikel/Karten-Meshes, siehe WeatherVfx).
##
## Determinismus: jede Kategorie hat einen fest verdrahteten internen Seed —
## bei jedem Start entsteht Pixel für Pixel exakt dieselbe Textur (wichtig,
## weil nichts davon über das Netzwerk synchronisiert wird — jeder Peer
## rechnet sie unabhängig, muss aber optisch identisch ankommen, gleiches
## Prinzip wie TerrainField/WeatherService).
##
## Einmal pro Kategorie berechnet, danach wie jede andere Textur GPU-seitig
## geteilt (statischer Cache — Analog zu MeshCache.materials).

const DEFAULT_SIZE := 96

static var _cache: Dictionary = {}  # { key: ImageTexture }

# ─────────────────────────────────────────────
# Öffentliche Fabrikmethoden
# ─────────────────────────────────────────────

static func grass(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("grass_%d" % size, func() -> Image: return _build_fibrous(size, 91))

static func stone(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("stone_%d" % size, func() -> Image: return _build_mottled(size, 47, 6, 0.45))

static func wood(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("wood_%d" % size, func() -> Image: return _build_grain_streaks(size, 12))

static func sand(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("sand_%d" % size, func() -> Image: return _build_mottled(size, 33, 14, 0.16))

static func gravel(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("gravel_%d" % size, func() -> Image: return _build_mottled(size, 58, 9, 0.55))

static func dirt(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("dirt_%d" % size, func() -> Image: return _build_mottled(size, 71, 5, 0.32))

## Raue Rinde — wie wood(), aber mit zusätzlichen queren Rissen zwischen den
## Maserungslinien und höherem Kontrast. Eigene Kategorie statt wood()-Parameter,
## weil beide gleichzeitig gebraucht werden (glattes Bauholz vs. lebende Baumrinde).
static func bark(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("bark_%d" % size, func() -> Image: return _build_bark(size, 23))

## Fleckiger Moosbewuchs — für liegende Stämme/Steine im Wald. Größere,
## weicher geformte Flecken statt feinem Korn (niedrigere Frequenz, höherer
## Kontrast als _build_mottled) — modelliert Moospolster, nicht Gestein.
static func moss(size: int = DEFAULT_SIZE) -> ImageTexture:
	return _cached("moss_%d" % size, func() -> Image: return _build_moss(size, 65))

## Blattkarte mit Alpha-Ausschnitt (Ellipse + Spitze + Mittelrippe) — für
## Farn/Unterholz-Karten-Meshes und als Basis für fallende-Blätter-Partikel.
## hue_seed variiert Grünton leicht (mehrere Blatt-Varianten ohne neuen Code).
static func leaf_card(size: int = 64, hue_seed: int = 0) -> ImageTexture:
	return _cached("leaf_card_%d_%d" % [size, hue_seed], func() -> Image: return _build_leaf(size, hue_seed))

## Schmale, oben transparente / unten zulaufende Strähne — Regen-Partikel-Billboard.
static func raindrop_streak(width: int = 8, height: int = 64) -> ImageTexture:
	return _cached("raindrop_%dx%d" % [width, height], func() -> Image: return _build_raindrop(width, height))

## Weicher, runder Punkt mit Falloff — Schnee-Partikel-Billboard.
static func snowflake(size: int = 16) -> ImageTexture:
	return _cached("snowflake_%d" % size, func() -> Image: return _build_soft_dot(size))

# ─────────────────────────────────────────────
# Noise-Bausteine (Value-Noise + fbm, nahtlos kachelbar)
# ─────────────────────────────────────────────

## Ganzzahliger Hash → deterministisches Pseudo-Zufall in [0, 1). Kein
## FastNoiseLite (das ist nicht exakt bit-identisch über Godot-Versionen
## garantiert) — reine Integer-Arithmetik, damit die Textur wirklich für
## immer gleich bleibt (analog TerrainSeed.derive(), FNV statt String.hash()).
static func _hash2(x: int, y: int, seed: int) -> float:
	var n: int = x * 374761393 + y * 668265263 + seed * 2654435761
	n = (n << 13) ^ n
	n = n * (n * n * 15731 + 789221) + 1376312589
	return float(n & 0x7fffffff) / float(0x7fffffff)

## Value-Noise, dessen Gitter bei `period` umbricht (posmod der Gitterpunkte)
## → an der rechten/unteren Kante schließt die Textur nahtlos an die linke/
## obere an (wichtig: diese Texturen werden per uv1_scale gekachelt).
static func _value_noise_tiled(x: float, y: float, seed: int, period: int) -> float:
	var xi: int = int(floor(x))
	var yi: int = int(floor(y))
	var xf: float = x - xi
	var yf: float = y - yi
	var x0: int = posmod(xi, period)
	var x1: int = posmod(xi + 1, period)
	var y0: int = posmod(yi, period)
	var y1: int = posmod(yi + 1, period)
	var v00: float = _hash2(x0, y0, seed)
	var v10: float = _hash2(x1, y0, seed)
	var v01: float = _hash2(x0, y1, seed)
	var v11: float = _hash2(x1, y1, seed)
	var u: float = xf * xf * (3.0 - 2.0 * xf)
	var v: float = yf * yf * (3.0 - 2.0 * yf)
	return lerp(lerp(v00, v10, u), lerp(v01, v11, u), v)

## Mehrere Oktaven übereinander (jede Oktave verdoppelt Frequenz + eigene
## Periode, damit jede Oktave für sich sauber kachelt).
static func _fbm_tiled(x: float, y: float, seed: int, base_period: int, octaves: int = 4) -> float:
	var total: float = 0.0
	var amp: float = 0.5
	var freq: float = 1.0
	var norm: float = 0.0
	for i in range(octaves):
		var period: int = base_period * int(freq)
		total += _value_noise_tiled(x * freq, y * freq, seed + i * 97, period) * amp
		norm += amp
		amp *= 0.5
		freq *= 2.0
	return total / norm

# ─────────────────────────────────────────────
# Oberflächen-Texturen (RGB, für albedo_texture — Farbe kommt vom Material,
# hier nur Helligkeits-/Grain-Variation um 1.0 herum)
# ─────────────────────────────────────────────

## Fleckig/körnig — trägt Stein, Kies, Erde, Sand (Unterschied nur in
## Skalierung/Kontrast der Aufrufer): grobe fbm-Basis + feine Sprenkel obendrauf.
static func _build_mottled(size: int, seed: int, base_period: int, contrast: float) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	for y in range(size):
		for x in range(size):
			var nx: float = float(x) / size * base_period
			var ny: float = float(y) / size * base_period
			var base: float = _fbm_tiled(nx, ny, seed, base_period, 4)
			var speck: float = _value_noise_tiled(nx * 6.0, ny * 6.0, seed + 500, base_period * 6)
			var v: float = 1.0 + (base - 0.5) * contrast + (speck - 0.5) * contrast * 0.35
			v = clampf(v, 0.35, 1.25)
			img.set_pixel(x, y, Color(v, v, v))
	return img

## Feine, in eine Richtung gestreckte Streifen — trägt Gras (Halme).
static func _build_fibrous(size: int, seed: int) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var period: int = 10
	for y in range(size):
		for x in range(size):
			# X gestaucht, Y gestreckt → längliche Halm-Fasern statt runder Flecken
			var nx: float = float(x) / size * period * 2.2
			var ny: float = float(y) / size * period * 0.6
			var base: float = _fbm_tiled(nx, ny, seed, period, 3)
			var blade: float = _value_noise_tiled(nx * 3.0, ny * 0.8, seed + 300, period * 3)
			var v: float = 0.75 + (base - 0.5) * 0.7 + (blade - 0.5) * 0.3
			v = clampf(v, 0.4, 1.3)
			img.set_pixel(x, y, Color(v, v * 1.02, v * 0.95))
	return img

## Vertikale Maserung mit leichtem Sinus-Verzug — trägt Holz/Rinde.
static func _build_grain_streaks(size: int, seed: int) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var period: int = 8
	for y in range(size):
		for x in range(size):
			var nx: float = float(x) / size * period
			var ny: float = float(y) / size * period
			var warp: float = (_fbm_tiled(nx, ny, seed, period, 3) - 0.5) * 3.0
			var grain: float = sin((nx + warp) * TAU * 1.5) * 0.5 + 0.5
			var fine: float = _value_noise_tiled(nx * 5.0, ny * 5.0, seed + 200, period * 5)
			var v: float = 0.65 + grain * 0.5 + (fine - 0.5) * 0.2
			v = clampf(v, 0.35, 1.25)
			img.set_pixel(x, y, Color(v, v * 0.92, v * 0.80))
	return img

## Vertikale Maserung wie _build_grain_streaks(), plus eine zweite, quer
## verlaufende Riss-Maske (dünne, unregelmäßige horizontale Linien) und mehr
## Gesamtkontrast — wirkt zerklüftet/borkig statt glatt gehobelt.
static func _build_bark(size: int, seed: int) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var period: int = 7
	for y in range(size):
		for x in range(size):
			var nx: float = float(x) / size * period
			var ny: float = float(y) / size * period
			var warp: float = (_fbm_tiled(nx, ny, seed, period, 3) - 0.5) * 4.0
			var grain: float = sin((nx + warp) * TAU * 1.8) * 0.5 + 0.5
			# Queres Rissmuster: eigene, niederfrequente Noise-Achse entlang Y,
			# nur dort abgedunkelt wo sie über einer Schwelle liegt -> vereinzelte
			# Furchen statt gleichmäßiger Streifen.
			var crack_n: float = _value_noise_tiled(ny * 2.5, nx * 0.4, seed + 700, period * 3)
			var crack: float = 1.0 if crack_n > 0.78 else 0.0
			var fine: float = _value_noise_tiled(nx * 6.0, ny * 6.0, seed + 200, period * 6)
			var v: float = 0.55 + grain * 0.6 + (fine - 0.5) * 0.25 - crack * 0.35
			v = clampf(v, 0.25, 1.3)
			img.set_pixel(x, y, Color(v, v * 0.88, v * 0.72))
	return img

## Weiche, klumpige Flecken (niedrige Grundfrequenz, scharf am oberen Ende
## geclampt) simulieren Moospolster; feine zweite Oktave bricht die Kanten
## der Flecken auf, damit sie nicht wie gestempelt wirken.
static func _build_moss(size: int, seed: int) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGB8)
	var period: int = 5
	for y in range(size):
		for x in range(size):
			var nx: float = float(x) / size * period
			var ny: float = float(y) / size * period
			var clump: float = _fbm_tiled(nx, ny, seed, period, 3)
			var edge_break: float = _value_noise_tiled(nx * 4.0, ny * 4.0, seed + 400, period * 4)
			var patch: float = clump + (edge_break - 0.5) * 0.25
			# Scharfe Schwelle statt linearer Mischung -> klar abgesetzte Polster
			# statt einem gleichmäßigen Verlauf.
			var v: float = 1.15 if patch > 0.55 else 0.55
			v = lerp(v, 0.85, 0.15)  # etwas Grundhelligkeit dazwischen, kein hartes Schwarz/Weiß
			v = clampf(v, 0.4, 1.2)
			img.set_pixel(x, y, Color(v, v, v))
	return img

# ─────────────────────────────────────────────
# Sprite-Texturen (RGBA, Alpha-Cutout — für Karten-Meshes/Partikel)
# ─────────────────────────────────────────────

static func _build_leaf(size: int, hue_seed: int) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var rng_offset: float = float(hue_seed) * 0.37
	var green_shift: float = sin(rng_offset) * 0.08
	for y in range(size):
		for x in range(size):
			var u: float = (float(x) / size) * 2.0 - 1.0   # -1..1, 0 = Mitte
			var v: float = (float(y) / size) * 2.0 - 1.0
			# Blattform: Ellipse, zur Spitze (v>0) hin verjüngt
			var taper: float = 1.0 - clampf(v, -1.0, 1.0) * 0.4
			var dist: float = (u * u) / (0.55 * taper * 0.55 * taper) + v * v
			var inside: bool = dist <= 1.0
			if not inside:
				img.set_pixel(x, y, Color(0, 0, 0, 0))
				continue
			var vein: float = absf(u)
			var vein_shade: float = 1.0 - clampf(1.0 - vein * 4.0, 0.0, 1.0) * 0.25
			var grain: float = _value_noise_tiled(float(x) * 0.3, float(y) * 0.3, hue_seed + 900, size)
			var g: float = 0.42 + green_shift + (grain - 0.5) * 0.12
			var edge_fade: float = clampf((1.0 - dist) * 6.0, 0.0, 1.0)  # weiche Kante statt Treppchen
			img.set_pixel(x, y, Color(0.18 * vein_shade, g * vein_shade, 0.10 * vein_shade, edge_fade))
	return img

static func _build_raindrop(width: int, height: int) -> Image:
	var img := Image.create(width, height, false, Image.FORMAT_RGBA8)
	for y in range(height):
		var t: float = float(y) / float(height - 1)
		# oben schwach, Mitte kräftig, unten spitz auslaufend (Tropfenschweif)
		var a: float = sin(t * PI) * (0.9 - t * 0.3)
		for x in range(width):
			var cx: float = (float(x) / float(width - 1)) * 2.0 - 1.0
			var falloff: float = 1.0 - clampf(absf(cx), 0.0, 1.0)
			img.set_pixel(x, y, Color(0.75, 0.85, 0.95, clampf(a * falloff, 0.0, 1.0)))
	return img

static func _build_soft_dot(size: int) -> Image:
	var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
	var center: float = size * 0.5
	for y in range(size):
		for x in range(size):
			var d: float = Vector2(x - center, y - center).length() / center
			var a: float = clampf(1.0 - d, 0.0, 1.0)
			a = a * a  # weicherer Falloff-Rand
			img.set_pixel(x, y, Color(1.0, 1.0, 1.0, a))
	return img

# ─────────────────────────────────────────────
# Cache
# ─────────────────────────────────────────────

static func _cached(key: String, builder: Callable) -> ImageTexture:
	if not _cache.has(key):
		var img: Image = builder.call()
		_cache[key] = ImageTexture.create_from_image(img)
	return _cache[key]
