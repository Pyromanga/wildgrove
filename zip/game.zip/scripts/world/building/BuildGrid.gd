class_name BuildGrid
extends RefCounted

## BuildGrid — Raster, Einrasten und Schlüssel für Bauteile. Rein statisch, ohne Engine-State.
##
## RASTER: Zellen von CELL Metern. Zelle (cx, cz) deckt [cx*CELL, (cx+1)*CELL) × [cz*CELL,
## (cz+1)*CELL) ab. CELL entspricht bewusst dem Terrain-Gitter (TerrainEditLayer.SPACING):
## Zellecken liegen exakt auf Terrain-Vertices — ein Boden deckt genau ein Terrain-Quad ab
## und lässt sich sauber einebnen.
##
##   Boden  (FLOOR): belegt eine ZELLE.            Schlüssel "F_<cx>_<cz>"
##   Wand   (WALL) : belegt eine ZELLKANTE.        Schlüssel "W<achse>_<cx>_<cz>"
##       Achse 0: Kante entlang X bei z = cz*CELL, von x = cx*CELL bis (cx+1)*CELL.
##       Achse 1: Kante entlang Z bei x = cx*CELL, von z = cz*CELL bis (cz+1)*CELL.
##
## ROTATION: Böden sind quadratisch, Drehen ändert nichts. Bei Wänden schaltet jeder
## Rotationsschritt zwischen Achse 0 und 1 um (gerade Schritte = Achse 0, ungerade = 1).
##
## ERWEITERUNG: Neue Bauteil-Arten (Dach, Tür, Fenster-Wand, Treppe) bekommen hier einen
## eigenen Schlüsselraum und eine snap()-Regel; Registry/Regeln arbeiten nur mit Schlüsseln.

const CELL: float = 2.0
## Bauhöhen werden auf dieses Raster gerundet, damit Nachbarn auf sanften Hängen dieselbe
## Höhe teilen und keine Stufen/Lücken entstehen.
const Y_STEP: float = 0.25

static func cell_of(world_x: float, world_z: float) -> Vector2i:
	return Vector2i(floori(world_x / CELL), floori(world_z / CELL))

static func floor_key(cell: Vector2i) -> String:
	return "F_%d_%d" % [cell.x, cell.y]

static func wall_key(axis: int, cx: int, cz: int) -> String:
	return "W%d_%d_%d" % [axis, cx, cz]

## Rastet eine Zielposition auf das Bauraster ein.
## Rückgabe: {key, kind, axis, cell: Vector2i, center: Vector2 (x,z), yaw: float}
##   axis: -1 bei Böden, sonst 0/1. yaw: Drehung um Y für die Darstellung.
static func snap(kind: int, world_pos: Vector3, rot_steps: int) -> Dictionary:
	if kind == BuildPieceDefinition.Kind.WALL:
		var axis: int = posmod(rot_steps, 2)
		if axis == 0:
			var ez: int = roundi(world_pos.z / CELL)
			var cx: int = floori(world_pos.x / CELL)
			return {
				"key": wall_key(0, cx, ez), "kind": kind, "axis": 0,
				"cell": Vector2i(cx, ez),
				"center": Vector2((float(cx) + 0.5) * CELL, float(ez) * CELL),
				"yaw": 0.0,
			}
		var ex: int = roundi(world_pos.x / CELL)
		var cz: int = floori(world_pos.z / CELL)
		return {
			"key": wall_key(1, ex, cz), "kind": kind, "axis": 1,
			"cell": Vector2i(ex, cz),
			"center": Vector2(float(ex) * CELL, (float(cz) + 0.5) * CELL),
			"yaw": PI * 0.5,
		}
	# FLOOR (Standard)
	var cell: Vector2i = cell_of(world_pos.x, world_pos.z)
	return {
		"key": floor_key(cell), "kind": BuildPieceDefinition.Kind.FLOOR, "axis": -1,
		"cell": cell,
		"center": Vector2((float(cell.x) + 0.5) * CELL, (float(cell.y) + 0.5) * CELL),
		"yaw": 0.0,
	}

## Die vier Zellecken einer Zelle als Terrain-Gitterindizes (für Einebnen).
static func floor_corner_lattice(cell: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var per_cell: int = roundi(CELL / TerrainEditLayer.SPACING)
	for dz in range(0, per_cell + 1):
		for dx in range(0, per_cell + 1):
			out.append(Vector2i(cell.x * per_cell + dx, cell.y * per_cell + dz))
	return out

## Endpunkte einer Wandkante in Weltkoordinaten: [Vector2 a, Vector2 b].
static func wall_endpoints(axis: int, cx: int, cz: int) -> Array[Vector2]:
	if axis == 0:
		return [Vector2(float(cx) * CELL, float(cz) * CELL), Vector2(float(cx + 1) * CELL, float(cz) * CELL)]
	return [Vector2(float(cx) * CELL, float(cz) * CELL), Vector2(float(cx) * CELL, float(cz + 1) * CELL)]

## Die (bis zu) zwei Zellen, an die eine Wandkante grenzt.
static func cells_adjacent_to_wall(axis: int, cx: int, cz: int) -> Array[Vector2i]:
	if axis == 0:
		return [Vector2i(cx, cz), Vector2i(cx, cz - 1)]
	return [Vector2i(cx, cz), Vector2i(cx - 1, cz)]

## Kürzester Abstand (XZ) eines Punkts zu einer Wandkante.
static func distance_to_wall(p: Vector2, axis: int, cx: int, cz: int) -> float:
	var ends: Array[Vector2] = wall_endpoints(axis, cx, cz)
	var a: Vector2 = ends[0]
	var b: Vector2 = ends[1]
	var ab: Vector2 = b - a
	var t: float = clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	return p.distance_to(a + ab * t)

static func quantize_y(y: float) -> float:
	return snappedf(y, Y_STEP)
