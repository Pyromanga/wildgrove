class_name BuildGrid
extends RefCounted

## BuildGrid — Raster, Einrasten und Schlüssel für Bauteile. Rein statisch, ohne Engine-State.
##
## RASTER: Zellen von CELL Metern. Zelle (cx, cz) deckt [cx*CELL, (cx+1)*CELL) × [cz*CELL,
## (cz+1)*CELL) ab. CELL entspricht bewusst dem Terrain-Gitter (TerrainEditLayer.SPACING):
## Zellecken liegen exakt auf Terrain-Vertices — ein Boden deckt genau ein Terrain-Quad ab
## und lässt sich sauber einebnen.
##
##   Boden  (FLOOR): belegt eine ZELLE.            Schlüssel "F_<cx>_<cz>"
##   Wand   (WALL) : belegt eine ZELLKANTE.        Schlüssel "W<achse>_<cx>_<cz>"
##       Achse 0: Kante entlang X bei z = cz*CELL, von x = cx*CELL bis (cx+1)*CELL.
##       Achse 1: Kante entlang Z bei x = cx*CELL, von z = cz*CELL bis (cz+1)*CELL.
##
## ROTATION: Böden sind quadratisch, Drehen ändert nichts. Bei Wänden schaltet jeder
## Rotationsschritt zwischen Achse 0 und 1 um (gerade Schritte = Achse 0, ungerade = 1).
##
## EBENEN (storey): Bauteile lassen sich übereinander setzen. Ebene 0 = Gelände (Schlüssel wie
## bisher, alte Spielstände bleiben gültig), Ebene n>0 hängt "_L<n>" an den Schlüssel. Eine
## Ebene ist LEVEL_HEIGHT hoch (= Wandhöhe): Boden der Ebene n liegt in Oberkante der Wände der
## Ebene n-1, Wände der Ebene n stehen auf diesem Boden.
##
## ERWEITERUNG: Neue Bauteil-Arten (Dach, Tür, Fenster-Wand, Treppe) bekommen hier einen
## eigenen Schlüsselraum und eine snap()-Regel; Registry/Regeln arbeiten nur mit Schlüsseln.

const CELL: float = 2.0
## Bauhöhen werden auf dieses Raster gerundet, damit Nachbarn auf sanften Hängen dieselbe
## Höhe teilen und keine Stufen/Lücken entstehen.
const Y_STEP: float = 0.25
## Höhe einer Ebene in Metern. Muss der Wandhöhe der Bauteile entsprechen (data/building/*.tres).
const LEVEL_HEIGHT: float = 2.5
## Höchste baubare Ebene (0 = Boden). Begrenzt Bauhöhe und Vorschau.
const MAX_STOREY: int = 3

static func _storey_suffix(storey: int) -> String:
	return "" if storey <= 0 else "_L%d" % storey

static func cell_of(world_x: float, world_z: float) -> Vector2i:
	return Vector2i(floori(world_x / CELL), floori(world_z / CELL))

static func floor_key(cell: Vector2i, storey: int = 0) -> String:
	return "F_%d_%d%s" % [cell.x, cell.y, _storey_suffix(storey)]

static func wall_key(axis: int, cx: int, cz: int, storey: int = 0) -> String:
	return "W%d_%d_%d%s" % [axis, cx, cz, _storey_suffix(storey)]

## Rastet eine Zielposition auf das Bauraster ein.
## Rückgabe: {key, kind, axis, cell: Vector2i, center: Vector2 (x,z), yaw: float, storey: int}
##   axis: -1 bei Böden, sonst 0/1. yaw: Drehung um Y für die Darstellung.
static func snap(kind: int, world_pos: Vector3, rot_steps: int, storey: int = 0) -> Dictionary:
	storey = clampi(storey, 0, MAX_STOREY)
	if kind == BuildPieceDefinition.Kind.WALL:
		var axis: int = posmod(rot_steps, 2)
		if axis == 0:
			var ez: int = roundi(world_pos.z / CELL)
			var cx: int = floori(world_pos.x / CELL)
			return {
				"key": wall_key(0, cx, ez, storey), "kind": kind, "axis": 0, "storey": storey,
				"cell": Vector2i(cx, ez),
				"center": Vector2((float(cx) + 0.5) * CELL, float(ez) * CELL),
				"yaw": 0.0,
			}
		var ex: int = roundi(world_pos.x / CELL)
		var cz: int = floori(world_pos.z / CELL)
		return {
			"key": wall_key(1, ex, cz, storey), "kind": kind, "axis": 1, "storey": storey,
			"cell": Vector2i(ex, cz),
			"center": Vector2(float(ex) * CELL, (float(cz) + 0.5) * CELL),
			"yaw": PI * 0.5,
		}
	# FLOOR (Standard)
	var cell: Vector2i = cell_of(world_pos.x, world_pos.z)
	return {
		"key": floor_key(cell, storey), "kind": BuildPieceDefinition.Kind.FLOOR, "axis": -1, "storey": storey,
		"cell": cell,
		"center": Vector2((float(cell.x) + 0.5) * CELL, (float(cell.y) + 0.5) * CELL),
		"yaw": 0.0,
	}

## Die vier Zellecken einer Zelle als Terrain-Gitterindizes (für Einebnen).
static func floor_corner_lattice(cell: Vector2i) -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	var per_cell: int = roundi(CELL / TerrainEditLayer.SPACING)
	for dz in range(0, per_cell + 1):
		for dx in range(0, per_cell + 1):
			out.append(Vector2i(cell.x * per_cell + dx, cell.y * per_cell + dz))
	return out

## Endpunkte einer Wandkante in Weltkoordinaten: [Vector2 a, Vector2 b].
static func wall_endpoints(axis: int, cx: int, cz: int) -> Array[Vector2]:
	if axis == 0:
		return [Vector2(float(cx) * CELL, float(cz) * CELL), Vector2(float(cx + 1) * CELL, float(cz) * CELL)]
	return [Vector2(float(cx) * CELL, float(cz) * CELL), Vector2(float(cx) * CELL, float(cz + 1) * CELL)]

## Die (bis zu) zwei Zellen, an die eine Wandkante grenzt.
static func cells_adjacent_to_wall(axis: int, cx: int, cz: int) -> Array[Vector2i]:
	if axis == 0:
		return [Vector2i(cx, cz), Vector2i(cx, cz - 1)]
	return [Vector2i(cx, cz), Vector2i(cx - 1, cz)]

## Kürzester Abstand (XZ) eines Punkts zu einer Wandkante.
static func distance_to_wall(p: Vector2, axis: int, cx: int, cz: int) -> float:
	var ends: Array[Vector2] = wall_endpoints(axis, cx, cz)
	var a: Vector2 = ends[0]
	var b: Vector2 = ends[1]
	var ab: Vector2 = b - a
	var t: float = clampf((p - a).dot(ab) / ab.length_squared(), 0.0, 1.0)
	return p.distance_to(a + ab * t)

static func quantize_y(y: float) -> float:
	return snappedf(y, Y_STEP)

## Zerlegt einen Schlüssel: {kind, axis, x, z, storey} oder {} bei ungültigem Format.
## Böden: axis = -1. x/z = Zellindex (Böden) bzw. Kantenindex (Wände).
static func parse_key(key: String) -> Dictionary:
	var storey: int = 0
	var base: String = key
	var l_pos: int = key.find("_L")
	if l_pos >= 0:
		storey = int(key.substr(l_pos + 2))
		base = key.substr(0, l_pos)
	var parts: PackedStringArray = base.split("_")
	if parts.size() != 3:
		return {}
	if parts[0] == "F":
		return {"kind": BuildPieceDefinition.Kind.FLOOR, "axis": -1,
			"x": int(parts[1]), "z": int(parts[2]), "storey": storey}
	if parts[0].length() == 2 and parts[0].begins_with("W"):
		return {"kind": BuildPieceDefinition.Kind.WALL, "axis": int(parts[0].substr(1)),
			"x": int(parts[1]), "z": int(parts[2]), "storey": storey}
	return {}
