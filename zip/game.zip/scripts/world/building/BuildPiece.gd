class_name BuildPiece
extends StaticBody3D

## BuildPiece — die 3D-ANSICHT eines gebauten Bauteils (Boden, Wand, ...).
##
## Die Wahrheit über das Bauwerk sind die Records in BuildRegistry; dieser Node wird von
## WorldBuildHandler beim Laden des Chunks erzeugt und beim Entladen wieder entfernt. Er
## hält deshalb KEINEN eigenen Zustand — alles kommt aus der Spawn-Config und der
## BuildPieceDefinition. Dadurch ist er beliebig oft neu erzeugbar (Chunk-Streaming,
## Laden eines Spielstands).
##
## Spawn-Config: {piece_id: String, key: String, yaw: float}. Position = Basis-Oberkante
## des Bauteils (Böden: Oberkante; Wände: Boden, auf dem sie stehen).
##
## Geometrie: BuildPieceDefinition.get_box_size()/get_box_center() (gemeinsame Quelle mit dem
## Geist im Baumodus). skirt versteckt Lücken auf unebenem Boden.
## ERWEITERUNG: neue Bauteil-Arten (Dach, Tür, Fenster) → neuer Zweig in _build_geometry().
##
## Interaktion: "Abreißen" (Autorität) → EventBus build_remove_requested → WorldService.
## Nicht gepoolt (siehe EntityOrchestrator): Geometrie hängt an der Definition.

const LOG_CAT := "BuildPiece"
const ACTION_DISMANTLE: String = "dismantle_piece"
const COL_MISSING := Color(0.85, 0.15, 0.15)

var _ctx: IEntityContext = null
var _piece_key: String = ""
var _def: BuildPieceDefinition = null
var _interactable_comp: InteractableComponent = null

func _ready() -> void:
	# Autorität ist immer der Server (wie alle Welt-Entities). Name kommt vom Orchestrator
	# (deterministisch aus der Position) — nur ersetzen, wenn noch der Godot-Standardname.
	set_multiplayer_authority(1)
	if name == get_class() or name.begins_with("@"):
		name = "BuildPiece_%d" % (get_instance_id() % 9999)
	add_to_group("build_pieces")
	add_to_group("interactable")
	_setup_interactable()

## Aufgerufen vom EntityOrchestrator NACH add_child() und NACH _ready().
func on_spawn(cfg: Dictionary = {}, ctx: IEntityContext = null) -> void:
	_ctx = ctx
	_piece_key = String(cfg.get("key", ""))
	rotation.y = float(cfg.get("yaw", 0.0))

	var data: DataService = ctx.get_data() if is_instance_valid(ctx) else null
	_def = data.get_build_piece(String(cfg.get("piece_id", ""))) if is_instance_valid(data) else null

	if is_instance_valid(_interactable_comp):
		_interactable_comp.inject_context(_ctx)

	_clear_geometry()
	_build_geometry()

func on_despawn() -> void:
	if is_instance_valid(_interactable_comp):
		_interactable_comp.disconnect_world_events()

func get_piece_key() -> String:
	return _piece_key

# ─────────────────────────────────────────────
# Geometrie
# ─────────────────────────────────────────────

func _build_geometry() -> void:
	if _def == null:
		# Fehlende Definition (Daten-Fehler): sichtbarer Platzhalter statt unsichtbarem Loch.
		AppLogger.log_error("BuildPiece '%s': keine BuildPieceDefinition — Platzhalter." % _piece_key, LOG_CAT)
		_add_box(Vector3(BuildGrid.CELL, 1.0, BuildGrid.CELL), Vector3(0, 0.5, 0), COL_MISSING)
		return

	_add_box(_def.get_box_size(BuildGrid.CELL), _def.get_box_center(), _def.color)

func _add_box(size: Vector3, center: Vector3, color: Color) -> void:
	var mesh := BoxMesh.new()
	mesh.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.9
	var mi := MeshInstance3D.new()
	mi.name = "Geom"
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = center
	add_child(mi)

	var shape := BoxShape3D.new()
	shape.size = size
	var col := CollisionShape3D.new()
	col.name = "GeomCol"
	col.shape = shape
	col.position = center
	add_child(col)

func _clear_geometry() -> void:
	for child in get_children():
		if child.name == "Geom" or child.name == "GeomCol" or child.name.begins_with("Geom"):
			remove_child(child)
			child.queue_free()

# ─────────────────────────────────────────────
# Interaktion (Abreißen)
# ─────────────────────────────────────────────

func _setup_interactable() -> void:
	var d := InteractableData.new()
	d.id           = ACTION_DISMANTLE
	d.label        = "Abreißen"
	d.duration     = 1.5
	d.xp_type      = "none"
	d.xp_amount    = 0
	d.loot_table   = null
	d.inspect_text = ""
	_interactable_comp = InteractableComponent.new()
	_interactable_comp.data = d
	add_child(_interactable_comp)
	_interactable_comp.interacted.connect(_on_interacted)

func _on_interacted(action_id: String, peer_id: int) -> void:
	if action_id != ACTION_DISMANTLE:
		return
	if not is_multiplayer_authority():
		return
	if not is_instance_valid(_ctx):
		AppLogger.log_error("_on_interacted(): kein EntityContext gespeichert.", LOG_CAT)
		return
	var network: NetworkBridge = _ctx.get_network_bridge()
	var player_id: String = network.get_player_id_for_peer(peer_id) if is_instance_valid(network) else ""
	var bus: IEventBus = _ctx.get_event_bus()
	if player_id.is_empty() or bus == null:
		AppLogger.log_warn("_on_interacted(): player_id/EventBus nicht verfügbar — Abreißen verweigert.", LOG_CAT)
		return
	bus.world().emit_build_remove_requested(player_id, _piece_key)
