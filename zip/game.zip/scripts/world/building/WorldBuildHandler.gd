class_name WorldBuildHandler
extends RefCounted

## WorldBuildHandler — Platzieren, Entfernen und Sichtbarmachen von Bauteilen.
##
## Kein Service, kein Node: Hilfsklasse von WorldService (Muster wie WorldSaveHandler).
## Alles Externe kommt über Callables — dadurch ohne SceneTree/Inventar testbar:
##   defs_cb(piece_id)                         -> BuildPieceDefinition | null
##   ground_fn(x, z)                           -> float (Geländehöhe, NAN = kein Boden; in Produktion
##                                                 TerrainField.get_height_at — kein Raycast nötig)
##   spawn_cb(type_id, pos, cfg)               -> Node3D | null
##   despawn_cb(node)                          -> void
##   can_afford(player_id, cost) / pay(player_id, cost) / refund(player_id, items)
##
## WAHRHEIT vs. ANSICHT: Die Bauteile leben als Records in BuildRegistry (WorldData, wird
## gespeichert). Die 3D-Nodes sind nur eine Ansicht: on_chunk_loaded() erzeugt sie, on_chunk_
## unloaded() entfernt sie wieder. So hängen keine Gebäude über einem entladenen (leeren)
## Chunk in der Luft, und nach dem Laden eines Spielstands erscheinen sie von selbst,
## sobald ihr Chunk geladen wird.

const LOG_CAT := "WorldBuild"
const ENTITY_TYPE: String = "build_piece"
## Maximale Entfernung Spieler → Bauplatz / Bauteil.
const REACH: float = 10.0

var _registry: BuildRegistry
var _editor: WorldTerrainEditor
var _defs_cb: Callable
var _ground_fn: Callable
var _spawn_cb: Callable
var _despawn_cb: Callable
var _chunk_size: float
## water_level_fn(x, z) -> float, i.d.R. TerrainField.get_water_level_at() — NICHT mehr eine
## einzelne Zahl, seit Flüsse je nach Ort einen eigenen Wasserspiegel haben (siehe
## BuildPlacementRules-Kommentar, BUGFIX 2026-09-20).
var _water_level_fn: Callable

var _can_afford: Callable = Callable()
var _pay: Callable = Callable()
var _refund: Callable = Callable()

## { key: Node3D } — aktuell existierende Ansichten.
var _nodes: Dictionary = {}

func _init(
	registry: BuildRegistry, editor: WorldTerrainEditor,
	defs_cb: Callable, ground_fn: Callable,
	spawn_cb: Callable, despawn_cb: Callable, chunk_size: float,
	water_level_fn: Callable = Callable()
) -> void:
	_registry = registry
	_editor = editor
	_defs_cb = defs_cb
	_ground_fn = ground_fn
	_spawn_cb = spawn_cb
	_despawn_cb = despawn_cb
	_chunk_size = chunk_size
	_water_level_fn = water_level_fn

## Materialkosten-Anbindung (WorldService: InventorySystem). Ohne diese Aufrufe ist Bauen
## kostenlos — nützlich für Tests, in Produktion IMMER setzen.
func set_inventory_ops(can_afford: Callable, pay: Callable, refund: Callable) -> void:
	_can_afford = can_afford
	_pay = pay
	_refund = refund

# ─────────────────────────────────────────────
# Vorschau / Platzieren / Entfernen
# ─────────────────────────────────────────────

## Vorschau OHNE Mutation (Geist im Baumodus).
## Rückgabe: {ok, reason, key, y, yaw, center: Vector2, affordable: bool, storey: int}
## storey: Ebene (0 = Gelände, siehe BuildGrid).
func preview(
	player_id: String, piece_id: String, target: Vector3, rot_steps: int, player_pos: Vector3, storey: int = 0
) -> Dictionary:
	var def: BuildPieceDefinition = _get_def(piece_id)
	if def == null:
		return {"ok": false, "reason": "unknown_piece", "key": "", "y": 0.0, "yaw": 0.0,
			"center": Vector2.ZERO, "affordable": false, "storey": storey}
	var snap: Dictionary = BuildGrid.snap(def.kind, target, rot_steps, storey)
	var check: Dictionary = _run_rules(def, snap, player_pos)
	var out: Dictionary = {
		"ok": bool(check["ok"]), "reason": String(check["reason"]), "key": String(snap["key"]),
		"y": float(check["y"]), "yaw": float(snap["yaw"]), "center": snap["center"],
		"affordable": _affordable(player_id, def), "storey": int(snap["storey"]),
	}
	if out["ok"] and _too_far(player_pos, snap["center"]):
		out["ok"] = false
		out["reason"] = "too_far"
	return out

## Platziert ein Bauteil. Rückgabe: {ok, reason, key}
func place(
	player_id: String, piece_id: String, target: Vector3, rot_steps: int, player_pos: Vector3, storey: int = 0
) -> Dictionary:
	var def: BuildPieceDefinition = _get_def(piece_id)
	if def == null:
		return _fail("unknown_piece")

	var snap: Dictionary = BuildGrid.snap(def.kind, target, rot_steps, storey)
	if _too_far(player_pos, snap["center"]):
		return _fail("too_far")

	var check: Dictionary = _run_rules(def, snap, player_pos)
	if not check["ok"]:
		return _fail(String(check["reason"]))

	if not _affordable(player_id, def):
		return _fail("no_materials")
	if _pay.is_valid() and not bool(_pay.call(player_id, def.cost)):
		return _fail("no_materials")

	# Ab hier keine Ablehnung mehr — Material ist bezahlt.
	if def.is_floor() and not (check["level"] as Dictionary).is_empty():
		_editor.apply_level((check["level"] as Dictionary)["changes"])

	var center: Vector2 = snap["center"]
	var record: Dictionary = {
		"key": snap["key"], "piece_id": def.id, "kind": def.kind,
		"x": center.x, "y": float(check["y"]), "z": center.y,
		"yaw": float(snap["yaw"]), "owner": player_id, "storey": int(snap["storey"]),
	}
	if not _registry.add(record):
		# Sollte durch den occupied-Check unmöglich sein — Material sicherheitshalber zurück.
		AppLogger.log_error("place(): Record '%s' ließ sich nicht eintragen." % record["key"], LOG_CAT)
		_give_back(player_id, def.cost)
		return _fail("occupied")

	_spawn(record)
	AppLogger.log_info("'%s' gebaut bei %s (Spieler '%s')." % [def.id, str(center), player_id], LOG_CAT)
	return {"ok": true, "reason": "", "key": record["key"]}

## Reißt ein Bauteil ab und erstattet Material (refund_ratio der Definition).
func remove(player_id: String, key: String, player_pos: Vector3) -> Dictionary:
	var rec: Dictionary = _registry.get_record(key)
	if rec.is_empty():
		return _fail("unknown_piece")
	if _too_far(player_pos, Vector2(float(rec["x"]), float(rec["z"]))):
		return _fail("too_far")

	# Nichts unter etwas Getragenem wegreißen — sonst schweben Wände/Böden darüber.
	if _registry.has_dependents(key):
		return _fail("supports_others")

	_registry.remove(key)
	_despawn_key(key)

	var def: BuildPieceDefinition = _get_def(String(rec.get("piece_id", "")))
	if def != null:
		var items: Dictionary = {}
		for item_id: String in def.cost.keys():
			var qty: int = def.refund_for(item_id)
			if qty > 0:
				items[item_id] = qty
		if not items.is_empty():
			_give_back(player_id, items)
	return {"ok": true, "reason": "", "key": key}

# ─────────────────────────────────────────────
# Chunk-Ansichten
# ─────────────────────────────────────────────

func on_chunk_loaded(coord: Vector2i) -> void:
	for rec in _registry.records_in_chunk(coord, _chunk_size):
		_spawn(rec)

func on_chunk_unloaded(coord: Vector2i) -> void:
	for rec in _registry.records_in_chunk(coord, _chunk_size):
		_despawn_key(String(rec["key"]))

## Anzahl aktuell existierender Ansichten (für Tests/Debug).
func get_view_count() -> int:
	var n: int = 0
	for node in _nodes.values():
		if is_instance_valid(node):
			n += 1
	return n

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _get_def(piece_id: String) -> BuildPieceDefinition:
	if not _defs_cb.is_valid():
		return null
	return _defs_cb.call(piece_id) as BuildPieceDefinition

func _run_rules(def: BuildPieceDefinition, snap: Dictionary, player_pos: Vector3) -> Dictionary:
	return BuildPlacementRules.check(def, snap, _registry, _ground_fn, _editor.get_layer(), player_pos, _water_level_fn)

func _affordable(player_id: String, def: BuildPieceDefinition) -> bool:
	if not _can_afford.is_valid():
		return true
	return bool(_can_afford.call(player_id, def.cost))

func _give_back(player_id: String, items: Dictionary) -> void:
	if _refund.is_valid():
		_refund.call(player_id, items)

## true, wenn die Position bekannt (nicht NAN) UND weiter als REACH entfernt ist.
func _too_far(player_pos: Vector3, target_xz: Vector2) -> bool:
	if is_nan(player_pos.x):
		return false
	return Vector2(player_pos.x, player_pos.z).distance_to(target_xz) > REACH

func _fail(reason: String) -> Dictionary:
	return {"ok": false, "reason": reason, "key": ""}

func _spawn(record: Dictionary) -> void:
	var key: String = String(record["key"])
	if _nodes.has(key) and is_instance_valid(_nodes[key]):
		return
	if not _spawn_cb.is_valid():
		return
	var pos := Vector3(float(record["x"]), float(record["y"]), float(record["z"]))
	var cfg: Dictionary = {
		"piece_id": String(record["piece_id"]), "key": key, "yaw": float(record.get("yaw", 0.0)),
	}
	var node: Node3D = _spawn_cb.call(ENTITY_TYPE, pos, cfg) as Node3D
	if is_instance_valid(node):
		_nodes[key] = node

func _despawn_key(key: String) -> void:
	var node: Variant = _nodes.get(key)
	_nodes.erase(key)
	if is_instance_valid(node) and _despawn_cb.is_valid():
		_despawn_cb.call(node)
