class_name BuildPlacementRules
extends RefCounted

## BuildPlacementRules — EINE Quelle der Wahrheit dafür, ob/wie ein Bauteil platziert werden
## darf. Wird vom echten Platzieren (WorldBuildHandler.place()) UND von der Vorschau
## (Geist im Baumodus) benutzt — dadurch kann der Geist nie "grün" zeigen, wo das Bauen
## dann doch scheitert.
##
## Rein statisch und ohne Engine-Zugriff: Höhen kommen über ground_fn, alles andere über
## Parameter. Kostenprüfung/Reichweite sind bewusst NICHT hier (hängen an Inventar bzw.
## Spielerposition) sondern im WorldBuildHandler.
##
## Rückgabe von check():
##   {ok: bool, reason: String, key: String, y: float, snap: Dictionary, level: Dictionary}
##   reason (bei ok=false): "occupied" | "no_ground" | "too_steep" | "unsupported" | "player_in_way" | "in_water"
##   y:     Basis-Oberkante des Bauteils (Boden: Oberkante; Wand: Unterkante der sichtbaren Wand)
##   level: nur FLOOR — Plan zum Einebnen des Geländes {ok, changes, target_y}, sonst {}

## Abstand, den ein Spieler mindestens von einer neuen Wand haben muss (sonst steckt er fest).
const PLAYER_CLEARANCE: float = 0.7
## Boden liegt minimal über dem (eingeebneten) Gelände — vermeidet Z-Fighting der Oberflächen.
## Mindestens TerrainEditLayer.QUANTUM: die Delta-Schicht rundet auf dieses Raster, ein
## kleinerer Wert würde beim Einebnen wegquantisiert und Boden/Gelände wären wieder plan.
const FLOOR_LIFT: float = 0.05
## Maximaler Höhenunterschied zwischen den Wandenden bei freistehender Wand (ohne Boden).
const MAX_WALL_SLOPE: float = 1.5
## Bauhöhe muss mindestens so weit über dem Wasserspiegel liegen (kein Bauen im/am Wasser).
const MIN_DRY_CLEARANCE: float = 0.2

static func check(
	def: BuildPieceDefinition,
	snap: Dictionary,
	registry: BuildRegistry,
	ground_fn: Callable,
	edit_layer: TerrainEditLayer = null,
	player_pos: Vector3 = Vector3(NAN, NAN, NAN),
	water_level: float = -INF
) -> Dictionary:
	var key: String = snap["key"]
	var result := {"ok": false, "reason": "", "key": key, "y": 0.0, "snap": snap, "level": {}}

	if registry.has_key(key):
		result["reason"] = "occupied"
		return result

	if def.is_floor():
		return _check_floor(def, snap, registry, ground_fn, edit_layer, water_level, result)
	return _check_wall(def, snap, registry, ground_fn, player_pos, water_level, result)

# ─────────────────────────────────────────────

static func _check_floor(
	_def: BuildPieceDefinition, snap: Dictionary, _registry: BuildRegistry,
	ground_fn: Callable, edit_layer: TerrainEditLayer, water_level: float, result: Dictionary
) -> Dictionary:
	var cell: Vector2i = snap["cell"]
	var corners: Array[Vector2i] = BuildGrid.floor_corner_lattice(cell)

	var sum: float = 0.0
	for p in corners:
		var w: Vector2 = TerrainEditLayer.lattice_to_world(p)
		var h: float = float(ground_fn.call(w.x, w.y))
		if is_nan(h):
			result["reason"] = "no_ground"
			return result
		sum += h

	# Bauhöhe = gerundeter Mittelwert der Ecken. Das Gelände wird darunter auf diese Höhe
	# eingeebnet (minus FLOOR_LIFT) — Böden liegen also plan, auch am Hang.
	var y: float = BuildGrid.quantize_y(sum / float(corners.size()))
	result["y"] = y
	if y < water_level + MIN_DRY_CLEARANCE:
		result["reason"] = "in_water"
		return result

	if edit_layer != null:
		var plan: Dictionary = edit_layer.plan_level(corners, y - FLOOR_LIFT, ground_fn)
		if not plan["ok"]:
			result["reason"] = plan["reason"]   # "too_steep" | "no_ground"
			return result
		plan["target_y"] = y - FLOOR_LIFT
		result["level"] = plan

	result["ok"] = true
	return result

static func _check_wall(
	_def: BuildPieceDefinition, snap: Dictionary, registry: BuildRegistry,
	ground_fn: Callable, player_pos: Vector3, water_level: float, result: Dictionary
) -> Dictionary:
	var axis: int = snap["axis"]
	var cell: Vector2i = snap["cell"]

	# Bau-Reihenfolge-Schutz: nicht auf den Spieler bauen.
	if not is_nan(player_pos.x):
		var d: float = BuildGrid.distance_to_wall(Vector2(player_pos.x, player_pos.z), axis, cell.x, cell.y)
		if d < PLAYER_CLEARANCE:
			result["reason"] = "player_in_way"
			return result

	# Angrenzende Böden bestimmen die Basishöhe (Wand steht AUF dem Boden).
	var floors: Array[Dictionary] = registry.floors_adjacent_to_wall(axis, cell.x, cell.y)
	if not floors.is_empty():
		var top: float = -INF
		for rec in floors:
			top = maxf(top, float(rec.get("y", 0.0)))
		result["y"] = top
		result["ok"] = true
		return result

	# Freistehend: braucht Bodenkontakt und darf nicht zu schräg stehen.
	var ends: Array[Vector2] = BuildGrid.wall_endpoints(axis, cell.x, cell.y)
	var center: Vector2 = snap["center"]
	var samples: Array[Vector2] = [ends[0], ends[1], center]
	var lo: float = INF
	var hi: float = -INF
	for s in samples:
		var h: float = float(ground_fn.call(s.x, s.y))
		if is_nan(h):
			result["reason"] = "no_ground"
			return result
		lo = minf(lo, h)
		hi = maxf(hi, h)
	if hi - lo > MAX_WALL_SLOPE:
		result["reason"] = "too_steep"
		return result
	# Basis auf die HÖCHSTE Stelle: Lücken nach unten füllt der Skirt, ins Gelände
	# ragende Wand-Enden am Hang gibt es dadurch nicht.
	result["y"] = BuildGrid.quantize_y(hi)
	if float(result["y"]) < water_level + MIN_DRY_CLEARANCE:
		result["reason"] = "in_water"
		return result
	result["ok"] = true
	return result

## Menschenlesbare Meldung zu einem reason-Code (für Benachrichtigungen).
static func reason_text(reason: String) -> String:
	match reason:
		"occupied":      return "Hier steht schon etwas."
		"no_ground":     return "Kein fester Boden gefunden."
		"too_steep":     return "Das Gelände ist hier zu uneben."
		"unsupported":   return "Hier hat das Bauteil keinen Halt."
		"player_in_way": return "Du stehst im Weg."
		"in_water":      return "Im Wasser kann man nicht bauen."
		"too_far":       return "Zu weit entfernt."
		"no_materials":  return "Dir fehlen Materialien."
		"unknown_piece": return "Unbekanntes Bauteil."
		"coop_unsupported": return "Bauen und Graben sind vorerst nur im Solo-Modus möglich."
		_:               return "Bauen nicht möglich."
