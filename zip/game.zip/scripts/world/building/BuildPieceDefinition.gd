class_name BuildPieceDefinition
extends Resource

## BuildPieceDefinition — Datengetriebene Beschreibung EINES Bauteils (Boden, Wand, Dach, ...).
##
## Neues Bauteil = neue .tres unter data/building/ + Eintrag in DataManifest.BUILD_PIECES.
## Solange es ein bekannter Kind ist (FLOOR/WALL/ROOF), ist KEIN Code nötig. Ein neuer Kind
## (z.B. Tür, Treppe) braucht Regeln in BuildGrid/BuildPlacementRules und Visuals in
## BuildPiece — die Erweiterungspunkte sind dort mit "ERWEITERUNG" markiert.

## ROOF (Dach): Satteldach-Segment über EINER Zelle. Braucht Wände derselben Ebene rund um
## die Zelle als Auflager (BuildPlacementRules._check_roof) — schließt ein Bauwerk nach oben
## ab. `height` ist hier NICHT die Wandhöhe, sondern die Firsthöhe über der Traufe (Auflage-
## punkt auf den Wänden). Geometrie: BuildPieceDefinition.build_roof_mesh() (Prisma/Walmdach-
## Ersatz), First verläuft entlang lokal X, Ausrichtung über yaw wie bei Wänden.
##
## DOOR/WINDOW (Tür/Fenster-Wand): teilen sich den Schlüsselraum UND die Platzierungsregeln
## mit WALL (BuildGrid.snap()/BuildPlacementRules.check() behandeln sie wie eine Wand — sie
## sitzen auf derselben Zellkante, schließen sich also gegenseitig mit einer normalen Wand
## aus). Einziger Unterschied: die Geometrie hat eine echte Öffnung (get_door_boxes()/
## get_window_boxes()) — mehrere Einzel-Boxen (Pfosten/Sturz/Brüstung) statt einer durch-
## gehenden Wandbox, jede mit eigener Kollision, damit man tatsächlich hindurchgehen kann.
##
## STAIRS (Treppe): belegt wie FLOOR/ROOF eine ZELLE, verbindet aber Ebene n mit n+1 begehbar
## (bisher nur per Bauen erreichbar, siehe docs/terrain-and-building.md). `height` = Aufstiegs-
## höhe (sollte BuildGrid.LEVEL_HEIGHT entsprechen, wie bei Wänden). Geometrie: STAIR_STEPS
## gestapelte Stufen (build_stairs_mesh()), Kollision als einzelne Stufen-Boxen
## (BuildPiece._add_stairs) statt einer durchgehenden (zu steilen) Rampe.
enum Kind { FLOOR, WALL, ROOF, DOOR, WINDOW, STAIRS }

## Breite der Durchgangsöffnung einer Tür, mittig auf der Zellkante. Rest der Wandfläche
## (Pfosten links/rechts + Sturz darüber) bleibt fest — siehe get_door_boxes().
const DOOR_WIDTH: float = 1.1
## Höhe der Türöffnung ab der Basis (y=0). Bei height <= DOOR_OPEN_HEIGHT entfällt der Sturz
## (Tür so hoch wie die Wand).
const DOOR_OPEN_HEIGHT: float = 2.0

## Breite/Höhe der Fensteröffnung sowie Brüstungshöhe ab der Basis — siehe get_window_boxes().
const WINDOW_WIDTH: float = 1.1
const WINDOW_SILL: float = 0.9
const WINDOW_OPEN_HEIGHT: float = 1.0

## Anzahl Stufen einer Treppe. Kollision (BuildPiece._add_stairs) UND Sichtgeometrie
## (build_stairs_mesh) teilen sich diese Konstante, damit Optik und begehbare Fläche
## übereinstimmen.
const STAIR_STEPS: int = 8

@export var id: String = ""
@export var display_name: String = ""
@export var kind: int = Kind.FLOOR
@export var color: Color = Color(0.55, 0.40, 0.25)

## FLOOR: Dicke der Platte (Oberkante = Bauhöhe).
## WALL:  sichtbare Höhe über der Basis.
@export var height: float = 0.3

## Nur WALL: Wanddicke in Metern.
@export var thickness: float = 0.2

## Wie tief das Bauteil UNTER seine Basis reicht. Versteckt Lücken zwischen Bauteil und
## unebenem Gelände (Boden ist nicht plan, Wände sind es). Rein optisch/kollisionsseitig.
@export var skirt: float = 0.8

## Baukosten: { item_id: Anzahl }. Werden beim Bauen abgezogen und beim Abreißen
## zu refund_ratio zurückgegeben (1.0 = vollständig).
@export var cost: Dictionary = {}
@export_range(0.0, 1.0) var refund_ratio: float = 1.0

func is_floor() -> bool:
	return kind == Kind.FLOOR

func is_wall() -> bool:
	return kind == Kind.WALL

func is_roof() -> bool:
	return kind == Kind.ROOF

func is_door() -> bool:
	return kind == Kind.DOOR

func is_window() -> bool:
	return kind == Kind.WINDOW

func is_stairs() -> bool:
	return kind == Kind.STAIRS

## Wandartig = belegt eine Zellkante wie WALL und benutzt dieselben Platzierungsregeln
## (BuildPlacementRules) — WALL, DOOR, WINDOW.
func is_wall_like() -> bool:
	return kind == Kind.WALL or kind == Kind.DOOR or kind == Kind.WINDOW

## GEOMETRIE — einzige Quelle für Bauteil (BuildPiece) UND Geist (Baumodus), damit die
## Vorschau nie anders aussieht als das fertige Bauteil. `cell` = BuildGrid.CELL (als Parameter,
## damit diese Ressource keine Abhängigkeit auf BuildGrid bekommt).
## Ursprung = Basis-Mittelpunkt (Oberkante bei Böden, Standfläche bei Wänden), +Y oben,
## Wandlänge entlang lokal X (Ausrichtung über yaw).
func get_box_size(cell: float) -> Vector3:
	var total: float = height + skirt
	if is_wall_like():
		return Vector3(cell, total, thickness)
	if is_roof():
		# Grobe Hüllbox fürs Kollisions-Shape (BuildPiece._build_geometry) — die sichtbare
		# Geometrie ist das Prisma aus build_roof_mesh(), nicht diese Box.
		return Vector3(cell, height, cell)
	if is_stairs():
		# Grobe Hüllbox — die sichtbare/begehbare Geometrie sind die Einzelstufen
		# (build_stairs_mesh() / BuildPiece._add_stairs()).
		return Vector3(cell, height, cell)
	return Vector3(cell, total, cell)

func get_box_center() -> Vector3:
	var total: float = height + skirt
	if is_wall_like():
		return Vector3(0.0, (height - skirt) * 0.5, 0.0)
	if is_roof() or is_stairs():
		return Vector3(0.0, height * 0.5, 0.0)
	return Vector3(0.0, -total * 0.5, 0.0)

## Boxen für eine Tür: zwei Pfosten (volle Wandhöhe inkl. Skirt) + Sturz über der Öffnung.
## Die Öffnung selbst (Boden bis DOOR_OPEN_HEIGHT, auch im Skirt-Bereich darunter) bleibt frei
## begehbar — kein Boxenteil dort, sonst würde die Schwelle auf unebenem Gelände blockieren.
## Gemeinsame Quelle für BuildPiece (Einzel-Boxen + je eigene Kollision) und BuildGhost
## (build_framed_mesh() kombiniert dieselben Boxen zu einem Vorschau-Mesh).
func get_door_boxes(cell: float) -> Array[Dictionary]:
	var hc: float = cell * 0.5
	var half_w: float = clampf(DOOR_WIDTH * 0.5, 0.05, hc - 0.05)
	var open_h: float = clampf(DOOR_OPEN_HEIGHT, 0.1, height)
	var total: float = height + skirt
	var jamb_w: float = hc - half_w
	var boxes: Array[Dictionary] = []
	boxes.append({"size": Vector3(jamb_w, total, thickness),
		"center": Vector3(-(hc + half_w) * 0.5, (height - skirt) * 0.5, 0.0)})
	boxes.append({"size": Vector3(jamb_w, total, thickness),
		"center": Vector3((hc + half_w) * 0.5, (height - skirt) * 0.5, 0.0)})
	if open_h < height:
		boxes.append({"size": Vector3(DOOR_WIDTH, height - open_h, thickness),
			"center": Vector3(0.0, (open_h + height) * 0.5, 0.0)})
	return boxes

## Boxen für ein Fenster: zwei Pfosten (volle Höhe), Brüstung (Boden bis WINDOW_SILL) und
## Sturz (WINDOW_SILL+WINDOW_OPEN_HEIGHT bis Wandhöhe) — die Öffnung dazwischen bleibt frei.
func get_window_boxes(cell: float) -> Array[Dictionary]:
	var hc: float = cell * 0.5
	var half_w: float = clampf(WINDOW_WIDTH * 0.5, 0.05, hc - 0.05)
	var sill_top: float = clampf(WINDOW_SILL, 0.0, height)
	var open_top: float = clampf(sill_top + WINDOW_OPEN_HEIGHT, sill_top, height)
	var total: float = height + skirt
	var jamb_w: float = hc - half_w
	var boxes: Array[Dictionary] = []
	boxes.append({"size": Vector3(jamb_w, total, thickness),
		"center": Vector3(-(hc + half_w) * 0.5, (height - skirt) * 0.5, 0.0)})
	boxes.append({"size": Vector3(jamb_w, total, thickness),
		"center": Vector3((hc + half_w) * 0.5, (height - skirt) * 0.5, 0.0)})
	boxes.append({"size": Vector3(WINDOW_WIDTH, sill_top + skirt, thickness),
		"center": Vector3(0.0, (sill_top - skirt) * 0.5, 0.0)})
	if open_top < height:
		boxes.append({"size": Vector3(WINDOW_WIDTH, height - open_top, thickness),
			"center": Vector3(0.0, (open_top + height) * 0.5, 0.0)})
	return boxes

## Sichtbare Geometrie eines Dach-Bauteils: Satteldach-Prisma über einer Zelle, First entlang
## lokal X bei y=height, Traufe (Basis) bei y=0 auf den vier Eckpunkten der Zelle. Gemeinsame
## Quelle für BuildPiece (fertiges Bauteil) UND BuildGhost (Vorschau) — dieselbe Regel wie bei
## get_box_size()/get_box_center() für Boden/Wand: der Geist sieht immer so aus wie das Ergebnis.
static func build_roof_mesh(cell: float, height: float) -> ArrayMesh:
	var h: float = maxf(height, 0.05)
	var hc: float = cell * 0.5
	# Traufe (4 Eckpunkte, y=0) + First (2 Punkte, y=h, entlang X bei z=0).
	var v_fl := Vector3(-hc, 0.0, -hc)   # front-left
	var v_fr := Vector3(hc, 0.0, -hc)    # front-right
	var v_bl := Vector3(-hc, 0.0, hc)    # back-left
	var v_br := Vector3(hc, 0.0, hc)     # back-right
	var r_l := Vector3(-hc, h, 0.0)      # First links
	var r_r := Vector3(hc, h, 0.0)       # First rechts

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)

	# Zwei geneigte Dachflächen (je ein Quad aus zwei Dreiecken).
	_add_quad(st, v_fl, v_fr, r_r, r_l)   # Vorderseite (Traufe bei z=-hc → First)
	_add_quad(st, v_br, v_bl, r_l, r_r)   # Rückseite (Traufe bei z=+hc → First)
	# Zwei Giebeldreiecke (Ost/West).
	_add_tri(st, v_fr, v_br, r_r)
	_add_tri(st, v_bl, v_fl, r_l)
	# Unterseite (Boden des Prismas) — sichtbar für Spieler, die von innen hochschauen.
	_add_quad(st, v_fl, v_bl, v_br, v_fr)

	st.generate_normals()
	return st.commit()

static func _add_tri(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3) -> void:
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)

## Quad aus vier Punkten (Reihenfolge = Umlauf), als zwei Dreiecke, Normale nach außen.
static func _add_quad(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, d: Vector3) -> void:
	_add_tri(st, a, b, c)
	_add_tri(st, a, c, d)

## Sichtbare Geometrie einer Treppe: STAIR_STEPS gestapelte Stufen, aufsteigend entlang lokal Z
## von -cell/2 (y=0) nach +cell/2 (y=height). Gemeinsame Quelle für BuildPiece UND BuildGhost —
## dieselbe Stufenteilung wie die Kollision in BuildPiece._add_stairs(), damit Vorschau, Optik
## und begehbare Fläche übereinstimmen.
static func build_stairs_mesh(cell: float, height: float) -> ArrayMesh:
	var steps: int = STAIR_STEPS
	var step_h: float = maxf(height, 0.05) / float(steps)
	var step_d: float = cell / float(steps)
	var hc: float = cell * 0.5

	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for i in steps:
		var z0: float = -hc + step_d * float(i)
		var z1: float = z0 + step_d
		var y1: float = step_h * float(i + 1)
		_add_box_geom(st, Vector3(-hc, 0.0, z0), Vector3(hc, y1, z1))
	st.generate_normals()
	return st.commit()

## Kombinierte Box-Geometrie aus mehreren {size, center}-Einträgen (Tür-/Fensterrahmen, siehe
## get_door_boxes()/get_window_boxes()) — EIN Mesh für den Geist (BuildGhost benutzt nur eine
## MeshInstance3D); das fertige BuildPiece rendert dieselben Boxen einzeln (siehe
## BuildPiece._add_framed()), mit je eigener Kollision.
static func build_framed_mesh(boxes: Array[Dictionary]) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for b: Dictionary in boxes:
		var size: Vector3 = b["size"]
		var center: Vector3 = b["center"]
		var half: Vector3 = size * 0.5
		_add_box_geom(st, center - half, center + half)
	st.generate_normals()
	return st.commit()

## Achsenausgerichtete Box aus zwei Eckpunkten (lo/hi) als sechs Quads. Hilfsfunktion für
## build_stairs_mesh()/build_framed_mesh(), benutzt dieselben _add_quad()/_add_tri() wie
## build_roof_mesh().
static func _add_box_geom(st: SurfaceTool, lo: Vector3, hi: Vector3) -> void:
	var a := Vector3(lo.x, lo.y, lo.z)
	var b := Vector3(hi.x, lo.y, lo.z)
	var c := Vector3(hi.x, lo.y, hi.z)
	var d := Vector3(lo.x, lo.y, hi.z)
	var e := Vector3(lo.x, hi.y, lo.z)
	var f := Vector3(hi.x, hi.y, lo.z)
	var g := Vector3(hi.x, hi.y, hi.z)
	var h := Vector3(lo.x, hi.y, hi.z)
	_add_quad(st, d, c, b, a)   # unten
	_add_quad(st, e, f, g, h)   # oben
	_add_quad(st, a, b, f, e)   # -Z Seite
	_add_quad(st, c, d, h, g)   # +Z Seite
	_add_quad(st, b, c, g, f)   # +X Seite
	_add_quad(st, d, a, e, h)   # -X Seite

## Rückgabemenge für ein Item beim Abreißen (abgerundet, nie mehr als investiert).
func refund_for(item_id: String) -> int:
	var spent: int = int(cost.get(item_id, 0))
	return mini(spent, int(floor(float(spent) * refund_ratio)))
