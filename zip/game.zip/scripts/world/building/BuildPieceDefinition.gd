class_name BuildPieceDefinition
extends Resource

## BuildPieceDefinition — Datengetriebene Beschreibung EINES Bauteils (Boden, Wand, ...).
##
## Neues Bauteil = neue .tres unter data/building/ + Eintrag in DataManifest.BUILD_PIECES.
## Solange es ein bekannter Kind ist (FLOOR/WALL), ist KEIN Code nötig. Ein neuer Kind
## (z.B. Dach, Tür, Treppe) braucht Regeln in BuildGrid/BuildPlacementRules und Visuals in
## BuildPiece — die Erweiterungspunkte sind dort mit "ERWEITERUNG" markiert.

enum Kind { FLOOR, WALL }

@export var id: String = ""
@export var display_name: String = ""
@export var kind: int = Kind.FLOOR
@export var color: Color = Color(0.55, 0.40, 0.25)

## FLOOR: Dicke der Platte (Oberkante = Bauhöhe).
## WALL:  sichtbare Höhe über der Basis.
@export var height: float = 0.3

## Nur WALL: Wanddicke in Metern.
@export var thickness: float = 0.2

## Wie tief das Bauteil UNTER seine Basis reicht. Versteckt Lücken zwischen Bauteil und
## unebenem Gelände (Boden ist nicht plan, Wände sind es). Rein optisch/kollisionsseitig.
@export var skirt: float = 0.8

## Baukosten: { item_id: Anzahl }. Werden beim Bauen abgezogen und beim Abreißen
## zu refund_ratio zurückgegeben (1.0 = vollständig).
@export var cost: Dictionary = {}
@export_range(0.0, 1.0) var refund_ratio: float = 1.0

func is_floor() -> bool:
	return kind == Kind.FLOOR

func is_wall() -> bool:
	return kind == Kind.WALL

## GEOMETRIE — einzige Quelle für Bauteil (BuildPiece) UND Geist (Baumodus), damit die
## Vorschau nie anders aussieht als das fertige Bauteil. `cell` = BuildGrid.CELL (als Parameter,
## damit diese Ressource keine Abhängigkeit auf BuildGrid bekommt).
## Ursprung = Basis-Mittelpunkt (Oberkante bei Böden, Standfläche bei Wänden), +Y oben,
## Wandlänge entlang lokal X (Ausrichtung über yaw).
func get_box_size(cell: float) -> Vector3:
	var total: float = height + skirt
	if is_wall():
		return Vector3(cell, total, thickness)
	return Vector3(cell, total, cell)

func get_box_center() -> Vector3:
	var total: float = height + skirt
	if is_wall():
		return Vector3(0.0, (height - skirt) * 0.5, 0.0)
	return Vector3(0.0, -total * 0.5, 0.0)

## Rückgabemenge für ein Item beim Abreißen (abgerundet, nie mehr als investiert).
func refund_for(item_id: String) -> int:
	var spent: int = int(cost.get(item_id, 0))
	return mini(spent, int(floor(float(spent) * refund_ratio)))
