class_name BuildPanelController
extends Node

## BuildPanelController — füllt das Bau-Menü mit den Bauteilen aus DataService.get_all_build_pieces()
## UND den Hausvorlagen aus DataService.get_all_house_templates(), markiert jeweils, was sich der
## Spieler gerade leisten kann (aus dem Inventar).
##
## Wahl eines Bauteils → Fenster schließt, piece_selected(piece_id). Wahl eines Hauses → Fenster
## schließt, house_selected(template_id). HUDBuilder verbindet beide mit dem BuildModeController
## (start()/start_house()).

signal piece_selected(piece_id: String)
## Wahl einer kompletten Hausvorlage — HUDBuilder verbindet das mit
## BuildModeController.start_house(), analog piece_selected/start().
signal house_selected(template_id: String)

const LOG_CAT := "BuildPanel"

var _visuals: BuildPanelVisuals
var _ctx: IUIContext

func setup(visuals: BuildPanelVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx = ctx
	_visuals.piece_chosen.connect(_on_piece_chosen)
	_visuals.house_chosen.connect(_on_house_chosen)
	_visuals.panel.visibility_changed.connect(_on_visibility_changed)
	refresh()

func _ready() -> void:
	var inv: InventorySystem = _ctx.get_inventory() if is_instance_valid(_ctx) else null
	if is_instance_valid(inv) and not inv.inventory_changed.is_connected(_on_inventory_changed):
		inv.inventory_changed.connect(_on_inventory_changed)

func _exit_tree() -> void:
	var inv: InventorySystem = _ctx.get_inventory() if is_instance_valid(_ctx) else null
	if is_instance_valid(inv) and inv.inventory_changed.is_connected(_on_inventory_changed):
		inv.inventory_changed.disconnect(_on_inventory_changed)

func refresh() -> void:
	if not is_instance_valid(_visuals):
		return
	_visuals.set_entries(build_entries(_ctx))
	_visuals.set_house_entries(build_house_entries(_ctx))

## Bauteil-Einträge fürs Menü. Statisch, damit ohne UI testbar.
static func build_entries(ctx: IUIContext) -> Array[Dictionary]:
	var entries: Array[Dictionary] = []
	var data: DataService = ctx.get_data() if is_instance_valid(ctx) else null
	if not is_instance_valid(data):
		return entries
	var inv: InventorySystem = ctx.get_inventory()
	var player_id: String = ctx.get_local_player_id()
	for piece in data.get_all_build_pieces():
		entries.append({
			"id": piece.id,
			"name": piece.display_name,
			"cost_text": format_cost(piece.cost, inv),
			"affordable": can_afford(piece.cost, inv, player_id),
		})
	return entries

## Hausvorlagen-Einträge fürs Menü. Statisch, damit ohne UI testbar (wie build_entries()).
## Die Materialkosten kommen aus HouseTemplateDefinition.total_cost() — braucht dieselben
## BuildPieceDefinition-Objekte wie die Einzelteile-Liste, deshalb data.get_build_piece als
## Callable (siehe HouseTemplateDefinition-Klassenkommentar, "kein DataService dort").
static func build_house_entries(ctx: IUIContext) -> Array[Dictionary]:
	var entries: Array[Dictionary] = []
	var data: DataService = ctx.get_data() if is_instance_valid(ctx) else null
	if not is_instance_valid(data):
		return entries
	var inv: InventorySystem = ctx.get_inventory()
	var player_id: String = ctx.get_local_player_id()
	for house: HouseTemplateDefinition in data.get_all_house_templates():
		var cost: Dictionary = house.total_cost(data.get_build_piece)
		entries.append({
			"id": house.id,
			"name": house.display_name,
			"description": house.description,
			"cost_text": format_cost(cost, inv),
			"affordable": can_afford(cost, inv, player_id),
		})
	return entries

## "3× Holz, 5× Stein" — Item-Namen aus dem Inventar-Register (Fallback: die ID).
static func format_cost(cost: Dictionary, inv: InventorySystem) -> String:
	var parts: PackedStringArray = []
	for item_id: String in cost.keys():
		var item_name: String = item_id
		if is_instance_valid(inv):
			var def: ItemDefinition = inv.get_item_info(item_id)
			if is_instance_valid(def) and not def.display_name.is_empty():
				item_name = def.display_name
		parts.append("%d× %s" % [int(cost[item_id]), item_name])
	return ", ".join(parts)

static func can_afford(cost: Dictionary, inv: InventorySystem, player_id: String) -> bool:
	if not is_instance_valid(inv):
		return false
	for item_id: String in cost.keys():
		if not inv.has_item(item_id, player_id, int(cost[item_id])):
			return false
	return true

func _on_piece_chosen(piece_id: String) -> void:
	_visuals.close()
	piece_selected.emit(piece_id)

func _on_house_chosen(template_id: String) -> void:
	_visuals.close()
	house_selected.emit(template_id)

func _on_visibility_changed() -> void:
	if is_instance_valid(_visuals) and _visuals.panel.visible:
		refresh()

func _on_inventory_changed(player_id: String, _items: Array[Dictionary]) -> void:
	if is_instance_valid(_ctx) and player_id == _ctx.get_local_player_id() and is_instance_valid(_visuals) and _visuals.panel.visible:
		refresh()
