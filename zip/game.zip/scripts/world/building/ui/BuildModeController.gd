class_name BuildModeController
extends Node

## BuildModeController — der Baumodus: Geist vor dem Spieler, Drehen, Bauen, Abbrechen.
##
## ABLAUF: Bau-Menü → start(piece_id). Jeden Frame: Zielpunkt TARGET_DISTANCE Meter vor dem Spieler
## (Player.get_ground_target) → WorldService.preview_build() (dieselben Regeln wie das echte Bauen,
## siehe BuildPlacementRules) → Geist rastet aufs Raster ein und färbt sich. ✔ schickt
## build_place_requested; der Modus bleibt aktiv (mehrere Teile hintereinander bauen). ✕ beendet.
## Spieler bewegen = Geist bewegen — kein Zielen per Touch nötig.
##
## Die UI liest nur (preview_build über ctx.get_world()) — alle Änderungen gehen als Event über
## den EventBus an den WorldService.

const TARGET_DISTANCE: float = 3.0
const LOG_CAT := "BuildMode"

var _visuals: BuildModeVisuals
var _ctx: IUIContext
var _piece_id: String = ""
var _rot_steps: int = 0
var _ghost: BuildGhost = null
var _active: bool = false
var _last_preview: Dictionary = {}
var _last_target: Vector3 = Vector3.ZERO

func setup(visuals: BuildModeVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx = ctx
	_visuals.rotate_button.pressed.connect(_on_rotate_pressed)
	_visuals.place_button.pressed.connect(_on_place_pressed)
	_visuals.cancel_button.pressed.connect(stop)
	set_process(false)

func is_active() -> bool:
	return _active

## Startet den Baumodus für ein Bauteil (Aufruf aus BuildPanelController.piece_selected).
func start(piece_id: String) -> void:
	stop()
	var data: DataService = _ctx.get_data() if is_instance_valid(_ctx) else null
	var def: BuildPieceDefinition = data.get_build_piece(piece_id) if is_instance_valid(data) else null
	var player: Node3D = _ctx.get_local_player() if is_instance_valid(_ctx) else null
	if def == null or not is_instance_valid(player):
		AppLogger.log_warn("Baumodus: Definition '%s' oder Spieler fehlt." % piece_id, LOG_CAT)
		return
	_piece_id = piece_id
	_rot_steps = 0
	_ghost = BuildGhost.new()
	_ghost.configure(def)
	# In die Spielwelt hängen (Elternknoten des Spielers), nicht ins HUD.
	player.get_parent().add_child(_ghost)
	_active = true
	_visuals.set_active(true)
	set_process(true)

func stop() -> void:
	_active = false
	set_process(false)
	_last_preview = {}
	if is_instance_valid(_ghost):
		_ghost.queue_free()
	_ghost = null
	if is_instance_valid(_visuals):
		_visuals.set_active(false)
		_visuals.set_reason("")

func _exit_tree() -> void:
	if is_instance_valid(_ghost):
		_ghost.queue_free()

func _process(_delta: float) -> void:
	if not _active:
		return
	var player: Node3D = _ctx.get_local_player()
	var world: WorldService = _ctx.get_world()
	if not is_instance_valid(player) or not is_instance_valid(world) or not is_instance_valid(_ghost):
		stop()
		return

	# call() statt direktem Aufruf: Player ist hier nur als Node3D typisiert (IUIContext.get_local_player()).
	_last_target = player.call("get_ground_target", TARGET_DISTANCE)
	_last_preview = world.preview_build(_ctx.get_local_player_id(), _piece_id, _last_target, _rot_steps)

	var center: Vector2 = _last_preview["center"]
	var y: float = float(_last_preview["y"]) if bool(_last_preview["ok"]) else _ground_y(world, center)
	_ghost.apply_state(Vector3(center.x, y, center.y), float(_last_preview["yaw"]), BuildGhost.state_from_preview(_last_preview))

	var ok: bool = bool(_last_preview["ok"])
	var affordable: bool = bool(_last_preview["affordable"])
	_visuals.set_place_enabled(ok and affordable)
	if not ok:
		_visuals.set_reason(BuildPlacementRules.reason_text(String(_last_preview["reason"])))
	elif not affordable:
		_visuals.set_reason(BuildPlacementRules.reason_text("no_materials"))
	else:
		_visuals.set_reason("")

func _on_rotate_pressed() -> void:
	_rot_steps = posmod(_rot_steps + 1, 4)

func _on_place_pressed() -> void:
	if not _active or _last_preview.is_empty():
		return
	if not (bool(_last_preview["ok"]) and bool(_last_preview["affordable"])):
		return
	var bus: IEventBus = _ctx.bus()
	if bus == null:
		return
	bus.world().emit_build_place_requested(_ctx.get_local_player_id(), _piece_id, _last_target, _rot_steps)

func _ground_y(world: WorldService, center: Vector2) -> float:
	var terrain: TerrainField = world.get_terrain()
	return terrain.get_height_at(center.x, center.y) if terrain != null else 0.0
