class_name BuildModeVisuals

## BuildModeVisuals — Bedienelemente im Baumodus: Drehen, Bauen, Abbrechen + Hinweistext.
## Sitzt mittig über der HP-Leiste (0.5 / 0.62) — überlappt weder Joystick noch Sprung/Aktionen.

var container: HBoxContainer
var rotate_button: Button
var place_button: Button
var cancel_button: Button
var reason_label: Label
var _root: Control

func _init(parent: CanvasLayer) -> void:
	_root = Control.new()
	_root.name = "BuildModeControls"
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.visible = false

	reason_label = Label.new()
	reason_label.name = "BuildReason"
	reason_label.anchor_left   = 0.5
	reason_label.anchor_right  = 0.5
	reason_label.anchor_top    = 0.55
	reason_label.anchor_bottom = 0.55
	reason_label.offset_left   = -320
	reason_label.offset_right  = 320
	reason_label.offset_top    = -20
	reason_label.offset_bottom = 20
	reason_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	reason_label.add_theme_font_size_override("font_size", 22)
	reason_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	reason_label.add_theme_constant_override("outline_size", 6)
	reason_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(reason_label)

	container = HBoxContainer.new()
	container.name = "BuildButtons"
	container.anchor_left   = 0.5
	container.anchor_right  = 0.5
	container.anchor_top    = 0.62
	container.anchor_bottom = 0.62
	container.offset_left   = -170
	container.offset_right  = 170
	container.offset_top    = -52
	container.offset_bottom = 52
	container.add_theme_constant_override("separation", 14)
	container.alignment = BoxContainer.ALIGNMENT_CENTER
	_root.add_child(container)

	rotate_button = _make_button("BuildRotateButton", "⟳")
	place_button  = _make_button("BuildPlaceButton", "✔")
	cancel_button = _make_button("BuildCancelButton", "✕")
	place_button.custom_minimum_size = Vector2(UIMetrics.TOOLBAR_BUTTON + 40, UIMetrics.TOOLBAR_BUTTON + 16)
	container.add_child(rotate_button)
	container.add_child(place_button)
	container.add_child(cancel_button)

	parent.add_child(_root)

func set_active(active: bool) -> void:
	_root.visible = active

func set_reason(text: String) -> void:
	reason_label.text = text

func set_place_enabled(enabled: bool) -> void:
	place_button.disabled = not enabled

func _make_button(node_name: String, text: String) -> Button:
	var b := Button.new()
	b.name = node_name
	b.text = text
	b.custom_minimum_size = Vector2(UIMetrics.TOOLBAR_BUTTON, UIMetrics.TOOLBAR_BUTTON + 16)
	b.add_theme_font_size_override("font_size", 34)
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	return b
