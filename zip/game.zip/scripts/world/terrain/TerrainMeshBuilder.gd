class_name TerrainMeshBuilder
extends RefCounted

## TerrainMeshBuilder — Baut Terrain-MeshInstance3D und Physics-Body aus einer Heightmap.
##
## Bekommt fertige Höhen (aus TerrainField, via TerrainChunkBuilder) — kennt selbst weder
## Noise noch Seed. Rein: Höhen rein, Mesh/Kollision raus.
##
## Verantwortung:
##   - Vertices, Normals, Colors, Indices assemblieren
##   - Normalen per Vertex berechnen (Durchschnitt anliegender Dreiecke)
##   - MeshInstance3D mit StandardMaterial3D zurückgeben
##   - StaticBody3D mit HeightMapShape3D zurückgeben
##
## Verwendet TerrainColorizer für Vertex-Farben.

const LOG_CAT := "TerrainMeshBuilder"

var _colorizer: TerrainColorizer

func _init() -> void:
	_colorizer = TerrainColorizer.new()

## Baut MeshInstance3D aus der Heightmap.
## biome_cb: Callable(world_x: float, world_z: float) -> Color (BiomeDefinition.
## terrain_color_grass des jeweiligen Bioms an dieser Weltposition, siehe
## TerrainChunkBuilder._biome_color()).
func build_terrain_mesh(
	heights:      PackedFloat32Array,
	resolution:   int,
	size:         float,
	max_height:   float,
	sea_level:    float,
	world_offset: Vector2,
	biome_cb:     Callable
) -> MeshInstance3D:
	var n    := resolution + 1
	var step := size / float(resolution)
	var half := size * 0.5

	var verts:   PackedVector3Array = PackedVector3Array()
	var normals: PackedVector3Array = PackedVector3Array()
	var colors:  PackedColorArray   = PackedColorArray()
	var indices: PackedInt32Array   = PackedInt32Array()

	for z_i in range(n):
		for x_i in range(n):
			var h:       float = heights[z_i * n + x_i]
			var vx:      float = x_i * step - half
			var vz:      float = z_i * step - half
			var world_x: float = world_offset.x + vx
			var world_z: float = world_offset.y + vz
			var biome:   Color = biome_cb.call(world_x, world_z) if biome_cb.is_valid() else _colorizer.COL_GRASS

			verts.append(Vector3(vx, h, vz))
			colors.append(_colorizer.height_to_color(h, biome, max_height, sea_level))
			normals.append(Vector3.UP)  # Placeholder, wird unten überschrieben

	for z_i in range(resolution):
		for x_i in range(resolution):
			var i00: int = z_i * n + x_i
			var i10: int = i00 + 1
			var i01: int = (z_i + 1) * n + x_i
			var i11: int = i01 + 1
			indices.append(i00); indices.append(i01); indices.append(i10)
			indices.append(i10); indices.append(i01); indices.append(i11)

	# Vertex-Normals: Durchschnitt der anliegenden Dreiecksnormalen
	var tri_normals: Array[Vector3] = []
	tri_normals.resize(verts.size())
	tri_normals.fill(Vector3.ZERO)

	for tri_i in range(0, indices.size(), 3):
		var a := indices[tri_i]; var b := indices[tri_i + 1]; var c := indices[tri_i + 2]
		var n_vec: Vector3 = (verts[b] - verts[a]).cross(verts[c] - verts[a]).normalized()
		tri_normals[a] += n_vec
		tri_normals[b] += n_vec
		tri_normals[c] += n_vec

	for i in range(verts.size()):
		normals[i] = tri_normals[i].normalized()

	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = normals
	arr[Mesh.ARRAY_COLOR]  = colors
	arr[Mesh.ARRAY_INDEX]  = indices

	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)

	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness  = 0.9
	mat.metallic   = 0.0
	# CULL_DISABLED: Terrain-Backfaces müssen sichtbar sein wenn die Kamera
	# z.B. beim Fallen unter das Mesh gerät oder Chunks seitlich sichtbar sind.
	mat.cull_mode  = BaseMaterial3D.CULL_DISABLED

	var mi := MeshInstance3D.new()
	mi.mesh              = mesh
	mi.material_override = mat
	mi.position.y        = 0.0
	return mi

## Baut StaticBody3D mit HeightMapShape3D aus der Heightmap.
func build_physics_body(
	heights:    PackedFloat32Array,
	resolution: int,
	size:       float
) -> StaticBody3D:
	var body  := StaticBody3D.new()
	var col   := CollisionShape3D.new()
	var shape := HeightMapShape3D.new()

	shape.map_width = resolution + 1
	shape.map_depth = resolution + 1
	shape.map_data  = heights

	col.shape = shape
	body.add_child(col)

	# HeightMapShape3D: 1 Unit/Vertex → auf Weltgröße skalieren via StaticBody3D.scale
	var scale_xz: float = size / float(resolution)
	body.scale = Vector3(scale_xz, 1.0, scale_xz)
	return body
