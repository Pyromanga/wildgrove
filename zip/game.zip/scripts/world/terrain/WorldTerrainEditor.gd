class_name WorldTerrainEditor
extends RefCounted

## WorldTerrainEditor — führt Gelände-Änderungen aus (Graben, Aufschütten, Einebnen).
##
## Kein Service, kein Node: Hilfsklasse von WorldService (gleiches Muster wie
## WorldSaveHandler/WorldSpawner). Kennt weder Inventar noch Spieler — Materialkosten
## (Erde) und Reichweite prüft der Aufrufer (WorldService). Hier nur: Regeln + Mutation +
## Neubau der betroffenen Chunks.
##
## Bauwerke sind tabu: in der Nähe eines Bauteils wird nicht gegraben (sonst hingen Wände
## in der Luft oder steckten im Boden). Einebnen für Böden läuft über apply_level() und
## umgeht diese Sperre bewusst — es ist ja der Bau selbst.

const LOG_CAT := "TerrainEdit"

const MODE_DIG: String = "dig"
const MODE_FILL: String = "fill"

## Pinselradius in Metern (deckt bei 2 m Gitter das Zentrum + 4 Nachbarn + Diagonalen ab).
const BRUSH_RADIUS: float = 3.5
## Änderung pro Aktion am Zentrum (Meter). Nachbarn bekommen weniger (weicher Verlauf).
const DIG_STEP: float = -0.5
const FILL_STEP: float = 0.5
## Maximale Entfernung Spieler → Zielpunkt.
const REACH: float = 6.0

var _layer: TerrainEditLayer
var _registry: BuildRegistry
## func(points: Array[Vector2i]) -> void — baut betroffene, geladene Chunks neu.
var _refresh_cb: Callable

func _init(layer: TerrainEditLayer, registry: BuildRegistry, refresh_cb: Callable) -> void:
	_layer = layer
	_registry = registry
	_refresh_cb = refresh_cb

func get_layer() -> TerrainEditLayer:
	return _layer

## Graben oder Aufschütten an `target`.
## Rückgabe: {ok, reason, changed: Array[Vector2i]}
##   reason: "" | "bad_mode" | "building_nearby" | "limit"
func edit(mode: String, target: Vector3) -> Dictionary:
	if mode != MODE_DIG and mode != MODE_FILL:
		return {"ok": false, "reason": "bad_mode", "changed": []}
	if _registry != null and _registry.is_area_occupied(target.x, target.z, BRUSH_RADIUS):
		return {"ok": false, "reason": "building_nearby", "changed": []}
	var amount: float = DIG_STEP if mode == MODE_DIG else FILL_STEP
	var changed: Array[Vector2i] = _layer.apply_brush(target.x, target.z, BRUSH_RADIUS, amount)
	if changed.is_empty():
		return {"ok": false, "reason": "limit", "changed": []}
	_refresh(changed)
	AppLogger.log_debug("Gelände %s @ (%.1f, %.1f): %d Punkte." % [mode, target.x, target.z, changed.size()], LOG_CAT)
	return {"ok": true, "reason": "", "changed": changed}

## Wendet einen TerrainEditLayer.plan_level()-Plan an (Einebnen unter einem Boden).
func apply_level(changes: Dictionary) -> Array[Vector2i]:
	var changed: Array[Vector2i] = _layer.apply_changes(changes)
	if not changed.is_empty():
		_refresh(changed)
	return changed

func _refresh(points: Array[Vector2i]) -> void:
	if _refresh_cb.is_valid():
		_refresh_cb.call(points)

## Menschenlesbare Meldung zu einem reason-Code.
static func reason_text(reason: String) -> String:
	match reason:
		"building_nearby": return "Zu nah an einem Bauwerk."
		"limit":           return "Tiefer oder höher geht es hier nicht."
		"too_far":         return "Zu weit entfernt."
		"no_dirt":         return "Du brauchst Erde zum Aufschütten."
		"inventory_full":  return "Dein Inventar ist voll."
		"coop_unsupported": return "Bauen und Graben sind vorerst nur im Solo-Modus möglich."
		_:                 return "Das geht hier nicht."
