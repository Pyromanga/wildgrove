# res://scripts/world/terrain/BiomeRegistry.gd
class_name BiomeRegistry

## BiomeRegistry — Statische Sammlung aller Biom-Definitionen.
##
## Kein externes .tres nötig: Biome werden hier code-seitig definiert.
## Vorteil: kein DirAccess/DataManifest-Overhead, sofort refaktorierbar.
##
## Noise-Zuweisung via get_biome_for(temp, humid):
##   temp  –1..1  (kalt → warm)
##   humid –1..1  (trocken → feucht)

const LOG_CAT := "BiomeRegistry"

## Alle registrierten Biome, keyed by biome_id.
static var _biomes: Dictionary = {}
static var _initialized: bool = false

static func get_biome(biome_id: String) -> BiomeDefinition:
	_ensure_init()
	return _biomes.get(biome_id)

## Hauptfunktion: wählt Biom anhand Temperatur + Feuchtigkeit.
static func get_biome_for(temp: float, humid: float) -> BiomeDefinition:
	_ensure_init()
	var id := _resolve_id(temp, humid)
	return _biomes.get(id, _biomes.get("meadow"))

static func get_biome_id_for(temp: float, humid: float) -> String:
	return _resolve_id(temp, humid)

## Temperatur-Schwellen für Wüste/Schnee.
## Vorher 0.6 / -0.5 — der 2-Oktaven-Klima-Noise (TerrainField.get_climate_at())
## erreicht diese Extremwerte nur auf wenigen Prozent der Fläche, Wüste und Eis
## waren dadurch praktisch nie in Sichtweite. Bei ±0.4 liegen beide grob im
## Bereich von je ~10–15 % der Weltfläche (Näherungs-Simulation, siehe Notiz).
## Höherer Betrag = seltener/kleiner, niedrigerer Betrag = häufiger/größer.
const DESERT_MIN_TEMP: float =  0.4
const WINTER_MAX_TEMP: float = -0.4

static func _resolve_id(temp: float, humid: float) -> String:
	if temp > DESERT_MIN_TEMP:            return "desert"
	if temp < WINTER_MAX_TEMP:            return "winter"
	if humid > 0.5 and temp > 0.0:       return "swamp"
	if humid > 0.3:                       return "dense_forest"
	if humid > 0.0:                       return "forest"
	# Round 78 — neue Nische für "mountain": bisher fiel jede trockene
	# (humid <= 0), nicht-heiße/nicht-eiskalte Zone (temp zwischen -0.5 und
	# 0.6) unterschiedslos auf "meadow". Kalt UND trocken (temp < -0.15)
	# wird jetzt zu "mountain" — schroffes, felsiges Hochland statt Wiese.
	# Warm-trocken (temp >= -0.15) bleibt weiterhin "meadow", unverändert.
	if temp < -0.15:                      return "mountain"
	# Round 79 — neue Nische für "dead_forest": innerhalb der bisherigen
	# meadow-Restzone (temp >= -0.15, humid <= 0) wird der besonders trockene
	# Ausschnitt (humid < -0.5) jetzt zu "toter Wald" statt Wiese — Bäume,
	# die an Wassermangel eingegangen sind, statt gar keiner Vegetation.
	# Warm-trocken-aber-nicht-extrem (humid zwischen -0.5 und 0) bleibt
	# weiterhin "meadow", unverändert.
	if humid < -0.5:                      return "dead_forest"
	return "meadow"

static func _ensure_init() -> void:
	if _initialized:
		return
	_initialized = true
	_register_all()

static func _register_all() -> void:
	_register(_make_forest())
	_register(_make_dense_forest())
	_register(_make_meadow())
	_register(_make_desert())
	_register(_make_winter())
	_register(_make_swamp())
	_register(_make_mountain())
	_register(_make_dead_forest())

static func _register(b: BiomeDefinition) -> void:
	_biomes[b.biome_id] = b

# ─────────────────────────────────────────────
# Biom-Definitionen
# ─────────────────────────────────────────────

static func _make_forest() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "forest"
	b.display_name = "Wald"
	b.terrain_color_grass = Color(0.13, 0.42, 0.12)
	b.terrain_color_dirt  = Color(0.35, 0.22, 0.10)
	b.terrain_color_rock  = Color(0.40, 0.40, 0.38)
	b.prop_chances = {
		"oak_tree":         0.28,  # Round 79 (Anfrage "viel Baum spawn" im Wald): von 0.15 fast verdoppelt
		"fallen_tree":      0.04,
		"mushroom_cluster": 0.12,  # Round 79 (Anfrage "Pilze"): von 0.08 leicht erhöht — Entity-Typ existiert jetzt, spawnt tatsächlich
		"fern":             0.20,
		"rock_boulder":     0.03,
	}
	b.structure_types = ["ruin", "cottage"]
	return b

static func _make_dense_forest() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "dense_forest"
	b.display_name = "Dichter Wald"
	b.terrain_color_grass = Color(0.08, 0.30, 0.08)
	b.terrain_color_dirt  = Color(0.28, 0.18, 0.08)
	b.terrain_color_rock  = Color(0.35, 0.35, 0.33)
	b.fog_density = 0.3
	b.prop_chances = {
		"oak_tree":        0.25,
		"fallen_tree":     0.07,
		"mushroom_cluster":0.12,
		"fern":            0.30,
	}
	return b

static func _make_meadow() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "meadow"
	b.display_name = "Wiese"
	b.terrain_color_grass = Color(0.38, 0.68, 0.20)
	b.terrain_color_dirt  = Color(0.55, 0.42, 0.20)
	b.terrain_color_rock  = Color(0.50, 0.48, 0.45)
	b.prop_chances = {
		"oak_tree":    0.05,
		"rock_boulder":0.02,
		"fern":        0.10,  # (Fern-Rollout) Wiese war das letzte "normale" Biom ohne fern-Eintrag.
	}
	b.structure_types = ["well", "cottage", "barn"]
	return b

static func _make_desert() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "desert"
	b.display_name = "Wüste"
	b.terrain_color_grass = Color(0.78, 0.65, 0.30)
	b.terrain_color_dirt  = Color(0.70, 0.55, 0.25)
	b.terrain_color_rock  = Color(0.65, 0.50, 0.30)
	b.prop_chances = {
		"cactus":      0.10,  # (Round 75) kein Entity-Typ registriert — wird von ChunkEntitySpawner gefiltert, spawnt aktuell NICHT. Sobald ein Cactus-Entity existiert (siehe TODO), spawnt es hierüber automatisch, ohne weitere Code-Änderung.
		"rock_boulder":0.08,  # dito — auch "rock_boulder" ist nirgends registriert
	}
	b.enemy_chances = {
		"skeleton": 0.06,  # (Round 75, Anfrage "vermehrt Skelette") — "skeleton" IST registriert (WorldEntityRegistry), spawnt also tatsächlich
	}
	return b

static func _make_winter() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "winter"
	b.display_name = "Schnee"
	b.terrain_color_grass = Color(0.85, 0.90, 0.95)
	b.terrain_color_dirt  = Color(0.70, 0.75, 0.80)
	b.terrain_color_rock  = Color(0.60, 0.65, 0.70)
	b.snow_coverage = 1.0
	b.prop_chances = {
		"pine_tree":   0.18,
		"rock_boulder":0.06,
		"fallen_tree": 0.03,
		"ice_crystal": 0.07,  # (Round 77) neu ergänzt, analog zum cactus/desert-Muster — IceCrystal-Entity existiert jetzt, spawnt automatisch.
	}
	return b

static func _make_swamp() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "swamp"
	b.display_name = "Sumpf"
	b.terrain_color_grass = Color(0.28, 0.38, 0.12)
	b.terrain_color_dirt  = Color(0.22, 0.28, 0.10)
	b.terrain_color_rock  = Color(0.30, 0.32, 0.22)
	b.fog_density = 0.5
	b.prop_chances = {
		"fallen_tree":      0.10,
		"mushroom_cluster": 0.15,
		"fern":             0.08,
	}
	return b

## Round 78 (Anfrage "rock_boulder im Gebirge-Biom") — neues Biom, siehe
## _resolve_id() für die Noise-Nische (kalt + trocken). Terrain-Farben
## bewusst steinern/karg statt Gras-lastig (grass-Farbe hier eher "karger
## Fels/Geröll" als echtes Gras, konsistent mit dem restlichen Farbschema,
## das terrain_color_grass als primäre Bodenfarbe der Vertex-Einfärbung
## nutzt, siehe TerrainChunkBuilder._biome_color()). rock_boulder deutlich
## höher gewichtet als in den bestehenden Nebenrollen (forest 0.03/meadow
## 0.02/desert 0.08/winter 0.06) — hier die Hauptattraktion des Bioms.
static func _make_mountain() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "mountain"
	b.display_name = "Gebirge"
	b.terrain_color_grass = Color(0.48, 0.46, 0.44)
	b.terrain_color_dirt  = Color(0.40, 0.36, 0.32)
	b.terrain_color_rock  = Color(0.35, 0.35, 0.34)
	b.prop_chances = {
		"rock_boulder": 0.30,
		"pine_tree":    0.06,  # vereinzelte Baumgrenze — kein eigenes Winter-Biom, aber realistisch für Hochland
		"fern":         0.05,  # (Fern-Rollout) vereinzelt zwischen den Felsen, nicht dominant
	}
	return b

## Round 79 (Anfrage "toter Wald: paar lebende Bäume & viele Baumstämme") —
## neues Biom, siehe _resolve_id() für die Noise-Nische (sehr trocken,
## nicht kalt genug für mountain). fallen_tree deutlich dominant, oak_tree
## nur als seltene Ausnahme ("ein paar lebende Bäume") — Umkehrung des
## forest-Verhältnisses (dort oak_tree 0.28 dominant, fallen_tree nur 0.04).
static func _make_dead_forest() -> BiomeDefinition:
	var b := BiomeDefinition.new()
	b.biome_id    = "dead_forest"
	b.display_name = "Toter Wald"
	b.terrain_color_grass = Color(0.42, 0.38, 0.30)
	b.terrain_color_dirt  = Color(0.35, 0.30, 0.22)
	b.terrain_color_rock  = Color(0.40, 0.38, 0.35)
	b.fog_density = 0.25
	b.prop_chances = {
		"fallen_tree": 0.28,
		"oak_tree":    0.03,
		"fern":        0.04,  # (Fern-Rollout) vereinzeltes zähes Grün trotz Trockenheit, deutlich seltener als im Wald
	}
	return b
