class_name TerrainColorizer
extends RefCounted

## TerrainColorizer — Höhe + Biome → Vertex-Farbe.
##
## Kapselt die gesamte Farbgebungs-Logik (aufgerufen vom TerrainMeshBuilder).
## Stateless: jede Methode braucht nur die übergebenen Werte.

const COL_DEEP_WATER := Color(0.08, 0.25, 0.55)
const COL_SHALLOW    := Color(0.18, 0.48, 0.70)
const COL_SAND       := Color(0.76, 0.71, 0.50)
const COL_GRASS      := Color(0.24, 0.54, 0.20)  # Fallback, falls kein Biom auflösbar (siehe height_to_color())
const COL_HILL       := Color(0.36, 0.30, 0.20)
const COL_ROCK       := Color(0.50, 0.46, 0.42)
const COL_SNOW       := Color(0.93, 0.94, 0.96)

## h in [-2, max_height], grass_color = BiomeDefinition.terrain_color_grass des
## Bioms an dieser Weltposition (Round 74 — vorher: synthetischer 0..1
## "biome"-Float ohne echte Biom-Zuordnung, siehe TerrainChunkBuilder._biome_color()).
## sea_level in Welteinheiten.
func height_to_color(h: float, grass_color: Color, max_height: float, sea_level: float) -> Color:
	var min_h: float    = -2.0
	var ratio: float    = clampf((h - min_h) / (max_height - min_h), 0.0, 1.0)
	var sl_ratio: float = (sea_level - min_h) / (max_height - min_h)

	if ratio < sl_ratio * 0.5:
		return COL_DEEP_WATER
	elif ratio < sl_ratio:
		return COL_SHALLOW.lerp(COL_SAND, (ratio - sl_ratio * 0.5) / (sl_ratio * 0.5))
	elif ratio < sl_ratio + 0.04:
		return COL_SAND.lerp(grass_color, (ratio - sl_ratio) / 0.04)
	elif ratio < 0.55:
		return grass_color
	elif ratio < 0.72:
		return grass_color.lerp(COL_HILL, (ratio - 0.55) / 0.17)
	elif ratio < 0.88:
		return COL_HILL.lerp(COL_ROCK, (ratio - 0.72) / 0.16)
	else:
		return COL_ROCK.lerp(COL_SNOW, (ratio - 0.88) / 0.12)
