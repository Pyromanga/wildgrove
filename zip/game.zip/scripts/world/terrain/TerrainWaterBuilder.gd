class_name TerrainWaterBuilder
extends RefCounted

## TerrainWaterBuilder — Wasseroberfläche eines Chunks.
##
## Vorher: WaterBody = opake Box MIT Kollision (ein Rechteck pro Chunk-"Becken", man lief
## drauf herum). Jetzt: EINE durchscheinende Ebene auf Höhe des Wasserspiegels, OHNE
## Kollision. Sie wird vom Terrain verdeckt, wo das Gelände höher liegt (normaler
## Tiefentest) und ist genau dort sichtbar, wo das Gelände unter dem Wasserspiegel liegt.
## Der Spieler geht dadurch durch das Wasser auf dem Grund — nicht darüber.
## Uferlinien entstehen automatisch aus der Geländeform (Seen, Flüsse, gegrabene Senken).
##
## Ein Chunk bekommt nur dann eine Ebene, wenn mindestens ein Vertex darunter liegt.
## Chunk-Nachbarn teilen ihre Randvertices — liegt ein Rand unter Wasser, haben beide
## Chunks eine Ebene, an der Grenze entsteht keine Lücke.
##
## SCHWIMMEN/WATEN/ANGELN: Diese Klasse ist nur Optik. Spielmechanik fragt
## TerrainField.get_water_depth_at()/is_water_at() — dieselbe Wahrheit wie die Optik.

## Vertices müssen mindestens so weit unter dem Spiegel liegen, damit eine Ebene entsteht
## (verhindert Ebenen für Chunks, die nur minimal am Spiegel kratzen → Z-Fighting).
const MIN_DEPTH: float = 0.05

const WATER_COLOR := Color(0.14, 0.42, 0.72, 0.62)

static var _shared_material: StandardMaterial3D = null

func needs_surface(heights: PackedFloat32Array, water_level: float) -> bool:
	for h in heights:
		if h < water_level - MIN_DEPTH:
			return true
	return false

## Baut die Wasserebene in lokalen Chunk-Koordinaten (Mittelpunkt (0, water_level, 0)).
func build_surface(chunk_size: float, water_level: float) -> MeshInstance3D:
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(chunk_size, chunk_size)

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _get_material()
	mi.position = Vector3(0.0, water_level, 0.0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	return mi

static func _get_material() -> StandardMaterial3D:
	if _shared_material == null:
		var mat := StandardMaterial3D.new()
		mat.albedo_color = WATER_COLOR
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		mat.roughness = 0.08
		mat.metallic = 0.0
		# Von beiden Seiten sichtbar (Kamera unter Wasser).
		mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		_shared_material = mat
	return _shared_material
