class_name GroundToolController
extends Node

## GroundToolController — "Graben" und "Füllen" mit der Schaufel.
##
## Sichtbar nur, wenn die Schaufel im Werkzeug-Slot ausgerüstet ist. Ein Tipp startet eine
## normale Interaktion (Fortschrittsbalken, Spieler beschäftigt, Abbruch bei Bewegung — alles
## vom InteractionExecutor); erst NACH Ablauf wird der Wunsch als Event abgeschickt:
##   bus().world().emit_terrain_edit_requested(player_id, mode, target)
## Die Ausführung samt Prüfungen (Reichweite, Erde, Regeln, Solo) liegt beim WorldService.
##
## Zielpunkt: DIST Meter vor dem Spieler (Player.get_ground_target()). Kein Zielen nötig —
## per Touch der einfachste Weg; der Spieler richtet sich durch Laufen aus.
## Der Schaufel-Tempo-Bonus kommt über action.speed_stat_id (ToolDefinition "dig_speed").

const TOOL_ID: String = "tool_shovel"
const DURATION: float = 1.4
const TARGET_DISTANCE: float = 2.2
const SPEED_STAT: String = "dig_speed"
const LOG_CAT := "GroundTool"

var _visuals: GroundToolVisuals
var _ctx: IUIContext
var _busy: bool = false

func setup(visuals: GroundToolVisuals, ctx: IUIContext) -> void:
	_visuals = visuals
	_ctx = ctx
	_visuals.dig_button.pressed.connect(_on_dig_pressed)
	_visuals.fill_button.pressed.connect(_on_fill_pressed)

func _ready() -> void:
	if not is_instance_valid(_ctx):
		return
	var eq: EquipmentService = _ctx.get_equipment()
	if is_instance_valid(eq) and not eq.equipment_changed.is_connected(_on_equipment_changed):
		eq.equipment_changed.connect(_on_equipment_changed)
	var bus: IEventBus = _ctx.bus()
	if bus != null:
		bus.world().interaction_started.connect(_on_interaction_started)
		bus.world().interaction_finished.connect(_on_interaction_ended)
		bus.world().interaction_cancelled.connect(_on_interaction_ended)
	_refresh()

func _exit_tree() -> void:
	if not is_instance_valid(_ctx):
		return
	var eq: EquipmentService = _ctx.get_equipment()
	if is_instance_valid(eq) and eq.equipment_changed.is_connected(_on_equipment_changed):
		eq.equipment_changed.disconnect(_on_equipment_changed)

# ─────────────────────────────────────────────

func _on_dig_pressed() -> void:
	_start(WorldTerrainEditor.MODE_DIG, "Graben")

func _on_fill_pressed() -> void:
	_start(WorldTerrainEditor.MODE_FILL, "Füllen")

func _start(mode: String, label: String) -> void:
	if _busy or not is_instance_valid(_ctx) or _ctx.bus() == null:
		return
	var player: Node3D = _ctx.get_local_player()
	if not is_instance_valid(player) or not player.has_method("get_ground_target"):
		AppLogger.log_warn("GroundTool: kein lokaler Player mit get_ground_target().", LOG_CAT)
		return
	var target: Vector3 = player.call("get_ground_target", TARGET_DISTANCE)
	var action: InteractableAction = build_action(
		mode, label, target, _ctx.get_local_player_id(), _ctx.get_local_peer_id(), _ctx.bus()
	)
	_ctx.bus().ui().emit_interaction_execute_requested(action)

## Baut die Interaktions-Aktion. Statisch/rein, damit testbar ohne UI.
## on_complete schickt den Wunsch ab — die Welt entscheidet, ob er gelingt.
static func build_action(
	mode: String, label: String, target: Vector3,
	player_id: String, peer_id: int, bus: IEventBus
) -> InteractableAction:
	var action := InteractableAction.new("%s_ground" % mode, label)
	action.duration = DURATION
	action.speed_stat_id = SPEED_STAT
	action.peer_id = peer_id
	action.on_complete = func(_completed_peer: int) -> void:
		bus.world().emit_terrain_edit_requested(player_id, mode, target)
	return action

# ─────────────────────────────────────────────

func _on_equipment_changed(_slot: String, _item: ItemDefinition, player_id: String) -> void:
	if is_instance_valid(_ctx) and player_id == _ctx.get_local_player_id():
		_refresh()

func _on_interaction_started(_id: String, _label: String, _duration: float) -> void:
	_busy = true
	_refresh()

func _on_interaction_ended(_id: String, _label: String) -> void:
	_busy = false
	_refresh()

func _refresh() -> void:
	if not is_instance_valid(_visuals):
		return
	_visuals.set_active(_shovel_equipped())
	_visuals.set_busy(_busy)

func _shovel_equipped() -> bool:
	if not is_instance_valid(_ctx):
		return false
	var eq: EquipmentService = _ctx.get_equipment()
	if not is_instance_valid(eq):
		return false
	var item: ItemDefinition = eq.get_equipped(EquipmentService.SLOT_TOOL, _ctx.get_local_player_id())
	return is_instance_valid(item) and item.id == TOOL_ID
