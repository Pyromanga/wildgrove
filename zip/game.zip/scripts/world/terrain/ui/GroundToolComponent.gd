class_name GroundToolComponent extends BaseUIComponent

func build(hud: HUD, ctx: IUIContext) -> GroundToolController:
	var visuals := GroundToolVisuals.new(hud)
	var ctrl := GroundToolController.new()
	hud.add_child(ctrl)
	ctrl.setup(visuals, ctx)
	return ctrl
