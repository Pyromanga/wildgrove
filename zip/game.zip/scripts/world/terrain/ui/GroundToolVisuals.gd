class_name GroundToolVisuals

## GroundToolVisuals — zwei Buttons "Graben" / "Füllen", nur sichtbar mit ausgerüsteter Schaufel.
##
## Position: über dem Kontext-Button (0.70 / 0.85), links vom Sprung-Button — Rechte Bildschirm-
## seite bleibt für Kamera-Drag frei, nichts überlappt (Sprung x ≥ 0.85, Kontext y ≥ 0.85).

var container: HBoxContainer
var dig_button: Button
var fill_button: Button

func _init(parent: CanvasLayer) -> void:
	container = HBoxContainer.new()
	container.name = "GroundToolButtons"
	container.anchor_left   = 0.70
	container.anchor_right  = 0.70
	container.anchor_top    = 0.70
	container.anchor_bottom = 0.70
	container.offset_left   = -124
	container.offset_right  = 124
	container.offset_top    = -52
	container.offset_bottom = 52
	container.add_theme_constant_override("separation", 16)
	container.visible = false
	container.mouse_filter = Control.MOUSE_FILTER_IGNORE

	dig_button  = _make_button("GroundDigButton",  "⬇\nGraben")
	fill_button = _make_button("GroundFillButton", "⬆\nFüllen")
	container.add_child(dig_button)
	container.add_child(fill_button)
	parent.add_child(container)

func set_active(active: bool) -> void:
	container.visible = active

func set_busy(busy: bool) -> void:
	dig_button.disabled = busy
	fill_button.disabled = busy

func _make_button(node_name: String, text: String) -> Button:
	var b := Button.new()
	b.name = node_name
	b.text = text
	b.custom_minimum_size = Vector2(UIMetrics.TOOLBAR_BUTTON + 20, UIMetrics.TOOLBAR_BUTTON + 16)
	b.add_theme_font_size_override("font_size", 20)
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	return b
