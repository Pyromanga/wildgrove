class_name TerrainChunkBuilder
extends RefCounted

## TerrainChunkBuilder — baut aus dem TerrainField die Nodes EINES Chunks:
## Terrain-Mesh, Terrain-Kollision und (falls nötig) Wasseroberfläche.
##
## Ersetzt TerrainGenerator.create() + ChunkWaterPlacer. Kennt keinen Noise und keinen Seed:
## es SAMPELT nur TerrainField.get_height_at() an den Chunk-Vertices. Dadurch gilt
## automatisch alles, was das Feld weiß (Layer, Spieler-Änderungen) — und Mesh, Kollision
## und jede andere Höhenabfrage im Spiel stimmen exakt überein.
##
## Vertex-Layout: (Auflösung+1)² Punkte im Abstand config.get_vertex_spacing(), Chunk-Zentrum
## = Chunk-Koordinate × chunk_size. Randvertices liegen exakt auf dem Rand und werden von
## Nachbar-Chunks geteilt → nahtlose Übergänge (gleiche Weltkoordinate → gleiche Höhe).

const LOG_CAT := "TerrainChunk"

## Namen der erzeugten Kinder (für Neubau nach Gelände-Änderungen).
const NODE_TERRAIN: String = "Terrain"
const NODE_PHYSICS: String = "TerrainPhysics"
const NODE_WATER: String = "TerrainWater"

var _field: TerrainField
var _mesh_builder: TerrainMeshBuilder
var _water_builder: TerrainWaterBuilder

func _init(field: TerrainField) -> void:
	_field = field
	_mesh_builder = TerrainMeshBuilder.new()
	_water_builder = TerrainWaterBuilder.new()

func get_chunk_center(coord: Vector2i) -> Vector2:
	var size: float = _field.get_config().chunk_size
	return Vector2(float(coord.x) * size, float(coord.y) * size)

## Welcher Chunk enthält (world_x, world_z)? (Zentrum = coord * size → Rundung.)
func get_chunk_at(world_x: float, world_z: float) -> Vector2i:
	var size: float = _field.get_config().chunk_size
	return Vector2i(roundi(world_x / size), roundi(world_z / size))

## Höhen aller Vertices eines Chunks, Zeile für Zeile (z-Zeilen, x-Spalten) — das Format,
## das HeightMapShape3D und TerrainMeshBuilder erwarten.
func sample_heights(center: Vector2) -> PackedFloat32Array:
	var cfg: TerrainConfig = _field.get_config()
	var res: int = cfg.get_resolution()
	var n: int = res + 1
	var step: float = cfg.get_vertex_spacing()
	var half: float = cfg.chunk_size * 0.5

	var heights := PackedFloat32Array()
	heights.resize(n * n)
	for z_i in range(n):
		var world_z: float = center.y - half + float(z_i) * step
		for x_i in range(n):
			var world_x: float = center.x - half + float(x_i) * step
			heights[z_i * n + x_i] = _field.get_height_at(world_x, world_z)
	return heights

## Lokaler Wasserspiegel (TerrainField.get_water_level_at()) an denselben Gitterpunkten wie
## sample_heights() — Fluss-Abschnitte liegen dadurch je nach Chunk auf unterschiedlicher
## Höhe statt überall auf der globalen Konstante (siehe TerrainWaterBuilder-Kommentar).
func sample_water_levels(center: Vector2) -> PackedFloat32Array:
	var cfg: TerrainConfig = _field.get_config()
	var res: int = cfg.get_resolution()
	var n: int = res + 1
	var step: float = cfg.get_vertex_spacing()
	var half: float = cfg.chunk_size * 0.5

	var levels := PackedFloat32Array()
	levels.resize(n * n)
	for z_i in range(n):
		var world_z: float = center.y - half + float(z_i) * step
		for x_i in range(n):
			var world_x: float = center.x - half + float(x_i) * step
			levels[z_i * n + x_i] = _field.get_water_level_at(world_x, world_z)
	return levels

## Fügt Terrain, Kollision und ggf. Wasser als Kinder von `chunk_node` hinzu.
## chunk_node muss bei get_chunk_center(coord) stehen (Kinder nutzen lokale Koordinaten).
func build(coord: Vector2i, chunk_node: Node3D) -> void:
	var cfg: TerrainConfig = _field.get_config()
	var center: Vector2 = get_chunk_center(coord)
	var res: int = cfg.get_resolution()
	var heights: PackedFloat32Array = sample_heights(center)

	var terrain: MeshInstance3D = _mesh_builder.build_terrain_mesh(
		heights, res, cfg.chunk_size, cfg.max_height, cfg.water_level, center, _biome_color
	)
	terrain.name = NODE_TERRAIN
	chunk_node.add_child(terrain)

	var physics: StaticBody3D = _mesh_builder.build_physics_body(heights, res, cfg.chunk_size)
	physics.name = NODE_PHYSICS
	chunk_node.add_child(physics)

	var water_levels: PackedFloat32Array = sample_water_levels(center)
	if _water_builder.needs_surface(heights, water_levels):
		var water: MeshInstance3D = _water_builder.build_surface(heights, water_levels, res, cfg.chunk_size)
		water.name = NODE_WATER
		chunk_node.add_child(water)

## Ersetzt Terrain/Kollision/Wasser eines bestehenden Chunk-Nodes (nach Gelände-Änderungen).
## Andere Kinder des Chunk-Nodes bleiben unangetastet.
func rebuild(coord: Vector2i, chunk_node: Node3D) -> void:
	for child_name in [NODE_TERRAIN, NODE_PHYSICS, NODE_WATER]:
		var old: Node = chunk_node.get_node_or_null(child_name)
		if old != null:
			# Sofort aus dem Baum nehmen: queue_free() allein hält den Namen bis zum
			# Frame-Ende belegt, der Neubau würde sonst umbenannt ("Terrain2").
			chunk_node.remove_child(old)
			old.queue_free()
	build(coord, chunk_node)

## Vertex-Farbe: Gras-Farbe des Bioms an dieser Weltposition (Fallback: TerrainColorizer.COL_GRASS).
func _biome_color(world_x: float, world_z: float) -> Color:
	var biome: BiomeDefinition = _field.get_biome_at(world_x, world_z)
	return biome.terrain_color_grass if is_instance_valid(biome) else TerrainColorizer.COL_GRASS
