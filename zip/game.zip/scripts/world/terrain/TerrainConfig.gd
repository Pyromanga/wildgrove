class_name TerrainConfig
extends Resource

## TerrainConfig — ALLE Stellschrauben des Geländes an EINER Stelle.
##
## WARUM: Vorher standen Chunk-Größe, Auflösung, Max-Höhe und Meeresspiegel doppelt im
## Code (WorldFactory UND ChunkManager, mit dem Kommentar "muss übereinstimmen, sonst
## stimmen Höhen nicht") — ein Fehler, der nur durch Disziplin verhindert wurde. Jetzt
## gibt es genau eine Konfiguration, die an TerrainField übergeben wird; alle anderen
## Teile (Chunks, Wasser, Spawner, Bauen) lesen sie von dort.
##
## Alle Höhen in Metern über/unter y=0. Alle Frequenzen in 1/Meter (Wellenlänge = 1/f).
## Neue Welten mit anderem Charakter = andere TerrainConfig (später als .tres ladbar).
##
## Reine Datenklasse, keine Logik außer abgeleiteten Größen.

## Seed, wenn kein world_seed gesetzt ist (0). Nur Fallback — im Spiel gibt WorldService
## immer den echten, zwischen Peers synchronisierten world_seed vor.
const DEFAULT_SEED: int = 1337

# ── Chunks ──────────────────────────────────────
## Kantenlänge eines Chunks in Metern.
const DEFAULT_CHUNK_SIZE: float = 64.0
@export var chunk_size: float = DEFAULT_CHUNK_SIZE

# ── Höhen ───────────────────────────────────────
## Obergrenze für die Höhen-Einfärbung (TerrainColorizer). KEIN hartes Limit der Höhe.
@export var max_height: float = 14.0
## Wasserspiegel. Alles Gelände darunter ist Wasser (Seen, Flüsse, Meer, aber auch
## vom Spieler gegrabene Senken). Eine Zahl für die ganze Welt.
@export var water_level: float = 0.0

# ── Kontinent (großräumige Form: Ebene / Hügel / Becken) ──
@export var continent_frequency: float = 0.0018
@export var continent_octaves: int = 3
## Ab welchem Kontinent-Wert Hügel beginnen (0) und voll ausgeprägt sind (1). Noise ~[-1,1].
@export var hill_start: float = 0.0
@export var hill_end: float = 0.35
## Unterhalb von basin_end beginnt ein Becken (See/Meer), unter basin_start ist es voll.
@export var basin_start: float = -0.48
@export var basin_end: float = -0.26

# ── Detail (kleinräumige Unebenheit) ────────────
@export var detail_frequency: float = 0.008
## 4 Oktaven: die feinste hat ~13 m Wellenlänge. Feinere Oktaven wären bei 2 m Vertex-Abstand
## nicht mehr darstellbar (Aliasing → zackiges, zufälliges Rauschen statt Hügelchen).
@export var detail_octaves: int = 4
@export var detail_lacunarity: float = 2.1
@export var detail_gain: float = 0.55

# ── Höhenprofile ────────────────────────────────
@export var plains_base: float = 2.4
@export var plains_amplitude: float = 2.0
@export var hill_base: float = 6.0
@export var hill_amplitude: float = 8.5
@export var basin_floor: float = -3.0
@export var basin_amplitude: float = 1.0

# ── Flüsse ──────────────────────────────────────
## Flüsse verlaufen entlang der Nulldurchgänge eines eigenen Noise-Feldes — dadurch
## zusammenhängend, weltweit nahtlos und ohne Chunk-Muster (der alte Fluss war pro Chunk
## lokal und wiederholte sich in jedem Chunk).
@export var river_frequency: float = 0.0032
## Halbe Breite des Flusstals in METERN (Abstand von der Flussmitte bis das Ufer ins Gelände
## ausläuft). Bewusst in Metern und nicht in Noise-Einheiten: dort, wo das Noise-Feld steil ist,
## wurde der Fluss sonst schmal mit fast senkrechten Ufern (Simulation: bis 4 m Höhe pro m).
@export var river_half_width: float = 10.0
## Nur Bereiche mit |Noise| unter diesem Wert werden überhaupt auf einen Fluss geprüft
## (Vorfilter, spart Rechenzeit; muss über halbe Breite × maximalem Gradient liegen).
@export var river_search_band: float = 0.14
## Tiefe des Flussbetts UNTER dem Wasserspiegel.
@export var river_depth: float = 1.2
## Nur Gelände unterhalb dieser Höhe wird vom Fluss eingeschnitten; darüber (Hügel)
## läuft der Fluss aus statt Schluchten zu graben.
@export var river_max_height: float = 4.5
@export var river_fade_range: float = 4.0

# ── Spawn-Plateau ───────────────────────────────
## Um den Ursprung (Dorf, NPCs, Ackerbeete, Spawn) wird das Gelände eingeebnet, damit
## der Startbereich immer begehbar und trocken ist — unabhängig vom Seed.
@export var spawn_height: float = 2.5
@export var spawn_flat_radius: float = 40.0
@export var spawn_blend_radius: float = 90.0

# ── Klima (Biome) ───────────────────────────────
@export var temperature_frequency: float = 0.0035
@export var humidity_frequency: float = 0.0046

# ── Abgeleitet ──────────────────────────────────

## Vertex-Anzahl je Chunk-Kante minus 1. Bewusst AUS dem Edit-Gitter abgeleitet
## (TerrainEditLayer.SPACING): Chunk-Vertices liegen dadurch immer exakt auf den Punkten
## der Delta-Schicht (Umgraben) — die Kopplung kann nicht mehr auseinanderlaufen.
func get_resolution() -> int:
	return maxi(1, roundi(chunk_size / TerrainEditLayer.SPACING))

func get_vertex_spacing() -> float:
	return chunk_size / float(get_resolution())
