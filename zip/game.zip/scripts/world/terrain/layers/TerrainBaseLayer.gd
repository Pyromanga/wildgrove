class_name TerrainBaseLayer
extends TerrainLayer

## TerrainBaseLayer — die Grundform der Welt: Ebenen, Hügel/Berge und Becken (Seen/Meer).
##
## Zwei Noise-Felder:
##   Kontinent (langwellig, ~550 m): entscheidet WO Ebene, Hügelland oder Becken ist.
##   Detail    (kurzwellig, ~125 m): die Unebenheit darin.
##
##   Ebene  = plains_base + Detail * plains_amplitude          (sanft, überwiegend trocken)
##   Hügel  = hill_base   + Detail * hill_amplitude            (deutlich bewegt, bis ~13 m)
##   Becken = basin_floor + Detail * basin_amplitude           (unter dem Wasserspiegel)
##
## Der Kontinent-Wert blendet weich zwischen den Profilen (smoothstep). Seen und Meer sind
## KEINE eigene Geometrie mehr: sie entstehen dort, wo das Becken-Profil unter den
## Wasserspiegel fällt — mit natürlichen, unregelmäßigen Uferlinien. Der Wasserspiegel
## selbst gehört zu TerrainField/TerrainWaterBuilder, nicht hierher.
##
## Ignoriert die eingehende Höhe (ist die unterste Schicht des Stapels).

var _cfg: TerrainConfig
var _continent: FastNoiseLite
var _detail: FastNoiseLite

func _init(cfg: TerrainConfig, world_seed: int) -> void:
	_cfg = cfg
	_continent = make_noise(
		TerrainSeed.derive(world_seed, "terrain.continent"),
		cfg.continent_frequency, cfg.continent_octaves
	)
	_detail = make_noise(
		TerrainSeed.derive(world_seed, "terrain.detail"),
		cfg.detail_frequency, cfg.detail_octaves, cfg.detail_lacunarity, cfg.detail_gain
	)

func apply(world_x: float, world_z: float, _h: float) -> float:
	var c: float = _continent.get_noise_2d(world_x, world_z)
	var d: float = _detail.get_noise_2d(world_x, world_z)

	var hill_mask: float = smoothstep(_cfg.hill_start, _cfg.hill_end, c)
	var basin_mask: float = 1.0 - smoothstep(_cfg.basin_start, _cfg.basin_end, c)

	var plains: float = _cfg.plains_base + d * _cfg.plains_amplitude
	var hills: float = _cfg.hill_base + d * _cfg.hill_amplitude
	var h: float = lerpf(plains, hills, hill_mask)

	var basin: float = _cfg.basin_floor + d * _cfg.basin_amplitude
	return lerpf(h, basin, basin_mask)
