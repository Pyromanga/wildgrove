class_name TerrainRiverLayer
extends TerrainLayer

## TerrainRiverLayer — Flusstäler entlang der Nulldurchgänge eines Noise-Feldes.
##
## IDEE: Dort, wo ein glattes Noise-Feld den Wert 0 kreuzt, verläuft eine zusammenhängende
## Kurve. Weil das Feld in WELTkoordinaten definiert ist, sind Flüsse über Chunk-Grenzen
## hinweg nahtlos, mäandern natürlich und wiederholen sich nicht (der alte Fluss war pro
## Chunk lokal → identisches Muster in jedem Chunk).
##
## BREITE IN METERN: Der Abstand zur Flussmitte ist |noise| / |Gradient| (Distanz zur
## Nulllinie in Metern, Gradient per zentraler Differenz). Dadurch hat jeder Fluss dieselbe
## Breite — mit reiner |noise|-Schwelle wurde er dort, wo das Feld steil ist, schmal mit fast
## senkrechten Ufern.
##
## Der Fluss schneidet das Gelände bis river_depth UNTER den Wasserspiegel ein, blendet mit
## einer S-Kurve in die Ufer aus und wirkt nur im Tiefland (river_max_height + Auslauf): in
## den Hügeln läuft er aus, statt Schluchten zu graben. Das Wasser selbst kommt vom globalen
## Wasserspiegel — hier wird nur das Bett geformt.

## Schrittweite (m) für den Gradienten. Klein genug für lokale Steigung, groß genug gegen
## Rauschen der Fließkommazahlen.
const GRADIENT_EPS: float = 1.0

var _cfg: TerrainConfig
var _noise: FastNoiseLite

func _init(cfg: TerrainConfig, world_seed: int) -> void:
	_cfg = cfg
	_noise = make_noise(TerrainSeed.derive(world_seed, "terrain.river"), cfg.river_frequency, 1)

func apply(world_x: float, world_z: float, h: float) -> float:
	var n: float = _noise.get_noise_2d(world_x, world_z)
	if absf(n) >= _cfg.river_search_band:
		return h

	var lowland: float = 1.0 - smoothstep(_cfg.river_max_height, _cfg.river_max_height + _cfg.river_fade_range, h)
	if lowland <= 0.0:
		return h

	var gx: float = (_noise.get_noise_2d(world_x + GRADIENT_EPS, world_z) - _noise.get_noise_2d(world_x - GRADIENT_EPS, world_z)) / (2.0 * GRADIENT_EPS)
	var gz: float = (_noise.get_noise_2d(world_x, world_z + GRADIENT_EPS) - _noise.get_noise_2d(world_x, world_z - GRADIENT_EPS)) / (2.0 * GRADIENT_EPS)
	var grad: float = sqrt(gx * gx + gz * gz)
	if grad < 0.000001:
		return h

	var dist_m: float = absf(n) / grad
	if dist_m >= _cfg.river_half_width:
		return h

	var carve: float = smoothstep(0.0, 1.0, 1.0 - dist_m / _cfg.river_half_width) * lowland
	var bed: float = _cfg.water_level - _cfg.river_depth
	return lerpf(h, minf(h, bed), carve)
