class_name TerrainRiverLayer
extends TerrainLayer

## TerrainRiverLayer — Flusstäler entlang der Nulldurchgänge eines Noise-Feldes.
##
## IDEE: Dort, wo ein glattes Noise-Feld den Wert 0 kreuzt, verläuft eine zusammenhängende
## Kurve. Weil das Feld in WELTkoordinaten definiert ist, sind Flüsse über Chunk-Grenzen
## hinweg nahtlos, mäandern natürlich und wiederholen sich nicht (der alte Fluss war pro
## Chunk lokal → identisches Muster in jedem Chunk).
##
## BREITE IN METERN: Der Abstand zur Flussmitte ist |noise| / |Gradient| (Distanz zur
## Nulllinie in Metern, Gradient per zentraler Differenz). Dadurch hat jeder Fluss dieselbe
## Breite — mit reiner |noise|-Schwelle wurde er dort, wo das Feld steil ist, schmal mit fast
## senkrechten Ufern.
##
## Der Fluss schneidet das Gelände bis river_depth UNTER den Wasserspiegel ein, blendet mit
## einer S-Kurve in die Ufer aus und wirkt nur im Tiefland (river_max_height + Auslauf): in
## den Hügeln läuft er aus, statt Schluchten zu graben. Das Wasser selbst kommt vom globalen
## Wasserspiegel — hier wird nur das Bett geformt.

## Schrittweite (m) für den Gradienten. Klein genug für lokale Steigung, groß genug gegen
## Rauschen der Fließkommazahlen.
const GRADIENT_EPS: float = 1.0

var _cfg: TerrainConfig
var _noise: FastNoiseLite

func _init(cfg: TerrainConfig, world_seed: int) -> void:
	_cfg = cfg
	_noise = make_noise(TerrainSeed.derive(world_seed, "terrain.river"), cfg.river_frequency, 1)

func apply(world_x: float, world_z: float, h: float) -> float:
	var carve: float = _carve_factor(world_x, world_z, h)
	if carve <= 0.0:
		return h
	# BUGFIX (2026-09-20, "Wasser/Flüsse immer auf derselben Ebene"): das Flussbett lag
	# bisher auf einer FESTEN absoluten Höhe (water_level - river_depth), egal wie hoch das
	# umgebende Gelände war — ein Fluss durch eine 3m-Ebene und einer durch eine 0.5m-Ebene
	# landeten beide exakt auf derselben Höhe. Jetzt relativ zur lokalen (uneingeschnittenen)
	# Geländehöhe `h`: das Bett folgt der Landschaft und liegt dort, wo das Land höher ist,
	# auch höher — siehe get_water_target_at() für die dazugehörige Wasseroberfläche.
	var bed: float = h - _cfg.river_depth
	return lerpf(h, minf(h, bed), carve)

## Wie stark schneidet der Fluss an (world_x, world_z) in ein Gelände der Höhe `h` ein?
## 0 = kein Fluss hier, 1 = volle Flussbett-Tiefe. Eine Stelle für beide Nutzer (apply() fürs
## Bett, get_water_target_at() für die Wasserfläche) — nur so können Bett und Wasseroberfläche
## nie auseinanderlaufen (z.B. Wasser über einer Stelle, an der doch kein Fluss eingeschnitten hat).
func _carve_factor(world_x: float, world_z: float, h: float) -> float:
	var n: float = _noise.get_noise_2d(world_x, world_z)
	if absf(n) >= _cfg.river_search_band:
		return 0.0

	var lowland: float = 1.0 - smoothstep(_cfg.river_max_height, _cfg.river_max_height + _cfg.river_fade_range, h)
	if lowland <= 0.0:
		return 0.0

	var gx: float = (_noise.get_noise_2d(world_x + GRADIENT_EPS, world_z) - _noise.get_noise_2d(world_x - GRADIENT_EPS, world_z)) / (2.0 * GRADIENT_EPS)
	var gz: float = (_noise.get_noise_2d(world_x, world_z + GRADIENT_EPS) - _noise.get_noise_2d(world_x, world_z - GRADIENT_EPS)) / (2.0 * GRADIENT_EPS)
	var grad: float = sqrt(gx * gx + gz * gz)
	if grad < 0.000001:
		return 0.0

	var dist_m: float = absf(n) / grad
	if dist_m >= _cfg.river_half_width:
		return 0.0

	return smoothstep(0.0, 1.0, 1.0 - dist_m / _cfg.river_half_width) * lowland

## Wasserspiegel-Ziel an (world_x, world_z) für die OPTIK/Wassertiefe, oder NAN außerhalb
## jedes Flusslaufs. `h_before` = Geländehöhe, wie TerrainBaseLayer sie an dieser Stelle
## geliefert hat (VOR dem Einschneiden hier) — exakt die Höhe, bis zu der das Bett mit Wasser
## vollläuft (Talsohle voll bis zur ursprünglichen Uferhöhe). Nur für TerrainField.
## get_water_level_at() gedacht: See/Meer bleiben unverändert auf dem globalen Spiegel
## (stehende Gewässer gleichen sich aus), nur echte Flussabschnitte bekommen ihre eigene,
## mit dem Gelände schwankende Höhe.
func get_water_target_at(world_x: float, world_z: float, h_before: float) -> float:
	return h_before if _carve_factor(world_x, world_z, h_before) > 0.0 else NAN
