class_name TerrainField
extends RefCounted

## TerrainField — DIE eine Wahrheit über das Gelände: Höhe, Wasser und Klima an jedem Punkt.
##
## ═══ WARUM ES DAS GIBT ═══
## Vorher wusste jeder etwas anderes: der Mesh-Bau kannte Flüsse/Seen, get_height_at()
## (für Bäume, NPCs, Gegner, Bauen) kannte sie nicht; der Fluss war pro Chunk lokal; der
## world_seed kam nie im Noise an; Wasser waren begehbare Rechtecke. Jetzt gilt:
##
##   get_height_at(x, z) ist die Höhe. Punkt. Mesh, Kollision, Spawner, Bauen und Graben
##   fragen ALLE dieselbe Funktion — deshalb kann nichts mehr in der Luft schweben oder im
##   Boden stecken, und man braucht keine Physik-Raycasts, um zu wissen, wo der Boden ist
##   (funktioniert auch für nicht geladene Chunks, auf Servern ohne Grafik und in Tests).
##
## ═══ AUFBAU ═══
##     Höhe = Stapel aus TerrainLayern (Basis → Fluss → Spawn-Plateau) + Edit-Deltas
##
##   - Layer sind reine Funktionen in Weltkoordinaten (siehe TerrainLayer).
##   - Edit-Deltas (TerrainEditLayer) sind die Spieler-Änderungen und kommen zuletzt.
##   - Wasser ist KEIN Objekt, sondern eine Eigenschaft: Wasser ist überall, wo die Höhe
##     unter get_water_level() liegt (Seen, Flüsse, Meer, gegrabene Senken).
##   - Klima (Temperatur/Feuchte) ist von der Höhe unabhängig und bestimmt das Biom.
##
## ═══ KONVENTIONEN ═══
##   - IMMER Weltkoordinaten. (Der alte TerrainGenerator.get_height_at() war chunk-LOKAL,
##     get_biome_at() absolut — eine Dauer-Fehlerquelle.)
##   - Deterministisch: (Config, world_seed) → immer dieselbe Welt, auf jedem Peer.
##   - Kein Node, kein Service, kein Zustand außer der (austauschbaren) Edit-Schicht.
##
## Tests können TerrainField per `extends TerrainField` überschreiben (get_height_at()).

var _config: TerrainConfig
var _seed: int
var _layers: Array[TerrainLayer] = []
var _edit_layer: TerrainEditLayer = null
var _temperature: FastNoiseLite
var _humidity: FastNoiseLite

func _init(config: TerrainConfig = null, world_seed: int = 0) -> void:
	_config = config if config != null else TerrainConfig.new()
	_seed = world_seed if world_seed != 0 else TerrainConfig.DEFAULT_SEED

	# Reihenfolge = Berechnungsreihenfolge. Spätere Layer sehen das Ergebnis der früheren.
	_layers.append(TerrainBaseLayer.new(_config, _seed))
	_layers.append(TerrainRiverLayer.new(_config, _seed))
	_layers.append(TerrainSpawnPlateauLayer.new(_config))

	_temperature = TerrainLayer.make_noise(
		TerrainSeed.derive(_seed, "climate.temperature"), _config.temperature_frequency, 2)
	_humidity = TerrainLayer.make_noise(
		TerrainSeed.derive(_seed, "climate.humidity"), _config.humidity_frequency, 2)

# ─────────────────────────────────────────────
# Zugriff auf Konfiguration
# ─────────────────────────────────────────────

func get_config() -> TerrainConfig:
	return _config

func get_seed() -> int:
	return _seed

func get_water_level() -> float:
	return _config.water_level

## Setzt die Schicht der Spieler-Änderungen. Dieselbe Instanz, die WorldData speichert.
func set_edit_layer(layer: TerrainEditLayer) -> void:
	_edit_layer = layer

func get_edit_layer() -> TerrainEditLayer:
	return _edit_layer

# ─────────────────────────────────────────────
# Höhe
# ─────────────────────────────────────────────

## Endgültige Geländehöhe (mit Spieler-Änderungen) an Weltposition (x, z).
func get_height_at(world_x: float, world_z: float) -> float:
	var h: float = get_base_height_at(world_x, world_z)
	if _edit_layer != null:
		h += _edit_layer.get_delta_at(world_x, world_z)
	return h

## Höhe OHNE Spieler-Änderungen (das unberührte, prozedurale Gelände).
func get_base_height_at(world_x: float, world_z: float) -> float:
	var h: float = 0.0
	for layer in _layers:
		h = layer.apply(world_x, world_z, h)
	return h

## Steigung an (x, z) in Grad (0 = eben). Zentrale Differenzen über `sample` Meter.
func get_slope_at(world_x: float, world_z: float, sample: float = 1.0) -> float:
	var dx: float = get_height_at(world_x + sample, world_z) - get_height_at(world_x - sample, world_z)
	var dz: float = get_height_at(world_x, world_z + sample) - get_height_at(world_x, world_z - sample)
	return rad_to_deg(atan(sqrt(dx * dx + dz * dz) / (2.0 * sample)))

# ─────────────────────────────────────────────
# Wasser
# ─────────────────────────────────────────────

## Wassertiefe an (x, z) in Metern (0 an Land).
func get_water_depth_at(world_x: float, world_z: float) -> float:
	return maxf(0.0, get_water_level() - get_height_at(world_x, world_z))

func is_water_at(world_x: float, world_z: float) -> bool:
	return get_height_at(world_x, world_z) < get_water_level()

# ─────────────────────────────────────────────
# Klima / Biome
# ─────────────────────────────────────────────

## (Temperatur, Feuchte), je ~[-1, 1]. Von der Höhe unabhängig.
func get_climate_at(world_x: float, world_z: float) -> Vector2:
	return Vector2(
		_temperature.get_noise_2d(world_x, world_z),
		_humidity.get_noise_2d(world_x, world_z)
	)

func get_biome_at(world_x: float, world_z: float) -> BiomeDefinition:
	var c: Vector2 = get_climate_at(world_x, world_z)
	return BiomeRegistry.get_biome_for(c.x, c.y)

func get_biome_id_at(world_x: float, world_z: float) -> String:
	var c: Vector2 = get_climate_at(world_x, world_z)
	return BiomeRegistry.get_biome_id_for(c.x, c.y)
