class_name AmbientForestVfx
extends Node3D

## AmbientForestVfx — reine Ambient-Optik, unabhängig von WeatherService/
## WeatherVfx: treibende, langsam fallende Blätter über dem Spieler, nur
## sichtbar in "forest"/"dense_forest" (siehe BiomeRegistry). Beantwortet den
## letzten offenen Punkt aus docs/procedural-textures-and-weather-vfx.md
## ("leaf_card() existiert, wird aber nirgends verwendet").
##
## Gleiches Muster wie WeatherVfx: RefCounted-Wahrheit bleibt woanders
## (hier: TerrainField.get_biome_id_at() statt eines eigenen Service), diese
## Klasse LIEST nur und schaltet Partikel um. Kein Netzwerk-Traffic, kein
## Save-State — fällt bei Verbindungs-/Chunk-Wechseln einfach neu an, wie
## WindField/WeatherVfx.
##
## Drei GPUParticles3D-Kinder statt einem: jedes bekommt eine eigene
## leaf_card(hue_seed)-Variante (siehe ProceduralTextureFactory-Kommentar
## "mehrere Blatt-Varianten ohne neuen Code") und trägt nur einen Drittel
## der Gesamtmenge — wirkt weniger wie ein einzelnes wiederholtes Sprite.

const LOG_CAT := "AmbientForestVfx"

const LEAF_HEIGHT := 3.2
const LEAF_AREA := Vector2(9.0, 9.0)
const LEAF_VARIANTS := 3
const LEAF_COUNT_PER_VARIANT := 16
## Wie oft neu geprüft wird, ob der Spieler noch im Wald steht (Sekunden) —
## nicht jeden Frame, Biom ändert sich nicht schlagartig.
const BIOME_CHECK_INTERVAL := 1.5

const FOREST_BIOMES := ["forest", "dense_forest"]

var _wind: WindField = null
var _terrain: TerrainField = null
var _follow_target: Node3D = null
var _leaves: Array[GPUParticles3D] = []
var _in_forest: bool = false
var _biome_check_timer: float = 0.0

## world_seed: für denselben deterministischen Wind wie WeatherVfx (keine
## zweite, abweichende Windquelle). terrain: für den Biom-Check. active:
## false auf einem kopflosen dedizierten Server (kein Rendering, kein Spieler).
func configure(world_seed: int, terrain: TerrainField, active: bool) -> void:
	_wind = WindField.new(world_seed)
	_terrain = terrain

	visible = active
	set_process(active)
	if active:
		_build_leaves()

## Partikel folgen diesem Node (typischerweise der lokale Spieler) statt
## fest an der Welt zu hängen — analog WeatherVfx.follow().
func follow(target: Node3D) -> void:
	_follow_target = target
	# Sofortiger Erst-Check statt bis zum ersten Timer-Intervall zu warten,
	# damit beim Weltbetreten mitten im Wald nicht erst 1.5s lang nichts fällt.
	_check_biome()

func _process(delta: float) -> void:
	if is_instance_valid(_follow_target):
		global_position = _follow_target.global_position

	_biome_check_timer -= delta
	if _biome_check_timer <= 0.0:
		_biome_check_timer = BIOME_CHECK_INTERVAL
		_check_biome()

	if not is_instance_valid(_wind):
		return
	_wind.advance(delta)
	var dir3: Vector3 = Vector3(_wind.direction.x, 0.0, _wind.direction.y)
	for leaf in _leaves:
		if not is_instance_valid(leaf):
			continue
		var pm := leaf.process_material as ParticleProcessMaterial
		if pm != null:
			# Blätter treiben deutlich stärker seitlich als Regen/Schnee —
			# sie sind leicht, kein senkrechter Fall, sondern Trudeln im Wind.
			pm.direction = (Vector3.DOWN * 0.4 + dir3 * (0.5 + _wind.strength)).normalized()

func _check_biome() -> void:
	if not is_instance_valid(_terrain):
		return
	var should_be_active: bool = false
	if is_instance_valid(_follow_target):
		var biome_id := _terrain.get_biome_id_at(global_position.x, global_position.z)
		should_be_active = biome_id in FOREST_BIOMES
	if should_be_active == _in_forest:
		return
	_in_forest = should_be_active
	for leaf in _leaves:
		if is_instance_valid(leaf):
			leaf.emitting = _in_forest
	AppLogger.log_info(
		"AmbientForestVfx: fallendes Laub %s." % ("aktiviert" if _in_forest else "deaktiviert"),
		LOG_CAT
	)

func _build_leaves() -> void:
	for i in range(LEAF_VARIANTS):
		var p := GPUParticles3D.new()
		p.name = "FallingLeaves_%d" % i
		p.amount = LEAF_COUNT_PER_VARIANT
		p.lifetime = 7.0 + i * 0.8  # leicht versetzte Lebenszeit -> weniger synchrones Fallen
		p.emitting = false
		p.position = Vector3(0.0, LEAF_HEIGHT, 0.0)
		p.visibility_aabb = AABB(
			Vector3(-LEAF_AREA.x, -LEAF_HEIGHT - 1.0, -LEAF_AREA.y),
			Vector3(LEAF_AREA.x * 2.0, LEAF_HEIGHT + 2.0, LEAF_AREA.y * 2.0)
		)
		p.draw_pass_1 = _build_leaf_mesh(i)

		var pm := ParticleProcessMaterial.new()
		pm.direction = Vector3.DOWN
		pm.spread = 30.0
		pm.gravity = Vector3(0.0, -0.35, 0.0)
		pm.initial_velocity_min = 0.05
		pm.initial_velocity_max = 0.2
		# Trudeln: Rotation + Orbit geben den typischen "Blatt fällt nicht
		# gerade, sondern schaukelt" Effekt, den Regen/Schnee nicht brauchen.
		pm.orbit_velocity_min = 0.08
		pm.orbit_velocity_max = 0.22
		pm.angular_velocity_min = -60.0
		pm.angular_velocity_max = 60.0
		pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		pm.emission_box_extents = Vector3(LEAF_AREA.x, 0.05, LEAF_AREA.y)
		pm.scale_min = 0.7
		pm.scale_max = 1.3
		p.process_material = pm

		add_child(p)
		_leaves.append(p)

func _build_leaf_mesh(hue_seed: int) -> QuadMesh:
	var q := QuadMesh.new()
	q.size = Vector2(0.14, 0.14)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED  # Blatt dreht sich frei, beide Seiten sichtbar
	mat.albedo_texture = ProceduralTextureFactory.leaf_card(48, hue_seed)
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = mat
	return q
