class_name AmbientForestVfx
extends Node3D

## AmbientForestVfx — reine Ambient-Optik, unabhängig von WeatherService/
## WeatherVfx: treibende, langsam fallende Blätter über dem Spieler, nur
## sichtbar in "forest"/"dense_forest" (siehe BiomeRegistry), plus
## Glühwürmchen nachts im "dense_forest". Beantwortet den letzten offenen
## Punkt aus docs/procedural-textures-and-weather-vfx.md ("leaf_card()
## existiert, wird aber nirgends verwendet").
##
## Gleiches Muster wie WeatherVfx: RefCounted-Wahrheit bleibt woanders
## (hier: TerrainField.get_biome_id_at() für Biom, WorldTimeService.day_time
## für Tag/Nacht statt eigener Services), diese Klasse LIEST nur und schaltet
## Partikel um. Kein Netzwerk-Traffic, kein Save-State — fällt bei
## Verbindungs-/Chunk-Wechseln einfach neu an, wie WindField/WeatherVfx.
##
## Drei GPUParticles3D-Kinder für Laub statt einem: jedes bekommt eine eigene
## leaf_card(hue_seed)-Variante (siehe ProceduralTextureFactory-Kommentar
## "mehrere Blatt-Varianten ohne neuen Code") und trägt nur einen Drittel
## der Gesamtmenge — wirkt weniger wie ein einzelnes wiederholtes Sprite.
## Glühwürmchen sind ein viertes, eigenständiges GPUParticles3D (eigene
## Emissions-Fläche/Höhe/Bewegungsart, siehe _build_fireflies()).

const LOG_CAT := "AmbientForestVfx"

const LEAF_HEIGHT := 3.2
const LEAF_AREA := Vector2(9.0, 9.0)
const LEAF_VARIANTS := 3
const LEAF_COUNT_PER_VARIANT := 16

const FIREFLY_HEIGHT := 1.4
const FIREFLY_AREA := Vector2(5.0, 5.0)
const FIREFLY_COUNT := 24

## Wie oft neu geprüft wird, ob der Spieler noch im Wald/bei Nacht steht
## (Sekunden) — nicht jeden Frame, Biom/Tageszeit ändern sich nicht schlagartig.
const AMBIENT_CHECK_INTERVAL := 1.5

const FOREST_BIOMES := ["forest", "dense_forest"]
const FIREFLY_BIOMES := ["dense_forest"]  # nur der dichte Wald, "forest" bleibt tagsüber-Look
## day_time in Stunden (WorldTimeService, 0..24) — Nacht ist alles außerhalb
## dieses Fensters. Bewusst grobzügig geschätzt (kein Playtest möglich hier).
const NIGHT_START_HOUR := 20.5
const NIGHT_END_HOUR := 5.5

var _wind: WindField = null
var _terrain: TerrainField = null
var _time: WorldTimeService = null
var _follow_target: Node3D = null
var _leaves: Array[GPUParticles3D] = []
var _fireflies: GPUParticles3D = null
var _in_forest: bool = false
var _fireflies_active: bool = false
var _ambient_check_timer: float = 0.0

## world_seed: für denselben deterministischen Wind wie WeatherVfx (keine
## zweite, abweichende Windquelle). terrain: für den Biom-Check. time_service:
## für den Tag/Nacht-Check (Glühwürmchen) — optional, ohne sie bleiben
## Glühwürmchen dauerhaft aus statt zu raten. active: false auf einem
## kopflosen dedizierten Server (kein Rendering, kein Spieler).
func configure(
	world_seed: int, terrain: TerrainField, active: bool, time_service: WorldTimeService = null
) -> void:
	_wind = WindField.new(world_seed)
	_terrain = terrain
	_time = time_service

	visible = active
	set_process(active)
	if active:
		_build_leaves()
		_build_fireflies()

## Partikel folgen diesem Node (typischerweise der lokale Spieler) statt
## fest an der Welt zu hängen — analog WeatherVfx.follow().
func follow(target: Node3D) -> void:
	_follow_target = target
	# Sofortiger Erst-Check statt bis zum ersten Timer-Intervall zu warten,
	# damit beim Weltbetreten mitten im Wald nicht erst 1.5s lang nichts fällt.
	_check_ambient_state()

func _process(delta: float) -> void:
	if is_instance_valid(_follow_target):
		global_position = _follow_target.global_position

	_ambient_check_timer -= delta
	if _ambient_check_timer <= 0.0:
		_ambient_check_timer = AMBIENT_CHECK_INTERVAL
		_check_ambient_state()

	if not is_instance_valid(_wind):
		return
	_wind.advance(delta)
	var dir3: Vector3 = Vector3(_wind.direction.x, 0.0, _wind.direction.y)
	for leaf in _leaves:
		if not is_instance_valid(leaf):
			continue
		var pm := leaf.process_material as ParticleProcessMaterial
		if pm != null:
			# Blätter treiben deutlich stärker seitlich als Regen/Schnee —
			# sie sind leicht, kein senkrechter Fall, sondern Trudeln im Wind.
			pm.direction = (Vector3.DOWN * 0.4 + dir3 * (0.5 + _wind.strength)).normalized()
	# Glühwürmchen wandern nur leicht mit dem Wind (kein "Fall" wie Laub) —
	# die eigentliche Bewegung kommt aus Turbulenz/Orbit in _build_fireflies().
	if is_instance_valid(_fireflies):
		var firefly_pm := _fireflies.process_material as ParticleProcessMaterial
		if firefly_pm != null:
			firefly_pm.direction = (Vector3.UP * 0.1 + dir3 * _wind.strength * 0.15).normalized()

func _check_ambient_state() -> void:
	var forest_active: bool = false
	var fireflies_active: bool = false
	if is_instance_valid(_terrain) and is_instance_valid(_follow_target):
		var biome_id := _terrain.get_biome_id_at(global_position.x, global_position.z)
		forest_active = biome_id in FOREST_BIOMES
		if biome_id in FIREFLY_BIOMES and _is_night():
			fireflies_active = true

	if forest_active != _in_forest:
		_in_forest = forest_active
		for leaf in _leaves:
			if is_instance_valid(leaf):
				leaf.emitting = _in_forest
		AppLogger.log_info(
			"AmbientForestVfx: fallendes Laub %s." % ("aktiviert" if _in_forest else "deaktiviert"),
			LOG_CAT
		)

	if fireflies_active != _fireflies_active:
		_fireflies_active = fireflies_active
		if is_instance_valid(_fireflies):
			_fireflies.emitting = _fireflies_active
		AppLogger.log_info(
			"AmbientForestVfx: Glühwürmchen %s." % ("aktiviert" if _fireflies_active else "deaktiviert"),
			LOG_CAT
		)

## true zwischen NIGHT_START_HOUR und NIGHT_END_HOUR (über Mitternacht hinweg).
## Ohne time_service (nicht übergeben) bewusst IMMER false statt zu raten —
## keine Glühwürmchen ist die sicherere Fehlannahme als welche am helllichten Tag.
func _is_night() -> bool:
	if not is_instance_valid(_time):
		return false
	var h: float = _time.day_time
	return h >= NIGHT_START_HOUR or h < NIGHT_END_HOUR

func _build_leaves() -> void:
	for i in range(LEAF_VARIANTS):
		var p := GPUParticles3D.new()
		p.name = "FallingLeaves_%d" % i
		p.amount = LEAF_COUNT_PER_VARIANT
		p.lifetime = 7.0 + i * 0.8  # leicht versetzte Lebenszeit -> weniger synchrones Fallen
		p.emitting = false
		p.position = Vector3(0.0, LEAF_HEIGHT, 0.0)
		p.visibility_aabb = AABB(
			Vector3(-LEAF_AREA.x, -LEAF_HEIGHT - 1.0, -LEAF_AREA.y),
			Vector3(LEAF_AREA.x * 2.0, LEAF_HEIGHT + 2.0, LEAF_AREA.y * 2.0)
		)
		p.draw_pass_1 = _build_leaf_mesh(i)

		var pm := ParticleProcessMaterial.new()
		pm.direction = Vector3.DOWN
		pm.spread = 30.0
		pm.gravity = Vector3(0.0, -0.35, 0.0)
		pm.initial_velocity_min = 0.05
		pm.initial_velocity_max = 0.2
		# Trudeln: Rotation + Orbit geben den typischen "Blatt fällt nicht
		# gerade, sondern schaukelt" Effekt, den Regen/Schnee nicht brauchen.
		pm.orbit_velocity_min = 0.08
		pm.orbit_velocity_max = 0.22
		pm.angular_velocity_min = -60.0
		pm.angular_velocity_max = 60.0
		pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
		pm.emission_box_extents = Vector3(LEAF_AREA.x, 0.05, LEAF_AREA.y)
		pm.scale_min = 0.7
		pm.scale_max = 1.3
		p.process_material = pm

		add_child(p)
		_leaves.append(p)

## Warme, selbstleuchtende Punkte, die frei um den Spieler herum schweben
## statt zu fallen (kaum Schwerkraft, Turbulenz statt gerichteter Bewegung).
## emission_enabled statt nur heller albedo_color, damit WorldFactorys
## env.glow_enabled (siehe dortiger Kommentar) sie tatsächlich zum Leuchten
## bringt statt nur eine helle Fläche zu zeichnen.
func _build_fireflies() -> void:
	var p := GPUParticles3D.new()
	p.name = "Fireflies"
	p.amount = FIREFLY_COUNT
	p.lifetime = 14.0
	p.emitting = false
	p.position = Vector3(0.0, FIREFLY_HEIGHT, 0.0)
	p.visibility_aabb = AABB(
		Vector3(-FIREFLY_AREA.x, -FIREFLY_HEIGHT - 1.0, -FIREFLY_AREA.y),
		Vector3(FIREFLY_AREA.x * 2.0, FIREFLY_HEIGHT + 3.0, FIREFLY_AREA.y * 2.0)
	)
	p.draw_pass_1 = _build_firefly_mesh()

	var pm := ParticleProcessMaterial.new()
	pm.direction = Vector3.UP
	pm.spread = 180.0  # in alle Richtungen, kein bevorzugtes "Fallen"
	pm.gravity = Vector3.ZERO
	pm.initial_velocity_min = 0.05
	pm.initial_velocity_max = 0.15
	pm.orbit_velocity_min = 0.03
	pm.orbit_velocity_max = 0.10
	# Turbulenz statt reiner Ballistik -> unregelmäßiges Umherschweben statt
	# einer erkennbaren Wurfbahn (ungetestet, Godot-4.3-Feature, siehe
	# Klassenkommentar zum fehlenden Runtime hier).
	pm.turbulence_enabled = true
	pm.turbulence_noise_strength = 0.6
	pm.turbulence_noise_scale = 1.5
	pm.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	pm.emission_box_extents = Vector3(FIREFLY_AREA.x, 1.0, FIREFLY_AREA.y)
	pm.scale_min = 0.6
	pm.scale_max = 1.2
	# Sanftes Auf-/Abblenden über die Lebenszeit statt hartem Erscheinen/
	# Verschwinden — ein Alpha-Kurvenverlauf über CanvasItemMaterial wäre hier
	# Overkill, ein simpler Farbverlauf über color_ramp reicht.
	var fade_gradient := Gradient.new()
	fade_gradient.set_color(0, Color(1, 1, 1, 0))
	fade_gradient.add_point(0.15, Color(1, 1, 1, 1))
	fade_gradient.add_point(0.85, Color(1, 1, 1, 1))
	fade_gradient.set_color(1, Color(1, 1, 1, 0))
	var fade_ramp := GradientTexture1D.new()
	fade_ramp.gradient = fade_gradient
	pm.color_ramp = fade_ramp
	p.process_material = pm

	add_child(p)
	_fireflies = p

func _build_leaf_mesh(hue_seed: int) -> QuadMesh:
	var q := QuadMesh.new()
	q.size = Vector2(0.14, 0.14)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED  # Blatt dreht sich frei, beide Seiten sichtbar
	mat.albedo_texture = ProceduralTextureFactory.leaf_card(48, hue_seed)
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = mat
	return q

func _build_firefly_mesh() -> QuadMesh:
	var q := QuadMesh.new()
	q.size = Vector2(0.05, 0.05)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.vertex_color_use_as_albedo = true  # nimmt den color_ramp-Fade oben auf
	mat.albedo_color = Color(0.85, 0.95, 0.35)
	mat.albedo_texture = ProceduralTextureFactory.snowflake()  # weicher runder Punkt, hier zweckentfremdet
	mat.emission_enabled = true
	mat.emission = Color(0.85, 0.95, 0.35)
	mat.emission_energy_multiplier = 2.5
	mat.billboard_mode = BaseMaterial3D.BILLBOARD_PARTICLES
	q.material = mat
	return q
