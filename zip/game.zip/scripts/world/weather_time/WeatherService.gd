class_name WeatherService
extends RefCounted

## WeatherService — verwaltet das aktuelle Wetter der Spielwelt.
##
## Sibling zu WorldTimeService (siehe dortiger Kommentar-Header in
## WorldService.gd) — gleiche Delegations-Idee, eigener Zustand.
##
## Design-Entscheidung (Round 95, siehe ADR-041): Wetter wird NICHT über ein
## eigenes RPC an alle Peers verteilt — das Projekt hat aktuell keinen
## "an alle Peers"-Broadcast-Mechanismus (siehe ADR-035 "Umsetzungsstand",
## gleiche Einschränkung dort für Auktionshaus-Listing-Änderungen). Stattdessen
## rollt jeder Peer das Wetter selbst, deterministisch aus `world_seed` +
## einem monoton steigenden Zyklus-Zähler — exakt dasselbe Prinzip wie
## `TerrainField`/`ChunkManager` (siehe TerrainSeed: Teil-Seeds aus dem world_seed):
## gleicher Seed + gleicher Zähler ⇒ überall identisches Ergebnis, ganz ohne
## Netzwerk-Traffic. Der Zyklus ist an `WorldTimeService.day_count` gekoppelt
## (ein Wetterwurf pro neuem Ingame-Tag) statt an eine eigene Echtzeit-Uhr —
## day_count wird bereits gespeichert/wiederhergestellt, eine zweite,
## unabhängig zu persistierende Uhr wäre hier unnötige Redundanz gewesen.
##
## Bewusst NICHT Teil dieser Runde: visuelle Wetter-Effekte (Partikel/Post-
## Processing), Gameplay-Auswirkungen (z.B. Angel-/Ernte-Boni bei Regen),
## Biom-Abhängigkeit (Wüste bekommt aktuell denselben Pool wie jedes andere
## Biom) — reiner Event-/Zustands-Layer, auf den künftige Systeme aufsetzen
## können. Siehe ADR-041 "Konsequenzen/Negativ".

const LOG_CAT := "Weather"

## Bewusst eine feste, globale Liste statt Biom-Abhängigkeit (siehe Klassenkommentar).
const WEATHER_TYPES: Array[String] = ["clear", "rain", "storm", "fog", "snow"]

const DEFAULT_WEATHER := "clear"

var current_weather: String = DEFAULT_WEATHER

## Der zuletzt für einen Wetterwurf verwendete day_count — verhindert einen
## zweiten Wurf für denselben Tag, falls roll_for_day() mehrfach mit demselben
## Wert aufgerufen wird (z.B. weil on_tick() öfter als einmal pro Frame-Grenze
## läuft, in der day_count gerade hochzählt).
var _last_rolled_day: int = -1

var _bus: IEventBus = null

func set_event_bus(bus: IEventBus) -> void:
	_bus = bus

## Rollt deterministisch ein neues Wetter für `day_count`, wenn dafür noch
## nicht gewürfelt wurde. `world_seed` kommt aus WorldData — pro Welt fest,
## damit alle Peers derselben Welt exakt denselben Wurf berechnen.
func roll_for_day(day_count: int, world_seed: int) -> void:
	if day_count == _last_rolled_day:
		return
	_last_rolled_day = day_count

	var rng := RandomNumberGenerator.new()
	# Analog TerrainSeed.derive() (Terrain): world_seed als
	# Basis, day_count als Zyklus-Index — deterministisch pro Welt+Tag, nie
	# von Time.get_ticks_*() oder echtem Zufall abhängig.
	rng.seed = world_seed * 1000003 + day_count

	var new_weather: String = WEATHER_TYPES[rng.randi_range(0, WEATHER_TYPES.size() - 1)]
	if new_weather == current_weather:
		return

	var old_weather := current_weather
	current_weather = new_weather
	if _bus != null:
		_bus.world().emit_weather_changed(current_weather, old_weather)
	AppLogger.log_info(
		"Wetter geändert (Tag %d): '%s' -> '%s'." % [day_count, old_weather, current_weather],
		LOG_CAT
	)

func restore(state: Dictionary) -> void:
	var restored: String = state.get("weather", DEFAULT_WEATHER)
	current_weather = restored if restored in WEATHER_TYPES else DEFAULT_WEATHER
	_last_rolled_day = state.get("weather_last_rolled_day", -1)

func get_save_data() -> Dictionary:
	return {"weather": current_weather, "weather_last_rolled_day": _last_rolled_day}
