class_name WorldSaveHandler
extends RefCounted

## WorldSaveHandler — Save/Restore-Logik für die Spielwelt.
##
## Ausgelagert aus WorldService (v28).
## KEIN eigener ISaveProvider: nie über register_save_provider() registriert.
## WorldService ist der tatsächliche Provider (get_save_key()/get_save_data()
## in WorldService.gd) und delegiert intern hierher. Der vorherige
## '## implements ISaveProvider'-Kommentar war schlicht falsch — kein
## fehlender Code, sondern eine unzutreffende Behauptung (siehe
## data/manager/decisions/, ADR-Neuaufbau Round 110).
## Verantwortlich für:
##   - get_save_data()  → serialisiert WorldData + WorldTimeService
##   - restore_world()  → deserialisiert gespeicherten Zustand zurück in WorldData
##
## Kein Service, kein Node. Wird von WorldService als Hilfsklasse genutzt.

const LOG_CAT := "WorldSave"

var _data: WorldData
var _time: WorldTimeService
## ADR-041: optional, Default null — bestehende Aufrufer (Tests, ältere
## Call-Sites) bleiben ohne Änderung kompilierbar; Wetter-Keys werden dann
## einfach ausgelassen statt zu crashen (siehe get_save_data()/restore_world()).
var _weather: WeatherService

func _init(data: WorldData, time: WorldTimeService, weather: WeatherService = null) -> void:
	_data = data
	_time = time
	_weather = weather

# ─────────────────────────────────────────────
# Speichern
# ─────────────────────────────────────────────

func get_save_data() -> Dictionary:
	var pets_raw: Variant = _data.get_meta("saved_pets") if _data.has_meta("saved_pets") else []

	var time_data := _time.get_save_data()
	var out := {
		"day_time":            time_data["day_time"],
		"day_count":           time_data["day_count"],
		"typed_tree_positions": var_to_str(_data.typed_tree_positions),
		"typed_ore_positions":  var_to_str(_data.typed_ore_positions),
		"player_pos":          var_to_str(_data.player_position),
		"harvested":           var_to_str(_data.harvested_objects),
		"saved_pets":          var_to_str(pets_raw),
		"world_seed":          _data.world_seed,
		# Gelände-Änderungen und Bauteile. Fehlen bei älteren Spielständen → beim Laden
		# einfach leer (siehe restore_world()), kein Migrationsschritt nötig.
		"terrain_edits":       var_to_str(_data.terrain_edits.to_save()),
		"build_pieces":        var_to_str(_data.build_registry.to_save()),
		"ladders":             var_to_str(_data.ladders.to_save()),
		"dig_finds":           var_to_str(_data.dig_finds.to_save()),
	}
	if is_instance_valid(_weather):
		var weather_data := _weather.get_save_data()
		out["weather"] = weather_data["weather"]
		out["weather_last_rolled_day"] = weather_data["weather_last_rolled_day"]
	return out

# ─────────────────────────────────────────────
# Wiederherstellen
# ─────────────────────────────────────────────

func restore_world(state: Dictionary) -> void:
	_time.restore(state)
	if is_instance_valid(_weather):
		_weather.restore(state)

	var typed_trees: Variant = str_to_var(state.get("typed_tree_positions", "{}"))
	_data.typed_tree_positions = typed_trees if typed_trees is Dictionary else {}

	var typed_ores: Variant = str_to_var(state.get("typed_ore_positions", "{}"))
	_data.typed_ore_positions = typed_ores if typed_ores is Dictionary else {}

	var player_pos_raw: Variant = str_to_var(state.get("player_pos", "Vector3(0,0,0)"))
	_data.player_position = player_pos_raw if player_pos_raw is Vector3 else Vector3.ZERO

	var harvested_raw: Variant = str_to_var(state.get("harvested", "{}"))
	_data.harvested_objects = harvested_raw if harvested_raw is Dictionary else {}

	var seed_raw: Variant = state.get("world_seed", 0)
	_data.world_seed = seed_raw if seed_raw is int else 0

	var pets_raw: Variant = str_to_var(state.get("saved_pets", "[]"))
	if pets_raw is Array:
		_data.set_meta("saved_pets", pets_raw)

	# In-place laden (Instanzen bleiben gleich — TerrainField/BuildHandler halten Referenzen).
	# str_to_var("null") bzw. fehlender Key → load_save() räumt auf, statt zu crashen.
	_data.terrain_edits.load_save(str_to_var(state.get("terrain_edits", "[]")))
	_data.build_registry.load_save(str_to_var(state.get("build_pieces", "[]")))
	_data.ladders.load_save(str_to_var(state.get("ladders", "[]")))
	_data.dig_finds.load_save(str_to_var(state.get("dig_finds", "[]")))

	AppLogger.log_info(
		"Welt geladen: Tag %d %s, %d Bäume, %d Erze." % [
			_time.day_count, _time.get_formatted_time(),
			_data.get_tree_count(), _data.get_ore_count()
		], LOG_CAT
	)
