class_name WorldEntityRegistry
extends RefCounted

## WorldEntityRegistry — Registriert Entity-Definitionen im EntityOrchestrator.
##
## Ausgelagert aus WorldService._register_entity_definitions() (v28).
## Zentrale Stelle für alle bekannten Entity-Typen der Spielwelt.
##
## Statisch nutzbar — kein State, keine Abhängigkeiten außer dem Orchestrator.

const LOG_CAT := "WorldEntityRegistry"

## Round 75 — Single Source of Truth für ChunkEntitySpawner: welche
## BiomeDefinition.prop_chances/enemy_chances-Keys tatsächlich einen
## registrierten Entity-Typ haben und deshalb wirklich spawnen dürfen. MUSS
## synchron mit register_all() unten gehalten werden (kein automatischer
## Abgleich — bewusst einfach gehalten, gleiche Konvention wie BiomeRegistry
## selbst: code-seitige statische Liste statt Reflection/Introspection).
## Fehlt ein Typ hier (z.B. "rock_boulder", "pine_tree", "fern",
## "fallen_tree", "mushroom_cluster" — alle in BiomeRegistry referenziert,
## keiner hier registriert), wird der jeweilige prop_chances/enemy_chances-
## Eintrag von ChunkEntitySpawner stillschweigend gefiltert (kein Spawn,
## kein Fehler) statt EntityRegistry.instantiate() mit einem Fehler-Log zu
## fluten. ("cactus" war hier bis Round 75 auch gefiltert — Round 76 hat den
## Entity-Typ nachgezogen, siehe Cactus.gd.)
const KNOWN_PROP_TYPES:   Array[String] = ["oak_tree", "willow_tree", "maple_tree", "iron_ore", "copper_ore", "cactus", "pine_tree", "ice_crystal", "rock_boulder", "mushroom_cluster", "fallen_tree", "fern"]
const KNOWN_ENEMY_TYPES:  Array[String] = ["goblin", "skeleton"]

## Registriert alle Welt-Entities im angegebenen Orchestrator.
static func register_all(orchestrator: EntityOrchestrator) -> void:
	orchestrator.register_definition("player",      "res://scripts/entities/player/Player.gd",                   "player")
	# Bäume — alle extends HarvestableEntity
	orchestrator.register_definition("oak_tree",    "res://scripts/world/objects/OakTree.gd",           "trees")
	orchestrator.register_definition("willow_tree", "res://scripts/world/objects/WillowTree.gd",        "trees")
	orchestrator.register_definition("maple_tree",  "res://scripts/world/objects/MapleTree.gd",         "trees")
	orchestrator.register_definition("pine_tree",   "res://scripts/world/objects/PineTree.gd",          "trees")
	orchestrator.register_definition("fallen_tree", "res://scripts/world/objects/FallenTree.gd",        "trees")
	# Pflanzen — extends HarvestableEntity (Round 76/77/79)
	orchestrator.register_definition("cactus",      "res://scripts/world/objects/Cactus.gd",            "plants")
	orchestrator.register_definition("ice_crystal", "res://scripts/world/objects/IceCrystal.gd",        "plants")
	orchestrator.register_definition("mushroom_cluster", "res://scripts/world/objects/MushroomCluster.gd", "plants")
	orchestrator.register_definition("fern",          "res://scripts/world/objects/Fern.gd",              "plants")
	# Erze — alle extends HarvestableEntity
	orchestrator.register_definition("iron_ore",    "res://scripts/world/objects/IronOre.gd",           "ores")
	orchestrator.register_definition("copper_ore",  "res://scripts/world/objects/CopperOre.gd",         "ores")
	orchestrator.register_definition("rock_boulder","res://scripts/world/objects/RockBoulder.gd",       "ores")
	# Tiere
	orchestrator.register_definition("deer",        "res://scripts/entities/animals/Deer.gd",              "animals")
	orchestrator.register_definition("rabbit",      "res://scripts/entities/animals/Rabbit.gd",            "animals")
	orchestrator.register_definition("boar",        "res://scripts/entities/animals/Boar.gd",              "animals")
	# Pets — gezähmte Tiere, spielergebunden statt fungibel (siehe EntityOrchestrator._ready(): kein Pooling).
	orchestrator.register_definition("pet",         "res://scripts/entities/animals/pets/PetComponent.gd",         "pets")
	# NPCs
	orchestrator.register_definition("quest_npc",   "res://scripts/progression/quests/QuestNPC.gd",              "npcs")
	orchestrator.register_definition("shop_npc",    "res://scripts/economy/shop/ShopNPC.gd",                     "npcs")
	orchestrator.register_definition("bank_npc",    "res://scripts/economy/bank/BankNPC.gd",                     "npcs")
	orchestrator.register_definition("auction_house_npc", "res://scripts/economy/trading/AuctionHouseNPC.gd",    "npcs")
	# ADR-048 Round 106: Tutorial-Teil 2 — erklärt UI/UX nahe dem Spawnpunkt,
	# siehe TutorialGuideNPC.gd Klassenkommentar.
	orchestrator.register_definition("tutorial_guide_npc", "res://scripts/onboarding/TutorialGuideNPC.gd",       "npcs")
	# Wunsch "es fehlt ein NPC den ich beklauen kann" — stationärer,
	# beklaubarer Dorfbewohner, siehe VillagerNPC.gd Klassenkommentar.
	orchestrator.register_definition("villager_npc", "res://scripts/entities/theft/VillagerNPC.gd",              "npcs")
	# Farming (Wunsch "Samen pflanzen + ernten") — siehe FarmPlot.gd Klassenkommentar.
	orchestrator.register_definition("farm_plot", "res://scripts/world/farming/FarmPlot.gd",                     "farming")
	# Bausystem: Ansicht eines gebauten Bauteils (Boden/Wand) — gespawnt von WorldBuildHandler pro
	# geladenem Chunk, nicht vom ChunkEntitySpawner (kein Biome-Prop) — daher bewusst NICHT in
	# KNOWN_PROP_TYPES. Siehe BuildPiece.gd Klassenkommentar.
	orchestrator.register_definition("build_piece", "res://scripts/world/building/BuildPiece.gd", "building")
	# ADR-037: Gravestone — PvE-Tod-Loot (Grab-Hybrid-Timer), gespawnt von
	# DeathLootService, nicht vom ChunkEntitySpawner (kein Biome-Prop) — daher
	# bewusst NICHT in KNOWN_PROP_TYPES/KNOWN_ENEMY_TYPES oben eingetragen.
	orchestrator.register_definition("gravestone", "res://scripts/entities/death/Gravestone.gd", "death")
	# Feinde
	orchestrator.register_definition("goblin",   "res://scripts/entities/combat/EnemyNPC.gd",    "enemies")
	orchestrator.register_definition("skeleton", "res://scripts/entities/combat/SkeletonNPC.gd", "enemies")
	AppLogger.log_info("Entity-Definitionen registriert.", LOG_CAT)
