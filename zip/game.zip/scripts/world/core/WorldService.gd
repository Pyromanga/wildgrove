extends ServiceNode
# justified: add_child(_entity_orchestrator); queue_free(ChunkManager); on_world_scene_ready(Node3D).
class_name WorldService

## WorldService — Lifecycle + öffentliche API für die Spielwelt.
##
## Delegiert Verantwortlichkeiten an spezialisierte Klassen:
##   WorldSpawner          → Entities, Tiere, Wasser, Pets, Chunks spawnen
##   WorldSaveHandler      → Save/Restore-Logik (v28)
##   WorldEntityRegistry   → Entity-Definitionen registrieren (v28)
##   WorldTimeService      → Tageszeit verwalten
##   WeatherService        → Wetter verwalten (ADR-041)
##   WorldFactory          → statische Geometrie erstellen
##   EntityOrchestrator    → Entity-Pooling + UUID-Verwaltung
##
## Abhängigkeiten: ["savesystem", "world_gen"]

const LOG_CAT := "World"
const SAVE_KEY := "world_state"

var data:     WorldData
var factory:  WorldFactory
var factory3d: Factory3D

var _save_system:    SaveSystem
var _world_gen:      WorldGenerationService
var _ticker:         ServiceTicker = null
var _respawn:        RespawnService = null
var _game_manager:   GameManager   = null
var _session_manager: SessionManager = null
var _entity_orchestrator: EntityOrchestrator
var _spawner:  WorldSpawner
var _time:     WorldTimeService
## ADR-041: Wetter — Sibling zu _time, siehe WeatherService-Klassenkommentar
## für die Design-Entscheidung (deterministischer Wurf statt RPC-Broadcast).
var _weather:  WeatherService
var _save_handler: WorldSaveHandler
var _chunk_manager: ChunkManager  # Stored so on_cleanup() can shut it down properly
var _bus:           IEventBus

## ADR-020: NetworkBridge — für request_entity_interaction() (Nicht-Autorität
## leitet an die Autorität weiter statt lokal zu wirken). NICHT als configure()-Dep
## bezogen (das wäre ein Zyklus mit NetworkBridges eigenem "world"-Dep, siehe
## BootstrapConfig.tres), sondern über denselben Phase-C8-Late-Inject-Mechanismus
## wie Inventory/Quest/SkillSystem/Equipment (siehe inject_network_bridge() unten).
var _network: NetworkBridge = null

## Werden in configure() aufgelöst und per set_entity_services() an EntityOrchestrator weitergereicht.
var _ent_skill:     SkillSystem         = null
var _ent_inventory: InventorySystem     = null
var _ent_stat_mod:  StatModifierService = null
var _ent_combat:    CombatSystem        = null
var _ent_equipment: EquipmentService    = null
var _ent_interact:  InteractionExecutor = null
var _ent_player_states: PlayerStateService = null
var _ent_data:      DataService         = null
## Für EntityContext.get_currency() — EnemyNPC._die() (Goblin-/Skelett-Gold-Drops).
var _ent_currency:  CurrencyService     = null
## ADR-035: für EntityContext.get_trade_service() — Player._on_trade_requested().
var _ent_trade:     TradeService        = null
## ADR-036: für EntityContext.get_pvp_death_loss() — Player._on_player_died().
var _ent_pvp_death_loss: PvPDeathLossService = null
## ADR-036: für EntityContext.get_aura() — Player._on_thank_requested().
var _ent_aura: AuraService = null
## ADR-037: für EntityContext.get_death_loot() — Player._on_player_died() (PvE-Zweig).
var _ent_death_loot: DeathLootService = null
## ADR-039: für EntityContext.get_pickpocket() — Player._on_pickpocket_requested().
var _ent_pickpocket: PickpocketService = null

## ADR-030: ZoneService — kein EntityContext-Dep (kein Entity braucht es
## direkt), nur zum Verdrahten der zone_triggers-Gruppe (siehe _wire_zone_triggers()).
var _zone_service: ZoneService = null

## Computed properties — always current, never one tick stale.
var day_time: float:
	get: return _time.day_time if is_instance_valid(_time) else 0.0
var day_count: int:
	get: return _time.day_count if is_instance_valid(_time) else 0
var current_weather: String:
	get: return _weather.current_weather if is_instance_valid(_weather) else WeatherService.DEFAULT_WEATHER

# ─────────────────────────────────────────────
# Service-Lifecycle
# ─────────────────────────────────────────────

func configure(deps: ServiceDeps) -> void:
	_save_system     = deps.get_optional(ServiceKeys.SAVE_SYSTEM)    as SaveSystem
	_world_gen       = deps.get_optional(ServiceKeys.WORLD_GEN)      as WorldGenerationService
	_ticker          = deps.get_optional(ServiceKeys.TICKER)         as ServiceTicker
	_respawn         = deps.get_optional(ServiceKeys.RESPAWN)        as RespawnService
	_game_manager    = deps.get_optional(ServiceKeys.GAME_MANAGER)   as GameManager
	_session_manager = deps.get_optional(ServiceKeys.SESSION_MANAGER) as SessionManager
	# BUG-24: war fälschlich .require() — als einzige der ~15 Deps hier,
	# im Widerspruch zum dokumentierten Vertrag oben ("configure() ohne
	# optionale Deps → kein Crash, null-Guards greifen") und zu
	# test_configure_without_deps_does_not_crash(). Alle Nutzungsstellen
	# unten sind bereits (oder werden hiermit) null-safe gemacht.
	_bus             = deps.get_optional(ServiceKeys.EVENT_BUS)      as IEventBus

	_ent_skill          = deps.get_optional(ServiceKeys.SKILL_SYSTEM)         as SkillSystem
	_ent_inventory      = deps.get_optional(ServiceKeys.INVENTORY)             as InventorySystem
	_ent_stat_mod       = deps.get_optional(ServiceKeys.STAT_MODIFIERS)        as StatModifierService
	_ent_combat         = deps.get_optional(ServiceKeys.COMBAT)                as CombatSystem
	_ent_equipment      = deps.get_optional(ServiceKeys.EQUIPMENT)             as EquipmentService
	_ent_interact       = deps.get_optional(ServiceKeys.INTERACTION)  as InteractionExecutor
	_ent_player_states  = deps.get_optional(ServiceKeys.PLAYER_STATES)         as PlayerStateService
	_ent_data           = deps.get_optional(ServiceKeys.DATA)                  as DataService
	_ent_currency       = deps.get_optional(ServiceKeys.CURRENCY)              as CurrencyService
	_ent_trade          = deps.get_optional(ServiceKeys.TRADE)                 as TradeService
	_ent_pvp_death_loss = deps.get_optional(ServiceKeys.PVP_DEATH_LOSS)        as PvPDeathLossService
	_ent_aura           = deps.get_optional(ServiceKeys.AURA)                  as AuraService
	_ent_death_loot     = deps.get_optional(ServiceKeys.DEATH_LOOT)            as DeathLootService
	# ADR-037: DeathLootService braucht WorldService zum Gravestone-Spawnen,
	# kann es aber nicht als eigene Dep deklarieren (Bootstrap-Zyklus — siehe
	# DeathLootService.gd Klassenkommentar). Stattdessen direkte Injection
	# hier, unmittelbar nachdem beide Seiten (self als WorldService,
	# _ent_death_loot als aufgelöste Dep) existieren.
	if is_instance_valid(_ent_death_loot):
		_ent_death_loot.inject_world(self)
	_ent_pickpocket     = deps.get_optional(ServiceKeys.PICKPOCKET)          as PickpocketService
	# ADR-020: opportunistisch — in Produktion kommt NetworkBridge erst über
	# inject_network_bridge() (Phase C8, siehe dort für den Zyklus-Grund),
	# aber falls ein Test/Kontext sie bereits hier bereitstellt, nicht ignorieren.
	_network            = deps.get_optional(ServiceKeys.NETWORK_BRIDGE)        as NetworkBridge
	_zone_service       = deps.get_optional(ServiceKeys.ZONE_SERVICE)          as ZoneService

	data      = WorldData.new()
	factory   = WorldFactory.new()
	factory3d = Factory3D.new()
	_time     = WorldTimeService.new()
	_time.set_event_bus(_bus)
	_weather  = WeatherService.new()
	_weather.set_event_bus(_bus)

	_entity_orchestrator      = EntityOrchestrator.new()
	_entity_orchestrator.name = "EntityOrchestrator"
	add_child(_entity_orchestrator)
	_entity_orchestrator.set_event_bus(_bus)
	WorldEntityRegistry.register_all(_entity_orchestrator)
	# factory3d stammt aus WorldService selbst (World-intern, kein dep nötig).
	# respawn, player_states, data (DataService) kommen aus den oben aufgelösten Deps.
	_entity_orchestrator.set_entity_services(
		_ent_skill, _ent_inventory, factory3d,
		_respawn, _ent_data, _ent_stat_mod,
		_ent_combat, _ent_equipment, self,
		_ent_interact, _ent_player_states, _network, _ent_currency, _ent_trade,
		_ent_pvp_death_loss, _ent_aura, _ent_death_loot, _ent_pickpocket
	)
	_save_handler = WorldSaveHandler.new(data, _time, _weather)

	if is_instance_valid(_save_system):
		# C-02 (Round 68): nur die Autorität persistiert world_state — dieselbe
		# Guard-Konvention wie InventorySystem/SkillSystem/QuestService/
		# EquipmentService (deren on_*_confirmed()-Methoden ebenfalls nur auf der
		# Autorität schreiben). world_state (Bäume/Erze/Tageszeit/Pets) ist
		# geteilter Weltzustand, den ein beitretender Client nie besitzt — ihn
		# trotzdem unter dem eigenen player_id-Save mitzuschreiben würde beim
		# nächsten Solo-Start dieses Spielers eine Welt wiederbeleben, die ihm nie
		# gehörte. `not is_instance_valid(_network)` zählt bewusst als Autorität
		# (derselbe Default wie überall sonst in dieser Klasse, z. B.
		# request_entity_interaction()) — NetworkBridge kann an diesem Punkt in
		# configure() noch nicht injiziert sein (Late-Inject, s. inject_network_bridge()
		# unten); Tier 1 (Solo) bleibt so unverändert: register+restore wie bisher.
		if not is_instance_valid(_network) or _network.is_server():
			_save_system.register_save_provider(self)
		# restore_world() bleibt UNCONDITIONAL: auch ein nicht-autoritativer Client
		# braucht einen lokalen Startzustand, bevor der Server-Sync
		# (SaveSystem.apply_remote_state(), NetworkBridge._rpc_receive_initial_state())
		# eintrifft — der wird danach ohnehin überschrieben, s. dort.
		var saved := _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_save_handler.restore_world(saved)
			# day_time and day_count are now computed properties — no copy needed

	# NAHT-FIX: world_seed vor create_world() setzen damit WorldFactory
	# und ChunkManager denselben Noise-Seed verwenden → nahtlose Chunk-Grenzen.
	# Muss NACH restore_world() laufen: sonst ist data.world_seed hier immer noch
	# 0 (frische WorldData), ein gespeicherter Seed würde nie ankommen und jede
	# geladene Welt bekäme statt des persistierten Seeds einen neuen Zufallsseed.
	#
	# BUGFIX (2026-09-14, "zwei Welten"): vorher wurde hier bei einer frischen
	# WorldData (world_seed == 0) IMMER aus der lokalen Systemzeit neu gewürfelt
	# — Host und Client generierten dadurch unabhängig voneinander ein komplett
	# anderes Terrain/Layout, obwohl sie verbunden waren (Server hat nie einen
	# Seed an den Client übertragen). SessionManager reserviert den Seed jetzt
	# beim Hosten und schickt ihn per Join-Handshake mit — hier zuerst danach
	# fragen, bevor lokal neu gewürfelt wird. Tier 1 (Solo) unverändert: dort
	# liefert get_world_seed() 0, also greift weiterhin der Zeit-Fallback.
	if data.world_seed == 0 and is_instance_valid(_session_manager):
		var network_seed := _session_manager.get_world_seed()
		if network_seed != 0:
			data.world_seed = network_seed
			AppLogger.log_info(
				"world_seed von SessionManager übernommen (Netzwerk-Sync): %d." % network_seed,
				LOG_CAT
			)
	var seed_for_factory: int = data.world_seed if data.world_seed != 0 		else int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	if data.world_seed == 0:
		data.world_seed = seed_for_factory
	factory.world_seed = seed_for_factory

	# ADR-041: erster Wetterwurf für den aktuellen (ggf. wiederhergestellten)
	# day_count — muss NACH data.world_seed final gesetzt UND NACH
	# _weather.restore() (innerhalb restore_world() oben) laufen, sonst würde
	# ein geladenes _last_rolled_day den Wurf für Tag 1 fälschlich überspringen
	# oder ein noch-0-Seed einen anderen Wurf als beim nächsten Boot ergeben.
	_weather.roll_for_day(_time.day_count, data.world_seed)

	if not is_instance_valid(_world_gen):
		AppLogger.log_warn("WorldGenerationService fehlt.", LOG_CAT)

	AppLogger.log_info("WorldService konfiguriert.", LOG_CAT)

## Phase S8.6 Late-Inject — NetworkBridge wird nach vollem Session-Boot injiziert
## um den zirkulären Dep (NetworkBridge ↔ WorldService) aufzulösen (ADR-020,
## identisches Muster zu Inventory/Quest/SkillSystem/Equipment).
## ADR-021 (R-5): reicht zusätzlich an EntityOrchestrator weiter, damit ab jetzt
## gespawnte Entities (QuestNPC, QuestCustomTrigger) get_network_bridge() im
## EntityContext bekommen — vorher war _entity_network_bridge in Produktion
## bei set_entity_services() (Phase 4) noch null (siehe dortiger Kommentar).
func inject_network_bridge(network: NetworkBridge) -> void:
	_network = network
	if is_instance_valid(_entity_orchestrator):
		_entity_orchestrator.set_network_bridge(network)
	# ADR-030: zone_triggers, die bereits vor diesem Late-Inject in der Gruppe
	# stehen (z.B. on_ready() lief schon), bekommen den NetworkBridge hier
	# nachgereicht — _wire_zone_triggers() in on_ready() lief zu diesem
	# Zeitpunkt noch ohne _network.
	for trigger in get_tree().get_nodes_in_group("zone_triggers"):
		if trigger is ZoneTriggerVolume:
			trigger.inject_network_bridge(network)

func on_ready() -> void:
	if is_instance_valid(_ticker):
		_ticker.register_service(self)

	if is_instance_valid(_bus):
		_bus.world().entity_despawn_requested.connect(_on_entity_despawn_requested)
		_bus.persistence().save_pre_flush.connect(_on_save_pre_flush)
		# ADR-018-Rest: SessionManager emittiert peer_cleanup_requested nur noch
		# über EventBus.networking() — kein direkter Connect auf die Service-
		# Instanz mehr (war der letzte Locator-artige Direkt-Connect zwischen
		# zwei Services, siehe SessionManager.gd Klassenkommentar).
		_bus.networking().peer_cleanup_requested.connect(_on_peer_cleanup_requested)
	else:
		AppLogger.log_warn("EventBus fehlt — Despawn-/Save-Flush-/Peer-Cleanup-Signale nicht verbunden.", LOG_CAT)

	_wire_zone_triggers()

	var respawn := _respawn
	if is_instance_valid(respawn):
		# Bäume — aufsteigend nach Fäll-Schwierigkeit / XP
		respawn.register_config("willow_tree", 180.0)  # 3 min — schnell (15 XP)
		respawn.register_config("oak_tree",    300.0)  # 5 min — standard (25 XP)
		respawn.register_config("maple_tree",  480.0)  # 8 min — langsam (60 XP)
		# Erze — aufsteigend nach Mining-Level
		respawn.register_config("copper_ore",  420.0)  # 7 min — Einsteiger (20 XP)
		respawn.register_config("iron_ore",    600.0)  # 10 min — fortgeschritten (40 XP)
		respawn.set_spawn_callback(func(t: String, p: Vector3, pid: int = 1) -> Node3D: return spawn_entity(t, p, {}, pid))
		respawn.set_remove_callback(func(t: String, p: Vector3) -> void: data.unmark_harvested(t, p))

	AppLogger.log_info("WorldService bereit.", LOG_CAT)

## Warms up the MeshCache inside factory3d.
## Called by ServiceOrchestrator Phase S8.8 — encapsulates factory3d internals
## so the orchestrator never touches WorldService fields directly.
func warmup_mesh_cache() -> void:
	if not is_instance_valid(factory3d):
		AppLogger.log_warn("warmup_mesh_cache: factory3d nicht verfügbar — übersprungen.", LOG_CAT)
		return
	if factory3d.cache == null:
		factory3d.cache = MeshCache.new()
	factory3d.cache.build()
	AppLogger.log_info("MeshCache gebaut.", LOG_CAT)

func on_cleanup() -> void:
	if is_instance_valid(_bus):
		if _bus.persistence().save_pre_flush.is_connected(_on_save_pre_flush):
			_bus.persistence().save_pre_flush.disconnect(_on_save_pre_flush)
		# G-03: Peer-Cleanup-Signal trennen (jetzt über EventBus, siehe on_ready()).
		if _bus.networking().peer_cleanup_requested.is_connected(_on_peer_cleanup_requested):
			_bus.networking().peer_cleanup_requested.disconnect(_on_peer_cleanup_requested)
	if is_instance_valid(_chunk_manager):
		_chunk_manager.queue_free()
		_chunk_manager = null
	if is_instance_valid(_entity_orchestrator) and _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()

func on_tick(delta: float) -> void:
	if is_instance_valid(_game_manager) and _game_manager.is_playing():
		var day_before := _time.day_count
		_time.tick(delta)
		# day_time / day_count are computed properties — no copy needed
		if _time.day_count != day_before and is_instance_valid(_weather):
			var weather_before := _weather.current_weather
			_weather.roll_for_day(_time.day_count, data.world_seed)
			# Rein lokale Anzeige (wie QuestCustomTrigger.hint_text, Round 73) —
			# jeder Peer zeigt seinen eigenen deterministischen Wurf, kein
			# zusätzlicher Netzwerk-Pfad nötig (siehe WeatherService-Kommentar).
			# Nur bei tatsächlicher Änderung — WeatherService.roll_for_day() ist
			# ein No-Op, wenn der Wurf zufällig dasselbe Wetter ergibt.
			if is_instance_valid(_bus) and _weather.current_weather != weather_before:
				_bus.ui().emit_notification_requested("Das Wetter ändert sich: %s" % _weather.current_weather)

# ─────────────────────────────────────────────
# Welt-Initialisierung
# ─────────────────────────────────────────────

func on_world_scene_ready(world_root: Node3D) -> void:
	var t := AppLogger.log_begin("on_world_scene_ready()", LOG_CAT)

	if _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()
		if is_instance_valid(_bus):
			_bus.world().emit_world_scene_unloaded()

	# Statische Geometrie
	var generated := factory.create_world()
	for child in generated.get_children():
		generated.remove_child(child)
		world_root.add_child(child)
	generated.queue_free()

	# Round 74: PvP-Zone "im Wüsten-Biom" (Anfrage) — sucht zur Laufzeit die
	# erste Wüsten-Koordinate über TerrainGenerator.get_biome_id_at() statt
	# einer geratenen Fixkoordinate (Biome sind prozedural, siehe
	# DesertPvpZonePlacer-Klassenkommentar). Läuft auf JEDEM Peer (kein
	# is_server()-Guard nötig) — feste globale Biom-Seeds liefern überall
	# denselben Ort, exakt wie WorldFactory.create_world()s statische
	# Geometrie. _zone_service/_network können hier noch null sein (Late-
	# Inject S8.6 für _network kommt erst danach) — place() injiziert direkt,
	# unabhängig von der "zone_triggers"-Gruppen-Nachreichung.
	DesertPvpZonePlacer.place(world_root, factory.terrain_generator, _zone_service, _network)

	# ADR-032: Safe-Zone um den Spawnpunkt — ohne mindestens eine "safe"-
	# getaggte Zone ist das Safe-Zone-Vulnerabilitäts-Fenster (PvPService)
	# komplett inert (nichts zum Betreten). Gleicher Aufrufkontext/Timing
	# wie DesertPvpZonePlacer direkt darüber.
	SpawnSafeZonePlacer.place(world_root, factory.terrain_generator, _zone_service, _network)

	# Terrain-Höhen-Callback: wird jetzt direkt an generate_world()/generate_world_async()
	# übergeben — kein persistentes set_height_callback() mehr (Architekturplan 1.5).

	_entity_orchestrator.initialize(world_root)

	# ChunkManager: stored on the service so on_cleanup() can shut it down properly.
	# Deterministic seed: read from WorldData so every session, server and client
	# generate the same world. Set once at world creation, never from the clock.
	if is_instance_valid(_chunk_manager):
		_chunk_manager.queue_free()
	_chunk_manager = ChunkManager.new()
	_chunk_manager.name = "ChunkManager"
	world_root.add_child(_chunk_manager)
	var seed_val: int = data.world_seed if data.world_seed != 0 \
		else int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	if data.world_seed == 0:
		data.world_seed = seed_val
		AppLogger.log_warn(
			"world_seed war 0 — neuer Seed generiert: %d. Für deterministische Welten in WorldData setzen." % seed_val,
			LOG_CAT
		)
	_chunk_manager.initialize(world_root, seed_val, func(type_id: String, pos: Vector3, pid: int = 1) -> Node3D: return spawn_entity(type_id, pos, {}, pid))

	# BUG-FIX: ChunkManager wurde nie beim ServiceTicker registriert und
	# WorldService.on_tick() ruft _chunk_manager.on_tick() auch nicht auf —
	# _sync_chunks() lief dadurch NIE, außer dem Spawn-Chunk wurde kein
	# einziger Chunk je geladen (auch keine Chunk-Bäume/-Tiere).
	if is_instance_valid(_ticker):
		_ticker.register_service(_chunk_manager)

	# WorldSpawner mit aktuellen Referenzen neu erstellen
	_spawner = WorldSpawner.new(
		_entity_orchestrator,
		factory.terrain_generator,
		_world_gen,
		data,
		func(pos: Vector3, pid: int) -> Node3D:
			return spawn_entity("player", pos, {spawn_position = pos}, pid)
	)
	var local_peer: int = _session_manager.get_local_peer_id() \
		if is_instance_valid(_session_manager) else 1
	# ADR-015: EntityOrchestrator braucht dies für jeden EntityContext, nicht
	# nur für den einen spawn_entity("player", ...)-Aufruf unten.
	_entity_orchestrator.set_local_peer_id(local_peer)
	# ADR-015: EntityOrchestrator braucht dies für jeden EntityContext, nicht
	# nur für den lokalen Player-Spawn unten — sonst bleibt ctx.get_local_peer_id()
	# für alle nicht-Player-Entities beim Default 1 stehen.
	_entity_orchestrator.set_local_peer_id(local_peer)

	# F-1: MultiplayerSpawner — repliziert vom Server gespawnte Entities an alle Clients.
	# Muss vor spawn_all() eingerichtet sein damit der Spawner bereits aktiv ist wenn
	# die ersten Entities hinzugefügt werden.
	# Nur auf Server aufsetzen — Clients empfangen Spawn-Events automatisch.
	if is_instance_valid(_session_manager) and _session_manager.is_server() \
			and _session_manager.has_active_peer():
		_setup_multiplayer_spawner(world_root)

	# ADR-010 Round 55: Tier 3 (Dedizierter Server) spawnt kein Player-Entity
	# für den Host-Prozess selbst — der Host ist dort reine Autorität, kein
	# spielender Client. Tier 1/2 unverändert (spawn_local_player bleibt true).
	var spawn_local_player := not (
		is_instance_valid(_session_manager) and _session_manager.is_dedicated_server()
	)
	await _spawner.spawn_all(world_root, local_peer, spawn_local_player)

	# BUGFIX (2026-09-14, "zwei Welten" Teil 2): world_seed sorgt jetzt für
	# identisches Terrain — aber ohne diesen Schritt spawnt jeder Peer weiterhin
	# nur sein EIGENES Player-Entity (siehe spawn_all()/_spawn_player_cb oben)
	# und niemand erfährt je vom Player-Entity eines ANDEREN Peers. Server und
	# Client melden ihr frisch gespawntes lokales Player-Entity daher hier an
	# NetworkBridge — die Autorität registriert es und informiert alle bereits
	# aktiven Peers gegenseitig (siehe NetworkBridge.report_local_player_spawned()).
	# Tier 1 (Solo) und Tier 3 (Host ohne eigenes Player-Entity): no-op dort.
	if spawn_local_player and is_instance_valid(_network):
		var local_player_node := get_player_by_id(local_peer)
		if is_instance_valid(local_player_node):
			_network.report_local_player_spawned(local_player_node.global_position)
		else:
			AppLogger.log_warn(
				"Lokales Player-Entity nach spawn_all() nicht gefunden (peer %d) — Mitspieler-Sichtbarkeit für diesen Peer nicht gemeldet." % local_peer,
				LOG_CAT
			)

	if is_instance_valid(_bus):
		_bus.world().emit_world_scene_ready(world_root)

	AppLogger.log_end("on_world_scene_ready()", t, LOG_CAT)
	AppLogger.log_info("Welt bereit. Entities: %d." % _entity_orchestrator.get_entity_count(), LOG_CAT)

# ─────────────────────────────────────────────
# Multiplayer (Sprint E)
# ─────────────────────────────────────────────

## F-1: Richtet einen MultiplayerSpawner für die Spielwelt ein.
## Läuft nur auf dem Server (Host/Tier 2-3) vor spawn_all().
##
## Verwendet spawn_function/despawn_function statt add_spawnable_scene(),
## weil das Projekt GDScript.new()-basiertes Instanziieren nutzt (keine .tscn-Wrapper).
## add_spawnable_scene() akzeptiert nur .tscn-Pfade und würde zur Laufzeit fehlschlagen.
##
## Godot ruft spawn_function(data) auf dem Client auf wenn der Server einen Node
## unter spawn_path hinzufügt. data ist ein frei wählbarer Variant — wir übergeben
## den registrierten script_path als String, der via path_map zu type_id aufgelöst wird.
func _setup_multiplayer_spawner(world_root: Node3D) -> void:
	var ms := MultiplayerSpawner.new()
	ms.name = "WorldMultiplayerSpawner"
	ms.spawn_path = NodePath("..")   # world_root selbst ist Spawn-Root

	# Path → TypeId-Map aus der EntityRegistry aufbauen.
	# Ermöglicht spawn_function() den richtigen type_id zu ermitteln
	# ohne den EntityOrchestrator direkt in der Closure zu referenzieren.
	var path_map: Dictionary = _entity_orchestrator.get_registry().get_path_to_type_map()
	var registry_ref := _entity_orchestrator.get_registry()  # Closure-Capture

	ms.spawn_function = func(data: Variant) -> Node:
		# data ist der script_path-String (vom Server beim Spawn übermittelt).
		var type_id: String = path_map.get(str(data), "")
		if type_id.is_empty():
			AppLogger.log_error(
				"MultiplayerSpawner.spawn_function: Unbekannter Pfad '%s'." % str(data),
				LOG_CAT
			)
			return null
		# Nur instanziieren — kein add_child, kein on_spawn, kein UUID-Tracking.
		# Der MultiplayerSpawner übernimmt add_child in world_root selbst.
		# State-Sync läuft via MultiplayerSynchronizer (Sprint E).
		return registry_ref.instantiate(type_id)

	# BUGFIX (2026-09-14): 'despawn_function' existiert NICHT als Property
	# auf MultiplayerSpawner (Godot 4) — die Zuweisung schlug bei JEDEM
	# Welt-Boot fehl: "Invalid assignment of property or key
	# 'despawn_function' ... on a base object of type 'MultiplayerSpawner'".
	# MultiplayerSpawner despawnt automatisch, sobald der Server-seitige
	# Node freigegeben wird — kein manueller Hook nötig. Für zusätzliche
	# Client-seitige Aufräumarbeiten existiert stattdessen das Signal
	# 'despawned(node)', keine zuweisbare Callable-Property.
	ms.despawned.connect(func(node: Node) -> void:
		if is_instance_valid(node) and not node.is_queued_for_deletion():
			node.queue_free()
	)

	world_root.add_child(ms)
	AppLogger.log_info(
		"MultiplayerSpawner eingerichtet (%d Typen, Custom Spawn/Despawn)." % path_map.size(),
		LOG_CAT
	)

# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func get_save_key() -> String:
	return SAVE_KEY

func get_save_data() -> Dictionary:
	return _save_handler.get_save_data()

# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

func get_formatted_time() -> String:
	return _time.get_formatted_time()

## peer_id: Multiplayer-Autorität des gespawnten Nodes.
## Default 1 = Server-Autorität (Bäume, Erze, Gegner, Tiere).
## Für Player-Respawn die echte peer_id des Clients übergeben.
func spawn_entity(type_id: String, position: Vector3, config: Dictionary = {}, peer_id: int = 1) -> Node3D:
	if not is_instance_valid(_entity_orchestrator):
		return null
	var entity := _entity_orchestrator.spawn_entity(type_id, position, config, peer_id)
	# G-02: Player-Nodes beim ChunkManager registrieren damit alle Spieler Chunks laden.
	if is_instance_valid(entity) and type_id == "player" and is_instance_valid(_chunk_manager):
		_chunk_manager.add_player(entity)
	return entity

func despawn_entity(uuid: String) -> void:
	if not is_instance_valid(_entity_orchestrator):
		return
	# G-02: Player-Node aus Chunk-Tracking entfernen bevor er despawnt wird.
	if is_instance_valid(_chunk_manager):
		var entity := _entity_orchestrator.get_entity(uuid)
		if is_instance_valid(entity) and entity.is_in_group("player"):
			_chunk_manager.remove_player(entity)
	_entity_orchestrator.despawn_entity(uuid)

func get_entity_debug_info() -> Dictionary:
	if not is_instance_valid(_entity_orchestrator):
		return {}
	return _entity_orchestrator.get_debug_info()

## ADR-027: Fassade auf EntityOrchestrator.find_player_by_id() — der eine
## kanonische "Player-Node für peer_id"-Lookup, aufrufbar von Services ohne
## IEntityContext/IUIContext (z. B. EquipmentService via inject_world_service()).
func get_player_by_id(peer_id: int) -> Node3D:
	if not is_instance_valid(_entity_orchestrator):
		return null
	return _entity_orchestrator.find_player_by_id(peer_id)

## ADR-027: löst den PlayerVisuals-Kindnode von peer_id auf. Ersetzt die
## bisher doppelt vorhandene Kind-Lookup-Logik aus
## InventoryUIController._find_local_player_visuals() und
## EquipmentUIController's Äquivalent — beide riefen zuvor ctx.get_local_player()
## (nur der LOKALE Peer) auf und suchten dann selbst den PlayerVisuals-Child.
## Hier für einen BELIEBIGEN peer_id, damit die Equip-Autorität (die auf
## Tier 2/3 nicht der aufrufende Peer ist) die Visuals des ZIEL-Spielers
## auflösen kann, nicht die des Aufrufers.
func get_player_visuals(peer_id: int) -> PlayerVisuals:
	var player_node := get_player_by_id(peer_id)
	if not is_instance_valid(player_node):
		return null
	var pv := player_node.get_node_or_null("PlayerVisuals") as PlayerVisuals
	if is_instance_valid(pv):
		return pv
	for child in player_node.get_children():
		if child is PlayerVisuals:
			return child as PlayerVisuals
	return null

## ADR-025: autoritäts-seitiger Einstiegspunkt für Bewegungs-Input, aufgerufen
## ausschließlich von NetworkBridge._rpc_submit_movement_input() (peer_id dort
## bereits fälschungssicher aus multiplayer.get_remote_sender_id() aufgelöst,
## nie aus dem Payload). Löst den Ziel-Player-Node über dieselbe Fassade wie
## jeder andere peer_id-Lookup auf (get_player_by_id() → EntityOrchestrator.
## find_player_by_id()) und reicht den Snapshot durch — keine eigene Logik hier,
## damit es nur EINE Stelle gibt, die "peer_id → Node" auflöst.
func route_movement_input(peer_id: int, input_snapshot: Dictionary) -> void:
	var player_node := get_player_by_id(peer_id)
	if not is_instance_valid(player_node):
		# Race zwischen Despawn/Disconnect und einem noch unterwegs befindlichen
		# unreliable Input-Paket — erwartbar, kein Fehlerfall, deshalb kein log_warn
		# (würde bei jedem Disconnect spammen, s. NetworkContract.gd "UNRELIABLE").
		return
	# has_method()+call() statt direktem typisiertem Aufruf — player_node ist als
	# Node3D typisiert (get_player_by_id()s Rückgabetyp), derselbe Grund wie beim
	# `_on_interacted`-Aufruf oben in resolve_and_dispatch_interaction().
	if player_node.has_method("receive_authoritative_input"):
		player_node.call("receive_authoritative_input", input_snapshot)

func _on_entity_despawn_requested(uuid: String) -> void:
	despawn_entity(uuid)

## ADR-030: verdrahtet alle ZoneTriggerVolume-Nodes, die zum Zeitpunkt von
## on_ready() bereits in der Welt-Szene stehen (Level-Design-platziert, nicht
## über EntityOrchestrator gespawnt — dieselbe Kategorie wie QuestCustomTrigger).
## _network ist an dieser Stelle typischerweise noch nicht gesetzt (Late-Inject
## S8.6 kommt danach) — inject_network_bridge() holt das nach, siehe dort.
## Nodes, die ERST NACH on_ready() zur Welt hinzugefügt werden, sind bewusst
## nicht abgedeckt (kein Rescan-Mechanismus) — wie WorldSpawner-gespawnte
## Trees etc. ohnehin über eigene Pfade laufen, nicht über zone_triggers.
func _wire_zone_triggers() -> void:
	if not is_instance_valid(_zone_service):
		return
	for trigger in get_tree().get_nodes_in_group("zone_triggers"):
		if trigger is ZoneTriggerVolume:
			trigger.inject_zone_service(_zone_service)
			if is_instance_valid(_network):
				trigger.inject_network_bridge(_network)

# ─────────────────────────────────────────────
# ADR-020: Interaktions-Ergebnisse werden auf der Autorität ausgeführt
# ─────────────────────────────────────────────

## Fallback-Reichweite falls eine Entity keine InteractableComponent (mehr) hat —
## sollte im Normalfall nie greifen (jede interagierbare Entity hat eine), rein
## defensiv gegen einen Despawn-Race zwischen Client-Interaktion und RPC-Ankunft.
const _FALLBACK_INTERACTION_RANGE := 5.0
## Toleranz zusätzlich zum tatsächlichen Interaktions-Radius — deckt Rundung/
## Interpolation ab, kein zusätzlicher Cheat-Spielraum (bewegt sich nicht mit
## einem client-gemeldeten Wert, sondern ist eine feste, servereigene Konstante).
const _INTERACTION_RANGE_MARGIN := 1.5

## Aufgerufen von InteractableComponent._handle_completion() für JEDE Entity mit
## _on_interacted()-Hook (Harvestables, Tiere, Gegner), NUR wenn diese Entity aus
## Sicht des ausführenden Peers nicht die Netzwerk-Autorität ist.
##
## WICHTIG (Cheat-Vektor geschlossen): peer_id kommt hier NIE vom Client selbst —
## auf Tier 2/3 setzt NetworkBridge ihn aus multiplayer.get_remote_sender_id()
## (fälschungssicher, Godot-verwaltet), auf Tier 1 ist es ohnehin immer der lokale
## Spieler. Ebenso wenig wird eine Reichweite vom Client entgegengenommen — siehe
## resolve_and_dispatch_interaction().
func request_entity_interaction(entity_uuid: String, action_id: String, peer_id: int) -> void:
	if is_instance_valid(_network) and _network.has_peer() and not _network.is_server():
		_network.send_entity_interaction(entity_uuid, action_id)
		return
	# Kein Peer (Tier 1) oder wir sind bereits die Autorität: direkt auflösen.
	# Sollte über den is_multiplayer_authority()-Guard im Aufrufer eigentlich nie
	# der reguläre Pfad sein (dann läuft der lokale interacted-Emit bereits mit
	# echter Wirkung) — rein defensive Deckung, kein Doppel-Wirkungs-Risiko, weil
	# resolve_and_dispatch_interaction() denselben _on_interacted()-Hook aufruft,
	# den auch der lokale Emit aufgerufen hätte.
	resolve_and_dispatch_interaction(entity_uuid, action_id, peer_id)

## Autoritäts-seitiger Einstiegspunkt (ADR-023 + ADR-020): löst entity_uuid über
## EntityOrchestrator.resolve_for_player() auf — inkl. Plausibilitäts-Check, ob
## peer_id überhaupt in Reichweite ist — und ruft bei Erfolg den Interaktions-
## Hook der Entity auf. Die max_range dafür kommt von der Entity selbst
## (InteractableComponent.detection_radius, servereigener State), niemals vom
## Client — ein modifizierter Client könnte sonst eine beliebig große Reichweite
## mitschicken und die Plausibilitätsprüfung wertlos machen.
func resolve_and_dispatch_interaction(entity_uuid: String, action_id: String, peer_id: int) -> void:
	if not is_instance_valid(_entity_orchestrator):
		AppLogger.log_warn("resolve_and_dispatch_interaction(): kein EntityOrchestrator.", LOG_CAT)
		return

	var probe := _entity_orchestrator.get_entity(entity_uuid)
	if not is_instance_valid(probe):
		AppLogger.log_warn(
			"resolve_and_dispatch_interaction('%s'): unbekannte/bereits despawnte Entity." % entity_uuid,
			LOG_CAT
		)
		return

	var max_range := _max_interaction_range_for(probe, action_id)
	var entity := _entity_orchestrator.resolve_for_player(entity_uuid, peer_id, max_range)
	if not is_instance_valid(entity):
		return  # resolve_for_player() loggt bereits den genauen Ablehnungsgrund

	if entity.has_method("_on_interacted"):
		entity._on_interacted(action_id, peer_id)
	else:
		AppLogger.log_warn(
			"resolve_and_dispatch_interaction('%s'): Entity hat keinen _on_interacted()-Hook." % entity_uuid,
			LOG_CAT
		)

## Liest den tatsächlichen Interaktions-Radius aus der InteractableComponent der
## Entity (gesetzt in InteractableComponent._ready() als Meta "interactable_components",
## Liste seit ADR-035 — ein Node kann mehrere Interaktionen tragen, z.B. Player:
## "attack_player" + "trade_request", jede mit potenziell eigenem detection_radius)
## statt einen globalen Wert zu raten — jede Interaktionsart hat ihren eigenen,
## typischerweise über @export data.detection_radius definierten Radius.
## action_id wählt die zur tatsächlich angeforderten Aktion passende Komponente
## aus der Liste — ohne das würde bei mehreren Komponenten pro Node einfach
## irgendeine (z.B. die erste) das Reichweiten-Limit für ALLE Aktionen setzen.
func _max_interaction_range_for(entity: Node, action_id: String) -> float:
	var comps: Array = entity.get_meta("interactable_components", [])
	var base_id := action_id.trim_suffix("_inspect")
	for comp in comps:
		if is_instance_valid(comp) and (comp as InteractableComponent).data.id == base_id:
			return (comp as InteractableComponent).detection_radius + _INTERACTION_RANGE_MARGIN
	# Kein exakter Treffer (z.B. "<id>_inspect"-Aktionen, die dieselbe Komponente
	# wie ihre Basis-Aktion nutzen, siehe InteractableComponent.get_actions()) —
	# größte verfügbare Reichweite unter den Komponenten dieser Entity als
	# plausibler Fallback, bevor auf den globalen Fallback-Wert zurückgefallen wird.
	var best := -1.0
	for comp in comps:
		if is_instance_valid(comp):
			best = max(best, (comp as InteractableComponent).detection_radius)
	if best >= 0.0:
		return best + _INTERACTION_RANGE_MARGIN
	AppLogger.log_warn(
		"_max_interaction_range_for('%s'): keine InteractableComponent gefunden — Fallback-Reichweite %.1f." \
		% [entity.name, _FALLBACK_INTERACTION_RANGE],
		LOG_CAT
	)
	return _FALLBACK_INTERACTION_RANGE

## G-03: Wird von SessionManager.peer_cleanup_requested ausgelöst wenn ein Peer die Verbindung trennt.
## Entfernt alle Player-Nodes dieses Peers aus dem ChunkManager-Tracking.
## Der eigentliche Node-Despawn läuft separat über EntityOrchestrator (uuid-basiert).
func _on_peer_cleanup_requested(peer_id: int) -> void:
	if not is_instance_valid(_chunk_manager):
		return
	if not is_instance_valid(_entity_orchestrator):
		return
	# Alle Player-Nodes mit diesem owner_peer_id aus dem Tracking entfernen.
	# Meta statt multiplayer_authority: "wem gehört das Node" und "wer ist
	# Netzwerk-Autorität" sind zwei verschiedene Fragen (ADR-025), siehe TODO
	# "BLOCKER für ADR-025/026-Umsetzung".
	var player_nodes := _entity_orchestrator.get_entities_in_group("player")
	for player in player_nodes:
		if is_instance_valid(player) and player.get_meta("owner_peer_id", 1) == peer_id:
			_chunk_manager.remove_player(player)
			AppLogger.log_info(
				"Peer %d: Player-Node aus Chunk-Tracking entfernt." % peer_id, LOG_CAT
			)

## Pre-Flush-Handler: Sichert Pet-Daten bevor SaveSystem auf Disk schreibt.
## Wird über EventBus.persistence.save_pre_flush ausgelöst (nicht direkt von GameSaveService).
func _on_save_pre_flush() -> void:
	collect_and_store_pet_data()

# ─────────────────────────────────────────────
# Öffentliche API — WorldData-Delegation
# Externe Aufrufer nutzen diese Wrapper statt direktem Datenzugriff.
# ─────────────────────────────────────────────

## Generischer Harvest-Marker für alle HarvestableEntity-Subklassen.
## type_id = EntityRegistry-Key (z.B. "oak_tree", "iron_ore", "copper_ore").
## Delegiert auf WorldData.make_key() → einheitliches Schema an allen drei
## Stellen: mark / unmark / is_harvested_by_type.
func mark_harvested(type_id: String, pos: Vector3) -> void:
	data.mark_harvested(WorldData.make_key(type_id, pos))

## Speichert Pet-Zustand vor dem Abspeichern.
func store_pet_save_data(pet_data: Array[Dictionary]) -> void:
	data.set_meta("saved_pets", pet_data)

## Scannt alle aktiven Pets und sichert deren Zustand via store_pet_save_data().
## Aufgerufen von _on_save_pre_flush() — nicht mehr direkt von GameSaveService.
func collect_and_store_pet_data() -> void:
	var pet_data: Array[Dictionary] = []
	for pet in get_tree().get_nodes_in_group("pets"):
		if pet is PetComponent:
			pet_data.append(pet.get_save_state())
	store_pet_save_data(pet_data)
	AppLogger.log_debug("Pets gesammelt und gespeichert: %d" % pet_data.size(), LOG_CAT)
