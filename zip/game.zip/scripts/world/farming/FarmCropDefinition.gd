class_name FarmCropDefinition
extends Resource

## FarmCropDefinition — Datengetriebene Konfiguration EINER Feldfrucht.
##
## Analog zu CombatProfile (TD-10)/SkillDefinition: statische, in
## DataService geladene Ressource statt Hardcode im Entity-Skript. Neue
## Feldfrüchte (Kartoffel, Weizen, …) brauchen nur eine neue .tres-Datei
## + Eintrag in DataManifest.CROPS + Samen-/Ernte-Items — kein Code-Änderung
## an FarmPlot.gd nötig.
##
## seed_item_id/harvest_item_id verweisen auf ItemDefinition-IDs (DataService.
## get_item()). growth_seconds ist Echtzeit (kein WorldTime/Tag-Nacht-Zyklus
## verdrahtet — siehe FarmPlot.gd Klassenkommentar "Bewusst NICHT").

@export var id: String = ""
@export var display_name: String = ""
@export var seed_item_id: String = ""
@export var harvest_loot_table_id: String = ""
## XP-Skill für die Ernte — FarmPlot._on_interacted() nutzt InteractionResolver.
## resolve() genau wie HarvestableEntity, xp_type kommt aus der
## InteractableData der "harvest_crop"-Aktion, nicht direkt von hier
## (Konsistenz mit dem bestehenden Resolver-Pfad).
@export var xp_amount: int = 15
@export var growth_seconds: float = 45.0
