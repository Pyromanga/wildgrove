class_name VillageNames
extends RefCounted

## VillageNames — deterministische deutsche Ortsnamen ("Eichenfurt", "Birkenau", …).
## Reine Funktion von einem Integer-Hash; keine Marken-/Franchise-Namen (siehe AGENT.md).

const PREFIXES: Array[String] = [
	"Eichen", "Birken", "Stein", "Mühl", "Wald", "Bach", "Linden", "Hain", "Rosen", "Fuchs",
	"Raben", "Nebel", "Wiesen", "Kiesel", "Weiden", "Tannen", "Buchen", "Hirsch", "Salz", "Klee",
	"Erlen", "Ahorn", "Moos", "Kranich", "Hasel", "Wolfs", "Distel", "Amsel",
]
const SUFFIXES: Array[String] = [
	"dorf", "bach", "furt", "au", "stedt", "hagen", "brunn", "heim", "feld", "rode", "thal", "kamp",
]

static func name_for(hash_value: int) -> String:
	var h: int = absi(hash_value)
	var prefix: String = PREFIXES[h % PREFIXES.size()]
	var suffix: String = SUFFIXES[(h >> 5) % SUFFIXES.size()]
	return prefix + suffix
