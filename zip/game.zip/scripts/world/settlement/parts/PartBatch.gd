class_name PartBatch
extends RefCounted

## PartBatch — sammelt viele kleine Bauteile (Boxen, Zylinder, Dachprismen, Pyramiden) zu
## EINEM Mesh (Vertex-Farben) plus Kollisionsformen.
##
## WARUM: Ein Dorf besteht aus hunderten Einzelteilen (Wandsegmente, Pfosten, Zaunlatten, …).
## Als einzelne MeshInstance3D wären das hunderte Draw-Calls und Nodes — auf Mobilgeräten
## nicht tragbar. Hier laufen alle Teile eines Gebäudes in einen SurfaceTool-Puffer und
## werden mit build() zu GENAU EINER MeshInstance3D (ein Material, Farbe pro Vertex) plus
## einem StaticBody3D zusammengesetzt.
##
## Rein deterministisch und ohne Weltbezug: Koordinaten sind lokal zum Gebäude-Ursprung.
## Das Material ist doppelseitig (CULL_DISABLED), damit eine falsche Dreiecks-Windung nie
## unsichtbare Flächen ergibt; Normalen werden deshalb explizit und nach außen gesetzt.

const SEGMENTS_DEFAULT: int = 10

static var _material: StandardMaterial3D = null

var _st: SurfaceTool = SurfaceTool.new()
var _shapes: Array = []        # [{shape: Shape3D, xform: Transform3D}]
var _tri_count: int = 0

func _init() -> void:
	_st.begin(Mesh.PRIMITIVE_TRIANGLES)

static func shared_material() -> StandardMaterial3D:
	if _material == null:
		_material = StandardMaterial3D.new()
		_material.vertex_color_use_as_albedo = true
		_material.roughness = 0.9
		_material.cull_mode = BaseMaterial3D.CULL_DISABLED
	return _material

func triangle_count() -> int:
	return _tri_count

func shape_count() -> int:
	return _shapes.size()

# ─────────────────────────────────────────────
# Primitive
# ─────────────────────────────────────────────

## Quader. pos = Mittelpunkt, rot_y = Drehung um die Hochachse (rad).
func add_box(size: Vector3, pos: Vector3, color: Color, rot_y: float = 0.0, collide: bool = true) -> void:
	var h := size * 0.5
	var c: Array[Vector3] = [
		Vector3(-h.x, -h.y, -h.z), Vector3(h.x, -h.y, -h.z),
		Vector3(h.x, -h.y, h.z), Vector3(-h.x, -h.y, h.z),
		Vector3(-h.x, h.y, -h.z), Vector3(h.x, h.y, -h.z),
		Vector3(h.x, h.y, h.z), Vector3(-h.x, h.y, h.z),
	]
	for i in range(8):
		c[i] = _xf(c[i], pos, rot_y)
	# Seiten: unten 0..3, oben 4..7.
	_quad(c[0], c[1], c[2], c[3], color, pos)  # unten
	_quad(c[4], c[5], c[6], c[7], color, pos)  # oben
	_quad(c[0], c[1], c[5], c[4], color, pos)  # hinten (-Z)
	_quad(c[3], c[2], c[6], c[7], color, pos)  # vorne (+Z)
	_quad(c[0], c[3], c[7], c[4], color, pos)  # links (-X)
	_quad(c[1], c[2], c[6], c[5], color, pos)  # rechts (+X)
	if collide:
		var shape := BoxShape3D.new()
		shape.size = size
		_shapes.append({"shape": shape, "xform": Transform3D(Basis(Vector3.UP, rot_y), pos)})

## Zylinder (stehend). pos = Mittelpunkt.
func add_cylinder(
	radius: float, height: float, pos: Vector3, color: Color,
	collide: bool = true, segments: int = SEGMENTS_DEFAULT
) -> void:
	var n: int = maxi(3, segments)
	var hy: float = height * 0.5
	var ring_lo: Array[Vector3] = []
	var ring_hi: Array[Vector3] = []
	for i in range(n):
		var a: float = float(i) * TAU / float(n)
		ring_lo.append(pos + Vector3(cos(a) * radius, -hy, sin(a) * radius))
		ring_hi.append(pos + Vector3(cos(a) * radius, hy, sin(a) * radius))
	var top_c := pos + Vector3(0.0, hy, 0.0)
	var bot_c := pos + Vector3(0.0, -hy, 0.0)
	for i in range(n):
		var j: int = (i + 1) % n
		_quad(ring_lo[i], ring_lo[j], ring_hi[j], ring_hi[i], color, pos)
		_tri(top_c, ring_hi[i], ring_hi[j], color, pos)
		_tri(bot_c, ring_lo[i], ring_lo[j], color, pos)
	if collide:
		var shape := CylinderShape3D.new()
		shape.radius = radius
		shape.height = height
		_shapes.append({"shape": shape, "xform": Transform3D(Basis.IDENTITY, pos)})

## Giebeldach (Prisma). pos = Mitte der Grundfläche auf Traufhöhe, First entlang lokal X
## (vor rot_y). half_w = halbe Länge (X), half_d = halbe Tiefe (Z), rise = Firsthöhe.
func add_gable_roof(
	half_w: float, half_d: float, rise: float, pos: Vector3, color: Color,
	rot_y: float = 0.0, collide: bool = true
) -> void:
	var a := _xf(Vector3(-half_w, 0.0, -half_d), pos, rot_y)
	var b := _xf(Vector3(half_w, 0.0, -half_d), pos, rot_y)
	var c := _xf(Vector3(half_w, 0.0, half_d), pos, rot_y)
	var d := _xf(Vector3(-half_w, 0.0, half_d), pos, rot_y)
	var r1 := _xf(Vector3(-half_w, rise, 0.0), pos, rot_y)
	var r2 := _xf(Vector3(half_w, rise, 0.0), pos, rot_y)
	var ref: Vector3 = pos + Vector3(0.0, rise * 0.33, 0.0)
	_quad(a, b, r2, r1, color, ref)   # Rückseite
	_quad(d, c, r2, r1, color, ref)   # Vorderseite
	_tri(a, d, r1, color, ref)        # Giebel links
	_tri(b, c, r2, color, ref)        # Giebel rechts
	_quad(a, b, c, d, color, ref)     # Unterseite
	if collide:
		var shape := ConvexPolygonShape3D.new()
		shape.points = PackedVector3Array([
			Vector3(-half_w, 0.0, -half_d), Vector3(half_w, 0.0, -half_d),
			Vector3(half_w, 0.0, half_d), Vector3(-half_w, 0.0, half_d),
			Vector3(-half_w, rise, 0.0), Vector3(half_w, rise, 0.0),
		])
		_shapes.append({"shape": shape, "xform": Transform3D(Basis(Vector3.UP, rot_y), pos)})

## Pyramide (Turm-/Zeltdach). pos = Mitte der Grundfläche.
func add_pyramid(
	half_w: float, half_d: float, rise: float, pos: Vector3, color: Color,
	rot_y: float = 0.0, collide: bool = true
) -> void:
	var a := _xf(Vector3(-half_w, 0.0, -half_d), pos, rot_y)
	var b := _xf(Vector3(half_w, 0.0, -half_d), pos, rot_y)
	var c := _xf(Vector3(half_w, 0.0, half_d), pos, rot_y)
	var d := _xf(Vector3(-half_w, 0.0, half_d), pos, rot_y)
	var apex := pos + Vector3(0.0, rise, 0.0)
	var ref: Vector3 = pos + Vector3(0.0, rise * 0.25, 0.0)
	_tri(a, b, apex, color, ref)
	_tri(b, c, apex, color, ref)
	_tri(c, d, apex, color, ref)
	_tri(d, a, apex, color, ref)
	_quad(a, b, c, d, color, ref)
	if collide:
		var shape := ConvexPolygonShape3D.new()
		shape.points = PackedVector3Array([
			Vector3(-half_w, 0.0, -half_d), Vector3(half_w, 0.0, -half_d),
			Vector3(half_w, 0.0, half_d), Vector3(-half_w, 0.0, half_d),
			Vector3(0.0, rise, 0.0),
		])
		_shapes.append({"shape": shape, "xform": Transform3D(Basis(Vector3.UP, rot_y), pos)})

# ─────────────────────────────────────────────
# Zusammenbau
# ─────────────────────────────────────────────

## Fertiger Node3D: Kind "Mesh" (MeshInstance3D) + Kind "Body" (StaticBody3D mit allen Formen).
## Nach build() darf der Batch nicht weiterverwendet werden (SurfaceTool ist verbraucht).
func build(node_name: String = "Parts") -> Node3D:
	var root := Node3D.new()
	root.name = node_name
	if _tri_count > 0:
		var mesh: ArrayMesh = _st.commit()
		var inst := MeshInstance3D.new()
		inst.name = "Mesh"
		inst.mesh = mesh
		inst.material_override = shared_material()
		inst.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		root.add_child(inst)
	if not _shapes.is_empty():
		var body := StaticBody3D.new()
		body.name = "Body"
		root.add_child(body)
		for entry: Dictionary in _shapes:
			var col := CollisionShape3D.new()
			col.shape = entry["shape"] as Shape3D
			col.transform = entry["xform"] as Transform3D
			body.add_child(col)
	return root

# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

static func _xf(v: Vector3, pos: Vector3, rot_y: float) -> Vector3:
	if rot_y == 0.0:
		return v + pos
	return v.rotated(Vector3.UP, rot_y) + pos

## Dreieck mit nach AUSSEN (weg von `ref`) zeigender Normale.
func _tri(a: Vector3, b: Vector3, c: Vector3, color: Color, ref: Vector3) -> void:
	var n: Vector3 = (b - a).cross(c - a)
	if n.length_squared() < 0.0000001:
		return
	n = n.normalized()
	var centroid: Vector3 = (a + b + c) / 3.0
	if n.dot(centroid - ref) < 0.0:
		n = -n
	for v: Vector3 in [a, b, c]:
		_st.set_color(color)
		_st.set_normal(n)
		_st.add_vertex(v)
	_tri_count += 1

func _quad(a: Vector3, b: Vector3, c: Vector3, d: Vector3, color: Color, ref: Vector3) -> void:
	_tri(a, b, c, color, ref)
	_tri(a, c, d, color, ref)
