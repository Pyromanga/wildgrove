# res://scripts/session/MeshCache.gd
class_name MeshCache extends RefCounted

## MeshCache — Baut alle prozeduralen Meshes einmalig beim Session-Boot.
##
## Kein Service im Container — lebt als Feld in Factory3D.
## Factory3D.build_cache() muss VOR dem ersten Spawn aufgerufen werden.
## ServiceOrchestrator ruft dies in Phase S8.8 auf (nach populate_session,
## vor world_gen und Entity-Spawning).
##
## Caching-Strategie:
##   ArrayMesh-Objekte: direkt geteilt (GPU-Ressource ist immutable nach build())
##   Multi-Node-Objekte (Baum, Kaktus, Pilz, Farn): PackedScene built from code, geklont via instantiate()
##   Randomisierte Objekte (Fels, gefällter Baumstamm): Einheits-Mesh + per-Instanz
##     non-uniform Node-Skalierung, statt neuer PrimitiveMesh-Objekte zur Laufzeit
##
## Factory3D erzeugt ausschließlich über diesen Cache. Factory3D.cache
## muss gesetzt und gebaut sein, bevor die erste create_*()-Methode
## aufgerufen wird.
##
## Performance-Ziel: 0 CylinderMesh.new() / SphereMesh.new() zur Laufzeit.
## Alle GPU-Uploads passieren einmalig in build().

const LOG_CAT := "MeshCache"

## Nah/Fern-Sichtweite für Baumkronen (Wunsch "entferntes/nahes Rendern"): innerhalb
## LOD_NEAR_DISTANCE zeigt sich die neue Karten-Krone (_build_leaf_cluster(), Blattform +
## Muster sichtbar), jenseits davon die alte, billige Kugel-Krone (kein Geometrie-Detail nötig,
## auf die Entfernung ohnehin nicht unterscheidbar) — beide sitzen die ganze Zeit im Baum, Godots
## GeometryInstance3D.visibility_range_* blendet rein über Entfernung zur Kamera um, kein
## eigener Tick/Code nötig. LOD_FADE_MARGIN ist die Übergangszone (visibility_range_*_margin),
## in der beide weich über- statt hart umgeblendet werden (VISIBILITY_RANGE_FADE_SELF).
const LOD_NEAR_DISTANCE: float = 14.0
const LOD_FADE_MARGIN: float = 2.5

## Wachstumsstadien (Wunsch "Bäume in verschiedenen Stadien darstellen"): EIN Bauplan pro Art
## (siehe _build_deciduous_tree()/_build_scene_pine()), `stage` skaliert ihn nur — kein
## separat gepflegtes "Sapling-Modell" pro Baumart, sondern derselbe Ast-für-Ast-Bauplan mit
## weniger/kürzeren Ästen und kleinerem Stamm. TREE_STAGE_SCALE skaliert Stamm/Äste/Kronen
## gleichmäßig, TREE_STAGE_LIMB_KEEP kürzt die Astliste einer Art auf die ersten N Einträge
## (Laubbäume) bzw. steuert die Wirtel-Anzahl bei der Tanne (siehe PINE_STAGE_TIERS).
## Auswahl WELCHES Stadium ein konkreter Baum bekommt: siehe TreeGrowthStage.gd (deterministisch
## aus der Weltposition, nicht zufällig — Determinismus über alle Peers, wie überall sonst in
## diesem Cache).
enum TreeStage { SAPLING, YOUNG, MATURE }
const TREE_STAGE_SCALE: Dictionary = {
	TreeStage.SAPLING: 0.42,
	TreeStage.YOUNG:   0.7,
	TreeStage.MATURE:  1.0,
}
const TREE_STAGE_LIMB_KEEP: Dictionary = {
	TreeStage.SAPLING: 1,
	TreeStage.YOUNG:   2,
	TreeStage.MATURE:  99,   # "alle" — echte Astzahl kommt aus limbs.size() der jeweiligen Art
}
const PINE_STAGE_TIERS: Dictionary = {
	TreeStage.SAPLING: 0,    # nur der Spitzen-Büschel, noch keine Wirtel
	TreeStage.YOUNG:   2,
	TreeStage.MATURE:  4,
}

## Einfache Meshes — direkt als ArrayMesh geteilt
var meshes: Dictionary = {}     # { "key": ArrayMesh }

## Komplexe Multi-Node-Objekte — als PackedScene geklont
var scenes: Dictionary = {}     # { "key": PackedScene }

## Material-Cache — StandardMaterial3D ist teuer zu erstellen
var materials: Dictionary = {}  # { color_key: StandardMaterial3D }

var _built: bool = false

func build() -> void:
	if _built:
		return
	var t := Time.get_ticks_msec()

	_build_materials()
	_build_simple_meshes()
	_build_tree_scenes()
	_build_mushroom_scenes()
	_build_animal_meshes()
	_build_bar_mesh()

	_built = true
	AppLogger.log_info(
		"MeshCache: %d meshes, %d scenes, %d materials in %d ms" % [
			meshes.size(), scenes.size(), materials.size(),
			Time.get_ticks_msec() - t
		],
		LOG_CAT
	)

func is_built() -> bool:
	return _built

## Gibt ein gecachtes oder neu erstelltes Material zurück.
## resource_local_to_scene = false → GPU-seitig geteilt, kein erneutes Upload.
func get_material(color: Color, unshaded: bool = false) -> StandardMaterial3D:
	var key := "%s_%s" % [color.to_html(), str(unshaded)]
	if not materials.has(key):
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		if unshaded:
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.resource_local_to_scene = false  # GPU-seitig teilen
		materials[key] = mat
	return materials[key]

## Wie get_material(), aber mit prozeduraler Detail-Textur (ProceduralTextureFactory)
## statt reiner Flächenfarbe — "Natur ist auch nur Mathematik": Stein/Holz/Rinde/
## Moos/Gras/Sand/Kies/Erde bekommen Grain-Variation statt komplett flacher Fläche,
## ohne eine einzige Bilddatei. `color` tönt die Textur (StandardMaterial3D
## multipliziert albedo_color * albedo_texture), uv1_scale kachelt sie mehrfach
## über das Mesh. Unbekannte category fällt auf get_material() zurück (kein harter
## Fehler).
func get_textured_material(color: Color, category: String, unshaded: bool = false) -> StandardMaterial3D:
	var key := "tex_%s_%s_%s" % [category, color.to_html(), str(unshaded)]
	if not materials.has(key):
		var tex: ImageTexture
		match category:
			"stone":  tex = ProceduralTextureFactory.stone()
			"wood":   tex = ProceduralTextureFactory.wood()
			"grass":  tex = ProceduralTextureFactory.grass()
			"sand":   tex = ProceduralTextureFactory.sand()
			"gravel": tex = ProceduralTextureFactory.gravel()
			"dirt":   tex = ProceduralTextureFactory.dirt()
			"bark":   tex = ProceduralTextureFactory.bark()
			"moss":   tex = ProceduralTextureFactory.moss()
			"ore_iron":   tex = ProceduralTextureFactory.ore_iron()
			"ore_copper": tex = ProceduralTextureFactory.ore_copper()
			"ice":        tex = ProceduralTextureFactory.ice()
			"sulfur":     tex = ProceduralTextureFactory.sulfur()
			"wax":        tex = ProceduralTextureFactory.wax()
			"glass":      tex = ProceduralTextureFactory.glass()
			"charcoal":   tex = ProceduralTextureFactory.charcoal()
			_:
				AppLogger.log_warn(
					"MeshCache: unbekannte Textur-Kategorie '%s' — falle auf Flächenfarbe zurück." % category,
					LOG_CAT
				)
				return get_material(color, unshaded)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.albedo_texture = tex
		mat.uv1_scale = Vector3(2.0, 2.0, 2.0)
		mat.roughness = 0.9
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		if unshaded:
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.resource_local_to_scene = false  # GPU-seitig teilen
		materials[key] = mat
	return materials[key]

## Einmal gebauter, geteilter Shader für get_swaying_material() — Shader.new()
## ist teuer, das Kompilat aber pro Prozess identisch, also genau wie
## MeshCache.meshes/materials nur EINMAL bauen, danach an alle ShaderMaterial-
## Instanzen weiterreichen (jede ShaderMaterial trägt nur ihre eigenen
## Uniform-Werte, der kompilierte Shader-Code wird geteilt).
static var _sway_shader: Shader = null

## Wind-Sway für Baumkronen/Farn (docs/procedural-textures-and-weather-vfx.md,
## "Bekannte Grenzen" → "naheliegender nächster Schritt"): Vertex-Shader statt
## StandardMaterial3D, verschiebt Vertices mit positivem lokalem Y (siehe
## Shader-Kommentar) im Takt zweier überlagerter Sinuskurven aus TIME — exakt
## dasselbe Zwei-Sinus-Prinzip wie WindField (GDScript), hier aber eigenständig
## in GLSL, weil ein Shader keine GDScript-Klassen aufrufen kann (siehe bereits
## TerrainMeshBuilder-Kommentar zu grain_hash()). Ein Hash auf die Weltposition
## der jeweiligen MeshInstance3D gibt jedem Baum/Farn eine eigene Phasenlage,
## damit nicht der komplette Wald im Gleichtakt wedelt.
##
## category: wie bei get_textured_material() — leer lässt die Fläche ungetönt
## einfarbig (für Baumkronen, die bisher get_material() nutzten).
## sway_strength: skaliert die Auslenkung (kleines Farnblatt braucht weniger
## als eine große Baumkrone), reiner Uniform-Wert, kein neuer Shader nötig.
func get_swaying_material(color: Color, category: String = "", sway_strength: float = 1.0) -> ShaderMaterial:
	var key := "sway_%s_%s_%s" % [category, color.to_html(), str(sway_strength)]
	if not materials.has(key):
		if _sway_shader == null:
			_sway_shader = _build_sway_shader()
		var tex: Texture2D = null
		if category != "":
			match category:
				"stone":  tex = ProceduralTextureFactory.stone()
				"wood":   tex = ProceduralTextureFactory.wood()
				"grass":  tex = ProceduralTextureFactory.grass()
				"sand":   tex = ProceduralTextureFactory.sand()
				"gravel": tex = ProceduralTextureFactory.gravel()
				"dirt":   tex = ProceduralTextureFactory.dirt()
				"bark":   tex = ProceduralTextureFactory.bark()
				"moss":   tex = ProceduralTextureFactory.moss()
				_:
					AppLogger.log_warn(
						"MeshCache: unbekannte Textur-Kategorie '%s' in get_swaying_material() — bleibt ungetönt." % category,
						LOG_CAT
					)
		var mat := ShaderMaterial.new()
		mat.shader = _sway_shader
		mat.set_shader_parameter("albedo_color", color)
		mat.set_shader_parameter("use_texture", tex != null)
		if tex != null:
			mat.set_shader_parameter("albedo_tex", tex)
		mat.set_shader_parameter("sway_strength", sway_strength)
		mat.resource_local_to_scene = false  # GPU-seitig teilen, wie alle anderen Materials hier
		materials[key] = mat
	return materials[key]

## cull_disabled (Wunsch "Bäume ... Blätter"): flache Blatt-Karten-Quads (siehe
## _build_leaf_cluster()) sind einseitig — ohne das würde man beim Herumlaufen von hinten
## einfach durch sie hindurchsehen. Für die bisherigen Kugel-Kronen ist Backface-Culling
## unerheblich (geschlossene Form, Rückseite sowieso nie sichtbar), daher hier pauschal für
## den ganzen (geteilten) Shader statt nur für Karten-Materialien — kein zweiter Shader nötig.
## Wie get_swaying_material(), aber für Blatt-Karten (leaf_quad-Mesh, siehe
## _build_leaf_cluster()): braucht ProceduralTextureFactory.leaf_card(hue_seed, shape) statt
## einer der festen category-Texturen, deshalb ein eigener kleiner Wrapper statt
## get_swaying_material() um einen shape/hue_seed-Parameter zu erweitern (der für
## Stein/Holz/... keinen Sinn ergäbe). Nutzt denselben geteilten _sway_shader.
func get_leaf_material(color: Color, shape: int, hue_seed: int, sway_strength: float = 1.0) -> ShaderMaterial:
	var key := "leafmat_%s_%d_%d_%s" % [color.to_html(), shape, hue_seed, str(sway_strength)]
	if not materials.has(key):
		if _sway_shader == null:
			_sway_shader = _build_sway_shader()
		var mat := ShaderMaterial.new()
		mat.shader = _sway_shader
		mat.set_shader_parameter("albedo_color", color)
		mat.set_shader_parameter("use_texture", true)
		# 64 statt 48 (Wunsch "Blätter sehen nicht gut aus"): bei dichteren, näher an der Kamera
		# sichtbaren Clustern (siehe _leaf_cloud_offsets()) fiel die gröbere Auflösung als
		# weiche/unscharfe Kante auf — merklich schärfer für kaum mehr Speicher.
		mat.set_shader_parameter("albedo_tex", ProceduralTextureFactory.leaf_card(64, hue_seed, shape))
		mat.set_shader_parameter("sway_strength", sway_strength)
		mat.resource_local_to_scene = false
		materials[key] = mat
	return materials[key]

## Nah-LOD (siehe LOD_NEAR_DISTANCE-Kommentar): sichtbar bis LOD_NEAR_DISTANCE, blendet danach
## weich zur Fern-Variante über.
func _apply_near_lod(inst: GeometryInstance3D) -> void:
	inst.visibility_range_end = LOD_NEAR_DISTANCE
	inst.visibility_range_end_margin = LOD_FADE_MARGIN
	inst.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF

## Fern-LOD: unsichtbar bis LOD_NEAR_DISTANCE, blendet davor weich von der Nah-Variante über.
func _apply_far_lod(inst: GeometryInstance3D) -> void:
	inst.visibility_range_begin = LOD_NEAR_DISTANCE
	inst.visibility_range_begin_margin = LOD_FADE_MARGIN
	inst.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF

## Baut einen kleinen "Blatt-Cluster" aus mehreren Karten-Quads um `anchor` — die Nah-LOD-
## Entsprechung einer Kronen-Kugel (crown_md/crown_sm). BUGFIX (Wunsch "Blätter sehen nicht gut
## aus, alle Bäume sehen nah gleich aus"): vorher IMMER dieselben 6 fest verdrahteten Positionen/
## Rotationen für JEDEN Cluster jeder Art — Eiche/Weide/Ahorn unterschieden sich nah dran also
## wirklich nur durch Textur-Farbe/-Silhouette, nie durch die Kronen-STRUKTUR selbst, und 6 dünn
## verteilte Karten wirkten löchrig/karg statt wie eine volle Krone. Jetzt: _leaf_cloud_offsets()
## erzeugt die Karten-Positionen aus dem botanischen Goldenen-Winkel-Muster (Phyllotaxis — so
## ordnen echte Pflanzen Blätter/Samen an, siehe Sonnenblumenkern-Spirale), deterministisch aus
## `count`/`seed_salt` (KEIN Random-Objekt — Determinismus über alle Peers bleibt erhalten), mit
## `radius`/`height_spread`/`height_bias` PRO ART unterschiedlich (siehe Aufrufer in
## _build_deciduous_tree()/_build_scene_pine()) — die Krone bekommt dadurch pro Art eine eigene
## Silhouette/Dichte, nicht nur eine eigene Farbe.
## `stretch`: zusätzliche Non-Uniform-Skalierung pro Karte (z.B. Weide: schmaler + länger für
## einen lanzettlichen statt ovalen Umriss, ohne eine eigene Blattform zu brauchen).
func _leaf_cloud_offsets(count: int, radius: float, height_spread: float, height_bias: float, seed_salt: int) -> Array:
	var out: Array = []
	var golden_angle_deg := 137.50776
	for i in count:
		# sqrt(t) statt t: gleichmäßige FLÄCHENDICHTE statt gehäufter Punkte zur Mitte hin
		# (Standard-Trick der Sonnenblumenkern-Spirale, siehe Klassenkommentar).
		var t: float = (float(i) + 0.5) / float(count)
		var r: float = sqrt(t) * radius
		var theta_deg: float = float(i) * golden_angle_deg + float(seed_salt) * 47.0
		var theta: float = deg_to_rad(theta_deg)
		var x: float = cos(theta) * r
		var z: float = sin(theta) * r
		# Höhe: leichte Welle statt einer flachen Scheibe (volumetrischer Eindruck),
		# height_bias verschiebt den ganzen Cluster nach oben/unten (z.B. Weide: hängend).
		var y: float = sin(theta * 2.0 + float(i)) * height_spread * 0.5 + height_bias
		# Deterministischer Hash (dieselbe sin()-Technik wie TreeGrowthStage._hash()) für
		# Rotations-/Größen-Jitter — sieht "zufällig" aus, ist aber auf jedem Peer identisch.
		var h1: float = sin(float(i) * 12.9898 + float(seed_salt) * 78.233) * 43758.5453
		var h2: float = sin(float(i) * 39.346 + float(seed_salt) * 11.135) * 24634.6345
		var jitter1: float = h1 - floor(h1)
		var jitter2: float = h2 - floor(h2)
		var rot := Vector3(jitter2 * 40.0 - 20.0, theta_deg + 90.0 + jitter1 * 50.0 - 25.0, 0.0)
		var scale_jitter: float = 0.8 + 0.4 * jitter1
		out.append({"pos": Vector3(x, y, z), "rot": rot, "scale_jitter": scale_jitter})
	return out

func _build_leaf_cluster(
	anchor: Vector3, base_scale: float, color: Color, shape: int,
	hue_seed_base: int, sway_strength: float = 1.0, stretch: Vector3 = Vector3.ONE,
	card_count: int = 10, spread_radius: float = 0.26, height_spread: float = 0.2, height_bias: float = 0.0
) -> Node3D:
	var cluster := Node3D.new()
	cluster.position = anchor
	var offsets := _leaf_cloud_offsets(card_count, spread_radius, height_spread, height_bias, hue_seed_base)
	for i in offsets.size():
		var o: Dictionary = offsets[i]
		var card := MeshInstance3D.new()
		card.mesh = meshes["leaf_quad"]
		card.material_override = get_leaf_material(color, shape, hue_seed_base + i, sway_strength)
		card.position = (o["pos"] as Vector3) * base_scale
		card.rotation_degrees = o["rot"]
		card.scale = Vector3.ONE * base_scale * float(o["scale_jitter"]) * stretch
		_apply_near_lod(card)
		cluster.add_child(card)
	return cluster

## Basis für einen Ast entlang `dir` (muss nicht normalisiert sein): Y-Achse = Astrichtung
## (Länge steckt in ihrer Vektorlänge), X/Z = beliebige dazu orthogonale Achsen (Länge = Radius)
## — codiert Rotation UND nicht-uniforme Skalierung in einem Schritt, ohne `look_at()`/
## `rotation_degrees` und ohne eine zusätzliche `.scale`-Zuweisung. `branch_unit` liegt entlang
## lokal Y von -0.5..0.5 → mit dieser Basis plaziert an der Mittelpunkt-Position ergibt das genau
## den Zylinder von `start` bis `start + dir`.
func _branch_basis(dir: Vector3, radius: float) -> Basis:
	var yn: Vector3 = dir.normalized()
	var refv: Vector3 = Vector3.FORWARD if absf(yn.dot(Vector3.UP)) > 0.95 else Vector3.UP
	var xn: Vector3 = refv.cross(yn).normalized()
	var zn: Vector3 = xn.cross(yn).normalized()
	return Basis(xn * radius, dir, zn * radius)

## Baut einen Ast von einem Punkt auf der Stammoberfläche (Höhe `height_frac` * `trunk_height`,
## Richtung `azimuth_deg` um den Stamm) schräg nach außen/oben (`angle_deg` von der Senkrechten,
## 0° = stammparallel nach oben, 90° = waagrecht, >90° = leicht hängend/nickend wie bei
## Nadelbaum-Zweigen) und gibt die Astspitze (lokal zu `root`) zurück, für Krone/Nadelbüschel an
## dieser Stelle. Gemeinsame Geometrie-Quelle für Laubbäume (_build_deciduous_tree()) UND Tanne
## (_build_scene_pine()) — nur die Winkel/Längen pro Aufrufer unterscheiden sich.
func _add_limb(
	root: Node3D, trunk_radius: float, trunk_height: float,
	height_frac: float, angle_deg: float, azimuth_deg: float,
	length: float, radius: float, bark_mat: Material
) -> Vector3:
	var az: float = deg_to_rad(azimuth_deg)
	var horiz: Vector3 = Vector3(cos(az), 0.0, sin(az))
	var start: Vector3 = Vector3(0.0, height_frac * trunk_height, 0.0) + horiz * trunk_radius * 0.6
	var ang: float = deg_to_rad(angle_deg)
	var dir: Vector3 = (Vector3.UP * cos(ang) + horiz * sin(ang)).normalized()
	var tip: Vector3 = start + dir * length

	var branch := MeshInstance3D.new()
	branch.mesh = meshes["branch_unit"]
	branch.material_override = bark_mat
	branch.transform = Transform3D(_branch_basis(dir * length, radius), (start + tip) * 0.5)
	root.add_child(branch)
	return tip

## Gemeinsamer Bauplan für Laubbäume (Wunsch "Stamm/Äste/Zweige" + "nicht einer für alle
## gleich"): die Artabgrenzung steckt komplett in `cfg` (Stammform/-farbe, pro Ast Winkel/Länge/
## Dicke/Kronenfarbe/-form/-streckung — siehe _build_scene_oak() usw. für die Werte je Art),
## diese Funktion ist reine Mechanik (Stamm → je Ast ein Ast-Zylinder → an dessen Spitze eine
## Krone aus Fern-Kugel + Nah-Karten-Cluster) und für alle drei Laubbaumarten identisch.
## `stage` (siehe TreeStage-Kommentar) skaliert Stamm/Äste/Kronen einheitlich und kürzt die
## Astliste auf die ersten `TREE_STAGE_LIMB_KEEP[stage]` Einträge — ein Sapling ist derselbe
## Bauplan mit weniger/kürzeren Ästen, kein eigenes Modell.
func _build_deciduous_tree(tree_name: String, cfg: Dictionary, stage: int) -> PackedScene:
	var root := Node3D.new()
	root.name = tree_name

	var s: float = TREE_STAGE_SCALE[stage]
	var limbs: Array = cfg["limbs"]
	var keep: int = mini(int(TREE_STAGE_LIMB_KEEP[stage]), limbs.size())
	var sway: float = float(cfg.get("sway_strength", 1.0))
	var trunk_aspect: Vector3 = cfg.get("trunk_aspect", Vector3.ONE)

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes[cfg["trunk_mesh"]]
	trunk.set_surface_override_material(0, get_textured_material(cfg["bark_color"], "bark"))
	var trunk_h: float = 2.0 * s * trunk_aspect.y   # 2.0 = Basishöhe aller trunk_*-Meshes
	trunk.position = Vector3(0.0, trunk_h * 0.5, 0.0)
	trunk.scale = Vector3(s, s, s) * trunk_aspect
	root.add_child(trunk)

	var bark_mat := get_textured_material((cfg["bark_color"] as Color).darkened(0.12), "bark")
	var trunk_radius: float = float(cfg["trunk_radius"]) * s

	for i in keep:
		var limb: Dictionary = limbs[i]
		var group := Node3D.new()

		var tip: Vector3 = _add_limb(
			group, trunk_radius, trunk_h,
			float(limb["height_frac"]), float(limb["angle"]), float(limb["azimuth"]),
			float(limb["length"]) * s, float(limb["radius"]) * s, bark_mat)
		tip.y -= float(limb.get("droop", 0.0)) * s   # nur die Krone hängt tiefer, der Ast nicht

		var crown_scale: float = float(limb["crown_scale"]) * s
		var crown_color: Color = limb["crown_color"]
		var crown_shape: int = limb["crown_shape"]
		var crown_stretch: Vector3 = limb.get("crown_stretch", Vector3.ONE)

		var far_sphere := MeshInstance3D.new()
		far_sphere.mesh = meshes["crown_unit"]
		far_sphere.set_surface_override_material(0, get_swaying_material(crown_color, "", sway))
		far_sphere.position = tip
		far_sphere.scale = Vector3.ONE * crown_scale
		_apply_far_lod(far_sphere)
		group.add_child(far_sphere)

		# Wunsch "alle Bäume sehen nah gleich aus": Cluster-DICHTE/-FORM kommt jetzt pro Art aus
		# `limb` (siehe cluster_count/cluster_radius/... in _build_scene_oak() usw.) statt aus
		# global gleichen Defaults — das unterscheidet Kronen strukturell, nicht nur farblich.
		group.add_child(_build_leaf_cluster(
			tip, crown_scale, crown_color, crown_shape,
			int(limb.get("hue_seed", i * 6)), sway, crown_stretch,
			int(limb.get("cluster_count", 10)), float(limb.get("cluster_radius", 0.26)),
			float(limb.get("cluster_height_spread", 0.2)), float(limb.get("cluster_height_bias", 0.0))))

		root.add_child(group)

	return _pack_scene(root)

static func _build_sway_shader() -> Shader:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx, cull_disabled;

uniform vec4 albedo_color : source_color = vec4(1.0);
uniform sampler2D albedo_tex : hint_default_white;
uniform bool use_texture = false;
uniform float sway_strength : hint_range(0.0, 2.0) = 1.0;
uniform float roughness_val : hint_range(0.0, 1.0) = 0.9;

// Gleiche Hash-Familie wie ProceduralTextureFactory._hash2() / TerrainMeshBuilder.grain_hash()
// -- eigenständig hier, weil ein Shader keine GDScript-Klassen aufrufen kann.
float sway_hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

void vertex() {
	// Weltposition des Objekt-Pivots (nicht pro Vertex) -> stabile Phase je
	// MeshInstance3D, unterschiedlich je Baum/Farn statt synchronem Wedeln.
	vec3 world_origin = (MODEL_MATRIX * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
	float phase = sway_hash(world_origin.xz) * 6.2831853;
	float t = TIME;
	float wind = sin(t * 0.9 + phase) * 0.7 + sin(t * 2.3 + phase * 1.7) * 0.3;
	float sway = cos(t * 0.7 + phase);
	// Nur der obere, von der Basis wegzeigende Teil des Meshes schwingt
	// spürbar (Ast/Blattspitze) -- die Basis (VERTEX.y <= 0) bleibt ruhig.
	float lift = max(VERTEX.y, 0.0);
	VERTEX.x += wind * lift * 0.10 * sway_strength;
	VERTEX.z += sway * lift * 0.08 * sway_strength;
}

void fragment() {
	vec4 tex_color = use_texture ? texture(albedo_tex, UV * 2.0) : vec4(1.0);
	ALBEDO = clamp((albedo_color * tex_color).rgb, 0.0, 1.0);
	ROUGHNESS = roughness_val;
	METALLIC = 0.0;
}
"""
	return shader

func get_mesh(key: String) -> ArrayMesh:
	return meshes.get(key)

## Instanziiert eine komplexe Szene (Baum, Kaktus, Farn etc.).
## Gibt Node3D.new() zurück wenn der Key nicht existiert — nie null.
func instantiate_scene(key: String) -> Node3D:
	var scene: PackedScene = scenes.get(key)
	if scene == null:
		AppLogger.log_error("MeshCache: Szene '%s' nicht gefunden." % key, LOG_CAT)
		return Node3D.new()
	return scene.instantiate() as Node3D

# ─────────────────────────────────────────────────────────────────────────────
# Build-Methoden (einmalig beim Session-Boot)
# ─────────────────────────────────────────────────────────────────────────────

func _build_materials() -> void:
	# Alle Biom-/Objekt-Farben vorab bauen
	var presets := {
		"trunk_oak":      Color(0.4,  0.25, 0.10),
		"trunk_pine":     Color(0.35, 0.20, 0.08),
		"leaves_oak":     Color(0.15, 0.50, 0.10),
		"leaves_pine":    Color(0.10, 0.40, 0.08),
		"leaves_snow":    Color(0.95, 0.97, 1.00),
		"rock_forest":    Color(0.45, 0.40, 0.35),
		"rock_desert":    Color(0.75, 0.60, 0.35),
		"cactus":         Color(0.20, 0.55, 0.15),
		"fern":           Color(0.20, 0.60, 0.15),
		"mushroom_red":   Color(0.85, 0.10, 0.10),
		"mushroom_brown": Color(0.50, 0.30, 0.10),
		"bar_hp":         Color(0.10, 0.85, 0.10),
		"bar_bg":         Color(0.15, 0.15, 0.15, 0.80),
		"fallen_log":     Color(0.35, 0.22, 0.09),
		"animal_body":    Color(0.60, 0.50, 0.35),
		"animal_head":    Color(0.55, 0.45, 0.30),
	}
	for key in presets:
		get_material(presets[key])

func _build_simple_meshes() -> void:
	# Zylinder-Varianten für Baumstämme
	for r_pair in [["trunk_sm", 0.12, 0.18], ["trunk_md", 0.15, 0.22], ["trunk_lg", 0.18, 0.28]]:
		var m := CylinderMesh.new()
		m.top_radius    = r_pair[1]
		m.bottom_radius = r_pair[2]
		m.height        = 2.0
		meshes[r_pair[0]] = _to_array_mesh(m)

	# Kugeln für Baumkronen (Fern-LOD, siehe LOD_NEAR_DISTANCE-Kommentar)
	for s_pair in [["crown_sm", 0.8], ["crown_md", 1.1], ["crown_lg", 1.4]]:
		var m := SphereMesh.new()
		m.radius = s_pair[1]
		m.height = s_pair[1] * 2.0
		meshes[s_pair[0]] = _to_array_mesh(m)

	# Ein einziges geteiltes Karten-Quad für alle Blatt-Cluster (Nah-LOD) — Größe/Form kommt
	# über Node-Skalierung pro Karte (siehe _build_leaf_cluster()), nicht über eigene Meshes.
	var leaf_quad_mesh := QuadMesh.new()
	leaf_quad_mesh.size = Vector2(0.4, 0.5)
	meshes["leaf_quad"] = _to_array_mesh(leaf_quad_mesh)

	# Einheits-Ast (Wunsch "wie Äste/Zweige wachsen"): EIN geteiltes Mesh für alle Äste aller
	# Baumarten/-stadien, wie rock_unit/trunk_* — die tatsächliche Länge/Dicke je Ast kommt aus
	# der Basis, mit der die Instanz plaziert wird (siehe _branch_basis()), nicht aus eigenen
	# CylinderMesh-Objekten pro Ast. Leichte Verjüngung (top_radius < bottom_radius) reicht für
	# alle Astformen, die feinere Formsprache steckt in Länge/Winkel/Dicke pro Art (siehe
	# Spezies-cfg in _build_deciduous_tree()).
	var branch_unit := CylinderMesh.new()
	branch_unit.top_radius    = 0.7
	branch_unit.bottom_radius = 1.0
	branch_unit.height        = 1.0
	branch_unit.radial_segments = 6   # dünne Äste — grobe Segmentierung reicht, spart Dreiecke
	meshes["branch_unit"] = _to_array_mesh(branch_unit)

	# Einheits-Krone (Radius 1) fürs Fern-LOD der Baumkronen — ersetzt die früheren festen
	# crown_sm/md/lg (bleiben registriert, falls noch irgendwo referenziert, werden aber von den
	# Baum-Buildern nicht mehr benutzt): eine einzige Kugel + Node-Skalierung pro Astspitze statt
	# dreier fester Größen, damit jede Art/jedes Stadium seine eigene Kronengröße bekommt.
	var crown_unit := SphereMesh.new()
	crown_unit.radius = 1.0
	crown_unit.height = 2.0
	meshes["crown_unit"] = _to_array_mesh(crown_unit)

	# Kegel für Tanne (CylinderMesh mit top_radius = 0)
	for c_pair in [["pine_cone_0", 1.2, 0.8], ["pine_cone_1", 1.0, 0.65], ["pine_cone_2", 0.75, 0.5]]:
		var m := CylinderMesh.new()
		m.top_radius    = 0.0
		m.bottom_radius = c_pair[1]
		m.height        = c_pair[2]
		meshes[c_pair[0]] = _to_array_mesh(m)

	# Kaktus-Stamm und -Arme
	var kaktus_stamm := CylinderMesh.new()
	kaktus_stamm.top_radius    = 0.18
	kaktus_stamm.bottom_radius = 0.20
	kaktus_stamm.height        = 1.6
	meshes["cactus_trunk"] = _to_array_mesh(kaktus_stamm)

	var kaktus_arm := CylinderMesh.new()
	kaktus_arm.top_radius    = 0.10
	kaktus_arm.bottom_radius = 0.12
	kaktus_arm.height        = 0.6
	meshes["cactus_arm"] = _to_array_mesh(kaktus_arm)

	# Farn-Blatt (abgeflachte Kugel)
	var fern_leaf := SphereMesh.new()
	fern_leaf.radius = 0.4
	fern_leaf.height = 0.15
	meshes["fern_leaf"] = _to_array_mesh(fern_leaf)

	# Gefällter Baumstamm (liegender Zylinder — Rotation beim Instanziieren)
	var log := CylinderMesh.new()
	log.top_radius    = 0.22
	log.bottom_radius = 0.25
	log.height        = 2.4
	meshes["fallen_log"] = _to_array_mesh(log)

	# Felsblock-Basis — Einheitskugel, pro Instanz non-uniform skaliert
	var boulder := SphereMesh.new()
	boulder.radius = 1.0
	boulder.height = 2.0
	meshes["rock_unit"] = _to_array_mesh(boulder)

	# Pilz-Teile — geteilt über alle Pilz-Typen, nur Material variiert
	var shroom_stem := CylinderMesh.new()
	shroom_stem.top_radius    = 0.04
	shroom_stem.bottom_radius = 0.06
	shroom_stem.height        = 0.18
	meshes["mushroom_stem"] = _to_array_mesh(shroom_stem)

	var shroom_cap := SphereMesh.new()
	shroom_cap.radius = 0.14
	shroom_cap.height = 0.14 * 0.55  # abgeflacht
	meshes["mushroom_cap"] = _to_array_mesh(shroom_cap)

	var shroom_dot := SphereMesh.new()
	shroom_dot.radius = 0.025
	shroom_dot.height = 0.05
	meshes["mushroom_dot"] = _to_array_mesh(shroom_dot)

	# Schnee-Kappen für Tannen — kleiner als die Blatt-Kegel, sitzen obendrauf
	for c_pair in [["snow_cap_0", 0.9, 0.35], ["snow_cap_1", 0.7, 0.30], ["snow_cap_2", 0.5, 0.25]]:
		var m := CylinderMesh.new()
		m.top_radius    = 0.0
		m.bottom_radius = c_pair[1]
		m.height        = c_pair[2]
		meshes[c_pair[0]] = _to_array_mesh(m)

func _build_tree_scenes() -> void:
	# Wunsch "Bäume in verschiedenen Stadien darstellen": jede Art registriert zusätzlich zur
	# unveränderten "tree_<art>"-Schlüssel (= MATURE, rückwärtskompatibel — Factory3D/bestehende
	# Aufrufer ohne Stadium-Wissen bekommen weiterhin den ausgewachsenen Baum) zwei weitere
	# Schlüssel "_young"/"_sapling". Auswahl WELCHES Stadium ein Baum bekommt: TreeGrowthStage.gd
	# (deterministisch aus der Weltposition), aufgerufen von OakTree/WillowTree/MapleTree/
	# PineTree._build_visuals() — hier wird nur die volle Palette gebaut/gecacht.
	scenes["tree_oak"]            = _build_scene_oak(TreeStage.MATURE)
	scenes["tree_oak_young"]      = _build_scene_oak(TreeStage.YOUNG)
	scenes["tree_oak_sapling"]    = _build_scene_oak(TreeStage.SAPLING)
	# BUGFIX (2026-09-20, "keine Farbunterschiede bei Baumarten"): tree_willow/
	# tree_maple fehlten komplett im Cache — Factory3D.create_simple_tree()
	# fiel für ALLE drei Laubbaumtypen (Oak/Willow/Maple) auf "tree_oak"
	# zurück, sichtbar identisch trotz unterschiedlicher Baumart.
	scenes["tree_willow"]         = _build_scene_willow(TreeStage.MATURE)
	scenes["tree_willow_young"]   = _build_scene_willow(TreeStage.YOUNG)
	scenes["tree_willow_sapling"] = _build_scene_willow(TreeStage.SAPLING)
	scenes["tree_maple"]          = _build_scene_maple(TreeStage.MATURE)
	scenes["tree_maple_young"]    = _build_scene_maple(TreeStage.YOUNG)
	scenes["tree_maple_sapling"]  = _build_scene_maple(TreeStage.SAPLING)
	scenes["tree_pine"]                = _build_scene_pine(false, TreeStage.MATURE)
	scenes["tree_pine_young"]          = _build_scene_pine(false, TreeStage.YOUNG)
	scenes["tree_pine_sapling"]        = _build_scene_pine(false, TreeStage.SAPLING)
	scenes["tree_pine_snow"]           = _build_scene_pine(true, TreeStage.MATURE)
	scenes["tree_pine_snow_young"]     = _build_scene_pine(true, TreeStage.YOUNG)
	scenes["tree_pine_snow_sapling"]   = _build_scene_pine(true, TreeStage.SAPLING)
	scenes["tree_fallen_forest"] = _build_scene_fallen("forest")
	scenes["tree_fallen_desert"] = _build_scene_fallen("desert")
	scenes["cactus"]            = _build_scene_cactus()
	scenes["fern"]              = _build_scene_fern()

func _build_mushroom_scenes() -> void:
	scenes["mushroom_red"]    = _build_scene_mushroom("red")
	scenes["mushroom_brown"]  = _build_scene_mushroom("brown")
	scenes["mushroom_orange"] = _build_scene_mushroom("orange")

func _build_scene_mushroom(mushroom_type: String) -> PackedScene:
	var root := Node3D.new()
	root.name = "Mushroom_%s" % mushroom_type.capitalize()

	var stem := MeshInstance3D.new()
	stem.mesh = meshes["mushroom_stem"]
	stem.set_surface_override_material(0, get_material(Color(0.85, 0.80, 0.72)))
	stem.position.y = 0.09
	root.add_child(stem)

	var cap_color: Color
	match mushroom_type:
		"red":    cap_color = Color(0.85, 0.15, 0.10)
		"orange": cap_color = Color(0.90, 0.55, 0.10)
		_:        cap_color = Color(0.55, 0.35, 0.18)

	var cap := MeshInstance3D.new()
	cap.mesh = meshes["mushroom_cap"]
	cap.set_surface_override_material(0, get_material(cap_color))
	cap.position.y = 0.22
	root.add_child(cap)

	if mushroom_type == "red":
		var dot_material := get_material(Color(1.0, 1.0, 1.0))
		for i in range(3):
			var dot := MeshInstance3D.new()
			dot.mesh = meshes["mushroom_dot"]
			dot.set_surface_override_material(0, dot_material)
			var angle := (TAU / 3.0) * i
			dot.position = Vector3(cos(angle) * 0.07, 0.24, sin(angle) * 0.07)
			root.add_child(dot)

	return _pack_scene(root)

func _build_animal_meshes() -> void:
	for a in [["animal_body_sm", Vector3(0.3, 0.5, 0.3)],
			  ["animal_body_md", Vector3(0.5, 0.7, 0.5)],
			  ["animal_body_lg", Vector3(0.6, 0.8, 0.6)]]:
		var m := BoxMesh.new()
		m.size = a[1]
		meshes[a[0]] = _to_array_mesh(m)

	# Tier-Kopf (kleinere Box)
	var head := BoxMesh.new()
	head.size = Vector3(0.28, 0.28, 0.28)
	meshes["animal_head"] = _to_array_mesh(head)

func _build_bar_mesh() -> void:
	# HP-Bar Hintergrund + Füllung (zwei schmale Quads)
	var bg := QuadMesh.new()
	bg.size = Vector2(1.2, 0.20)
	meshes["bar_bg"] = _to_array_mesh(bg)
	var fg := QuadMesh.new()
	fg.size = Vector2(1.1, 0.15)
	meshes["bar_fg"] = _to_array_mesh(fg)

# ─────────────────────────────────────────────────────────────────────────────
# Szenen-Builder (erstellen Node-Hierarchie, verpacken als PackedScene)
# ─────────────────────────────────────────────────────────────────────────────

## Eiche — dicker Stamm, zwei kurze, weit abgewinkelte Scharnier-Äste (58°/50° von der
## Senkrechten — deutlich breiter abgewinkelt als Ahorn) tragen die charakteristisch
## fiederig-gelappte (LOBED) Krone. Siehe _build_deciduous_tree()-Kommentar für den Bauplan.
func _build_scene_oak(stage: int = TreeStage.MATURE) -> PackedScene:
	var cfg := {
		"trunk_mesh": "trunk_md", "trunk_radius": 0.22,
		"bark_color": Color(0.4, 0.25, 0.10),
		"limbs": [
			{"height_frac": 0.5, "angle": 58.0, "azimuth": 30.0, "length": 1.15, "radius": 0.075,
			 "crown_scale": 1.1, "crown_color": Color(0.15, 0.50, 0.10),
			 "crown_shape": ProceduralTextureFactory.LeafShape.LOBED, "hue_seed": 0,
			 # Dicht + rundlich + leicht domförmig (height_bias > 0) — Wunsch "Bäume sehen nah
			 # gleich aus": das eigentliche STRUKTUR-Merkmal der Eiche, nicht nur ihre Farbe.
			 "cluster_count": 16, "cluster_radius": 0.34, "cluster_height_spread": 0.26, "cluster_height_bias": 0.06},
			{"height_frac": 0.68, "angle": 50.0, "azimuth": 205.0, "length": 0.95, "radius": 0.06,
			 "crown_scale": 0.8, "crown_color": Color(0.12, 0.45, 0.08),
			 "crown_shape": ProceduralTextureFactory.LeafShape.LOBED, "hue_seed": 6,
			 "cluster_count": 12, "cluster_radius": 0.26, "cluster_height_spread": 0.22, "cluster_height_bias": 0.04},
		],
	}
	return _build_deciduous_tree("Tree_Oak", cfg, stage)

## Weide — schlanker, hellerer Stamm (trunk_aspect schmaler+länger als der Grundzylinder);
## DREI dünne, flach abgewinkelte Äste (30-40°, kaum abgespreizt — anders als Eiches breite
## Scharniere) mit `droop`: die Krone hängt spürbar UNTER der Astspitze statt direkt daran zu
## sitzen — billiger Stand-in für den hängenden Weiden-Habitus, ohne gebogene Ast-Geometrie zu
## brauchen. ELLIPSE-Blattform, aber stark lang gestreckt (crown_stretch) für den lanzettlichen
## Umriss echter Weidenblätter.
func _build_scene_willow(stage: int = TreeStage.MATURE) -> PackedScene:
	var stretch := Vector3(0.6, 1.5, 0.6)
	var cfg := {
		"trunk_mesh": "trunk_sm", "trunk_radius": 0.18,
		"trunk_aspect": Vector3(0.85, 1.1, 0.85),
		"bark_color": Color(0.45, 0.38, 0.22),
		"sway_strength": 1.3,
		"limbs": [
			{"height_frac": 0.55, "angle": 35.0, "azimuth": 10.0, "length": 0.95, "radius": 0.05,
			 "droop": 0.4, "crown_scale": 0.85, "crown_color": Color(0.55, 0.62, 0.22),
			 "crown_shape": ProceduralTextureFactory.LeafShape.ELLIPSE, "crown_stretch": stretch, "hue_seed": 20,
			 # Schmal + nach unten kaskadierend (negatives height_bias, großer height_spread)
			 # statt eines runden Balls — der strukturelle Weiden-Unterschied zur Eiche.
			 "cluster_count": 9, "cluster_radius": 0.16, "cluster_height_spread": 0.4, "cluster_height_bias": -0.18},
			{"height_frac": 0.72, "angle": 30.0, "azimuth": 140.0, "length": 0.8, "radius": 0.045,
			 "droop": 0.35, "crown_scale": 0.65, "crown_color": Color(0.50, 0.58, 0.20),
			 "crown_shape": ProceduralTextureFactory.LeafShape.ELLIPSE, "crown_stretch": stretch, "hue_seed": 26,
			 "cluster_count": 8, "cluster_radius": 0.13, "cluster_height_spread": 0.34, "cluster_height_bias": -0.15},
			{"height_frac": 0.85, "angle": 40.0, "azimuth": 260.0, "length": 0.65, "radius": 0.04,
			 "droop": 0.3, "crown_scale": 0.55, "crown_color": Color(0.52, 0.60, 0.21),
			 "crown_shape": ProceduralTextureFactory.LeafShape.ELLIPSE, "crown_stretch": stretch, "hue_seed": 30,
			 "cluster_count": 7, "cluster_radius": 0.11, "cluster_height_spread": 0.3, "cluster_height_bias": -0.12},
		],
	}
	return _build_deciduous_tree("Tree_Willow", cfg, stage)

## Ahorn — dickster Stamm, zwei mäßig aufwärts geneigte Äste (38°/35° — steiler/kompakter als
## Eiche) tragen die handförmig gelappte (PALMATE, 5-strahliger Stern) Krone in kräftigen
## Herbstfarben.
func _build_scene_maple(stage: int = TreeStage.MATURE) -> PackedScene:
	var cfg := {
		"trunk_mesh": "trunk_lg", "trunk_radius": 0.28,
		"bark_color": Color(0.32, 0.18, 0.08),
		"limbs": [
			{"height_frac": 0.55, "angle": 38.0, "azimuth": 50.0, "length": 1.25, "radius": 0.08,
			 "crown_scale": 1.3, "crown_color": Color(0.75, 0.30, 0.08),
			 "crown_shape": ProceduralTextureFactory.LeafShape.PALMATE, "hue_seed": 40,
			 # Weniger, dafür GRÖSSERE Karten (großes Ahornblatt) statt vieler kleiner — dritter
			 # struktureller Fingerabdruck neben Eiche (dicht/klein) und Weide (schmal/hängend).
			 "cluster_count": 10, "cluster_radius": 0.30, "cluster_height_spread": 0.22, "cluster_height_bias": 0.05},
			{"height_frac": 0.72, "angle": 35.0, "azimuth": 220.0, "length": 1.05, "radius": 0.065,
			 "crown_scale": 1.0, "crown_color": Color(0.80, 0.45, 0.05),
			 "crown_shape": ProceduralTextureFactory.LeafShape.PALMATE, "hue_seed": 46,
			 "cluster_count": 8, "cluster_radius": 0.24, "cluster_height_spread": 0.18, "cluster_height_bias": 0.03},
		],
	}
	return _build_deciduous_tree("Tree_Maple", cfg, stage)

## Tanne — Wunsch "sieht nicht aus wie eine echte Tanne, nachziehen": bisher drei gestapelte
## massive Kegel auf einem kaum sichtbaren Stumpf-Stamm (kein Wirtel, kein Leittrieb — die
## Kritik war berechtigt). Jetzt monopodial wie ein echter Nadelbaum: EIN durchgehender, hoher
## Leittrieb (Stamm gestreckt statt versteckt) mit regelmäßigen Astkränzen ("Wirteln") aus
## dünnen, leicht nickenden Ast-Stummeln (>90°, siehe _add_limb()-Kommentar), die nach oben
## kürzer werden, je Astspitze ein kleines, dichtes Nadelbüschel (NEEDLE-Silhouette, wenige
## Karten statt der vollen Laubbaum-Streuung) statt einer runden Kugel, plus ein Spitzen-Büschel
## statt eines weiteren Astes am oberen Stammende. Die alten drei Kegel bleiben unverändert als
## billiges Fern-LOD (auf Distanz nicht von einer echten Wirtel-Struktur zu unterscheiden).
func _build_scene_pine(snow: bool, stage: int = TreeStage.MATURE) -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Pine" + ("_Snow" if snow else "")

	var s: float = TREE_STAGE_SCALE[stage]
	var trunk_h: float = 2.0 * 1.6 * s      # 1.6 = Streckfaktor für den hohen, geraden Leittrieb
	var trunk_radius: float = 0.16 * s      # ~Mittel aus trunk_sm top/bottom (0.12/0.18)

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_sm"]
	trunk.set_surface_override_material(0, get_textured_material(Color(0.35, 0.20, 0.08), "bark"))
	trunk.position = Vector3(0.0, trunk_h * 0.5, 0.0)
	trunk.scale = Vector3(0.8 * s, 1.6 * s, 0.8 * s)
	root.add_child(trunk)

	# Fern-LOD: die alten drei gestapelten Kegel, unverändert (siehe Funktionskommentar) —
	# jetzt auch mit _apply_far_lod() UND Stage-Skalierung, sonst wäre ein Sapling von weitem
	# wieder ein ausgewachsener Baum.
	var cone_offsets: Array = [[0, 0.6], [1, 1.1], [2, 1.55]]
	var leaf_color := get_swaying_material(
		Color(0.10, 0.40, 0.08) if not snow else Color(0.95, 0.97, 1.0), "", 0.6
	)
	var snow_material := get_swaying_material(Color(0.95, 0.97, 1.00), "", 0.6)
	for pair in cone_offsets:
		var cone := MeshInstance3D.new()
		cone.mesh = meshes["pine_cone_%d" % pair[0]]
		cone.set_surface_override_material(0, leaf_color)
		cone.position = Vector3(0.0, pair[1] * s, 0.0)
		cone.scale = Vector3.ONE * s
		_apply_far_lod(cone)
		root.add_child(cone)

		if snow:
			var snow_cone := MeshInstance3D.new()
			snow_cone.mesh = meshes["snow_cap_%d" % pair[0]]
			snow_cone.set_surface_override_material(0, snow_material)
			snow_cone.position = Vector3(0.0, (pair[1] + 0.2) * s, 0.0)
			snow_cone.scale = Vector3.ONE * s
			_apply_far_lod(snow_cone)
			root.add_child(snow_cone)

	# Nah-LOD: echte Astkränze statt Kegel (siehe Funktionskommentar). Anzahl der Wirtel kommt
	# aus PINE_STAGE_TIERS[stage] — ein Sapling hat noch KEINEN Wirtel (nur das Spitzenbüschel
	# unten), ein Jungbaum die untersten zwei.
	var needle_color := Color(0.08, 0.28, 0.12)
	var bark_mat := get_textured_material(Color(0.30, 0.17, 0.07), "bark")
	var tiers: Array = [
		{"height_frac": 0.16, "length": 0.55, "radius": 0.03, "hue": 60},
		{"height_frac": 0.38, "length": 0.46, "radius": 0.026, "hue": 64},
		{"height_frac": 0.60, "length": 0.36, "radius": 0.022, "hue": 68},
		{"height_frac": 0.80, "length": 0.26, "radius": 0.018, "hue": 72},
	]
	var tier_count: int = mini(int(PINE_STAGE_TIERS[stage]), tiers.size())
	var branches_per_tier := 5

	for t in tier_count:
		var tier: Dictionary = tiers[t]
		var tier_group := Node3D.new()
		var azimuth_offset: float = float(t) * 25.0   # gegen einen zu mechanischen Look versetzt
		for b in branches_per_tier:
			var az: float = azimuth_offset + 360.0 * float(b) / float(branches_per_tier)
			var tip: Vector3 = _add_limb(
				tier_group, trunk_radius, trunk_h,
				float(tier["height_frac"]), 95.0, az,
				float(tier["length"]) * s, float(tier["radius"]) * s, bark_mat)
			# Klein + eng (spread_radius/height_spread) statt der breiten Laubbaum-Streuung —
			# ein dichtes Nadelbüschel, keine kleine Kugelkrone.
			tier_group.add_child(_build_leaf_cluster(
				tip, 0.35 * s, needle_color, ProceduralTextureFactory.LeafShape.NEEDLE,
				int(tier["hue"]) + b, 0.6, Vector3.ONE, 4, 0.12, 0.08, 0.0))

		if snow:
			# Ein flacher weißer Schneefleck pro Wirtel statt pro Ast — genug für den Eindruck,
			# ohne die Kinderzahl unnötig aufzublähen (siehe
			# test_pine_tree_with_snow_has_more_children(), das nur mehr statt weniger prüft).
			var dab := MeshInstance3D.new()
			dab.mesh = meshes["leaf_quad"]
			dab.material_override = get_material(Color(0.97, 0.98, 1.0))
			dab.position = Vector3(0.0, float(tier["height_frac"]) * trunk_h + 0.05 * s, 0.05 * s)
			dab.rotation_degrees = Vector3(-80.0, 0.0, 0.0)
			dab.scale = Vector3.ONE * (0.35 * s)
			_apply_near_lod(dab)
			tier_group.add_child(dab)

		root.add_child(tier_group)

	# Spitzen-Büschel: kleiner Nadel-Tuft direkt am oberen Stammende (Leittrieb) statt eines
	# weiteren Astes — echte Nadelbäume laufen oben spitz aus.
	root.add_child(_build_leaf_cluster(
		Vector3(0.0, trunk_h, 0.0), 0.3 * s, needle_color,
		ProceduralTextureFactory.LeafShape.NEEDLE, 80, 0.6, Vector3.ONE, 4, 0.1, 0.1, 0.05))

	return _pack_scene(root)

func _build_scene_fallen(biome: String) -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Fallen_%s" % biome.capitalize()

	var log := MeshInstance3D.new()
	log.mesh = meshes["fallen_log"]
	# Waldboden-Stämme moosen an (feucht, im Schatten liegend), Wüsten-Totholz
	# bleibt trocken/borkig — gleiche Mesh, unterschiedliche Oberfläche je Biom.
	var log_category: String = "moss" if biome == "forest" else "bark"
	log.set_surface_override_material(0, get_textured_material(Color(0.35, 0.22, 0.09), log_category))
	# Liegend: 90° um Z-Achse kippen
	log.rotation_degrees = Vector3(0.0, 0.0, 90.0)
	root.add_child(log)

	return _pack_scene(root)

func _build_scene_cactus() -> PackedScene:
	var root := Node3D.new()
	root.name = "Cactus"

	var mat := get_material(Color(0.20, 0.55, 0.15))

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["cactus_trunk"]
	trunk.set_surface_override_material(0, mat)
	trunk.position = Vector3(0.0, 0.8, 0.0)
	root.add_child(trunk)

	# Linker Arm
	var arm_l := MeshInstance3D.new()
	arm_l.mesh = meshes["cactus_arm"]
	arm_l.set_surface_override_material(0, mat)
	arm_l.rotation_degrees = Vector3(0.0, 0.0, 90.0)
	arm_l.position = Vector3(-0.38, 1.0, 0.0)
	root.add_child(arm_l)

	# Rechter Arm
	var arm_r := MeshInstance3D.new()
	arm_r.mesh = meshes["cactus_arm"]
	arm_r.set_surface_override_material(0, mat)
	arm_r.rotation_degrees = Vector3(0.0, 0.0, -90.0)
	arm_r.position = Vector3(0.38, 0.85, 0.0)
	root.add_child(arm_r)

	return _pack_scene(root)

func _build_scene_fern() -> PackedScene:
	var root := Node3D.new()
	root.name = "Fern"

	# Farn schwingt stärker als Baumkronen (leichtes Blattwerk, kein Holzkern) —
	# höherer sway_strength als der Krone-Default.
	var mat := get_swaying_material(Color(0.20, 0.60, 0.15), "grass", 1.6)

	# 4 Blätter radial angeordnet
	var leaf_positions: Array = [
		[Vector3( 0.3, 0.1,  0.0), Vector3(-30.0, 0.0, 0.0)],
		[Vector3(-0.3, 0.1,  0.0), Vector3(-30.0, 180.0, 0.0)],
		[Vector3( 0.0, 0.1,  0.3), Vector3(-30.0, 90.0, 0.0)],
		[Vector3( 0.0, 0.1, -0.3), Vector3(-30.0, -90.0, 0.0)],
	]
	for lp in leaf_positions:
		var leaf := MeshInstance3D.new()
		leaf.mesh = meshes["fern_leaf"]
		leaf.set_surface_override_material(0, mat)
		leaf.position = lp[0]
		leaf.rotation_degrees = lp[1]
		root.add_child(leaf)

	return _pack_scene(root)

# ─────────────────────────────────────────────────────────────────────────────
# Hilfsmethoden
# ─────────────────────────────────────────────────────────────────────────────

## Konvertiert PrimitiveMesh → ArrayMesh (unveränderlich, GPU-seitig cachbar).
static func _to_array_mesh(primitive: PrimitiveMesh) -> ArrayMesh:
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, primitive.get_mesh_arrays())
	return am

## Verpackt eine Node-Hierarchie als PackedScene.
## Die root-Node muss bereits alle Kinder haben.
##
## BUGFIX (2026-09-18, "Bäume unsichtbar"): PackedScene.pack() nimmt nur Nodes
## auf, deren `owner` auf die root-Node zeigt — alle programmatisch per
## add_child() angehängten Kinder (trunk, crown, cone, ...) hatten owner=null,
## wurden also beim pack() stillschweigend verworfen. instantiate_scene() lieferte
## dadurch nur eine leere Node3D-Hülle: Entity spawnt/despawnt korrekt (die
## InteractableComponent hängt direkt an der Entity, nicht an dieser Szene),
## aber es gab nie eine sichtbare Mesh. _set_owner_recursive() setzt owner auf
## allen Nachfahren, damit pack() sie tatsächlich mit einschließt.
static func _pack_scene(root: Node) -> PackedScene:
	_set_owner_recursive(root, root)
	var scene := PackedScene.new()
	scene.pack(root)
	root.free()  # Temp-Node freigeben — PackedScene hat den State geklont
	return scene

## Setzt `owner` rekursiv auf allen Nachfahren von `node` (node selbst ausgenommen),
## damit PackedScene.pack() die komplette Hierarchie mit einpackt.
static func _set_owner_recursive(node: Node, root: Node) -> void:
	for child in node.get_children():
		child.owner = root
		_set_owner_recursive(child, root)
