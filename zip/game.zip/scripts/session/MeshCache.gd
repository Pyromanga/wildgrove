# res://scripts/session/MeshCache.gd
class_name MeshCache extends RefCounted

## MeshCache — Baut alle prozeduralen Meshes einmalig beim Session-Boot.
##
## Kein Service im Container — lebt als Feld in Factory3D.
## Factory3D.build_cache() muss VOR dem ersten Spawn aufgerufen werden.
## ServiceOrchestrator ruft dies in Phase S8.8 auf (nach populate_session,
## vor world_gen und Entity-Spawning).
##
## Caching-Strategie:
##   ArrayMesh-Objekte: direkt geteilt (GPU-Ressource ist immutable nach build())
##   Multi-Node-Objekte (Baum, Kaktus, Pilz, Farn): PackedScene built from code, geklont via instantiate()
##   Randomisierte Objekte (Fels, gefällter Baumstamm): Einheits-Mesh + per-Instanz
##     non-uniform Node-Skalierung, statt neuer PrimitiveMesh-Objekte zur Laufzeit
##
## Factory3D erzeugt ausschließlich über diesen Cache. Factory3D.cache
## muss gesetzt und gebaut sein, bevor die erste create_*()-Methode
## aufgerufen wird.
##
## Performance-Ziel: 0 CylinderMesh.new() / SphereMesh.new() zur Laufzeit.
## Alle GPU-Uploads passieren einmalig in build().

const LOG_CAT := "MeshCache"

## Nah/Fern-Sichtweite für Baumkronen (Wunsch "entferntes/nahes Rendern"): innerhalb
## LOD_NEAR_DISTANCE zeigt sich die neue Karten-Krone (_build_leaf_cluster(), Blattform +
## Muster sichtbar), jenseits davon die alte, billige Kugel-Krone (kein Geometrie-Detail nötig,
## auf die Entfernung ohnehin nicht unterscheidbar) — beide sitzen die ganze Zeit im Baum, Godots
## GeometryInstance3D.visibility_range_* blendet rein über Entfernung zur Kamera um, kein
## eigener Tick/Code nötig. LOD_FADE_MARGIN ist die Übergangszone (visibility_range_*_margin),
## in der beide weich über- statt hart umgeblendet werden (VISIBILITY_RANGE_FADE_SELF).
const LOD_NEAR_DISTANCE: float = 14.0
const LOD_FADE_MARGIN: float = 2.5

## Einfache Meshes — direkt als ArrayMesh geteilt
var meshes: Dictionary = {}     # { "key": ArrayMesh }

## Komplexe Multi-Node-Objekte — als PackedScene geklont
var scenes: Dictionary = {}     # { "key": PackedScene }

## Material-Cache — StandardMaterial3D ist teuer zu erstellen
var materials: Dictionary = {}  # { color_key: StandardMaterial3D }

var _built: bool = false

func build() -> void:
	if _built:
		return
	var t := Time.get_ticks_msec()

	_build_materials()
	_build_simple_meshes()
	_build_tree_scenes()
	_build_mushroom_scenes()
	_build_animal_meshes()
	_build_bar_mesh()

	_built = true
	AppLogger.log_info(
		"MeshCache: %d meshes, %d scenes, %d materials in %d ms" % [
			meshes.size(), scenes.size(), materials.size(),
			Time.get_ticks_msec() - t
		],
		LOG_CAT
	)

func is_built() -> bool:
	return _built

## Gibt ein gecachtes oder neu erstelltes Material zurück.
## resource_local_to_scene = false → GPU-seitig geteilt, kein erneutes Upload.
func get_material(color: Color, unshaded: bool = false) -> StandardMaterial3D:
	var key := "%s_%s" % [color.to_html(), str(unshaded)]
	if not materials.has(key):
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		if unshaded:
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.resource_local_to_scene = false  # GPU-seitig teilen
		materials[key] = mat
	return materials[key]

## Wie get_material(), aber mit prozeduraler Detail-Textur (ProceduralTextureFactory)
## statt reiner Flächenfarbe — "Natur ist auch nur Mathematik": Stein/Holz/Rinde/
## Moos/Gras/Sand/Kies/Erde bekommen Grain-Variation statt komplett flacher Fläche,
## ohne eine einzige Bilddatei. `color` tönt die Textur (StandardMaterial3D
## multipliziert albedo_color * albedo_texture), uv1_scale kachelt sie mehrfach
## über das Mesh. Unbekannte category fällt auf get_material() zurück (kein harter
## Fehler).
func get_textured_material(color: Color, category: String, unshaded: bool = false) -> StandardMaterial3D:
	var key := "tex_%s_%s_%s" % [category, color.to_html(), str(unshaded)]
	if not materials.has(key):
		var tex: ImageTexture
		match category:
			"stone":  tex = ProceduralTextureFactory.stone()
			"wood":   tex = ProceduralTextureFactory.wood()
			"grass":  tex = ProceduralTextureFactory.grass()
			"sand":   tex = ProceduralTextureFactory.sand()
			"gravel": tex = ProceduralTextureFactory.gravel()
			"dirt":   tex = ProceduralTextureFactory.dirt()
			"bark":   tex = ProceduralTextureFactory.bark()
			"moss":   tex = ProceduralTextureFactory.moss()
			"ore_iron":   tex = ProceduralTextureFactory.ore_iron()
			"ore_copper": tex = ProceduralTextureFactory.ore_copper()
			"ice":        tex = ProceduralTextureFactory.ice()
			"sulfur":     tex = ProceduralTextureFactory.sulfur()
			"wax":        tex = ProceduralTextureFactory.wax()
			"glass":      tex = ProceduralTextureFactory.glass()
			"charcoal":   tex = ProceduralTextureFactory.charcoal()
			_:
				AppLogger.log_warn(
					"MeshCache: unbekannte Textur-Kategorie '%s' — falle auf Flächenfarbe zurück." % category,
					LOG_CAT
				)
				return get_material(color, unshaded)
		var mat := StandardMaterial3D.new()
		mat.albedo_color = color
		mat.albedo_texture = tex
		mat.uv1_scale = Vector3(2.0, 2.0, 2.0)
		mat.roughness = 0.9
		mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		if unshaded:
			mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		mat.resource_local_to_scene = false  # GPU-seitig teilen
		materials[key] = mat
	return materials[key]

## Einmal gebauter, geteilter Shader für get_swaying_material() — Shader.new()
## ist teuer, das Kompilat aber pro Prozess identisch, also genau wie
## MeshCache.meshes/materials nur EINMAL bauen, danach an alle ShaderMaterial-
## Instanzen weiterreichen (jede ShaderMaterial trägt nur ihre eigenen
## Uniform-Werte, der kompilierte Shader-Code wird geteilt).
static var _sway_shader: Shader = null

## Wind-Sway für Baumkronen/Farn (docs/procedural-textures-and-weather-vfx.md,
## "Bekannte Grenzen" → "naheliegender nächster Schritt"): Vertex-Shader statt
## StandardMaterial3D, verschiebt Vertices mit positivem lokalem Y (siehe
## Shader-Kommentar) im Takt zweier überlagerter Sinuskurven aus TIME — exakt
## dasselbe Zwei-Sinus-Prinzip wie WindField (GDScript), hier aber eigenständig
## in GLSL, weil ein Shader keine GDScript-Klassen aufrufen kann (siehe bereits
## TerrainMeshBuilder-Kommentar zu grain_hash()). Ein Hash auf die Weltposition
## der jeweiligen MeshInstance3D gibt jedem Baum/Farn eine eigene Phasenlage,
## damit nicht der komplette Wald im Gleichtakt wedelt.
##
## category: wie bei get_textured_material() — leer lässt die Fläche ungetönt
## einfarbig (für Baumkronen, die bisher get_material() nutzten).
## sway_strength: skaliert die Auslenkung (kleines Farnblatt braucht weniger
## als eine große Baumkrone), reiner Uniform-Wert, kein neuer Shader nötig.
func get_swaying_material(color: Color, category: String = "", sway_strength: float = 1.0) -> ShaderMaterial:
	var key := "sway_%s_%s_%s" % [category, color.to_html(), str(sway_strength)]
	if not materials.has(key):
		if _sway_shader == null:
			_sway_shader = _build_sway_shader()
		var tex: Texture2D = null
		if category != "":
			match category:
				"stone":  tex = ProceduralTextureFactory.stone()
				"wood":   tex = ProceduralTextureFactory.wood()
				"grass":  tex = ProceduralTextureFactory.grass()
				"sand":   tex = ProceduralTextureFactory.sand()
				"gravel": tex = ProceduralTextureFactory.gravel()
				"dirt":   tex = ProceduralTextureFactory.dirt()
				"bark":   tex = ProceduralTextureFactory.bark()
				"moss":   tex = ProceduralTextureFactory.moss()
				_:
					AppLogger.log_warn(
						"MeshCache: unbekannte Textur-Kategorie '%s' in get_swaying_material() — bleibt ungetönt." % category,
						LOG_CAT
					)
		var mat := ShaderMaterial.new()
		mat.shader = _sway_shader
		mat.set_shader_parameter("albedo_color", color)
		mat.set_shader_parameter("use_texture", tex != null)
		if tex != null:
			mat.set_shader_parameter("albedo_tex", tex)
		mat.set_shader_parameter("sway_strength", sway_strength)
		mat.resource_local_to_scene = false  # GPU-seitig teilen, wie alle anderen Materials hier
		materials[key] = mat
	return materials[key]

## cull_disabled (Wunsch "Bäume ... Blätter"): flache Blatt-Karten-Quads (siehe
## _build_leaf_cluster()) sind einseitig — ohne das würde man beim Herumlaufen von hinten
## einfach durch sie hindurchsehen. Für die bisherigen Kugel-Kronen ist Backface-Culling
## unerheblich (geschlossene Form, Rückseite sowieso nie sichtbar), daher hier pauschal für
## den ganzen (geteilten) Shader statt nur für Karten-Materialien — kein zweiter Shader nötig.
## Wie get_swaying_material(), aber für Blatt-Karten (leaf_quad-Mesh, siehe
## _build_leaf_cluster()): braucht ProceduralTextureFactory.leaf_card(hue_seed, shape) statt
## einer der festen category-Texturen, deshalb ein eigener kleiner Wrapper statt
## get_swaying_material() um einen shape/hue_seed-Parameter zu erweitern (der für
## Stein/Holz/... keinen Sinn ergäbe). Nutzt denselben geteilten _sway_shader.
func get_leaf_material(color: Color, shape: int, hue_seed: int, sway_strength: float = 1.0) -> ShaderMaterial:
	var key := "leafmat_%s_%d_%d_%s" % [color.to_html(), shape, hue_seed, str(sway_strength)]
	if not materials.has(key):
		if _sway_shader == null:
			_sway_shader = _build_sway_shader()
		var mat := ShaderMaterial.new()
		mat.shader = _sway_shader
		mat.set_shader_parameter("albedo_color", color)
		mat.set_shader_parameter("use_texture", true)
		mat.set_shader_parameter("albedo_tex", ProceduralTextureFactory.leaf_card(48, hue_seed, shape))
		mat.set_shader_parameter("sway_strength", sway_strength)
		mat.resource_local_to_scene = false
		materials[key] = mat
	return materials[key]

## Nah-LOD (siehe LOD_NEAR_DISTANCE-Kommentar): sichtbar bis LOD_NEAR_DISTANCE, blendet danach
## weich zur Fern-Variante über.
func _apply_near_lod(inst: GeometryInstance3D) -> void:
	inst.visibility_range_end = LOD_NEAR_DISTANCE
	inst.visibility_range_end_margin = LOD_FADE_MARGIN
	inst.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF

## Fern-LOD: unsichtbar bis LOD_NEAR_DISTANCE, blendet davor weich von der Nah-Variante über.
func _apply_far_lod(inst: GeometryInstance3D) -> void:
	inst.visibility_range_begin = LOD_NEAR_DISTANCE
	inst.visibility_range_begin_margin = LOD_FADE_MARGIN
	inst.visibility_range_fade_mode = GeometryInstance3D.VISIBILITY_RANGE_FADE_SELF

## Baut einen kleinen "Blatt-Cluster" aus mehreren Karten-Quads um `anchor` — die Nah-LOD-
## Entsprechung einer Kronen-Kugel (crown_md/crown_sm). Positionen/Rotationen sind bewusst fest
## verdrahtet statt zufällig (Determinismus — dieselbe PackedScene läuft identisch auf jedem
## Peer, siehe Klassenkommentar oben zu Determinismus in ProceduralTextureFactory) — eine
## handverlesene, leicht unregelmäßige Streuung statt eines perfekten Kreises, damit die Krone
## nicht wie ein Kranz aus lauter gleich ausgerichteten Karten wirkt.
## `stretch`: zusätzliche Non-Uniform-Skalierung pro Karte (z.B. Weide: schmaler + länger für
## einen lanzettlichen statt ovalen Umriss, ohne eine eigene Blattform zu brauchen).
var _leaf_cluster_offsets: Array = [
	{"pos": Vector3(0.00, 0.06, 0.00), "rot": Vector3(6, 0, 0)},
	{"pos": Vector3(0.20, -0.04, 0.06), "rot": Vector3(10, 45, 4)},
	{"pos": Vector3(-0.18, 0.02, -0.09), "rot": Vector3(-8, -50, -3)},
	{"pos": Vector3(0.06, 0.16, -0.16), "rot": Vector3(22, 105, 6)},
	{"pos": Vector3(-0.09, -0.13, 0.17), "rot": Vector3(-18, 155, -6)},
	{"pos": Vector3(0.02, -0.02, 0.21), "rot": Vector3(4, 205, 2)},
]

func _build_leaf_cluster(
	anchor: Vector3, base_scale: float, color: Color, shape: int,
	hue_seed_base: int, sway_strength: float = 1.0, stretch: Vector3 = Vector3.ONE
) -> Node3D:
	var cluster := Node3D.new()
	cluster.position = anchor
	for i in _leaf_cluster_offsets.size():
		var o: Dictionary = _leaf_cluster_offsets[i]
		var card := MeshInstance3D.new()
		card.mesh = meshes["leaf_quad"]
		card.material_override = get_leaf_material(color, shape, hue_seed_base + i, sway_strength)
		card.position = (o["pos"] as Vector3) * base_scale
		card.rotation_degrees = o["rot"]
		card.scale = Vector3.ONE * base_scale * stretch
		_apply_near_lod(card)
		cluster.add_child(card)
	return cluster

static func _build_sway_shader() -> Shader:
	var shader := Shader.new()
	shader.code = """
shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx, cull_disabled;

uniform vec4 albedo_color : source_color = vec4(1.0);
uniform sampler2D albedo_tex : hint_default_white;
uniform bool use_texture = false;
uniform float sway_strength : hint_range(0.0, 2.0) = 1.0;
uniform float roughness_val : hint_range(0.0, 1.0) = 0.9;

// Gleiche Hash-Familie wie ProceduralTextureFactory._hash2() / TerrainMeshBuilder.grain_hash()
// -- eigenständig hier, weil ein Shader keine GDScript-Klassen aufrufen kann.
float sway_hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

void vertex() {
	// Weltposition des Objekt-Pivots (nicht pro Vertex) -> stabile Phase je
	// MeshInstance3D, unterschiedlich je Baum/Farn statt synchronem Wedeln.
	vec3 world_origin = (MODEL_MATRIX * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
	float phase = sway_hash(world_origin.xz) * 6.2831853;
	float t = TIME;
	float wind = sin(t * 0.9 + phase) * 0.7 + sin(t * 2.3 + phase * 1.7) * 0.3;
	float sway = cos(t * 0.7 + phase);
	// Nur der obere, von der Basis wegzeigende Teil des Meshes schwingt
	// spürbar (Ast/Blattspitze) -- die Basis (VERTEX.y <= 0) bleibt ruhig.
	float lift = max(VERTEX.y, 0.0);
	VERTEX.x += wind * lift * 0.10 * sway_strength;
	VERTEX.z += sway * lift * 0.08 * sway_strength;
}

void fragment() {
	vec4 tex_color = use_texture ? texture(albedo_tex, UV * 2.0) : vec4(1.0);
	ALBEDO = clamp((albedo_color * tex_color).rgb, 0.0, 1.0);
	ROUGHNESS = roughness_val;
	METALLIC = 0.0;
}
"""
	return shader

func get_mesh(key: String) -> ArrayMesh:
	return meshes.get(key)

## Instanziiert eine komplexe Szene (Baum, Kaktus, Farn etc.).
## Gibt Node3D.new() zurück wenn der Key nicht existiert — nie null.
func instantiate_scene(key: String) -> Node3D:
	var scene: PackedScene = scenes.get(key)
	if scene == null:
		AppLogger.log_error("MeshCache: Szene '%s' nicht gefunden." % key, LOG_CAT)
		return Node3D.new()
	return scene.instantiate() as Node3D

# ─────────────────────────────────────────────────────────────────────────────
# Build-Methoden (einmalig beim Session-Boot)
# ─────────────────────────────────────────────────────────────────────────────

func _build_materials() -> void:
	# Alle Biom-/Objekt-Farben vorab bauen
	var presets := {
		"trunk_oak":      Color(0.4,  0.25, 0.10),
		"trunk_pine":     Color(0.35, 0.20, 0.08),
		"leaves_oak":     Color(0.15, 0.50, 0.10),
		"leaves_pine":    Color(0.10, 0.40, 0.08),
		"leaves_snow":    Color(0.95, 0.97, 1.00),
		"rock_forest":    Color(0.45, 0.40, 0.35),
		"rock_desert":    Color(0.75, 0.60, 0.35),
		"cactus":         Color(0.20, 0.55, 0.15),
		"fern":           Color(0.20, 0.60, 0.15),
		"mushroom_red":   Color(0.85, 0.10, 0.10),
		"mushroom_brown": Color(0.50, 0.30, 0.10),
		"bar_hp":         Color(0.10, 0.85, 0.10),
		"bar_bg":         Color(0.15, 0.15, 0.15, 0.80),
		"fallen_log":     Color(0.35, 0.22, 0.09),
		"animal_body":    Color(0.60, 0.50, 0.35),
		"animal_head":    Color(0.55, 0.45, 0.30),
	}
	for key in presets:
		get_material(presets[key])

func _build_simple_meshes() -> void:
	# Zylinder-Varianten für Baumstämme
	for r_pair in [["trunk_sm", 0.12, 0.18], ["trunk_md", 0.15, 0.22], ["trunk_lg", 0.18, 0.28]]:
		var m := CylinderMesh.new()
		m.top_radius    = r_pair[1]
		m.bottom_radius = r_pair[2]
		m.height        = 2.0
		meshes[r_pair[0]] = _to_array_mesh(m)

	# Kugeln für Baumkronen (Fern-LOD, siehe LOD_NEAR_DISTANCE-Kommentar)
	for s_pair in [["crown_sm", 0.8], ["crown_md", 1.1], ["crown_lg", 1.4]]:
		var m := SphereMesh.new()
		m.radius = s_pair[1]
		m.height = s_pair[1] * 2.0
		meshes[s_pair[0]] = _to_array_mesh(m)

	# Ein einziges geteiltes Karten-Quad für alle Blatt-Cluster (Nah-LOD) — Größe/Form kommt
	# über Node-Skalierung pro Karte (siehe _build_leaf_cluster()), nicht über eigene Meshes.
	var leaf_quad_mesh := QuadMesh.new()
	leaf_quad_mesh.size = Vector2(0.4, 0.5)
	meshes["leaf_quad"] = _to_array_mesh(leaf_quad_mesh)

	# Kegel für Tanne (CylinderMesh mit top_radius = 0)
	for c_pair in [["pine_cone_0", 1.2, 0.8], ["pine_cone_1", 1.0, 0.65], ["pine_cone_2", 0.75, 0.5]]:
		var m := CylinderMesh.new()
		m.top_radius    = 0.0
		m.bottom_radius = c_pair[1]
		m.height        = c_pair[2]
		meshes[c_pair[0]] = _to_array_mesh(m)

	# Kaktus-Stamm und -Arme
	var kaktus_stamm := CylinderMesh.new()
	kaktus_stamm.top_radius    = 0.18
	kaktus_stamm.bottom_radius = 0.20
	kaktus_stamm.height        = 1.6
	meshes["cactus_trunk"] = _to_array_mesh(kaktus_stamm)

	var kaktus_arm := CylinderMesh.new()
	kaktus_arm.top_radius    = 0.10
	kaktus_arm.bottom_radius = 0.12
	kaktus_arm.height        = 0.6
	meshes["cactus_arm"] = _to_array_mesh(kaktus_arm)

	# Farn-Blatt (abgeflachte Kugel)
	var fern_leaf := SphereMesh.new()
	fern_leaf.radius = 0.4
	fern_leaf.height = 0.15
	meshes["fern_leaf"] = _to_array_mesh(fern_leaf)

	# Gefällter Baumstamm (liegender Zylinder — Rotation beim Instanziieren)
	var log := CylinderMesh.new()
	log.top_radius    = 0.22
	log.bottom_radius = 0.25
	log.height        = 2.4
	meshes["fallen_log"] = _to_array_mesh(log)

	# Felsblock-Basis — Einheitskugel, pro Instanz non-uniform skaliert
	var boulder := SphereMesh.new()
	boulder.radius = 1.0
	boulder.height = 2.0
	meshes["rock_unit"] = _to_array_mesh(boulder)

	# Pilz-Teile — geteilt über alle Pilz-Typen, nur Material variiert
	var shroom_stem := CylinderMesh.new()
	shroom_stem.top_radius    = 0.04
	shroom_stem.bottom_radius = 0.06
	shroom_stem.height        = 0.18
	meshes["mushroom_stem"] = _to_array_mesh(shroom_stem)

	var shroom_cap := SphereMesh.new()
	shroom_cap.radius = 0.14
	shroom_cap.height = 0.14 * 0.55  # abgeflacht
	meshes["mushroom_cap"] = _to_array_mesh(shroom_cap)

	var shroom_dot := SphereMesh.new()
	shroom_dot.radius = 0.025
	shroom_dot.height = 0.05
	meshes["mushroom_dot"] = _to_array_mesh(shroom_dot)

	# Schnee-Kappen für Tannen — kleiner als die Blatt-Kegel, sitzen obendrauf
	for c_pair in [["snow_cap_0", 0.9, 0.35], ["snow_cap_1", 0.7, 0.30], ["snow_cap_2", 0.5, 0.25]]:
		var m := CylinderMesh.new()
		m.top_radius    = 0.0
		m.bottom_radius = c_pair[1]
		m.height        = c_pair[2]
		meshes[c_pair[0]] = _to_array_mesh(m)

func _build_tree_scenes() -> void:
	scenes["tree_oak"]          = _build_scene_oak()
	# BUGFIX (2026-09-20, "keine Farbunterschiede bei Baumarten"): tree_willow/
	# tree_maple fehlten komplett im Cache — Factory3D.create_simple_tree()
	# fiel für ALLE drei Laubbaumtypen (Oak/Willow/Maple) auf "tree_oak"
	# zurück, sichtbar identisch trotz unterschiedlicher Baumart.
	scenes["tree_willow"]       = _build_scene_willow()
	scenes["tree_maple"]        = _build_scene_maple()
	scenes["tree_pine"]         = _build_scene_pine(false)
	scenes["tree_pine_snow"]    = _build_scene_pine(true)
	scenes["tree_fallen_forest"] = _build_scene_fallen("forest")
	scenes["tree_fallen_desert"] = _build_scene_fallen("desert")
	scenes["cactus"]            = _build_scene_cactus()
	scenes["fern"]              = _build_scene_fern()

func _build_mushroom_scenes() -> void:
	scenes["mushroom_red"]    = _build_scene_mushroom("red")
	scenes["mushroom_brown"]  = _build_scene_mushroom("brown")
	scenes["mushroom_orange"] = _build_scene_mushroom("orange")

func _build_scene_mushroom(mushroom_type: String) -> PackedScene:
	var root := Node3D.new()
	root.name = "Mushroom_%s" % mushroom_type.capitalize()

	var stem := MeshInstance3D.new()
	stem.mesh = meshes["mushroom_stem"]
	stem.set_surface_override_material(0, get_material(Color(0.85, 0.80, 0.72)))
	stem.position.y = 0.09
	root.add_child(stem)

	var cap_color: Color
	match mushroom_type:
		"red":    cap_color = Color(0.85, 0.15, 0.10)
		"orange": cap_color = Color(0.90, 0.55, 0.10)
		_:        cap_color = Color(0.55, 0.35, 0.18)

	var cap := MeshInstance3D.new()
	cap.mesh = meshes["mushroom_cap"]
	cap.set_surface_override_material(0, get_material(cap_color))
	cap.position.y = 0.22
	root.add_child(cap)

	if mushroom_type == "red":
		var dot_material := get_material(Color(1.0, 1.0, 1.0))
		for i in range(3):
			var dot := MeshInstance3D.new()
			dot.mesh = meshes["mushroom_dot"]
			dot.set_surface_override_material(0, dot_material)
			var angle := (TAU / 3.0) * i
			dot.position = Vector3(cos(angle) * 0.07, 0.24, sin(angle) * 0.07)
			root.add_child(dot)

	return _pack_scene(root)

func _build_animal_meshes() -> void:
	for a in [["animal_body_sm", Vector3(0.3, 0.5, 0.3)],
			  ["animal_body_md", Vector3(0.5, 0.7, 0.5)],
			  ["animal_body_lg", Vector3(0.6, 0.8, 0.6)]]:
		var m := BoxMesh.new()
		m.size = a[1]
		meshes[a[0]] = _to_array_mesh(m)

	# Tier-Kopf (kleinere Box)
	var head := BoxMesh.new()
	head.size = Vector3(0.28, 0.28, 0.28)
	meshes["animal_head"] = _to_array_mesh(head)

func _build_bar_mesh() -> void:
	# HP-Bar Hintergrund + Füllung (zwei schmale Quads)
	var bg := QuadMesh.new()
	bg.size = Vector2(1.2, 0.20)
	meshes["bar_bg"] = _to_array_mesh(bg)
	var fg := QuadMesh.new()
	fg.size = Vector2(1.1, 0.15)
	meshes["bar_fg"] = _to_array_mesh(fg)

# ─────────────────────────────────────────────────────────────────────────────
# Szenen-Builder (erstellen Node-Hierarchie, verpacken als PackedScene)
# ─────────────────────────────────────────────────────────────────────────────

func _build_scene_oak() -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Oak"

	# Stamm
	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_md"]
	trunk.set_surface_override_material(0, get_textured_material(Color(0.4, 0.25, 0.10), "bark"))
	trunk.position = Vector3(0.0, 1.0, 0.0)
	root.add_child(trunk)

	# Krone (Hauptkugel) — Fern-LOD, siehe LOD_NEAR_DISTANCE-Kommentar
	var crown := MeshInstance3D.new()
	crown.mesh = meshes["crown_md"]
	crown.set_surface_override_material(0, get_swaying_material(Color(0.15, 0.50, 0.10)))
	crown.position = Vector3(0.0, 2.4, 0.0)
	_apply_far_lod(crown)
	root.add_child(crown)

	# Zweite, kleinere Krone versetzt — ebenfalls Fern-LOD
	var crown2 := MeshInstance3D.new()
	crown2.mesh = meshes["crown_sm"]
	crown2.set_surface_override_material(0, get_swaying_material(Color(0.12, 0.45, 0.08)))
	crown2.position = Vector3(0.3, 2.8, 0.2)
	_apply_far_lod(crown2)
	root.add_child(crown2)

	# Nah-LOD: Blatt-Karten-Cluster an denselben Ankerpunkten, LOBED-Silhouette (fiederig
	# gelappter Rand wie eine echte Eiche statt einer glatten Kugel).
	root.add_child(_build_leaf_cluster(
		Vector3(0.0, 2.4, 0.0), 1.1, Color(0.15, 0.50, 0.10), ProceduralTextureFactory.LeafShape.LOBED, 0))
	root.add_child(_build_leaf_cluster(
		Vector3(0.3, 2.8, 0.2), 0.8, Color(0.12, 0.45, 0.08), ProceduralTextureFactory.LeafShape.LOBED, 6))

	return _pack_scene(root)

## Weide — schlanker, hellerer Stamm; hängende, gelblich-grüne Krone
## (deutlich heller/gelbstichiger als die dunkelgrüne Eiche).
func _build_scene_willow() -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Willow"

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_sm"]
	trunk.set_surface_override_material(0, get_textured_material(Color(0.45, 0.38, 0.22), "bark"))
	trunk.position = Vector3(0.0, 1.0, 0.0)
	trunk.scale = Vector3(0.85, 1.1, 0.85)
	root.add_child(trunk)

	var crown := MeshInstance3D.new()
	crown.mesh = meshes["crown_md"]
	crown.set_surface_override_material(0, get_swaying_material(Color(0.55, 0.62, 0.22), "", 1.3))
	crown.position = Vector3(0.0, 2.55, 0.0)
	crown.scale = Vector3(1.1, 0.85, 1.1)  # abgeflacht/hängend statt kugelig
	_apply_far_lod(crown)
	root.add_child(crown)

	var crown2 := MeshInstance3D.new()
	crown2.mesh = meshes["crown_sm"]
	crown2.set_surface_override_material(0, get_swaying_material(Color(0.50, 0.58, 0.20), "", 1.3))
	crown2.position = Vector3(0.35, 2.15, 0.25)
	crown2.scale = Vector3(1.0, 0.75, 1.0)
	_apply_far_lod(crown2)
	root.add_child(crown2)

	# Nah-LOD: schmale, lanzettliche Karten (stretch schmaler/länger als der Kugel-Umriss) mit
	# stärkerem sway_strength (1.3, wie schon die Fern-Kugeln) für den typischen "hängenden"
	# Weiden-Eindruck, ELLIPSE-Silhouette reicht hier (die Länge macht den Unterschied, nicht
	# der Rand).
	root.add_child(_build_leaf_cluster(
		Vector3(0.0, 2.55, 0.0), 0.85, Color(0.55, 0.62, 0.22), ProceduralTextureFactory.LeafShape.ELLIPSE,
		20, 1.3, Vector3(0.6, 1.5, 0.6)))
	root.add_child(_build_leaf_cluster(
		Vector3(0.35, 2.15, 0.25), 0.65, Color(0.50, 0.58, 0.20), ProceduralTextureFactory.LeafShape.ELLIPSE,
		26, 1.3, Vector3(0.6, 1.5, 0.6)))

	return _pack_scene(root)

## Ahorn — dickerer, dunklerer Stamm; kräftig rot-orange Krone (Herbstfarben,
## deutlich abgesetzt von Eiche/Weide-Grün).
func _build_scene_maple() -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Maple"

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_lg"]
	trunk.set_surface_override_material(0, get_textured_material(Color(0.32, 0.18, 0.08), "bark"))
	trunk.position = Vector3(0.0, 1.1, 0.0)
	root.add_child(trunk)

	var crown := MeshInstance3D.new()
	crown.mesh = meshes["crown_lg"]
	crown.set_surface_override_material(0, get_swaying_material(Color(0.75, 0.30, 0.08)))
	crown.position = Vector3(0.0, 2.7, 0.0)
	_apply_far_lod(crown)
	root.add_child(crown)

	var crown2 := MeshInstance3D.new()
	crown2.mesh = meshes["crown_md"]
	crown2.set_surface_override_material(0, get_swaying_material(Color(0.80, 0.45, 0.05)))
	crown2.position = Vector3(0.35, 3.15, 0.25)
	_apply_far_lod(crown2)
	root.add_child(crown2)

	# Nah-LOD: PALMATE-Silhouette (5-strahliger Stern — handförmig gelappt wie ein echtes
	# Ahornblatt statt einer glatten Kugel), Herbstfarben wie die Fern-Kronen.
	root.add_child(_build_leaf_cluster(
		Vector3(0.0, 2.7, 0.0), 1.4, Color(0.75, 0.30, 0.08), ProceduralTextureFactory.LeafShape.PALMATE, 40))
	root.add_child(_build_leaf_cluster(
		Vector3(0.35, 3.15, 0.25), 1.1, Color(0.80, 0.45, 0.05), ProceduralTextureFactory.LeafShape.PALMATE, 46))

	return _pack_scene(root)

func _build_scene_pine(snow: bool) -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Pine" + ("_Snow" if snow else "")

	# Stamm
	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["trunk_sm"]
	trunk.set_surface_override_material(0, get_textured_material(Color(0.35, 0.20, 0.08), "bark"))
	trunk.position = Vector3(0.0, 1.0, 0.0)
	root.add_child(trunk)

	# Drei Kegel-Ebenen von unten nach oben
	var cone_offsets: Array = [[0, 0.6], [1, 1.1], [2, 1.55]]
	# Nadelbäume schwingen spürbar weniger als Laubkronen (steifere Nadelmasse) —
	# eigener, kleinerer sway_strength statt der Krone-Default (1.0).
	var leaf_color := get_swaying_material(
		Color(0.10, 0.40, 0.08) if not snow else Color(0.95, 0.97, 1.0), "", 0.6
	)

	# Schneehaube schwingt mit demselben sway_strength/derselben Phase wie der
	# Nadelkegel darunter mit (gleiche X/Z-Weltposition -> gleicher Hash in
	# _build_sway_shader()) — sonst würde sie optisch vom wedelnden Ast abheben.
	var snow_material := get_swaying_material(Color(0.95, 0.97, 1.00), "", 0.6)

	for pair in cone_offsets:
		var cone := MeshInstance3D.new()
		cone.mesh = meshes["pine_cone_%d" % pair[0]]
		cone.set_surface_override_material(0, leaf_color)
		cone.position = Vector3(0.0, pair[1], 0.0)
		root.add_child(cone)

		if snow:
			var snow_cone := MeshInstance3D.new()
			snow_cone.mesh = meshes["snow_cap_%d" % pair[0]]
			snow_cone.set_surface_override_material(0, snow_material)
			snow_cone.position = Vector3(0.0, pair[1] + 0.2, 0.0)
			root.add_child(snow_cone)

	return _pack_scene(root)

func _build_scene_fallen(biome: String) -> PackedScene:
	var root := Node3D.new()
	root.name = "Tree_Fallen_%s" % biome.capitalize()

	var log := MeshInstance3D.new()
	log.mesh = meshes["fallen_log"]
	# Waldboden-Stämme moosen an (feucht, im Schatten liegend), Wüsten-Totholz
	# bleibt trocken/borkig — gleiche Mesh, unterschiedliche Oberfläche je Biom.
	var log_category: String = "moss" if biome == "forest" else "bark"
	log.set_surface_override_material(0, get_textured_material(Color(0.35, 0.22, 0.09), log_category))
	# Liegend: 90° um Z-Achse kippen
	log.rotation_degrees = Vector3(0.0, 0.0, 90.0)
	root.add_child(log)

	return _pack_scene(root)

func _build_scene_cactus() -> PackedScene:
	var root := Node3D.new()
	root.name = "Cactus"

	var mat := get_material(Color(0.20, 0.55, 0.15))

	var trunk := MeshInstance3D.new()
	trunk.mesh = meshes["cactus_trunk"]
	trunk.set_surface_override_material(0, mat)
	trunk.position = Vector3(0.0, 0.8, 0.0)
	root.add_child(trunk)

	# Linker Arm
	var arm_l := MeshInstance3D.new()
	arm_l.mesh = meshes["cactus_arm"]
	arm_l.set_surface_override_material(0, mat)
	arm_l.rotation_degrees = Vector3(0.0, 0.0, 90.0)
	arm_l.position = Vector3(-0.38, 1.0, 0.0)
	root.add_child(arm_l)

	# Rechter Arm
	var arm_r := MeshInstance3D.new()
	arm_r.mesh = meshes["cactus_arm"]
	arm_r.set_surface_override_material(0, mat)
	arm_r.rotation_degrees = Vector3(0.0, 0.0, -90.0)
	arm_r.position = Vector3(0.38, 0.85, 0.0)
	root.add_child(arm_r)

	return _pack_scene(root)

func _build_scene_fern() -> PackedScene:
	var root := Node3D.new()
	root.name = "Fern"

	# Farn schwingt stärker als Baumkronen (leichtes Blattwerk, kein Holzkern) —
	# höherer sway_strength als der Krone-Default.
	var mat := get_swaying_material(Color(0.20, 0.60, 0.15), "grass", 1.6)

	# 4 Blätter radial angeordnet
	var leaf_positions: Array = [
		[Vector3( 0.3, 0.1,  0.0), Vector3(-30.0, 0.0, 0.0)],
		[Vector3(-0.3, 0.1,  0.0), Vector3(-30.0, 180.0, 0.0)],
		[Vector3( 0.0, 0.1,  0.3), Vector3(-30.0, 90.0, 0.0)],
		[Vector3( 0.0, 0.1, -0.3), Vector3(-30.0, -90.0, 0.0)],
	]
	for lp in leaf_positions:
		var leaf := MeshInstance3D.new()
		leaf.mesh = meshes["fern_leaf"]
		leaf.set_surface_override_material(0, mat)
		leaf.position = lp[0]
		leaf.rotation_degrees = lp[1]
		root.add_child(leaf)

	return _pack_scene(root)

# ─────────────────────────────────────────────────────────────────────────────
# Hilfsmethoden
# ─────────────────────────────────────────────────────────────────────────────

## Konvertiert PrimitiveMesh → ArrayMesh (unveränderlich, GPU-seitig cachbar).
static func _to_array_mesh(primitive: PrimitiveMesh) -> ArrayMesh:
	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, primitive.get_mesh_arrays())
	return am

## Verpackt eine Node-Hierarchie als PackedScene.
## Die root-Node muss bereits alle Kinder haben.
##
## BUGFIX (2026-09-18, "Bäume unsichtbar"): PackedScene.pack() nimmt nur Nodes
## auf, deren `owner` auf die root-Node zeigt — alle programmatisch per
## add_child() angehängten Kinder (trunk, crown, cone, ...) hatten owner=null,
## wurden also beim pack() stillschweigend verworfen. instantiate_scene() lieferte
## dadurch nur eine leere Node3D-Hülle: Entity spawnt/despawnt korrekt (die
## InteractableComponent hängt direkt an der Entity, nicht an dieser Szene),
## aber es gab nie eine sichtbare Mesh. _set_owner_recursive() setzt owner auf
## allen Nachfahren, damit pack() sie tatsächlich mit einschließt.
static func _pack_scene(root: Node) -> PackedScene:
	_set_owner_recursive(root, root)
	var scene := PackedScene.new()
	scene.pack(root)
	root.free()  # Temp-Node freigeben — PackedScene hat den State geklont
	return scene

## Setzt `owner` rekursiv auf allen Nachfahren von `node` (node selbst ausgenommen),
## damit PackedScene.pack() die komplette Hierarchie mit einpackt.
static func _set_owner_recursive(node: Node, root: Node) -> void:
	for child in node.get_children():
		child.owner = root
		_set_owner_recursive(child, root)
