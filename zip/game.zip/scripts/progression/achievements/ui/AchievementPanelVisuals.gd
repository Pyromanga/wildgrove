class_name AchievementPanelVisuals

## AchievementPanelVisuals — reine Darstellung, keine Logik (analog
## SkillPanelVisuals/QuestPanelVisuals). Round 104.
##
## Baut das Panel programmatisch (kein .tscn) — exakt dasselbe Muster wie
## alle anderen HUD-Panels im Projekt (Skill/Quest/Shop/Bank/Trade/
## Auktionshaus), bewusst gewählt statt eines Editor-Scene-Files: Round 103
## hatte ein UI-Panel zurückgestellt, weil ein blind gebautes `.tscn` ohne
## Godot-Editor-Zugriff das höchste Risiko im gesamten Achievement-System
## gewesen wäre. Der programmatische Weg umgeht dieses Risiko vollständig,
## da er derselbe bereits mehrfach produktiv verifizierte Code-Pfad ist.
##
## Toggle-Button-Position: nächster freier Slot in der oberen Button-Reihe
## nach Skill (112–192) und Quest (208–288) → 304–384.

const CATEGORY_LABELS: Dictionary = {
	"combat": "Kampf",
	"economy": "Wirtschaft",
	"social": "Sozial",
	"stats": "Statistiken",
}

var panel: PanelContainer
var toggle_button: Button

var _list_vbox: VBoxContainer
var _category_sections: Dictionary = {}  # category -> VBoxContainer
var _rows: Dictionary = {}  # achievement_id -> { container, name_label, desc_label, bar, progress_label }

func _init(parent: CanvasLayer) -> void:
	toggle_button = Button.new()
	toggle_button.name = "AchievementToggleButton"
	toggle_button.text = "🏆"
	toggle_button.custom_minimum_size = Vector2(80, 80)
	toggle_button.anchor_left   = 0.0
	toggle_button.anchor_right  = 0.0
	toggle_button.anchor_top    = 0.0
	toggle_button.anchor_bottom = 0.0
	toggle_button.offset_left   = 304
	toggle_button.offset_right  = 384
	toggle_button.offset_top    = 16
	toggle_button.offset_bottom = 96
	toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	toggle_button.pressed.connect(toggle)
	parent.add_child(toggle_button)

	panel = PanelContainer.new()
	panel.name = "AchievementPanel"
	panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.07, 0.10, 0.94)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)

	panel.anchor_left   = 0.0
	panel.anchor_right  = 0.0
	panel.anchor_top    = 0.0
	panel.anchor_bottom = 0.0
	panel.offset_left   = 16
	panel.offset_right  = 360
	panel.offset_top    = 110
	panel.offset_bottom = 530
	panel.size_flags_vertical = Control.SIZE_SHRINK_BEGIN

	var outer_vbox := VBoxContainer.new()
	outer_vbox.add_theme_constant_override("separation", 8)
	panel.add_child(outer_vbox)

	var header := HBoxContainer.new()
	outer_vbox.add_child(header)

	var title := Label.new()
	title.text = "Erfolge"
	title.add_theme_font_size_override("font_size", 20)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)

	var close_button := Button.new()
	close_button.text = "✕"
	close_button.custom_minimum_size = Vector2(32, 32)
	close_button.pressed.connect(toggle)
	header.add_child(close_button)

	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 360)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	outer_vbox.add_child(scroll)

	_list_vbox = VBoxContainer.new()
	_list_vbox.add_theme_constant_override("separation", 10)
	_list_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_list_vbox)

	parent.add_child(panel)

## Erstellt die Zeile bei Bedarf (erster Aufruf pro achievement_id) und
## aktualisiert sie danach immer vollständig — idempotent, kann beliebig oft
## mit demselben oder geändertem Zustand aufgerufen werden.
func update_achievement(achievement_id: String, definition: Dictionary, current: float, is_unlocked: bool) -> void:
	if not _rows.has(achievement_id):
		_add_row(achievement_id, definition)

	var row: Dictionary = _rows[achievement_id]
	var target: float = float(definition.get("target", 1.0))
	var display_current: float = min(current, target)
	var name_text: String = String(definition.get("name", achievement_id))

	(row["name_label"] as Label).text = ("✅ " if is_unlocked else "🔒 ") + name_text
	(row["desc_label"] as Label).text = String(definition.get("description", ""))

	var bar := row["bar"] as ProgressBar
	bar.max_value = max(target, 0.01)
	bar.value = display_current

	var reward: int = int(definition.get("reward_gold", 0))
	var progress_text: String = "%d / %d" % [int(round(display_current)), int(round(target))]
	if reward > 0:
		progress_text += "   ·   %d Gold" % reward
	(row["progress_label"] as Label).text = progress_text

	var container := row["container"] as VBoxContainer
	container.modulate = Color(1, 1, 1, 1.0) if is_unlocked else Color(1, 1, 1, 0.6)

func _add_row(achievement_id: String, definition: Dictionary) -> void:
	var category: String = String(definition.get("category", "misc"))
	var section := _get_or_create_section(category)

	var container := VBoxContainer.new()
	container.add_theme_constant_override("separation", 2)

	var name_lbl := Label.new()
	name_lbl.add_theme_font_size_override("font_size", 15)
	container.add_child(name_lbl)

	var desc_lbl := Label.new()
	desc_lbl.add_theme_font_size_override("font_size", 12)
	desc_lbl.modulate = Color(1, 1, 1, 0.7)
	desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	container.add_child(desc_lbl)

	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(280, 12)
	bar.show_percentage = false
	container.add_child(bar)

	var progress_lbl := Label.new()
	progress_lbl.add_theme_font_size_override("font_size", 11)
	progress_lbl.modulate = Color(1, 1, 1, 0.6)
	container.add_child(progress_lbl)

	section.add_child(container)
	_rows[achievement_id] = {
		"container": container, "name_label": name_lbl, "desc_label": desc_lbl,
		"bar": bar, "progress_label": progress_lbl,
	}

func _get_or_create_section(category: String) -> VBoxContainer:
	if _category_sections.has(category):
		return _category_sections[category]

	var header_lbl := Label.new()
	header_lbl.text = String(CATEGORY_LABELS.get(category, category.capitalize()))
	header_lbl.add_theme_font_size_override("font_size", 13)
	header_lbl.modulate = Color(0.75, 0.85, 1.0, 0.9)
	_list_vbox.add_child(header_lbl)

	var section := VBoxContainer.new()
	section.add_theme_constant_override("separation", 8)
	_list_vbox.add_child(section)

	_category_sections[category] = section
	return section

func toggle() -> void:
	panel.visible = !panel.visible
