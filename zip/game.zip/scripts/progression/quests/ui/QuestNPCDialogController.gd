class_name QuestNPCDialogController
extends RefCounted

## QuestNPCDialogController — Dialog-State-Machine für den Quest-NPC.
##
## Ausgelagert aus QuestNPC (v28).
## Verwaltet die drei NPC-Zustände (HAS_QUEST, QUEST_ACTIVE, QUEST_DONE)
## und die dazugehörigen Dialog-Texte.
##
## Kein Node. Wird von QuestNPC instanziiert und aufgerufen.
## QuestNPC bleibt Koordinator — dieser Controller kennt nur die State-Logik.

enum NPCState { HAS_QUEST, QUEST_ACTIVE, QUEST_DONE }

var state: NPCState = NPCState.HAS_QUEST
var obj_progress: int = 0   ## Gecacht via quest_objective_updated Signal

var _quest_id: String
var _dialog_label: Label3D
var _scene_tree: SceneTree
var _bus: IEventBus

## Konfigurierbare Dialog-Texte — Defaults entsprechen 1:1 den bisherigen
## Erik/quest_woodcutter_intro-Texten (rückwärtskompatibel, siehe
## test_quest_npc_dialog_controller.gd). _encourage_format erwartet genau
## zwei %d-Platzhalter (current, required), analog zum bisherigen "%d/3".
var _offer_text: String
var _encourage_format: String
var _completed_text: String
var _required: int

## Optionale 2-stufige Quest-Kette (siehe set_next_quest()). Wenn gesetzt,
## bietet der NPC nach Abschluss von _quest_id automatisch die Folgequest an,
## statt für immer in QUEST_DONE zu bleiben — analog zum realen Vorbild
## "Erik" (quest_woodcutter_intro → quest_woodcutter_master →
## quest_erik_friendship), nur bewusst als fester 2-Schritt statt einer
## generischen N-Ketten-Struktur (kein Bedarf über 2 Stufen hinaus aktuell,
## siehe MinerNPC/HerbalistNPC — YAGNI statt spekulativer Generalität).
var _has_next: bool = false
var _next_quest_id: String
var _next_obj_id: String
var _next_offer_text: String
var _next_encourage_format: String
var _next_completed_text: String
var _next_required: int

## ADR-051 Stufe 1 ("mehrere Quests gleichzeitig von derselben Person"):
## zusätzliche, VOM Primär-Strang UNABHÄNGIGE Quest-Slots (siehe
## add_independent_slot()). Jeder Slot hat seinen eigenen State (inkl.
## optionaler eigener 2-Schritt-Kette, gleiches Muster wie _has_next oben)
## und läuft komplett unabhängig vom Primär-Slot. Leer (Default) = exakt das
## alte 1-Strang-Verhalten — siehe on_interact()/on_quest_completed()/
## on_quest_start_failed() unten: bei leerem _extra_slots ist jeder Codepfad
## byte-identisch zum Vor-ADR-051-Verhalten (Rückwärtskompatibilität für alle
## 6 bestehenden NPC-Subklassen + ihre Tests, siehe ADR-051 "Migrationsaufwand").
class ExtraSlot:
	var quest_id: String
	var obj_id: String
	var required: int
	var offer_text: String
	var encourage_format: String
	var completed_text: String
	var state: int = NPCState.HAS_QUEST
	var obj_progress: int = 0
	var has_next: bool = false
	var next_quest_id: String = ""
	var next_obj_id: String = ""
	var next_required: int = 1
	var next_offer_text: String = ""
	var next_encourage_format: String = ""
	var next_completed_text: String = ""

var _extra_slots: Array[ExtraSlot] = []

func _init(
	quest_id: String,
	dialog_label: Label3D,
	scene_tree: SceneTree,
	bus: IEventBus,
	offer_text: String = "Gut, dass du da bist!\nFälle 3 Eichen für mich.\nDas Holz wird gebraucht.",
	encourage_format: String = "Gut! Du hast schon\n%d/%d Bäume gefällt.",
	completed_text: String = "Danke! Das Holz werde\nich gut gebrauchen können.",
	required: int = 3
) -> void:
	_quest_id         = quest_id
	_dialog_label     = dialog_label
	_scene_tree       = scene_tree
	_bus              = bus
	_offer_text       = offer_text
	_encourage_format = encourage_format
	_completed_text   = completed_text
	_required         = required

## Registriert eine Folgequest, die dieser NPC nach Abschluss von quest_id
## automatisch anbietet (2-stufige Kette, siehe Klassenkommentar oben zu
## _has_next). Muss vor dem ersten on_interact() aufgerufen werden — von
## QuestNPC.on_spawn() direkt nach dem Konstruktor, siehe dort.
func set_next_quest(
	next_quest_id: String,
	next_obj_id: String,
	next_required: int,
	next_offer_text: String,
	next_encourage_format: String,
	next_completed_text: String
) -> void:
	if next_quest_id.is_empty():
		return
	_has_next              = true
	_next_quest_id          = next_quest_id
	_next_obj_id            = next_obj_id
	_next_required          = next_required
	_next_offer_text        = next_offer_text
	_next_encourage_format  = next_encourage_format
	_next_completed_text    = next_completed_text

## Die Quest-ID, die aktuell im Dialog relevant ist — vor Abschluss der
## ersten Kettenstufe quest_id, danach (falls set_next_quest() aufgerufen
## wurde) die Folgequest. QuestNPC nutzt das, um quest_objective_updated-
## Signale nach einem Ketten-Sprung weiterhin korrekt zu filtern (siehe
## QuestNPC._on_quest_completed()/_on_objective_updated()).
func get_active_quest_id() -> String:
	return _quest_id

## ADR-051 Stufe 1: registriert einen zusätzlichen, unabhängigen Quest-Slot
## auf demselben NPC — z.B. Talia könnte parallel zu "Der Dieb im Pelz" noch
## eine zweite, komplett unabhängige Aufgabe anbieten. Anders als
## set_next_quest() (Kette NACH Abschluss des Primär-Strangs) ist dieser Slot
## von Anfang an gleichzeitig mit dem Primär-Strang aktiv/anbietbar.
## next_quest_id optional gesetzt = auch dieser Slot bekommt seine eigene
## 2-Schritt-Kette (gleiches Muster wie set_next_quest(), nur pro Slot).
func add_independent_slot(
	quest_id: String, obj_id: String, required: int,
	offer_text: String, encourage_format: String, completed_text: String,
	next_quest_id: String = "", next_obj_id: String = "", next_required: int = 1,
	next_offer_text: String = "", next_encourage_format: String = "", next_completed_text: String = ""
) -> void:
	var slot := ExtraSlot.new()
	slot.quest_id         = quest_id
	slot.obj_id            = obj_id
	slot.required          = required
	slot.offer_text       = offer_text
	slot.encourage_format = encourage_format
	slot.completed_text   = completed_text
	if not next_quest_id.is_empty():
		slot.has_next             = true
		slot.next_quest_id         = next_quest_id
		slot.next_obj_id           = next_obj_id
		slot.next_required         = next_required
		slot.next_offer_text       = next_offer_text
		slot.next_encourage_format = next_encourage_format
		slot.next_completed_text   = next_completed_text
	_extra_slots.append(slot)

## Gesamtzahl der Quest-Slots (Primär + alle add_independent_slot()-Aufrufe).
## Für Tests/Diagnose — kein Einfluss auf die Dialog-Logik selbst.
func slot_count() -> int:
	return 1 + _extra_slots.size()

## Prüft ob q_id zu IRGENDEINEM Slot gehört (Primär, dessen Kette, oder einem
## der Extra-Slots inkl. deren Ketten) — nutzt QuestNPC, um
## quest_start_failed-Signale korrekt zu filtern, siehe dort.
func has_quest_id(q_id: String) -> bool:
	if q_id == _quest_id or (_has_next and q_id == _next_quest_id):
		return true
	for slot in _extra_slots:
		if q_id == slot.quest_id or (slot.has_next and q_id == slot.next_quest_id):
			return true
	return false

# ─────────────────────────────────────────────
# State-Übergänge
# ─────────────────────────────────────────────

## Priorität bei mehreren gleichzeitig anbietbaren/aktiven Slots: aktiv vor
## anbietbar vor erledigt (ADR-051 Stufe 1). Primär-Slot wird dabei genauso
## behandelt wie ein Extra-Slot in der Prioritäts-Kette — bei leerem
## _extra_slots reduziert sich das exakt auf das alte match-state-Verhalten
## (keine Verhaltensänderung für alle bestehenden Ein-Strang-NPCs).
func on_interact() -> void:
	if state == NPCState.QUEST_ACTIVE:
		_encourage()
		return
	for slot in _extra_slots:
		if slot.state == NPCState.QUEST_ACTIVE:
			_show_dialog(slot.encourage_format % [slot.obj_progress, slot.required])
			return
	if state == NPCState.HAS_QUEST:
		_offer_quest()
		return
	for slot in _extra_slots:
		if slot.state == NPCState.HAS_QUEST:
			_bus.quest().emit_quest_start_requested(slot.quest_id)
			slot.state = NPCState.QUEST_ACTIVE
			_show_dialog(slot.offer_text)
			return
	# Primär UND alle Extra-Slots erledigt — zeig den Primär-Completed-Text
	# (Sonderfall Mehrfach-Slot-NPC ganz durch; für den Normalfall ohne
	# Extra-Slots ist das exakt der alte _show_completed()-Aufruf).
	_show_completed()

func on_quest_completed(q_id: String) -> void:
	if q_id == _quest_id:
		if _has_next:
			# Auf die Folgequest umschalten statt endgültig QUEST_DONE zu werden.
			_quest_id         = _next_quest_id
			_required         = _next_required
			_offer_text       = _next_offer_text
			_encourage_format = _next_encourage_format
			_completed_text   = _next_completed_text
			_has_next         = false  # nur ein Sprung — feste 2-Stufen-Kette
			obj_progress      = 0
			state             = NPCState.HAS_QUEST
		else:
			state = NPCState.QUEST_DONE
	for slot in _extra_slots:
		if q_id != slot.quest_id:
			continue
		if slot.has_next:
			slot.quest_id         = slot.next_quest_id
			slot.obj_id            = slot.next_obj_id
			slot.required          = slot.next_required
			slot.offer_text       = slot.next_offer_text
			slot.encourage_format = slot.next_encourage_format
			slot.completed_text   = slot.next_completed_text
			slot.has_next         = false
			slot.obj_progress     = 0
			slot.state            = NPCState.HAS_QUEST
		else:
			slot.state = NPCState.QUEST_DONE

func on_objective_updated(_q_id: String, current: int) -> void:
	obj_progress = current

## Gegenstück zu on_objective_updated() für Extra-Slots — braucht zusätzlich
## obj_id, weil ein Quest mit mehreren Objectives (z.B. quest_talia_investigation
## mit 4 Objectives) sonst auch bei irrelevanten Objectives den angezeigten
## Fortschritt verfälschen würde (siehe QuestNPC._on_objective_updated(), das
## für den Primär-Slot exakt aus demselben Grund schon vorher auf obj_id filtert).
func on_extra_objective_updated(q_id: String, obj_id: String, current: int) -> void:
	for slot in _extra_slots:
		if slot.quest_id == q_id and slot.obj_id == obj_id:
			slot.obj_progress = current
			return

func on_quest_start_failed(reason: String) -> void:
	var msg := "Quest konnte nicht gestartet werden."
	if reason == "already_completed":
		msg = "Diese Aufgabe hast du\nbereits erledigt."
	elif reason == "already_active":
		msg = "Du arbeitest bereits\nan dieser Aufgabe!"
	elif reason.begins_with("prereq_missing"):
		msg = "Dafür bist du\nnoch nicht bereit."
	_show_dialog(msg)

# ─────────────────────────────────────────────
# Dialoge
# ─────────────────────────────────────────────

func _offer_quest() -> void:
	_bus.quest().emit_quest_start_requested(_quest_id)
	state = NPCState.QUEST_ACTIVE
	_show_dialog(_offer_text)

func _encourage() -> void:
	_show_dialog(_encourage_format % [obj_progress, _required])

func _show_completed() -> void:
	_show_dialog(_completed_text)

func _show_dialog(text: String) -> void:
	_dialog_label.text    = text
	_dialog_label.visible = true
	_scene_tree.create_timer(5.0).timeout.connect(func():
		if is_instance_valid(_dialog_label):
			_dialog_label.visible = false
	)
	_bus.world().emit_interaction_reward_text(text.replace("\n", " "))
