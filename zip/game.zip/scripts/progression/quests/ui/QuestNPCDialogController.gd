class_name QuestNPCDialogController
extends RefCounted

## QuestNPCDialogController — Dialog-State-Machine für den Quest-NPC.
##
## Ausgelagert aus QuestNPC (v28).
## Verwaltet die drei NPC-Zustände (HAS_QUEST, QUEST_ACTIVE, QUEST_DONE)
## und die dazugehörigen Dialog-Texte.
##
## Kein Node. Wird von QuestNPC instanziiert und aufgerufen.
## QuestNPC bleibt Koordinator — dieser Controller kennt nur die State-Logik.

enum NPCState { HAS_QUEST, QUEST_ACTIVE, QUEST_DONE }

var state: NPCState = NPCState.HAS_QUEST
var obj_progress: int = 0   ## Gecacht via quest_objective_updated Signal

var _quest_id: String
var _dialog_label: Label3D
var _scene_tree: SceneTree
var _bus: IEventBus

## Konfigurierbare Dialog-Texte — Defaults entsprechen 1:1 den bisherigen
## Erik/quest_woodcutter_intro-Texten (rückwärtskompatibel, siehe
## test_quest_npc_dialog_controller.gd). _encourage_format erwartet genau
## zwei %d-Platzhalter (current, required), analog zum bisherigen "%d/3".
var _offer_text: String
var _encourage_format: String
var _completed_text: String
var _required: int

## Optionale 2-stufige Quest-Kette (siehe set_next_quest()). Wenn gesetzt,
## bietet der NPC nach Abschluss von _quest_id automatisch die Folgequest an,
## statt für immer in QUEST_DONE zu bleiben — analog zum realen Vorbild
## "Erik" (quest_woodcutter_intro → quest_woodcutter_master →
## quest_erik_friendship), nur bewusst als fester 2-Schritt statt einer
## generischen N-Ketten-Struktur (kein Bedarf über 2 Stufen hinaus aktuell,
## siehe MinerNPC/HerbalistNPC — YAGNI statt spekulativer Generalität).
var _has_next: bool = false
var _next_quest_id: String
var _next_obj_id: String
var _next_offer_text: String
var _next_encourage_format: String
var _next_completed_text: String
var _next_required: int

func _init(
	quest_id: String,
	dialog_label: Label3D,
	scene_tree: SceneTree,
	bus: IEventBus,
	offer_text: String = "Gut, dass du da bist!\nFälle 3 Eichen für mich.\nDas Holz wird gebraucht.",
	encourage_format: String = "Gut! Du hast schon\n%d/%d Bäume gefällt.",
	completed_text: String = "Danke! Das Holz werde\nich gut gebrauchen können.",
	required: int = 3
) -> void:
	_quest_id         = quest_id
	_dialog_label     = dialog_label
	_scene_tree       = scene_tree
	_bus              = bus
	_offer_text       = offer_text
	_encourage_format = encourage_format
	_completed_text   = completed_text
	_required         = required

## Registriert eine Folgequest, die dieser NPC nach Abschluss von quest_id
## automatisch anbietet (2-stufige Kette, siehe Klassenkommentar oben zu
## _has_next). Muss vor dem ersten on_interact() aufgerufen werden — von
## QuestNPC.on_spawn() direkt nach dem Konstruktor, siehe dort.
func set_next_quest(
	next_quest_id: String,
	next_obj_id: String,
	next_required: int,
	next_offer_text: String,
	next_encourage_format: String,
	next_completed_text: String
) -> void:
	if next_quest_id.is_empty():
		return
	_has_next              = true
	_next_quest_id          = next_quest_id
	_next_obj_id            = next_obj_id
	_next_required          = next_required
	_next_offer_text        = next_offer_text
	_next_encourage_format  = next_encourage_format
	_next_completed_text    = next_completed_text

## Die Quest-ID, die aktuell im Dialog relevant ist — vor Abschluss der
## ersten Kettenstufe quest_id, danach (falls set_next_quest() aufgerufen
## wurde) die Folgequest. QuestNPC nutzt das, um quest_objective_updated-
## Signale nach einem Ketten-Sprung weiterhin korrekt zu filtern (siehe
## QuestNPC._on_quest_completed()/_on_objective_updated()).
func get_active_quest_id() -> String:
	return _quest_id

# ─────────────────────────────────────────────
# State-Übergänge
# ─────────────────────────────────────────────

func on_interact() -> void:
	match state:
		NPCState.HAS_QUEST:    _offer_quest()
		NPCState.QUEST_ACTIVE: _encourage()
		NPCState.QUEST_DONE:   _show_completed()

func on_quest_completed(q_id: String) -> void:
	if q_id != _quest_id:
		return
	if _has_next:
		# Auf die Folgequest umschalten statt endgültig QUEST_DONE zu werden.
		_quest_id         = _next_quest_id
		_required         = _next_required
		_offer_text       = _next_offer_text
		_encourage_format = _next_encourage_format
		_completed_text   = _next_completed_text
		_has_next         = false  # nur ein Sprung — feste 2-Stufen-Kette
		obj_progress      = 0
		state             = NPCState.HAS_QUEST
	else:
		state = NPCState.QUEST_DONE

func on_objective_updated(_q_id: String, current: int) -> void:
	obj_progress = current

func on_quest_start_failed(reason: String) -> void:
	var msg := "Quest konnte nicht gestartet werden."
	if reason == "already_completed":
		msg = "Diese Aufgabe hast du\nbereits erledigt."
	elif reason == "already_active":
		msg = "Du arbeitest bereits\nan dieser Aufgabe!"
	elif reason.begins_with("prereq_missing"):
		msg = "Dafür bist du\nnoch nicht bereit."
	_show_dialog(msg)

# ─────────────────────────────────────────────
# Dialoge
# ─────────────────────────────────────────────

func _offer_quest() -> void:
	_bus.quest().emit_quest_start_requested(_quest_id)
	state = NPCState.QUEST_ACTIVE
	_show_dialog(_offer_text)

func _encourage() -> void:
	_show_dialog(_encourage_format % [obj_progress, _required])

func _show_completed() -> void:
	_show_dialog(_completed_text)

func _show_dialog(text: String) -> void:
	_dialog_label.text    = text
	_dialog_label.visible = true
	_scene_tree.create_timer(5.0).timeout.connect(func():
		if is_instance_valid(_dialog_label):
			_dialog_label.visible = false
	)
	_bus.world().emit_interaction_reward_text(text.replace("\n", " "))
