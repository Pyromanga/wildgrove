extends QuestNPC
class_name MinerNPC

## MinerNPC — "Bergarbeiterin Mira". Quest-Geberin für quest_miner_defense.
##
## quest_miner_defense existierte bereits als Daten-Ressource, hatte aber
## keine gebende NPC-Instanz im Spiel (siehe DataManifest.gd-Bugfix im selben
## Round — die Quest wurde zusätzlich nie geladen). Mira schließt beide
## Lücken: sie ist der In-Welt-Träger für den Talk-Einstieg und den weiteren
## Dialog-Loop, exakt nach demselben Muster wie QuestNPC/Erik (Koordinator-
## Klasse bleibt unverändert, nur die @export-Defaults werden hier
## überschrieben — analog zu OakTree extends HarvestableEntity).
##
## Folgequest quest_miner_gratitude (prerequisites=[quest_miner_defense],
## auto_start=false — wird NIE von selbst gestartet, siehe QuestService.
## _unlock_followup_quests()) wird über die 2-stufige Kette in QuestNPC/
## QuestNPCDialogController (next_quest_id etc.) direkt an dieselbe
## Mira-Instanz angehängt: nach Abschluss von quest_miner_defense bietet
## Mira beim nächsten Gespräch automatisch quest_miner_gratitude an, statt
## für immer im "Danke, Fremder"-Dialog steckenzubleiben.

func _init() -> void:
	quest_id           = "quest_miner_defense"
	quest_obj_id        = "obj_collect_iron"
	npc_display_name   = "Bergarbeiterin Mira"
	npc_id              = "mira_miner"
	quest_obj_required  = 5
	dialog_offer_text = (
		"Goblins haben unsere Mine\n" +
		"überfallen! Bring mir 5 Eisenerz\n" +
		"und vertreib die Kerle."
	)
	dialog_encourage_format = "Weiter so! Schon\n%d/%d Eisenerz."
	dialog_completed_text = (
		"Die Mine ist wieder sicher.\n" +
		"Ich schulde dir was, Freund."
	)

	# Kettenstufe 2 — quest_miner_gratitude.
	next_quest_id             = "quest_miner_gratitude"
	next_quest_obj_id         = "obj_reach_mining_3"
	next_quest_obj_required   = 3
	next_dialog_offer_text = (
		"Weißt du was — bleib dran\n" +
		"mit dem Bergbau. Zeig mir,\n" +
		"dass du's wirklich drauf hast."
	)
	next_dialog_encourage_format = "Bergbau-Stufe %d/%d.\nWeiter üben!"
	next_dialog_completed_text = (
		"Respekt! Du bist jetzt\n" +
		"eine von uns Bergleuten."
	)

func _get_body_color() -> Color:
	# Erdiges Ocker/Braun statt Eriks Blau — passt zur Bergbau-Rolle.
	return Color(0.55, 0.42, 0.20)
