extends StaticBody3D
class_name QuestNPC

## QuestNPC — Stationärer Quest-Geber. Koordinator-Klasse.
##
## Delegiert an:
##   NPCVisualBuilder          → 3D-Visuals aufbauen
##   QuestNPCDialogController  → Dialog-State-Machine
##
## EventBus-Zugriff: via _bus (IEventBus), Pflicht-Dep injiziert durch on_spawn(ctx).

const LOG_CAT := "QuestNPC"

@export var quest_id:         String = "quest_woodcutter_intro"
@export var quest_obj_id:     String = "obj_chop_trees"
@export var npc_display_name: String = "Waldläufer Erik"
## Stabile ID für TALK-Quest-Objectives (QuestObjective.target_id) — unabhängig
## von npc_display_name, damit Lokalisierung/Umbenennung Quest-Daten nicht bricht.
@export var npc_id:           String = "erik_woodcutter"

## Konfigurierbare Dialog-Texte + Ziel-Menge für den generischen
## QuestNPCDialogController (siehe dort). Defaults entsprechen 1:1 den alten,
## Erik-spezifisch hartkodierten Texten — bestehende Instanzen (auch in
## Tests) bleiben dadurch unverändert. Subklassen (z.B. MinerNPC, HerbalistNPC)
## überschreiben diese Werte in _init(), analog zum Muster von HarvestableEntity-
## Subklassen (OakTree etc.) die ihre eigenen Konstanten setzen.
@export_multiline var dialog_offer_text: String = "Gut, dass du da bist!\nFälle 3 Eichen für mich.\nDas Holz wird gebraucht."
@export var dialog_encourage_format: String = "Gut! Du hast schon\n%d/%d Bäume gefällt."
@export_multiline var dialog_completed_text: String = "Danke! Das Holz werde\nich gut gebrauchen können."
## Ziel-Menge des über quest_obj_id getrackten Objectives — nur für die
## Encourage-Dialog-Anzeige (%d/%d), NICHT die Quelle der Wahrheit für den
## tatsächlichen Quest-Fortschritt (das bleibt QuestService/QuestObjective.required).
@export var quest_obj_required: int = 3

## Optionale Folgequest (2-stufige Kette, siehe QuestNPCDialogController.
## set_next_quest()/on_quest_completed()). Leer (Default) = kein Ketten-
## Verhalten, NPC bleibt nach quest_id für immer im QUEST_DONE-Dialog —
## exakt das bisherige, unveränderte Verhalten (z.B. Erik/quest_woodcutter_intro).
@export var next_quest_id:          String = ""
@export var next_quest_obj_id:      String = ""
@export var next_quest_obj_required: int = 1
@export_multiline var next_dialog_offer_text: String = ""
@export var next_dialog_encourage_format: String = ""
@export_multiline var next_dialog_completed_text: String = ""

var _dialog: QuestNPCDialogController
var _dialog_label: Label3D
var _bus: IEventBus = null  ## Pflicht-Dep, injiziert via on_spawn(ctx). Für Tests: MockEventBus.
## ADR-021 (R-5): optionaler Dep, injiziert via on_spawn(ctx). NICHT Pflicht wie
## _bus — ohne NetworkBridge funktioniert der Dialog weiter lokal, nur das
## TALK-Quest-Objective-Tracking erreicht dann die Autorität nicht (siehe
## _on_interacted()).
var _network: NetworkBridge = null

func _ready() -> void:
	name = "QuestNPC_" + npc_display_name.replace(" ", "_")
	add_to_group("npcs")

	_dialog_label = NPCVisualBuilder.build(self, npc_display_name, _get_body_color())
	# QuestNPCDialogController braucht IEventBus — wird in on_spawn() erzeugt,
	# da _bus erst dort garantiert gesetzt ist (Pflicht-Dep via EntityContext).

	_build_collision()
	_setup_interactable()
	AppLogger.log_info("QuestNPC '%s' bereit." % npc_display_name, LOG_CAT)

func _connect_bus() -> void:
	var q := _bus.quest()
	q.quest_completed.connect(_on_quest_completed)
	q.quest_objective_updated.connect(_on_objective_updated)
	q.quest_start_failed.connect(_on_quest_start_failed)

func _disconnect_bus() -> void:
	if _bus == null:
		return
	var q := _bus.quest()
	if q.quest_completed.is_connected(_on_quest_completed):
		q.quest_completed.disconnect(_on_quest_completed)
	if q.quest_objective_updated.is_connected(_on_objective_updated):
		q.quest_objective_updated.disconnect(_on_objective_updated)
	if q.quest_start_failed.is_connected(_on_quest_start_failed):
		q.quest_start_failed.disconnect(_on_quest_start_failed)

# ─────────────────────────────────────────────
# EventBus-Handler
# ─────────────────────────────────────────────

func _on_objective_updated(q_id: String, obj_id: String, current: int, _required: int) -> void:
	# quest_id/quest_obj_id werden von _on_quest_completed() nach einem
	# Ketten-Sprung (siehe next_quest_id) auf die Folgequest umgeschrieben —
	# hier also immer gegen den AKTUELLEN Stand von quest_id/quest_obj_id
	# filtern, nicht gegen einen zur Spawnzeit gecachten Wert.
	if q_id == quest_id and obj_id == quest_obj_id:
		_dialog.on_objective_updated(q_id, current)

func _on_quest_start_failed(q_id: String, reason: String) -> void:
	if q_id == quest_id or q_id == next_quest_id:
		_dialog.on_quest_start_failed(reason)
		AppLogger.log_warn("Quest-Start fehlgeschlagen '%s': %s" % [q_id, reason], LOG_CAT)

func _on_quest_completed(q_id: String, _reward: QuestReward) -> void:
	if q_id != quest_id:
		return
	_dialog.on_quest_completed(q_id)
	AppLogger.log_info("Quest '%s' abgeschlossen — NPC-Status aktualisiert." % q_id, LOG_CAT)
	# Ketten-Sprung nachziehen: der Dialog-Controller hat intern bereits auf
	# next_quest_id umgeschaltet (siehe set_next_quest()/on_quest_completed()
	# dort) — quest_id/quest_obj_id hier synchron nachführen, damit obiger
	# _on_objective_updated()-Filter beim nächsten Fortschritts-Signal auf
	# die Folgequest passt.
	if not next_quest_id.is_empty() and _dialog.get_active_quest_id() == next_quest_id:
		quest_id             = next_quest_id
		quest_obj_id         = next_quest_obj_id
		quest_obj_required   = next_quest_obj_required
		next_quest_id        = ""  # Kette bereits verbraucht (fester 2-Schritt)

## Hook für Subklassen (analog zu HarvestableEntity._get_entity_type_id()):
## eigene Körperfarbe statt Erik-Standardblau. Override per Subklasse, siehe
## MinerNPC.gd / HerbalistNPC.gd.
func _get_body_color() -> Color:
	return Color(0.25, 0.40, 0.65)

# ─────────────────────────────────────────────
# Interaktion
# ─────────────────────────────────────────────

func _setup_interactable() -> void:
	var d := InteractableData.new()
	d.id          = "talk_quest_npc"
	d.label       = "Mit %s sprechen" % npc_display_name
	d.duration    = 0.3
	d.xp_type     = "none"
	d.xp_amount   = 0
	d.inspect_text = "%s. Er sieht aus als hätte er eine Aufgabe für dich." % npc_display_name
	var comp := InteractableComponent.new()
	comp.data = d
	add_child(comp)
	# BUG-FIX: fehlte — InteractableComponent._handle_completion() feuert nur
	# das 'interacted'-Signal, ruft _on_interacted() nicht mehr direkt auf
	# (siehe AnimalBase/HarvestableEntity, die genau das schon richtig machen).
	# Ohne Connect lief das Gespräch optisch durch, aber _dialog.on_interact()
	# — und damit der Quest-Start — wurde nie ausgelöst.
	comp.interacted.connect(_on_interacted)

## Aufgerufen von InteractableComponent nach Abschluss der Rede-Interaktion.
## peer_id: ADR-021 (R-5) — nicht mehr ungenutzt. Dialogzustand selbst bleibt
## global (kein Dictionary pro Spieler, siehe Klassenkommentar oben), aber das
## TALK-Quest-Objective-Tracking braucht den echten Wert, um über
## report_domain_event() die Autorität mit korrektem peer_id zu erreichen —
## sonst kann ein Nicht-Host-Spieler dieses Objective serverseitig nie erfüllen.
##
## BUG-26 (Round 45→46): fehlender Autoritäts-Guard hier führte zu einem
## Doppel-Zähler. InteractableComponent._handle_completion() (ADR-020) ruft
## diesen Hook für einen Nicht-Host-Spieler ZWEIMAL auf: einmal lokal auf dem
## Client (reines Feedback, feuert dort bereits report_domain_event() als RPC),
## einmal erneut auf der Autorität über resolve_and_dispatch_interaction()
## (WorldService), wo dieselbe Zeile ein zweites Mal — diesmal direkt, ohne
## RPC-Umweg — dasselbe Domain-Event meldet. Ergebnis: TALK-Objectives zählten
## pro Gespräch doppelt hoch. Fix nach demselben Muster wie
## HarvestableEntity._on_interacted() / EnemyNPC._on_interacted(): lokales
## Feedback (Dialog-Anzeige) bleibt für jeden Peer bestehen, Quest-Tracking
## (Bus-Emit + report_domain_event()) ist Autoritäts-exklusiv.
func _on_interacted(action_id: String, peer_id: int) -> void:
	if action_id != "talk_quest_npc":
		return
	if not is_instance_valid(_dialog):
		AppLogger.log_warn("_on_interacted vor on_spawn() — _dialog nicht initialisiert.", LOG_CAT)
		return
	_dialog.on_interact()
	if not is_multiplayer_authority():
		# Server übernimmt: _on_interacted() läuft dort erneut als Autorität
		# (via resolve_and_dispatch_interaction(), ADR-020) — siehe BUG-26 oben.
		return
	if _bus != null:
		_bus.quest().emit_npc_talked_to(npc_id)
	if is_instance_valid(_network):
		_network.report_domain_event("npc_talked_to", {"npc_id": npc_id}, peer_id)
	AppLogger.log_info("NPC interagiert, State: %s" % _dialog.state, LOG_CAT)

# ─────────────────────────────────────────────
# Collision
# ─────────────────────────────────────────────

func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.35
	sh.height = 1.5
	col.shape = sh
	col.position.y = 0.75
	add_child(col)

# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────

func on_spawn(_cfg: Dictionary, ctx: IEntityContext = null) -> void:
	if is_instance_valid(ctx) and ctx.has_method("get_event_bus"):
		_bus = ctx.get_event_bus() as IEventBus
	if _bus == null:
		AppLogger.log_error(
			"QuestNPC.on_spawn(): kein IEventBus im EntityContext — Spawn ohne DI nicht unterstützt.",
			LOG_CAT
		)
		return
	if is_instance_valid(ctx) and ctx.has_method("get_network_bridge"):
		_network = ctx.get_network_bridge() as NetworkBridge
	if _network == null:
		AppLogger.log_warn(
			"QuestNPC.on_spawn(): keine NetworkBridge im EntityContext — TALK-Quest-Objectives " +
			"werden für diesen NPC nicht an die Autorität gemeldet (siehe ADR-021).",
			LOG_CAT
		)
	_dialog = QuestNPCDialogController.new(
		quest_id, _dialog_label, get_tree(), _bus,
		dialog_offer_text, dialog_encourage_format, dialog_completed_text, quest_obj_required
	)
	if not next_quest_id.is_empty():
		_dialog.set_next_quest(
			next_quest_id, next_quest_obj_id, next_quest_obj_required,
			next_dialog_offer_text, next_dialog_encourage_format, next_dialog_completed_text
		)
	_connect_bus()

func on_despawn() -> void:
	_disconnect_bus()
