extends QuestNPC
class_name WudangMasterNPC

## WudangMasterNPC — "Kampfmeisterin Wei". Quest-Geberin für den Questchain
## quest_wei_patience → quest_wei_mastery.
##
## Kulturkreis: chinesische Wudang-Tradition (innere Kampfkunst/Qi-Kultivierung,
## siehe docs/quest-writing-guide.md Abschnitt 1/4 — "Asiatisch: Meisterschaft/
## Prüfungslinien"). Bewusst KEIN KILL-Objective: Wei prüft `combat`-Skill-Level
## über SKILL-Objectives statt Kill-Counts ("wer nur zählt, hat nichts gelernt"),
## exakt der im Guide unter Abschnitt 4 vorgeschlagene Ansatz für die bis dahin
## offene asiatische Kulturkreis-Lücke.
##
## Running Gag (Abschnitt 3, "Der Schüler, der schneller sein will als die
## Prüfung erlaubt"): Wei kommentiert schnellen Fortschritt mit ruhiger Ironie
## statt Lob — siehe next_dialog_offer_text unten.
##
## Gleiches Muster wie MinerNPC/HerbalistNPC: eigene @export-Defaults + 2-stufige
## Kette über QuestNPC.next_quest_id. Beide Quests via content_forge.py erzeugt
## (Schema-validiert, automatisch in DataManifest.QUESTS registriert).

func _init() -> void:
	quest_id            = "quest_wei_patience"
	quest_obj_id         = "obj_reach_combat_2"
	npc_display_name    = "Kampfmeisterin Wei"
	npc_id               = "wei_master"
	quest_obj_required   = 2
	dialog_offer_text = (
		"Ich zähle keine Kills.\n" +
		"Erreiche Kampf-Stufe 2 —\n" +
		"dann reden wir weiter."
	)
	dialog_encourage_format = "Kampf-Stufe %d/%d.\nGeduld schlägt Tempo."
	dialog_completed_text = (
		"Gut. Du lernst, nicht\n" +
		"zu zählen. Das ist der\n" +
		"erste Schritt."
	)

	# Kettenstufe 2 — quest_wei_mastery.
	next_quest_id              = "quest_wei_mastery"
	next_quest_obj_id          = "obj_reach_combat_4"
	next_quest_obj_required    = 4
	next_dialog_offer_text = (
		"Stufe 2 in halber Zeit?\n" +
		"Kein Kompliment. Zeig mir\n" +
		"Stufe 4 — richtig geübt."
	)
	next_dialog_encourage_format = "Kampf-Stufe %d/%d.\nImmer noch kein Rennen."
	next_dialog_completed_text = (
		"Jetzt verstehst du Wudang.\n" +
		"Oder zumindest die Hälfte\n" +
		"davon. Genug für heute."
	)

func _get_body_color() -> Color:
	# Gedecktes Rot (Kampfkunst-Gewand) statt Eriks Blau — passt zur Rolle.
	return Color(0.50, 0.12, 0.12)
