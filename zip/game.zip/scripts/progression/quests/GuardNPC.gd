extends QuestNPC
class_name GuardNPC

## GuardNPC — "Wächterin Talia". Quest-Geberin für den Questchain
## quest_talia_investigation → quest_talia_verdict ("Der Dieb im Pelz").
##
## Wunsch "ein wirklicher Quest, der etwas länger geht und Pfiff hat" — anders
## als die bisherigen Ketten (je 1 Haupt-Objective pro Stufe) hat diese Kette
## deutlich mehr Fleisch:
##   Stufe 1 (quest_talia_investigation, 4 Objectives): TALK zu Mira (Hinweis
##   einholen) → SKILL forestry 3 (Spur verfolgen) → CUSTOM "caught_fox" (den
##   Übeltäter tatsächlich als Pet fangen — siehe AnimalCatcher.gd Feature-
##   Kommentar) → TALK zurück zu Talia (Bericht).
##   Stufe 2 (quest_talia_verdict, 2 Objectives): TALK zu Mira (konfrontieren)
##   → TALK zu Talia (Urteil) — liefert den eigentlichen Pfiff: der "Dieb" war
##   gar keiner, Mira hat ihr Glücksnugget selbst verlegt und dem Fuchs die
##   Schuld gegeben. Reward ist ein einzigartiges Erinnerungsstück
##   (fox_tail_talisman), keine generische Zahl.
##
## DER MECHANISCHE PFIFF: obj_catch_fox ist kein abstrakter Skill-Check,
## sondern verlangt echtes Fangen einer KONKRETEN Tierart über das reale
## Pet-System (AnimalCatcher.catch_animal()) — die generische "catch_animal"-
## Interactable-Action-Id (jede Tierart) wäre für ein INTERACT-Objective zu
## grob (siehe dortiger Kommentar), deshalb ein neues artspezifisches
## CUSTOM-Signal "caught_<art>". Wiederverwendbar für künftige Quests mit
## anderen Tierarten (caught_rabbit, caught_deer, ...).
##
## Gleiches Muster wie MinerNPC/HerbalistNPC/WudangMasterNPC/AncestorSpiritNPC/
## WoodcutterNPC: eigene @export-Defaults + 2-stufige Kette über
## QuestNPC.next_quest_id. quest_obj_id/next_quest_obj_id zeigen jeweils auf
## das Objective mit sinnvollem Fortschrittszähler (SKILL bzw. die erste TALK-
## Etappe) — die übrigen Objectives der jeweiligen Stufe laufen im Hintergrund
## mit (siehe QuestNPCDialogController: nur EIN Objective wird als %d/%d im
## Dialog angezeigt, der Rest zählt trotzdem für den Quest-Abschluss).

func _init() -> void:
	quest_id            = "quest_talia_investigation"
	quest_obj_id         = "obj_track_forestry_3"
	npc_display_name    = "Wächterin Talia"
	npc_id               = "talia_guard"
	quest_obj_required   = 3
	dialog_offer_text = (
		"Seit Tagen fehlt Mira\n" +
		"allerhand Glänzendes. Frag sie,\n" +
		"folge der Spur, fang den Dieb."
	)
	dialog_encourage_format = "Spur verfolgt: Stufe %d/%d.\nDu kommst näher ran."
	dialog_completed_text = (
		"Ein Fuchs war's? Na sowas.\n" +
		"Gut gemacht — aber irgendwas\n" +
		"an der Sache stinkt noch."
	)

	# Kettenstufe 2 — quest_talia_verdict (die eigentliche Auflösung/Pointe).
	next_quest_id              = "quest_talia_verdict"
	next_quest_obj_id          = "obj_talk_mira_confront"
	next_quest_obj_required    = 1
	next_dialog_offer_text = (
		"Frag Mira nochmal genau,\n" +
		"wo sie das Nugget zuletzt\n" +
		"gesehen hat. Irgendwas passt nicht."
	)
	next_dialog_encourage_format = "Schon mit Mira gesprochen?\nIch warte auf deinen Bericht."
	next_dialog_completed_text = (
		"Sie hat's selbst verlegt, was?\n" +
		"Typisch. Der Fuchs kriegt eine\n" +
		"Entschuldigung. Von mir aus reicht's."
	)

func _get_body_color() -> Color:
	# Gedecktes Grün (Wächter-Uniform) — unterscheidet sie von Eriks Blau
	# und Weis Rot.
	return Color(0.20, 0.40, 0.25)
