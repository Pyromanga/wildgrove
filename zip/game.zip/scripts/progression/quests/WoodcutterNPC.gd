extends QuestNPC
class_name WoodcutterNPC

## WoodcutterNPC — "Waldläufer Erik". Quest-Geber für quest_woodcutter_intro
## → quest_woodcutter_master.
##
## BUGFIX ("nach quest_woodcutter_intro nie eine zweite Erik-Quest bekommen"):
## Erik lief bisher über den GENERISCHEN Entity-Typ "quest_npc" (reine
## QuestNPC-Basisklasse, siehe WorldEntityRegistry.gd/WorldSpawner.gd vor
## diesem Fix) — mit next_quest_id auf Default "" (siehe QuestNPC.gd). Anders
## als Mira/Senna (MinerNPC.gd/HerbalistNPC.gd, jeweils eigene Subklasse mit
## konfigurierter Kette) hat Erik nie next_quest_id gesetzt bekommen. Beide
## Folgequests (quest_woodcutter_master, quest_erik_friendship;
## prerequisites=[quest_woodcutter_intro]) haben sich zwar korrekt
## "freigeschaltet" (siehe QuestService._unlock_followup_quests()), aber
## OHNE next_quest_id bietet Erik nach Abschluss für immer nur noch seinen
## QUEST_DONE-Text ("Danke! Das Holz...") an — die Folgequests hatten
## dadurch nie einen tatsächlichen Startpunkt. Exakt dieselbe Bug-Klasse wie
## die in ImplementAgent.md dokumentierten "Quest ohne NPC-Träger"-Fälle.
##
## Warum quest_woodcutter_master als Kettenschritt 2 und NICHT
## quest_erik_friendship: Erstens erlaubt QuestNPC/QuestNPCDialogController
## bewusst nur einen festen 2-Schritt (siehe dortiger Klassenkommentar —
## YAGNI statt N-stufiger Kette), es kann also nur EINE der beiden
## gleichrangig freigeschalteten Folgequesten automatisch angeboten werden.
## Zweitens hängt quest_erik_friendship.obj_explore_camp an einem
## QuestCustomTrigger, der im aktuellen World-Setup nirgends instanziiert ist
## (siehe AncestorSpiritNPC.gd Klassenkommentar für dieselbe Einschränkung)
## — sie wäre also selbst mit Kette nie abschließbar. quest_woodcutter_master
## (reines SKILL-Objective, `woodcutting`-Stufe 5) ist dagegen sofort
## erreichbar. quest_erik_friendship bleibt bis zur QuestCustomTrigger-
## Verdrahtung ein bekannter offener Punkt (siehe TODO-offene-probleme.md).
##
## Alle @export-Defaults entsprechen 1:1 den bisherigen, Erik-spezifisch
## hartkodierten Texten (siehe QuestNPCDialogController-Konstruktor-Defaults)
## — bestehende Spielstände/Tests, die gegen die alten Default-Dialogtexte
## laufen, bleiben unverändert. Gleiches Muster wie MinerNPC/HerbalistNPC/
## WudangMasterNPC/AncestorSpiritNPC: eigene @export-Defaults + 2-stufige
## Kette über QuestNPC.next_quest_id.

func _init() -> void:
	quest_id            = "quest_woodcutter_intro"
	quest_obj_id         = "obj_chop_trees"
	npc_display_name    = "Waldläufer Erik"
	npc_id               = "erik_woodcutter"
	quest_obj_required   = 3
	dialog_offer_text = (
		"Gut, dass du da bist!\n" +
		"Fälle 3 Eichen für mich.\n" +
		"Das Holz wird gebraucht."
	)
	dialog_encourage_format = "Gut! Du hast schon\n%d/%d Bäume gefällt."
	dialog_completed_text = (
		"Danke! Das Holz werde\n" +
		"ich gut gebrauchen können."
	)

	# Kettenstufe 2 — quest_woodcutter_master (reines SKILL-Objective,
	# sofort erreichbar, siehe Klassenkommentar oben für die Begründung
	# gegen quest_erik_friendship als Alternative).
	next_quest_id              = "quest_woodcutter_master"
	next_quest_obj_id          = "obj_reach_woodcutting_5"
	next_quest_obj_required    = 5
	next_dialog_offer_text = (
		"Du hast wirklich Talent.\n" +
		"Erreiche Holzfäller-Stufe 5 —\n" +
		"dann bist du kein Anfänger mehr."
	)
	next_dialog_encourage_format = "Holzfäller-Stufe %d/%d.\nWeiter so!"
	next_dialog_completed_text = (
		"Beeindruckend. Ich habe\n" +
		"nichts mehr, was ich dir\n" +
		"beibringen könnte."
	)
