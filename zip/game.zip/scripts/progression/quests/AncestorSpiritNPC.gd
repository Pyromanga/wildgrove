extends QuestNPC
class_name AncestorSpiritNPC

## AncestorSpiritNPC — "Ahnengeist Babatunde". Quest-Geber für den Questchain
## quest_babatunde_tale → quest_babatunde_legacy.
##
## Kulturkreis: Yoruba-Egungun-Tradition (Ahnenmaskerade — die Geister der
## Vorfahren kehren zurück, um mit den Lebenden zu sprechen; siehe
## docs/quest-writing-guide.md Abschnitt 1/4 — "Afrikanisch: Ahnengeist als
## Questgeber"). Name bewusst "Babatunde" ("der Vater kehrt zurück") — passt
## wörtlich zur Rolle als wiederkehrender Ahne.
##
## Running Gag (Abschnitt 3, "Der Ahnengeist mit Nachrichten-Rückstand"):
## Babatunde hält eine längst beigelegte Dorf-Fehde für aktuell — siehe
## dialog_completed_text/next_dialog_offer_text unten.
##
## Design-Entscheidung gegen CUSTOM-Objective: QuestCustomTrigger (Area3D) ist
## im aktuellen World-Setup nirgends instanziiert (nur in Tests referenziert —
## dasselbe Muster, das quest_erik_friendship.obj_explore_camp bereits unsichtbar
## macht, siehe dortigen Trigger-Kommentar). Statt eine zweite, gleichermaßen
## unerreichbare CUSTOM-Quest zu bauen, nutzt diese Kette stattdessen zwei
## TALK-Objectives auf BEREITS existierende NPCs (Erik, Mira) — mechanisch
## erprobt (siehe QuestObjectiveHandler.resolve_talk()) UND thematisch passend:
## eine mündlich überlieferte Geschichte weiterzutragen bedeutet hier wörtlich
## "sprich mit den Leuten im Dorf". Verdrahtung von QuestCustomTrigger in die
## Welt bleibt ein offener Folge-Punkt (siehe TODO-Notiz am Ende dieser Datei).
##
## Reward-Framing (quest_babatunde_legacy): reward_items bewusst leer — der
## stat_modifier wird im Dialog explizit als "weitergegebenes Wissen", nicht
## als Beute/Loot präsentiert (siehe docs/quest-writing-guide.md Abschnitt 4,
## Vorschlag "Stat-Modifier als weitergegebenes Wissen geframed").
##
## Gleiches Muster wie MinerNPC/HerbalistNPC/WudangMasterNPC: eigene
## @export-Defaults + 2-stufige Kette über QuestNPC.next_quest_id.

func _init() -> void:
	quest_id            = "quest_babatunde_tale"
	quest_obj_id         = "obj_talk_erik_tale"
	npc_display_name    = "Ahnengeist Babatunde"
	npc_id               = "babatunde_spirit"
	quest_obj_required   = 1
	dialog_offer_text = (
		"Endlich! Wie steht's um\n" +
		"den Streit mit dem Nachbar-\n" +
		"dorf? Erzähl's Erik und Mira."
	)
	dialog_encourage_format = "Noch nicht überall erzählt?\nDie Geschichte wartet\nseit Generationen. Sie kann warten."
	dialog_completed_text = (
		"Ein Streit? Der ist doch...\n" +
		"moment, seit wann ist der\n" +
		"vorbei? Wir müssen reden."
	)

	# Kettenstufe 2 — quest_babatunde_legacy.
	next_quest_id              = "quest_babatunde_legacy"
	next_quest_obj_id          = "obj_reach_forestry_2"
	next_quest_obj_required    = 2
	next_dialog_offer_text = (
		"Vorbei seit drei Generationen.\n" +
		"Peinlich. Zeig mir, dass du\n" +
		"das Wissen des Waldes wert bist."
	)
	next_dialog_encourage_format = "Forstwissen-Stufe %d/%d.\nDie Bäume erinnern sich\nan mehr als ich."
	next_dialog_completed_text = (
		"Gut. Nimm dieses Wissen —\n" +
		"kein Schatz, nur Erinnerung,\n" +
		"weitergereicht."
	)

func _get_body_color() -> Color:
	# Blasses Violett-Grau — geisterhaft, statt Eriks kräftigem Blau.
	return Color(0.52, 0.48, 0.60)

## TODO (Folge-Ticket, kein Teil dieser Quest-Runde): QuestCustomTrigger in
## World.tscn/WorldSpawner verdrahten (aktuell nirgends instanziiert, siehe
## Klassenkommentar oben) — würde auch quest_erik_friendship.obj_explore_camp
## reparieren. Erst DANACH wäre ein echtes CUSTOM-"Ahnenhain erkunden"-Objective
## für Babatunde sinnvoll nachrüstbar.
