extends QuestNPC
class_name HerbalistNPC

## HerbalistNPC — "Kräuterkundige Senna". Quest-Geberin für den neuen
## Foraging-Questchain quest_herbalist_request → quest_herbalist_secret.
##
## Gleiches Muster wie MinerNPC: eigene @export-Defaults + 2-stufige Kette
## über QuestNPC.next_quest_id (siehe dort). Beide neuen Quests wurden mit
## dem projekteigenen content_forge.py-Tool erzeugt (Schema-validiert,
## automatisch in DataManifest.QUESTS registriert).

func _init() -> void:
	quest_id           = "quest_herbalist_request"
	quest_obj_id        = "obj_collect_mushroom"
	npc_display_name   = "Kräuterkundige Senna"
	npc_id              = "senna_herbalist"
	quest_obj_required  = 4
	dialog_offer_text = (
		"Ah, ein Sammler! Ich brauche\n" +
		"4 wilde Pilze und 3 Farnfasern\n" +
		"für meine Tinkturen."
	)
	dialog_encourage_format = "Pilze bisher: %d/%d.\nDie Fasern nicht vergessen!"
	dialog_completed_text = (
		"Wunderbar, genau was ich\n" +
		"brauchte. Danke dir!"
	)

	# Kettenstufe 2 — quest_herbalist_secret.
	next_quest_id             = "quest_herbalist_secret"
	next_quest_obj_id         = "obj_collect_cactus_fiber"
	next_quest_obj_required   = 2
	next_dialog_offer_text = (
		"Weil du so zuverlässig bist,\n" +
		"verrate ich dir mein geheimes\n" +
		"Rezept — bring mir 2 Kaktusfasern."
	)
	next_dialog_encourage_format = "Kaktusfasern: %d/%d.\nDie Wüste ist im Osten."
	next_dialog_completed_text = (
		"Perfekt. Das Rezept gehört\n" +
		"jetzt auch dir, Freund/in."
	)

func _get_body_color() -> Color:
	# Kräuter-Grün statt Eriks Blau — passt zur Kräuterkunde-Rolle.
	return Color(0.30, 0.55, 0.28)
