class_name SkillPanelVisuals

var panel: PanelContainer
var toggle_button: Button
var _skill_labels: Dictionary = {}  # { skill_id: { label, bar, xp_label } }

func _init(parent: CanvasLayer) -> void:
	toggle_button = Button.new()
	toggle_button.name = "SkillToggleButton"
	toggle_button.text = "⚔"
	toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	toggle_button.pressed.connect(toggle)

	panel = PanelContainer.new()
	panel.name = "SkillPanel"
	panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.07, 0.10, 0.94)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)

	UIMetrics.place_sheet(panel, 320)

	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	panel.add_child(vbox)

	var title := Label.new()
	title.text = "Skills"
	title.add_theme_font_size_override("font_size", 20)
	vbox.add_child(title)
	parent.add_child(panel)
	PanelDock.register_in(parent, &"skills", panel, PanelDock.Kind.SHEET, toggle_button)

func update_skill(skill_id: String, level: int, xp: int, xp_needed: int) -> void:
	var vbox := panel.get_child(0) as VBoxContainer
	if not vbox:
		return

	if not _skill_labels.has(skill_id):
		_add_skill_row(vbox, skill_id)

	var row: Dictionary = _skill_labels[skill_id]
	(row["label"] as Label).text = "%s  Lv.%d" % [skill_id.capitalize(), level]
	var bar := row["bar"] as ProgressBar
	bar.max_value = xp_needed
	bar.value = xp
	(row["xp_label"] as Label).text = "%d / %d XP" % [xp, xp_needed]

func _add_skill_row(vbox: VBoxContainer, skill_id: String) -> void:
	var container := VBoxContainer.new()
	container.add_theme_constant_override("separation", 2)

	var name_lbl := Label.new()
	name_lbl.text = skill_id.capitalize()
	name_lbl.add_theme_font_size_override("font_size", 15)
	container.add_child(name_lbl)

	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(200, 14)
	bar.show_percentage = false
	container.add_child(bar)

	var xp_lbl := Label.new()
	xp_lbl.add_theme_font_size_override("font_size", 12)
	xp_lbl.modulate = Color(1, 1, 1, 0.6)
	container.add_child(xp_lbl)

	vbox.add_child(container)
	_skill_labels[skill_id] = {"label": name_lbl, "bar": bar, "xp_label": xp_lbl}

func toggle() -> void:
	panel.visible = !panel.visible
