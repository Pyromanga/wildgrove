extends Service
class_name TelemetryService

## ADR-045: Telemetrie/Crash-Reporting — Telemetrie-Hälfte.
##
## record_event() ist bewusst NUR ein dünner Wrapper um AppLogger.log_trace()
## mit der Kategorie "Telemetry" — KEINE eigene Datei-I/O, KEIN eigener
## Ring-Puffer, KEIN eigener Thread. AppLogger hat das alles bereits
## (NDJSON-Format, Hintergrund-Schreib-Thread, Ring-Puffer, Kategorie-
## basiertes Stummschalten via AppLogger.mute_category("Telemetry")) — ein
## zweites File-I/O-System nur für Telemetrie-Events wäre reine Dopplung.
## Dieser Service liefert nur, was AppLogger NICHT hat: pro-Event-Namen
## aggregierte Zähler für die laufende Sitzung (get_event_counts()) — für
## eine künftige Debug-/Status-Anzeige, ohne den kompletten Log-Ringpuffer
## durchsuchen zu müssen.
##
## KEIN Netzwerk-Upload — es gibt (noch) keinen Telemetrie-Server/-Endpunkt
## im Projekt. Events landen ausschließlich lokal in der bestehenden
## Log-Datei (NDJSON, Kategorie "Telemetry") — filterbar/ingestierbar mit
## denselben Werkzeugen wie der Rest des Logs (Loki/Datadog/ELK, siehe
## AppLogger-Klassenkommentar), sobald ein Upload-Pfad gebraucht wird.
##
## KEINE Persistenz der Zähler — Session-only, setzt bei jedem Neustart
## zurück, analog Chat (ADR-043). Die zugrundeliegenden Rohdaten (die
## einzelnen log_trace()-Aufrufe) überleben dagegen sehr wohl in der
## Log-Datei — nur die AGGREGATION hier ist transient.
##
## Zwei automatische Beispiel-Events (session_start/session_end) sind
## bewusst mit eingebaut, statt den Service komplett ungenutzt zu lassen —
## sonst gäbe es 0 tatsächliche Aufrufer dieser neuen Infrastruktur, exakt
## das Muster, das in früheren Runden (z. B. ADR-042) bewusst vermieden
## wurde, wo es machbar war.
##
## BEWUSST NICHT TEIL DIESER RUNDE: kein Netzwerk-Upload/Endpunkt (siehe
## oben), keine Opt-out-/Datenschutz-Einstellung (bislang rein lokal, kein
## Datenabfluss — sobald ein Upload-Pfad existiert, wird das relevant und
## muss dann nachgezogen werden), kein Dashboard/UI, kein `UIContext`-
## Eintrag (noch keine UI, die ihn bräuchte).

const LOG_CAT := "Telemetry"

## Event-Namen -> Anzahl in dieser Sitzung. Rein transient (siehe
## Klassenkommentar).
var _event_counts: Dictionary = {}

var _session_start_unix: float = 0.0

func configure(_deps: ServiceDeps) -> void:
	_session_start_unix = Time.get_unix_time_from_system()
	AppLogger.log_info("TelemetryService initialisiert.", LOG_CAT)
	record_event("session_start")

func on_cleanup() -> void:
	record_event("session_end", {"duration_sec": get_session_duration_sec()})
	_event_counts.clear()

## Zeichnet ein einzelnes Ereignis auf. `properties` ist ein freies
## Dictionary (muss JSON-serialisierbar sein — AppLogger.log_trace()
## stringifiziert es für die Log-Zeile, siehe dortiger Kommentar zu
## `data_str`). Leere event_name wird stillschweigend ignoriert (kein
## Fehler-Signal nötig — Telemetrie ist nicht kritischer Pfad, ein
## verpasstes Event darf kein Fehlerzustand für den Aufrufer sein).
func record_event(event_name: String, properties: Dictionary = {}) -> void:
	var clean_name := event_name.strip_edges()
	if clean_name.is_empty():
		return
	_event_counts[clean_name] = int(_event_counts.get(clean_name, 0)) + 1
	AppLogger.log_trace(clean_name, properties, LOG_CAT)

## Aggregierte Zähler für die laufende Sitzung. Kopie — Aufrufer dürfen die
## interne Struktur nicht mutieren.
func get_event_counts() -> Dictionary:
	return _event_counts.duplicate()

func get_event_count(event_name: String) -> int:
	return int(_event_counts.get(event_name, 0))

func get_session_duration_sec() -> float:
	return Time.get_unix_time_from_system() - _session_start_unix
