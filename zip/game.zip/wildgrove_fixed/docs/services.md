# WildGrove — Service Registry & EventBus Reference

> **Stand:** v34  
> **Vorgänger:** `scripts/debug/services.md` (v24) — diese Datei ersetzt sie  
> **Pflege:** Bei jedem neuen Service, Signal oder Save-Provider aktualisieren (siehe `CONTRIBUTING.md` Abschnitt 2.7)  
> **⚠ Ableitungs-Warnung:** Diese Datei ist eine *Ableitung* — die eigentliche Source of Truth ist `BootstrapConfig.tres` (Services) und die `*Events.gd`-Dateien (Signals). Ableitungen driften. Wenn diese Datei und der Code widersprechen: **dem Code glauben.** Langfristig ist ein Generator-Tool (Code → Docs) der richtige Fix; bis dahin gilt diese Datei als "ungefähre Übersicht", nicht als präzise Referenz.
>
> **v34 (Session 5):** `CombatSystem` und `StatModifierService` ergänzt — beide waren seit ihrer Einführung (A-07/A-08) nicht in dieser Tabelle. `damage_dealt`-Signal ergänzt. Basisklassen für `InventorySystem`/`SkillSystem`/`QuestService` aktualisiert (A-02-Migration, siehe ADR-003).

---

## 1. Service-Registry

Alle Services werden in `BootstrapConfig.tres` registriert und von `ServiceOrchestrator` in topologischer Reihenfolge gebootet. Die Reihenfolge in dieser Tabelle entspricht der Reihenfolge im Boot.

| Service | Registry-Key | Basisklasse | Verantwortung | Abhängigkeiten |
|---------|-------------|-------------|---------------|----------------|
| `ServiceTicker` | `ticker` | `ServiceNode` | Zentraler Update-Loop für alle `on_tick()`-Services | keine |
| `SceneManager` | `scenemanager` | `ServiceNode` | Szenenwechsel via `transition_to_state()` | keine |
| `SaveSystem` | `savesystem` | `ServiceNode`¹ | JSON-Serialisierung, Provider-Pattern, Disk-IO | keine |
| `DataService` | `data` | `ServiceNode`¹ | Statische Ressourcen: PlayerData, Item-DB, Quest-DB, Skill-DB, CombatProfile-DB | keine |
| `PlayerStateService` | `playerstates` | `ServiceNode`¹ | Mikro-State des Spielers: FREE / BUSY / MENU | keine |
| `SaveMigrationService` | *(statisch)* | `RefCounted` | Versionierte Save-Schema-Migration | keine |
| `SkillSystem` | `skill_system` | `Service` | XP-Kurven, Level-Ups, Skill-Tracking | `data`, `savesystem` |
| `InventorySystem` | `inventory` | `Service` | Item-Add/Remove, Slot/Gewichts-Limits, Save-Provider | `data`, `savesystem` |
| `RewardDispatcher` | `reward_dispatcher` | `ServiceNode` | Verteilt Quest-Rewards an Inventory/Skills | `inventory`, `skill_system` |
| `InteractionExecutor` | `interaction_executor` | `ServiceNode` | Timed-Interaction-Ablauf, Tween-Management | `playerstates` |
| `GameSaveService` | `gamesave` | `ServiceNode` | Koordiniert vollständige Speichervorgänge² | `savesystem` |
| `GameManager` | `gamemanager` | `ServiceNode` | State Machine: BOOT → MENU → PLAYING → … | `savesystem`, `playerstates`, `scenemanager` |
| `WorldGenerationService` | `world_gen` | `ServiceNode` | Seed-basierte prozedurale Welt-Generierung | keine |
| `WorldService` | `world` | `ServiceNode` | Welt-Daten, Tag/Nacht-Zyklus, Entity-Orchestration | `savesystem`, `data` |
| `RespawnService` | `respawn` | `ServiceNode` | Plant geerntete Entities für Respawn ein (Min-Heap) | keine |
| `QuestService` | `quest` | `Service` | Quest-Tracking, Objectives, Rewards | `data`, `savesystem`, `skill_system`, `reward_dispatcher` |
| `StatModifierService` | `stat_modifiers` | `ServiceNode` | Generische Stat-Boni (FLAT_ADD/PERCENT_ADD/PERCENT_MULTIPLY), zeitbasiert | keine |
| `CombatSystem` | `combat` | `ServiceNode` | Schaden-Berechnung (`DamageRecord`, Resistenz, Krit), `apply_damage()` (ADR-008) | `stat_modifiers` |
| `EquipmentService` | `equipment` | `Service` | Ausgerüstete Items pro Slot, Equipment-Boni via StatModifier, WeaponVisual3D-Attachment | `stat_modifiers` |

**¹ Tech Debt (ADR-003):** Diese Services extenden `ServiceNode` (Node), brauchen aber keinen SceneTree-Zugriff. Sollten auf `Service extends RefCounted` migriert werden. (Session 5: `InventorySystem`, `SkillSystem`, `QuestService` migriert — verbleibender Backlog: `DataService`, `SaveSystem`, `PlayerStateService`.)
**² Tech Debt:** Aufteilung zwischen `GameSaveService` und `SaveSystem` ist unklar. Konsolidierung ausstehend.

> **v33:** `HUDManager` wurde aus dem Services-Container entfernt (A-03 ✅). Er lebt jetzt als eigenständiger Node unter `/root`, wird von `WorldService` instanziiert und kommuniziert ausschliesslich über `EventBus.ui`. Kein `Services.hud`-Eintrag mehr.

---

## 2. Entity-System

Nicht über BootstrapConfig registriert — leben im SceneTree unter WorldService.

| Klasse | Pfad | Verantwortung |
|--------|------|---------------|
| `EntityOrchestrator` | `scripts/core/entity/` | Spawn/Despawn/Pool aller World-Entities |
| `EntityPool` | `scripts/core/entity/` | Object-Pool: acquire / release nach type_id |
| `EntityRegistry` | `scripts/core/entity/` | Definition-Verwaltung: script_path + group pro type_id |
| `OakTree` | `scripts/world/objects/` | Fällbarer Baum (mit InteractableComponent) |
| `IronOre` | `scripts/world/objects/` | Abbaubares Erz (mit InteractableComponent) |
| `EnemyNPC` | `scripts/world/combat/` | Gegner mit EnemyAI, HealthComponent |
| `QuestNPC` | `scripts/world/npc/` | Quest-Geber mit DialogController |
| `AnimalBase` | `scripts/world/animals/` | Basis für Deer, Rabbit, Boar |

---

## 3. Save-Provider

| Service | Save-Key | Schema | Gespeicherte Daten |
|---------|----------|--------|-------------------|
| `InventorySystem` | `inventory` | `{ "item_id": quantity }` | Alle Items + Mengen |
| `SkillSystem` | `skills` | `{ "skill_name": { "xp": int, "level": int } }` | XP + Level pro Skill |
| `QuestService` | `quest_progress` | `{ "active": {}, "completed": [], "available": [] }` | Quest-Fortschritt |
| `WorldService` | `world_state` | `{ "day_time", "day_count", "tree_positions", "player_pos", "world_seed" }` | Welt-State |

**Schema-Version:** `SaveMigrationService.CURRENT_VERSION`. Bei jeder Änderung erhöhen + Migration implementieren.

---

## 4. EventBus-Namespaces

> **⚠ Signal-Ownership:** Die Spalte "Empfänger" dokumentiert *wer* sich verbindet — nicht *wer* automatisch getrennt wird. `BaseEvents`-Objekte (alle EventBus-Namespaces) sind `RefCounted`-basiert und trennen Connections **nicht** automatisch beim Freigeben des Empfängers. **Jeder Service der sich in `on_ready()` connected, muss sich in `on_cleanup()` explizit disconnecten.** Fehlt das `disconnect()`, ruft Godot beim nächsten emittierten Signal eine Methode auf einem null-Objekt auf — silent failure oder Crash. Siehe `principles.md` → Abschnitt 3 (Signal-Ownership) für das Code-Pattern.

### `EventBus.system`

| Signal | Parameter | Emittiert von | Empfänger |
|--------|-----------|---------------|-----------|
| `state_changed` | `state: int` | `GameManager` | `PlayerStateService`, `SceneManager` |
| `services_initialized` | — | `ServiceOrchestrator` (Phase 8) | `Player` |
| `boot_failed` | `phase: String, reason: String` | `ServiceOrchestrator` | Debug-UI |
| `save_started` | — | `SaveSystem` | HUD-Feedback |
| `save_completed` | `success: bool` | `SaveSystem` | HUD-Feedback |

### `EventBus.player`

| Signal | Parameter | Emittiert von | Empfänger |
|--------|-----------|---------------|-----------|
| `xp_gained` | `skill: String, amount: int` | `InteractableComponent` | `SkillSystem`, `QuestService` |
| `level_up` | `skill: String, new_level: int` | `SkillSystem` | HUD, Notifications |
| `health_changed` | `current: float, max: float` | `HealthComponent` | HUD |
| `player_died` | — | `Player` | HUD, GameManager |
| `player_respawned` | — | `Player` | HUD |
| `movement_interrupted` | — | `Player` | HUD-Animation |
| `input_reset_requested` | — | `PlayerStateService` | `TouchInput` |
| `speed_modifier_changed` | `id: String, multiplier: float` | extern | `PlayerMover` |
| `speed_modifier_removed` | `id: String` | extern | `PlayerMover` |

### `EventBus.world`

| Signal | Parameter | Emittiert von | Empfänger |
|--------|-----------|---------------|-----------|
| `world_scene_ready` | `world_root: Node3D` | `WorldService` | `EntityOrchestrator`, `HUDManager` (direkt, kein Service-Zugriff) |
| `world_unloaded` | — | `WorldService` | `EntityOrchestrator`, `RespawnService` |
| `entity_spawned` | `type_id: String, entity: Node3D, pos: Vector3` | `EntityOrchestrator` | Debug |
| `entity_despawned` | `type_id: String, uuid: String, pos: Vector3` | `EntityOrchestrator` | `RespawnService` |
| `loot_collected` | `item_id: String, quantity: int` | `InteractableComponent` | `InventorySystem`, `QuestService` |
| `interaction_started` | `label: String, duration: float` | `InteractionExecutor` | HUD-Progressbar |
| `interaction_finished` | `action_id: String, label: String` | `InteractionExecutor` | `QuestService` |
| `interaction_cancelled` | `label: String` | `InteractionExecutor` | HUD |
| `day_started` | `day_count: int` | `WorldTimeService` | UI, Quests |
| `day_time_changed` | `normalized: float` | `WorldTimeService` | Sky-Shader, UI |
| `respawn_scheduled` | `type_id: String, pos: Vector3, at: float` | `RespawnService` | Debug |
| `damage_dealt` | `record: DamageRecord` | `CombatSystem.apply_damage()` | UI (Floating-Text), Logger, zukünftiges Analytics-System |

### `EventBus.quest`

| Signal | Parameter | Emittiert von | Empfänger |
|--------|-----------|---------------|-----------|
| `quest_unlock_requested` | `quest_id: String` | NPCs | `QuestService` |
| `quest_start_requested` | `quest_id: String` | UI | `QuestService` |
| `quest_unlocked` | `quest_id: String` | `QuestService` | HUD |
| `quest_started` | `quest_id: String` | `QuestService` | HUD |
| `quest_completed` | `quest_id: String, reward: QuestReward` | `QuestService` | HUD, Notification |
| `quest_failed` | `quest_id: String` | `QuestService` | HUD |
| `objective_updated` | `quest_id, obj_id, current, required` | `QuestService` | HUD |
| `quest_start_failed` | `quest_id: String, reason: String` | `QuestService` | Debug |

### `EventBus.ui`

| Signal | Parameter | Emittiert von | Empfänger |
|--------|-----------|---------------|-----------|
| `pause_requested` | — | `PauseMenuController` | `GameManager` |
| `resume_requested` | — | `PauseMenuController` | `GameManager` |
| `inventory_open_requested` | — | UI-Button | `HUDManager` |

---

## 5. Boot-Reihenfolge (AutoLoads)

AutoLoads starten in dieser Reihenfolge — fest in `project.godot` konfiguriert:

```
1. Logger              — Muss als erstes starten (alle anderen loggen)
2. EventBus            — Namespaced Signal-Infrastruktur
3. SimpleTerminal      — Debug-Terminal (nur Development-Build)
4. Services            — Typisierter Service-Container (startet leer)
5. ServiceOrchestrator — Startet Boot-Pipeline, befüllt Services
```

---

## 6. Change-Impact-Matrix

Welche Datei hat welche Auswirkung wenn sie geändert wird:

| Datei | Auswirkung |
|-------|-----------|
| `BootstrapConfig.tres` | Boot-Reihenfolge, alle Service-Instanziierungen |
| `Services.gd` | Alle Stellen die `Services.xyz` aufrufen (gesamtes Projekt) |
| `EventBus.gd` + `*Events.gd` | Alle Signal-Connections (grep nach `EventBus.namespace`) |
| `Logger.gd` | Jede einzelne Log-Zeile im Projekt |
| `ServiceOrchestrator.gd` | Komplettes Boot-Verhalten |
| `SaveSystem.gd` | Alle Save-Provider |
| `SaveMigrationService.gd` | Alle gespeicherten Spielstände |
| `EntityContext.gd` | Alle Entities die `on_spawn(config, ctx)` implementieren |
| `NetworkContract.gd` | Dokumentation der Authority-Grenzen (kein Runtime-Code) |
