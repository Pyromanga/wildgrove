# ADR-007: INetworkAdapter-Interface und LocalNetworkAdapter als Offline-Stub

**Status:** Abgelöst von ADR-010 (Session 8)
**Datum:** 2026-06

## Entscheidung

Eine `INetworkAdapter`-Schicht wurde zwischen `request_*()` und `on_*_confirmed()` eingezogen,
mit einem `LocalNetworkAdapter` der die Anfragen lokal synchron durchleitet (kein echtes Netz).

## Warum abgelöst

Die Adapter-Abstraktion trennte zwar `request_*()` von `on_*_confirmed()`, löste aber nicht,
wer die Autorität ist und wie State pro Spieler getrennt wird. Sie baute parallel etwas nach,
das Godots `MultiplayerAPI` bereits liefert.

ADR-010 ersetzt diesen Ansatz: direkte `@rpc`-Methoden, Godots `multiplayer_authority`,
`NetworkBridge.gd` als einziger RPC-Node für RefCounted-Services.
