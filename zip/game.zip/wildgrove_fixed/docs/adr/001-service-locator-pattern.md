# ADR-001: Service Locator statt vollständigem DI-Container

**Status:** Akzeptiert  
**Datum:** 2026-06  
**Kontext:** Alle Services, alle Entities, gesamte Boot-Infrastruktur

---

## Problem

Services müssen ihre Abhängigkeiten bekommen. Die klassischen Optionen sind Constructor-Injection (vollständiges DI) oder ein Service-Locator-Singleton. GDScript hat keine Konstruktoren im C#/Java-Sinne — `_init()` existiert zwar, aber der SceneTree ist zu diesem Zeitpunkt nicht verfügbar, und `ServiceNode`-Instanzen werden von der `ServiceFactory` via `load(script_path).new()` erzeugt, nicht durch direkten Konstruktoraufruf.

---

## Optionen

### Option A: Vollständiger DI-Container (Constructor Injection)
Jede Klasse deklariert ihre Deps als Konstruktor-Parameter.  
- ✅ Maximale Explizitheit, testbar ohne globalen State  
- ❌ GDScript `_init()` hat keine Typ-Annotationen auf Parametern bis GDScript 4.x  
- ❌ `ServiceFactory` müsste Dependency-Graph auflösen *bevor* sie instanziiert — Henne-Ei-Problem mit `Node.add_child()`  
- ❌ Jede Klasse müsste alle ihre Deps als init-Parameter vorhalten → massives Refactoring-Risiko bei Dep-Änderungen

### Option B: Service Locator (`Services.xyz`)
Ein AutoLoad-Singleton hält alle registrierten Services. Jeder Code kann `Services.inventory` aufrufen.
- ✅ Einfach, GDScript-nativ, keine Infrastruktur notwendig  
- ✅ Funktioniert mit Godot's Node-Lifecycle  
- ❌ Abhängigkeiten sind implizit — man sieht nicht, was eine Klasse braucht  
- ❌ Tests brauchen den echten Container oder aufwändiges Mocking des AutoLoads  
- ❌ Jede Klasse kann jeden Service aufrufen — keine Schicht-Erzwingung

### Option C: Hybrid — DI in configure(), Service Locator als Fallback (gewählt)
Services bekommen ihre Deps explizit via `configure(deps: Dictionary)` injiziert. Der `Services`-Singleton existiert als typisierter Accessor, aber die Konvention erzwingt, dass er nur aus bestimmten Schichten aufgerufen wird.

- ✅ DI für Services — Deps sind in `configure()` explizit und sichtbar  
- ✅ `EntityContext`-Pattern erlaubt Entities ihre Services ohne direkten `Services.xyz`-Zugriff zu bekommen  
- ✅ Testbar: `EntityContext.for_test()` injiziert Mock-Objekte  
- ⚠️ Service Locator bleibt als Escape-Hatch — muss durch Konvention eingeschränkt werden

---

## Entscheidung

**Option C** — Hybrid-Pattern.

Services erhalten ihre Abhängigkeiten via `configure(deps)` (echte DI). Entities erhalten ihren Service-Zugriff via `EntityContext`-Injection in `on_spawn(config, ctx)`. Der `Services`-Singleton ist nur für `ServiceNode`-Implementierungen in `on_ready()` erlaubt, nicht für Entities oder Components.

---

## Konsequenzen

### Positiv
- Service-Abhängigkeiten sind in `configure()` vollständig sichtbar und typisiert
- Topological Sort (Kahn's Algorithmus im `ServiceDependencyResolver`) erzwingt korrekte Boot-Reihenfolge
- `EntityContext.for_test()` ermöglicht isolierte Entity-Tests ohne globalen State

### Negativ / Risiken
- `Services.xyz` ist als globales Singleton verfügbar — Konvention kann gebrochen werden
- Keine compile-time Erzwingung der Schichten-Regel

### Mitigationen
- `CONTRIBUTING.md` Abschnitt 2.1: `Services.xyz` aus Entities/Components ist Review-Blocker
- `NetworkContract.gd` dokumentiert welche Systeme server-autoritativ sind
- `EntityContext` als verpflichtetes Injection-Pattern für alle Entities
- Zukünftig: statischer Analyzer oder GDScript-Linter-Plugin um direkten `Services.xyz`-Zugriff in Entity-Klassen zu detektieren

---

## Ablösung

**Trigger-Bedingung für Obsoleszenz:** Dieser ADR wird ablösungsreif wenn GDScript typisierte Constructor-Parameter mit vollständiger Typ-Annotation bekommt *und* `ServiceFactory` diese ohne SceneTree-Abhängigkeit auflösen kann. In diesem Fall wäre echter Constructor-Injection ohne Workaround möglich — ADR-007 würde die Migrationsstrategie dokumentieren.

Solange GDScript diese Fähigkeit nicht hat, bleibt der Kompromiss (Hybrid mit `configure(deps)`) die beste verfügbare Option.

**Revisit:** Bei jeder neuen Godot-Hauptversion (5.x, 6.x) prüfen ob `_init()` Typ-annotierte Parameter unterstützt. Wenn ja: Ablösung initiieren.
