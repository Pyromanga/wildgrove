# ADR-004: request_/on_*_confirmed als Networking-Kontrakt

**Status:** Akzeptiert  
**Datum:** 2026-06  
**Kontext:** Alle server-autoritativen Systeme: InventorySystem, QuestService, SkillSystem, EntityOrchestrator, PlayerStateService

---

## Problem

WildGrove ist als MMORPG konzipiert. In einem MMORPG muss der Server die einzige Autorität über spielkritischen State sein — Inventar, Quest-Fortschritt, XP, Entities. Wenn ein Client direkt `_items["gold"] += 1000` schreibt, ist das ein Cheating-Vektor.

Das Problem: Zum jetzigen Zeitpunkt gibt es keinen Netzwerk-Layer. Alle Logik läuft lokal. Wenn der Netzwerk-Layer in einem Jahr kommt, müssten alle State-Mutationen umgeschrieben werden — an Stellen die in der gesamten Codebase verteilt sind.

---

## Optionen

### Option A: Direkte State-Mutation jetzt, Refactor später
`_items[id] += qty` direkt im Handler. Wenn Netzwerk kommt: alles umschreiben.
- ✅ Einfach jetzt  
- ❌ Der "später"-Refactor trifft jeden Service, jede Mutation, jede Stelle — unkontrollierbar bei wachsender Codebase

### Option B: Jetzt schon Server-Code schreiben (Overkill)
Vollständige Server/Client-Trennung mit RPCs, Godot Multiplayer API, etc.
- ✅ Korrekt für Multiplayer  
- ❌ Massiver Overhead bevor der erste Gameplay-Loop fertig ist  
- ❌ Erfordert laufende Server-Infrastruktur für Singleplayer-Testing

### Option C: Naming-Convention als Kontrakt (gewählt)
`request_*()` für Client-seitige Anfragen (werden später zum Server gehen).  
`on_*_confirmed()` für State-Mutation (wird später Server-RPC-Handler sein).  
Heute: `request_add_item()` ruft direkt `on_item_add_confirmed()` auf — lokal und synchron.  
Morgen: `request_add_item()` sendet an Server, Server ruft `on_item_add_confirmed()` via RPC.

---

## Entscheidung

**Option C.** Die Konvention ist dokumentiert in `NetworkContract.gd`. Die Implementation heute ist synchron und lokal — aber die Trennlinie ist gezogen. Wenn der Netzwerk-Layer kommt, ändert sich nur der Body von `request_*()`, nicht die Methode oder ihre Aufrufer.

**Regeln:**
- `request_*()` — darf nur validieren und weiterleiten, niemals direkt State mutieren
- `on_*_confirmed()` — einzige Methode die internen State direkt schreibt
- Kein Code außerhalb dieser beiden Methoden mutiert den State

**Server-autoritative Systeme** (Pflicht für das Pattern):
- `InventorySystem` — `request_add_item()` / `on_item_add_confirmed()`
- `QuestService` — `start_quest()` / `complete_quest()` (noch nicht umbenannt — bekannter Tech Debt)
- `SkillSystem` — `add_xp()` (noch nicht umbenannt — bekannter Tech Debt)
- `EntityOrchestrator` — `spawn_entity()` / `despawn_entity()`
- `PlayerStateService` — `set_state()` (state ist flüchtig, niedrige Priorität)

---

## Konsequenzen

### Positiv
- State-Mutation ist in jeder server-autoritativen Klasse auf eine einzige Methode isoliert
- Netzwerk-Integration erfordert keinen Refactor der Aufrufer
- `NetworkContract.assert_server_authoritative_uses_request_pattern()` kann in Tests validiert werden

### Negativ / Risiken
- `QuestService` und `SkillSystem` haben die Konvention noch nicht vollständig umgesetzt (Tech Debt, dokumentiert)
- Mehr Boilerplate pro Mutation-Methode

### Mitigationen
- `CONTRIBUTING.md` Abschnitt 2.3: Verletzung des Patterns ist Review-Blocker
- `NetworkContract.gd` als lebendiges Dokument mit expliziter Authority-Matrix
- Tech Debt für `QuestService` und `SkillSystem` in diesem ADR vermerkt, nicht in einem separaten TODO-File

---

## Ablösung

**Trigger-Bedingung für Obsoleszenz:** Dieser ADR wird durch einen Netzwerk-ADR (ADR-00X) abgelöst sobald ein echter Netzwerk-Layer implementiert wird. Zu diesem Zeitpunkt wird der Body von `request_*()` von einem lokalen Direktaufruf zu einem Server-RPC geändert — die Konvention bleibt, die Implementation darunter wechselt.

**Offene Tech Debt (Revisit-Pflicht):** `QuestService` und `SkillSystem` verwenden noch nicht vollständig das `request_/confirmed_`-Muster. Diese Schuld muss abgearbeitet sein *bevor* ein Netzwerk-Layer hinzukommt — danach wird das Nachrüsten deutlich teurer. Spätester Revisit-Termin: Beginn des Netzwerk-Sprints.
