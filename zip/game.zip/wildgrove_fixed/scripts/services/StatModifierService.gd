# res://scripts/services/StatModifierService.gd
extends ServiceNode
class_name StatModifierService

## StatModifierService — Akkumuliert Stat-Modifier und berechnet Effektivwerte.
##
## Löst A-07: Equipment-Boni, Buffs, Debuffs und Auren brauchen ein Fundament
## bevor das erste Equipment implementiert wird. Danach wäre die Migration teurer.
##
## DESIGN:
##   - Modifier werden per source_id verwaltet → jede Quelle hat genau einen Modifier
##     pro Stat (oder keinen). Equipment kann NICHT denselben source_id zweimal belegen.
##   - Expired-Cleanup läuft on_tick() — kein separater Thread, kein Timer.
##   - get_effective_stat() ist O(n) in der Anzahl aktiver Modifier — bei typischen
##     Game-Szenarien (< 50 Modifier) vernachlässigbar.
##
## OPERATIONSREIHENFOLGE:
##   1. base_value
##   2. + sum(FLAT_ADD.value)
##   3. × (1.0 + sum(PERCENT_ADD.value))
##   4. × product(PERCENT_MULTIPLY.value)
##
## VERWENDUNG:
##   Services.stat_modifiers.add_modifier(
##       StatModifier.permanent("equipment_sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
##   )
##   var damage := Services.stat_modifiers.get_effective_stat("damage", base_damage)
##   Services.stat_modifiers.remove_modifier("equipment_sword")

const LOG_CAT := "StatModifiers"

## Alle aktiven Modifier: source_id → StatModifier
var _modifiers: Dictionary = {}

## Emittiert wenn ein Modifier hinzugefügt, entfernt oder durch Ablauf entfernt wurde.
## Listener (z.B. PlayerStats-UI, SkillSystem) können Werte neu berechnen.
signal modifier_changed(stat: String)


# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────

func configure(_deps: Dictionary) -> void:
	Logger.log_debug("Konfiguriert.", LOG_CAT)


func on_ready() -> void:
	Logger.log_info("StatModifierService bereit.", LOG_CAT)


func on_cleanup() -> void:
	_modifiers.clear()
	Logger.log_info("StatModifierService cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Fügt einen Modifier hinzu oder überschreibt einen bestehenden mit derselben source_id.
## Gibt false zurück wenn source_id leer ist (Validierungsfehler).
func add_modifier(modifier: StatModifier) -> bool:
	if modifier.source_id.is_empty():
		Logger.log_error("add_modifier: source_id darf nicht leer sein!", LOG_CAT)
		return false
	if modifier.stat.is_empty():
		Logger.log_error("add_modifier: stat darf nicht leer sein!", LOG_CAT)
		return false

	var was_overwrite := _modifiers.has(modifier.source_id)
	_modifiers[modifier.source_id] = modifier

	Logger.log_debug(
		"%s %s" % ["Überschrieben:" if was_overwrite else "Hinzugefügt:", modifier.to_debug_string()],
		LOG_CAT
	)
	modifier_changed.emit(modifier.stat)
	return true


## Entfernt einen Modifier anhand der source_id.
## Gibt false zurück wenn kein Modifier mit dieser ID gefunden wurde.
func remove_modifier(source_id: String) -> bool:
	if not _modifiers.has(source_id):
		Logger.log_warn("remove_modifier('%s'): nicht gefunden." % source_id, LOG_CAT)
		return false

	var stat: String = (_modifiers[source_id] as StatModifier).stat
	_modifiers.erase(source_id)

	Logger.log_debug("Entfernt: '%s' (stat: %s)" % [source_id, stat], LOG_CAT)
	modifier_changed.emit(stat)
	return true


## Berechnet den effektiven Wert eines Stats mit allen aktiven Modifiern.
## base_value: der unmodifizierte Basiswert (z.B. aus PlayerStats oder ItemDefinition).
## stat: der Stat-Bezeichner (snake_case, z.B. "move_speed", "damage").
##
## Gibt base_value zurück wenn keine Modifier für diesen Stat registriert sind.
func get_effective_stat(stat: String, base_value: float) -> float:
	var flat_sum:      float = 0.0
	var percent_sum:   float = 0.0
	var multiply_prod: float = 1.0

	for source_id in _modifiers:
		var mod: StatModifier = _modifiers[source_id]
		if mod.stat != stat:
			continue
		if not mod.is_active():
			continue

		match mod.operation:
			StatModifier.Operation.FLAT_ADD:
				flat_sum += mod.value
			StatModifier.Operation.PERCENT_ADD:
				percent_sum += mod.value
			StatModifier.Operation.PERCENT_MULTIPLY:
				multiply_prod *= mod.value

	return (base_value + flat_sum) * (1.0 + percent_sum) * multiply_prod


## Gibt alle aktiven Modifier für einen bestimmten Stat zurück.
## Nützlich für UI (z.B. Tooltip mit Modifier-Aufschlüsselung).
func get_modifiers_for_stat(stat: String) -> Array[StatModifier]:
	var result: Array[StatModifier] = []
	for source_id in _modifiers:
		var mod: StatModifier = _modifiers[source_id]
		if mod.stat == stat and mod.is_active():
			result.append(mod)
	return result


## Gibt true zurück wenn ein Modifier mit dieser source_id aktiv ist.
func has_modifier(source_id: String) -> bool:
	return _modifiers.has(source_id) and (_modifiers[source_id] as StatModifier).is_active()


## Entfernt alle Modifier einer Quelle die mit einem Präfix beginnen.
## Nützlich wenn ein Item-Set mehrere Modifier mit demselben Präfix belegt hat
## z.B. remove_modifiers_with_prefix("equipment_") entfernt alle Equipment-Boni.
func remove_modifiers_with_prefix(prefix: String) -> int:
	var to_remove: Array[String] = []
	for source_id in _modifiers:
		if source_id.begins_with(prefix):
			to_remove.append(source_id)

	var affected_stats: Array[String] = []
	for source_id in to_remove:
		var stat: String = (_modifiers[source_id] as StatModifier).stat
		_modifiers.erase(source_id)
		if not affected_stats.has(stat):
			affected_stats.append(stat)

	for stat in affected_stats:
		modifier_changed.emit(stat)

	if to_remove.size() > 0:
		Logger.log_debug(
			"Entfernt %d Modifier mit Präfix '%s'." % [to_remove.size(), prefix],
			LOG_CAT
		)
	return to_remove.size()


## Entfernt alle abgelaufenen Modifier und emittiert modifier_changed für betroffene Stats.
## Wird vom ServiceTicker aufgerufen wenn ITickable implementiert ist.
## Kann auch manuell aufgerufen werden (z.B. in on_ready() nach einem Load).
func cleanup_expired() -> int:
	var to_remove: Array[String] = []
	var affected_stats: Array[String] = []

	for source_id in _modifiers:
		var mod: StatModifier = _modifiers[source_id]
		if not mod.is_active():
			to_remove.append(source_id)
			if not affected_stats.has(mod.stat):
				affected_stats.append(mod.stat)

	for source_id in to_remove:
		_modifiers.erase(source_id)

	for stat in affected_stats:
		modifier_changed.emit(stat)

	if to_remove.size() > 0:
		Logger.log_debug("Expired Modifier entfernt: %d." % to_remove.size(), LOG_CAT)
	return to_remove.size()


# ─────────────────────────────────────────────
# Debug-API
# ─────────────────────────────────────────────

## Gibt alle aktiven Modifier als lesbare Liste zurück. Für Terminal-Commands.
func get_debug_report() -> Array[String]:
	var result: Array[String] = []
	for source_id in _modifiers:
		result.append((_modifiers[source_id] as StatModifier).to_debug_string())
	return result
