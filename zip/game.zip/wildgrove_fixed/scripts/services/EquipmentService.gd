# res://scripts/services/EquipmentService.gd
extends Service
class_name EquipmentService

## EquipmentService — Verwaltet ausgerüstete Items pro Slot.
##
## DESIGN: Slot-basiert (String-Key wie "weapon"), nicht hart auf "die eine
## Waffe" verdrahtet. Jeder Slot bekommt seine eigene StatModifier-source_id
## ("equipment_<slot>") und sein eigenes optionales 3D-Visual — verschiedene
## Slots überschreiben sich dadurch nie gegenseitig, sie koexistieren parallel
## (genau wie StatModifierService bereits mehrere parallele source_ids pro Stat
## erlaubt, siehe StatModifierService.gd OPERATIONSREIHENFOLGE). Equip in einem
## Slot tauscht nur das Item *in diesem einen Slot* — alle anderen Slots und
## alle anderen Buff-/Debuff-Quellen (Skills, Tränke, Status-Effekte über
## CombatSystem) bleiben unberührt.
##
## VERANTWORTUNG:
##   equip()/unequip()        → Item in einen Slot setzen/entfernen.
##   get_equipped_weapon()    → Bequemlichkeits-Accessor für CombatSystem —
##                                siehe WeaponDefinition.gd: "player_melee_damage()
##                                liest diesen Wert und ruft apply_poison()/
##                                apply_burn() wenn gesetzt." Diese Verdrahtung
##                                selbst ist noch nicht Teil dieses Schritts
##                                (reines Fundament, analog CombatSystem TD-12).
##
## NICHT VERANTWORTLICH für:
##   - Inventar-Abzug beim Equip (InventorySystem bleibt Quelle der Wahrheit
##     über Item-Besitz — Verdrahtung "equip aus Inventar" ist UI-/Interaction-
##     Schicht, nicht dieser Service)
##   - Persistenz (kein ISaveProvider — Equipment geht bei Session-Ende
##     verloren, wie StatModifierService es auch tut. Absichtlich nicht
##     Teil dieses Schritts.)
##   - Multi-Tenanz (kein player_id-Parameter wie bei den fünf MIGRATION-010-
##     Services — EquipmentService existiert noch nicht zum Zeitpunkt von
##     Phase 1 und ist bewusst außerhalb von deren Scope. Wird nachgezogen
##     wenn Tier 2 (Phase 4) real verdrahtet wird, nicht vorher.)
##
## VERWENDUNG:
##   Services.equipment.equip("weapon", iron_sword_def, player.visuals)
##   Services.equipment.unequip("weapon")
##   var weapon := Services.equipment.get_equipped_weapon()  # für CombatSystem

const LOG_CAT := "Equipment"

## Präfix für StatModifier-source_ids dieses Service — ermöglicht Komplett-
## Cleanup über StatModifierService.remove_modifiers_with_prefix() statt
## jeden Slot einzeln zu tracken.
const SOURCE_PREFIX := "equipment_"

## Aktuell einziger genutzter Slot. Bewusst als String (nicht Enum) angelegt —
## künftige Slots (Rüstung, Ringe, ...) sollen ohne Enum-Erweiterung dazukommen.
const SLOT_WEAPON := "weapon"

var _stat_modifiers: StatModifierService = null

## slot (String) → ItemDefinition.
var _equipped: Dictionary = {}

## slot (String) → WeaponVisual3D. Getrennt von _equipped gehalten, weil nicht
## jedes Item ein 3D-Visual hat (z.B. künftige Ringe).
var _visuals: Dictionary = {}

## Emittiert wenn ein Slot equipped/unequipped wurde. item_def == null bei unequip.
## Kein EventBus-Signal (analog StatModifierService.modifier_changed) — Listener
## verbinden sich direkt über Services.equipment.equipment_changed.
signal equipment_changed(slot: String, item_def: ItemDefinition)


# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	_stat_modifiers = deps.get("stat_modifiers") as StatModifierService
	if not is_instance_valid(_stat_modifiers):
		Logger.log_debug("StatModifierService nicht in deps — Equipment-Boni nicht verfügbar.", LOG_CAT)
	Logger.log_info("EquipmentService konfiguriert.", LOG_CAT)


func on_ready() -> void:
	Logger.log_info("EquipmentService bereit.", LOG_CAT)


func on_cleanup() -> void:
	for slot in _visuals.keys():
		var wv: WeaponVisual3D = _visuals[slot]
		if is_instance_valid(wv):
			wv.detach()
			wv.queue_free()
	_visuals.clear()

	if is_instance_valid(_stat_modifiers):
		_stat_modifiers.remove_modifiers_with_prefix(SOURCE_PREFIX)

	_equipped.clear()
	Logger.log_info("EquipmentService cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Rüstet item_def in slot aus. Slots sind exklusiv (ein zweites equip() auf
## denselben Slot ruft zuerst unequip() auf jenem Slot auf — symmetrisch zu
## StatModifierService.add_modifier()'s "überschreibt bei gleicher source_id").
## Verschiedene Slots sind NICHT exklusiv zueinander — siehe Klassen-Kommentar.
##
## [param visuals] Optional — nur nötig wenn item_def ein 3D-Visual besitzt
## (aktuell: WeaponDefinition → WeaponVisual3D am hand_r-Bone). null ist
## gültig für Items ohne Visual oder in Tests ohne PlayerVisuals-Setup.
## [return] false bei ungültigen Parametern (leerer Slot-Name, ungültiges Item).
func equip(slot: String, item_def: ItemDefinition, visuals: PlayerVisuals = null) -> bool:
	if slot.is_empty():
		Logger.log_error("equip: slot darf nicht leer sein!", LOG_CAT)
		return false
	if not is_instance_valid(item_def):
		Logger.log_error("equip: item_def ungültig.", LOG_CAT)
		return false

	unequip(slot)

	_equipped[slot] = item_def
	_apply_stat_bonus(slot, item_def)

	if item_def is WeaponDefinition and is_instance_valid(visuals):
		var wv := WeaponVisual3D.new()
		wv.attach_to(visuals, item_def as WeaponDefinition)
		_visuals[slot] = wv

	Logger.log_info("Ausgerüstet: '%s' in Slot '%s'." % [item_def.display_name, slot], LOG_CAT)
	equipment_changed.emit(slot, item_def)
	return true


## Entfernt das Item aus slot. Räumt StatModifier + Visual symmetrisch ab —
## dieselbe Disziplin wie B-02/B-03 (review.md) bei EventBus-Connections.
## [return] false wenn der Slot bereits leer war.
func unequip(slot: String) -> bool:
	if not _equipped.has(slot):
		return false

	if is_instance_valid(_stat_modifiers):
		_stat_modifiers.remove_modifier(_source_id(slot))

	if _visuals.has(slot):
		var wv: WeaponVisual3D = _visuals[slot]
		if is_instance_valid(wv):
			wv.detach()
			wv.queue_free()
		_visuals.erase(slot)

	var removed: ItemDefinition = _equipped[slot]
	_equipped.erase(slot)

	Logger.log_info("Entfernt: '%s' aus Slot '%s'." % [removed.display_name, slot], LOG_CAT)
	equipment_changed.emit(slot, null)
	return true


## Gibt das ausgerüstete Item in slot zurück, oder null wenn leer.
func get_equipped(slot: String) -> ItemDefinition:
	return _equipped.get(slot)


## Bequemlichkeits-Accessor für CombatSystem (siehe Klassen-Kommentar oben).
## [return] null wenn der Slot leer ist oder kein WeaponDefinition enthält.
func get_equipped_weapon(slot: String = SLOT_WEAPON) -> WeaponDefinition:
	var item: ItemDefinition = _equipped.get(slot)
	return item as WeaponDefinition if item is WeaponDefinition else null


func is_equipped(slot: String) -> bool:
	return _equipped.has(slot)


# ─────────────────────────────────────────────
# Debug-API
# ─────────────────────────────────────────────


## Gibt alle aktuell belegten Slots als lesbare Liste zurück. Für Terminal-Commands.
func get_debug_report() -> Array[String]:
	var result: Array[String] = []
	for slot in _equipped:
		var item: ItemDefinition = _equipped[slot]
		result.append("[%s] %s" % [slot, item.display_name])
	return result


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _source_id(slot: String) -> String:
	return SOURCE_PREFIX + slot


## Übersetzt die Boni eines ausgerüsteten Items in StatModifier(e). Aktuell nur
## WeaponDefinition.damage_bonus — erweiterbar sobald weitere Definition-Typen
## (Armor, Ring, ...) eigene Bonus-Felder bekommen. Mehrere Slots, die alle
## auf denselben Stat ("damage_bonus") einzahlen, addieren sich automatisch
## über StatModifierService.get_effective_stat() — kein Sonderfall nötig.
func _apply_stat_bonus(slot: String, item_def: ItemDefinition) -> void:
	if not is_instance_valid(_stat_modifiers):
		return
	if item_def is WeaponDefinition:
		var weapon := item_def as WeaponDefinition
		if weapon.damage_bonus != 0.0:
			_stat_modifiers.add_modifier(StatModifier.permanent(
				_source_id(slot), "damage_bonus", StatModifier.Operation.FLAT_ADD, weapon.damage_bonus
			))
