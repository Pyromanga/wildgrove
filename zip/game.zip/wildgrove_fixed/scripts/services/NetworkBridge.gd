extends ServiceNode
class_name NetworkBridge

## NetworkBridge — RPC-Empfangsstelle für alle RefCounted-Services.
##
## MIGRATION-010 Phase 2:
## Godots RPC-System ist an Node gebunden. InventorySystem, QuestService,
## SkillSystem und PlayerStateService sind bewusst RefCounted (ADR-003).
## Dieser ServiceNode ist die einzige dünne Node-Schicht, die @rpc-Methoden
## hostet und intern an die vier Services delegiert.
##
## CombatSystem und EntityOrchestrator sind bereits Node-basiert und bekommen
## ihre @rpc-Methoden in Phase 4 direkt auf sich selbst.
##
## TIER 1 (Solo): Kein MultiplayerPeer → kein RPC nötig.
##   request_*()-Methoden in den Services rufen on_*_confirmed() direkt auf.
##   Diese Datei existiert, wird aber nie als RPC-Empfänger aktiv.
##
## TIER 2/3: request_*() rufen:
##   NetworkBridge.rpc_id(get_multiplayer_authority(), "_rpc_add_item", item_id, qty)
##   → _rpc_add_item() läuft auf der Autorität (Host/Server)
##   → ruft Services.inventory.on_item_add_confirmed() auf
##
## call_local=true bei @rpc: Autorität führt die Confirm-Methode auch lokal aus
## (für das eigene UI des Hosts in Tier 2 — kein zweiter lokaler Aufruf nötig).

const LOG_CAT := "NetworkBridge"

var _inventory:     InventorySystem    = null
var _quest:         QuestService       = null
var _skill_system:  SkillSystem        = null
var _player_states: PlayerStateService = null


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────

func configure(deps: Dictionary) -> void:
	_inventory     = deps.get("inventory")     as InventorySystem
	_quest         = deps.get("quest")         as QuestService
	_skill_system  = deps.get("skill_system")  as SkillSystem
	_player_states = deps.get("playerstates")  as PlayerStateService
	Logger.log_info("NetworkBridge konfiguriert.", LOG_CAT)


func on_ready() -> void:
	Logger.log_info(
		"NetworkBridge bereit. Peer gesetzt: %s" % str(multiplayer.has_multiplayer_peer()),
		LOG_CAT
	)


func on_cleanup() -> void:
	Logger.log_info("NetworkBridge cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# RPC-Methoden — Inventory
# ─────────────────────────────────────────────

## Empfängt RPC von einem Client, der ein Item hinzufügen möchte.
## Nur die Autorität (Host/Server) mutiert den State.
@rpc("any_peer", "call_local", "reliable")
func _rpc_add_item(item_id: String, qty: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_inventory):
		_inventory.on_item_add_confirmed(item_id, qty, player_id)
	else:
		Logger.log_error("_rpc_add_item: InventorySystem nicht verfügbar!", LOG_CAT)


# ─────────────────────────────────────────────
# RPC-Methoden — Quest
# ─────────────────────────────────────────────

@rpc("any_peer", "call_local", "reliable")
func _rpc_start_quest(quest_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_quest):
		_quest._on_quest_start_confirmed({"quest_id": quest_id, "player_id": player_id})
	else:
		Logger.log_error("_rpc_start_quest: QuestService nicht verfügbar!", LOG_CAT)


@rpc("any_peer", "call_local", "reliable")
func _rpc_complete_quest(quest_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_quest):
		_quest._on_quest_complete_confirmed({"quest_id": quest_id, "player_id": player_id})
	else:
		Logger.log_error("_rpc_complete_quest: QuestService nicht verfügbar!", LOG_CAT)


# ─────────────────────────────────────────────
# RPC-Methoden — Skill
# ─────────────────────────────────────────────

@rpc("any_peer", "call_local", "reliable")
func _rpc_add_xp(skill_name: String, amount: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_skill_system):
		_skill_system._on_xp_add_confirmed({"skill_name": skill_name, "amount": amount, "player_id": player_id})
	else:
		Logger.log_error("_rpc_add_xp: SkillSystem nicht verfügbar!", LOG_CAT)


# ─────────────────────────────────────────────
# RPC-Methoden — PlayerState
# ─────────────────────────────────────────────

@rpc("any_peer", "call_local", "reliable")
func _rpc_set_state(state: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_player_states):
		_player_states.set_state(state as PlayerStateService.State, player_id)
	else:
		Logger.log_error("_rpc_set_state: PlayerStateService nicht verfügbar!", LOG_CAT)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

## Gibt true zurück wenn dieser Peer die Autorität ist (oder kein Peer gesetzt → Tier 1).
func _is_authority() -> bool:
	return not multiplayer.has_multiplayer_peer() or multiplayer.is_server()


## Gibt die peer_id des Senders zurück. 0 = lokaler Aufruf → player_id 1 (Tier 1 / Host selbst).
func _sender_as_player_id() -> int:
	var sender := multiplayer.get_remote_sender_id()
	return sender if sender != 0 else 1
