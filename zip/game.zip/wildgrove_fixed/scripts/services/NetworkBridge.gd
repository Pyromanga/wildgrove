extends ServiceNode
class_name NetworkBridge

## NetworkBridge — RPC-Empfangsstelle + Host/Join-API für alle RefCounted-Services.
##
## TIER 1 (Solo): Kein MultiplayerPeer → kein RPC nötig.
##   request_*()-Methoden in den Services rufen on_*_confirmed() direkt auf.
##
## TIER 2 (Hosted Coop): Host ruft host_game(port), Clients rufen join_game(ip, port).
##   request_*() rufen rpc_id(1, "_rpc_*", ...) auf.
##   NetworkBridge empfängt auf der Autorität (peer_id=1) und delegiert an Services.
##
## TIER 3 (Dedicated Server): Identisch zu Tier 2, Server ist kein spielender Client.

const LOG_CAT := "NetworkBridge"

const DEFAULT_PORT    := 7777
const MAX_CLIENTS     := 8

var _inventory:     InventorySystem    = null
var _quest:         QuestService       = null
var _skill_system:  SkillSystem        = null
var _player_states: PlayerStateService = null

## Signale für UI/GameManager
signal player_connected(peer_id: int)
signal player_disconnected(peer_id: int)
signal connection_failed()
signal server_disconnected()


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────

func configure(deps: Dictionary) -> void:
	_inventory     = deps.get("inventory")     as InventorySystem
	_quest         = deps.get("quest")         as QuestService
	_skill_system  = deps.get("skill_system")  as SkillSystem
	_player_states = deps.get("playerstates")  as PlayerStateService
	Logger.log_info("NetworkBridge konfiguriert.", LOG_CAT)


func on_ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	var peer_set := _has_peer()
	Logger.log_info("NetworkBridge bereit. Peer gesetzt: %s" % str(peer_set), LOG_CAT)


func on_cleanup() -> void:
	if multiplayer.peer_connected.is_connected(_on_peer_connected):
		multiplayer.peer_connected.disconnect(_on_peer_connected)
	if multiplayer.peer_disconnected.is_connected(_on_peer_disconnected):
		multiplayer.peer_disconnected.disconnect(_on_peer_disconnected)
	if multiplayer.connected_to_server.is_connected(_on_connected_to_server):
		multiplayer.connected_to_server.disconnect(_on_connected_to_server)
	if multiplayer.connection_failed.is_connected(_on_connection_failed):
		multiplayer.connection_failed.disconnect(_on_connection_failed)
	if multiplayer.server_disconnected.is_connected(_on_server_disconnected):
		multiplayer.server_disconnected.disconnect(_on_server_disconnected)
	close()
	Logger.log_info("NetworkBridge cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# Host / Join API (Phase 4)
# ─────────────────────────────────────────────

## Startet einen ENet-Host auf dem angegebenen Port.
## Gibt true zurück wenn erfolgreich.
func host_game(port: int = DEFAULT_PORT, max_clients: int = MAX_CLIENTS) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(port, max_clients)
	if err != OK:
		Logger.log_error("host_game(): create_server(%d) fehlgeschlagen: %s" % [port, error_string(err)], LOG_CAT)
		return false
	multiplayer.multiplayer_peer = peer
	Logger.log_info("Host gestartet auf Port %d (max. %d Clients)." % [port, max_clients], LOG_CAT)
	return true


## Verbindet als Client mit einem Host.
## Gibt true zurück wenn die Verbindung eingeleitet wurde (nicht: wenn sie fertig ist).
func join_game(address: String, port: int = DEFAULT_PORT) -> bool:
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(address, port)
	if err != OK:
		Logger.log_error("join_game(): create_client(%s:%d) fehlgeschlagen: %s" % [address, port, error_string(err)], LOG_CAT)
		return false
	multiplayer.multiplayer_peer = peer
	Logger.log_info("Verbindung zu %s:%d eingeleitet." % [address, port], LOG_CAT)
	return true


## Trennt den Peer und setzt ihn zurück auf Tier 1 (Solo).
func close() -> void:
	if _has_peer():
		multiplayer.multiplayer_peer = null
		Logger.log_info("Multiplayer-Peer geschlossen — zurück zu Tier 1.", LOG_CAT)


func is_server() -> bool:
	return not _has_peer() or multiplayer.is_server()


func get_local_peer_id() -> int:
	return multiplayer.get_unique_id() if _has_peer() else 1


# ─────────────────────────────────────────────
# RPC-Routing-Helfer (genutzt von Services)
# ─────────────────────────────────────────────

## Gibt true zurück wenn ein Peer gesetzt ist (Tier 2/3).
## Services rufen das ab um zu entscheiden ob sie rpc_id() oder direkt aufrufen.
func has_peer() -> bool:
	return _has_peer()


## Sendet einen XP-Gain an die Autorität (oder ruft lokal auf in Tier 1).
func send_add_xp(skill_name: String, amount: int) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_add_xp", skill_name, amount)
	else:
		if is_instance_valid(_skill_system):
			_skill_system._on_xp_add_confirmed({"skill_name": skill_name, "amount": amount, "player_id": 1})


## Sendet eine Item-Anfrage an die Autorität.
func send_add_item(item_id: String, qty: int) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_add_item", item_id, qty)
	else:
		if is_instance_valid(_inventory):
			_inventory.on_item_add_confirmed(item_id, qty, 1)


## Sendet eine Quest-Start-Anfrage an die Autorität.
func send_start_quest(quest_id: String) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_start_quest", quest_id)
	else:
		if is_instance_valid(_quest):
			_quest._on_quest_start_confirmed({"quest_id": quest_id, "player_id": 1})


## Sendet eine Quest-Complete-Anfrage an die Autorität.
func send_complete_quest(quest_id: String) -> void:
	if _has_peer() and not multiplayer.is_server():
		rpc_id(1, "_rpc_complete_quest", quest_id)
	else:
		if is_instance_valid(_quest):
			_quest._on_quest_complete_confirmed({"quest_id": quest_id, "player_id": 1})


# ─────────────────────────────────────────────
# RPC-Empfangs-Methoden (laufen auf Autorität)
# ─────────────────────────────────────────────

@rpc("any_peer", "call_local", "reliable")
func _rpc_add_item(item_id: String, qty: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	Logger.log_debug("RPC _rpc_add_item von peer %d: %s x%d" % [player_id, item_id, qty], LOG_CAT)
	if is_instance_valid(_inventory):
		_inventory.on_item_add_confirmed(item_id, qty, player_id)
	else:
		Logger.log_error("_rpc_add_item: InventorySystem nicht verfügbar!", LOG_CAT)


@rpc("any_peer", "call_local", "reliable")
func _rpc_start_quest(quest_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	Logger.log_debug("RPC _rpc_start_quest von peer %d: %s" % [player_id, quest_id], LOG_CAT)
	if is_instance_valid(_quest):
		_quest._on_quest_start_confirmed({"quest_id": quest_id, "player_id": player_id})
	else:
		Logger.log_error("_rpc_start_quest: QuestService nicht verfügbar!", LOG_CAT)


@rpc("any_peer", "call_local", "reliable")
func _rpc_complete_quest(quest_id: String) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	Logger.log_debug("RPC _rpc_complete_quest von peer %d: %s" % [player_id, quest_id], LOG_CAT)
	if is_instance_valid(_quest):
		_quest._on_quest_complete_confirmed({"quest_id": quest_id, "player_id": player_id})
	else:
		Logger.log_error("_rpc_complete_quest: QuestService nicht verfügbar!", LOG_CAT)


@rpc("any_peer", "call_local", "reliable")
func _rpc_add_xp(skill_name: String, amount: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	Logger.log_debug("RPC _rpc_add_xp von peer %d: %s +%d" % [player_id, skill_name, amount], LOG_CAT)
	if is_instance_valid(_skill_system):
		_skill_system._on_xp_add_confirmed({"skill_name": skill_name, "amount": amount, "player_id": player_id})
	else:
		Logger.log_error("_rpc_add_xp: SkillSystem nicht verfügbar!", LOG_CAT)


@rpc("any_peer", "call_local", "reliable")
func _rpc_set_state(state: int) -> void:
	if not _is_authority():
		return
	var player_id := _sender_as_player_id()
	if is_instance_valid(_player_states):
		_player_states.set_state(state as PlayerStateService.State, player_id)
	else:
		Logger.log_error("_rpc_set_state: PlayerStateService nicht verfügbar!", LOG_CAT)


# ─────────────────────────────────────────────
# Peer-Event-Handler
# ─────────────────────────────────────────────

func _on_peer_connected(peer_id: int) -> void:
	Logger.log_info("Peer verbunden: %d" % peer_id, LOG_CAT)
	player_connected.emit(peer_id)


func _on_peer_disconnected(peer_id: int) -> void:
	Logger.log_info("Peer getrennt: %d" % peer_id, LOG_CAT)
	player_disconnected.emit(peer_id)


func _on_connected_to_server() -> void:
	Logger.log_info("Mit Server verbunden. Lokale peer_id: %d" % multiplayer.get_unique_id(), LOG_CAT)


func _on_connection_failed() -> void:
	Logger.log_error("Verbindung zum Server fehlgeschlagen.", LOG_CAT)
	connection_failed.emit()


func _on_server_disconnected() -> void:
	Logger.log_warn("Server-Verbindung verloren.", LOG_CAT)
	server_disconnected.emit()


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _has_peer() -> bool:
	return is_instance_valid(multiplayer) and multiplayer.has_multiplayer_peer()


func _is_authority() -> bool:
	return not _has_peer() or multiplayer.is_server()


func _sender_as_player_id() -> int:
	var sender := multiplayer.get_remote_sender_id()
	return sender if sender != 0 else 1
