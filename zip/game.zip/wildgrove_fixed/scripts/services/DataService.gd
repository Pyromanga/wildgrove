extends Service
class_name DataService

## DataService — Zentrales Repository für ALLE statischen Spieldaten.
##
###   kein zentrales Repository, kein Caching, inkonsistente Pfade.
##   Jetzt: einziger Ladeort für alle statischen .tres-Ressourcen. InventorySystem
##   und QuestService rufen get_item() / get_quest() auf, statt selbst DirAccess
##   zu öffnen.
##
## Was DataService lädt:
##   - PlayerData.tres       → Spieler-Konfiguration (Speed, Gravity, …)
##   - data/items/*.tres     → ItemDefinition-Ressourcen
##   - data/quests/*.tres    → QuestDefinition-Ressourcen (wenn vorhanden)
##   - data/skills/*.tres    → SkillDefinition-Ressourcen (wenn vorhanden)
##   - data/combat_profiles/*.tres → CombatProfile-Ressourcen (TD-10, ADR-008)
##
## Was DataService NICHT tut:
##   - Keinen Laufzeit-State halten (Inventar, Quest-Fortschritt, Skills)
##   - Kein SaveSystem-Provider (statische Daten ändern sich nicht)

const LOG_CAT := "DataService"

const PLAYER_DATA_PATH := "res://config/PlayerData.tres"
# Item/Quest/Skill-Pfade sind jetzt in DataManifest — kein DirAccess mehr nötig.

var player_data: PlayerData

## Repositories — befüllt in configure()
var _items:  Dictionary = {}   # { item_id:  ItemDefinition  }
var _quests: Dictionary = {}   # { quest_id: QuestDefinition }
var _skills: Dictionary = {}   # { skill_id: SkillDefinition } — leer bis SkillDefinition.tres existieren
var _combat_profiles: Dictionary = {}   # { profile_id: CombatProfile } — TD-10


# ─────────────────────────────────────────────
# Phase 4: Configure
# ─────────────────────────────────────────────
func configure(_deps: Dictionary) -> void:
	var t := Logger.log_begin("DataService.configure()", LOG_CAT)
	_load_player_data()
	_load_items()
	_load_quests()
	_load_skills()
	_load_combat_profiles()
	Logger.log_end("DataService.configure()", t, LOG_CAT)
	Logger.log_info(
		"Geladen: %d Items, %d Quests, %d Skills, %d CombatProfiles."
		% [_items.size(), _quests.size(), _skills.size(), _combat_profiles.size()],
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Öffentliche API — PlayerData
# ─────────────────────────────────────────────


## Liest einen numerischen Spieler-Konfigurationswert.
func get_player_stat(stat_name: String, default_val: float = 0.0) -> float:
	if not player_data:
		Logger.log_error("Abfrage '%s' fehlgeschlagen: player_data ist NULL!" % stat_name, LOG_CAT)
		return default_val

	var value: Variant = player_data.get(stat_name)
	if value != null:
		return float(value)

	Logger.log_warn("Stat '%s' existiert nicht in PlayerData.tres!" % stat_name, LOG_CAT)
	return default_val


# ─────────────────────────────────────────────
# Öffentliche API — Items
# ─────────────────────────────────────────────


## Gibt die ItemDefinition für eine ID zurück, oder null.
func get_item(item_id: String) -> ItemDefinition:
	return _items.get(item_id)


## Gibt alle geladenen Items zurück (für InventorySystem-Initialisierung).
func get_all_items() -> Dictionary:
	return _items


# ─────────────────────────────────────────────
# Öffentliche API — Quests
# ─────────────────────────────────────────────


## Gibt die QuestDefinition für eine ID zurück, oder null.
func get_quest(quest_id: String) -> QuestDefinition:
	return _quests.get(quest_id)


## Gibt alle geladenen Quest-Definitionen zurück.
func get_all_quests() -> Dictionary:
	return _quests


## Gibt alle Quest-IDs mit auto_start=true zurück (für QuestService-Initialisierung).
func get_auto_start_quests() -> Array[String]:
	var result: Array[String] = []
	for id in _quests:
		var q: QuestDefinition = _quests[id]
		if q.auto_start:
			result.append(id)
	return result


# ─────────────────────────────────────────────
# Öffentliche API — Skills
# ─────────────────────────────────────────────


## Gibt alle geladenen SkillDefinitions zurück.
## Leer bis res://data/skills/*.tres Dateien existieren.
func get_all_skills() -> Dictionary:
	return _skills


# ─────────────────────────────────────────────
# Öffentliche API — CombatProfiles (TD-10)
# ─────────────────────────────────────────────


## Gibt das CombatProfile für eine ID zurück, oder ein neutrales Default-Profil
## (keine Resistenz) wenn die ID unbekannt ist — z.B. eine neue Entity-Klasse
## ohne eigenes .tres. Gibt NIEMALS null zurück, damit Call-Sites keinen
## zusätzlichen Null-Check brauchen.
func get_combat_profile(profile_id: String) -> CombatProfile:
	var profile: CombatProfile = _combat_profiles.get(profile_id)
	if profile == null:
		Logger.log_warn(
			"CombatProfile '%s' nicht gefunden — nutze Default (keine Resistenz)." % profile_id,
			LOG_CAT
		)
		return CombatProfile.default_profile()
	return profile


## Gibt alle geladenen CombatProfiles zurück.
func get_all_combat_profiles() -> Dictionary:
	return _combat_profiles


# ─────────────────────────────────────────────
# Intern — Lader
# ─────────────────────────────────────────────


func _load_player_data() -> void:
	if not ResourceLoader.exists(PLAYER_DATA_PATH):
		Logger.log_error("KRITISCH: PlayerData fehlt unter '%s'!" % PLAYER_DATA_PATH, LOG_CAT)
		return
	player_data = load(PLAYER_DATA_PATH) as PlayerData
	if player_data:
		Logger.log_debug(
			"PlayerData geladen. Speed=%.1f, Gravity=%.1f." % [player_data.speed, player_data.gravity],
			LOG_CAT
		)
	else:
		Logger.log_error(
			"PlayerData Cast fehlgeschlagen — Script-Pfad in PlayerData.tres prüfen! "
			+ "Erwartet: res://scripts/resources/PlayerData.gd",
			LOG_CAT
		)


func _load_items() -> void:
	_items = {}
	for path: String in DataManifest.ITEMS:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("Item nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		if not res is ItemDefinition:
			Logger.log_warn("'%s' ist kein ItemDefinition." % path, LOG_CAT)
			continue
		var item := res as ItemDefinition
		_items[item.id] = item
	Logger.log_debug("Items geladen: %d" % _items.size(), LOG_CAT)


func _load_quests() -> void:
	_quests = {}
	for path: String in DataManifest.QUESTS:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("Quest nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		if not res is QuestDefinition:
			Logger.log_warn("'%s' ist kein QuestDefinition." % path, LOG_CAT)
			continue
		var quest := res as QuestDefinition
		_quests[quest.id] = quest
	Logger.log_debug("Quests geladen: %d" % _quests.size(), LOG_CAT)


func _load_skills() -> void:
	_skills = {}
	for path: String in DataManifest.SKILLS:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("Skill nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		# SkillDefinition ist optional — kein Fehler wenn Klasse noch nicht existiert
		if res.get("id") == null:
			Logger.log_warn("'%s' hat kein 'id'-Feld." % path, LOG_CAT)
			continue
		_skills[str(res.get("id"))] = res
	Logger.log_debug("Skills geladen: %d" % _skills.size(), LOG_CAT)


func _load_combat_profiles() -> void:
	_combat_profiles = {}
	for path: String in DataManifest.COMBAT_PROFILES:
		var res: Resource = load(path)
		if res == null:
			Logger.log_warn("CombatProfile nicht ladbar: '%s'" % path, LOG_CAT)
			continue
		if not res is CombatProfile:
			Logger.log_warn("'%s' ist kein CombatProfile." % path, LOG_CAT)
			continue
		var profile := res as CombatProfile
		_combat_profiles[profile.id] = profile
	Logger.log_debug("CombatProfiles geladen: %d" % _combat_profiles.size(), LOG_CAT)
