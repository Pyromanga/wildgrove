extends ServiceNode
class_name GameSaveService

## GameSaveService — Koordinator für übergreifende Speicheroperationen.
##
## Verantwortung (klar abgegrenzt nach A-04-Fix):
##   - Lauscht auf save_requested (externer Auslöser von UI/Buttons)
##   - Emittiert save_pre_flush damit Services transiente Daten sichern können
##     (z.B. WorldService → Pets, ohne dass GameSaveService WorldService kennt)
##   - Delegiert den eigentlichen Schreibvorgang an SaveSystem
##   - Doppelaufruf-Schutz (_is_saving-Guard)
##
## Was GameSaveService NICHT tut:
##   - Kein direkter Zugriff auf Services.world oder andere Services
##   - Kein Wissen über Pet-Daten, Spielstand-Inhalt oder Provider-Details
##   - Kein Schreiben auf Disk (delegiert an SaveSystem)
##
## Externe Auslöser:
##   EventBus.system.emit_save_requested()  ← von UI-Button oder Quicksave
##
## Internes Notify:
##   EventBus.system.save_pre_flush         ← WorldService lauscht hier (Pets)
##   EventBus.system.save_started           ← von SaveSystem, für UI-Feedback
##   EventBus.system.save_completed(bool)   ← von SaveSystem, für UI-Feedback

const LOG_CAT := "GameSave"

var _save_system: SaveSystem
var _is_saving: bool = false


func configure(deps: Dictionary) -> void:
	_save_system = deps.get("savesystem") as SaveSystem
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem-Dependency fehlt!", LOG_CAT)


func on_ready() -> void:
	EventBus.system.save_requested.connect(_on_save_requested)
	Logger.log_info("GameSaveService bereit. Lauscht auf save_requested.", LOG_CAT)


func on_cleanup() -> void:
	if EventBus.system.save_requested.is_connected(_on_save_requested):
		EventBus.system.save_requested.disconnect(_on_save_requested)
	Logger.log_info("GameSaveService cleanup.", LOG_CAT)


## Vollständiger Speichervorgang über alle registrierten Provider.
## Gibt true zurück wenn erfolgreich.
func save_all() -> bool:
	if not is_instance_valid(_save_system):
		Logger.log_error("SaveSystem nicht verfügbar — Speichern abgebrochen!", LOG_CAT)
		return false

	if _is_saving:
		Logger.log_warn("save_all() bereits aktiv — doppelter Aufruf ignoriert.", LOG_CAT)
		return false

	_is_saving = true
	var t := Logger.log_begin("save_all()", LOG_CAT)

	# Pre-Flush: Services mit transienten SceneTree-Daten bereiten ihren State vor.
	# WorldService lauscht hier und sichert Pet-Positionen — GameSaveService
	# kennt WorldService nicht direkt (ADR-001 Schichttrennung).
	EventBus.system.emit_save_pre_flush()

	var success := _save_system.save_game()
	Logger.log_end("save_all()", t, LOG_CAT)
	_is_saving = false

	if success:
		Logger.log_info("Speichervorgang erfolgreich.", LOG_CAT)
	else:
		Logger.log_error("Speichervorgang fehlgeschlagen!", LOG_CAT)

	return success


func _on_save_requested() -> void:
	Logger.log_info("save_requested empfangen — starte save_all().", LOG_CAT)
	save_all()
