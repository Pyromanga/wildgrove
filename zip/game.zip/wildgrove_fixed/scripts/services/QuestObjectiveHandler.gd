class_name QuestObjectiveHandler
extends RefCounted

## QuestObjectiveHandler — Prüft EventBus-Events gegen aktive Quest-Objectives.
##
## Extrahiert aus QuestService._on_loot_collected(), _on_xp_gained(), _on_interaction_finished().
## Kein Node, kein Service — reine Logik-Klasse.
##
## Verantwortung:
##   - Für jeden eingehenden Event-Wert berechnen welche Objectives betroffen sind
##   - Gibt Array[{ quest_id, objective_id, delta }] zurück → QuestService führt update_objective() aus
##
## Was QuestObjectiveHandler NICHT tut:
##   - Kein EventBus-Connect (bleibt bei QuestService)
##   - Kein state-Zugriff (active_quests, definitions bleiben bei QuestService)

const LOG_CAT := "QuestObjectiveHandler"


## Gibt alle Objective-Updates zurück die durch ein COLLECT-Event ausgelöst werden.
## { quest_id, obj_id, delta }
static func resolve_loot(
	item_id:       String,
	quantity:      int,
	active_quests: Dictionary,
	definitions:   Dictionary
) -> Array[Dictionary]:
	var updates: Array[Dictionary] = []
	for quest_id in active_quests.keys():
		var def: QuestDefinition = definitions.get(quest_id)
		if not def:
			continue
		for obj in def.objectives:
			if obj.type == QuestObjective.Type.COLLECT and obj.target_id == item_id:
				updates.append({"quest_id": quest_id, "obj_id": obj.id, "delta": quantity})
	return updates


## Gibt alle Objective-Updates zurück die durch ein XP/SKILL-Event ausgelöst werden.
## Prüft ob skill_system.get_level() den Required-Level erreicht.
static func resolve_xp(
	skill_name:    String,
	active_quests: Dictionary,
	definitions:   Dictionary,
	skill_system:  SkillSystem
) -> Array[Dictionary]:
	var updates: Array[Dictionary] = []
	for quest_id in active_quests.keys():
		var def: QuestDefinition = definitions.get(quest_id)
		if not def:
			continue
		for obj in def.objectives:
			if obj.type == QuestObjective.Type.SKILL and obj.target_id == skill_name:
				if is_instance_valid(skill_system):
					var cur_level: int = skill_system.get_level(skill_name)
					if cur_level >= obj.required:
						updates.append({"quest_id": quest_id, "obj_id": obj.id, "delta": 1})
	return updates


## Gibt alle Objective-Updates zurück die durch ein INTERACT-Event ausgelöst werden.
static func resolve_interaction(
	action_id:     String,
	active_quests: Dictionary,
	definitions:   Dictionary
) -> Array[Dictionary]:
	var updates: Array[Dictionary] = []
	for quest_id in active_quests.keys():
		var def: QuestDefinition = definitions.get(quest_id)
		if not def:
			continue
		for obj in def.objectives:
			if obj.type == QuestObjective.Type.INTERACT and obj.target_id == action_id:
				updates.append({"quest_id": quest_id, "obj_id": obj.id, "delta": 1})
	return updates


## Prüft ob alle Pflicht-Objectives einer Quest erfüllt sind.
## Gibt true zurück wenn die Quest abgeschlossen werden kann.
static func is_completable(
	quest_id:        String,
	objectives_state: Dictionary,
	def:             QuestDefinition
) -> bool:
	for obj in def.objectives:
		if obj.optional:
			continue
		var progress: int = objectives_state.get(obj.id, 0)
		if progress < obj.required:
			return false
	return true
