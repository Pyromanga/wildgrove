extends ServiceNode
class_name CombatSystem

## CombatSystem — Zentrales Fundament für alle Kampf-Berechnungen.
##
## Abhängigkeiten (deps): ["stat_modifiers" (optional)]
##
## VERANTWORTUNG:
##   calculate_damage()              → Nimmt raw_amount + DamageType, wendet
##                                      Resistenzen (als rohe Floats) an, füllt
##                                      final_amount, gibt DamageRecord zurück.
##   calculate_damage_with_profile() → Wie calculate_damage(), nimmt aber ein
##                                      CombatProfile statt zweier loser Floats (TD-10).
##   apply_damage()                  → Wendet einen fertigen Record auf ein
##                                      HealthComponent an und emittiert
##                                      EventBus.world.damage_dealt.
##   roll_critical()                 → Zufalls-Check ob ein Treffer kritisch ist (TD-13).
##   player_melee_damage()           → Zentralisiert die Spieler-Angriffs-Formel.
##   enemy_melee_damage()            → Zentralisiert die Gegner-Angriffs-Formel (TD-11).
##   apply_poison() / apply_burn()   → Registriert einen rekurrierenden Status-Effekt
##                                      (TD-12). Tickt via on_tick() — siehe unten.
##
## NICHT VERANTWORTLICH für:
##   - KI-Entscheidungen (EnemyAI)
##   - Animations-Timing (EnemyVisuals / EnemyAttack)
##   - XP-Vergabe (bleibt in EnemyNPC._die() → EventBus.player)
##   - Loot-Drop (bleibt in EnemyNPC._die() → EventBus.world)
##
## STATUS-EFFEKTE (TD-12): `_active_effects: { entity_id: [StatusEffect] }`.
## apply_status_effect() / tick_status_effects() stehen bereit — Anbindung an
## konkrete Angriffe (Gift-Waffen, Debuff-Skills) steht noch aus.

## sich dafür bei Services.ticker (gleiches Muster wie RespawnService/
## StatModifierService.cleanup_expired()). Kein eigener Timer-Node nötig.
## Aktuell NICHT verdrahtet mit EnemyAttack/Player — reines Fundament, analog zu
## Integration in konkrete Angriffe (Gift-Waffen,
## Feuer-Fallen) ist eine künftige Feature-Session, kein Scope dieses Tickets.
##
## ERWEITERBARKEIT (noch offen, siehe ADR-008 "Bekannter Tech Debt"):
##   - Reflect/Thorns: apply_damage() gibt optionalen Rückschlag-Record zurück
##
## ADR-008: Diese Klasse begründet ADR-008 (CombatSystem mit DamageRecord + DamageType).

const LOG_CAT := "Combat"

## Basis-Krit-Chance (5 %). Wird später durch StatModifier "crit_chance" erhöht.
const BASE_CRIT_CHANCE: float  = 0.05

## Krit-Multiplikator (1.5× Schaden).
const CRIT_MULTIPLIER: float   = 1.5

## Minimaler Schaden (verhindert 0-Damage durch hohe Rüstung).
const MIN_DAMAGE: float = 1.0

var _stat_modifiers: StatModifierService = null

## TD-13: Injizierbarer RNG statt globalem randf(). Default = randomisierte eigene
## Instanz (Produktionsverhalten bleibt nicht-deterministisch wie zuvor).
## Tests können via configure({"rng": seeded_rng}) einen geseedeten RandomNumberGenerator
## injizieren — dann ist calculate_damage()/roll_critical() exakt reproduzierbar,
## ohne das Krit-Toleranzband aus test_combat_system.gd zu brauchen.
var _rng: RandomNumberGenerator = RandomNumberGenerator.new()

## TD-12: aktive Status-Effekte. Key = StatusEffect.effect_key, Value = StatusEffect.
## Siehe on_tick() für die Tick-Verarbeitung, apply_poison()/apply_burn() für die API.
var _active_effects: Dictionary = {}


# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────


func configure(deps: Dictionary) -> void:
	_stat_modifiers = deps.get("stat_modifiers") as StatModifierService
	if not is_instance_valid(_stat_modifiers):
		Logger.log_debug("StatModifierService nicht in deps — Boni nicht verfügbar.", LOG_CAT)

	# TD-13: optionaler RNG-Override für deterministische Tests.
	# Production-BootstrapConfig deklariert "rng" nicht als Service-Dependency —
	# dieser Pfad wird nur von Tests genutzt (configure({"rng": seeded_rng})).
	var injected_rng: Variant = deps.get("rng")
	if injected_rng is RandomNumberGenerator:
		_rng = injected_rng
	else:
		_rng.randomize()

	Logger.log_info("CombatSystem konfiguriert.", LOG_CAT)


func on_ready() -> void:
	# TD-12: Registrierung für on_tick() — ServiceTicker erkennt has_method("on_tick")
	# duck-typed, gleiches Muster wie RespawnService.on_ready().
	if Services.ticker:
		Services.ticker.register_service(self)
	Logger.log_info("CombatSystem aktiv.", LOG_CAT)


func on_cleanup() -> void:
	_active_effects.clear()
	Logger.log_info("CombatSystem cleanup.", LOG_CAT)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────


## Berechnet den finalen Schaden für einen DamageRecord.
##
## Verarbeitung:
##   1. Krit-Check (PHYSICAL + MAGIC, nicht TRUE)
##   2. Type-spezifische Resistenz via target_armor / target_magic_resist
##   3. StatModifier "damage_bonus" des Angreifers addiert auf raw
##   4. Clamp auf MIN_DAMAGE
##   5. record.final_amount gesetzt — Record danach als fertig betrachten
##
## [param record]         Vorbereiteter DamageRecord (source, target, raw, type gesetzt).
## [param target_armor]   Rüstungswert des Ziels (0.0 = keine Rüstung, 1.0 = immun — kein sinnvoller Wert, Clamp auf 0.85 max).
## [param target_magic]   Magische Resistenz des Ziels (selbes Schema).
## [return] denselben Record (gefüllt, zur Weitergabe).
func calculate_damage(
		record: DamageRecord,
		target_armor: float = 0.0,
		target_magic_resist: float = 0.0
) -> DamageRecord:
	var raw := record.raw_amount

	# Damage-Bonus aus StatModifiers des Angreifers
	if is_instance_valid(_stat_modifiers) and not record.source_id.is_empty():
		raw = _stat_modifiers.get_effective_stat("damage_bonus", raw)

	# Krit-Check (TRUE-Schaden ignoriert Krits — kein Würfelglück bei Gift/Sturz)
	if record.damage_type != DamageRecord.DamageType.TRUE:
		if roll_critical(record.source_id):
			raw *= CRIT_MULTIPLIER
			record.is_critical = true

	# Resistenz anwenden
	var final := raw
	match record.damage_type:
		DamageRecord.DamageType.PHYSICAL:
			var mitigation := clampf(target_armor, 0.0, 0.85)
			final = raw * (1.0 - mitigation)
		DamageRecord.DamageType.MAGIC:
			var mitigation := clampf(target_magic_resist, 0.0, 0.85)
			final = raw * (1.0 - mitigation)
		DamageRecord.DamageType.TRUE:
			final = raw  # Unverändert

	record.final_amount = maxf(final, MIN_DAMAGE)

	Logger.log_debug(record.to_debug_string(), LOG_CAT)
	return record


## Wie calculate_damage(), nimmt aber ein CombatProfile statt zweier loser
## Floats entgegen (TD-10). Bevorzugter Einstiegspunkt für Entity-Code —
## calculate_damage() bleibt als reine Funktion über zwei Floats bestehen,
## weil sie ohne DataService/CombatProfile-Setup testbar sein soll (ADR-008).
##
## [param profile] Resistenz-Profil des Ziels. null → CombatProfile.default_profile()
## (keine Resistenz) statt eines Crashs — z.B. wenn DataService nicht verfügbar ist.
func calculate_damage_with_profile(record: DamageRecord, profile: CombatProfile) -> DamageRecord:
	var p := profile if is_instance_valid(profile) else CombatProfile.default_profile()
	return calculate_damage(record, p.armor, p.magic_resist)


## Wendet einen fertigen DamageRecord auf ein HealthComponent an.
##
## Emittiert EventBus.world.damage_dealt(record) nach dem Schaden.
## Gibt false zurück wenn hc ungültig ist oder bereits tot.
func apply_damage(record: DamageRecord, hc: HealthComponent) -> bool:
	if not is_instance_valid(hc) or hc.is_dead:
		return false
	hc.take_damage(int(record.final_amount))
	EventBus.world.emit_damage_dealt(record)
	return true


## Würfelt ob ein Treffer kritisch ist.
## source_id kann genutzt werden um Krit-Chance per Entity zu variieren.
## TD-13: nutzt den injizierbaren _rng statt des globalen randf() — mit
## configure({"rng": seeded_rng}) ist das Ergebnis deterministisch (siehe Tests).
## TODO (kein Issue/ADR bisher): chance += _stat_modifiers.get_effective_stat("crit_chance", 0.0)
## sobald ein Skill/Equipment existiert, das crit_chance tatsächlich modifiziert.
func roll_critical(_source_id: String = "") -> bool:
	# MIGRATION-010 Phase 1: Authority-Guard — Krit-Würfe sind server-autoritativ.
	# Tier 1 (kein Peer gesetzt): multiplayer-Objekt kann null sein → Guard überspringen.
	# Tier 2/3: nur die Autorität darf Krit-Würfe durchführen (verhindert Client-Manipulation).
	if is_instance_valid(multiplayer) and multiplayer.has_multiplayer_peer():
		assert(
			multiplayer.is_server(),
			"roll_critical() darf nur von der Autorität aufgerufen werden!"
		)
	var chance := BASE_CRIT_CHANCE
	return _rng.randf() < chance


## Berechnet Spieler-Angriffs-Schaden basierend auf Skill-Level + ausgerüsteter Waffe.
## Liest Equipment via Services.equipment (optional, null-safe).
func player_melee_damage(skill_system: SkillSystem, player_id: String) -> DamageRecord:
	var base_dmg := 10.0
	if is_instance_valid(skill_system):
		base_dmg += skill_system.get_level("combat") * 2.0

	# Waffen-Bonus aus Equipment
	var weapon: WeaponDefinition = null
	if Services.get("equipment") and is_instance_valid(Services.equipment):
		weapon = Services.equipment.get_equipped_weapon()
		if is_instance_valid(weapon):
			base_dmg += weapon.damage_bonus

	var dmg_type := DamageRecord.DamageType.PHYSICAL
	if is_instance_valid(weapon):
		dmg_type = weapon.damage_type

	return DamageRecord.make_player_attack(player_id, "", base_dmg, dmg_type)


## Wendet on_hit_effects der ausgerüsteten Waffe auf das Ziel an (z.B. Gift).
## Aufgerufen von EnemyNPC._on_interacted() nach erfolgreichem Treffer.
func apply_weapon_on_hit(target_hc: HealthComponent, attacker_id: String, target_id: String) -> void:
	if not is_instance_valid(target_hc):
		return
	if not (Services.get("equipment") and is_instance_valid(Services.equipment)):
		return
	var weapon: WeaponDefinition = Services.equipment.get_equipped_weapon()
	if not is_instance_valid(weapon) or weapon.on_hit_effect < 0:
		return
	# on_hit_effect 0 = POISON (analog StatusEffect.Kind.POISON)
	apply_poison(
		attacker_id, target_id, target_hc,
		weapon.on_hit_damage_per_tick,
		weapon.on_hit_ticks,
		weapon.on_hit_tick_interval
	)
	EventBus.ui.emit_floating_text("☠ Vergiftet!")


## Berechnet Gegner-Angriffs-Schaden (Enemy → Spieler). Spiegelt player_melee_damage().
## TD-11: bisher rief EnemyNPC._do_melee() hc.take_damage() direkt auf, am
## CombatSystem vorbei — kein Krit-Check, keine Resistenz, kein damage_dealt-Event.
##
## [param raw_damage] Basis-Schaden aus der EnemyNPC-Konfiguration (on_spawn cfg "damage").
## Bewusst kein Skill-Level-Einfluss wie bei player_melee_damage() — Gegner haben
## (noch) keine Skills. Variation kommt aktuell ausschließlich aus dem Ziel-Profil
## (Resistenz) und dem Krit-Würfel in calculate_damage().
func enemy_melee_damage(source_id: String, target_id: String, raw_damage: float) -> DamageRecord:
	return DamageRecord.make_enemy_attack(
		source_id, target_id, raw_damage, DamageRecord.DamageType.PHYSICAL
	)


# ─────────────────────────────────────────────
# Status-Effekte (TD-12)
# ─────────────────────────────────────────────


## Registriert einen Gift-Tick-Status-Effekt auf hc. Erneuter Aufruf mit derselben
## source_id/target_id-Kombination überschreibt den bestehenden Effekt (kein Stacking,
## Dauer + Schaden werden zurückgesetzt) — siehe StatusEffect.gd Kommentar.
##
## [param hc]              Ziel-HealthComponent (direkte Referenz, wie bei apply_damage()).
## [param damage_per_tick] Roh-Schaden pro Tick. Läuft über DamageType.TRUE — ignoriert
##                          Rüstung/Magieresistenz des Ziels (siehe StatusEffect.gd).
## [param total_ticks]     Anzahl Ticks bis der Effekt endet.
## [param tick_interval]   Sekunden zwischen zwei Ticks. Muss > 0 sein.
## [return] Den registrierten StatusEffect, oder null bei ungültigen Parametern.
func apply_poison(
		source_id: String, target_id: String, hc: HealthComponent,
		damage_per_tick: float, total_ticks: int, tick_interval: float = 1.0
) -> StatusEffect:
	return _apply_status_effect(
		StatusEffect.Kind.POISON, source_id, target_id, hc,
		damage_per_tick, tick_interval, total_ticks
	)


## Registriert einen Brand-Tick-Status-Effekt. Spiegelt apply_poison() — siehe dort.
func apply_burn(
		source_id: String, target_id: String, hc: HealthComponent,
		damage_per_tick: float, total_ticks: int, tick_interval: float = 1.0
) -> StatusEffect:
	return _apply_status_effect(
		StatusEffect.Kind.BURN, source_id, target_id, hc,
		damage_per_tick, tick_interval, total_ticks
	)


func _apply_status_effect(
		kind: StatusEffect.Kind, source_id: String, target_id: String, hc: HealthComponent,
		damage_per_tick: float, tick_interval: float, total_ticks: int
) -> StatusEffect:
	if not is_instance_valid(hc) or hc.is_dead:
		Logger.log_warn("apply_status_effect: HealthComponent ungültig oder Ziel bereits tot — ignoriert.", LOG_CAT)
		return null
	if tick_interval <= 0.0:
		Logger.log_error("apply_status_effect: tick_interval muss > 0 sein (war %.2f)." % tick_interval, LOG_CAT)
		return null
	if total_ticks <= 0:
		Logger.log_warn("apply_status_effect: total_ticks <= 0 — Effekt wird ignoriert.", LOG_CAT)
		return null

	var effect := StatusEffect.make(kind, source_id, target_id, hc, damage_per_tick, tick_interval, total_ticks)
	var was_overwrite := _active_effects.has(effect.effect_key)
	_active_effects[effect.effect_key] = effect

	Logger.log_debug(
		"%s %s" % ["Überschrieben:" if was_overwrite else "Aktiviert:", effect.to_debug_string()],
		LOG_CAT
	)
	return effect


## Entfernt einen aktiven Status-Effekt vorzeitig (z.B. Heiltrank/Gegengift).
## Gibt false zurück wenn kein Effekt mit diesem Key aktiv ist.
func remove_status_effect(effect_key: String) -> bool:
	if not _active_effects.has(effect_key):
		return false
	_active_effects.erase(effect_key)
	Logger.log_debug("Status-Effekt entfernt: %s" % effect_key, LOG_CAT)
	return true


func has_status_effect(effect_key: String) -> bool:
	return _active_effects.has(effect_key)


## Debug/Tests: Anzahl aktuell aktiver Status-Effekte.
func get_active_status_effect_count() -> int:
	return _active_effects.size()


## Tick-Einstiegspunkt für ServiceTicker (TD-12). Verarbeitet alle aktiven
## Status-Effekte: akkumuliert delta, wendet bei Überschreiten von tick_interval
## eine TRUE-Damage-Tick via apply_damage() an, entfernt abgelaufene/ungültige
## Effekte. Mehrere fällige Ticks in einem einzigen on_tick() (z.B. nach Lag-Spike)
## werden alle nachgeholt — siehe while-Schleife.
func on_tick(delta: float) -> void:
	if _active_effects.is_empty():
		return

	var expired: Array[String] = []
	for key in _active_effects:
		var effect: StatusEffect = _active_effects[key]

		if not is_instance_valid(effect.health_component) or effect.health_component.is_dead:
			expired.append(key)
			continue

		effect._elapsed += delta
		while effect._elapsed >= effect.tick_interval and effect.ticks_remaining > 0:
			effect._elapsed -= effect.tick_interval

			var record := DamageRecord.make_environmental(
				effect.target_id, effect.damage_per_tick, effect.context_tag()
			)
			record.source_id = effect.source_id
			calculate_damage(record)  # TRUE-Type: kein Krit, keine Resistenz — final_amount = raw
			apply_damage(record, effect.health_component)

			effect.ticks_remaining -= 1
			if effect.ticks_remaining <= 0:
				break

		if effect.ticks_remaining <= 0:
			expired.append(key)

	for key in expired:
		_active_effects.erase(key)
