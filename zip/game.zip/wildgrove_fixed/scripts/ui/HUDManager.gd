extends Node
class_name HUDManager

## HUDManager — Zentrale Steuerung des in-game HUD.
##
## LIFECYCLE: HUDManager instanziiert sich selbst als AutoLoad-ähnlicher Singleton
## über EventBus.system.session_ready — kein WorldService-Coupling.
## Kommunikation mit Services ausschliesslich über UIContext + EventBus.
##
## Warum kein Service: Services leben für die gesamte Spiellaufzeit.
## HUDManager braucht Referenzen auf InventorySystem und PlayerStateService
## — diese werden via initialize() injiziert, nicht via ServiceOrchestrator.
##
## KRITISCH: HUD hängt unter /root — NICHT unter der Welt-Szene.
## change_scene_to_file() freed die alte Szene komplett.
## Alles was Kind einer Szene ist wird mitgefreedt.
## CanvasLayer unter /root überlebt jeden Szenenwechsel.
##
## Lifecycle:
##   initialize()      → DI für InventorySystem + PlayerStateService
##   _ready()          → HUD unter /root einhängen, einmalig
##   world_scene_ready → Controller neu bauen (zeigen auf neue Spieler-Instanz)
##   state_changed     → HUD ein-/ausblenden

const LOG_CAT := "HUD"

var hud: HUD = null
var controllers: Dictionary = {}

## HUD wird in initialize() erstellt — _ready() hängt ihn unter /root ein.
func initialize() -> void:
	hud = HUD.new()
	hud.name = "GameHUD"
	hud.visible = false
	hud.add_to_group("hud_canvas")


## Erzeugt den HUDManager und hängt ihn unter /root — kein WorldService nötig.
## Wird von ServiceOrchestrator nach session_ready aufgerufen (via EventBus).
static func boot(tree: SceneTree) -> HUDManager:
	var mgr := HUDManager.new()
	mgr.name = "HUDManager"
	mgr.initialize()
	tree.root.call_deferred("add_child", mgr)
	return mgr


func _ready() -> void:
	Logger.log_debug("HUDManager._ready() — hänge HUD unter /root ein.", LOG_CAT)
	get_tree().root.call_deferred("add_child", hud)
	EventBus.world.world_scene_ready.connect(_on_world_scene_ready)
	EventBus.system.state_changed.connect(_on_state_changed)
	Logger.log_info("HUDManager bereit. HUD wird unter /root eingehängt.", LOG_CAT)


func _exit_tree() -> void:
	if EventBus.world.world_scene_ready.is_connected(_on_world_scene_ready):
		EventBus.world.world_scene_ready.disconnect(_on_world_scene_ready)
	if EventBus.system.state_changed.is_connected(_on_state_changed):
		EventBus.system.state_changed.disconnect(_on_state_changed)
	if is_instance_valid(hud):
		hud.queue_free()
	hud = null
	controllers.clear()


func get_controller(key: String) -> Object:
	return controllers.get(key)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _on_world_scene_ready(_scene_root: Node) -> void:
	Logger.log_debug("world_scene_ready Signal empfangen — baue HUD-Controller.", LOG_CAT)
	if not is_instance_valid(hud):
		Logger.log_error("_on_world_scene_ready: HUD ist null!", LOG_CAT)
		return

	# Alte Controller-Nodes bereinigen
	# (zeigen auf Spieler/Entities der alten Session)
	for child in hud.get_children():
		hud.remove_child(child)
		child.free()
	controllers.clear()

	var notif_old := controllers.get("notification") as NotificationController
	if notif_old and EventBus.world.interaction_reward_text.is_connected(notif_old.show):
		EventBus.world.interaction_reward_text.disconnect(notif_old.show)

	# Controller neu aufbauen — referenzieren neue Spieler-Instanz
	controllers = HUDBuilder.build_all(hud, UIContext.from_services())

	var notif := controllers.get("notification") as NotificationController
	if notif:
		EventBus.world.interaction_reward_text.connect(notif.show)

	hud.visible = true
	Logger.log_info("HUD aktiv. %d Controller." % controllers.size(), LOG_CAT)


func _on_state_changed(new_state: int) -> void:
	if not is_instance_valid(hud):
		return
	hud.visible = (new_state == GameEnums.State.PLAYING)
