extends Node
class_name MainMenuController

## MainMenuController — Character-Select-Screen-Logik.
##
## Zeigt vorhandene Spielstände als auswählbare Schaltflächen an
## und bietet die Option einen neuen Charakter zu starten.
##
## Flow:
##   1. _ready() → _refresh_ui() → list_local_saves() → Buttons erzeugen
##   2. Spieler klickt Charakter → emit_session_requested(player_id)
##   3. ServiceOrchestrator bootet Session → session_ready → GameManager → PLAYING
##   4. Bei Rückkehr: session_unloaded wird emittiert → _refresh_ui() erneut

const LOG_CAT := "MainMenuController"

## Neue Charaktere erhalten eine ID nach diesem Muster.
const NEW_CHAR_PREFIX := "charakter"


func _ready() -> void:
	# Auf Session-Ende reagieren (Rückkehr aus dem Spiel)
	EventBus.system.session_unloaded.connect(_refresh_ui)
	# Auf gelöschte Saves reagieren (UI-Refresh)
	EventBus.system.save_slot_deleted.connect(_on_save_deleted)

	_refresh_ui()

	Logger.log_info("MainMenuController bereit.", LOG_CAT)


# ─────────────────────────────────────────────
# UI aufbauen
# ─────────────────────────────────────────────


func _refresh_ui() -> void:
	_clear_character_list()

	# SaveSystem ist global — direkt nutzbar ohne aktive Session
	var saves := Services.save_system.list_local_saves()
	Logger.log_debug("%d lokale Spielstände gefunden." % saves.size(), LOG_CAT)

	for player_id in saves:
		_add_character_button(player_id)

	# "Neues Spiel"-Button immer anzeigen
	_update_new_game_button(saves)


func _clear_character_list() -> void:
	var list := _get_character_list()
	if list:
		for child in list.get_children():
			child.queue_free()


func _add_character_button(player_id: String) -> void:
	var list := _get_character_list()
	if not list:
		return

	var btn := Button.new()
	btn.text = _format_character_name(player_id)
	btn.pressed.connect(func() -> void: _on_character_selected(player_id))
	list.add_child(btn)


func _update_new_game_button(existing_saves: Array[String]) -> void:
	var btn := _get_new_game_button()
	if not btn:
		Logger.log_error("NewGameButton nicht gefunden — Pfad CenterContainer/NewGameButton stimmt nicht mit Szene überein!", LOG_CAT)
		return
	# Text anpassen je nach ob bereits Charaktere existieren
	btn.text = "Neues Spiel" if existing_saves.is_empty() else "Neuer Charakter"
	btn.pressed.connect(_on_new_game_pressed, CONNECT_ONE_SHOT)
	Logger.log_debug("NewGameButton verbunden: '%s'." % btn.text, LOG_CAT)


func _format_character_name(player_id: String) -> String:
	# "charakter_1718000000" → "Charakter 1" (vereinfacht für jetzt)
	# Später: gespeicherter Charaktername aus Save-Datei
	var display := player_id.replace("_", " ").capitalize()
	return display


# ─────────────────────────────────────────────
# Event-Handler
# ─────────────────────────────────────────────


func _on_character_selected(player_id: String) -> void:
	Logger.log_info("Charakter ausgewählt: '%s'." % player_id, LOG_CAT)
	EventBus.system.emit_session_requested(player_id)


func _on_new_game_pressed() -> void:
	Logger.log_debug("NewGameButton gedrueckt.", LOG_CAT)
	# Eindeutige ID basierend auf Unix-Zeitstempel
	var new_id := "%s_%d" % [NEW_CHAR_PREFIX, Time.get_unix_time_from_system()]
	Logger.log_info("Neuen Charakter starten: '%s'." % new_id, LOG_CAT)
	EventBus.system.emit_session_requested(new_id)
	Logger.log_debug("emit_session_requested abgesetzt fuer '%s'." % new_id, LOG_CAT)


func _on_save_deleted(_player_id: String) -> void:
	_refresh_ui()


# ─────────────────────────────────────────────
# Node-Referenzen
# ─────────────────────────────────────────────


func _get_character_list() -> Node:
	return get_node_or_null("CenterContainer/CharacterList")


func _get_new_game_button() -> Button:
	return get_node_or_null("CenterContainer/NewGameButton") as Button
