class_name InventoryComponent extends BaseUIComponent


func build(hud: HUD, ctx: IUIContext) -> InventoryUIController:
	var visuals := InventoryVisuals.new(hud)
	var ctrl := InventoryUIController.new()
	ctrl.setup(visuals, ctx.get_inventory())
	return ctrl
