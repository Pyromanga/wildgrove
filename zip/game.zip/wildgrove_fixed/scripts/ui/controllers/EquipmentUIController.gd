class_name EquipmentUIController

## EquipmentUIController — verwaltet das Equipment-Panel mit Slot-UI.
##
## Zeigt alle Equipment-Slots, verbindet Item-Taps im Inventar mit "Anlegen"-Dialog.
## Verdrahtet EquipmentService ↔ InventorySystem ↔ HUD.
##
## Aufgerufen von HUDBuilder via EquipmentComponent.build(hud, ctx).

const LOG_CAT := "EquipmentUI"

const SLOT_ICONS := {
	"weapon":  "🗡️",
	"offhand": "🛡",
	"helmet":  "⛑",
	"chest":   "🥋",
	"legs":    "👖",
	"boots":   "👟",
	"ring":    "💍",
	"amulet":  "📿",
}

const SLOT_LABELS := {
	"weapon":  "Waffe",
	"offhand": "Nebenhand",
	"helmet":  "Helm",
	"chest":   "Brust",
	"legs":    "Beine",
	"boots":   "Stiefel",
	"ring":    "Ring",
	"amulet":  "Amulett",
}

var _equipment: EquipmentService
var _inventory: InventorySystem
var _data: DataService

var _panel: PanelContainer
var _tab_bar: HBoxContainer
var _inv_tab: Button
var _equip_tab: Button
var _inventory_list: VBoxContainer
var _equipment_slots: VBoxContainer
var _stats_label: Label
var _dialog: PanelContainer
var _toggle_button: Button
var _hud: CanvasLayer

## Welcher Tab aktiv ist
var _active_tab: String = "inventory"


func setup(hud: HUD, ctx: IUIContext) -> void:
	_hud = hud
	_equipment = ctx.get_equipment()
	_inventory  = ctx.get_inventory()
	_data        = ctx.get_data()

	_build_ui(hud)

	if is_instance_valid(_equipment):
		_equipment.equipment_changed.connect(_on_equipment_changed)
	if is_instance_valid(_inventory):
		_inventory.inventory_changed.connect(
			func(player_id: int, _items) -> void:
				if player_id == 1:
					_refresh_inventory_tab()
		)

	_refresh_inventory_tab()
	_refresh_equipment_tab()


func toggle() -> void:
	_panel.visible = !_panel.visible


# ─────────────────────────────────────────────
# UI-Aufbau
# ─────────────────────────────────────────────


func _build_ui(parent: CanvasLayer) -> void:
	# Toggle-Button (🎒 icon wird durch Equipment-Button ersetzt;
	# bestehender InventoryVisuals-Button bleibt für Inventar-Tab)
	_toggle_button = Button.new()
	_toggle_button.name = "EquipToggleButton"
	_toggle_button.text = "⚔"
	_toggle_button.custom_minimum_size = Vector2(80, 80)
	_toggle_button.anchor_left   = 0.02
	_toggle_button.anchor_right  = 0.02
	_toggle_button.anchor_top    = 0.02
	_toggle_button.anchor_bottom = 0.02
	_toggle_button.offset_top    = 0
	_toggle_button.offset_right  = 80
	_toggle_button.offset_bottom = 80
	_toggle_button.offset_left   = 90   # rechts neben dem Inventar-Button
	_toggle_button.mouse_filter = Control.MOUSE_FILTER_STOP
	_toggle_button.pressed.connect(toggle)
	parent.add_child(_toggle_button)

	# Haupt-Panel
	_panel = PanelContainer.new()
	_panel.name = "EquipmentPanel"
	_panel.visible = false

	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.05, 0.08, 0.93)
	sb.set_corner_radius_all(12)
	sb.set_content_margin_all(12)
	_panel.add_theme_stylebox_override("panel", sb)

	_panel.anchor_left   = 0.02
	_panel.anchor_right  = 0.02
	_panel.anchor_top    = 0.02
	_panel.anchor_bottom = 0.02
	_panel.offset_top    = 90
	_panel.offset_right  = 310
	_panel.offset_bottom = 90 + 420
	parent.add_child(_panel)

	var vbox := VBoxContainer.new()
	_panel.add_child(vbox)

	# Tab-Leiste
	_tab_bar = HBoxContainer.new()
	_tab_bar.add_theme_constant_override("separation", 4)
	vbox.add_child(_tab_bar)

	_inv_tab = _make_tab_button("🎒 Inventar",   "inventory")
	_equip_tab = _make_tab_button("⚔ Ausrüstung", "equipment")
	_tab_bar.add_child(_inv_tab)
	_tab_bar.add_child(_equip_tab)

	var sep := HSeparator.new()
	vbox.add_child(sep)

	# Scrollbarer Inhalt
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, 300)
	vbox.add_child(scroll)

	# Inventar-Liste (Tab 1)
	_inventory_list = VBoxContainer.new()
	_inventory_list.name = "InventoryList"
	_inventory_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(_inventory_list)

	# Equipment-Slots (Tab 2)
	_equipment_slots = VBoxContainer.new()
	_equipment_slots.name = "EquipmentSlots"
	_equipment_slots.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_equipment_slots.visible = false
	scroll.add_child(_equipment_slots)

	# Stats-Zusammenfassung
	var stats_panel := PanelContainer.new()
	var stats_sb := StyleBoxFlat.new()
	stats_sb.bg_color = Color(0.08, 0.08, 0.12, 0.9)
	stats_sb.set_corner_radius_all(6)
	stats_sb.set_content_margin_all(8)
	stats_panel.add_theme_stylebox_override("panel", stats_sb)
	stats_panel.name = "StatsPanel"
	vbox.add_child(stats_panel)

	_stats_label = Label.new()
	_stats_label.name = "StatsLabel"
	_stats_label.text = ""
	_stats_label.add_theme_font_size_override("font_size", 14)
	_stats_label.self_modulate = Color(0.8, 0.9, 1.0)
	stats_panel.add_child(_stats_label)

	_switch_tab("inventory")


func _make_tab_button(label: String, tab_id: String) -> Button:
	var btn := Button.new()
	btn.text = label
	btn.custom_minimum_size = Vector2(130, 44)
	btn.pressed.connect(func() -> void: _switch_tab(tab_id))
	return btn


func _switch_tab(tab_id: String) -> void:
	_active_tab = tab_id
	_inventory_list.visible  = (tab_id == "inventory")
	_equipment_slots.visible = (tab_id == "equipment")
	_inv_tab.modulate   = Color.WHITE if tab_id == "inventory"  else Color(0.6, 0.6, 0.6)
	_equip_tab.modulate = Color.WHITE if tab_id == "equipment" else Color(0.6, 0.6, 0.6)
	if tab_id == "equipment":
		_refresh_equipment_tab()


# ─────────────────────────────────────────────
# Inventar-Tab
# ─────────────────────────────────────────────


func _refresh_inventory_tab() -> void:
	for child in _inventory_list.get_children():
		child.queue_free()

	if not is_instance_valid(_inventory):
		var lbl := Label.new()
		lbl.text = "(Inventar nicht verfügbar)"
		_inventory_list.add_child(lbl)
		return

	var items := _inventory.get_all_items()
	if items.is_empty():
		var lbl := Label.new()
		lbl.text = "(Leer)"
		_inventory_list.add_child(lbl)
		return

	for item_dict in items:
		var item_id: String = item_dict.get("id", item_dict.get("item_id", ""))
		var item_name: String = item_dict.get("name", item_dict.get("display_name", item_id))
		var qty: int = item_dict.get("quantity", 1)

		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		_inventory_list.add_child(row)

		var name_lbl := Label.new()
		name_lbl.text = "%s ×%d" % [item_name, qty]
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.add_theme_font_size_override("font_size", 16)
		row.add_child(name_lbl)

		# Prüfen ob Item equipbar ist
		var item_def: ItemDefinition = null
		if is_instance_valid(_data):
			item_def = _data.get_item(item_id)

		if item_def is WeaponDefinition:
			var equip_btn := Button.new()
			equip_btn.text = "⚔ Anlegen"
			equip_btn.custom_minimum_size = Vector2(100, 36)
			var captured_def: WeaponDefinition = item_def as WeaponDefinition
			equip_btn.pressed.connect(func() -> void: _on_equip_weapon(captured_def))
			row.add_child(equip_btn)


# ─────────────────────────────────────────────
# Equipment-Tab
# ─────────────────────────────────────────────


func _refresh_equipment_tab() -> void:
	for child in _equipment_slots.get_children():
		child.queue_free()

	var slots_to_show := ["weapon", "offhand", "helmet", "chest", "legs", "boots"]

	for slot_id in slots_to_show:
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		_equipment_slots.add_child(row)

		var icon_lbl := Label.new()
		icon_lbl.text = SLOT_ICONS.get(slot_id, "?")
		icon_lbl.custom_minimum_size = Vector2(36, 36)
		icon_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		row.add_child(icon_lbl)

		var slot_lbl := Label.new()
		slot_lbl.text = SLOT_LABELS.get(slot_id, slot_id)
		slot_lbl.custom_minimum_size = Vector2(80, 0)
		slot_lbl.add_theme_font_size_override("font_size", 14)
		slot_lbl.self_modulate = Color(0.7, 0.7, 0.8)
		row.add_child(slot_lbl)

		var item_lbl := Label.new()
		item_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		item_lbl.add_theme_font_size_override("font_size", 16)

		if is_instance_valid(_equipment) and _equipment.is_equipped(slot_id):
			var equipped := _equipment.get_equipped(slot_id)
			item_lbl.text = equipped.display_name
			item_lbl.self_modulate = Color(1.0, 0.95, 0.5)

			var unequip_btn := Button.new()
			unequip_btn.text = "❌"
			unequip_btn.custom_minimum_size = Vector2(44, 36)
			var captured_slot := slot_id
			unequip_btn.pressed.connect(func() -> void: _on_unequip(captured_slot))
			row.add_child(item_lbl)
			row.add_child(unequip_btn)
		else:
			item_lbl.text = "(leer)"
			item_lbl.self_modulate = Color(0.4, 0.4, 0.4)
			row.add_child(item_lbl)

	_refresh_stats()


func _refresh_stats() -> void:
	if not is_instance_valid(_equipment):
		_stats_label.text = ""
		return

	var weapon := _equipment.get_equipped_weapon()
	var lines: Array[String] = []
	if is_instance_valid(weapon):
		lines.append("⚔ Schaden +%.0f" % weapon.damage_bonus)
		if weapon.on_hit_effect >= 0:
			lines.append("☠ Gift: %.0f/s × %d Ticks" % [weapon.on_hit_damage_per_tick, weapon.on_hit_ticks])
	if lines.is_empty():
		_stats_label.text = "Keine aktiven Boni"
	else:
		_stats_label.text = "\n".join(lines)


# ─────────────────────────────────────────────
# Aktions-Handler
# ─────────────────────────────────────────────


func _on_equip_weapon(weapon_def: WeaponDefinition) -> void:
	if not is_instance_valid(_equipment):
		return

	# PlayerVisuals für 3D-Rendering suchen
	var player_visuals: PlayerVisuals = null
	var players := Engine.get_main_loop().get_nodes_in_group("player") if Engine.get_main_loop() else []
	if not players.is_empty():
		var player_node: Node = players[0]
		player_visuals = player_node.get_node_or_null("PlayerVisuals") as PlayerVisuals
		if not is_instance_valid(player_visuals):
			# Suche per Class-Name in Children
			for child in player_node.get_children():
				if child is PlayerVisuals:
					player_visuals = child as PlayerVisuals
					break

	_equipment.equip("weapon", weapon_def, player_visuals)
	EventBus.ui.emit_floating_text("⚔ %s angelegt!" % weapon_def.display_name)
	_refresh_equipment_tab()
	_refresh_inventory_tab()


func _on_unequip(slot: String) -> void:
	if not is_instance_valid(_equipment):
		return
	var item := _equipment.get_equipped(slot)
	_equipment.unequip(slot)
	if is_instance_valid(item):
		EventBus.ui.emit_floating_text("🔄 %s abgelegt." % item.display_name)
	_refresh_equipment_tab()


func _on_equipment_changed(_slot: String, _item_def: ItemDefinition) -> void:
	if _active_tab == "equipment":
		_refresh_equipment_tab()


# ─────────────────────────────────────────────
# Zusatz: CombatSystem-Verdrahtung für Waffen-Schaden
# ─────────────────────────────────────────────
## Wird von CombatSystem.player_melee_damage() genutzt.
## Kein direkter Aufruf hier — CombatSystem greift via Services.equipment.
