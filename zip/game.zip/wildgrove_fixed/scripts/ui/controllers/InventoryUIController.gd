# res://scripts/ui/controllers/InventoryUIController.gd
class_name InventoryUIController

var _visuals: InventoryVisuals
var _service: InventorySystem


func setup(visuals: InventoryVisuals, inv_service: InventorySystem) -> void:
	_visuals = visuals
	_service = inv_service
	# inventory_changed(player_id, items) — nur Items von Spieler 1 anzeigen.
	_service.inventory_changed.connect(
		func(player_id: int, items: Array[Dictionary]) -> void:
			if player_id == 1:
				_on_inventory_changed(items)
	)
	_update_display(_service.get_all_items())


## Manuelles Refresh — von HUDBuilder nach dem Build aufgerufen damit der
## initiale Inventar-Stand korrekt angezeigt wird (wird nach on_ready() gebaut).
func refresh() -> void:
	if is_instance_valid(_service):
		_update_display(_service.get_all_items())


func _on_inventory_changed(items: Array[Dictionary]) -> void:
	_update_display(items)


func _update_display(items: Array[Dictionary]) -> void:
	var lines: Array[String] = []
	for item in items:
		lines.append("%s ×%d" % [item["name"], item["quantity"]])
	_visuals.update_text("\n".join(lines) if not lines.is_empty() else "(Leer)")


func toggle() -> void:
	_visuals.toggle()
