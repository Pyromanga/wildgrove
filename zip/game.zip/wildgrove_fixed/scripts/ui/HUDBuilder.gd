class_name HUDBuilder

## HUDBuilder — Instanziiert und verbindet alle HUD-Komponenten.
##
## Bekommt einen UIContext injiziert statt Services.xyz direkt zu greifen.
## Das macht alle Controller testbar (UIContext.for_test() mit Mocks).


static func build_all(hud: HUD, ctx: IUIContext) -> Dictionary:
	var registry: Dictionary = {}
	var ui_events: UIEvents = EventBus.ui

	# 1. Interaktions-Fortschrittsbalken
	registry["interaction"] = InteractionComponent.new().build(hud, EventBus.world)

	# 2. Interaktions-Button
	registry["interaction_button"] = InteractionButtonComponent.new().build(hud)

	# 3. Inventar
	var inv_ctrl := InventoryComponent.new().build(hud, ctx)
	registry["inventory"] = inv_ctrl
	if inv_ctrl is InventoryUIController:
		inv_ctrl.refresh()

	# 3b. Equipment-Panel (Tab neben Inventar)
	registry["equipment"] = EquipmentComponent.new().build(hud, ctx)

	# 4. Floating Text (XP-Gains, Level-Ups)
	registry["floating_text"] = FloatingTextComponent.new().build(hud, EventBus.player)

	# 5. Benachrichtigungen
	registry["notification"] = NotificationComponent.new().build(hud)

	# 6. Joystick-Visual
	registry["joystick"] = JoystickComponent.new().build(hud)

	# 7. Kontext-Button und Menü
	registry["context_button"] = ContextButtonComponent.new().build(hud, ui_events)
	registry["context_menu"]   = ContextMenuComponent.new().build(hud, ui_events)

	# 8. Pause-/Optionsmenü
	registry["pause_menu"] = PauseMenuComponent.new().build(hud)

	# 9. Skill-Panel
	registry["skill_panel"] = SkillPanelComponent.new().build(hud, ctx)

	# 10. Quest-Panel
	registry["quest_panel"] = QuestPanelComponent.new().build(hud, ctx)

	# 11. Spieler-HP-Balken
	registry["player_hp"] = PlayerHPComponent.new().build(hud)

	# 12. Sprung-Button
	registry["jump_button"] = JumpButtonComponent.new().build(hud)

	return registry
