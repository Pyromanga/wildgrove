class_name SystemEvents extends BaseEvents

## SystemEvents.gd
## Alle systemrelevanten Signals (Save, Load, Settings, State, Session).

signal state_changed(state: int)
signal setting_changed(key: String, value: Variant)
## Internes Notify: von SaveSystem.save_game() emittiert wenn Vorgang beginnt.
## NUR für UI-Feedback/Logging nutzen — NICHT um save_all() zu triggern!
signal save_started
## Externer Auslöser: von UI/Buttons emittiert um einen Speichervorgang anzufordern.
## GameSaveService lauscht hierauf und ruft save_all() auf.
signal save_requested
## Pre-Flush-Hook: von GameSaveService emittiert direkt BEVOR save_game() läuft.
signal save_pre_flush
signal save_completed(success: bool)
signal load_started
signal load_completed(success: bool)
signal services_initialized
signal boot_failed(phase: String, reason: String)
## Emittiert von SaveSystem.delete_save_for() wenn ein Slot erfolgreich gelöscht wurde.
signal save_slot_deleted(player_id: String)

## ── Session-Lifecycle (ADR-009) ─────────────────────────────────
## Emittiert von MainMenuController wenn Spieler einen Charakter auswählt.
## ServiceOrchestrator lauscht hierauf und startet boot_session(player_id).
signal session_requested(player_id: String)
## Emittiert von ServiceOrchestrator wenn boot_session() abgeschlossen ist.
## GameManager lauscht hierauf und wechselt in PLAYING-State.
signal session_ready
## Emittiert von ServiceOrchestrator wenn teardown_session() abgeschlossen ist.
## MainMenuController lauscht hierauf für UI-Refresh.
signal session_unloaded


func _init() -> void:
	super._init("Events/System")


func emit_state_changed(state: int) -> void:
	_log_info("GameState geändert → %d" % state)
	state_changed.emit(state)


func emit_setting_changed(key: String, value: Variant) -> void:
	_log("Setting geändert: '%s' = %s" % [key, str(value)])
	setting_changed.emit(key, value)


func emit_save_started() -> void:
	_log_info("Speichervorgang gestartet...")
	save_started.emit()


func emit_save_pre_flush() -> void:
	_log_info("Pre-Flush: Services bereiten Save-Daten vor.")
	save_pre_flush.emit()


func emit_save_requested() -> void:
	_log_info("Speichervorgang angefordert (extern).")
	save_requested.emit()


func emit_save_completed(success: bool) -> void:
	if success:
		_log_info("Speichervorgang erfolgreich.")
	else:
		_log_warn("Speichervorgang fehlgeschlagen!")
	save_completed.emit(success)


func emit_save_slot_deleted(player_id: String) -> void:
	_log_info("Save-Slot gelöscht: '%s'" % player_id)
	save_slot_deleted.emit(player_id)


func emit_load_started() -> void:
	_log_info("Ladevorgang gestartet...")
	load_started.emit()


func emit_load_completed(success: bool) -> void:
	if success:
		_log_info("Ladevorgang erfolgreich.")
	else:
		_log_warn("Ladevorgang fehlgeschlagen!")
	load_completed.emit(success)


func emit_services_initialized() -> void:
	_log_info("Systemdienste vollständig initialisiert.")
	services_initialized.emit()


func emit_session_requested(player_id: String) -> void:
	_log_info("Session angefordert für Charakter '%s'." % player_id)
	session_requested.emit(player_id)


func emit_session_ready() -> void:
	_log_info("Session bereit — Spiel kann starten.")
	session_ready.emit()


func emit_session_unloaded() -> void:
	_log_info("Session beendet — zurück zum Hauptmenü.")
	session_unloaded.emit()
