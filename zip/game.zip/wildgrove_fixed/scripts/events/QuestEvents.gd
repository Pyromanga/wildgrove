class_name QuestEvents
extends BaseEvents

## QuestEvents — EventBus-Namespace für alle Quest-Signale.
##
## Einbinden in EventBus.gd:
##   var quest: QuestEvents
##   # in _ready():
##   quest = QuestEvents.new()
##
## Verwendung:
##   EventBus.quest.quest_started.connect(_on_quest_started)
##   EventBus.quest.emit_quest_completed("quest_tutorial")

signal quest_started(quest_id: String)
## Von Quest-Gebern (z.B. QuestNPC) gesendet um eine Quest zu starten.
## QuestService lauscht hierauf — kein direkter Services.quest.start_quest()-Call nötig.
signal quest_start_requested(quest_id: String)
## Von QuestService gesendet wenn ein start_request fehlschlägt (Prereq, schon aktiv, etc.)
signal quest_start_failed(quest_id: String, reason: String)
signal quest_objective_updated(quest_id: String, objective_id: String, current: int, required: int)
signal quest_completed(quest_id: String, reward: QuestReward)
signal quest_failed(quest_id: String)
signal quest_unlocked(quest_id: String)
## Von RewardDispatcher gesendet wenn ein Quest-Reward ein Quest freischalten soll.
## QuestService lauscht hierauf statt direkt von RewardDispatcher aufgerufen zu werden.
signal quest_unlock_requested(quest_id: String)
## Für custom_signals in QuestReward — beliebige Quest-Ereignisse ohne eigenes Signal.
signal reward_custom_signal(signal_key: String)


func _init() -> void:
	super._init("Events/Quest")


func emit_quest_start_failed(quest_id: String, reason: String) -> void:
	_log_warn("Quest-Start fehlgeschlagen '%s': %s" % [quest_id, reason])
	quest_start_failed.emit(quest_id, reason)


func emit_quest_start_requested(quest_id: String) -> void:
	_log("Quest-Start angefordert: '%s'" % quest_id)
	quest_start_requested.emit(quest_id)


func emit_quest_started(quest_id: String) -> void:
	_log_info("Quest gestartet: '%s'" % quest_id)
	quest_started.emit(quest_id)


func emit_objective_updated(
	quest_id: String, objective_id: String, current: int, required: int
) -> void:
	_log("Objective '%s/%s': %d/%d" % [quest_id, objective_id, current, required])
	quest_objective_updated.emit(quest_id, objective_id, current, required)


func emit_quest_completed(quest_id: String, reward: QuestReward) -> void:
	_log_info("Quest abgeschlossen: '%s'" % quest_id)
	quest_completed.emit(quest_id, reward)


func emit_quest_failed(quest_id: String) -> void:
	_log_warn("Quest fehlgeschlagen: '%s'" % quest_id)
	quest_failed.emit(quest_id)


func emit_quest_unlocked(quest_id: String) -> void:
	_log_info("Quest freigeschalten: '%s'" % quest_id)
	quest_unlocked.emit(quest_id)


func emit_quest_unlock_requested(quest_id: String) -> void:
	_log("Quest-Unlock angefordert (von RewardDispatcher): '%s'" % quest_id)
	quest_unlock_requested.emit(quest_id)


func emit_reward_signal(signal_key: String) -> void:
	_log("Custom-Reward-Signal: '%s'" % signal_key)
	reward_custom_signal.emit(signal_key)
