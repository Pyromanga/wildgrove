class_name InteractionSensor extends Area3D

## InteractionSensor — findet das nächste interagierbare Objekt in Reichweite.
##
## Verantwortung: Synchronen Lookup via get_closest() liefern UND
## proximity_changed emittieren wenn sich das nächste Ziel ändert.
##
## WICHTIG: Der Sensor ist die einzige Autorität für proximity_changed.
##   InteractableComponent emittiert proximity_changed nur noch für Logging-Zwecke.
##   Der Sensor aggregiert alle Area3D-Überlappungen und gibt nur das nächste Ziel aus.
##   Das verhindert Flickering wenn der Spieler zwischen zwei Entities läuft.
##
## CollisionShape wird von Player._build_sensor() gesetzt (Radius: 2.5m).

const LOG_CAT := "Sensor"

var _last_closest: Node3D = null


func _ready() -> void:
	Logger.log_debug(
		"InteractionSensor bereit. Monitoring: %s, Monitorable: %s."
		% [str(monitoring), str(monitorable)],
		LOG_CAT
	)

	if not monitoring:
		monitoring = true
		Logger.log_warn("monitoring war false — automatisch aktiviert.", LOG_CAT)


func _physics_process(_delta: float) -> void:
	var current := get_closest()

	if current == _last_closest:
		return  # Kein Wechsel — nichts zu tun

	# Ziel hat sich geändert — proximity_changed für altes und neues Ziel emittieren
	if is_instance_valid(_last_closest):
		Logger.log_debug("Ziel verloren: '%s'." % _last_closest.name, LOG_CAT)
		EventBus.world.emit_proximity_changed(_last_closest, false)

	if is_instance_valid(current):
		var dist := global_position.distance_to(current.global_position)
		Logger.log_info(
			"Nächstes Ziel: '%s' (Dist: %.2fm)." % [current.name, dist],
			LOG_CAT
		)
		EventBus.world.emit_proximity_changed(current, true)
	else:
		Logger.log_info("Kein Ziel mehr in Reichweite.", LOG_CAT)

	_last_closest = current


## Gibt das nächste Objekt in der "interactable"-Gruppe zurück, oder null.
## Nutzt get_overlapping_bodies() für Physics-Bodies und get_overlapping_areas() für Area3D-Entities.
func get_closest() -> Node3D:
	var closest: Node3D = null
	var min_dist := 999.0

	# Overlapping Bodies (für CharacterBody3D, StaticBody3D Entities)
	for body in get_overlapping_bodies():
		if body is Node3D and body.is_in_group("interactable"):
			var dist := global_position.distance_to((body as Node3D).global_position)
			if dist < min_dist:
				min_dist = dist
				closest = body

	# Overlapping Areas (für Area3D-basierte Entities — deckt InteractableComponent ab)
	for area in get_overlapping_areas():
		# Die InteractableComponent erstellt eine Area3D als Kind.
		# Ihr Parent (z.B. OakTree) ist das eigentliche Interagierbare.
		var area_parent := area.get_parent()
		# Nicht auf die eigene InteractableComponent-Area reagieren (deren Parent ist InteractableComponent selbst)
		if not is_instance_valid(area_parent):
			continue
		# Wenn der Parent der Area3D in der Gruppe "interactable" ist → das ist der Entity-Root
		if area_parent.is_in_group("interactable"):
			var dist := global_position.distance_to(area_parent.global_position)
			if dist < min_dist:
				min_dist = dist
				closest = area_parent
		# Wenn der Großvater in der Gruppe ist (Area3D ist Kind von InteractableComponent ist Kind von Entity)
		elif is_instance_valid(area_parent.get_parent()) and area_parent.get_parent().is_in_group("interactable"):
			var grandparent := area_parent.get_parent() as Node3D
			var dist := global_position.distance_to(grandparent.global_position)
			if dist < min_dist:
				min_dist = dist
				closest = grandparent

	return closest


## Gibt true zurück wenn gerade ein Ziel in Reichweite ist.
func has_target() -> bool:
	return is_instance_valid(get_closest())
