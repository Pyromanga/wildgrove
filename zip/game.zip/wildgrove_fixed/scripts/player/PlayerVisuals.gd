extends Node3D
class_name PlayerVisuals

## PlayerVisuals — Capsule-Mesh + Skeleton mit benannten Bones.
##
## Bone-Hierarchie (Indices sind stabil — nie umsortieren ohne WeaponVisual3D zu prüfen):
##   0  root       — Wurzel, sitzt auf Boden (y=0)
##   1  spine      — Rumpf-Mitte (~y=0.9)
##   2  head       — Kopf-Ansatz (~y=1.6)
##   3  hand_r     — Rechte Hand (~y=1.1, x=+0.4) — Waffenhalte-Punkt
##   4  hand_l     — Linke Hand  (~y=1.1, x=-0.4)
##
## Warum Skeleton ohne Animation-Player:
##   WeaponVisual3D braucht einen stabilen world-space Attachment-Punkt.
##   BoneAttachment3D liefert genau das ohne eigene Animation zu benötigen.
##   Animationen können später hinzugefügt werden ohne diese API zu brechen.
##
## get_bone_attachment(bone_name) gibt eine BoneAttachment3D zurück die
## bereits unter dem Skeleton hängt — Aufrufer fügen ihre Nodes dort ein.

const LOG_CAT := "PlayerVisuals"

var mesh:     MeshInstance3D
var skeleton: Skeleton3D
var rotation_speed: float = 10.0

## Bone-Name → Index-Cache, gefüllt in _build_skeleton().
var _bone_index: Dictionary = {}

## Vorbelegte BoneAttachments, keyed by bone_name.
var _attachments: Dictionary = {}


func _init() -> void:
	_build_skeleton()
	_build_mesh()


# ─────────────────────────────────────────────
# Aufbau
# ─────────────────────────────────────────────

func _build_skeleton() -> void:
	skeleton = Skeleton3D.new()
	skeleton.name = "Skeleton3D"
	add_child(skeleton)

	# Bone 0: root — Basis, kein Parent
	var root_idx := skeleton.add_bone("root")
	skeleton.set_bone_rest(root_idx, Transform3D(Basis(), Vector3(0.0, 0.0, 0.0)))

	# Bone 1: spine — Parent: root
	var spine_idx := skeleton.add_bone("spine")
	skeleton.set_bone_parent(spine_idx, root_idx)
	skeleton.set_bone_rest(spine_idx, Transform3D(Basis(), Vector3(0.0, 0.9, 0.0)))

	# Bone 2: head — Parent: spine
	var head_idx := skeleton.add_bone("head")
	skeleton.set_bone_parent(head_idx, spine_idx)
	skeleton.set_bone_rest(head_idx, Transform3D(Basis(), Vector3(0.0, 0.7, 0.0)))

	# Bone 3: hand_r — Parent: spine (rechte Hand, Waffenhalte-Punkt)
	var hand_r_idx := skeleton.add_bone("hand_r")
	skeleton.set_bone_parent(hand_r_idx, spine_idx)
	skeleton.set_bone_rest(hand_r_idx, Transform3D(Basis(), Vector3(0.4, 0.2, 0.0)))

	# Bone 4: hand_l — Parent: spine (linke Hand)
	var hand_l_idx := skeleton.add_bone("hand_l")
	skeleton.set_bone_parent(hand_l_idx, spine_idx)
	skeleton.set_bone_rest(hand_l_idx, Transform3D(Basis(), Vector3(-0.4, 0.2, 0.0)))

	# Index-Cache füllen
	_bone_index = {
		"root":   root_idx,
		"spine":  spine_idx,
		"head":   head_idx,
		"hand_r": hand_r_idx,
		"hand_l": hand_l_idx,
	}

	# BoneAttachments vorbelegen — bereit für WeaponVisual3D etc.
	for bone_name in _bone_index:
		var att := BoneAttachment3D.new()
		att.name            = "Attach_" + bone_name
		att.bone_name       = bone_name
		att.use_external_skeleton = false
		skeleton.add_child(att)
		_attachments[bone_name] = att

	Logger.log_debug("Skeleton: %d Bones, %d Attachments." % [skeleton.get_bone_count(), _attachments.size()], LOG_CAT)


func _build_mesh() -> void:
	## Mesh hängt unter dem Skeleton damit es später per SkinInstance korrekt deformiert
	## werden kann. Aktuell kein Skinning — rein visuell zentriert auf die Kapsel.
	mesh = MeshInstance3D.new()
	mesh.name = "BodyMesh"
	mesh.mesh = CapsuleMesh.new()
	mesh.position = Vector3(0.0, 1.0, 0.0)
	skeleton.add_child(mesh)


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Gibt die BoneAttachment3D für einen Bone-Namen zurück.
## Aufrufer (z.B. WeaponVisual3D) hängen ihre Nodes dort als Child ein.
## Gibt null zurück wenn der Bone nicht existiert — Aufrufer prüfen mit is_instance_valid().
func get_bone_attachment(bone_name: String) -> BoneAttachment3D:
	if not _attachments.has(bone_name):
		Logger.log_warn("PlayerVisuals: unbekannter Bone '%s'." % bone_name, LOG_CAT)
		return null
	return _attachments[bone_name] as BoneAttachment3D


## Gibt den Bone-Index zurück (-1 wenn nicht vorhanden).
func get_bone_index(bone_name: String) -> int:
	return _bone_index.get(bone_name, -1)


func handle_rotation(direction: Vector3, delta: float) -> void:
	if direction.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(direction.x, direction.z), rotation_speed * delta)


## Visuelles Feedback für verschiedene Events.
func play_effect(effect_name: String) -> void:
	match effect_name:
		"interrupted":
			var tween := create_tween()
			tween.tween_property(self, "position:x",  0.15, 0.05)
			tween.tween_property(self, "position:x", -0.15, 0.05)
			tween.tween_property(self, "position:x",  0.0,  0.05)
