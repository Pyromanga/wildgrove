extends CharacterBody3D
class_name Player

## Player.gd — Gameplay-Loop, State-Machine, Death/Respawn.
## Setup-Logik (Subsystem-Bau) → PlayerSetup.gd
##
## Player wird via EntityOrchestrator.spawn_entity("player", pos) gespawnt.
## on_spawn(config, ctx) übernimmt Initialisierung — identisch zu allen anderen Entities.
## Initialer State kommt via EventBus.player.player_state_changed (PlayerStateService
## emittiert beim ersten set_state()). Kein einmaliges Polling mehr nötig.

const LOG_CAT       := "Player"
const JUMP_VELOCITY := 6.0

var _mover:  PlayerMover
var visuals: PlayerVisuals
var camera:  PlayerCamera
var input:   TouchInput
var sensor:  InteractionSensor
var health:  HealthComponent

var _jump_requested: bool    = false
var _spawn_position: Vector3 = Vector3.ZERO
var _is_dead:        bool    = false

## Lokaler State-Cache — wird via EventBus aktualisiert, nie per Polling.
var _player_state: PlayerStateService.State = PlayerStateService.State.FREE


func _ready() -> void:
	add_to_group("player")
	set_physics_process(false)
	# State-Updates via EventBus — kein Service-Lookup per Frame.
	EventBus.player.movement_interrupted.connect(_on_action_interrupted)
	EventBus.player.player_state_changed.connect(_on_player_state_changed)
	Logger.log_debug("Player _ready(). Warte auf on_spawn().", LOG_CAT)


## on_spawn() — Einstiegspunkt via EntityOrchestrator. Kein Services.xyz.
## ctx liefert alle benötigten Services. config kann spawn_position enthalten.
func on_spawn(config: Dictionary, ctx: IEntityContext) -> void:
	Logger.log_info("Player on_spawn() — initialisiere Subsysteme.", LOG_CAT)

	var subs := PlayerSetup.build(self)
	_mover  = subs["mover"]
	visuals = subs["visuals"]
	camera  = subs["camera"]
	input   = subs["input"]
	sensor  = subs["sensor"]
	health  = subs["health"]
	health.died.connect(_on_player_died)

	PlayerSetup.apply_stats(_mover, ctx)

	# Spawn-Position aus config falls vorhanden, sonst aktuelle Position.
	if config.has("spawn_position"):
		global_position = config["spawn_position"]
	_spawn_position = global_position

	set_physics_process(true)
	Logger.log_info("Player online. Position: %s." % str(global_position), LOG_CAT)


func on_despawn() -> void:
	set_physics_process(false)
	Logger.log_info("Player despawned.", LOG_CAT)


# ─────────────────────────────────────────────
# Physics-Loop — kein Services.xyz-Zugriff
# ─────────────────────────────────────────────

func _physics_process(delta: float) -> void:
	match _player_state:
		PlayerStateService.State.FREE:
			_loop_free(delta)
		PlayerStateService.State.BUSY:
			_loop_busy(delta)
		_:
			velocity = Vector3.ZERO
			move_and_slide()


func _loop_free(delta: float) -> void:
	var move_dir := MathHelper.calculate_move_direction(camera, input.js_vec)
	velocity = _mover.calculate_velocity(velocity, move_dir, delta, is_on_floor())
	if _jump_requested:
		_jump_requested = false
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
	move_and_slide()
	visuals.handle_rotation(move_dir, delta)
	camera.handle_input(input, delta)


func _loop_busy(delta: float) -> void:
	if input.js_vec.length() > 0.5:
		EventBus.player.emit_movement_interrupted()
	velocity = velocity.move_toward(Vector3.ZERO, 15.0 * delta)
	move_and_slide()
	camera.handle_input(input, delta)


# ─────────────────────────────────────────────
# Jump / Death / Respawn
# ─────────────────────────────────────────────

func request_jump() -> void:
	_jump_requested = true


func _on_player_died() -> void:
	if _is_dead:
		return
	_is_dead = true
	Logger.log_info("Spieler gestorben — Respawn in 2s.", LOG_CAT)
	EventBus.player.emit_player_died()
	get_tree().create_timer(2.0).timeout.connect(
		func() -> void:
			if is_instance_valid(self):
				_respawn()
	)


func _respawn() -> void:
	global_position = _spawn_position
	if is_instance_valid(health):
		health.reset()
	velocity        = Vector3.ZERO
	_is_dead        = false
	_jump_requested = false
	EventBus.player.emit_player_respawned()
	Logger.log_info("Spieler respawnt.", LOG_CAT)


func _on_action_interrupted() -> void:
	visuals.play_effect("interrupted")


## Event-Handler für State-Updates vom PlayerStateService via EventBus.
func _on_player_state_changed(new_state: int) -> void:
	_player_state = new_state as PlayerStateService.State


# ─────────────────────────────────────────────
# Öffentliche API — Interaktion
# ─────────────────────────────────────────────

func get_closest_interactable() -> Node3D:
	return sensor.get_closest() if is_instance_valid(sensor) else null


func get_context_actions() -> Array[InteractableAction]:
	var target := get_closest_interactable()
	if not is_instance_valid(target):
		return []

	Logger.log_debug("Kontext für '%s'." % target.name, LOG_CAT)

	if target.has_meta("interactable_component"):
		var comp: InteractableComponent = target.get_meta("interactable_component")
		if is_instance_valid(comp):
			var actions := comp.get_actions()
			Logger.log_info("%d Aktion(en) für '%s'." % [actions.size(), target.name], LOG_CAT)
			return actions

	# Fallback: Child-Traversal
	for child in target.get_children():
		if child is InteractableComponent:
			return (child as InteractableComponent).get_actions()

	if target.has_method("start_default_interaction"):
		var fallback := InteractableAction.new("interact", "Interagieren")
		fallback.duration   = 1.5
		fallback.on_complete = func(): target.start_default_interaction()
		return [fallback]

	return []
