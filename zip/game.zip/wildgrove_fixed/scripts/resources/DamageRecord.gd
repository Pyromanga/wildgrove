class_name DamageRecord
extends RefCounted

## DamageRecord — Unveränderlicher Datenbehälter für einen einzelnen Schadenspunkt.
##
## Wird von CombatSystem erstellt und dann weitergegeben:
##   CombatSystem.calculate_damage() → DamageRecord
##   HealthComponent.take_damage_record(record) → wendet final_amount an
##   EventBus.world.damage_dealt emittiert den fertigen Record
##
## NIEMALS nachträglich mutieren — Record ist nach calculate_damage() final.

## Schadenstypen (entsprechen ADR-008-Entscheidung).
## PHYSICAL → durch Rüstung reduziert
## MAGIC    → durch magische Resistenz reduziert
## TRUE     → ignoriert alle Resistenzen (Gifttränke, Sturz, etc.)
enum DamageType {
	PHYSICAL,
	MAGIC,
	TRUE,
}

## UUID der angreifenden Entity. Leer = Umweltschaden (Sturz, Gift).
var source_id: String = ""

## UUID des Ziels.
var target_id: String = ""

## Roh-Schaden vor Resistenz-Berechnung.
var raw_amount: float = 0.0

## Schadenstyp — bestimmt welche Resistenzen angewendet werden.
var damage_type: DamageType = DamageType.PHYSICAL

## Finaler Schaden nach Berechnung (was tatsächlich abgezogen wird).
## Wird von CombatSystem.calculate_damage() gesetzt.
var final_amount: float = 0.0

## Ob dieser Treffer ein kritischer Treffer war.
var is_critical: bool = false

## Optionaler Freitext — z.B. "fall_damage", "poison_tick", "reflect" für Logging.
var context_tag: String = ""


## Factory: erstellt einen Record für Spieler-Angriff auf Enemy.
static func make_player_attack(
		source: String,
		target: String,
		raw: float,
		dtype: DamageType = DamageType.PHYSICAL
) -> DamageRecord:
	var r := DamageRecord.new()
	r.source_id  = source
	r.target_id  = target
	r.raw_amount = raw
	r.damage_type = dtype
	return r


## Factory: erstellt einen Record für Enemy-Angriff auf Spieler (TD-11).
## Eigene Factory statt Wiederverwendung von make_player_attack() — der Name
## dokumentiert die Angriffsrichtung direkt im Log (context_tag), nicht nur
## über source_id/target_id, die je nach Entity-UUID kryptisch sein können.
static func make_enemy_attack(
		source: String,
		target: String,
		raw: float,
		dtype: DamageType = DamageType.PHYSICAL
) -> DamageRecord:
	var r := DamageRecord.new()
	r.source_id   = source
	r.target_id   = target
	r.raw_amount  = raw
	r.damage_type = dtype
	r.context_tag = "enemy_melee"
	return r


## Factory: erstellt einen Record für Umweltschaden (kein Angreifer).
static func make_environmental(
		target: String,
		raw: float,
		tag: String = ""
) -> DamageRecord:
	var r := DamageRecord.new()
	r.source_id   = ""
	r.target_id   = target
	r.raw_amount  = raw
	r.damage_type = DamageType.TRUE
	r.context_tag = tag
	return r


func to_debug_string() -> String:
	return "DamageRecord[%s→%s type=%d raw=%.1f final=%.1f crit=%s tag=%s]" % [
		source_id if source_id else "ENV",
		target_id if target_id else "?",
		damage_type,
		raw_amount,
		final_amount,
		"YES" if is_critical else "no",
		context_tag if context_tag else "-",
	]
