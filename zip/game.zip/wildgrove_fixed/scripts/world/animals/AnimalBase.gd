extends CharacterBody3D
class_name AnimalBase

## AnimalBase — Basisklasse für alle Tiere.
##
## State Machine: IDLE → WANDER → FLEE (Spieler zu nah)
## Unterklassen überschreiben _on_ready_extended() für Farbe, Größe, Speed.
##
## Delegiert Geometrie-Bau → AnimalVisualBuilder (statische Helfer-Klasse)
##
## INTERAKTION: InteractableComponent ruft _on_interacted(action_id) am Parent auf.

const LOG_CAT := "Animal"
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)

enum State { IDLE, WANDER, FLEE }

var _color:        Color   = Color(0.7, 0.5, 0.3)
var _body_size:    Vector3 = Vector3(0.4, 0.6, 0.4)
var _speed:        float   = 3.0
var _flee_radius:  float   = 5.0
var _idle_time:    float   = 2.0
var _wander_range: float   = 8.0
var _home_radius:  float   = 15.0

var _state:         State   = State.IDLE
var _state_timer:   float   = 0.0
var _wander_target: Vector3 = Vector3.ZERO
var _spawn_origin:  Vector3 = Vector3.ZERO
var _player_ref:    Node3D  = null  # Cached once — no per-frame SceneTree scan


func _ready() -> void:
	_spawn_origin = global_position
	_on_ready_extended()
	# Cache the player reference once instead of scanning the SceneTree every physics frame.
	# If the player node isn't in the tree yet, wait for the group to be populated.
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty():
		_player_ref = players[0] as Node3D

	var base_name: String = name if (not name.begins_with("@") and not name.is_empty()) else "Animal"
	name = "%s%d" % [base_name, get_instance_id() % 999]

	# Geometrie über Builder — kein Mesh-Code in dieser Datei
	add_child(AnimalVisualBuilder.build(_color, _body_size))
	_build_collision()
	add_to_group("animals")
	_setup_catch_interaction()
	Logger.log_debug("Tier '%s' @ %s" % [name, str(global_position)], LOG_CAT)


func _on_ready_extended() -> void:
	pass  ## Unterklassen: hier name, _color, _body_size, _speed setzen


# ─────────────────────────────────────────────
# Interaktion
# ─────────────────────────────────────────────


func _setup_catch_interaction() -> void:
	var d := InteractableData.new()
	d.id           = "catch_animal"
	d.label        = "Tier fangen"
	d.duration     = 2.0
	d.xp_type      = "none"
	d.xp_amount    = 0
	d.drops        = {}
	d.inspect_text = get_inspect_text()
	var comp := InteractableComponent.new()
	comp.data = d
	add_child(comp)
	# Connect signal upward — component never calls get_parent() directly.
	comp.interacted.connect(_on_interacted)


func _on_interacted(action_id: String) -> void:
	if action_id == "catch_animal":
		AnimalCatcher.catch_animal(self)


## Unterklassen überschreiben für individuelle Beschreibung.
func get_inspect_text() -> String:
	return "Ein Tier."


# ─────────────────────────────────────────────
# Physics / AI
# ─────────────────────────────────────────────


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0

	_state_timer -= delta

	match _state:
		State.IDLE:
			velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)
			if _state_timer <= 0.0:
				_enter_wander()
		State.WANDER:
			_move_toward(_wander_target, _speed, delta)
			if global_position.distance_to(_wander_target) < 0.6 or _state_timer <= 0.0:
				_enter_idle()
		State.FLEE:
			_move_toward(_wander_target, _speed * 2.2, delta)
			if _state_timer <= 0.0:
				_enter_idle()

	var home_flat := Vector2(
		global_position.x - _spawn_origin.x,
		global_position.z - _spawn_origin.z
	)
	if home_flat.length() > _home_radius and _state != State.FLEE:
		_wander_target = _spawn_origin
		_state         = State.WANDER
		_state_timer   = 4.0

	move_and_slide()
	_check_player_proximity()


func _check_player_proximity() -> void:
	# Use the cached reference — zero SceneTree traversal per frame.
	if not is_instance_valid(_player_ref):
		# Retry cache once (handles the case where player spawned after this animal).
		var players := get_tree().get_nodes_in_group("player")
		if players.is_empty():
			return
		_player_ref = players[0] as Node3D
	if global_position.distance_to(_player_ref.global_position) < _flee_radius \
	   and _state != State.FLEE:
		var flee_dir: Vector3 = (global_position - _player_ref.global_position).normalized()
		_wander_target = global_position + flee_dir * _wander_range
		_state         = State.FLEE
		_state_timer   = 3.5


func _move_toward(target: Vector3, spd: float, delta: float) -> void:
	var dir: Vector3 = target - global_position
	dir.y = 0.0
	if dir.length_squared() > 0.01:
		dir = dir.normalized()
		velocity.x = move_toward(velocity.x, dir.x * spd, 12.0 * delta)
		velocity.z = move_toward(velocity.z, dir.z * spd, 12.0 * delta)
		look_at(global_position + dir, Vector3.UP)


func _enter_idle() -> void:
	_state       = State.IDLE
	_state_timer = _idle_time + randf_range(-0.5, 1.5)


func _enter_wander() -> void:
	_state       = State.WANDER
	_state_timer = 3.0 + randf_range(0.0, 2.0)
	_wander_target = _spawn_origin + Vector3(
		randf_range(-_wander_range, _wander_range),
		0.0,
		randf_range(-_wander_range, _wander_range)
	)


# ─────────────────────────────────────────────
# Collision
# ─────────────────────────────────────────────


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius  = _body_size.x * 0.45
	sh.height  = _body_size.y
	col.shape  = sh
	col.position.y = _body_size.y * 0.5
	add_child(col)


# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────


func on_spawn(_cfg: Dictionary) -> void:
	_spawn_origin = global_position
	_enter_idle()


func on_despawn() -> void:
	pass
