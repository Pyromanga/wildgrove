class_name AnimalVisualBuilder
extends RefCounted

## AnimalVisualBuilder — Baut die prozedurale Tier-Geometrie.
##
## Extrahiert aus AnimalBase._build_visuals() und _add_legs().
## Stateless — keine Member-Variablen. Gibt einen Node3D ("Visuals") zurück
## der direkt per add_child() an das Tier gehängt werden kann.

## Baut Kapsel-Körper + Kugelkopf + 4 Zylinder-Beine.
## body_size: Vector3(x=radius*2, y=Höhe, z=Tiefe)
static func build(color: Color, body_size: Vector3) -> Node3D:
	var root := Node3D.new()
	root.name = "Visuals"

	# Körper
	var bm   := CapsuleMesh.new()
	bm.radius = body_size.x * 0.5
	bm.height = body_size.y
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = color
	var bmi  := MeshInstance3D.new()
	bmi.mesh              = bm
	bmi.material_override = bmat
	bmi.position.y        = body_size.y * 0.5
	root.add_child(bmi)

	# Kopf
	var hm   := SphereMesh.new()
	hm.radius = body_size.x * 0.35
	hm.height = body_size.x * 0.7
	var hmat := StandardMaterial3D.new()
	hmat.albedo_color = color.lightened(0.1)
	var hmi  := MeshInstance3D.new()
	hmi.mesh              = hm
	hmi.material_override = hmat
	hmi.position          = Vector3(0.0, body_size.y * 1.05, body_size.x * 0.25)
	root.add_child(hmi)

	# Beine
	_add_legs(root, color, body_size)

	return root


static func _add_legs(parent: Node3D, color: Color, body_size: Vector3) -> void:
	var lmat := StandardMaterial3D.new()
	lmat.albedo_color = color.darkened(0.2)

	var offsets: Array[Vector3] = [
		Vector3(-body_size.x * 0.3, 0.0, -body_size.z * 0.2),
		Vector3( body_size.x * 0.3, 0.0, -body_size.z * 0.2),
		Vector3(-body_size.x * 0.3, 0.0,  body_size.z * 0.2),
		Vector3( body_size.x * 0.3, 0.0,  body_size.z * 0.2),
	]

	for lp: Vector3 in offsets:
		var lm  := CylinderMesh.new()
		lm.top_radius    = body_size.x * 0.08
		lm.bottom_radius = body_size.x * 0.08
		lm.height        = body_size.y * 0.55
		var lmi := MeshInstance3D.new()
		lmi.mesh              = lm
		lmi.material_override = lmat
		lmi.position          = lp + Vector3(0.0, body_size.y * 0.27, 0.0)
		parent.add_child(lmi)
