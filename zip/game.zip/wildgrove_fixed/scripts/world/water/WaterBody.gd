extends Node3D
class_name WaterBody

## WaterBody — Platzierbares Wasser-Objekt.
##
## Kann als See, Fluss-Abschnitt, Bergsee oder Wasserfall-Becken verwendet werden.
## Position und Größe sind frei wählbar → funktioniert für:
##   - Seen auf beliebiger Höhe (Bergsee bei y=5)
##   - Fluss-Segmente mit Gefälle (mehrere WaterBodies gestaffelt)
##   - Höhlenseen (unter Terrain, beleuchtet durch Emission)
##   - Trockene Höhlen (einfach keinen WaterBody platzieren)
##
## Rendering: opakes Box-Mesh.
##   - Kein Depth-Hacking, kein render_priority, keine Transparenz-Probleme.
##   - Box schaut von oben wie eine Wasserfläche aus, von der Seite sieht man
##     die Tiefe (dunkleres Blau für tiefer liegende Flächen).
##
## Kollision: StaticBody3D damit der Spieler nicht durch das Wasser fällt,
##   aber mit niedrigerer Friction (fühlt sich wie Waten an).
##   Für "Schwimmen" kann hier later ein Area3D ergänzt werden.

## Größe der Wasserfläche in Metern (x=Breite, y=Tiefe, z=Länge)
## Größe der Wasserfläche. y = Tiefe (mindestens 4m damit Spieler nicht den Tümpel füllt).
@export var water_size: Vector3 = Vector3(20.0, 4.0, 20.0)

## Farben für Oberfläche und Tiefe
const COL_SURFACE := Color(0.12, 0.42, 0.78, 1.0)
const COL_DEEP    := Color(0.04, 0.14, 0.38, 1.0)


func _ready() -> void:
	_build()


func _build() -> void:
	# Oberflächen-Mesh (dünne Plane oben)
	var surface_mi := _build_surface()
	surface_mi.name = "WaterSurface"
	add_child(surface_mi)

	# Volumen-Box (sichtbare Tiefe von der Seite)
	var volume_mi := _build_volume()
	volume_mi.name = "WaterVolume"
	add_child(volume_mi)

	# Physik (optional — verhindert Durchfallen)
	var body := _build_physics()
	body.name = "WaterPhysics"
	add_child(body)


func _build_surface() -> MeshInstance3D:
	var mesh := PlaneMesh.new()
	mesh.size = Vector2(water_size.x, water_size.z)
	mesh.subdivide_width  = 8
	mesh.subdivide_depth  = 8

	var mat := StandardMaterial3D.new()
	mat.albedo_color      = COL_SURFACE
	mat.roughness         = 0.05
	mat.metallic          = 0.4
	mat.transparency      = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color.a    = 0.85
	# CULL_DISABLED: von beiden Seiten sichtbar (unter Wasser + von oben)
	mat.cull_mode         = BaseMaterial3D.CULL_DISABLED

	var mi := MeshInstance3D.new()
	mi.mesh              = mesh
	mi.material_override = mat
	mi.position.y        = 0.0
	return mi


func _build_volume() -> MeshInstance3D:
	## Sichtbare Tiefe — Box unter der Oberfläche, dunkler gefärbt.
	var mesh := BoxMesh.new()
	mesh.size = Vector3(water_size.x, water_size.y, water_size.z)

	var mat := StandardMaterial3D.new()
	mat.albedo_color = COL_DEEP
	mat.roughness    = 0.1
	mat.metallic     = 0.1

	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = mat
	mi.position.y = -water_size.y * 0.5  # Mitte der Box liegt unter der Oberfläche
	return mi


func _build_physics() -> StaticBody3D:
	var body := StaticBody3D.new()
	var col  := CollisionShape3D.new()
	var sh   := BoxShape3D.new()
	sh.size    = Vector3(water_size.x, water_size.y, water_size.z)
	col.shape  = sh
	col.position.y = -water_size.y * 0.5
	body.add_child(col)
	return body


## Erstellt einen WaterBody und fügt ihn zu `parent` hinzu.
## pos: Weltposition der OBERFLÄCHE des Wassers (y = Oberkante).
## size: Vector3(breite, tiefe, länge).
static func place(parent: Node3D, pos: Vector3, size: Vector3 = Vector3(20, 2, 20)) -> WaterBody:
	var wb := WaterBody.new()
	wb.water_size = size
	wb.position   = pos
	parent.add_child(wb)
	return wb
