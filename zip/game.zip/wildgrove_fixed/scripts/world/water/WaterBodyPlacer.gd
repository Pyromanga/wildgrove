class_name WaterBodyPlacer
extends RefCounted

## WaterBodyPlacer — Platziert WaterBody-Nodes anhand von Terrain-Tiefen.
##
## Ausgelagert aus WorldSpawner._place_water_bodies() (v28).
## Analog zu ChunkWaterPlacer, aber für die Hauptwelt (nicht Chunks).
##
## Algorithmus:
##   1. Terrain in einem Raster abtasten (8x8 Punkte)
##   2. Punkte unter Schwellwert -0.5 als Wasser-Kandidaten sammeln
##   3. Benachbarte Kandidaten zu Bounding-Box-Gruppen zusammenfassen
##   4. Zu kleine Gruppen verwerfen (< 4.0 Einheiten)
##   5. WaterBody.place() für jede Gruppe aufrufen

const LOG_CAT := "WaterBodyPlacer"

var _terrain_generator: TerrainGenerator


func _init(terrain_gen: TerrainGenerator) -> void:
	_terrain_generator = terrain_gen


func place_all(world_root: Node3D) -> void:
	if not is_instance_valid(_terrain_generator):
		return

	var sample_step: float = _terrain_generator.size / 8.0
	var water_centers: Array[Vector3] = []

	for zi in range(-4, 5):
		for xi in range(-4, 5):
			var lx: float = xi * sample_step
			var lz: float = zi * sample_step
			if _terrain_generator.get_height_at(lx, lz) < -0.5:
				water_centers.append(Vector3(lx, 0.0, lz))

	if water_centers.is_empty():
		return

	var used: Array[bool] = []
	for _i in range(water_centers.size()):
		used.append(false)
	var placed := 0

	for i in range(water_centers.size()):
		if used[i]:
			continue
		var center := water_centers[i]
		var min_x := center.x
		var max_x := center.x
		var min_z := center.z
		var max_z := center.z
		for j in range(water_centers.size()):
			if used[j]:
				continue
			if center.distance_to(water_centers[j]) < sample_step * 1.8:
				min_x = minf(min_x, water_centers[j].x)
				max_x = maxf(max_x, water_centers[j].x)
				min_z = minf(min_z, water_centers[j].z)
				max_z = maxf(max_z, water_centers[j].z)
				used[j] = true
		used[i] = true
		var w: float = max(max_x - min_x + sample_step, sample_step * 0.8)
		var l: float = max(max_z - min_z + sample_step, sample_step * 0.8)
		if w < 4.0 or l < 4.0:
			continue
		# Wasser auf Terrain-Höhe der Senke platzieren (nicht hardcoded 0.02).
		# Mindesttiefe 4.0m damit der Spieler nicht den See auffüllt.
		var cy: float = _terrain_generator.get_height_at(
			(min_x + max_x) * 0.5, (min_z + max_z) * 0.5
		) + 0.1
		WaterBody.place(
			world_root,
			Vector3((min_x + max_x) * 0.5, cy, (min_z + max_z) * 0.5),
			Vector3(w, 4.0, l)
		)
		placed += 1

	Logger.log_info("WaterBodies platziert: %d." % placed, LOG_CAT)
