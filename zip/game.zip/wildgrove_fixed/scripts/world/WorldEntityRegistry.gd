class_name WorldEntityRegistry
extends RefCounted

## WorldEntityRegistry — Registriert Entity-Definitionen im EntityOrchestrator.
##
## Ausgelagert aus WorldService._register_entity_definitions() (v28).
## Zentrale Stelle für alle bekannten Entity-Typen der Spielwelt.
##
## Statisch nutzbar — kein State, keine Abhängigkeiten außer dem Orchestrator.

const LOG_CAT := "WorldEntityRegistry"


## Registriert alle Welt-Entities im angegebenen Orchestrator.
static func register_all(orchestrator: EntityOrchestrator) -> void:
	orchestrator.register_definition("player",    "res://scripts/player/Player.gd",             "player")
	orchestrator.register_definition("oak_tree",  "res://scripts/world/objects/OakTree.gd",       "trees")
	orchestrator.register_definition("iron_ore",  "res://scripts/world/objects/IronOre.gd",        "ores")
	orchestrator.register_definition("deer",      "res://scripts/world/animals/Deer.gd",           "animals")
	orchestrator.register_definition("rabbit",    "res://scripts/world/animals/Rabbit.gd",         "animals")
	orchestrator.register_definition("boar",      "res://scripts/world/animals/Boar.gd",           "animals")
	orchestrator.register_definition("quest_npc", "res://scripts/world/npc/QuestNPC.gd",           "npcs")
	orchestrator.register_definition("goblin",    "res://scripts/world/combat/EnemyNPC.gd",        "enemies")
	Logger.log_info("Entity-Definitionen registriert.", LOG_CAT)
