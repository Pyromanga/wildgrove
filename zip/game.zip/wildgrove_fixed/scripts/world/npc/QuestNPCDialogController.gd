class_name QuestNPCDialogController
extends RefCounted

## QuestNPCDialogController — Dialog-State-Machine für den Quest-NPC.
##
## Ausgelagert aus QuestNPC (v28).
## Verwaltet die drei NPC-Zustände (HAS_QUEST, QUEST_ACTIVE, QUEST_DONE)
## und die dazugehörigen Dialog-Texte.
##
## Kein Node. Wird von QuestNPC instanziiert und aufgerufen.
## QuestNPC bleibt Koordinator — dieser Controller kennt nur die State-Logik.

enum NPCState { HAS_QUEST, QUEST_ACTIVE, QUEST_DONE }

var state: NPCState = NPCState.HAS_QUEST
var obj_progress: int = 0   ## Gecacht via quest_objective_updated Signal

var _quest_id: String
var _dialog_label: Label3D
var _scene_tree: SceneTree


func _init(quest_id: String, dialog_label: Label3D, scene_tree: SceneTree) -> void:
	_quest_id     = quest_id
	_dialog_label = dialog_label
	_scene_tree   = scene_tree


# ─────────────────────────────────────────────
# State-Übergänge
# ─────────────────────────────────────────────

func on_interact() -> void:
	match state:
		NPCState.HAS_QUEST:    _offer_quest()
		NPCState.QUEST_ACTIVE: _encourage()
		NPCState.QUEST_DONE:   _show_completed()


func on_quest_completed(q_id: String) -> void:
	if q_id == _quest_id:
		state = NPCState.QUEST_DONE


func on_objective_updated(_q_id: String, current: int) -> void:
	obj_progress = current


func on_quest_start_failed(reason: String) -> void:
	var msg := "Quest konnte nicht gestartet werden."
	if reason == "already_completed":
		msg = "Diese Aufgabe hast du\nbereits erledigt."
	elif reason == "already_active":
		msg = "Du arbeitest bereits\nan dieser Aufgabe!"
	elif reason.begins_with("prereq_missing"):
		msg = "Dafür bist du\nnoch nicht bereit."
	_show_dialog(msg)


# ─────────────────────────────────────────────
# Dialoge
# ─────────────────────────────────────────────

func _offer_quest() -> void:
	EventBus.quest.emit_quest_start_requested(_quest_id)
	state = NPCState.QUEST_ACTIVE
	_show_dialog("Gut, dass du da bist!\nFälle 3 Eichen für mich.\nDas Holz wird gebraucht.")


func _encourage() -> void:
	_show_dialog("Gut! Du hast schon\n%d/3 Bäume gefällt." % obj_progress)


func _show_completed() -> void:
	_show_dialog("Danke! Das Holz werde\nich gut gebrauchen können.")


func _show_dialog(text: String) -> void:
	_dialog_label.text    = text
	_dialog_label.visible = true
	_scene_tree.create_timer(5.0).timeout.connect(func():
		if is_instance_valid(_dialog_label):
			_dialog_label.visible = false
	)
	EventBus.world.emit_interaction_reward_text(text.replace("\n", " "))
