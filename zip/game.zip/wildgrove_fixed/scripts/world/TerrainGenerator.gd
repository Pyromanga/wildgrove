class_name TerrainGenerator
extends RefCounted

## TerrainGenerator — Heightmap-Sampling, Biome-Noise, River/Lake-Anwendung.
##
## Delegiert Mesh-Bau    → TerrainMeshBuilder
## Delegiert Vertex-Farbe → TerrainColorizer (via TerrainMeshBuilder)
##
## ── BIOME ────────────────────────────────────────────────────────────────
## _biome_noise hat FESTEN globalen Seed → kontinuierliche Biome über Chunks.
## world_offset (Chunk-Zentrum) wird vor create() gesetzt.
##
## ── WASSER ───────────────────────────────────────────────────────────────
## Kein globales Wasser-Mesh mehr. WaterBody wird von WorldSpawner gesetzt.

const LOG_CAT := "TerrainGen"

var size:         float   = 64.0
var resolution:   int     = 64
var max_height:   float   = 12.0
var sea_level:    float   = 0.0
var noise_seed:   int     = 0
var world_offset: Vector2 = Vector2.ZERO

const BIOME_SEED: int   = 424242
const BIOME_FREQ: float = 0.0035

var _noise:       FastNoiseLite
var _biome_noise: FastNoiseLite
var _rng:         RandomNumberGenerator
var _mesh_builder: TerrainMeshBuilder


func _init() -> void:
	_rng        = RandomNumberGenerator.new()
	_rng.seed   = noise_seed if noise_seed != 0 else int(Time.get_unix_time_from_system())

	_noise = FastNoiseLite.new()
	_noise.seed               = _rng.randi()
	_noise.noise_type         = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_noise.fractal_type       = FastNoiseLite.FRACTAL_FBM
	_noise.fractal_octaves    = 6
	_noise.fractal_lacunarity = 2.1
	_noise.fractal_gain       = 0.55
	_noise.frequency          = 0.012

	_biome_noise = FastNoiseLite.new()
	_biome_noise.seed        = BIOME_SEED
	_biome_noise.noise_type  = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_biome_noise.fractal_type = FastNoiseLite.FRACTAL_FBM
	_biome_noise.fractal_octaves = 2
	_biome_noise.frequency   = BIOME_FREQ

	_mesh_builder = TerrainMeshBuilder.new()


## Erzeugt Terrain-Mesh + Physics als Kinder von `world`.
func create(world: Node3D) -> void:
	var t      := Logger.log_begin("TerrainGenerator.create()", LOG_CAT)
	var heights := _generate_heightmap()

	var terrain := _mesh_builder.build_terrain_mesh(
		heights, resolution, size, max_height, sea_level, world_offset, _get_biome_factor
	)
	terrain.name = "Terrain"
	world.add_child(terrain)

	var physics := _mesh_builder.build_physics_body(heights, resolution, size)
	physics.name = "TerrainPhysics"
	world.add_child(physics)

	Logger.log_end("TerrainGenerator.create()", t, LOG_CAT)
	Logger.log_info(
		"Terrain: %dx%d, %.0fm×%.0fm @ %s" % [resolution, resolution, size, size, str(world_offset)],
		LOG_CAT
	)


## Höhe an LOKALER Position (x, z), relativ zu world_offset.
func get_height_at(x: float, z: float) -> float:
	var nx:      float = x / size
	var nz:      float = z / size
	var world_x: float = world_offset.x + x
	var world_z: float = world_offset.y + z
	return _sample_height(nx, nz, world_x, world_z)


# ─────────────────────────────────────────────
# Heightmap
# ─────────────────────────────────────────────


func _generate_heightmap() -> PackedFloat32Array:
	var n   := resolution + 1
	var map := PackedFloat32Array()
	map.resize(n * n)

	var river_x_offset:  float = _rng.randf_range(-0.1, 0.1)
	var river_amplitude: float = _rng.randf_range(0.06, 0.12)

	for z_i in range(n):
		for x_i in range(n):
			var nx:      float = float(x_i) / float(resolution) - 0.5
			var nz:      float = float(z_i) / float(resolution) - 0.5
			var local_x: float = nx * size
			var local_z: float = nz * size
			var world_x: float = world_offset.x + local_x
			var world_z: float = world_offset.y + local_z

			var h: float = _sample_height(nx, nz, world_x, world_z)

			# Fluss
			var river_x:    float = sin(nz * PI * 2.0) * river_amplitude + river_x_offset
			var river_dist: float = abs(nx - river_x)
			var river_width: float = 0.035
			if river_dist < river_width:
				var t_r: float = 1.0 - river_dist / river_width
				h = lerp(h, -1.5, pow(t_r, 2.5))

			# Seen
			h = _apply_lake(h, nx, nz,  0.18, -0.22, 0.10)
			h = _apply_lake(h, nx, nz, -0.20,  0.15, 0.08)

			map[z_i * n + x_i] = h

	return map


func _get_biome_factor(world_x: float, world_z: float) -> float:
	return (_biome_noise.get_noise_2d(world_x, world_z) + 1.0) * 0.5


func _sample_height(nx: float, nz: float, world_x: float, world_z: float) -> float:
	var detail: float      = (_noise.get_noise_2d(nx, nz) + 1.0) * 0.5
	var biome: float       = _get_biome_factor(world_x, world_z)
	var height_mult: float = lerp(0.15, 1.0, biome)
	return (detail - 0.35) * max_height * height_mult


func _apply_lake(h: float, nx: float, nz: float, cx: float, cz: float, radius: float) -> float:
	var dist: float = Vector2(nx - cx, nz - cz).length()
	if dist < radius:
		var t: float = 1.0 - dist / radius
		return lerp(h, -2.0, pow(t, 3.0))
	return h
