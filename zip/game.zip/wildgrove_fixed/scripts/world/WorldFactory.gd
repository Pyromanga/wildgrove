extends RefCounted
class_name WorldFactory

## WorldFactory — Erzeugt die STATISCHE Spielwelt (Geometrie + Licht + Player).
##
## WICHTIG — Was gehört NICHT hierher:
##   Entities (OakTree, IronOre, NPCs) → EntityOrchestrator (via WorldService)
##   Services, UI → jeweilige Manager
##
## Anti-Pattern VERHINDERT:
##   VERBOTEN: Node3D.new() + node.set_script(script)
##   GRUND: set_script() nach Node-Erstellung triggert _ready() ein zweites Mal
##          (Godot's Engine ruft _ready() beim Tree-Eintritt auf, und nochmal wenn
##          das Script gesetzt wird). Bei CharacterBody3D: undefiniertes Physik-Verhalten.
##   KORREKT: script.new() → direkte Instanz MIT Script von Anfang an.
##            Damit gibt es exakt einen _ready()-Aufruf nach add_child().

const LOG_CAT := "WorldFactory"


## Erzeugt die statische Welt-Geometrie ohne Entities.
## Gibt einen temporären Container-Node zurück — WorldService verschiebt dessen Kinder
## in world_root (die echte World.tscn).
##
## Enthält: Beleuchtung, Himmel, Boden.
## NICHT enthalten: Player, OakTree, IronOre, NPCs → alle via EntityOrchestrator gespawnt.
## Terrain-Generator-Instanz — wird in create_world() erstellt und
## als öffentliche Variable exponiert damit WorldGenerationService die
## Höhe an beliebigen Positionen abfragen kann.
var terrain_generator: TerrainGenerator = null


func create_world() -> Node3D:
	var t := Logger.log_begin("create_world()", LOG_CAT)
	var world := Node3D.new()
	world.name = "WorldContainer"

	_add_environment(world)
	_add_terrain(world)   # Ersetzt _add_ground — echtes prozedurales Terrain
	# Player wird via EntityOrchestrator.spawn_entity("player", ...) gespawnt.
	# WorldSpawner.spawn_all() übernimmt das nach on_world_scene_ready().

	Logger.log_end("create_world()", t, LOG_CAT)
	Logger.log_info(
		"Statische Welt erstellt. Nodes: %d." % world.get_child_count(), LOG_CAT
	)
	return world


# ─────────────────────────────────────────────
# Umgebung
# ─────────────────────────────────────────────


func _add_environment(world: Node3D) -> void:
	# Sonne
	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-45, 30, 0)
	sun.light_energy = 1.2
	sun.shadow_enabled = true
	world.add_child(sun)

	# Prozeduraler Himmel
	var env_node := WorldEnvironment.new()
	env_node.name = "WorldEnvironment"
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.2, 0.5, 0.9)
	sky_mat.sky_horizon_color = Color(0.6, 0.8, 1.0)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.5
	env_node.environment = env
	world.add_child(env_node)

	Logger.log_debug("Umgebung (Sonne + Himmel) erstellt.", LOG_CAT)


# ─────────────────────────────────────────────
# Boden
# ─────────────────────────────────────────────


## Seed wird von WorldService gesetzt bevor _add_terrain() aufgerufen wird.
## Default 0 → TerrainGenerator nutzt seinen eigenen Default-Seed (nicht Zeit-basiert).
var world_seed: int = 0


func _add_terrain(world: Node3D) -> void:
	terrain_generator = TerrainGenerator.new()
	# size MUSS exakt ChunkManager.CHUNK_SIZE (64m) entsprechen —
	# ChunkManager überspringt Chunk (0,0) um Overlap zu vermeiden.
	terrain_generator.size        = 64.0
	# NAHT-FIX: Gleiche Auflösung wie ChunkManager (32) damit Chunk-Grenzen
	# dieselbe Vertex-Dichte haben und kein Höhenunterschied entsteht.
	terrain_generator.resolution  = 32
	# NAHT-FIX: Gleicher seed wie world_seed → alle Chunks samplen denselben
	# globalen Noise → nahtlose Übergänge an Chunk-Grenzen.
	terrain_generator.noise_seed  = world_seed
	terrain_generator.world_offset = Vector2.ZERO
	terrain_generator.create(world)
	Logger.log_debug("Prozedurales Terrain erstellt (Start-Chunk 0,0, seed=%d)." % world_seed, LOG_CAT)


