extends Node3D
class_name WeaponVisual3D

## WeaponVisual3D — rendert eine Waffe als Mesh am hand_r-Bone des Players.
##
## VERWENDUNG:
##   var wv := WeaponVisual3D.new()
##   wv.attach_to(player.visuals, weapon_def)   # hängt sich selbst ein
##   wv.detach()                                 # entfernt sich wieder
##
## DESIGN:
##   - Hängt als Child in die BoneAttachment3D "hand_r" von PlayerVisuals.
##   - weapon_offset / weapon_rotation sind @export — im Editor justierbar,
##     oder per WeaponDefinition.visual_offset überschreibbar (Schritt 3).
##   - Kein eigenes Mesh-Asset bisher: erzeugt ein prozedurales BoxMesh als
##     Platzhalter. Echte Meshes kommen wenn Assets vorhanden sind.
##   - Singleton-Konvention: ein Player trägt immer nur eine Waffe gleichzeitig.
##     attach_to() ruft zuerst detach() auf dem alten Attachment auf.

const LOG_CAT := "WeaponVisual3D"

## Offset relativ zum Bone-Attachment (justierbar per WeaponDefinition).
@export var weapon_offset:   Vector3 = Vector3(0.0, -0.15, 0.2)

## Rotation relativ zum Bone-Attachment.
@export var weapon_rotation: Vector3 = Vector3(0.0, 0.0, 0.0)

var _mesh_instance: MeshInstance3D = null
var _current_attachment: BoneAttachment3D = null


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

## Hängt diesen WeaponVisual3D in den hand_r-Bone von PlayerVisuals ein
## und baut das Mesh aus der WeaponDefinition auf.
##
## [param visuals]     PlayerVisuals-Instanz des Players.
## [param weapon_def]  WeaponDefinition-Resource (darf null sein → Platzhalter-Mesh).
func attach_to(visuals: PlayerVisuals, weapon_def: WeaponDefinition = null) -> void:
	detach()

	var att := visuals.get_bone_attachment("hand_r")
	if not is_instance_valid(att):
		Logger.log_error("WeaponVisual3D: hand_r-Attachment nicht gefunden.", LOG_CAT)
		return

	_current_attachment = att
	att.add_child(self)

	# Offset + Rotation aus WeaponDefinition übernehmen wenn vorhanden.
	if is_instance_valid(weapon_def):
		weapon_offset   = weapon_def.visual_offset
		weapon_rotation = weapon_def.visual_rotation

	position = weapon_offset
	rotation_degrees = weapon_rotation

	_build_mesh(weapon_def)
	Logger.log_info("WeaponVisual3D eingehängt (Bone: hand_r, Waffe: %s)." % \
		(weapon_def.display_name if is_instance_valid(weapon_def) else "Platzhalter"), LOG_CAT)


## Entfernt diesen Node vom Bone-Attachment.
func detach() -> void:
	if is_instance_valid(_current_attachment) and get_parent() == _current_attachment:
		_current_attachment.remove_child(self)
		Logger.log_debug("WeaponVisual3D ausgehängt.", LOG_CAT)
	_current_attachment = null


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────

func _build_mesh(weapon_def: WeaponDefinition) -> void:
	if is_instance_valid(_mesh_instance):
		_mesh_instance.queue_free()

	_mesh_instance      = MeshInstance3D.new()
	_mesh_instance.name = "WeaponMesh"

	## Platzhalter-Mesh: schmales BoxMesh das einen Dolch andeutet.
	## Wird ersetzt wenn echte Mesh-Assets vorliegen (dann weapon_def.mesh_path laden).
	var box        := BoxMesh.new()
	box.size        = _get_mesh_size(weapon_def)
	_mesh_instance.mesh = box

	add_child(_mesh_instance)


## Gibt eine Mesh-Größe zurück die zum Waffentyp passt.
## WeaponDefinition.weapon_type steuert die Proportionen.
func _get_mesh_size(weapon_def: WeaponDefinition) -> Vector3:
	if not is_instance_valid(weapon_def):
		return Vector3(0.05, 0.3, 0.05)   # Generischer Platzhalter

	match weapon_def.weapon_type:
		WeaponDefinition.WeaponType.DAGGER:
			return Vector3(0.04, 0.25, 0.04)
		WeaponDefinition.WeaponType.SWORD:
			return Vector3(0.06, 0.55, 0.06)
		WeaponDefinition.WeaponType.AXE:
			return Vector3(0.14, 0.40, 0.06)
		WeaponDefinition.WeaponType.STAFF:
			return Vector3(0.05, 0.90, 0.05)
		_:
			return Vector3(0.05, 0.30, 0.05)
