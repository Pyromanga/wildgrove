extends CharacterBody3D
class_name EnemyNPC

## EnemyNPC — Koordiniert KI, Gesundheit, Visuals und Interaktion.
##
## Delegiert:
##   KI-State-Machine    → EnemyAI
##   Visuals + Health-Bar → EnemyVisuals
##   Interaktions-Setup + Schaden-Berechnung → EnemyAttack
##
## on_interacted(action_id) wird von InteractableComponent nach Abschluss aufgerufen.

const LOG_CAT := "EnemyNPC"
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)

## Konfigurierbar via on_spawn(config)
var _color:        Color  = Color(0.7, 0.15, 0.15)
var _max_health:   int    = 30
var _damage:       int    = 5
var _speed:        float  = 2.5
var _detect_range: float  = 8.0
var _attack_range: float  = 1.5
var _attack_cd:    float  = 1.5
var _xp_reward:    int    = 20
var _xp_skill:     String = "combat"
var _drops:        Dictionary = {}
var _loot_table_id: String = "goblin_loot"   ## ID der LootTable für Goblin-Drops
var _label:        String = "Goblin"

## CombatProfile-ID dieser Entity-Klasse (TD-10). Default "goblin" passt zum
## aktuell einzigen Gegnertyp im Spiel (EnemySpawner.spawn_entity("goblin", …)).
## Konfigurierbar via on_spawn(cfg) für künftige Gegnertypen.
var _combat_profile_id: String = "goblin"

## CombatProfile-ID des Angriffsziels bei _do_melee() (TD-11). Aktuell immer
## der Spieler — kein PvP/Multi-Target geplant, daher Konstante statt Config-Feld.
const PLAYER_COMBAT_PROFILE_ID := "player"

var _ai:     EnemyAI
var _health: HealthComponent
var _visuals: EnemyVisuals

var _ctx:        IEntityContext = null   ## Injected via on_spawn() — kein Services.xyz
var _player_ref: Node3D = null


func _ready() -> void:
	add_to_group("enemies")
	var players := get_tree().get_nodes_in_group("player")
	if not players.is_empty():
		_player_ref = players[0] as Node3D
	if name == get_class() or name.begins_with("@"):
		name = "%s_%d" % [_label, get_instance_id() % 9999]

	_ai      = EnemyAI.new(_detect_range, _attack_range, _attack_cd, _speed)
	_visuals = EnemyVisuals.new()
	_visuals.build(self, _color, _max_health, _label)
	_build_collision()
	_setup_health()
	EnemyAttack.setup_interactable(self)
	Logger.log_debug("EnemyNPC '%s' bereit." % name, LOG_CAT)


func _physics_process(delta: float) -> void:
	if _ai.state == EnemyAI.State.DEAD:
		return
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0

	var player := _get_player()
	if not is_instance_valid(player):
		_ai.state = EnemyAI.State.IDLE
		move_and_slide()
		return

	var result := _ai.update(self, player, delta, velocity)
	velocity = result["velocity"]
	if result["do_melee"]:
		_do_melee(player)

	_visuals.update_health_bar(_health.current_health, _health.max_health)
	move_and_slide()


# ─────────────────────────────────────────────
# Interaktions-Callback
# ─────────────────────────────────────────────


func _on_interacted(action_id: String) -> void:
	if action_id != "attack_enemy" or _ai.state == EnemyAI.State.DEAD:
		return

	# Schaden-Berechnung über CombatSystem (ADR-008).
	# IEntityContext liefert CombatSystem/DataService — kein Services.xyz in Entity-Code.
	var combat: CombatSystem = _ctx.get_combat_system() if is_instance_valid(_ctx) else null
	var skill: SkillSystem   = _ctx.get_skill_system()  if is_instance_valid(_ctx) else null
	var data: DataService    = _ctx.get_data()          if is_instance_valid(_ctx) else null

	var record: DamageRecord
	if is_instance_valid(combat) and is_instance_valid(skill):
		record = combat.player_melee_damage(skill, "player")
		# TD-10: Resistenz des Ziels (dieser Gegner) statt hartcodierter 0.0/0.0.
		var profile: CombatProfile = (
			data.get_combat_profile(_combat_profile_id)
			if is_instance_valid(data)
			else CombatProfile.default_profile()
		)
		# calculate_damage_with_profile gibt die modifizierte Instanz zurück —
		# Rückgabewert muss zugewiesen werden, sonst bleibt final_amount=0.
		record = combat.calculate_damage_with_profile(record, profile)
	else:
		# Fallback wenn kein CombatSystem verfügbar (Testumgebung ohne EntityContext)
		record = DamageRecord.make_player_attack("player", name, 10.0)
		record.final_amount = 10.0
		Logger.log_warn("CombatSystem nicht verfügbar — Fallback-Schaden 10.", LOG_CAT)

	record.target_id = name
	if is_instance_valid(_health):
		if is_instance_valid(combat):
			combat.apply_damage(record, _health)
			# On-Hit Effekte (Gift etc.) nach dem Treffer anwenden
			combat.apply_weapon_on_hit(_health, "player", name)
		else:
			_health.take_damage(int(record.final_amount))
		Logger.log_debug(
			"Spieler trifft '%s': %s → %d/%d HP"
			% [name, record.to_debug_string(), _health.current_health, _health.max_health],
			LOG_CAT
		)


# ─────────────────────────────────────────────
# Kampf
# ─────────────────────────────────────────────


func _do_melee(player: Node3D) -> void:
	var hc := player.get_node_or_null("HealthComponent") as HealthComponent
	if not is_instance_valid(hc):
		return

	# TD-11: vorher hc.take_damage(_damage) direkt — kein Krit-Check, keine
	# Resistenz, kein EventBus.world.damage_dealt. Jetzt über CombatSystem,
	# spiegelbildlich zu _on_interacted() (Spieler → Gegner).
	var combat: CombatSystem = _ctx.get_combat_system() if is_instance_valid(_ctx) else null
	var data: DataService    = _ctx.get_data()          if is_instance_valid(_ctx) else null

	var record: DamageRecord
	if is_instance_valid(combat):
		record = combat.enemy_melee_damage(name, "player", float(_damage))
		var profile: CombatProfile = (
			data.get_combat_profile(PLAYER_COMBAT_PROFILE_ID)
			if is_instance_valid(data)
			else CombatProfile.default_profile()
		)
		combat.calculate_damage_with_profile(record, profile)
		combat.apply_damage(record, hc)
	else:
		# Fallback wenn kein CombatSystem verfügbar (Testumgebung ohne EntityContext)
		record = DamageRecord.make_enemy_attack(name, "player", float(_damage))
		record.final_amount = float(_damage)
		hc.take_damage(_damage)
		Logger.log_warn("CombatSystem nicht verfügbar — Fallback-Schaden %d." % _damage, LOG_CAT)

	Logger.log_debug(
		"%s trifft Spieler: %s → %d/%d HP"
		% [_label, record.to_debug_string(), hc.current_health, hc.max_health],
		LOG_CAT
	)


func _die() -> void:
	_ai.set_dead()
	remove_from_group("interactable")
	EventBus.player.emit_xp(_xp_skill, _xp_reward)

	# LootTable-basierte Drops (hat Vorrang vor statischen _drops)
	var data: DataService = _ctx.get_data() if is_instance_valid(_ctx) else null
	if not _loot_table_id.is_empty() and is_instance_valid(data):
		var loot_table: LootTable = data.get_loot_table(_loot_table_id)
		if is_instance_valid(loot_table):
			var rolled := loot_table.roll()
			for item_id in rolled:
				var qty: int = rolled[item_id]
				EventBus.world.emit_loot_collected(item_id, qty)
				# Floating-Text für jeden Drop
				var item_def: ItemDefinition = data.get_item(item_id)
				var item_name := item_def.display_name if is_instance_valid(item_def) else item_id
				EventBus.ui.emit_floating_text(
					"+ %s ×%d" % [item_name, qty], global_position
				)
	else:
		# Fallback: statische _drops (Legacy-Pfad)
		for item_id in _drops:
			EventBus.world.emit_loot_collected(item_id, _drops[item_id])

	var ic := get_node_or_null("AttackInteractable")
	if is_instance_valid(ic):
		ic.queue_free()
	get_tree().create_timer(1.5).timeout.connect(
		func() -> void:
			if is_instance_valid(self):
				queue_free()
	)
	Logger.log_info("%s besiegt. +%d %s XP." % [_label, _xp_reward, _xp_skill], LOG_CAT)


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _setup_health() -> void:
	_health            = HealthComponent.new()
	_health.name       = "HealthComponent"
	_health.max_health = _max_health
	add_child(_health)
	_health.died.connect(_die)


func _build_collision() -> void:
	var col := CollisionShape3D.new()
	var sh  := CapsuleShape3D.new()
	sh.radius = 0.32
	sh.height = 1.0
	col.shape  = sh
	col.position.y = 0.7
	add_child(col)


func _get_player() -> Node3D:
	# Retry once if the player spawned after this enemy (late join).
	if not is_instance_valid(_player_ref):
		var players := get_tree().get_nodes_in_group("player")
		if players.is_empty():
			return null
		_player_ref = players[0] as Node3D
	return _player_ref


# ─────────────────────────────────────────────
# EntityOrchestrator-Interface
# ─────────────────────────────────────────────


func on_spawn(cfg: Dictionary = {}, ctx: IEntityContext = null) -> void:
	_ctx = ctx
	if cfg.has("label"):       _label       = cfg["label"]
	if cfg.has("color"):       _color       = cfg["color"]
	if cfg.has("max_health"):  _max_health  = cfg["max_health"]
	if cfg.has("damage"):      _damage      = cfg["damage"]
	if cfg.has("xp_reward"):   _xp_reward   = cfg["xp_reward"]
	if cfg.has("drops"):       _drops       = cfg["drops"]
	if cfg.has("loot_table"): _loot_table_id = cfg["loot_table"]
	if cfg.has("combat_profile"): _combat_profile_id = cfg["combat_profile"]
	if is_instance_valid(_health):
		_health.max_health = _max_health
		_health.reset()
		# on_despawn() disconnectet das died-Signal — bei Pool-Reuse muss es
		# hier wieder verbunden werden, sonst stirbt der Goblin nie.
		if not _health.died.is_connected(_die):
			_health.died.connect(_die)
	_ai.state = EnemyAI.State.IDLE
	add_to_group("interactable")


func on_despawn() -> void:
	_ai.set_dead()
	if is_instance_valid(_health) and _health.died.is_connected(_die):
		_health.died.disconnect(_die)
