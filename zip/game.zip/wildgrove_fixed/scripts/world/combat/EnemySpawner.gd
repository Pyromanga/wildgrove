class_name EnemySpawner
extends RefCounted

## EnemySpawner — Spawnt Tiere und feindliche NPCs in der Spielwelt.
##
## Ausgelagert aus WorldSpawner._spawn_animals() + _spawn_enemies() (v28).
## Tiere: Deer, Rabbit, Boar — werden zufällig verteilt platziert.
## Feinde: Goblins — werden in Randzone der Welt gespawnt.
##
## Kein Node, kein Service. Wird von WorldSpawner instanziiert.

const LOG_CAT := "EnemySpawner"

var _entity_orchestrator: EntityOrchestrator
var _terrain_generator: TerrainGenerator


func _init(orchestrator: EntityOrchestrator, terrain_gen: TerrainGenerator) -> void:
	_entity_orchestrator = orchestrator
	_terrain_generator   = terrain_gen


# ─────────────────────────────────────────────
# Tiere
# ─────────────────────────────────────────────

func spawn_animals() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system()) ^ 0xABCDEF

	var configs := [
		{"type": "deer",   "count": 4, "min_dist": 6.0},
		{"type": "rabbit", "count": 6, "min_dist": 3.0},
		{"type": "boar",   "count": 3, "min_dist": 7.0},
	]

	var all_positions: Array[Vector3] = []
	for cfg in configs:
		var placed := 0
		var attempts := 0
		while placed < cfg["count"] and attempts < 60:
			attempts += 1
			var x := rng.randf_range(-25.0, 25.0)
			var z := rng.randf_range(-25.0, 25.0)
			var candidate := Vector3(x, 0.0, z)
			if candidate.length() < 8.0:
				continue
			var too_close := false
			for other in all_positions:
				if candidate.distance_to(other) < cfg["min_dist"]:
					too_close = true
					break
			if too_close:
				continue
			if is_instance_valid(_terrain_generator):
				var h := _terrain_generator.get_height_at(x, z)
				if h < 0.3:
					continue
				candidate.y = h
			all_positions.append(candidate)
			_entity_orchestrator.spawn_entity(cfg["type"], candidate)
			placed += 1

	Logger.log_info("Tiere gespawnt: %d." % all_positions.size(), LOG_CAT)


# ─────────────────────────────────────────────
# Feinde
# ─────────────────────────────────────────────

func spawn_enemies() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = int(Time.get_unix_time_from_system()) ^ 0x1337
	for _i in range(5):
		var x := rng.randf_range(-20.0, 20.0)
		var z := rng.randf_range(-20.0, 20.0)
		if Vector2(x, z).length() < 10.0:
			continue
		var h := 1.5
		if is_instance_valid(_terrain_generator):
			h = _terrain_generator.get_height_at(x, z)
		if h > 0.3:
			_entity_orchestrator.spawn_entity("goblin", Vector3(x, h, z))
	Logger.log_info("Feindliche NPCs gespawnt.", LOG_CAT)
