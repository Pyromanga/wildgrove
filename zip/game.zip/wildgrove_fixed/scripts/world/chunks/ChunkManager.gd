extends Node
class_name ChunkManager

## ChunkManager — Lädt/entlädt Terrain-Chunks basierend auf Spielerposition.
##
## ── KOORDINATEN-SYSTEM ────────────────────────────────────────────────────
## _chunk_to_world(coord) gibt das ZENTRUM des Chunks zurück.
## Chunk (0,0) wird übersprungen (identisch zum Haupt-Terrain aus WorldFactory).
##
## Delegiert:
##   Entity-Spawning → ChunkEntitySpawner
##   Wasser-Platzierung → ChunkWaterPlacer

const LOG_CAT       := "ChunkManager"
const CHUNK_SIZE    := 64.0
const LOAD_RADIUS   := 2
const UNLOAD_RADIUS := 3

var _chunks:        Dictionary = {}           # { Vector2i: Node3D | null }
var _player_chunk:  Vector2i   = Vector2i(999, 999)
var _world_root:    Node3D
var _seed:          int = 0
var _entity_spawner: ChunkEntitySpawner
var _water_placer:   ChunkWaterPlacer


func initialize(world_root: Node3D, world_seed: int, spawn_entity_cb: Callable) -> void:
	_world_root      = world_root
	_seed            = world_seed
	_entity_spawner  = ChunkEntitySpawner.new(CHUNK_SIZE, world_seed, spawn_entity_cb)
	_water_placer    = ChunkWaterPlacer.new()
	Logger.log_info(
		"ChunkManager initialisiert. Chunk-Größe: %.0fm, Radius: %d" % [CHUNK_SIZE, LOAD_RADIUS],
		LOG_CAT
	)


func _process(_delta: float) -> void:
	if not is_instance_valid(_world_root):
		return
	var player := _get_player()
	if not is_instance_valid(player):
		return
	var new_chunk := _world_to_chunk(player.global_position)
	if new_chunk == _player_chunk:
		return
	_player_chunk = new_chunk
	_update_chunks()


# ─────────────────────────────────────────────
# Chunk-Verwaltung
# ─────────────────────────────────────────────


func _update_chunks() -> void:
	for dz in range(-LOAD_RADIUS, LOAD_RADIUS + 1):
		for dx in range(-LOAD_RADIUS, LOAD_RADIUS + 1):
			var coord := Vector2i(_player_chunk.x + dx, _player_chunk.y + dz)
			if not _chunks.has(coord):
				_load_chunk(coord)

	var to_unload: Array[Vector2i] = []
	for coord in _chunks:
		var dist: int = max(abs(coord.x - _player_chunk.x), abs(coord.y - _player_chunk.y))
		if dist > UNLOAD_RADIUS:
			to_unload.append(coord)
	for coord in to_unload:
		_unload_chunk(coord)


func _load_chunk(coord: Vector2i) -> void:
	if coord == Vector2i(0, 0):
		_chunks[coord] = null  # Haupt-Terrain überspringen
		return

	var center := _chunk_to_world(coord)
	Logger.log_debug("Lade Chunk %s @ Zentrum %s" % [str(coord), str(center)], LOG_CAT)

	var gen := TerrainGenerator.new()
	gen.size        = CHUNK_SIZE
	gen.resolution  = 32
	gen.max_height  = 12.0
	gen.sea_level   = 0.6
	gen.noise_seed  = _seed ^ (coord.x * 73856093) ^ (coord.y * 19349663)
	gen.world_offset = center

	var chunk_node := Node3D.new()
	chunk_node.name     = "Chunk_%d_%d" % [coord.x, coord.y]
	chunk_node.position = Vector3(center.x, 0.0, center.y)
	_world_root.add_child(chunk_node)

	gen.create(chunk_node)
	_chunks[coord] = chunk_node

	_entity_spawner.spawn_for_chunk(coord, center, gen)
	_water_placer.place_water(chunk_node, center, gen)


func _unload_chunk(coord: Vector2i) -> void:
	if not _chunks.has(coord):
		return
	var chunk_node = _chunks[coord]
	_chunks.erase(coord)
	if is_instance_valid(chunk_node):
		chunk_node.queue_free()
	Logger.log_debug("Chunk %s entladen." % str(coord), LOG_CAT)


# ─────────────────────────────────────────────
# Koordinaten-Helpers
# ─────────────────────────────────────────────


func _world_to_chunk(pos: Vector3) -> Vector2i:
	return Vector2i(int(round(pos.x / CHUNK_SIZE)), int(round(pos.z / CHUNK_SIZE)))


func _chunk_to_world(coord: Vector2i) -> Vector2:
	return Vector2(coord.x * CHUNK_SIZE, coord.y * CHUNK_SIZE)


func _get_player() -> Node3D:
	var players := get_tree().get_nodes_in_group("player")
	return players[0] as Node3D if not players.is_empty() else null
