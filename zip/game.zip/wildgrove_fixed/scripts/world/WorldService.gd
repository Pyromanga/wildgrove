extends ServiceNode
class_name WorldService

## WorldService — Lifecycle + öffentliche API für die Spielwelt.
##
## Delegiert Verantwortlichkeiten an spezialisierte Klassen:
##   WorldSpawner          → Entities, Tiere, Wasser, Pets, Chunks spawnen
##   WorldSaveHandler      → Save/Restore-Logik (v28)
##   WorldEntityRegistry   → Entity-Definitionen registrieren (v28)
##   WorldTimeService      → Tageszeit verwalten
##   WorldFactory          → statische Geometrie erstellen
##   EntityOrchestrator    → Entity-Pooling + UUID-Verwaltung
##
## Abhängigkeiten: ["savesystem", "world_gen"]

const LOG_CAT := "World"
const SAVE_KEY := "world_state"

var data:     WorldData
var factory:  WorldFactory
var factory3d: Factory3D

var _save_system: SaveSystem
var _world_gen:   WorldGenerationService
var _entity_orchestrator: EntityOrchestrator
var _spawner:  WorldSpawner
var _time:     WorldTimeService
var _save_handler: WorldSaveHandler
var _chunk_manager: ChunkManager  # Stored so on_cleanup() can shut it down properly

## Computed properties — always current, never one tick stale.
var day_time: float:
	get: return _time.day_time if is_instance_valid(_time) else 0.0
var day_count: int:
	get: return _time.day_count if is_instance_valid(_time) else 0


# ─────────────────────────────────────────────
# Service-Lifecycle
# ─────────────────────────────────────────────

func configure(deps: Dictionary) -> void:
	_save_system = deps.get("savesystem") as SaveSystem
	_world_gen   = deps.get("world_gen")  as WorldGenerationService

	data      = WorldData.new()
	factory   = WorldFactory.new()
	factory3d = Factory3D.new()
	_time     = WorldTimeService.new()

	_entity_orchestrator      = EntityOrchestrator.new()
	_entity_orchestrator.name = "EntityOrchestrator"
	add_child(_entity_orchestrator)
	WorldEntityRegistry.register_all(_entity_orchestrator)

	_save_handler = WorldSaveHandler.new(data, _time)

	if is_instance_valid(_save_system):
		_save_system.register_save_provider(self)
		var saved := _save_system.get_state_for(SAVE_KEY)
		if not saved.is_empty():
			_save_handler.restore_world(saved)
			# day_time and day_count are now computed properties — no copy needed

	if not is_instance_valid(_world_gen):
		Logger.log_warn("WorldGenerationService fehlt.", LOG_CAT)

	Logger.log_info("WorldService konfiguriert.", LOG_CAT)


func on_ready() -> void:
	if Services.ticker:
		Services.ticker.register_service(self)

	EventBus.world.entity_despawn_requested.connect(_on_entity_despawn_requested)
	# Pre-Flush-Hook: GameSaveService emittiert save_pre_flush bevor SaveSystem schreibt.
	# WorldService sichert hier Pets die zur Laufzeit im SceneTree leben und nicht
	# automatisch über ISaveProvider.get_save_data() erreichbar sind.
	EventBus.system.save_pre_flush.connect(_on_save_pre_flush)

	var respawn := Services.respawn
	if is_instance_valid(respawn):
		respawn.register_config("oak_tree", 300.0)
		respawn.register_config("iron_ore", 600.0)
		respawn.set_spawn_callback(func(t: String, p: Vector3) -> Node3D: return spawn_entity(t, p))
		respawn.set_remove_callback(func(t: String, p: Vector3) -> void: data.unmark_harvested(t, p))

	Logger.log_info("WorldService bereit.", LOG_CAT)


func on_cleanup() -> void:
	if EventBus.system.save_pre_flush.is_connected(_on_save_pre_flush):
		EventBus.system.save_pre_flush.disconnect(_on_save_pre_flush)
	if is_instance_valid(_chunk_manager):
		_chunk_manager.queue_free()
		_chunk_manager = null
	if is_instance_valid(_entity_orchestrator) and _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()


func on_tick(delta: float) -> void:
	if is_instance_valid(Services.game_manager) and Services.game_manager.is_playing():
		_time.tick(delta)
		# day_time / day_count are computed properties — no copy needed


# ─────────────────────────────────────────────
# Welt-Initialisierung
# ─────────────────────────────────────────────

func on_world_scene_ready(world_root: Node3D) -> void:
	var t := Logger.log_begin("on_world_scene_ready()", LOG_CAT)

	if _entity_orchestrator.get_entity_count() > 0:
		_entity_orchestrator.on_world_unloaded()
		EventBus.world.emit_world_scene_unloaded()

	# Statische Geometrie
	var generated := factory.create_world()
	for child in generated.get_children():
		generated.remove_child(child)
		world_root.add_child(child)
	generated.queue_free()

	# Terrain-Höhen-Callback
	if is_instance_valid(_world_gen) and is_instance_valid(factory.terrain_generator):
		_world_gen.set_height_callback(factory.terrain_generator.get_height_at)

	_entity_orchestrator.initialize(world_root)

	# ChunkManager: stored on the service so on_cleanup() can shut it down properly.
	# Deterministic seed: read from WorldData so every session, server and client
	# generate the same world. Set once at world creation, never from the clock.
	if is_instance_valid(_chunk_manager):
		_chunk_manager.queue_free()
	_chunk_manager = ChunkManager.new()
	_chunk_manager.name = "ChunkManager"
	world_root.add_child(_chunk_manager)
	var seed_val: int = data.world_seed if data.world_seed != 0 \
		else int(Time.get_unix_time_from_system()) & 0x7FFFFFFF
	if data.world_seed == 0:
		data.world_seed = seed_val
		Logger.log_warn(
			"world_seed war 0 — neuer Seed generiert: %d. Für deterministische Welten in WorldData setzen." % seed_val,
			LOG_CAT
		)
	_chunk_manager.initialize(world_root, seed_val, func(type_id: String, pos: Vector3) -> Node3D: return spawn_entity(type_id, pos))

	# WorldSpawner mit aktuellen Referenzen neu erstellen
	_spawner = WorldSpawner.new(
		_entity_orchestrator,
		factory.terrain_generator,
		_world_gen,
		data
	)
	_spawner.spawn_all(world_root)

	EventBus.world.emit_world_scene_ready(world_root)

	Logger.log_end("on_world_scene_ready()", t, LOG_CAT)
	Logger.log_info("Welt bereit. Entities: %d." % _entity_orchestrator.get_entity_count(), LOG_CAT)


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func get_save_key() -> String:
	return SAVE_KEY


func get_save_data() -> Dictionary:
	return _save_handler.get_save_data()


# ─────────────────────────────────────────────
# Öffentliche API
# ─────────────────────────────────────────────

func get_formatted_time() -> String:
	return _time.get_formatted_time()


func spawn_entity(type_id: String, position: Vector3, config: Dictionary = {}) -> Node3D:
	if not is_instance_valid(_entity_orchestrator):
		return null
	return _entity_orchestrator.spawn_entity(type_id, position, config)


func despawn_entity(uuid: String) -> void:
	if is_instance_valid(_entity_orchestrator):
		_entity_orchestrator.despawn_entity(uuid)


func get_entity_debug_info() -> Dictionary:
	if not is_instance_valid(_entity_orchestrator):
		return {}
	return _entity_orchestrator.get_debug_info()


func _on_entity_despawn_requested(uuid: String) -> void:
	despawn_entity(uuid)


## Pre-Flush-Handler: Sichert Pet-Daten bevor SaveSystem auf Disk schreibt.
## Wird über EventBus.system.save_pre_flush ausgelöst (nicht direkt von GameSaveService).
func _on_save_pre_flush() -> void:
	collect_and_store_pet_data()


# ─────────────────────────────────────────────
# Öffentliche API — WorldData-Delegation
# Externe Aufrufer (Entities, Services) nutzen diese statt Services.world.data.*
# ─────────────────────────────────────────────

## Markiert einen Baum als geerntet. Aufgerufen von OakTree nach Interaktion.
func mark_tree_harvested(pos: Vector3) -> void:
	data.mark_tree_harvested(pos)


## Markiert ein Erz als geerntet. Aufgerufen von IronOre nach Interaktion.
func mark_ore_harvested(pos: Vector3) -> void:
	data.mark_ore_harvested(pos)


## Speichert Pet-Zustand vor dem Abspeichern.
func store_pet_save_data(pet_data: Array[Dictionary]) -> void:
	data.set_meta("saved_pets", pet_data)


## Scannt alle aktiven Pets und sichert deren Zustand via store_pet_save_data().
## Aufgerufen von _on_save_pre_flush() — nicht mehr direkt von GameSaveService.
func collect_and_store_pet_data() -> void:
	var pet_data: Array[Dictionary] = []
	for pet in get_tree().get_nodes_in_group("pets"):
		if pet is PetComponent:
			pet_data.append(pet.get_save_state())
	store_pet_save_data(pet_data)
	Logger.log_debug("Pets gesammelt und gespeichert: %d" % pet_data.size(), LOG_CAT)
