# res://scripts/core/UIContext.gd
class_name UIContext extends IUIContext

## UIContext — Produktions-Implementierung von IUIContext.
##
## Wird von HUDBuilder.build_all() erstellt und an alle Controller injiziert.

var _quest:        QuestService    = null
var _skill_system: SkillSystem     = null
var _inventory:    InventorySystem = null
var _equipment:    EquipmentService = null
var _data:         DataService      = null


static func from_services() -> UIContext:
	var ctx        := UIContext.new()
	ctx._quest        = Services.quest
	ctx._skill_system = Services.skill_system
	ctx._inventory    = Services.inventory
	ctx._equipment    = Services.equipment
	ctx._data         = Services.data
	return ctx


static func for_test() -> UIContext:
	return UIContext.new()


func get_quest()        -> QuestService:    return _quest
func get_skill_system() -> SkillSystem:     return _skill_system
func get_inventory()    -> InventorySystem: return _inventory
func get_equipment()    -> EquipmentService: return _equipment
func get_data()         -> DataService:      return _data
