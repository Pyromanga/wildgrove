class_name BootstrapConfig extends Resource

## BootstrapConfig — deklariert welche Services beim App-Start (global)
## und welche beim Charakter-Start (session) gebootet werden.
##
## ENTSCHEIDUNGSBAUM für neue Services:
##   Hält dieser Service Charakter-spezifischen State
##   oder lädt er Daten aus dem aktiven Save-Slot?
##     JA  → session_services
##     NEIN → global_services
##
## Global-Services leben für die gesamte App-Lifetime.
## Session-Services werden bei jedem Charakter-Wechsel
## vollständig abgerissen und neu gebootet (ADR-009).

## App-globale Services. Booten einmalig beim App-Start.
## Kein Charakter-State — überleben jeden Charakter-Wechsel.
@export var global_services: Array[ServiceDefinition] = []

## Charakter-spezifische Services. Booten bei Session-Start,
## werden bei Charakter-Wechsel via ServiceTeardownManager bereinigt.
@export var session_services: Array[ServiceDefinition] = []
