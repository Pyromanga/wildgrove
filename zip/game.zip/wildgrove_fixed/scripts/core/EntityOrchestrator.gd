extends Node
class_name EntityOrchestrator

## EntityOrchestrator — Entity-Lifecycle, Gruppe-Management, UUID-Tracking.
##
## LEBT ALS CHILD VON WorldService (nicht als Autoload).
##
## Verantwortung (koordiniert, delegiert Details):
##   - spawn_entity() / despawn_entity() — öffentliche API
##   - UUID-basiertes Tracking: _entities { uuid: Node3D }
##   - Delegiert Pooling  → EntityPool
##   - Delegiert Definition/Instanziierung → EntityRegistry
##   - on_world_unloaded() für sauberes Cleanup

const LOG_CAT := "EntityOrchestrator"

var _world_root: Node3D = null
var _entities:   Dictionary = {}   # { uuid: Node3D }
var _pool:       EntityPool
var _registry:   EntityRegistry
var _stats:      Dictionary = {
	"total_spawned":  0,
	"total_despawned": 0,
}


# ─────────────────────────────────────────────
# Lifecycle
# ─────────────────────────────────────────────


func _ready() -> void:
	_pool     = EntityPool.new()
	_registry = EntityRegistry.new()
	Logger.log_info("EntityOrchestrator bereit.", LOG_CAT)


## Initialisiert für eine neue Welt-Szene. Idempotent.
func initialize(world_root: Node3D) -> void:
	if not is_instance_valid(world_root):
		Logger.log_error("initialize() fehlgeschlagen: world_root ist null.", LOG_CAT)
		return

	if _world_root != null:
		Logger.log_warn(
			"initialize() erneut aufgerufen — vorheriger world_root '%s' wird ersetzt."
			% (_world_root.name if is_instance_valid(_world_root) else "<freigegeben>"),
			LOG_CAT
		)
		_entities.clear()

	_world_root = world_root
	Logger.log_info(
		"Initialisiert für World '%s'. Definitionen: %d."
		% [world_root.name, _registry.get_keys().size()],
		LOG_CAT
	)


## Aufgerufen bevor die Welt-Szene entladen wird.
func on_world_unloaded() -> void:
	var count := _entities.size()
	Logger.log_info("World-Unload: %d aktive Entities werden bereinigt." % count, LOG_CAT)

	for uuid in _entities.keys():
		var entity := _entities[uuid] as Node3D
		if is_instance_valid(entity):
			var type_id: String = entity.get_meta("entity_type", "")
			Logger.log_debug("on_despawn() → '%s' (uuid: %s)" % [type_id, uuid], LOG_CAT)
			if entity.has_method("on_despawn"):
				entity.on_despawn()
		else:
			Logger.log_debug("Entity '%s' bereits freigegeben." % uuid, LOG_CAT)

	_entities.clear()
	_world_root = null

	var pool_freed := _pool.flush()
	Logger.log_info(
		"EntityOrchestrator zurückgesetzt. Aktive: 0, Pool freigegeben: %d." % pool_freed,
		LOG_CAT
	)


# ─────────────────────────────────────────────
# Öffentliche API — Definitionen
# ─────────────────────────────────────────────


## Registriert eine Entity-Definition. Muss vor spawn_entity() aufgerufen werden.
func register_definition(type_id: String, script_path: String, group: String = "") -> void:
	_registry.register(type_id, script_path, group)


# ─────────────────────────────────────────────
# Öffentliche API — Spawn / Despawn
# ─────────────────────────────────────────────


## Instanziiert eine Entity anhand type_id an position.
## config: optionale Konfiguration die an on_spawn() übergeben wird.
## Gibt die Entity zurück oder null bei Fehler.
func spawn_entity(type_id: String, position: Vector3, config: Dictionary = {}) -> Node3D:
	if not is_instance_valid(_world_root):
		Logger.log_error(
			"spawn_entity('%s') fehlgeschlagen: Kein world_root. initialize() aufgerufen?"
			% type_id,
			LOG_CAT
		)
		return null

	# Pool zuerst, dann frisch instanziieren
	var entity: Node3D = _pool.acquire(type_id)
	if not is_instance_valid(entity):
		entity = _registry.instantiate(type_id)
	if not is_instance_valid(entity):
		Logger.log_error("spawn_entity('%s'): Instanziierung fehlgeschlagen." % type_id, LOG_CAT)
		return null

	entity.position = position

	var uuid := _generate_uuid()
	entity.set_meta("entity_uuid", uuid)
	entity.set_meta("entity_type", type_id)

	_world_root.add_child(entity)  # ← _ready() feuert hier
	_entities[uuid] = entity

	if entity.has_method("on_spawn"):
		var ctx := EntityContext.from_services()
		entity.on_spawn(config, ctx)

	_stats["total_spawned"] += 1
	EventBus.world.emit_entity_spawned(type_id, entity, position)

	Logger.log_info(
		"Entity gespawnt: type='%s' uuid='%s' pos=%s" % [type_id, uuid, str(position)],
		LOG_CAT
	)
	return entity


## Despawnt eine Entity anhand UUID. Gibt sie in den Pool zurück wenn möglich.
func despawn_entity(uuid: String) -> void:
	if uuid.is_empty():
		Logger.log_warn("despawn_entity(): UUID ist leer!", LOG_CAT)
		return

	if not _entities.has(uuid):
		Logger.log_warn("despawn_entity('%s'): UUID nicht in aktiven Entities." % uuid, LOG_CAT)
		return

	var entity := _entities[uuid] as Node3D
	var type_id: String = entity.get_meta("entity_type", "") if is_instance_valid(entity) else ""

	_entities.erase(uuid)
	_stats["total_despawned"] += 1

	if not is_instance_valid(entity):
		Logger.log_debug("Entity '%s' war bereits freigegeben." % uuid, LOG_CAT)
		EventBus.world.emit_entity_despawned(type_id, uuid, Vector3.ZERO)
		return

	var entity_pos := entity.global_position

	if entity.has_method("on_despawn"):
		entity.on_despawn()

	if _pool.release(type_id, entity):
		Logger.log_debug("Entity '%s' (%s) → Pool zurückgegeben." % [uuid, type_id], LOG_CAT)
	else:
		entity.queue_free()
		Logger.log_debug("Entity '%s' (%s) → queue_free()." % [uuid, type_id], LOG_CAT)

	EventBus.world.emit_entity_despawned(type_id, uuid, entity_pos)


# ─────────────────────────────────────────────
# Öffentliche API — Abfragen
# ─────────────────────────────────────────────


func get_entities_in_group(group: String) -> Array[Node3D]:
	var result: Array[Node3D] = []
	for uuid in _entities:
		var entity := _entities[uuid] as Node3D
		if is_instance_valid(entity) and entity.is_in_group(group):
			result.append(entity)
	return result


func get_entity_count() -> int:
	return _entities.size()


func get_entity(uuid: String) -> Node3D:
	return _entities.get(uuid)


func get_debug_info() -> Dictionary:
	return {
		"world_root":       _world_root.name if is_instance_valid(_world_root) else "<null>",
		"active_entities":  _entities.size(),
		"definitions":      _registry.get_keys(),
		"pool_sizes":       _pool.get_sizes(),
		"pool_hits":        _pool.pool_hits,
		"pool_misses":      _pool.pool_misses,
		"stats":            _stats.duplicate(),
	}


# ─────────────────────────────────────────────
# Intern
# ─────────────────────────────────────────────


func _generate_uuid() -> String:
	# MIGRATION-010 Phase 1: Authority-Guard — UUID-Vergabe ist server-autoritativ.
	# Kein get_ticks_usec() (Kollisionsgefahr bei gleichzeitigen Clients).
	# Tier 1 (kein Peer gesetzt): Guard ist immer true → verhält sich wie bisher.
	# Tier 2/3: nur die Autorität darf UUIDs vergeben (Phase 4 verdrahtet den RPC-Rückweg).
	if is_instance_valid(multiplayer) and multiplayer.has_multiplayer_peer():
		assert(
			multiplayer.is_server(),
			"_generate_uuid() darf nur von der Autorität aufgerufen werden!"
		)
	var a := randi()
	var b := randi()
	var c := randi()
	var d := randi()
	# Version-Bits setzen: version=4 (0100xxxx), variant=10xx (RFC 4122)
	c = (c & 0x0FFF) | 0x4000        # version 4
	d = (d & 0x3FFFFFFF) | 0x80000000  # variant 10xx
	return "%08x-%04x-%04x-%04x-%04x%08x" % [
		a,
		(b >> 16) & 0xFFFF,
		c & 0xFFFF,
		(c >> 16) & 0xFFFF,
		d & 0xFFFF,
		d >> 16
	]
