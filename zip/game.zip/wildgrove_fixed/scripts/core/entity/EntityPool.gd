class_name EntityPool
extends RefCounted

## EntityPool — Object-Pooling für World-Entities.
##
## Verantwortung:
##   - Despawnte Entities zwischenspeichern für Wiederverwendung
##   - Pool-Größe pro Typ begrenzen (POOL_SIZE)
##   - Nodes aus dem SceneTree entfernen bevor sie gelagert werden
##
## Verwendet von EntityOrchestrator für _create_or_pool() und _try_return_to_pool().

const LOG_CAT  := "EntityPool"
const POOL_SIZE := 10

## { type_id: Array[Node3D] }
var _pool: Dictionary = {}

## Statistiken (spiegeln EntityOrchestrator._stats für Pool-Entries)
var pool_hits:   int = 0
var pool_misses: int = 0


## Versucht eine Instanz aus dem Pool zu holen.
## Gibt null zurück wenn kein valider Eintrag vorhanden.
func acquire(type_id: String) -> Node3D:
	if not _pool.has(type_id) or _pool[type_id].is_empty():
		pool_misses += 1
		return null

	var pooled := _pool[type_id].pop_back() as Node3D
	if is_instance_valid(pooled):
		pool_hits += 1
		Logger.log_debug(
			"Pool-Hit: '%s' (Pool noch: %d)" % [type_id, _pool[type_id].size()], LOG_CAT
		)
		return pooled

	Logger.log_debug("Pool-Eintrag für '%s' war invalid — übersprungen." % type_id, LOG_CAT)
	pool_misses += 1
	return null


## Legt eine Instanz in den Pool zurück.
## Gibt false zurück wenn Pool voll oder type_id unbekannt.
func release(type_id: String, entity: Node3D) -> bool:
	if type_id.is_empty():
		return false

	if not _pool.has(type_id):
		_pool[type_id] = []

	if _pool[type_id].size() >= POOL_SIZE:
		Logger.log_debug(
			"Pool voll für '%s' (max: %d) → queue_free." % [type_id, POOL_SIZE], LOG_CAT
		)
		return false

	# Aus dem Tree entfernen bevor im Pool lagern
	if entity.is_inside_tree() and is_instance_valid(entity.get_parent()):
		entity.get_parent().remove_child(entity)

	_pool[type_id].append(entity)
	return true


## Gibt alle Pool-Nodes frei (bei World-Unload).
## Gibt die Anzahl der freigegebenen Nodes zurück.
func flush() -> int:
	var freed := 0
	for type_id in _pool.keys():
		for pooled in _pool[type_id]:
			if is_instance_valid(pooled) and not pooled.is_inside_tree():
				pooled.queue_free()
				freed += 1
	_pool.clear()
	return freed


## Gibt Debug-Infos zurück: { type_id: pool_size }
func get_sizes() -> Dictionary:
	var out: Dictionary = {}
	for type_id in _pool:
		out[type_id] = _pool[type_id].size()
	return out
