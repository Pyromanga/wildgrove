class_name ServiceValidator extends RefCounted

const LOG_CAT := "ServiceValidator"
const CONFIG_PATH := "res://config/BootstrapConfig.tres"


## Validiert die Global-Services aus BootstrapConfig.tres.
func validate() -> Array[ServiceDefinition]:
	var config := _load_config()
	if config == null:
		return []
	return _validate_list(config.global_services, "global")


## Validiert die Session-Services aus BootstrapConfig.tres.
## global_names: Namen der bereits gebootteten Global-Services (gelten als bekannte Deps).
func validate_session(global_names: Array[String] = []) -> Array[ServiceDefinition]:
	var config := _load_config()
	if config == null:
		return []
	return _validate_list(config.session_services, "session", global_names)


func _validate_list(
	services: Array[ServiceDefinition],
	label: String,
	external_names: Array[String] = []
) -> Array[ServiceDefinition]:
	if services.is_empty():
		Logger.log_warn("BootstrapConfig.%s_services ist leer." % label, LOG_CAT)
		return []

	# Bekannte Namen: eigene + externe (Global-Services)
	var known_names: Dictionary = {}
	for name in external_names:
		known_names[name.to_lower()] = true

	var defs: Array[ServiceDefinition] = []
	var errors := 0

	for i in range(services.size()):
		var s = services[i]

		if s == null:
			Logger.log_error(
				"[%s] Eintrag am Index %d ist physisch NULL." % [label, i], LOG_CAT
			)
			errors += 1
			continue

		var def := s as ServiceDefinition
		if def == null:
			Logger.log_error(
				"[%s] Eintrag am Index %d ist keine 'ServiceDefinition'." % [label, i], LOG_CAT
			)
			errors += 1
			continue

		defs.append(def)
		known_names[def.service_name.to_lower()] = true

	if errors > 0:
		Logger.log_error("%d fundamentale Strukturfehler in [%s]." % [errors, label], LOG_CAT)
		return []

	var validation_errors := 0
	for i in range(defs.size()):
		validation_errors += _check_definition(defs[i], i, known_names)

	if validation_errors > 0:
		Logger.log_error(
			"%d inhaltliche Fehler in [%s] — Boot abgebrochen." % [validation_errors, label], LOG_CAT
		)
		return []

	Logger.log_info("[%s] %d Services validiert." % [label, defs.size()], LOG_CAT)
	return defs


func _load_config() -> BootstrapConfig:
	if not ResourceLoader.exists(CONFIG_PATH):
		Logger.log_error("BootstrapConfig nicht gefunden: '%s'" % CONFIG_PATH, LOG_CAT)
		return null

	var res = load(CONFIG_PATH)
	if res == null:
		Logger.log_error(
			"Resource konnte nicht geladen werden (Pfad okay, aber Datei defekt?).", LOG_CAT
		)
		return null

	return res as BootstrapConfig


func _check_definition(
	def: ServiceDefinition,
	index: int,
	known_names: Dictionary
) -> int:
	var errors := 0
	var identifier := (
		"'%s'" % def.service_name if not def.service_name.is_empty() else "Index %d" % index
	)

	if def.service_name.is_empty():
		Logger.log_error("Service am Index %d hat keinen 'service_name'!" % index, LOG_CAT)
		errors += 1

	if def.path.is_empty():
		Logger.log_error("Service %s: Pfad-Variable ist leer." % identifier, LOG_CAT)
		errors += 1
	elif not ResourceLoader.exists(def.path):
		Logger.log_error("Service %s: Pfad '%s' existiert nicht." % [identifier, def.path], LOG_CAT)
		errors += 1

	for res_path in def.required_data_files:
		if res_path.is_empty():
			Logger.log_warn(
				"Service %s: Leerer Pfad in 'required_data_files'." % identifier, LOG_CAT
			)
			continue
		if not ResourceLoader.exists(res_path):
			Logger.log_error(
				"Service %s: Benötigte Datei fehlt: '%s'" % [identifier, res_path], LOG_CAT
			)
			errors += 1

	if def.service_name in def.deps:
		Logger.log_error(
			"Service %s: Abhängigkeit auf sich selbst (Circular)!" % identifier, LOG_CAT
		)
		errors += 1

	return errors
