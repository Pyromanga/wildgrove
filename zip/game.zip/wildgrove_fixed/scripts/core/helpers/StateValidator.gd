class_name StateValidator


static func is_transition_allowed(
	from: GameEnums.State, to: GameEnums.State, _config: GameConfig
) -> bool:
	var from_str: String = GameEnums.State.keys()[from]
	var to_str: String = GameEnums.State.keys()[to]
	var allowed: Array = GameConfig.VALID_TRANSITIONS.get(from_str, [])

	if not to_str in allowed:
		Logger.log_warn("Ungültiger Übergang: %s -> %s" % [from_str, to_str], "StateValidator")
		return false

	return true
