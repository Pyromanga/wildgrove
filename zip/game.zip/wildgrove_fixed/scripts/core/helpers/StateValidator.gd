class_name StateValidator


static func is_transition_allowed(
	from: GameEnums.State, to: GameEnums.State, config: GameConfig
) -> bool:
	if not config:
		return true  # Oder Fallback-Logik

	var from_str: String = str(GameEnums.State.keys()[from])
	var to_str: String = str(GameEnums.State.keys()[to])

	# Kein Cast zu Array[String] — Godot 4 speichert Dictionary-Werte aus .tres
	# als ungetyptes Array. Der Cast "as Array[String]" würde silent nil zurückgeben.
	var allowed: Array = config.valid_transitions.get(from_str, [])

	if not to_str in allowed:
		Logger.log_warn("Ungültiger Übergang: %s -> %s" % [from_str, to_str], "StateValidator")
		return false

	return true
