extends Node

## Services — Typisierter Service-Locator / Dependency-Container.
##
## AutoLoad #4 (nach Logger, EventBus, SimpleTerminal).
## Wird leer gestartet und von ServiceOrchestrator in zwei Schritten befüllt:
##   Phase 7 (global boot):   populate_global()  — ticker, scene, data, ...
##   Phase S8 (session boot): populate_session() — inventory, skills, world, ...
##
## WICHTIG: Niemals Services.xyz in configure() aufrufen — Services ist zu diesem
## Zeitpunkt noch nicht befüllt. Services.xyz ist erst ab on_ready() sicher.

# ─────────────────────────────────────────────
# Infrastruktur-Services (GLOBAL)
# ─────────────────────────────────────────────
var ticker: ServiceTicker = null
var scene: SceneManager   = null

# ─────────────────────────────────────────────
# Datenhaltung (GLOBAL)
# ─────────────────────────────────────────────
var save_system: SaveSystem = null
var data:        DataService = null

# ─────────────────────────────────────────────
# Game Flow (GLOBAL)
# ─────────────────────────────────────────────
var game_manager: GameManager = null

# ─────────────────────────────────────────────
# Datenhaltung (SESSION)
# ─────────────────────────────────────────────
var game_save:   GameSaveService = null

# ─────────────────────────────────────────────
# Gameplay-Services (SESSION)
# ─────────────────────────────────────────────
## MIGRATION-010 Phase 2: NetworkBridge hostet alle @rpc-Methoden für RefCounted-Services.
var network_bridge:    NetworkBridge       = null
var inventory:         InventorySystem     = null
var skill_system:      SkillSystem         = null
var quest:             QuestService        = null
var player_states:     PlayerStateService  = null
var reward_dispatcher: RewardDispatcher    = null
var stat_modifiers:    StatModifierService = null
var combat:            CombatSystem        = null
var equipment:         EquipmentService    = null

# ─────────────────────────────────────────────
# World & Entities (SESSION)
# ─────────────────────────────────────────────
var world:                WorldService          = null
var interaction_executor: InteractionExecutor   = null
var respawn:              RespawnService        = null
var world_gen:            WorldGenerationService = null

## Alias für WorldService.factory3d — gibt null zurück wenn keine Session aktiv.
var factory3d: Factory3D:
	get:
		return world.factory3d if is_instance_valid(world) else null

# ─────────────────────────────────────────────
# UI
# ─────────────────────────────────────────────
## HUDManager lebt nicht im Services-Container (Lifecycle-Mismatch, ADR-003/TD-05).
## HUDManager wird von WorldService.on_world_scene_ready() instanziiert und
## kommuniziert ausschliesslich über EventBus.ui.


# ─────────────────────────────────────────────
# Intern — aufgerufen von ServiceOrchestrator
# ─────────────────────────────────────────────


func populate_global(registry: ServiceRegistry) -> void:
	var t := Logger.log_begin("Services.populate_global()", "Services")

	ticker       = _resolve(registry, "ticker")       as ServiceTicker
	scene        = _resolve(registry, "scenemanager") as SceneManager
	save_system  = _resolve(registry, "savesystem")   as SaveSystem
	data         = _resolve(registry, "data")         as DataService
	game_manager = _resolve(registry, "gamemanager")  as GameManager

	Logger.log_end("Services.populate_global()", t, "Services")
	Logger.log_info("Globale Services im Container.", "Services")


func populate_session(registry: ServiceRegistry) -> void:
	var t := Logger.log_begin("Services.populate_session()", "Services")

	game_save            = _resolve(registry, "gamesave")             as GameSaveService
	network_bridge       = _resolve(registry, "network_bridge")       as NetworkBridge
	inventory            = _resolve(registry, "inventory")            as InventorySystem
	skill_system         = _resolve(registry, "skill_system")         as SkillSystem
	quest                = _resolve(registry, "quest")                as QuestService
	player_states        = _resolve(registry, "playerstates")         as PlayerStateService
	reward_dispatcher    = _resolve(registry, "reward_dispatcher")    as RewardDispatcher
	stat_modifiers       = _resolve(registry, "stat_modifiers")       as StatModifierService
	combat               = _resolve(registry, "combat")               as CombatSystem
	equipment            = _resolve(registry, "equipment")            as EquipmentService
	world                = _resolve(registry, "world")                as WorldService
	interaction_executor = _resolve(registry, "interaction_executor") as InteractionExecutor
	world_gen            = _resolve(registry, "world_gen")            as WorldGenerationService
	respawn              = _resolve(registry, "respawn")              as RespawnService

	Logger.log_end("Services.populate_session()", t, "Services")
	Logger.log_info("Session-Services im Container.", "Services")


func clear_session() -> void:
	game_save            = null
	network_bridge       = null
	inventory            = null
	skill_system         = null
	quest                = null
	player_states        = null
	reward_dispatcher    = null
	stat_modifiers       = null
	combat               = null
	equipment            = null
	world                = null
	interaction_executor = null
	world_gen            = null
	respawn              = null
	Logger.log_debug("Session-Slots geleert.", "Services")


func clear() -> void:
	clear_session()
	ticker       = null
	scene        = null
	save_system  = null
	data         = null
	game_manager = null
	Logger.log_debug("DependencyContainer vollständig geleert.", "Services")


# ─────────────────────────────────────────────
# Hilfsfunktionen
# ─────────────────────────────────────────────


func _resolve(registry: ServiceRegistry, key: String) -> Object:
	var svc: Object = registry.get_service(key)
	if svc == null:
		Logger.log_warn("Services._resolve: '%s' nicht in Registry." % key, "Services")
	return svc


## Gibt eine lesbare Übersicht aller Services zurück. Für Debug-Commands.
func get_status_report() -> Dictionary:
	return {
		# Global
		"ticker":             is_instance_valid(ticker),
		"scene":              is_instance_valid(scene),
		"save_system":        is_instance_valid(save_system),
		"data":               is_instance_valid(data),
		"game_manager":       is_instance_valid(game_manager),
		# Session
		"game_save":          is_instance_valid(game_save),
		"network_bridge":     is_instance_valid(network_bridge),
		"inventory":          is_instance_valid(inventory),
		"skill_system":       is_instance_valid(skill_system),
		"quest":              is_instance_valid(quest),
		"player_states":      is_instance_valid(player_states),
		"reward_dispatcher":  is_instance_valid(reward_dispatcher),
		"stat_modifiers":     is_instance_valid(stat_modifiers),
		"combat":             is_instance_valid(combat),
		"equipment":          is_instance_valid(equipment),
		"world":              is_instance_valid(world),
		"world.factory3d":    is_instance_valid(factory3d),
		"interaction_executor": is_instance_valid(interaction_executor),
		"world_gen":          is_instance_valid(world_gen),
		"respawn":            is_instance_valid(respawn),
	}
