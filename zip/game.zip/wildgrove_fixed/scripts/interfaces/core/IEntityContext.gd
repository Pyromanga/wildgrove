# res://scripts/interfaces/core/IEntityContext.gd
class_name IEntityContext extends RefCounted

## IEntityContext — Schmale Service-Fassade für Entities.
##
## Stattdessen bekommen sie via on_spawn(config, context) nur die Services,
## die sie wirklich brauchen — testbar, server/client-dual-context-fähig.
##
## VERWENDUNG:
##   EntityOrchestrator erstellt einen EntityContext und injiziert ihn in on_spawn():
##     entity.on_spawn(config, context)
##
##   In einem Server-Kontext: ServerEntityContext mit anderen Implementierungen.
##   In einem Client-Kontext: ClientEntityContext mit Prediction-Services.
##   In Tests:               MockEntityContext mit Mock-Implementations.
##
## WICHTIG: Entities speichern den Context als _ctx: IEntityContext.
##   Kein Services.xyz, kein get_node("/root/Services").

# ─────────────────────────────────────────────
# Gameplay-Services
# ─────────────────────────────────────────────

## Skill-System für Schadens-Berechnung, XP-Queries.
## Gibt null zurück wenn der Kontext diesen Service nicht bereitstellt
## (z.B. rein visueller Client-Kontext).
func get_skill_system() -> SkillSystem:
	return null


## InventorySystem für Item-Checks (z.B. Tool-Requirement).
func get_inventory() -> InventorySystem:
	return null


## EventBus-Zugriff — immer vorhanden, da er ein AutoLoad ist.
## Hier als expliziter Accessor für Testbarkeit (Mock-EventBus möglich).
func get_event_bus() -> Node:
	return EventBus


# ─────────────────────────────────────────────
# Welt-Services
# ─────────────────────────────────────────────

## Factory3D für prozedurales Spawning von Sub-Entities.
func get_factory() -> Factory3D:
	return null


## RespawnService — für Entities die ihren eigenen Respawn triggern müssen.
func get_respawn() -> RespawnService:
	return null


## DataService — für Entities die Basiswerte (Stats, Definitionen) lesen müssen.
## Player nutzt ihn um Geschwindigkeit und Schwerkraft aus PlayerStats zu laden.
func get_data() -> DataService:
	return null


## StatModifierService — für Entities die effektive Stat-Werte berechnen.
func get_stat_modifiers() -> StatModifierService:
	return null


## CombatSystem — für Entities die Schaden berechnen und anwenden müssen.
## EnemyNPC nutzt es in _on_interacted() um player_melee_damage() zu berechnen.
func get_combat_system() -> CombatSystem:
	return null


## EquipmentService — für Entities die ihr eigenes Equipment lesen/ändern müssen
## (z.B. Player beim Ausrüsten einer Waffe aus dem Inventar).
func get_equipment() -> EquipmentService:
	return null
