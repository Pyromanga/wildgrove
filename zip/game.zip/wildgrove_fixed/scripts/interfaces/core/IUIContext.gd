# res://scripts/interfaces/core/IUIContext.gd
class_name IUIContext extends RefCounted

## IUIContext — Schmale Service-Fassade für UI-Controller.
##
## Analogon zu IEntityContext für den UI-Layer.
## Controller bekommen via setup(visuals, ctx) nur die Services die sie
## wirklich brauchen — testbar, keine direkten Services.xyz-Zugriffe.
##
## VERWENDUNG:
##   HUDBuilder.build_all(hud, UIContext.from_services()) injiziert den Context.
##   In Tests: UIContext.for_test() mit Mock-Implementations.
##
## WICHTIG: Controller speichern den Context als _ctx: IUIContext.
##   Kein Services.xyz aus Controller-Code.

## QuestService — für Panels die Quest-State lesen.
func get_quest() -> QuestService:
	return null

## SkillSystem — für Panels die Skill-Level/XP anzeigen.
func get_skill_system() -> SkillSystem:
	return null

## InventorySystem — für das Inventar-Panel.
func get_inventory() -> InventorySystem:
	return null

## EquipmentService — für das Equipment-Panel.
func get_equipment() -> EquipmentService:
	return null

## DataService — für Item-Definitionen in Equipment-Panel.
func get_data() -> DataService:
	return null
