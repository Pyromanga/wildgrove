# Tests — WildGrove

## Setup

GUT v9.3.0 muss installiert sein. Ohne GUT laufen nur die Stubs in `tests/`.

### GUT installieren

```
Project → Asset Library → "Gut - Godot Unit Testing" → Install
```

Oder manuell: https://github.com/bitwes/Gut/releases/tag/v9.3.0  
→ Ordner als `res://addons/gut/` ablegen  
→ Project → Project Settings → Plugins → GUT aktivieren

### Tests ausführen

```
# Via GUT-Panel (empfohlen):
Project → Tools → GUT

# Via CLI (CI):
godot --headless -s addons/gut/gut_cmdln.gd -gdir=res://tests/ -gexit
```

---

## Test-Struktur

```
tests/
  unit/                          ← Isolierte Unit-Tests (kein SceneTree nötig)
    test_save_migration.gd       ← SaveMigrationService — pure functions
    test_quest_objective.gd      ← QuestObjectiveHandler — pure functions
    test_entity_context.gd       ← EntityContext.for_test() — kein AutoLoad
    test_stat_modifier.gd        ← StatModifier + StatModifierService
    test_save_system.gd          ← SaveSystem — atomic write, slot management
    test_equipment_service.gd    ← EquipmentService — item equip/unequip logic
    test_combat_system.gd        ← CombatSystem — damage calculation
    test_skill_system.gd         ← SkillSystem — XP, level-up, multi-tenancy
  IntegrationTest.gd             ← Boot-Sanity-Check (braucht echten ServiceOrchestrator)
```

---

## Konventionen

- Unit-Tests: `extends GutTest` (GUT v9 API)
- Dateien: `test_*.gd` — GUT matched automatisch
- Assertions: `assert_eq`, `assert_true`, `assert_not_null` (GUT-API)
- Kein `Services.xyz` in Unit-Tests — `EntityContext.for_test()` oder direkte Instanziierung
- Jeder `describe_*`-Block gruppiert verwandte Tests

---

## Warum diese drei Klassen zuerst?

| Klasse | Warum sofort testbar |
|--------|---------------------|
| `SaveMigrationService` | Reine statische Funktionen — kein State, kein SceneTree |
| `QuestObjectiveHandler` | Reine statische Funktionen — nur Dictionary-Input |
| `EntityContext.for_test()` | Liefert isolierten Kontext — kein AutoLoad nötig |

Diese drei decken die kritischsten Datenpfade ab (Speichern, Quests, Entities) und haben null externe Abhängigkeiten.
