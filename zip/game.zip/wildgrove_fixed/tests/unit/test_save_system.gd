# res://tests/unit/test_save_system.gd
extends GutTest

## Tests für SaveSystem Slot-Infrastruktur (A-10).
##
## Strategie: SaveSystem direkt instanziieren — kein configure()-Aufruf nötig,
## da nur die Slot-API (Pfad, ID, Liste, Löschen) getestet wird. File-System-Operationen
## nutzen das Prefix "unit_test_" und werden in after_each() vollständig bereinigt.
##
## A-02 (Session 6): SaveSystem extends jetzt Service (RefCounted) statt ServiceNode.
## Kein add_child_autofree() mehr nötig — RefCounted wird automatisch freigegeben,
## sobald die letzte Referenz (_sys) in after_each() / beim nächsten before_each()
## überschrieben wird. Kein .free()-Aufruf nötig oder zulässig (RefCounted hat keine free()).
##
## WICHTIG: Diese Tests schreiben echte Dateien nach user://saves/ (Godot-User-Dir
## im Test-Environment). Der TEST_PREFIX verhindert Kollisionen mit echten Saves.
##
## Abgedeckte Pfade:
##   get_save_path()         — korrekter Pfad pro Player-ID, keine Kollisionen
##   begin_session()         — Validierung (leer, whitespace), Wechsel, ID-Persistenz
##   get_active_save_path()  — spiegelt aktive ID
##   has_save_for()          — existiert / existiert nicht
##   list_local_saves()      — listet .json, ignoriert .bak
##   delete_save_for()       — löscht Datei + .bak, lehnt Leer-ID ab, kein Cross-Delete
##   Vollständiger Lifecycle  — create → list → switch → delete

const SAVE_DIR   := "user://saves/"
const TEST_PREFIX := "unit_test_"
const PLAYER_A   := "unit_test_alpha"
const PLAYER_B   := "unit_test_beta"

var _sys: SaveSystem


func before_each() -> void:
	_sys = SaveSystem.new()
	if not DirAccess.dir_exists_absolute(SAVE_DIR):
		DirAccess.make_dir_recursive_absolute(SAVE_DIR)


func after_each() -> void:
	_cleanup_test_files()
	_sys = null


# ─────────────────────────────────────────────
# get_save_path()
# ─────────────────────────────────────────────

func test_get_save_path_contains_player_id() -> void:
	var path := _sys.get_save_path(PLAYER_A)
	assert_true(path.contains(PLAYER_A), "Pfad muss die Player-ID enthalten")


func test_get_save_path_ends_with_dot_json() -> void:
	var path := _sys.get_save_path(PLAYER_A)
	assert_true(path.ends_with(".json"), "Pfad muss .json-Extension haben")


func test_different_ids_yield_different_paths() -> void:
	var path_a := _sys.get_save_path(PLAYER_A)
	var path_b := _sys.get_save_path(PLAYER_B)
	assert_ne(path_a, path_b, "Unterschiedliche Player-IDs → unterschiedliche Pfade")


func test_same_id_yields_same_path() -> void:
	var path_1 := _sys.get_save_path(PLAYER_A)
	var path_2 := _sys.get_save_path(PLAYER_A)
	assert_eq(path_1, path_2, "Gleiche ID → deterministischer Pfad")


# ─────────────────────────────────────────────
# begin_session() / end_session() / get_active_player_id()  [ADR-009]
# set_active_player_id() wurde durch begin_session() ersetzt.
# ─────────────────────────────────────────────

func test_default_player_id_is_empty_without_session() -> void:
	assert_eq(_sys.get_active_player_id(), "",
		"Frische Instanz ohne Session muss leer sein (ADR-009)")


func test_begin_session_sets_player_id() -> void:
	_sys.begin_session(PLAYER_A)
	assert_eq(_sys.get_active_player_id(), PLAYER_A)


func test_begin_session_empty_string_is_rejected() -> void:
	_sys.begin_session(PLAYER_A)
	_sys.begin_session("")
	assert_eq(_sys.get_active_player_id(), PLAYER_A,
		"Leere ID darf die aktive ID nicht überschreiben")


func test_begin_session_whitespace_only_is_rejected() -> void:
	_sys.begin_session(PLAYER_A)
	_sys.begin_session("   ")
	assert_eq(_sys.get_active_player_id(), PLAYER_A,
		"Whitespace-only ID darf die aktive ID nicht überschreiben")


func test_get_active_save_path_reflects_session_id() -> void:
	_sys.begin_session(PLAYER_A)
	var active := _sys.get_active_save_path()
	var expected := _sys.get_save_path(PLAYER_A)
	assert_eq(active, expected,
		"get_active_save_path() muss auf die aktive Session-ID zeigen")


func test_end_session_clears_player_id() -> void:
	_sys.begin_session(PLAYER_A)
	_sys.end_session()
	assert_eq(_sys.get_active_player_id(), "",
		"end_session() muss aktive Player-ID leeren")


func test_has_active_session_false_without_session() -> void:
	assert_false(_sys.has_active_session(), "Keine Session → has_active_session() false")


func test_has_active_session_true_after_begin() -> void:
	_sys.begin_session(PLAYER_A)
	assert_true(_sys.has_active_session(), "Nach begin_session() → has_active_session() true")


func test_has_active_session_false_after_end() -> void:
	_sys.begin_session(PLAYER_A)
	_sys.end_session()
	assert_false(_sys.has_active_session(), "Nach end_session() → has_active_session() false")


# ─────────────────────────────────────────────
# has_save_for()
# ─────────────────────────────────────────────

func test_has_save_for_returns_false_when_no_file() -> void:
	assert_false(_sys.has_save_for(PLAYER_A), "Nicht-existente Datei → false")


func test_has_save_for_returns_true_after_write() -> void:
	_write_dummy(PLAYER_A)
	assert_true(_sys.has_save_for(PLAYER_A), "Nach Datei-Anlage → true")


func test_has_save_for_is_per_player_id() -> void:
	_write_dummy(PLAYER_A)
	assert_false(_sys.has_save_for(PLAYER_B),
		"has_save_for() darf nur die angefragte ID prüfen")


# ─────────────────────────────────────────────
# list_local_saves()
# ─────────────────────────────────────────────

func test_list_includes_written_save() -> void:
	_write_dummy(PLAYER_A)
	var saves := _sys.list_local_saves()
	assert_true(saves.has(PLAYER_A), "Geschriebener Save muss in der Liste erscheinen")


func test_list_shows_multiple_saves() -> void:
	_write_dummy(PLAYER_A)
	_write_dummy(PLAYER_B)
	var saves := _sys.list_local_saves()
	assert_true(saves.has(PLAYER_A), "PLAYER_A muss gelistet sein")
	assert_true(saves.has(PLAYER_B), "PLAYER_B muss gelistet sein")


func test_list_excludes_bak_files() -> void:
	_write_dummy(PLAYER_A)
	# .bak-Datei manuell anlegen (wie sie atomic_write erzeugt)
	var bak_path := _sys.get_save_path(PLAYER_A) + ".bak"
	var bak_file := FileAccess.open(bak_path, FileAccess.WRITE)
	if bak_file:
		bak_file.store_string("{}")
		bak_file.close()
	var saves := _sys.list_local_saves()
	for entry in saves:
		assert_false(entry.ends_with(".bak"),
			".bak-Einträge dürfen nicht in der Liste erscheinen: " + entry)


func test_list_contains_only_ids_not_filenames() -> void:
	_write_dummy(PLAYER_A)
	var saves := _sys.list_local_saves()
	for entry in saves:
		if entry.begins_with(TEST_PREFIX):
			assert_false(entry.ends_with(".json"),
				"Einträge müssen IDs sein, nicht Dateinamen: " + entry)


# ─────────────────────────────────────────────
# delete_save_for()
# ─────────────────────────────────────────────

func test_delete_nonexistent_returns_false() -> void:
	var result := _sys.delete_save_for(PLAYER_A)
	assert_false(result, "Nicht-existenten Save zu löschen → false")


func test_delete_empty_id_returns_false() -> void:
	var result := _sys.delete_save_for("")
	assert_false(result, "Leere ID → false, kein Crash")


func test_delete_removes_main_file() -> void:
	_write_dummy(PLAYER_A)
	_sys.delete_save_for(PLAYER_A)
	assert_false(_sys.has_save_for(PLAYER_A), "Datei muss nach delete_save_for() fehlen")


func test_delete_returns_true_on_success() -> void:
	_write_dummy(PLAYER_A)
	var result := _sys.delete_save_for(PLAYER_A)
	assert_true(result, "Erfolgreiches Löschen → true")


func test_delete_removes_bak_companion() -> void:
	_write_dummy(PLAYER_A)
	var bak_path := _sys.get_save_path(PLAYER_A) + ".bak"
	var bak_file := FileAccess.open(bak_path, FileAccess.WRITE)
	if bak_file:
		bak_file.store_string("{}")
		bak_file.close()
	_sys.delete_save_for(PLAYER_A)
	assert_false(FileAccess.file_exists(bak_path),
		".bak muss zusammen mit dem Haupt-Save gelöscht werden")


func test_delete_does_not_affect_other_saves() -> void:
	_write_dummy(PLAYER_A)
	_write_dummy(PLAYER_B)
	_sys.delete_save_for(PLAYER_A)
	assert_true(_sys.has_save_for(PLAYER_B),
		"delete_save_for(A) darf save von B nicht berühren")


func test_delete_removes_from_list() -> void:
	_write_dummy(PLAYER_A)
	_sys.delete_save_for(PLAYER_A)
	var saves := _sys.list_local_saves()
	assert_false(saves.has(PLAYER_A), "Gelöschter Save darf nicht mehr in der Liste sein")


# ─────────────────────────────────────────────
# Vollständiger Slot-Lifecycle
# ─────────────────────────────────────────────

func test_full_slot_lifecycle_create_switch_delete() -> void:
	# Phase 1: Kein Save vorhanden
	assert_false(_sys.has_save_for(PLAYER_A),     "Phase 1: kein Save")
	assert_false(_sys.list_local_saves().has(PLAYER_A), "Phase 1: nicht in Liste")

	# Phase 2: Save erzeugen
	_write_dummy(PLAYER_A)
	assert_true(_sys.has_save_for(PLAYER_A),      "Phase 2: Save existiert")
	assert_true(_sys.list_local_saves().has(PLAYER_A),  "Phase 2: in Liste sichtbar")

	# Phase 3: Session starten → aktiver Pfad ändert sich (ADR-009: begin_session statt set_active_player_id)
	_sys.begin_session(PLAYER_A)
	assert_eq(_sys.get_active_save_path(), _sys.get_save_path(PLAYER_A),
		"Phase 3: aktiver Pfad muss auf PLAYER_A zeigen")

	# Phase 4: Löschen → aus allen Abfragen entfernt
	var deleted := _sys.delete_save_for(PLAYER_A)
	assert_true(deleted,                             "Phase 4: Löschen erfolgreich")
	assert_false(_sys.has_save_for(PLAYER_A),        "Phase 4: hat_save_for gibt false")
	assert_false(_sys.list_local_saves().has(PLAYER_A), "Phase 4: nicht mehr in Liste")


# ─────────────────────────────────────────────
# Hilfsfunktionen
# ─────────────────────────────────────────────

## Schreibt eine minimale valide Save-Datei direkt auf Disk (umgeht SaveSystem-Lifecycle).
func _write_dummy(player_id: String) -> void:
	var path := _sys.get_save_path(player_id)
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file:
		file.store_string(
			"{\"schema_version\":2,\"player_id\":\"%s\",\"timestamp\":\"2026-06-19\"}" \
			% player_id
		)
		file.close()


## Bereinigt alle Dateien mit TEST_PREFIX aus user://saves/.
## Wird von after_each() aufgerufen.
func _cleanup_test_files() -> void:
	var dir := DirAccess.open(SAVE_DIR)
	if not dir:
		return
	dir.list_dir_begin()
	var to_delete: Array[String] = []
	var fname := dir.get_next()
	while fname != "":
		if fname.begins_with(TEST_PREFIX):
			to_delete.append(fname)
		fname = dir.get_next()
	dir.list_dir_end()
	for f in to_delete:
		DirAccess.remove_absolute(SAVE_DIR + f)
