## tests/unit/test_equipment_service.gd
## Unit-Tests für EquipmentService.
##
## Abdeckung:
##   - equip() / unequip() / get_equipped() / is_equipped()
##   - StatModifier-Anbindung: damage_bonus aus WeaponDefinition wird über
##     StatModifierService.add_modifier() sichtbar, mit korrekter source_id
##   - PARALLELE BUFFS: zwei verschiedene Slots erzeugen zwei unabhängige
##     StatModifier — beide bleiben gleichzeitig aktiv, summieren sich
##     (Kernanforderung dieses Schritts)
##   - Slot-Exklusivität: erneutes equip() auf DENSELBEN Slot ersetzt nur
##     diesen einen Modifier, andere Slots bleiben unberührt
##   - unequip() entfernt Modifier + Visual symmetrisch
##   - on_cleanup() räumt alle "equipment_"-Modifier in einem Rutsch ab
##   - get_equipped_weapon() liefert null für Nicht-Waffen-Items

extends GutTest

var _equipment: EquipmentService
var _stat_mods: StatModifierService


func before_each() -> void:
	_stat_mods = StatModifierService.new()
	_equipment = EquipmentService.new()
	_equipment.configure({"stat_modifiers": _stat_mods})


func after_each() -> void:
	_equipment.on_cleanup()
	_stat_mods.on_cleanup()
	_equipment = null
	_stat_mods = null


func _make_weapon(id: String, dmg_bonus: float) -> WeaponDefinition:
	var w := WeaponDefinition.new()
	w.id = id
	w.display_name = id
	w.damage_bonus = dmg_bonus
	return w


# ─────────────────────────────────────────────
# equip / unequip / Accessors
# ─────────────────────────────────────────────


func test_equip_stores_item_in_slot() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	assert_true(_equipment.equip("weapon", sword))
	assert_eq(_equipment.get_equipped("weapon"), sword)
	assert_true(_equipment.is_equipped("weapon"))


func test_equip_rejects_empty_slot() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	assert_false(_equipment.equip("", sword))


func test_equip_rejects_invalid_item() -> void:
	assert_false(_equipment.equip("weapon", null))


func test_unequip_clears_slot() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	assert_true(_equipment.unequip("weapon"))
	assert_false(_equipment.is_equipped("weapon"))
	assert_null(_equipment.get_equipped("weapon"))


func test_unequip_empty_slot_returns_false() -> void:
	assert_false(_equipment.unequip("weapon"))


func test_get_equipped_weapon_returns_null_for_non_weapon_item() -> void:
	var generic_item := ItemDefinition.new()
	generic_item.id = "raw_log"
	_equipment.equip("offhand", generic_item)
	assert_null(_equipment.get_equipped_weapon("offhand"))


# ─────────────────────────────────────────────
# StatModifier-Anbindung
# ─────────────────────────────────────────────


func test_equip_applies_damage_bonus_as_stat_modifier() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	assert_true(_stat_mods.has_modifier("equipment_weapon"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 15.0)


func test_unequip_removes_stat_modifier() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	_equipment.unequip("weapon")
	assert_false(_stat_mods.has_modifier("equipment_weapon"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 10.0)


func test_equip_zero_damage_bonus_adds_no_modifier() -> void:
	var dagger := _make_weapon("starter_dagger", 0.0)
	_equipment.equip("weapon", dagger)
	assert_false(_stat_mods.has_modifier("equipment_weapon"))


# ─────────────────────────────────────────────
# Parallele Buffs (Kernanforderung)
# ─────────────────────────────────────────────


func test_two_slots_apply_independent_parallel_modifiers() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	var ring  := _make_weapon("power_ring", 3.0)  # Platzhalter — kein eigener RingDefinition-Typ nötig für den Test

	_equipment.equip("weapon", sword)
	_equipment.equip("offhand", ring)

	assert_true(_stat_mods.has_modifier("equipment_weapon"))
	assert_true(_stat_mods.has_modifier("equipment_offhand"))
	# Beide Boni summieren sich — kein gegenseitiges Überschreiben über source_id hinweg.
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 18.0)


func test_unequipping_one_slot_leaves_other_slot_active() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	var ring  := _make_weapon("power_ring", 3.0)
	_equipment.equip("weapon", sword)
	_equipment.equip("offhand", ring)

	_equipment.unequip("weapon")

	assert_false(_stat_mods.has_modifier("equipment_weapon"))
	assert_true(_stat_mods.has_modifier("equipment_offhand"))
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 13.0)


func test_reequipping_same_slot_replaces_only_that_modifier() -> void:
	var sword       := _make_weapon("iron_sword", 5.0)
	var better_sword := _make_weapon("steel_sword", 8.0)
	var ring        := _make_weapon("power_ring", 3.0)

	_equipment.equip("weapon", sword)
	_equipment.equip("offhand", ring)
	_equipment.equip("weapon", better_sword)  # ersetzt nur "weapon"

	assert_eq(_equipment.get_equipped("weapon"), better_sword)
	assert_true(_stat_mods.has_modifier("equipment_offhand"), "offhand-Slot darf vom weapon-Re-Equip nicht betroffen sein.")
	assert_eq(_stat_mods.get_effective_stat("damage_bonus", 10.0), 21.0)  # 10 + 8 + 3


# ─────────────────────────────────────────────
# Cleanup
# ─────────────────────────────────────────────


func test_on_cleanup_removes_all_equipment_modifiers() -> void:
	_equipment.equip("weapon", _make_weapon("iron_sword", 5.0))
	_equipment.equip("offhand", _make_weapon("power_ring", 3.0))

	_equipment.on_cleanup()

	assert_false(_stat_mods.has_modifier("equipment_weapon"))
	assert_false(_stat_mods.has_modifier("equipment_offhand"))
	assert_false(_equipment.is_equipped("weapon"))
	assert_false(_equipment.is_equipped("offhand"))


# ─────────────────────────────────────────────
# Signal
# ─────────────────────────────────────────────


func test_equip_emits_equipment_changed_signal() -> void:
	watch_signals(_equipment)
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	assert_signal_emitted_with_parameters(_equipment, "equipment_changed", ["weapon", sword])


func test_unequip_emits_equipment_changed_with_null() -> void:
	var sword := _make_weapon("iron_sword", 5.0)
	_equipment.equip("weapon", sword)
	watch_signals(_equipment)
	_equipment.unequip("weapon")
	assert_signal_emitted_with_parameters(_equipment, "equipment_changed", ["weapon", null])
