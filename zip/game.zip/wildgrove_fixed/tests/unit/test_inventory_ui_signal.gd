## tests/unit/test_inventory_ui_signal.gd
## Regression-Tests für InventoryUIController Signal-Parameter.
##
## Abdeckung:
##   - inventory_changed(player_id, items) wird korrekt empfangen
##   - UI zeigt Items nach Signal-Emit an (nicht leer)
##   - Items von anderen player_ids werden ignoriert
##   - Leeres Inventar zeigt "(Leer)"

extends GutTest

var _inventory: InventorySystem
var _displayed_lines: Array = []


func before_each() -> void:
	_inventory = InventorySystem.new()
	_inventory.configure({})
	_displayed_lines = []


func after_each() -> void:
	_inventory.on_cleanup()
	_inventory = null


func _capture_signal(player_id: int, items: Array[Dictionary]) -> void:
	if player_id == 1:
		_displayed_lines = items


func test_inventory_changed_emits_player_id_and_items() -> void:
	# Regression: Controller verband _on_inventory_changed(items) direkt —
	# Signal hat aber Signatur (player_id, items), daher kam nie etwas an.
	_inventory.inventory_changed.connect(_capture_signal)
	_inventory.on_item_add_confirmed("iron_ore", 3, 1)
	assert_false(_displayed_lines.is_empty(),
		"inventory_changed muss Items liefern — Signal-Signatur (player_id, items).")


func test_inventory_changed_only_for_player_1() -> void:
	var other_player_received := false
	_inventory.inventory_changed.connect(
		func(player_id: int, _items: Array[Dictionary]) -> void:
			if player_id == 2:
				other_player_received = true
	)
	_inventory.on_item_add_confirmed("iron_ore", 1, 2)
	assert_true(other_player_received, "Signal muss auch für andere player_ids emittiert werden.")
	# UI-Controller filtert selbst auf player_id == 1
	_inventory.on_item_add_confirmed("log_normal", 1, 1)
	assert_eq(_displayed_lines.size(), 0,
		"Capture-Funktion filtert auf player_id==1 — andere dürfen nicht durchkommen.")


func test_item_quantity_in_signal() -> void:
	_inventory.inventory_changed.connect(_capture_signal)
	_inventory.on_item_add_confirmed("iron_ore", 5, 1)
	var found := false
	for item in _displayed_lines:
		if item.get("id") == "iron_ore" and item.get("quantity") == 5:
			found = true
	assert_true(found, "Signal muss korrektes Item mit Menge 5 enthalten.")
