# res://tests/unit/test_save_migration.gd
extends GutTest

## Tests für SaveMigrationService — pure static functions, kein SceneTree nötig.
##
## Abgedeckte Pfade:
##   - Bereits aktueller Save (CURRENT_VERSION) → unverändert
##   - v0 → v2 (volle Kette)
##   - v1 → v2 (halbe Kette)
##   - Downgrade-Warnung (Version > CURRENT_VERSION)
##   - v1 → v2 mit fehlendem quest_progress-Block → kein Crash
##   - v1 → v2: fehlende Felder werden aufgefüllt
##   - v1 → v2: bestehende valide Felder bleiben erhalten

const CURRENT := SaveMigrationService.CURRENT_VERSION


# ─────────────────────────────────────────────
# Aktuelle Version → unverändert zurück
# ─────────────────────────────────────────────

func test_current_version_passthrough() -> void:
	var data := { "schema_version": CURRENT, "inventory": { "gold": 99 } }
	var result := SaveMigrationService.migrate(data)
	assert_eq(result["schema_version"], CURRENT)
	assert_eq(result["inventory"]["gold"], 99, "Inventar muss unberührt bleiben")


# ─────────────────────────────────────────────
# v0 → v2 (volle Migrationskette)
# ─────────────────────────────────────────────

func test_v0_migrates_to_current() -> void:
	var data := {}  # kein schema_version → v0
	var result := SaveMigrationService.migrate(data)
	assert_eq(result["schema_version"], CURRENT)


func test_v0_with_quest_gets_normalized() -> void:
	# v0-Save mit Quest-Block im alten Format (kein level, kein started_at)
	var data := {
		"quest_progress": {
			"active": {
				"quest_wood_01": {
					"status":     "started",
					"objectives": { "chop_5": 3 }
				}
			}
		}
	}
	var result := SaveMigrationService.migrate(data)
	assert_eq(result["schema_version"], CURRENT)
	var entry: Dictionary = result["quest_progress"]["active"]["quest_wood_01"]
	assert_eq(entry.get("level"),      1,         "level muss auf 1 defaulten")
	assert_eq(entry.get("started_at"), 0,         "started_at muss auf 0 defaulten")
	assert_eq(entry.get("status"),     "started",  "status bleibt erhalten")
	assert_eq(entry["objectives"]["chop_5"], 3,    "objectives-Progress bleibt erhalten")


# ─────────────────────────────────────────────
# v1 → v2 (halbe Kette)
# ─────────────────────────────────────────────

func test_v1_migrates_to_current() -> void:
	var data := { "schema_version": 1 }
	var result := SaveMigrationService.migrate(data)
	assert_eq(result["schema_version"], CURRENT)


func test_v1_missing_fields_get_defaults() -> void:
	var data := {
		"schema_version": 1,
		"quest_progress": {
			"active": {
				"quest_mining_01": {
					"status":     "started",
					"objectives": { "mine_10": 5 }
					# level und started_at fehlen absichtlich
				}
			}
		}
	}
	var result := SaveMigrationService.migrate(data)
	var entry: Dictionary = result["quest_progress"]["active"]["quest_mining_01"]
	assert_eq(entry.get("level"),      1, "level Default 1")
	assert_eq(entry.get("started_at"), 0, "started_at Default 0")


func test_v1_existing_fields_preserved() -> void:
	var data := {
		"schema_version": 1,
		"quest_progress": {
			"active": {
				"quest_farming_01": {
					"status":     "started",
					"level":      3,
					"started_at": 1700000000,
					"objectives": { "plant_5": 5 }
				}
			}
		}
	}
	var result := SaveMigrationService.migrate(data)
	var entry: Dictionary = result["quest_progress"]["active"]["quest_farming_01"]
	assert_eq(entry.get("level"),      3,          "Vorhandenes level bleibt erhalten")
	assert_eq(entry.get("started_at"), 1700000000, "Vorhandenes started_at bleibt erhalten")


# ─────────────────────────────────────────────
# Edge Cases
# ─────────────────────────────────────────────

func test_missing_quest_block_no_crash() -> void:
	# v1-Save ohne quest_progress → keine Exception
	var data := { "schema_version": 1, "inventory": {} }
	var result := SaveMigrationService.migrate(data)
	assert_eq(result["schema_version"], CURRENT, "Migration trotzdem abgeschlossen")


func test_corrupt_active_quest_entry_replaced() -> void:
	# Einzelner Quest-Eintrag ist kein Dictionary → soll mit Defaults ersetzt werden
	var data := {
		"schema_version": 1,
		"quest_progress": {
			"active": {
				"quest_broken": "not_a_dict"
			}
		}
	}
	var result := SaveMigrationService.migrate(data)
	var entry: Variant = result["quest_progress"]["active"]["quest_broken"]
	assert_true(entry is Dictionary, "Kaputtes Entry muss als Dictionary ersetzt werden")
	assert_eq((entry as Dictionary).get("status"), "started")


func test_downgrade_returns_data_unchanged() -> void:
	# Save-Version ist höher als Software → warnen aber nicht crashen
	var future_version := CURRENT + 5
	var data := { "schema_version": future_version, "custom_field": "xyz" }
	var result := SaveMigrationService.migrate(data)
	assert_eq(result["schema_version"], future_version, "Downgrade: Version bleibt wie sie ist")
	assert_eq(result.get("custom_field"), "xyz",        "Downgrade: Daten bleiben erhalten")
