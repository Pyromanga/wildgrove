## tests/unit/test_stat_modifier.gd
## Unit-Tests für StatModifier (Daten) und StatModifierService (Logik).
##
## Abdeckung:
##   - StatModifier.permanent() / .temporary() / .is_active()
##   - add_modifier / remove_modifier / has_modifier
##   - get_effective_stat: FLAT_ADD, PERCENT_ADD, PERCENT_MULTIPLY, Kombinationen
##   - Operationsreihenfolge (flat → percent_add → percent_multiply)
##   - cleanup_expired
##   - remove_modifiers_with_prefix
##   - modifier_changed Signal
##   - Edge Cases: leere source_id, unbekannter Stat, Überschreiben

extends GutTest

var _svc: StatModifierService


func before_each() -> void:
	_svc = StatModifierService.new()


func after_each() -> void:
	_svc.on_cleanup()
	_svc = null


# ─────────────────────────────────────────────
# StatModifier Daten-Tests
# ─────────────────────────────────────────────

func test_permanent_modifier_is_always_active() -> void:
	var mod := StatModifier.permanent("src", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	assert_true(mod.is_active(), "Permanenter Modifier muss immer aktiv sein.")
	assert_eq(mod.expires_at, -1.0)


func test_temporary_modifier_is_active_before_expiry() -> void:
	var mod := StatModifier.temporary("src", "damage", StatModifier.Operation.FLAT_ADD, 5.0, 100.0)
	assert_true(mod.is_active(), "Modifier mit 100s Laufzeit muss aktiv sein.")


func test_expired_modifier_is_inactive() -> void:
	var mod := StatModifier.new()
	mod.source_id  = "src"
	mod.stat       = "damage"
	mod.operation  = StatModifier.Operation.FLAT_ADD
	mod.value      = 5.0
	mod.expires_at = 0.001  # schon abgelaufen (unix 0 = 1970)
	assert_false(mod.is_active(), "Modifier mit expires_at in der Vergangenheit muss inaktiv sein.")


func test_to_debug_string_contains_source_and_stat() -> void:
	var mod := StatModifier.permanent("my_sword", "damage", StatModifier.Operation.FLAT_ADD, 10.0)
	var s := mod.to_debug_string()
	assert_true("my_sword" in s, "Debug-String muss source_id enthalten.")
	assert_true("damage" in s, "Debug-String muss stat enthalten.")


# ─────────────────────────────────────────────
# add / remove / has
# ─────────────────────────────────────────────

func test_add_modifier_returns_true_for_valid() -> void:
	var mod := StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	assert_true(_svc.add_modifier(mod))


func test_add_modifier_rejects_empty_source_id() -> void:
	var mod := StatModifier.permanent("", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	assert_false(_svc.add_modifier(mod), "Leere source_id muss abgelehnt werden.")


func test_add_modifier_rejects_empty_stat() -> void:
	var mod := StatModifier.permanent("sword", "", StatModifier.Operation.FLAT_ADD, 5.0)
	assert_false(_svc.add_modifier(mod), "Leerer stat muss abgelehnt werden.")


func test_has_modifier_after_add() -> void:
	var mod := StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	_svc.add_modifier(mod)
	assert_true(_svc.has_modifier("sword"))


func test_has_modifier_false_when_not_added() -> void:
	assert_false(_svc.has_modifier("nonexistent"))


func test_remove_modifier_returns_true() -> void:
	var mod := StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	_svc.add_modifier(mod)
	assert_true(_svc.remove_modifier("sword"))
	assert_false(_svc.has_modifier("sword"))


func test_remove_modifier_returns_false_when_missing() -> void:
	assert_false(_svc.remove_modifier("nonexistent"), "Entfernen eines nicht-existenten Modifiers muss false zurückgeben.")


func test_overwrite_modifier_same_source_id() -> void:
	var mod1 := StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	var mod2 := StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 10.0)
	_svc.add_modifier(mod1)
	_svc.add_modifier(mod2)
	# Effektivwert muss den neueren Modifier widerspiegeln
	var effective := _svc.get_effective_stat("damage", 0.0)
	assert_eq(effective, 10.0, "Überschriebener Modifier muss den neuen Wert haben.")


# ─────────────────────────────────────────────
# get_effective_stat — Einzeloperationen
# ─────────────────────────────────────────────

func test_effective_stat_no_modifiers_returns_base() -> void:
	assert_eq(_svc.get_effective_stat("damage", 50.0), 50.0)


func test_effective_stat_flat_add() -> void:
	_svc.add_modifier(StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 10.0))
	assert_eq(_svc.get_effective_stat("damage", 100.0), 110.0)


func test_effective_stat_multiple_flat_add() -> void:
	_svc.add_modifier(StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 10.0))
	_svc.add_modifier(StatModifier.permanent("ring", "damage", StatModifier.Operation.FLAT_ADD, 5.0))
	assert_eq(_svc.get_effective_stat("damage", 100.0), 115.0)


func test_effective_stat_percent_add() -> void:
	_svc.add_modifier(StatModifier.permanent("buff", "damage", StatModifier.Operation.PERCENT_ADD, 0.20))
	var result := _svc.get_effective_stat("damage", 100.0)
	assert_almost_eq(result, 120.0, 0.001, "100 × (1 + 0.20) = 120")


func test_effective_stat_percent_multiply() -> void:
	_svc.add_modifier(StatModifier.permanent("debuff", "damage", StatModifier.Operation.PERCENT_MULTIPLY, 0.5))
	var result := _svc.get_effective_stat("damage", 100.0)
	assert_almost_eq(result, 50.0, 0.001, "100 × 0.5 = 50")


# ─────────────────────────────────────────────
# get_effective_stat — Operationsreihenfolge
# ─────────────────────────────────────────────

func test_effective_stat_operation_order() -> void:
	## base=100, FLAT_ADD +20 → 120, PERCENT_ADD +0.15 → 138, PERCENT_MULTIPLY ×0.5 → 69
	_svc.add_modifier(StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 20.0))
	_svc.add_modifier(StatModifier.permanent("buff", "damage", StatModifier.Operation.PERCENT_ADD, 0.15))
	_svc.add_modifier(StatModifier.permanent("debuff", "damage", StatModifier.Operation.PERCENT_MULTIPLY, 0.5))
	var result := _svc.get_effective_stat("damage", 100.0)
	assert_almost_eq(result, 69.0, 0.001, "Operationsreihenfolge: flat → percent_add → percent_multiply")


func test_effective_stat_ignores_other_stats() -> void:
	_svc.add_modifier(StatModifier.permanent("boots", "move_speed", StatModifier.Operation.FLAT_ADD, 2.0))
	assert_eq(_svc.get_effective_stat("damage", 100.0), 100.0, "Modifier für anderen Stat darf keinen Einfluss haben.")


# ─────────────────────────────────────────────
# Zeitbasierte Modifier
# ─────────────────────────────────────────────

func test_cleanup_expired_removes_expired_modifiers() -> void:
	var expired := StatModifier.new()
	expired.source_id  = "old_buff"
	expired.stat       = "damage"
	expired.operation  = StatModifier.Operation.FLAT_ADD
	expired.value      = 20.0
	expired.expires_at = 0.001  # in der Vergangenheit
	_svc.add_modifier(expired)

	var permanent := StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0)
	_svc.add_modifier(permanent)

	var removed := _svc.cleanup_expired()
	assert_eq(removed, 1, "Genau ein Modifier muss entfernt worden sein.")
	assert_false(_svc.has_modifier("old_buff"))
	assert_true(_svc.has_modifier("sword"))


func test_expired_modifier_not_counted_in_effective_stat() -> void:
	var expired := StatModifier.new()
	expired.source_id  = "old_buff"
	expired.stat       = "damage"
	expired.operation  = StatModifier.Operation.FLAT_ADD
	expired.value      = 99.0
	expired.expires_at = 0.001
	_svc.add_modifier(expired)

	var result := _svc.get_effective_stat("damage", 100.0)
	assert_eq(result, 100.0, "Abgelaufene Modifier dürfen nicht in den Effektivwert eingehen.")


# ─────────────────────────────────────────────
# Prefix-Remove
# ─────────────────────────────────────────────

func test_remove_modifiers_with_prefix() -> void:
	_svc.add_modifier(StatModifier.permanent("equipment_sword", "damage", StatModifier.Operation.FLAT_ADD, 10.0))
	_svc.add_modifier(StatModifier.permanent("equipment_ring", "damage", StatModifier.Operation.FLAT_ADD, 5.0))
	_svc.add_modifier(StatModifier.permanent("buff_haste", "move_speed", StatModifier.Operation.FLAT_ADD, 2.0))

	var removed := _svc.remove_modifiers_with_prefix("equipment_")
	assert_eq(removed, 2, "Zwei Equipment-Modifier müssen entfernt werden.")
	assert_false(_svc.has_modifier("equipment_sword"))
	assert_false(_svc.has_modifier("equipment_ring"))
	assert_true(_svc.has_modifier("buff_haste"), "Buff darf nicht entfernt worden sein.")


# ─────────────────────────────────────────────
# Signal
# ─────────────────────────────────────────────

func test_modifier_changed_emitted_on_add() -> void:
	watch_signals(_svc)
	_svc.add_modifier(StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0))
	assert_signal_emitted_with_parameters(_svc, "modifier_changed", ["damage"])


func test_modifier_changed_emitted_on_remove() -> void:
	_svc.add_modifier(StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 5.0))
	watch_signals(_svc)
	_svc.remove_modifier("sword")
	assert_signal_emitted_with_parameters(_svc, "modifier_changed", ["damage"])


# ─────────────────────────────────────────────
# get_modifiers_for_stat
# ─────────────────────────────────────────────

func test_get_modifiers_for_stat_returns_correct_entries() -> void:
	_svc.add_modifier(StatModifier.permanent("sword", "damage", StatModifier.Operation.FLAT_ADD, 10.0))
	_svc.add_modifier(StatModifier.permanent("ring", "damage", StatModifier.Operation.PERCENT_ADD, 0.1))
	_svc.add_modifier(StatModifier.permanent("boots", "move_speed", StatModifier.Operation.FLAT_ADD, 2.0))

	var damage_mods := _svc.get_modifiers_for_stat("damage")
	assert_eq(damage_mods.size(), 2, "Zwei Damage-Modifier erwartet.")
	for mod in damage_mods:
		assert_eq(mod.stat, "damage")
