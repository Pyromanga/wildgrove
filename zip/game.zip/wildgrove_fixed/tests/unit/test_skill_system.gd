# res://tests/unit/test_skill_system.gd
## Unit-Tests für SkillSystem.
##
## Abdeckung:
##   - Spieler-State wird bei Bedarf angelegt (_ensure_player Fix 3)
##   - request_add_xp() / _on_xp_add_confirmed() mutieren State korrekt
##   - get_xp() / get_level() lesen den mutierten State zurück
##   - Level-Up bei Erreichen der XP-Schwelle (ohne DataService → level * 100)
##   - XP-Verbrauch beim Level-Up (kein Überlauf)
##   - Zwei player_ids erhalten unabhängigen State (Multi-Tenanz, MIGRATION-010 Phase 1)
##   - Unbekannter Skill-Name → kein Crash, kein State-Leak
##   - get_skill_ids() gibt alle Fallback-Skills zurück
##   - get_save_key() liefert "skills"
##   - get_save_data() liefert serialisierbaren Snapshot
##
## Teardown: kein SceneTree nötig, keine AutoLoads außer Logger/EventBus.

extends GutTest

var _svc: SkillSystem


func before_each() -> void:
	_svc = SkillSystem.new()
	# configure() ohne DataService und ohne SaveSystem — Fallback-Skills werden genutzt
	_svc.configure({})


func after_each() -> void:
	_svc.on_cleanup()
	_svc = null


# ─────────────────────────────────────────────
# Grundzustand
# ─────────────────────────────────────────────

func test_default_player_has_fallback_skills() -> void:
	# configure() ruft _ensure_player(1) auf — Fallback-Skills müssen vorhanden sein
	var ids := _svc.get_skill_ids(1)
	assert_true(ids.has("woodcutting"), "Fallback: 'woodcutting' muss vorhanden sein.")
	assert_true(ids.has("mining"),      "Fallback: 'mining' muss vorhanden sein.")
	assert_true(ids.has("farming"),     "Fallback: 'farming' muss vorhanden sein.")
	assert_true(ids.has("combat"),      "Fallback: 'combat' muss vorhanden sein.")


func test_initial_level_is_1() -> void:
	assert_eq(_svc.get_level("woodcutting"), 1, "Startlevel muss 1 sein.")


func test_initial_xp_is_0() -> void:
	assert_eq(_svc.get_xp("woodcutting"), 0, "Start-XP muss 0 sein.")


# ─────────────────────────────────────────────
# Fix 3 — _ensure_player-Regression
# ─────────────────────────────────────────────

func test_request_add_xp_does_not_crash() -> void:
	# Kerntest für Fix 3: skills war undeclared → jeder XP-Gain crashte
	_svc.request_add_xp("woodcutting", 10)
	assert_eq(_svc.get_xp("woodcutting"), 10,
		"Nach request_add_xp(10) muss XP = 10 sein (Fix 3).")


func test_request_add_xp_accumulates() -> void:
	_svc.request_add_xp("woodcutting", 30)
	_svc.request_add_xp("woodcutting", 20)
	assert_eq(_svc.get_xp("woodcutting"), 50, "XP muss akkumulieren.")


func test_add_xp_to_unknown_skill_is_silent() -> void:
	# Kein Crash, kein State-Leak bei unbekanntem Skill-Namen
	_svc.request_add_xp("nonexistent_skill", 999)
	assert_false(_svc.has_skill("nonexistent_skill"), "Unbekannter Skill darf nicht angelegt werden.")


# ─────────────────────────────────────────────
# Level-Up-Logik (ohne DataService: xp_needed = level * 100)
# ─────────────────────────────────────────────

func test_no_level_up_before_threshold() -> void:
	_svc.request_add_xp("mining", 99)
	assert_eq(_svc.get_level("mining"), 1, "99 XP < 100 → kein Level-Up.")
	assert_eq(_svc.get_xp("mining"),   99, "XP muss erhalten bleiben.")


func test_level_up_at_exact_threshold() -> void:
	_svc.request_add_xp("mining", 100)
	assert_eq(_svc.get_level("mining"), 2, "100 XP → Level 2.")
	assert_eq(_svc.get_xp("mining"),    0, "XP wird beim Level-Up verbraucht.")


func test_level_up_with_overflow_xp() -> void:
	_svc.request_add_xp("mining", 150)
	assert_eq(_svc.get_level("mining"), 2, "150 XP → Level 2.")
	assert_eq(_svc.get_xp("mining"),   50, "Überschuss-XP 50 muss übertragen werden.")


func test_double_level_up_in_one_call() -> void:
	# Level 1→2 braucht 100 XP, Level 2→3 braucht 200 XP — insgesamt 300 XP
	_svc.request_add_xp("mining", 300)
	assert_eq(_svc.get_level("mining"), 3, "300 XP → Level 3 (zwei Level-Ups).")
	assert_eq(_svc.get_xp("mining"),    0, "Kein überschüssiges XP nach genau 300.")


# ─────────────────────────────────────────────
# Multi-Tenanz (MIGRATION-010 Phase 1)
# ─────────────────────────────────────────────

func test_two_player_ids_have_independent_state() -> void:
	_svc.request_add_xp("woodcutting", 50, 1)
	_svc.request_add_xp("woodcutting", 99, 2)

	assert_eq(_svc.get_xp("woodcutting", 1), 50,
		"Spieler 1 darf Spieler-2-XP nicht sehen.")
	assert_eq(_svc.get_xp("woodcutting", 2), 99,
		"Spieler 2 darf Spieler-1-XP nicht sehen.")


func test_level_up_for_player2_does_not_affect_player1() -> void:
	_svc.request_add_xp("combat", 100, 2)

	assert_eq(_svc.get_level("combat", 1), 1, "Level-Up für Spieler 2 darf Spieler 1 nicht verändern.")
	assert_eq(_svc.get_level("combat", 2), 2, "Spieler 2 muss Level 2 haben.")


# ─────────────────────────────────────────────
# Save-Interface
# ─────────────────────────────────────────────

func test_get_save_key_returns_skills() -> void:
	assert_eq(_svc.get_save_key(), "skills", "SAVE_KEY muss 'skills' sein.")


func test_get_save_data_contains_default_player() -> void:
	var data := _svc.get_save_data()
	assert_true(data.has("1"), "get_save_data() muss Spieler '1' (als String-Key) enthalten.")


func test_get_save_data_reflects_xp_changes() -> void:
	_svc.request_add_xp("farming", 42)
	var data := _svc.get_save_data()
	var p1: Dictionary = data.get("1", {}) as Dictionary
	var farming: Dictionary = p1.get("farming", {}) as Dictionary
	assert_eq(farming.get("xp", -1), 42, "get_save_data() muss aktuellen XP-Stand serialisieren.")
