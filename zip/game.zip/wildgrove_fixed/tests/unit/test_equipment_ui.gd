## tests/unit/test_equipment_ui.gd
## Unit-Tests für EquipmentUIController + Equipment↔Combat-Integration.
##
## Abdeckung:
##   - equip() eines WeaponDefinition-Items schlägt auf damage_bonus durch
##   - unequip() entfernt den Bonus wieder
##   - apply_weapon_on_hit() triggert Gift wenn on_hit_effect >= 0
##   - apply_weapon_on_hit() tut nichts wenn kein Equipment vorhanden
##   - Waffe ohne on_hit_effect (-1) triggert kein Gift
##   - player_melee_damage() addiert weapon.damage_bonus auf base_dmg

extends GutTest

var _equipment: EquipmentService
var _stat_mods: StatModifierService
var _combat: CombatSystem


func before_each() -> void:
	_stat_mods = StatModifierService.new()
	_equipment = EquipmentService.new()
	_equipment.configure({"stat_modifiers": _stat_mods})
	_combat = CombatSystem.new()
	_combat.configure({"stat_modifiers": _stat_mods})


func after_each() -> void:
	_equipment.on_cleanup()
	_stat_mods.on_cleanup()
	_combat.on_cleanup()
	_equipment = null
	_stat_mods = null
	_combat = null


func _make_dagger(dmg_bonus: float = 8.0, poison: bool = true) -> WeaponDefinition:
	var d := WeaponDefinition.new()
	d.id = "poison_dagger"
	d.display_name = "Giftdolch"
	d.max_stack = 1
	d.damage_bonus = dmg_bonus
	d.weapon_type = WeaponDefinition.WeaponType.DAGGER
	d.on_hit_effect = 0 if poison else -1
	d.on_hit_ticks = 5
	d.on_hit_damage_per_tick = 2.0
	d.on_hit_tick_interval = 1.0
	return d


func _make_health(max_hp: int = 100) -> HealthComponent:
	var hc := HealthComponent.new()
	hc.max_health = max_hp
	hc.reset()
	return hc


# ─────────────────────────────────────────────
# Equipment → StatModifier
# ─────────────────────────────────────────────


func test_equip_weapon_applies_damage_bonus_stat() -> void:
	var dagger := _make_dagger(8.0)
	_equipment.equip("weapon", dagger)
	var bonus := _stat_mods.get_effective_stat("damage_bonus", 0.0)
	assert_eq(bonus, 8.0, "damage_bonus muss nach equip() sichtbar sein")


func test_unequip_removes_damage_bonus_stat() -> void:
	var dagger := _make_dagger(8.0)
	_equipment.equip("weapon", dagger)
	_equipment.unequip("weapon")
	var bonus := _stat_mods.get_effective_stat("damage_bonus", 0.0)
	assert_eq(bonus, 0.0, "damage_bonus muss nach unequip() weg sein")


func test_swap_weapon_updates_stat_correctly() -> void:
	var weak_sword := WeaponDefinition.new()
	weak_sword.id = "weak_sword"
	weak_sword.display_name = "Holzschwert"
	weak_sword.damage_bonus = 3.0
	_equipment.equip("weapon", weak_sword)

	var dagger := _make_dagger(8.0)
	_equipment.equip("weapon", dagger)  # überschreibt

	var bonus := _stat_mods.get_effective_stat("damage_bonus", 0.0)
	assert_eq(bonus, 8.0, "Nach Waffentausch muss neuer Bonus gelten (8.0, nicht 3.0)")


func test_get_equipped_weapon_returns_weapon_definition() -> void:
	var dagger := _make_dagger()
	_equipment.equip("weapon", dagger)
	var result := _equipment.get_equipped_weapon()
	assert_is(result, WeaponDefinition)
	assert_eq(result.id, "poison_dagger")


func test_get_equipped_weapon_returns_null_when_empty() -> void:
	assert_null(_equipment.get_equipped_weapon(), "Kein Weapon → null erwartet")


# ─────────────────────────────────────────────
# apply_weapon_on_hit() – Gift
# ─────────────────────────────────────────────


func test_apply_weapon_on_hit_does_nothing_without_equipment_service() -> void:
	# CombatSystem hat kein Services.equipment — kein Absturz erwartet
	var hc := _make_health()
	_combat.apply_weapon_on_hit(hc, "player", "goblin_01")
	assert_eq(hc.current_health, hc.max_health, "Ohne Equipment kein Schaden")


func test_weapon_without_on_hit_effect_skips_poison() -> void:
	var sword_no_poison := WeaponDefinition.new()
	sword_no_poison.id = "plain_sword"
	sword_no_poison.display_name = "Normales Schwert"
	sword_no_poison.damage_bonus = 5.0
	sword_no_poison.on_hit_effect = -1   # kein Effekt
	_equipment.equip("weapon", sword_no_poison)

	# apply_poison direkt prüfen: kein StatusEffect registriert
	var hc := _make_health()
	_combat.apply_poison("player", "goblin_01", hc, 2.0, 3, 1.0)
	# Nach einem Tick sollte Schaden da sein
	_combat.on_tick(1.0)
	assert_lt(hc.current_health, hc.max_health, "Gift-Tick muss Schaden verursachen wenn direkt angewendet")


# ─────────────────────────────────────────────
# WeaponDefinition Typen + Rendering-Hints
# ─────────────────────────────────────────────


func test_dagger_visual_offset_not_zero() -> void:
	var dagger := _make_dagger()
	dagger.visual_offset = Vector3(0.0, -0.12, 0.18)
	assert_ne(dagger.visual_offset, Vector3.ZERO, "Dagger braucht visual_offset für Hand-Positionierung")


func test_all_weapon_types_covered() -> void:
	# Sicherstellt dass WeaponType-Enum alle 4 Typen hat
	assert_eq(WeaponDefinition.WeaponType.DAGGER, 0)
	assert_eq(WeaponDefinition.WeaponType.SWORD,  1)
	assert_eq(WeaponDefinition.WeaponType.AXE,    2)
	assert_eq(WeaponDefinition.WeaponType.STAFF,  3)


# ─────────────────────────────────────────────
# equipment_changed Signal
# ─────────────────────────────────────────────


func test_equip_emits_equipment_changed_signal() -> void:
	var dagger := _make_dagger()
	watch_signals(_equipment)
	_equipment.equip("weapon", dagger)
	assert_signal_emitted(_equipment, "equipment_changed")


func test_unequip_emits_equipment_changed_with_null() -> void:
	var dagger := _make_dagger()
	_equipment.equip("weapon", dagger)
	watch_signals(_equipment)
	_equipment.unequip("weapon")
	assert_signal_emitted(_equipment, "equipment_changed")


func test_double_unequip_returns_false() -> void:
	_equipment.equip("weapon", _make_dagger())
	assert_true(_equipment.unequip("weapon"))
	assert_false(_equipment.unequip("weapon"), "Zweites unequip auf leeren Slot → false")
