## tests/unit/test_enemy_npc_pool_reuse.gd
## Regression-Tests für EnemyNPC Pool-Reuse.
##
## Abdeckung:
##   - Nach on_despawn() + on_spawn() ist das died-Signal wieder verbunden
##   - Goblin stirbt korrekt wenn HP auf 0 fallen (nach Pool-Reuse)
##   - HealthComponent.reset() setzt is_dead zurück
##   - is_dead bleibt false nach on_spawn()

extends GutTest

var _enemy: EnemyNPC


func before_each() -> void:
	_enemy = EnemyNPC.new()
	add_child_autofree(_enemy)
	await get_tree().process_frame


func after_each() -> void:
	_enemy = null


func test_died_signal_connected_after_spawn() -> void:
	# Regression: on_despawn() disconnectet died, on_spawn() reconnectete es nie.
	_enemy.on_despawn()
	_enemy.on_spawn({})
	assert_true(
		_enemy._health.died.is_connected(_enemy._die),
		"died-Signal muss nach on_spawn() wieder verbunden sein."
	)


func test_died_signal_connected_on_first_spawn() -> void:
	assert_true(
		_enemy._health.died.is_connected(_enemy._die),
		"died-Signal muss nach _ready() verbunden sein."
	)


func test_enemy_dies_after_pool_reuse() -> void:
	# Simuliert Pool-Reuse: despawn → spawn → Schaden bis Tod
	_enemy.on_despawn()
	_enemy.on_spawn({"max_health": 10})
	var died_count := 0
	_enemy._health.died.connect(func() -> void: died_count += 1)
	_enemy._health.take_damage(10)
	assert_eq(died_count, 1, "Goblin muss nach Pool-Reuse sterben können.")


func test_health_reset_after_pool_reuse() -> void:
	_enemy._health.take_damage(15)
	_enemy.on_despawn()
	_enemy.on_spawn({"max_health": 30})
	assert_eq(_enemy._health.current_health, 30, "HP muss nach on_spawn() auf max_health gesetzt sein.")
	assert_false(_enemy._health.is_dead, "is_dead muss nach on_spawn() false sein.")


func test_double_spawn_does_not_double_connect() -> void:
	# Sicherstellen dass mehrfaches on_spawn() nicht zu doppeltem Signal führt
	_enemy.on_spawn({})
	_enemy.on_spawn({})
	var count := _enemy._health.died.get_connections().size()
	# _die + der in test_enemy_dies_after_pool_reuse addierte — aber hier nur _die
	assert_true(count <= 2, "died-Signal darf nicht mehrfach verbunden werden (count: %d)." % count)
