## tests/unit/test_enemy_npc_pool_reuse.gd
## Regression-Tests für EnemyNPC Pool-Reuse und HealthComponent.
##
## EnemyNPC braucht 3D-Rendering (EnemyVisuals) und kann im headless
## Testmodus nicht instanziiert werden. Deshalb testen wir:
##   a) HealthComponent direkt (das ist die Komponente die buggy war)
##   b) Die Signal-Reconnect-Logik via HealthComponent isoliert

extends GutTest

var _health: HealthComponent


func before_each() -> void:
	_health = HealthComponent.new()
	_health.max_health = 30
	add_child_autofree(_health)
	await get_tree().process_frame


func after_each() -> void:
	_health = null


func test_health_reset_clears_is_dead() -> void:
	# Regression: nach Pool-Reuse war is_dead nicht zurückgesetzt.
	_health.take_damage(30)
	assert_true(_health.is_dead, "Nach vollem Schaden muss is_dead=true sein.")
	_health.reset()
	assert_false(_health.is_dead, "reset() muss is_dead=false setzen.")
	assert_eq(_health.current_health, 30, "reset() muss HP auf max_health setzen.")


func test_died_signal_fires_on_lethal_damage() -> void:
	var died_count := 0
	_health.died.connect(func() -> void: died_count += 1)
	_health.take_damage(30)
	assert_eq(died_count, 1, "died muss genau einmal emittiert werden.")


func test_died_not_fired_twice_after_reset() -> void:
	# Regression: nach Pool-Reuse darf died nicht doppelt feuern.
	var died_count := 0
	_health.died.connect(func() -> void: died_count += 1)

	# Simuliert: erster Tod (despawn)
	_health.take_damage(30)
	# Simuliert: reset (on_spawn)
	_health.reset()
	# Zweiter Tod (neues Leben nach Pool-Reuse)
	_health.take_damage(30)

	assert_eq(died_count, 2,
		"died muss nach reset() wieder feuern — genau 2x total (einmal pro Leben).")


func test_take_damage_does_nothing_when_dead() -> void:
	_health.take_damage(30)
	var hp_after_death := _health.current_health
	_health.take_damage(10)  # Sollte ignoriert werden
	assert_eq(_health.current_health, hp_after_death,
		"Schaden nach Tod darf HP nicht weiter reduzieren.")


func test_health_changed_signal_emitted() -> void:
	var changes := 0
	_health.health_changed.connect(func(_c: int, _m: int) -> void: changes += 1)
	_health.take_damage(10)
	assert_eq(changes, 1, "health_changed muss bei Schaden emittiert werden.")
