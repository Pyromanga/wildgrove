# res://tests/unit/test_entity_context.gd
extends GutTest

## Tests für EntityContext.for_test() — kein AutoLoad, kein SceneTree nötig.
##
## Abgedeckte Pfade:
##   - for_test() liefert gültige EntityContext-Instanz
##   - Alle Getter geben null zurück (kein Mock injiziert)
##   - Nach Injektion liefern Getter die injizierten Mock-Objekte
##   - IEntityContext-Interface korrekt implementiert (alle Methoden vorhanden)
##   - get_event_bus() gibt EventBus zurück (AutoLoad ist im Test verfügbar)


# ─────────────────────────────────────────────
# Minimale Mock-Klassen (inline, kein extra File)
# ─────────────────────────────────────────────

class MockSkillSystem extends SkillSystem:
	func get_level(_skill: String, _player_id: int = 1) -> int: return 42

class MockInventorySystem extends InventorySystem:
	func has_item(_item_id: String, _quantity: int = 1, _player_id: int = 1) -> bool: return true

class MockFactory3D extends Factory3D:
	pass

class MockRespawnService extends RespawnService:
	pass


# ─────────────────────────────────────────────
# Basis-Verhalten
# ─────────────────────────────────────────────

func test_for_test_returns_valid_instance() -> void:
	var ctx := EntityContext.for_test()
	assert_not_null(ctx, "for_test() muss eine EntityContext-Instanz liefern")
	assert_true(ctx is IEntityContext, "EntityContext muss IEntityContext implementieren")


func test_for_test_all_services_null_by_default() -> void:
	var ctx := EntityContext.for_test()
	assert_null(ctx.get_skill_system(), "SkillSystem ohne Injektion → null")
	assert_null(ctx.get_inventory(),    "InventorySystem ohne Injektion → null")
	assert_null(ctx.get_factory(),      "Factory3D ohne Injektion → null")
	assert_null(ctx.get_respawn(),      "RespawnService ohne Injektion → null")


func test_for_test_independent_instances() -> void:
	# Zwei for_test()-Aufrufe → unabhängige Instanzen (kein Singleton-Leak)
	var ctx_a := EntityContext.for_test()
	var ctx_b := EntityContext.for_test()
	ctx_a._skill_system = MockSkillSystem.new()
	assert_null(ctx_b.get_skill_system(), "ctx_b darf ctx_a-Injection nicht sehen")


# ─────────────────────────────────────────────
# Mock-Injection
# ─────────────────────────────────────────────

func test_injected_skill_system_returned() -> void:
	var ctx  := EntityContext.for_test()
	var mock := MockSkillSystem.new()
	ctx._skill_system = mock
	assert_eq(ctx.get_skill_system(), mock, "Injiziertes SkillSystem wird zurückgegeben")


func test_injected_inventory_returned() -> void:
	var ctx  := EntityContext.for_test()
	var mock := MockInventorySystem.new()
	ctx._inventory = mock
	assert_eq(ctx.get_inventory(), mock, "Injiziertes Inventory wird zurückgegeben")


func test_injected_factory_returned() -> void:
	var ctx  := EntityContext.for_test()
	var mock := MockFactory3D.new()
	ctx._factory = mock
	assert_eq(ctx.get_factory(), mock, "Injizierte Factory wird zurückgegeben")


func test_injected_respawn_returned() -> void:
	var ctx  := EntityContext.for_test()
	var mock := MockRespawnService.new()
	ctx._respawn = mock
	assert_eq(ctx.get_respawn(), mock, "Injizierter RespawnService wird zurückgegeben")


func test_mock_skill_system_method_callable() -> void:
	var ctx  := EntityContext.for_test()
	var mock := MockSkillSystem.new()
	ctx._skill_system = mock

	# Verhalten des Mocks prüfen (nicht nur Identität)
	assert_eq(ctx.get_skill_system().get_level("woodcutting"), 42,
		"Mock-SkillSystem.get_level() muss 42 zurückgeben")


# ─────────────────────────────────────────────
# IEntityContext-Vertrag
# ─────────────────────────────────────────────

func test_ientitycontext_base_methods_return_null() -> void:
	# IEntityContext selbst (Basisklasse) gibt auf allen Gettern null zurück
	var base := IEntityContext.new()
	assert_null(base.get_skill_system())
	assert_null(base.get_inventory())
	assert_null(base.get_factory())
	assert_null(base.get_respawn())


func test_get_event_bus_returns_autoload() -> void:
	# EventBus ist AutoLoad — auch im Test verfügbar
	var ctx := EntityContext.for_test()
	var bus := ctx.get_event_bus()
	assert_not_null(bus, "get_event_bus() darf nie null sein")
