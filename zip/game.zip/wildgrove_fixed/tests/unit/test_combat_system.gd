## tests/unit/test_combat_system.gd
## Unit-Tests für CombatSystem, DamageRecord-Factories und CombatProfile.
##
## Abdeckung:
##   - calculate_damage(): PHYSICAL/MAGIC-Mitigation, TRUE ignoriert Resistenz,
##     MIN_DAMAGE-Clamp, Rüstungs-Clamp auf max. 0.85
##   - calculate_damage_with_profile() (TD-10): CombatProfile-Resistenz, null-Fallback
##   - CombatProfile.get_resistance() / default_profile()
##   - DamageRecord.make_player_attack() / make_enemy_attack() (TD-11)
##   - player_melee_damage() / enemy_melee_damage(): Ziel-IDs, DamageType
##   - apply_damage(): mutiert HealthComponent, ignoriert bereits tote Ziele
##   - roll_critical(): bleibt innerhalb eines statistisch plausiblen Bands
##   - roll_critical() / TD-13: Determinismus bei injiziertem RandomNumberGenerator
##   - Status-Effekte (TD-12): apply_poison()/apply_burn(), on_tick()-Verarbeitung,
##     Ablauf nach total_ticks, Overwrite-Semantik, remove_status_effect()

extends GutTest

var _combat: CombatSystem


func before_each() -> void:
	_combat = CombatSystem.new()
	_combat.configure({})  # kein StatModifierService nötig — optionale dep


func after_each() -> void:
	_combat.on_cleanup()
	_combat = null


## calculate_damage() würfelt intern einen Krit (BASE_CRIT_CHANCE = 5%). Die Tests in
## diesem before_each() nutzen bewusst KEINEN geseedeten RNG (configure({}) → randomisierte
## Default-Instanz, TD-13) — die meisten Tests hier prüfen produktionsnahes Verhalten und
## sollen nicht an einen bestimmten Seed gekoppelt sein. Tests für PHYSICAL/MAGIC dürfen
## sich daher NICHT auf einen exakten Wert verlassen, sonst sind sie ~5% der Läufe flaky.
## Dieser Helfer akzeptiert sowohl den Nicht-Krit- als auch den Krit-Wert (×1.5).
## TRUE-Schaden und der MIN_DAMAGE-Clamp sind crit-unabhängig und brauchen ihn nicht.
## Für Tests die echten Determinismus brauchen: configure({"rng": seeded_rng}) (siehe
## test_roll_critical_is_deterministic_with_same_seed()).
func _assert_damage_matches_expected_or_crit(actual: float, expected: float, msg: String) -> void:
	var crit_expected := expected * CombatSystem.CRIT_MULTIPLIER
	var matches := is_equal_approx(actual, expected) or is_equal_approx(actual, crit_expected)
	assert_true(
		matches,
		"%s (erwartet %.2f oder %.2f bei Krit, war %.2f)" % [msg, expected, crit_expected, actual]
	)


# ─────────────────────────────────────────────
# calculate_damage() — rohe Floats
# ─────────────────────────────────────────────

func test_physical_damage_no_armor_passes_through() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 20.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage(rec, 0.0, 0.0)
	_assert_damage_matches_expected_or_crit(rec.final_amount, 20.0, "Ohne Rüstung muss roher Schaden unverändert durchgehen.")


func test_physical_damage_mitigated_by_armor() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 20.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage(rec, 0.5, 0.0)
	_assert_damage_matches_expected_or_crit(rec.final_amount, 10.0, "20 × (1 - 0.5) = 10")


func test_magic_damage_mitigated_by_magic_resist() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 40.0, DamageRecord.DamageType.MAGIC)
	_combat.calculate_damage(rec, 0.0, 0.25)
	_assert_damage_matches_expected_or_crit(rec.final_amount, 30.0, "40 × (1 - 0.25) = 30")


func test_physical_armor_ignores_magic_resist_value() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 20.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage(rec, 0.0, 0.9)  # magic_resist hoch, aber irrelevant für PHYSICAL
	_assert_damage_matches_expected_or_crit(rec.final_amount, 20.0, "Magic-Resist darf PHYSICAL-Schaden nicht beeinflussen.")


func test_true_damage_ignores_all_resistance() -> void:
	## TRUE-Schaden überspringt den Krit-Check im Code (record.damage_type != TRUE-Gate)
	## — deshalb hier exakte Gleichheit statt des Krit-toleranten Helfers.
	var rec := DamageRecord.make_player_attack("player", "goblin", 15.0, DamageRecord.DamageType.TRUE)
	_combat.calculate_damage(rec, 0.9, 0.9)
	assert_eq(rec.final_amount, 15.0, "TRUE-Schaden muss jede Resistenz ignorieren (ADR-008).")
	assert_false(rec.is_critical, "TRUE-Schaden darf nie kritisch sein.")


func test_armor_clamped_at_max_85_percent() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 100.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage(rec, 1.0, 0.0)  # 100% Rüstung angefragt
	_assert_damage_matches_expected_or_crit(rec.final_amount, 15.0, "Rüstung wird auf 0.85 geclampt: 100 × (1 - 0.85) = 15")


func test_min_damage_clamp_prevents_zero_damage() -> void:
	## Bei raw=1.0 und 0.85 Rüstung bleibt selbst der Krit-Wert (1.5) unter
	## MIN_DAMAGE — der Clamp absorbiert die Krit-Varianz, exakte Gleichheit ist sicher.
	var rec := DamageRecord.make_player_attack("player", "goblin", 1.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage(rec, 0.85, 0.0)
	assert_eq(rec.final_amount, 1.0, "MIN_DAMAGE = 1.0 verhindert 0-Schaden auch bei voller Rüstung.")


func test_calculate_damage_returns_same_record_instance() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 10.0)
	var result := _combat.calculate_damage(rec)
	assert_eq(result, rec, "calculate_damage() muss denselben Record zurückgeben, nicht kopieren.")


# ─────────────────────────────────────────────
# calculate_damage_with_profile() (TD-10)
# ─────────────────────────────────────────────

func test_calculate_damage_with_profile_applies_armor() -> void:
	var profile := CombatProfile.new()
	profile.id = "goblin"
	profile.armor = 0.5
	profile.magic_resist = 0.0

	var rec := DamageRecord.make_player_attack("player", "goblin", 20.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage_with_profile(rec, profile)
	_assert_damage_matches_expected_or_crit(rec.final_amount, 10.0, "Profil-Rüstung 0.5 muss wie target_armor=0.5 wirken.")


func test_calculate_damage_with_profile_applies_magic_resist() -> void:
	var profile := CombatProfile.new()
	profile.armor = 0.0
	profile.magic_resist = 0.5

	var rec := DamageRecord.make_player_attack("player", "goblin", 20.0, DamageRecord.DamageType.MAGIC)
	_combat.calculate_damage_with_profile(rec, profile)
	_assert_damage_matches_expected_or_crit(rec.final_amount, 10.0, "Profil-Magic-Resist 0.5 muss wie target_magic_resist=0.5 wirken.")


func test_calculate_damage_with_profile_null_falls_back_to_no_resistance() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 20.0, DamageRecord.DamageType.PHYSICAL)
	_combat.calculate_damage_with_profile(rec, null)
	_assert_damage_matches_expected_or_crit(rec.final_amount, 20.0, "null-Profil darf nicht crashen — Fallback ist 0% Resistenz.")


# ─────────────────────────────────────────────
# CombatProfile
# ─────────────────────────────────────────────

func test_combat_profile_get_resistance_physical() -> void:
	var p := CombatProfile.new()
	p.armor = 0.3
	p.magic_resist = 0.7
	assert_eq(p.get_resistance(DamageRecord.DamageType.PHYSICAL), 0.3)


func test_combat_profile_get_resistance_magic() -> void:
	var p := CombatProfile.new()
	p.armor = 0.3
	p.magic_resist = 0.7
	assert_eq(p.get_resistance(DamageRecord.DamageType.MAGIC), 0.7)


func test_combat_profile_get_resistance_true_is_always_zero() -> void:
	var p := CombatProfile.new()
	p.armor = 0.9
	p.magic_resist = 0.9
	assert_eq(p.get_resistance(DamageRecord.DamageType.TRUE), 0.0, "TRUE hat kein eigenes Resistenz-Feld.")


func test_default_profile_has_no_resistance() -> void:
	var p := CombatProfile.default_profile()
	assert_eq(p.armor, 0.0)
	assert_eq(p.magic_resist, 0.0)


# ─────────────────────────────────────────────
# DamageRecord-Factories
# ─────────────────────────────────────────────

func test_make_player_attack_sets_fields() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin_1", 25.0, DamageRecord.DamageType.MAGIC)
	assert_eq(rec.source_id, "player")
	assert_eq(rec.target_id, "goblin_1")
	assert_eq(rec.raw_amount, 25.0)
	assert_eq(rec.damage_type, DamageRecord.DamageType.MAGIC)


func test_make_enemy_attack_sets_fields() -> void:
	var rec := DamageRecord.make_enemy_attack("goblin_1", "player", 5.0)
	assert_eq(rec.source_id, "goblin_1")
	assert_eq(rec.target_id, "player")
	assert_eq(rec.raw_amount, 5.0)
	assert_eq(rec.damage_type, DamageRecord.DamageType.PHYSICAL, "Default-DamageType muss PHYSICAL sein.")
	assert_eq(rec.context_tag, "enemy_melee", "make_enemy_attack muss die Angriffsrichtung im context_tag dokumentieren.")


# ─────────────────────────────────────────────
# player_melee_damage() / enemy_melee_damage()
# ─────────────────────────────────────────────

func test_player_melee_damage_scales_with_skill_level() -> void:
	var skill := SkillSystem.new()
	# MIGRATION-010: skills liegen jetzt unter _players[peer_id][skill_id],
	# nicht mehr flach unter einer "skills"-Property (die es nicht mehr gibt).
	skill._players[1] = {"combat": {"xp": 0, "level": 3}}
	var rec := _combat.player_melee_damage(skill, "player")
	assert_eq(rec.raw_amount, 16.0, "10 Basis + 3 × 2 = 16")
	assert_eq(rec.source_id, "player")


func test_player_melee_damage_without_skill_system_uses_base() -> void:
	var rec := _combat.player_melee_damage(null, "player")
	assert_eq(rec.raw_amount, 10.0, "Ohne SkillSystem nur Basis-Schaden.")


func test_enemy_melee_damage_uses_raw_damage_directly() -> void:
	var rec := _combat.enemy_melee_damage("goblin_1", "player", 7.0)
	assert_eq(rec.raw_amount, 7.0, "Gegner haben keine Skill-Level-Skalierung (noch kein Skill-System für NPCs).")
	assert_eq(rec.source_id, "goblin_1")
	assert_eq(rec.target_id, "player")
	assert_eq(rec.damage_type, DamageRecord.DamageType.PHYSICAL)


# ─────────────────────────────────────────────
# apply_damage()
# ─────────────────────────────────────────────

func test_apply_damage_reduces_health() -> void:
	var hc := HealthComponent.new()
	hc.max_health = 50
	var rec := DamageRecord.make_player_attack("player", "goblin", 10.0)
	rec.final_amount = 10.0
	var ok := _combat.apply_damage(rec, hc)
	assert_true(ok)
	assert_eq(hc.current_health, 40)
	hc.free()


func test_apply_damage_returns_false_for_dead_target() -> void:
	var hc := HealthComponent.new()
	hc.max_health = 10
	hc.take_damage(10)  # tötet das Ziel
	assert_true(hc.is_dead)
	var rec := DamageRecord.make_player_attack("player", "goblin", 5.0)
	rec.final_amount = 5.0
	var ok := _combat.apply_damage(rec, hc)
	assert_false(ok, "apply_damage() darf auf bereits toten Zielen nichts mehr tun.")
	hc.free()


func test_apply_damage_returns_false_for_invalid_target() -> void:
	var rec := DamageRecord.make_player_attack("player", "goblin", 5.0)
	rec.final_amount = 5.0
	assert_false(_combat.apply_damage(rec, null))


# ─────────────────────────────────────────────
# roll_critical()
# ─────────────────────────────────────────────

func test_roll_critical_stays_within_plausible_band() -> void:
	## BASE_CRIT_CHANCE = 0.05. Über 2000 Würfe sollte die Trefferquote deutlich
	## unter 20% bleiben — großzügige Toleranz, um Flakiness durch Zufall zu vermeiden.
	var crits := 0
	for i in 2000:
		if _combat.roll_critical("player"):
			crits += 1
	assert_lt(crits, 400, "Kritische Treffer sollten bei 5% Basis-Chance deutlich unter 20% liegen.")


# ─────────────────────────────────────────────
# roll_critical() — TD-13 Determinismus
# ─────────────────────────────────────────────

## Zwei CombatSystem-Instanzen mit identisch geseedetem RandomNumberGenerator müssen
## exakt dieselbe Krit-Sequenz erzeugen. Bewusst KEINE Prüfung auf einen konkreten
## erwarteten Wert (der hängt von Godots PCG32-Implementierung ab) — die Garantie,
## die TD-13 liefert, ist Reproduzierbarkeit bei gleichem Seed, nicht ein bestimmtes
## Ergebnis. Würde roll_critical() versehentlich wieder auf das globale randf()
## zurückfallen, schlägt dieser Test mit überwältigender Wahrscheinlichkeit fehl.
func test_roll_critical_is_deterministic_with_same_seed() -> void:
	var rng_a := RandomNumberGenerator.new()
	rng_a.seed = 12345
	var combat_a := CombatSystem.new()
	combat_a.configure({"rng": rng_a})

	var rng_b := RandomNumberGenerator.new()
	rng_b.seed = 12345
	var combat_b := CombatSystem.new()
	combat_b.configure({"rng": rng_b})

	var sequence_a: Array[bool] = []
	var sequence_b: Array[bool] = []
	for i in 50:
		sequence_a.append(combat_a.roll_critical())
		sequence_b.append(combat_b.roll_critical())

	assert_eq(sequence_a, sequence_b, "Gleicher Seed muss dieselbe Krit-Sequenz erzeugen (TD-13).")

	combat_a.on_cleanup()
	combat_b.on_cleanup()


## configure({}) ohne "rng"-Key darf nicht crashen — Default-Pfad (randomisierte
## Eigeninstanz) muss weiterhin funktionieren. Reine Regressionsabsicherung,
## der eigentliche Zufalls-Test ist test_roll_critical_stays_within_plausible_band().
func test_configure_without_rng_key_does_not_crash() -> void:
	var combat := CombatSystem.new()
	combat.configure({})
	var result := combat.roll_critical()
	assert_true(result == true or result == false, "roll_critical() muss einen bool zurückgeben.")
	combat.on_cleanup()


# ─────────────────────────────────────────────
# Status-Effekte (TD-12)
# ─────────────────────────────────────────────
## HINWEIS zu Krit-Toleranz: roll_critical() würfelt auch bei Status-Effekt-Ticks
## (calculate_damage() unterscheidet nicht zwischen normalem Treffer und DoT-Tick).
## Wo die exakte Schadenshöhe geprüft wird, wird daher mit einem Min/Max-Band
## gerechnet: pro Tick liefert int(damage_per_tick) im Normalfall, int(damage_per_tick
## × CRIT_MULTIPLIER) im Krit-Fall. Tests die nur Tick-Buchhaltung prüfen (Ablauf,
## Overwrite, Anzahl aktiver Effekte) sind davon nicht betroffen.

func _hc(max_hp: int = 50) -> HealthComponent:
	var hc := HealthComponent.new()
	hc.max_health = max_hp
	return hc


func test_apply_poison_returns_null_for_invalid_health_component() -> void:
	var effect := _combat.apply_poison("goblin_1", "player", null, 5.0, 3)
	assert_null(effect, "Ungültiges HealthComponent darf keinen Effekt registrieren.")
	assert_eq(_combat.get_active_status_effect_count(), 0)


func test_apply_poison_returns_null_for_already_dead_target() -> void:
	var hc := _hc(10)
	hc.take_damage(10)
	assert_true(hc.is_dead)
	var effect := _combat.apply_poison("goblin_1", "player", hc, 5.0, 3)
	assert_null(effect, "Bereits totes Ziel darf keinen neuen Status-Effekt erhalten.")
	hc.free()


func test_apply_poison_returns_null_for_zero_tick_interval() -> void:
	var hc := _hc()
	var effect := _combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 0.0)
	assert_null(effect, "tick_interval <= 0 muss abgelehnt werden (sonst Endlosschleife in on_tick()).")
	hc.free()


func test_apply_poison_returns_null_for_zero_total_ticks() -> void:
	var hc := _hc()
	var effect := _combat.apply_poison("goblin_1", "player", hc, 5.0, 0, 1.0)
	assert_null(effect, "total_ticks <= 0 muss abgelehnt werden.")
	hc.free()


func test_apply_poison_registers_active_effect() -> void:
	var hc := _hc()
	var effect := _combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	assert_not_null(effect)
	assert_eq(_combat.get_active_status_effect_count(), 1)
	assert_true(_combat.has_status_effect(effect.effect_key))
	hc.free()


func test_apply_poison_and_apply_burn_coexist_independently() -> void:
	## Unterschiedlicher Kind → unterschiedlicher effect_key → beide gleichzeitig aktiv,
	## kein gegenseitiges Überschreiben trotz identischer source_id/target_id.
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	_combat.apply_burn("goblin_1", "player", hc, 3.0, 2, 1.0)
	assert_eq(_combat.get_active_status_effect_count(), 2,
		"Gift und Brand auf demselben Ziel müssen unabhängige Effekte sein.")
	hc.free()


func test_on_tick_does_not_tick_before_interval_elapsed() -> void:
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	_combat.on_tick(0.5)  # < tick_interval
	assert_eq(hc.current_health, hc.max_health, "Vor Ablauf des Intervalls darf kein Schaden anfallen.")
	assert_eq(_combat.get_active_status_effect_count(), 1, "Effekt darf vor Ablauf nicht entfernt werden.")
	hc.free()


func test_on_tick_applies_damage_after_interval_elapsed() -> void:
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	_combat.on_tick(1.0)
	var loss: int = hc.max_health - hc.current_health
	assert_true(loss == 5 or loss == 7,
		"Ein Tick muss int(5.0) oder bei Krit int(5.0*1.5)=7 Schaden verursachen, war %d." % loss)
	hc.free()


func test_status_effect_expires_after_total_ticks_not_before() -> void:
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	_combat.on_tick(1.0)  # Tick 1/3
	assert_eq(_combat.get_active_status_effect_count(), 1, "Nach 1 von 3 Ticks noch aktiv.")
	_combat.on_tick(1.0)  # Tick 2/3
	assert_eq(_combat.get_active_status_effect_count(), 1, "Nach 2 von 3 Ticks noch aktiv.")
	_combat.on_tick(1.0)  # Tick 3/3 — letzter Tick, danach Ablauf
	assert_eq(_combat.get_active_status_effect_count(), 0, "Nach 3 von 3 Ticks muss der Effekt abgelaufen sein.")
	hc.free()


func test_status_effect_does_not_tick_again_after_expiry() -> void:
	## 4. on_tick()-Aufruf nach Ablauf darf keinen weiteren Schaden mehr verursachen —
	## Schadens-Obergrenze bleibt das 3-Tick-Band (min 15, max 21 bei worst-case Krit).
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	for i in 4:
		_combat.on_tick(1.0)
	var loss: int = hc.max_health - hc.current_health
	assert_true(loss >= 15 and loss <= 21,
		"Schaden nach 4 on_tick()-Aufrufen (nur 3 Ticks konfiguriert) muss im 3-Tick-Band liegen, war %d." % loss)
	hc.free()


func test_multiple_due_ticks_in_single_on_tick_call_are_caught_up() -> void:
	## Ein einzelner on_tick(3.0) bei tick_interval=1.0 muss alle 3 fälligen Ticks
	## nachholen (Lag-Spike-Fall) statt nur einen.
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	_combat.on_tick(3.0)
	assert_eq(_combat.get_active_status_effect_count(), 0, "Effekt muss nach einem 3.0s-Tick (3× Intervall) abgelaufen sein.")
	var loss: int = hc.max_health - hc.current_health
	assert_true(loss >= 15 and loss <= 21, "Alle 3 nachgeholten Ticks müssen Schaden verursacht haben, war %d." % loss)
	hc.free()


func test_reapplying_poison_overwrites_and_resets_remaining_ticks() -> void:
	## Diskriminierender Test: Ohne Overwrite-Reset wären nach 1+2=3 Ticks noch
	## 5-1-2=2 Ticks übrig (aktiv). Mit Reset auf total_ticks=2 ist der Effekt nach
	## 2 weiteren Ticks komplett abgelaufen.
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 5, 1.0)
	_combat.on_tick(1.0)  # 1 von ursprünglich 5 Ticks verbraucht
	assert_eq(_combat.get_active_status_effect_count(), 1)

	_combat.apply_poison("goblin_1", "player", hc, 5.0, 2, 1.0)  # Überschreibt → total_ticks=2
	_combat.on_tick(1.0)  # 1/2
	assert_eq(_combat.get_active_status_effect_count(), 1, "Nach Overwrite + 1 Tick muss noch 1 Tick übrig sein.")
	_combat.on_tick(1.0)  # 2/2
	assert_eq(_combat.get_active_status_effect_count(), 0,
		"Nach Overwrite muss der Effekt nach genau 2 (nicht 4) weiteren Ticks ablaufen.")
	hc.free()


func test_remove_status_effect_stops_further_ticks() -> void:
	var hc := _hc()
	var effect := _combat.apply_poison("goblin_1", "player", hc, 5.0, 5, 1.0)
	var removed := _combat.remove_status_effect(effect.effect_key)
	assert_true(removed)
	assert_false(_combat.has_status_effect(effect.effect_key))

	_combat.on_tick(10.0)  # würde alle 5 Ticks nachholen, wenn der Effekt noch aktiv wäre
	assert_eq(hc.current_health, hc.max_health, "Nach remove_status_effect() darf kein weiterer Schaden anfallen.")
	hc.free()


func test_remove_status_effect_returns_false_for_unknown_key() -> void:
	var result := _combat.remove_status_effect("999:unknown:unknown")
	assert_false(result)


func test_status_effect_removed_when_target_becomes_invalid() -> void:
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 3, 1.0)
	hc.free()  # Ziel verschwindet bevor der nächste Tick fällig wird
	_combat.on_tick(1.0)
	assert_eq(_combat.get_active_status_effect_count(), 0,
		"Effekt muss entfernt werden, sobald das Ziel-HealthComponent ungültig wird.")


func test_status_effect_removed_when_target_dies_between_ticks() -> void:
	var hc := _hc(10)
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 5, 1.0)
	hc.take_damage(10)  # Ziel stirbt durch eine andere Schadensquelle
	assert_true(hc.is_dead)
	_combat.on_tick(1.0)
	assert_eq(_combat.get_active_status_effect_count(), 0,
		"Effekt muss entfernt werden, sobald das Ziel zwischen zwei Ticks stirbt.")
	hc.free()


func test_on_cleanup_clears_all_active_effects() -> void:
	var hc := _hc()
	_combat.apply_poison("goblin_1", "player", hc, 5.0, 5, 1.0)
	_combat.apply_burn("goblin_1", "player", hc, 3.0, 5, 1.0)
	assert_eq(_combat.get_active_status_effect_count(), 2)
	_combat.on_cleanup()
	assert_eq(_combat.get_active_status_effect_count(), 0, "on_cleanup() muss alle aktiven Effekte leeren.")
	hc.free()
